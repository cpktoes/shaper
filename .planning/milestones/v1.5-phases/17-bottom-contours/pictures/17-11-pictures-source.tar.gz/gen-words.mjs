// Scratch: writes components/bottom/bottom-guide-words.ts from the founder's page, so no line is retyped by hand.
import { readFileSync, writeFileSync } from "node:fs";
const [, , mdPath, outPath] = process.argv;
const md = readFileSync(mdPath, "utf8").split("\n");
const sectionOf = { Nose: "nose", Center: "center", Tail: "tail" };
let section = null;
const cards = [];
let card = null;
for (const line of md) {
  const h2 = /^## (.+)$/.exec(line);
  if (h2) {
    const word = h2[1].split(" ")[0];
    section = sectionOf[word] ?? (word === "Channels" ? "channels" : null);
    continue;
  }
  const h3 = /^### (\d+)\. (.+)$/.exec(line);
  if (h3) {
    card = { key: h3[2], section, lines: [] };
    cards.push(card);
    continue;
  }
  const bullet = /^- \*\*(.+?):\*\* (.+)$/.exec(line);
  if (bullet && card) card.lines.push(bullet[2]);
}
if (cards.length !== 19 || cards.some((c) => c.lines.length !== 3)) throw new Error("expected 19 cards of 3 lines");
const q = (s) => JSON.stringify(s);
const body = cards
  .map((c) => `  {\n    key: ${q(c.key)},\n    section: ${q(c.section)},\n    is: ${q(c.lines[0])},\n    does: ${q(c.lines[1])},\n    how: ${q(c.lines[2])},\n  },`)
  .join("\n");
const out = `/**
 * The GUIDE's words (Phase 17, D-18): nineteen cards, three lines each — what the cut is and looks like, what it does,
 * and how it is shaped — copied word for word from the founder's page, \`17-GUIDE-WORDS.md\`.
 *
 * That page is the source of truth, and it is his to mark up: a correction lands in both files in one change, and
 * \`bottom-guide-words.test.ts\` reads the page and fails if a single line here differs from it. Nothing else lives
 * here — no number, no drawing, no markup; the cards draw these strings as plain text.
 */
import type { BottomCutName, BottomSectionKey } from "@/lib/geometry/bottom";

/** One GUIDE card's words. \`key\` is the cut's own name (or \`Channels\`); \`section\` is the group it is listed under. */
export interface BottomGuideCard {
  key: BottomCutName | "Channels";
  section: BottomSectionKey | "channels";
  /** What it is and looks like — drawn in ink. */
  is: string;
  /** What it does — drawn muted, after \`is\` in the same paragraph. */
  does: string;
  /** How to shape — the note under the dashed rule. */
  how: string;
}

/** The nineteen cards in the page's order: Nose, Center, Tail, then Channels (cut last, inside TAIL). */
export const BOTTOM_GUIDE_WORDS: readonly BottomGuideCard[] = [
${body}
];
`;
writeFileSync(outPath, out);
console.log("wrote", cards.length, "cards");

// Scratch: how long do the nineteen cartoons take on each preset, and how much path data do they hold?
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { BOTTOM_CUT_NAMES, BOTTOM_SECTIONS } from "@/lib/geometry/bottom";
import { guideCartoon, type GuideCartoonKey } from "@/lib/geometry/bottom-draw";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";

const keys: GuideCartoonKey[] = [
  ...BOTTOM_SECTIONS.flatMap((section) => BOTTOM_CUT_NAMES[section].map((name) => ({ section, name }) as GuideCartoonKey)),
  { section: "channels" },
];
const all = phase16Boards();
for (const preset of BOARD_PRESETS) {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b) => b.label === label)!.fields;
  const geometry = buildOutline(fields.outline);
  const board = designBottomBoard(fields.outline, geometry, designSideProfile(fields, LIVE_DESIGN_RULES), designFinPlacement(fields));
  for (let pass = 0; pass < 2; pass++) {
    const t0 = performance.now();
    let chars = 0;
    let worst = 0;
    let worstName = "";
    for (const key of keys) {
      const t1 = performance.now();
      const c = guideCartoon(key, board, geometry);
      const dt = performance.now() - t1;
      if (dt > worst) {
        worst = dt;
        worstName = "name" in key ? key.name : "Channels";
      }
      chars += c.board.length + c.shade.join("").length + c.pencil.length + c.trough.length + c.section.pieces.join("").length;
    }
    console.log(preset.id, `pass ${pass}`, `${(performance.now() - t0).toFixed(0)} ms for 19`, `worst ${worst.toFixed(1)} ms (${worstName})`, `${(chars / 1000).toFixed(0)} KB of path data`);
  }
}

import { defineConfig, devices } from "@playwright/test";

// Scratch config for 17-11's pictures: the worktree's own dev server on 3311, already running. Two times the dots so
// the words are sharp when the founder reads them.
export default defineConfig({
  testDir: ".",
  testMatch: /guide-pictures\.spec\.ts$/,
  timeout: 300_000,
  workers: 1,
  reporter: "list",
  // A step that cannot be done says so in half a minute rather than sitting until the whole test runs out.
  use: { baseURL: "http://localhost:3311", actionTimeout: 30_000 },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 } },
    { name: "iphone", use: { ...devices["iPhone 14"], deviceScaleFactor: 2 } },
  ],
});

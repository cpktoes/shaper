// Scratch: lays the GUIDE's pictures out on one captioned sheet (compose.html) and saves it as one picture.
// Run: node compose.mjs <out.png>
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright";

const here = dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] ?? join(here, "17-11-guide.png");

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 5300, height: 1200 }, deviceScaleFactor: 1 });
await page.goto(pathToFileURL(join(here, "compose.html")).href);
await page.waitForFunction(() => [...document.images].every((img) => img.complete && img.naturalWidth > 0));
const size = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight }));
await page.screenshot({ path: out, fullPage: true });
await browser.close();
console.log(`saved ${out} — ${size.width} x ${size.height} dots`);

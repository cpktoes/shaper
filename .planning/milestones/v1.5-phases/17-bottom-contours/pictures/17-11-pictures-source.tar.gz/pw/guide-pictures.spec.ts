import { join } from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-af6f98e2ea71d8a84/e2e/helpers/screens";

// Scratch: the pictures of BOTTOM's GUIDE for the founder's look (17-11). Every picture is the running page.
const SHOTS = join(__dirname, "shots");
const PRESET_NAME: Record<string, string> = { shortboard: "Shortboard", fish: "Fish", midlength: "Mid-length", longboard: "Longboard" };
const SCREEN_HREF = "/design/bottom";

async function quiet(page: Page, metric = false) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
    try {
      window.localStorage.removeItem("shaper-open-board");
    } catch {}
  });
  if (metric) await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
}

async function openBottom(page: Page, presetId: string) {
  await page.goto("/");
  const card = page
    .getByRole("button")
    .filter({ hasText: PRESET_NAME[presetId] })
    .filter({ hasText: /Start Shaping|\d\.\d L/ })
    .first();
  await expect(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2_000 });
      await card.click({ timeout: 2_000 });
    }
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
  }).toPass({ timeout: 90_000 });
  // The app's own way between screens: the top row's link on a computer; ☰ and the tile on a phone.
  await goToScreen(page, "BOTTOM");
  await expect(page).toHaveURL(new RegExp(`${SCREEN_HREF}$`), { timeout: 60_000 });
  await expect(page.locator("[data-bottom-cut-line]")).toBeAttached({ timeout: 60_000 });
}

async function openGuide(page: Page) {
  const tab = page.getByRole("tab", { name: "GUIDE", exact: true });
  await expect(async () => {
    await tab.click({ timeout: 2_000 });
    await expect(page.locator("[data-bottom-guide]")).toBeVisible({ timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await expect(page.locator("[data-guide-card]")).toHaveCount(19);
}

async function pick(page: Page, section: "Nose" | "Center" | "Tail", name: string) {
  await expect(async () => {
    await page.getByRole("combobox", { name: `${section} Cut` }).click();
    await page.getByRole("option", { name, exact: true }).click({ timeout: 2_000 });
    await expect(page.locator(`[data-bottom-card="${section.toLowerCase()}"] [data-bottom-cut-echo]`)).toHaveText(name, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

const cardOf = (page: Page, name: string): Locator => page.locator(`[data-guide-card="${name}"]`);

/** Grows the window until the cards need no scrolling, so one picture can hold all nineteen. */
async function growUntilAllShow(page: Page, width: number) {
  for (let i = 0; i < 4; i++) {
    const extra = await page.locator("[data-bottom-guide]").evaluate((el) => el.scrollHeight - el.clientHeight);
    if (extra <= 0) return;
    const now = page.viewportSize()!;
    await page.setViewportSize({ width, height: now.height + extra + 8 });
    await page.waitForTimeout(300);
  }
}

async function shootCards(page: Page, names: string[], prefix: string) {
  for (const name of names) {
    const card = cardOf(page, name);
    await card.scrollIntoViewIfNeeded();
    // The card's top to the folder's top, so the floating Undo pair in the window's corner is never over it.
    await page.locator("[data-bottom-guide]").evaluate((el, key) => {
      const target = el.querySelector(`[data-guide-card="${key}"]`) as HTMLElement;
      el.scrollTop += target.getBoundingClientRect().top - el.getBoundingClientRect().top - 4;
    }, name);
    await page.waitForTimeout(150);
    await card.screenshot({ path: join(SHOTS, `${prefix}-${name.replace(/[^A-Za-z]+/g, "-").toLowerCase()}.png`) });
  }
}

test.describe("computer", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "desktop"));

  test("shortboard: the window, all nineteen, the five vees, two across", async ({ page }) => {
    await quiet(page);
    await openBottom(page, "shortboard");
    await pick(page, "Center", "Deep Single Concave");
    await openGuide(page);
    await page.waitForTimeout(500);
    await page.screenshot({ path: join(SHOTS, "d1280-window.png") });
    const widths = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().width * 10) / 10));
    console.log("1280 card widths", [...new Set(widths)].join(" "));

    await shootCards(page, ["Reverse Vee Nose", "Tri-Plane Hull Center", "Panel Vee", "Spiral Vee", "Rolled Vee"], "vee");

    await growUntilAllShow(page, 1280);
    await page.locator("[data-viewer-panel]").screenshot({ path: join(SHOTS, "d1280-all.png") });
    const heights = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().height)));
    console.log("1280 card heights", Math.min(...heights), Math.max(...heights), "window", JSON.stringify(page.viewportSize()));

    await page.setViewportSize({ width: 1024, height: 768 });
    await page.waitForTimeout(500);
    await page.locator("[data-bottom-guide]").evaluate((el) => (el.scrollTop = 0));
    await page.screenshot({ path: join(SHOTS, "d1024-window.png") });
    const w1024 = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().width * 10) / 10));
    const h1024 = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().height)));
    console.log("1024 card widths", [...new Set(w1024)].join(" "), "heights", Math.min(...h1024), Math.max(...h1024));

    await page.setViewportSize({ width: 820, height: 800 });
    await page.waitForTimeout(500);
    const w820 = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().width * 10) / 10));
    console.log("820 card widths", [...new Set(w820)].join(" "));
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.waitForTimeout(500);
    const w1440 = await page.locator("[data-guide-card]").evaluateAll((els) => els.map((el) => Math.round(el.getBoundingClientRect().width * 10) / 10));
    console.log("1440 card widths", [...new Set(w1440)].join(" "));
    for (const width of [1180, 1199, 1200, 1210, 955, 956, 960, 970]) {
      await page.setViewportSize({ width, height: 800 });
      await page.waitForTimeout(250);
      const lefts = await page.locator('[data-guide-group="nose"] [data-guide-card]').evaluateAll((els) => new Set(els.map((el) => Math.round(el.getBoundingClientRect().left))).size);
      console.log("columns at", width, lefts);
    }
  });

  for (const [preset, names] of [
    ["longboard", ["Teardrop Nose Concave", "Continuous Belly / Rolled Mid", "Panel Vee", "Channels"]],
    ["fish", ["Deep Single Concave", "Double Concave Exit", "Spiral Vee", "Channels"]],
  ] as const) {
    test(`${preset}: four cards on that board`, async ({ page }) => {
      await quiet(page);
      await openBottom(page, preset);
      await openGuide(page);
      await page.waitForTimeout(500);
      await shootCards(page, [...names], preset);
    });
  }

  test("metric: the same cards read by a Metric shaper", async ({ page }) => {
    await quiet(page, true);
    await openBottom(page, "shortboard");
    await openGuide(page);
    await page.waitForTimeout(500);
    await shootCards(page, ["Flat Entry", "Deep Single Concave"], "metric");
  });
});

test.describe("phone", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "iphone"));

  test("upright and sideways", async ({ page }) => {
    await quiet(page);
    // A real iPhone's upright page, as `e2e/phone-chrome.spec.ts` sets it.
    await page.setViewportSize({ width: 390, height: 844 });
    await openBottom(page, "shortboard");
    await openGuide(page);
    await page.waitForTimeout(500);
    await page.screenshot({ path: join(SHOTS, "phone-upright-top.png") });
    const info = await page.evaluate(() => {
      const guide = document.querySelector("[data-bottom-guide]") as HTMLElement;
      const card = document.querySelector("[data-guide-card]") as HTMLElement;
      const panel = document.querySelector("[data-viewer-panel]") as HTMLElement;
      return {
        window: [window.innerWidth, window.innerHeight],
        guide: [guide.clientHeight, guide.scrollHeight, getComputedStyle(guide).overflowY],
        panel: [Math.round(panel.getBoundingClientRect().top), Math.round(panel.getBoundingClientRect().height)],
        card: [Math.round(card.getBoundingClientRect().width), Math.round(card.getBoundingClientRect().height)],
        page: [document.documentElement.scrollHeight, window.scrollY],
      };
    });
    console.log("upright", JSON.stringify(info));
    await cardOf(page, "Panel Vee").scrollIntoViewIfNeeded();
    await page.locator("[data-bottom-guide]").evaluate((el) => {
      const card = el.querySelector('[data-guide-card="Panel Vee"]') as HTMLElement;
      el.scrollTop += card.getBoundingClientRect().top - el.getBoundingClientRect().top - 4;
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: join(SHOTS, "phone-upright-panel-vee.png") });

    // A real iPhone held sideways reports about 844 x 390 (CLAUDE.md, Layout) — never the emulator's swapped box.
    await page.setViewportSize({ width: 844, height: 390 });
    await page.waitForTimeout(800);
    await page.locator("[data-bottom-guide]").evaluate((el) => (el.scrollTop = 0));
    await page.waitForTimeout(300);
    await page.screenshot({ path: join(SHOTS, "phone-sideways-top.png") });
    const side = await page.evaluate(() => {
      const guide = document.querySelector("[data-bottom-guide]") as HTMLElement;
      const card = document.querySelector("[data-guide-card]") as HTMLElement;
      return {
        window: [window.innerWidth, window.innerHeight],
        guide: [guide.clientHeight, guide.scrollHeight],
        card: [Math.round(card.getBoundingClientRect().width), Math.round(card.getBoundingClientRect().height)],
        columns: new Set([...document.querySelectorAll('[data-guide-group="nose"] [data-guide-card]')].map((el) => Math.round(el.getBoundingClientRect().left))).size,
      };
    });
    console.log("sideways", JSON.stringify(side));
    await page.locator("[data-bottom-guide]").evaluate((el) => {
      const card = el.querySelector('[data-guide-card="Deep Single Concave"]') as HTMLElement;
      el.scrollTop += card.getBoundingClientRect().top - el.getBoundingClientRect().top - 4;
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: join(SHOTS, "phone-sideways-deep-single.png") });
    const scrolled = await page.evaluate(() => ({ page: [document.documentElement.scrollHeight, window.innerHeight, window.scrollY] }));
    console.log("sideways scrolled", JSON.stringify(scrolled));
  });
});

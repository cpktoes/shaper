# 17-22: put the before and after pictures side by side, a caption line over each row, into one PNG. Every mark dot
# that moves between before and after (read off each picture's own JSON) is ringed in red on the after picture and
# captioned with its rise, the rise read off the capture (rises.json, the app's own maths).
# Usage: python3 -I compose.py alone|channels <pics-out dir> <rises.json> <output png>
import json
import sys
from PIL import Image, ImageDraw, ImageFont

mode, src, rises_path, out = sys.argv[1:5]
rises = json.load(open(rises_path))


def font(size):
    for path in ["/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()


title_font = font(34)
caption_font = font(26)
label_font = font(24)
ring_font = font(24)
pad = 24
gap = 30
title_h = 60
caption_h = 40
label_h = 34

NAMES = {"tuck1": "Rail Tuck 1", "tuck2": "Rail Tuck 2", "band1": "Band 1", "band2": "Band 2"}
COLOR_KEY = {"#7d5ba6": "tuck1", "#3a6ea5": "tuck2"}

# (picture name, caption, board label in rises.json, card, channels, section)
if mode == "alone":
    title = "17-22 - RAILS draws every concave (\"Always draw it\"), no channels: before (left) and after (right)"
    rows = [
        ("shortboard-blended-nose", "Shortboard, Blended Nose Concave - RAILS nose section, Finished Rail on. No mark moves.", "shortboard|hard", "Blended Nose Concave", 0, "nose"),
        ("shortboard-deep-single", "Shortboard, Deep Single Concave - RAILS centre section, Finished Rail on. No mark moves.", "shortboard|hard", "Deep Single Concave", 0, "center"),
        ("longboard-early-double", "Longboard as it opens (rolled rail), Early Double Concave - RAILS tail section. The ringed mark rides up onto the concave.", "longboard|soft", "Early Double Concave", 0, "tail"),
    ]
else:
    title = "17-22 - RAILS draws the concave under the channels (\"Draw the concave\"): before (left) and after (right), tail section"
    rows = [
        ("shortboard-extending-6", "Shortboard, Extending Single Concave and its starting six channels. No mark moves.", "shortboard|hard", "Extending Single Concave", 6, "tail"),
        ("shortboard-dce-6", "Shortboard, Double Concave Exit and its starting six channels. No mark moves.", "shortboard|hard", "Double Concave Exit", 6, "tail"),
        ("fish-extending-8", "Fish, Extending Single Concave and its starting eight channels. No mark moves.", "fish|hard", "Extending Single Concave", 8, "tail"),
        ("fish-dce-8", "Fish, Double Concave Exit and its starting eight channels. No mark moves.", "fish|hard", "Double Concave Exit", 8, "tail"),
        ("longboard-dce-6", "Longboard as it opens (rolled rail), Double Concave Exit and its starting six. The ringed marks ride up onto the concave.", "longboard|soft", "Double Concave Exit", 6, "tail"),
    ]


def rise_of(board, card, channels, section, key):
    for e in rises:
        if e["board"] == board and e["card"] == card and e["channels"] == channels and e["section"] == section:
            for m in e["moved"]:
                if m["key"] == key:
                    return m["riseExact"]
    raise SystemExit(f"no rise for {board} {card} {channels} {section} {key}")


loaded = []
for name, caption, board, card, channels, section in rows:
    before = Image.open(f"{src}/before-{name}.png").convert("RGB")
    after = Image.open(f"{src}/after-{name}.png").convert("RGB")
    bj = json.load(open(f"{src}/before-{name}.json"))
    aj = json.load(open(f"{src}/after-{name}.json"))
    assert bj["readout"] == aj["readout"], name
    rings = []
    seen = set()
    for bd, ad in zip(bj["dots"], aj["dots"]):
        if abs(bd["y"] - ad["y"]) > 0.01 or abs(bd["x"] - ad["x"]) > 0.01:
            key = COLOR_KEY[ad["fill"]]
            if key in seen:
                continue
            seen.add(key)
            rings.append((ad["x"], ad["y"], f"{NAMES[key]} +{rise_of(board, card, channels, section, key):.3f}\""))
    loaded.append((caption, before, after, rings))

col_w = max(max(b.width, a.width) for _, b, a, _ in loaded)
width = pad * 2 + col_w * 2 + gap + 160  # room for a label to the right of a ring near the apex
height = pad + title_h + sum(caption_h + label_h + max(b.height, a.height) + pad for _, b, a, _ in loaded) + pad
sheet = Image.new("RGB", (width, height), "white")
draw = ImageDraw.Draw(sheet)
draw.text((pad, pad), title, fill="black", font=title_font)
y = pad + title_h
for caption, before, after, rings in loaded:
    draw.text((pad, y), caption, fill="black", font=caption_font)
    y += caption_h
    draw.text((pad, y), "Before", fill=(120, 120, 120), font=label_font)
    draw.text((pad + col_w + gap, y), "After", fill=(120, 120, 120), font=label_font)
    y += label_h
    sheet.paste(before, (pad, y))
    ax = pad + col_w + gap
    sheet.paste(after, (ax, y))
    draw.rectangle([pad - 1, y - 1, pad + before.width, y + before.height], outline=(200, 200, 200))
    draw.rectangle([ax - 1, y - 1, ax + after.width, y + after.height], outline=(200, 200, 200))
    # Left to right: the leftmost ring's label stands up and to its left, every other ring's up and to its right.
    for i, (dx, dy, text) in enumerate(sorted(rings)):
        cx, cy = ax + dx, y + dy
        r = 22
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(214, 40, 40), width=5)
        tw = draw.textlength(text, font=ring_font)
        ty = cy - 70
        if i == 0:
            tx = cx - r - 12 - tw
            anchor = (tx + tw + 6, ty + 26)
            to = (cx - r * 0.7, cy - r * 0.7)
        else:
            tx = cx + r + 12
            anchor = (tx - 6, ty + 26)
            to = (cx + r * 0.7, cy - r * 0.7)
        draw.rectangle([tx - 6, ty - 4, tx + tw + 6, ty + 30], fill=(255, 255, 255), outline=(214, 40, 40), width=2)
        draw.text((tx, ty), text, fill=(214, 40, 40), font=ring_font)
        draw.line([anchor, to], fill=(214, 40, 40), width=3)
    y += max(before.height, after.height) + pad
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

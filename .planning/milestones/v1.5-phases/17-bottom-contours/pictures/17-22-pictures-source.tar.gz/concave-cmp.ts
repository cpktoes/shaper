// 17-22: compares rails-concave.json before and after. Every difference must be a section whose lift is 0 gaining
// (or changing) its `bottom`, every `across` point exactly sectionsFoamOff there; the rails, every lifted section and
// every other field of a section identical. Re-derives the boards the way capture.ts does.
// Usage: npx --no-install tsx --tsconfig ./tsconfig.json <this> <before dir> <after dir>
import { readFileSync } from "node:fs";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import {
  DEFAULT_BOTTOM, pickCut, resolveBottom, sectionsFoamOff, startingChannels,
  type BoardBottom, type BottomBoard, type BottomCutName, type BottomSectionKey, type ChannelCount,
} from "@/lib/geometry/bottom";
import {
  designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, railAnchorStations, type DesignSummaryFields,
} from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { mm } from "@/lib/geometry/units";

type Pick = [BottomSectionKey, BottomCutName];
const CARDS: Record<string, Pick[]> = {
  "Teardrop Nose Concave": [["nose", "Teardrop Nose Concave"]],
  "Blended Nose Concave": [["nose", "Blended Nose Concave"]],
  "Slight Single Concave Entry": [["nose", "Slight Single Concave Entry"]],
  "Deep Single Concave": [["center", "Deep Single Concave"]],
  "Shallow Single Concave": [["center", "Shallow Single Concave"]],
  "Early Double Concave": [["center", "Early Double Concave"]],
  "Double Concave Exit": [["tail", "Double Concave Exit"]],
  "Extending Single Concave": [["tail", "Extending Single Concave"]],
  "Deep Single + Rolled Vee": [["center", "Deep Single Concave"], ["tail", "Rolled Vee"]],
  "Teardrop + Continuous Belly + Rolled Vee": [["nose", "Teardrop Nose Concave"], ["center", "Continuous Belly / Rolled Mid"], ["tail", "Rolled Vee"]],
  "Teardrop + Early Double + Spiral Vee": [["nose", "Teardrop Nose Concave"], ["center", "Early Double Concave"], ["tail", "Spiral Vee"]],
};

const [beforeDir, afterDir] = process.argv.slice(2);
const before = JSON.parse(readFileSync(`${beforeDir}/rails-concave.json`, "utf8"));
const after = JSON.parse(readFileSync(`${afterDir}/rails-concave.json`, "utf8"));
const all = phase16Boards();
const strip = (o: Record<string, unknown> | undefined) => {
  if (!o) return o;
  const { bottom: _b, ...rest } = o;
  return rest;
};

let problems = 0;
let gained = 0;
let changedChannels = 0;
const gainedBy: Record<string, number> = { nose: 0, center: 0, tail: 0 };
for (const label of Object.keys(before)) {
  const b = before[label];
  const a = after[label];
  const [id, tail, card, ch] = label.split("|");
  const base = all.find((x) => x.label === `${id}|asis|${tail}`)!.fields as DesignSummaryFields;
  const profile = designSideProfile(base, LIVE_DESIGN_RULES);
  const board: BottomBoard = designBottomBoard(base.outline, buildOutline(base.outline), profile, designFinPlacement(base));
  let bottom: BoardBottom = structuredClone(DEFAULT_BOTTOM);
  for (const [s, n] of CARDS[card]) bottom = pickCut(bottom, s, n, board);
  const n = Number(ch.replace("ch", ""));
  if (n) bottom = { ...bottom, channels: startingChannels(n as ChannelCount, board, bottom.channels) };
  const resolved = resolveBottom(bottom, board);
  const anchors = railAnchorStations(profile.effectiveFoil, base.outline.length);
  if (JSON.stringify(a.rails) !== JSON.stringify(b.rails) || a.railsSame !== b.railsSame) { problems++; console.log("RAILS moved", label); }
  for (const key of ["tail", "center", "nose"] as const) {
    const bs = b[key];
    const as = a[key];
    if (JSON.stringify(bs) === JSON.stringify(as)) continue;
    const lifted = bs.bottom && bs.bottom.lift > 0;
    if (lifted) { problems++; console.log("LIFTED section changed", label, key); continue; }
    if (JSON.stringify(strip(bs)) !== JSON.stringify(strip(as))) { problems++; console.log("other field changed", label, key); continue; }
    if (!as.bottom || as.bottom.lift !== 0) { problems++; console.log("no lift-0 bottom after", label, key); continue; }
    const rail = board.railAt(anchors[key]);
    for (const p of as.bottom.across) {
      const want = sectionsFoamOff(resolved, board, anchors[key], mm(Math.abs(rail + p.x)));
      if (p.y !== want) { problems++; console.log("across off", label, key, p.x, p.y, want); break; }
    }
    if (!as.bottom.across.some((p: { y: number }) => p.y > 0)) { problems++; console.log("no concave point", label, key); }
    if (bs.bottom) changedChannels++;
    else { gained++; gainedBy[key]++; }
  }
}
console.log({ problems, gained, gainedBy, changedChannels });

// Scratch config for 17-22's before/after pictures: the suite's own config, its dev server started from the
// worktree (PW_PORT=3322), its desktop project only, the specs from this scratch folder.
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a410b1a79575aeaf7/playwright.config";

const SCRATCH = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/work";
const server = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer!;

export default {
  ...base,
  testDir: `${SCRATCH}/pics`,
  testIgnore: [],
  outputDir: `${SCRATCH}/pics-results`,
  webServer: { ...server, cwd: "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a410b1a79575aeaf7" },
  projects: (base.projects ?? []).filter((p) => p.name === "desktop"),
};

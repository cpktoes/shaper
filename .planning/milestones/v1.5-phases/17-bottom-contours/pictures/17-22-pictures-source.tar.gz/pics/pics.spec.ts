// 17-22's pictures, 1280 wide, Imperial: RAILS' VIEWER with the Finished Rail on, one section plot per board. Writes
// `<phase>-<name>.png` and `<phase>-<name>.json` (each mark dot's centre in the picture's own dots and its colour, the
// readout card's text). PICS_PHASE=before|after names the files. Run with the scratch pics.config.ts (desktop only).
import { writeFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a410b1a79575aeaf7/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a410b1a79575aeaf7/lib/models/toolbar-tip";
import { boardWithBottom, openOnBoard, type BottomPicks } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a410b1a79575aeaf7/e2e/helpers/bottom-print";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/work/pics-out";
const PHASE = process.env.PICS_PHASE ?? "before";

async function dismiss(page: Page) {
  await page.addInitScript((key) => window.sessionStorage.setItem(key, "true"), BANNER_DISMISSAL_KEY);
  await page.addInitScript((key) => window.localStorage.setItem(key, "true"), TOOLBAR_TIP_DISMISSAL_KEY);
}

const SHOTS: { name: string; preset: string; picks: BottomPicks; section: "nose" | "center" | "tail" }[] = [
  { name: "shortboard-blended-nose", preset: "shortboard", picks: { nose: "Blended Nose Concave" }, section: "nose" },
  { name: "shortboard-deep-single", preset: "shortboard", picks: { center: "Deep Single Concave" }, section: "center" },
  { name: "longboard-early-double", preset: "longboard", picks: { center: "Early Double Concave" }, section: "tail" },
  { name: "shortboard-extending-6", preset: "shortboard", picks: { tail: "Extending Single Concave", channels: 6 }, section: "tail" },
  { name: "shortboard-dce-6", preset: "shortboard", picks: { tail: "Double Concave Exit", channels: 6 }, section: "tail" },
  { name: "fish-extending-8", preset: "fish", picks: { tail: "Extending Single Concave", channels: 8 }, section: "tail" },
  { name: "fish-dce-8", preset: "fish", picks: { tail: "Double Concave Exit", channels: 8 }, section: "tail" },
  { name: "longboard-dce-6", preset: "longboard", picks: { tail: "Double Concave Exit", channels: 6 }, section: "tail" },
];

test.setTimeout(240_000);
test.use({ deviceScaleFactor: 2 });

for (const shot of SHOTS) {
  test(shot.name, async ({ page }) => {
    await dismiss(page);
    await openOnBoard(page, boardWithBottom(shot.preset, shot.picks));
    await page.goto("/design/rails");
    await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeAttached({ timeout: 60_000 });
    const button = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /finished rail$/ });
    if ((await button.getAttribute("aria-pressed")) !== "true") await button.click();
    await expect(button).toHaveAttribute("aria-pressed", "true");
    const plot = page.locator(`[data-rail-plot-row="desktop"] [data-rail-section-plot="${shot.section}"]`);
    await expect(plot.locator("[data-finished-rail]")).toHaveCount(1);
    // The kept board replaces the stock one a moment after the page opens: after, wait for its planed bottom; before,
    // wait for channels (if any) or let the page settle.
    if (PHASE === "after" || shot.picks.channels) await expect(plot.locator("[data-rail-planed-bottom]")).toHaveCount(1, { timeout: 60_000 });
    await page.waitForTimeout(3_000);
    await plot.screenshot({ path: `${OUT}/${PHASE}-${shot.name}.png` });
    const box = (await plot.boundingBox())!;
    const dots = await plot.evaluate((svg, origin) => {
      return [...svg.querySelectorAll("circle")].map((c) => {
        const r = c.getBoundingClientRect();
        return { x: (r.x + r.width / 2 - origin.x) * 2, y: (r.y + r.height / 2 - origin.y) * 2, fill: c.getAttribute("fill"), cx: c.getAttribute("cx"), cy: c.getAttribute("cy") };
      });
    }, { x: box.x, y: box.y });
    const card = page.locator("aside").getByRole("group", { name: /^From ROCKER/i });
    const readout = ((await card.textContent()) ?? "").replace(/\s+/g, " ").trim();
    writeFileSync(`${OUT}/${PHASE}-${shot.name}.json`, JSON.stringify({ dots, readout }));
  });
}

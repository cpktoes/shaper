#!/bin/bash
# Re-runs 17-22's capture into cap-<name> and compares each file with cap-before. Run from the worktree root.
P=/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/work
mkdir -p "$P/cap-$1"
npx --no-install tsx --tsconfig ./tsconfig.json "$P/capture.ts" "$P/cap-$1" || exit 1
for f in rails-kept rails-concave litres; do
  if cmp -s "$P/cap-before/$f.json" "$P/cap-$1/$f.json"; then echo "$f identical"; else echo "$f DIFFERS"; fi
done

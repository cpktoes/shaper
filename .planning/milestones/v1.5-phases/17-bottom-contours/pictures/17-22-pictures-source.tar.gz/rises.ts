// 17-22: on the four presets (Hard Edge and soft), each concave card alone with 0 and 6 channels: which sections now
// stand on a concave (the deepest the concave stands inside the plot), and every mark dot that rises, by how much —
// all off the app's own maths (railBandsOnTheBottom, railPlotDots, railPointOnBottom). Inches, to 3 places.
// Usage: npx --no-install tsx --tsconfig ./tsconfig.json <this> > rises.json
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import {
  DEFAULT_BOTTOM, pickCut, resolveBottom, startingChannels,
  type BoardBottom, type BottomBoard, type BottomCutName, type BottomSectionKey,
} from "@/lib/geometry/bottom";
import {
  bottomRailLift, deriveEffectiveRails, designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES,
  railAnchorStations, railBandsOnTheBottom, railsOnTheBottom, type DesignSummaryFields,
} from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands, railPlotDots } from "@/lib/geometry/rail-bands";
import { railPointOnBottom } from "@/lib/geometry/rail-bottom";
import { mmToInches } from "@/lib/geometry/units";

const CONCAVES: [BottomSectionKey, BottomCutName][] = [
  ["nose", "Teardrop Nose Concave"],
  ["nose", "Blended Nose Concave"],
  ["nose", "Slight Single Concave Entry"],
  ["center", "Deep Single Concave"],
  ["center", "Shallow Single Concave"],
  ["center", "Early Double Concave"],
  ["tail", "Double Concave Exit"],
  ["tail", "Extending Single Concave"],
];
const all = phase16Boards();
const r3 = (v: number) => Math.round(mmToInches(v as never) * 1000) / 1000;
const out: Record<string, unknown>[] = [];
for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  for (const tail of ["hard", "soft"]) {
    const fields = all.find((b) => b.label === `${id}|asis|${tail}`)!.fields as DesignSummaryFields;
    const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
    const board: BottomBoard = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
    for (const [section, name] of CONCAVES) {
      for (const n of [0, 6] as const) {
        let bottom: BoardBottom = pickCut(structuredClone(DEFAULT_BOTTOM), section, name, board);
        if (n) bottom = { ...bottom, channels: startingChannels(n, board, bottom.channels) };
        const resolved = resolveBottom(bottom, board);
        const eff = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
        const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
        const lift = bottomRailLift(resolved, board);
        const rails = railsOnTheBottom(eff, lift, anchors);
        const bands = railBandsOnTheBottom(computeRailBands(rails), resolved, board, anchors);
        for (const key of ["nose", "center", "tail"] as const) {
          const s = bands[key];
          const railLift = lift(anchors[key]);
          if (!s.bottom) continue;
          const inPlot = s.bottom.across.filter((p) => p.x >= s.bounds.xAxisMin);
          const concave = Math.max(0, ...inPlot.map((p) => p.y));
          const dots = railPlotDots(s.segments, s.result, s.domed);
          const moved = dots
            .map((d) => ({ key: d.key, rise: railPointOnBottom(s.bottom!, s.boardThickness, { x: d.x, y: d.y }).y - d.y, x: r3(d.x), y: r3(d.y) }))
            .filter((d) => d.rise !== 0)
            .map((d) => ({ ...d, rise: r3(d.rise), riseExact: mmToInches(d.rise as never) }));
          out.push({ board: `${id}|${tail}`, card: name, channels: n, section: key, railLift, concaveInPlot: r3(concave), hasChannelCut: !!s.bottom.channelCut, moved });
        }
      }
    }
  }
}
console.log(JSON.stringify(out, null, 1));

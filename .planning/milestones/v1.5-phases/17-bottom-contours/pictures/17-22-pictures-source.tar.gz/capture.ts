// 17-22 regression capture. Writes three JSON files into argv[2] (a folder):
//  rails-kept.json — on the four presets (`<id>|asis|hard` and `…|soft`): railsOnTheBottom's rails, the three sections
//    of railBandsOnTheBottom and each bottomed section's finished rail on that bottom — on a flat bottom; each vee and
//    belly alone with 0 and 6 channels; a flat bottom with 4, 6 and 8 channels.
//  rails-concave.json — the same for each concave card alone with 0, 4, 6 and 8 channels, and three mixes with 0 and 6.
//  litres.json — summarizeDesign's litres (toPrecision(17)) for every board above and every board of phase17ChannelBoards().
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <out dir>
import { writeFileSync } from "node:fs";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { phase17ChannelBoards } from "@/lib/geometry/__fixtures__/phase17-channel-boards";
import {
  DEFAULT_BOTTOM,
  pickCut,
  resolveBottom,
  startingChannels,
  type BoardBottom,
  type BottomBoard,
  type BottomCutName,
  type BottomSectionKey,
  type ChannelCount,
} from "@/lib/geometry/bottom";
import {
  bottomRailLift,
  deriveEffectiveRails,
  designBottomBoard,
  designFinPlacement,
  designSideProfile,
  LIVE_DESIGN_RULES,
  railAnchorStations,
  railBandsOnTheBottom,
  railsOnTheBottom,
  summarizeDesign,
  type DesignSummaryFields,
} from "@/lib/geometry/design";
import { finishedRail } from "@/lib/geometry/finished-rail";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom } from "@/lib/geometry/rail-bottom";

type Pick = [BottomSectionKey, BottomCutName];
const LIFTERS: Pick[] = [
  ["tail", "Panel Vee"],
  ["tail", "Spiral Vee"],
  ["tail", "Rolled Vee"],
  ["nose", "Reverse Vee Nose"],
  ["center", "Tri-Plane Hull Center"],
  ["nose", "Rolled Belly Entry"],
  ["center", "Continuous Belly / Rolled Mid"],
];
const CONCAVES: Pick[] = [
  ["nose", "Teardrop Nose Concave"],
  ["nose", "Blended Nose Concave"],
  ["nose", "Slight Single Concave Entry"],
  ["center", "Deep Single Concave"],
  ["center", "Shallow Single Concave"],
  ["center", "Early Double Concave"],
  ["tail", "Double Concave Exit"],
  ["tail", "Extending Single Concave"],
];
const MIXES: [string, Pick[]][] = [
  ["Deep Single + Rolled Vee", [["center", "Deep Single Concave"], ["tail", "Rolled Vee"]]],
  ["Teardrop + Continuous Belly + Rolled Vee", [["nose", "Teardrop Nose Concave"], ["center", "Continuous Belly / Rolled Mid"], ["tail", "Rolled Vee"]]],
  ["Teardrop + Early Double + Spiral Vee", [["nose", "Teardrop Nose Concave"], ["center", "Early Double Concave"], ["tail", "Spiral Vee"]]],
];

const dir = process.argv[2];
const kept: Record<string, unknown> = {};
const concave: Record<string, unknown> = {};
const litres: Record<string, string> = {};
const all = phase16Boards();

function boardOf(fields: DesignSummaryFields): BottomBoard {
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  return designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
}

function record(into: Record<string, unknown>, label: string, fields: DesignSummaryFields) {
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const board = boardOf(fields);
  const resolved = resolveBottom(fields.bottom ?? DEFAULT_BOTTOM, board);
  const effectiveRails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
  const r = railsOnTheBottom(effectiveRails, bottomRailLift(resolved, board), anchors);
  const plain = computeRailBands(r);
  const bands = railBandsOnTheBottom(plain, resolved, board, anchors);
  const entry: Record<string, unknown> = { rails: r, railsSame: r === effectiveRails, bandsSame: bands === plain };
  for (const key of ["tail", "center", "nose"] as const) {
    const sec = bands[key];
    entry[key] = sec;
    entry[`${key}Same`] = sec === plain[key];
    if (sec.bottom) entry[`finished-${key}`] = finishedRailOnBottom(finishedRail(sec, sec.bounds.xAxisMin), sec.bottom, sec.boardThickness);
  }
  into[label] = entry;
  litres[label] = summarizeDesign(fields).volumeLitres.toPrecision(17);
}

function withPicks(board: BottomBoard, picks: Pick[], channels: number): BoardBottom {
  let bottom: BoardBottom = structuredClone(DEFAULT_BOTTOM);
  for (const [section, name] of picks) bottom = pickCut(bottom, section, name, board);
  if (channels) bottom = { ...bottom, channels: startingChannels(channels as ChannelCount, board, bottom.channels) };
  return bottom;
}

for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  for (const tail of ["hard", "soft"]) {
    const base = all.find((b) => b.label === `${id}|asis|${tail}`)!.fields;
    const board = boardOf(base);
    const at = (label: string) => `${id}|${tail}|${label}`;
    record(kept, at("flat"), { ...base, bottom: structuredClone(DEFAULT_BOTTOM) });
    for (const n of [4, 6, 8]) record(kept, at(`flat|${n}ch`), { ...base, bottom: withPicks(board, [], n) });
    for (const pick of LIFTERS) {
      for (const n of [0, 6]) record(kept, at(`${pick[1]}|${n}ch`), { ...base, bottom: withPicks(board, [pick], n) });
    }
    for (const pick of CONCAVES) {
      for (const n of [0, 4, 6, 8]) record(concave, at(`${pick[1]}|${n}ch`), { ...base, bottom: withPicks(board, [pick], n) });
    }
    for (const [name, picks] of MIXES) {
      for (const n of [0, 6]) record(concave, at(`${name}|${n}ch`), { ...base, bottom: withPicks(board, picks, n) });
    }
  }
}
for (const { label, fields } of phase17ChannelBoards()) {
  litres[`p17|${label}`] = summarizeDesign(fields).volumeLitres.toPrecision(17);
}

writeFileSync(`${dir}/rails-kept.json`, JSON.stringify(kept));
writeFileSync(`${dir}/rails-concave.json`, JSON.stringify(concave));
writeFileSync(`${dir}/litres.json`, JSON.stringify(litres));
console.log("kept", Object.keys(kept).length, "concave", Object.keys(concave).length, "litres", Object.keys(litres).length);

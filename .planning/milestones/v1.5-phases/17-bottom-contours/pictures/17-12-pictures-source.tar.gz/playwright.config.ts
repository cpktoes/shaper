import { defineConfig, devices } from "@playwright/test";
import repo from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2f7f351aa6b8b4e9/playwright.config";

// Scratch config for 17-12's pictures and probes: the worktree's own dev server on PW_PORT (3312), started and stopped
// by this run exactly as the project's suite starts it. Two times the dots so the words are sharp.
const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2f7f351aa6b8b4e9";
const port = Number(process.env.PW_PORT ?? 3312);
const server = repo.webServer as { command: string; url: string; timeout: number; env: Record<string, string> };

export default defineConfig({
  testDir: ".",
  testMatch: /\.(pictures|probe)\.spec\.ts$/,
  timeout: 420_000,
  workers: 1,
  reporter: "list",
  webServer: { ...server, cwd: WORKTREE, reuseExistingServer: true },
  use: { baseURL: `http://localhost:${port}`, actionTimeout: 30_000 },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 } },
    { name: "zoom", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 6 } },
    { name: "iphone", use: { ...devices["iPhone 14"], deviceScaleFactor: 2 } },
  ],
});

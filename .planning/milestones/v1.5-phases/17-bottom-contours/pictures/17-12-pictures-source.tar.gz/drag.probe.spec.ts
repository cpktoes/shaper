import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2f7f351aa6b8b4e9/e2e/helpers/screens";

// Scratch probe: how far apart in time do the notches of one mouse drag of Center Depth land, on BOTTOM, on the dev
// server? The app folds moves into one Undo step when they land within 500 ms of each other.

async function openPreset(page: Page, name: string) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  await expect(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2_000 });
      await card.click({ timeout: 2_000 });
    }
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
  }).toPass({ timeout: 90_000 });
}

async function addWing(page: Page) {
  await expect(async () => {
    await page.getByRole("tab", { name: "ADD WINGS" }).click({ timeout: 2_000 });
    await expect(page.getByRole("tab", { name: "ADD WINGS" })).toHaveAttribute("aria-selected", "true", { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await page.getByRole("button", { name: "+ Add a wing" }).filter({ visible: true }).first().click();
  const dialog = page.getByRole("dialog", { name: "Dial in your wing placement" });
  await dialog.getByRole("button", { name: "Got it" }).click();
  await expect(dialog).toHaveCount(0);
}

async function pickCenter(page: Page, name: string) {
  await expect(async () => {
    await page.getByRole("combobox", { name: "Center Cut" }).click();
    await page.getByRole("option", { name, exact: true }).click({ timeout: 2_000 });
    await expect(page.locator('[data-bottom-card="center"] [data-bottom-cut-echo]')).toHaveText(name, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

async function timeADrag(page: Page, label: string, steps: number) {
  const depth = page.getByRole("slider", { name: "Center Depth", exact: true });
  await depth.evaluate((el) => {
    const w = window as unknown as { __marks: { at: number; value: string | null }[] };
    w.__marks = [];
    new MutationObserver(() => w.__marks.push({ at: performance.now(), value: el.getAttribute("aria-valuenow") ?? (el as HTMLInputElement).value })).observe(el, {
      attributes: true,
    });
  });
  const thumb = depth.locator('xpath=ancestor::*[@data-slot="slider-thumb"]');
  await thumb.scrollIntoViewIfNeeded();
  const track = (await depth.locator('xpath=ancestor::*[@data-slot="slider"]').boundingBox())!;
  const grip = (await thumb.boundingBox())!;
  const y = grip.y + grip.height / 2;
  const started = Date.now();
  await page.mouse.move(grip.x + grip.width / 2, y);
  await page.mouse.down();
  await page.mouse.move(track.x + track.width * 0.9, y, { steps });
  await page.mouse.up();
  const took = Date.now() - started;
  await page.waitForTimeout(1500);
  const marks = await page.evaluate(() => (window as unknown as { __marks: { at: number; value: string | null }[] }).__marks);
  const changes = marks.filter((m, i) => i === 0 || m.value !== marks[i - 1].value);
  const gaps = changes.slice(1).map((m, i) => Math.round(m.at - changes[i].at));
  console.log(`${label}: drag of ${steps} steps took ${took} ms; values ${changes.map((m) => m.value).join(" → ")}; gaps between notches ${gaps.join(", ")} ms`);
  // How many Undo presses take the drag back?
  const undo = page.getByRole("button", { name: "Undo", exact: true });
  const first = changes[0]?.value;
  let presses = 0;
  const now = async () => (await depth.getAttribute("aria-valuenow")) ?? (await depth.inputValue());
  const startValue = "0.25";
  while (presses < 8 && (await now()) !== startValue) {
    await undo.click();
    await page.waitForTimeout(700);
    presses += 1;
  }
  console.log(`${label}: ${presses} Undo press(es) took it back to ${await now()} (first change seen: ${first})`);
}

test("how a Center Depth drag lands in time", async ({ page }, info) => {
  test.skip(info.project.name !== "desktop");
  await openPreset(page, "Fish");
  await goToScreen(page, "BOTTOM");
  await pickCenter(page, "Deep Single Concave");
  await timeADrag(page, "Fish, no wing, 12 steps", 12);
  await timeADrag(page, "Fish, no wing, 4 steps", 4);
  await goToScreen(page, "TEMPLATE");
  await addWing(page);
  await goToScreen(page, "BOTTOM");
  await timeADrag(page, "Fish, one wing, 12 steps", 12);
  await timeADrag(page, "Fish, one wing, 4 steps", 4);
});

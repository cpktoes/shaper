import { join } from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2f7f351aa6b8b4e9/e2e/helpers/screens";

// Scratch: the pictures of BOTTOM's WINGS row and of a bottom kept with its board, for the founder's look (17-12).
// Every picture is the running page on the worktree's own dev server.
const SHOTS = join(__dirname, "shots");
const shot = (name: string) => join(SHOTS, `${name}.png`);
const NARROWEST = "Narrowest outline";
const NATURAL = "Natural outline, before the wing";
const RULE_MENU = "Measure Off Rail from";

async function quiet(page: Page, metric = false) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  if (metric) await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
}

async function openPreset(page: Page, name: string) {
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  await expect(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2_000 });
      await card.click({ timeout: 2_000 });
    }
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
  }).toPass({ timeout: 90_000 });
}

async function addWings(page: Page, count: number) {
  await expect(async () => {
    await page.getByRole("tab", { name: "ADD WINGS" }).click({ timeout: 2_000 });
    await expect(page.getByRole("tab", { name: "ADD WINGS" })).toHaveAttribute("aria-selected", "true", { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await page.getByRole("button", { name: "+ Add a wing" }).filter({ visible: true }).first().click();
  const dialog = page.getByRole("dialog", { name: "Dial in your wing placement" });
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Got it" }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByRole("tab", { name: "WINGS · 1" })).toBeVisible();
  for (let n = 2; n <= count; n += 1) {
    await page.getByRole("button", { name: `+ Add wing ${n}` }).filter({ visible: true }).first().click();
    await expect(page.getByRole("tab", { name: `WINGS · ${n}` })).toBeVisible();
  }
}

async function toBottom(page: Page) {
  await goToScreen(page, "BOTTOM");
  await expect(page).toHaveURL(/\/design\/bottom$/, { timeout: 60_000 });
  await expect(page.locator('[data-bottom-card="nose"]')).toBeVisible({ timeout: 60_000 });
}

async function pick(page: Page, section: "Nose" | "Center" | "Tail", name: string) {
  await expect(async () => {
    await page.getByRole("combobox", { name: `${section} Cut` }).click();
    await page.getByRole("option", { name, exact: true }).click({ timeout: 2_000 });
    await expect(page.locator(`[data-bottom-card="${section.toLowerCase()}"] [data-bottom-cut-echo]`)).toHaveText(name, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

async function pickFrom(page: Page, menu: string, option: string) {
  const box = page.getByRole("combobox", { name: menu, exact: true });
  await expect(async () => {
    await box.click();
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2_000 });
    await expect(box).toContainText(option, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

const wingsRow = (page: Page): Locator => page.locator("[data-bottom-wings]");

/** Brings the WINGS row to the top of the controls, clear of anything pinned over them. */
async function showWingsRow(page: Page) {
  await wingsRow(page).evaluate((el) => el.scrollIntoView({ block: "start" }));
  await page.waitForTimeout(300);
}

/** A close look at the tail's rail on the top view, where the wing stands: the last third of the board, one side. */
async function tailCloseUp(page: Page, name: string) {
  const box = (await page.locator("[data-bottom-top-view]").boundingBox())!;
  const drawn = await page.locator("[data-bottom-top-view] g").first().boundingBox();
  const b = drawn ?? box;
  await page.screenshot({
    path: shot(name),
    clip: { x: b.x + b.width * 0.7, y: b.y, width: b.width * 0.3, height: b.height * 0.5 },
  });
}

/** Reads everything BOTTOM's panel holds the board to, off the page. */
async function panelReading(page: Page) {
  return page.evaluate(() => {
    const squash = (text: string | null | undefined) => (text ?? "").replace(/\s+/g, " ").trim();
    return [...document.querySelectorAll("[data-bottom-wings], [data-bottom-card]")].map((root) => ({
      part: root.getAttribute("data-bottom-card") ?? "wings",
      cut: squash(root.querySelector("[data-bottom-cut-echo]")?.textContent),
      channels: squash(root.querySelector("[data-bottom-channels-echo]")?.textContent),
      sliders: [...root.querySelectorAll<HTMLInputElement>('input[type="range"]')].map(
        (el) => `${el.getAttribute("aria-label")} = ${el.getAttribute("aria-valuenow") ?? el.value}`,
      ),
      menus: [...root.querySelectorAll('[role="combobox"]')].map(
        (el) => `${el.getAttribute("aria-label")} = ${squash(el.querySelector("[data-slot=select-value]")?.textContent)}`,
      ),
    }));
  });
}

test.describe("computer", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "desktop"));

  test("a winged Fish: Narrowest then Natural, with an Extending Single Concave", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Fish");
    await addWings(page, 1);
    await toBottom(page);
    await pick(page, "Tail", "Extending Single Concave");
    for (const [rule, key] of [
      [NARROWEST, "narrowest"],
      [NATURAL, "natural"],
    ] as const) {
      if (rule === NATURAL) await pickFrom(page, RULE_MENU, NATURAL);
      await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
      await showWingsRow(page);
      await page.mouse.move(700, 790);
      await page.waitForTimeout(500);
      await page.screenshot({ path: shot(`fish-${key}-window`) });
      await wingsRow(page).screenshot({ path: shot(`fish-${key}-row`) });
      await page.locator("[data-bottom-top-view-press]").screenshot({ path: shot(`fish-${key}-top`) });
      await page.getByRole("tab", { name: "DATA", exact: true }).click();
      await expect(page.locator("[data-bottom-marks]")).toBeVisible();
      await page.locator("[data-bottom-marks]").scrollIntoViewIfNeeded();
      await page.waitForTimeout(300);
      await page.locator("[data-bottom-marks]").screenshot({ path: shot(`fish-${key}-marks`) });
      console.log(`${key}: echo "${await page.locator("[data-bottom-wings-echo]").innerText()}" · note "${await page.locator("[data-bottom-wing-note]").innerText()}"`);
    }
    // The menu open, so both rules show at once.
    await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
    await showWingsRow(page);
    await page.getByRole("combobox", { name: RULE_MENU, exact: true }).click();
    await expect(page.getByRole("option", { name: NARROWEST, exact: true })).toBeVisible();
    await page.waitForTimeout(400);
    await page.screenshot({ path: shot("fish-menu-open"), clip: { x: 0, y: 0, width: 520, height: 520 } });
    await page.keyboard.press("Escape");
  });

  test("two wings: the heading and the caption name both", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Fish");
    await addWings(page, 2);
    await toBottom(page);
    await showWingsRow(page);
    await page.waitForTimeout(400);
    await page.screenshot({ path: shot("two-wings-window") });
    await wingsRow(page).screenshot({ path: shot("two-wings-row") });
    console.log(`two wings: "${await page.locator("[data-bottom-wings-echo]").innerText()}" · caption "${await page.locator("[data-bottom-top-view-note]").innerText()}"`);
  });

  test("a board with no wing: no WINGS row", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Shortboard");
    await toBottom(page);
    await expect(wingsRow(page)).toHaveCount(0);
    await page.waitForTimeout(400);
    await page.screenshot({ path: shot("no-wing-window") });
    console.log(`no wing: caption "${await page.locator("[data-bottom-top-view-note]").innerText()}"`);
  });

  test("Metric: one wing, then two", async ({ page }) => {
    await quiet(page, true);
    await openPreset(page, "Fish");
    await addWings(page, 1);
    await toBottom(page);
    await pick(page, "Tail", "Extending Single Concave");
    await showWingsRow(page);
    await page.waitForTimeout(400);
    await page.screenshot({ path: shot("metric-one-window") });
    await wingsRow(page).screenshot({ path: shot("metric-one-row") });
    console.log(`metric, one wing: "${await page.locator("[data-bottom-wings-echo]").innerText()}" · caption "${await page.locator("[data-bottom-top-view-note]").innerText()}"`);
    await goToScreen(page, "TEMPLATE");
    await page.getByRole("tab", { name: "WINGS · 1" }).click();
    await page.getByRole("button", { name: "+ Add wing 2" }).filter({ visible: true }).first().click();
    await expect(page.getByRole("tab", { name: "WINGS · 2" })).toBeVisible();
    await toBottom(page);
    await showWingsRow(page);
    await page.waitForTimeout(400);
    await wingsRow(page).screenshot({ path: shot("metric-two-row") });
    console.log(`metric, two wings: "${await page.locator("[data-bottom-wings-echo]").innerText()}" · caption "${await page.locator("[data-bottom-top-view-note]").innerText()}"`);
  });

  test("a bottom kept with its board: shaped, left, and opened again from the Board Rack", async ({ page }) => {
    await quiet(page);
    await page.setViewportSize({ width: 1280, height: 2300 });
    await openPreset(page, "Fish");
    await addWings(page, 1);
    await toBottom(page);
    await pick(page, "Tail", "Spiral Vee");
    await pickFrom(page, "Channels", "6 channels");
    await pickFrom(page, RULE_MENU, NATURAL);
    await page.waitForTimeout(800);
    const before = await panelReading(page);
    await wingsRow(page).screenshot({ path: shot("kept-before-row") });
    await page.locator('[data-bottom-card="tail"]').screenshot({ path: shot("kept-before-tail") });
    const litresBefore = await page.evaluate(() => document.body.innerText.match(/\d+\.\d+\s*L/g)?.slice(0, 3).join(" | "));
    // The browser writes its copy of the open board a moment after the last change.
    await expect
      .poll(async () => page.evaluate(() => /"Spiral Vee"/.test(window.localStorage.getItem("shaper-open-board") ?? "")), { timeout: 20_000 })
      .toBe(true);

    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto("/");
    const caption = page.locator('[data-rack-caption]').filter({ hasText: "In progress" }).first();
    await expect(caption).toBeVisible({ timeout: 60_000 });
    await page.waitForTimeout(1500);
    await page.screenshot({ path: shot("kept-rack-window") });
    const open = caption.getByRole("button", { name: "Continue This Board" });
    await expect(async () => {
      if (!/\/design\/outline$/.test(page.url())) await open.click({ timeout: 2_000 });
      await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
    }).toPass({ timeout: 90_000 });
    await page.setViewportSize({ width: 1280, height: 2300 });
    await toBottom(page);
    await expect(page.locator('[data-bottom-card="tail"] [data-bottom-cut-echo]')).toHaveText("Spiral Vee", { timeout: 60_000 });
    await page.waitForTimeout(800);
    const after = await panelReading(page);
    expect(after).toEqual(before);
    await wingsRow(page).screenshot({ path: shot("kept-after-row") });
    await page.locator('[data-bottom-card="tail"]').screenshot({ path: shot("kept-after-tail") });
    const litresAfter = await page.evaluate(() => document.body.innerText.match(/\d+\.\d+\s*L/g)?.slice(0, 3).join(" | "));
    console.log(`kept: ${before.reduce((n, p) => n + p.sliders.length + p.menus.length, 0)} sliders and menus read the same before and after; litres ${litresBefore} → ${litresAfter}`);
    console.log(`kept: tail sliders ${before[3].sliders.join("; ")}`);
  });
});

test.describe("close up", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "zoom"));

  test("the edge behind the wing, Narrowest beside Natural", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Fish");
    await addWings(page, 1);
    await toBottom(page);
    await pick(page, "Tail", "Extending Single Concave");
    await page.mouse.move(700, 790);
    await page.waitForTimeout(600);
    await tailCloseUp(page, "zoom-narrowest");
    await pickFrom(page, RULE_MENU, NATURAL);
    await page.mouse.move(700, 790);
    await page.waitForTimeout(600);
    await tailCloseUp(page, "zoom-natural");
  });
});

test.describe("phone", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "iphone"));

  test("upright: the WINGS row under the drawing", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Fish");
    await addWings(page, 1);
    await toBottom(page);
    await pick(page, "Tail", "Extending Single Concave");
    await showWingsRow(page);
    await page.waitForTimeout(500);
    await page.screenshot({ path: shot("phone-narrowest") });
    await pickFrom(page, RULE_MENU, NATURAL);
    await showWingsRow(page);
    await page.waitForTimeout(500);
    await page.screenshot({ path: shot("phone-natural") });
  });
});

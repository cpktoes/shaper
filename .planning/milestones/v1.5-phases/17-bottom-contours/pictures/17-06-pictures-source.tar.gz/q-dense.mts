/* Scratch: the channels' foam per station with the re-laid run, the old 24-point run and a 400-point run (the truth). */
import path from "node:path";
const [root] = process.argv.slice(2);
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const FR = await import(path.join(root, "lib/geometry/finished-rail.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { inchesToMm, mm } = await import(path.join(root, "lib/geometry/units.ts"));
const all = phase16Boards();
for (const preset of BOARD_PRESETS) {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b: any) => b.label === label).fields;
  const geometry = buildOutline(fields.outline);
  const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
  const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = design.designBottomBoard(fields.outline, geometry, profile, design.designFinPlacement(fields));
  for (const count of [4, 6, 8] as const) {
    const bottom = structuredClone(B.DEFAULT_BOTTOM);
    bottom.channels = B.startingChannels(count, board, bottom.channels);
    const input = design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
    const { bottomWallsAt, foamOffAt, ...plain } = input;
    const base = V.boardSections(plain);
    const walled = V.boardSections(input);
    const old = V.boardSections({ ...plain, foamOffAt });
    let eNew = 0, eOld = 0, tot = 0;
    base.forEach((s: any, k: number) => {
      if (!s.result) return;
      const half = s.drawn ?? s.blended ?? FR.sampledFinishedRail(s.result, s.domed, s.halfWidth);
      const edge = 78;
      const run = half.slice(edge);
      const [ye] = run[0];
      const dense = [...half.slice(0, edge + 1)];
      for (let i = 1; i <= 400; i++) dense.push([ye * (1 - i / 400), 0]);
      const cut = V.bottomedHalfSection(dense, (y: number) => foamOffAt(s.station, y), V.BOTTOM_COLUMN_FLOOR);
      const truth = FR.sampledSectionArea(half) - FR.sampledSectionArea(cut.half);
      const nw = s.area - walled[k].area;
      const od = s.area - old[k].area;
      tot += truth; eNew += Math.abs(nw - truth); eOld += Math.abs(od - truth);
    });
    console.log(preset.id, count, `truth Σ ${tot.toFixed(1)} mm²`, `re-laid off by ${eNew.toFixed(2)}`, `old run off by ${eOld.toFixed(2)}`);
  }
}

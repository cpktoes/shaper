/* Scratch: the five boards with 8 channels (starting numbers, and every section + channels at 1/2"): mesh check,
   mesh vs litres, wall faces, and the litres with and without the re-laid run. Run from the worktree root:
   npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> */
import path from "node:path";
const [root] = process.argv.slice(2);
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const S = await import(path.join(root, "lib/geometry/board-surface.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { frontFinStation } = await import(path.join(root, "lib/geometry/fins.ts"));
const { inchesToMm, mm } = await import(path.join(root, "lib/geometry/units.ts"));

const all = phase16Boards();
const jobs: { id: string; fields: any }[] = BOARD_PRESETS.map((preset: any) => {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  return { id: preset.id, fields: all.find((b: any) => b.label === label).fields };
});
const fishF = jobs.find((j) => j.id === "fish")!.fields;
const wing = { station: mm(frontFinStation(design.designFinPlacement(fishF)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
jobs.push({ id: "fishwing", fields: { ...fishF, outline: { ...fishF.outline, wings: [wing] } } });

const TRIO: Record<string, string> = { nose: "Rolled Belly Entry", center: "Deep Single Concave", tail: "Rolled Vee" };
for (const { id, fields } of jobs) {
  const geometry = buildOutline(fields.outline);
  const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
  const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = design.designBottomBoard(fields.outline, geometry, profile, design.designFinPlacement(fields));
  for (const half of [false, true]) {
    const bottom = structuredClone(B.DEFAULT_BOTTOM);
    if (half) for (const s of B.BOTTOM_SECTIONS) bottom[s] = { ...B.startingCut(s, TRIO[s], board), depth: inchesToMm(1 / 2) };
    bottom.channels = { ...B.startingChannels(8, board, bottom.channels), ...(half ? { depth: inchesToMm(1 / 2) } : {}) };
    const sections = design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
    const t0 = performance.now();
    const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
    const ms = performance.now() - t0;
    const litres = V.computeCrossSectionVolume(sections).volumeLitres;
    const { bottomWallsAt, ...noWalls } = sections;
    const litresOld = V.computeCrossSectionVolume(noWalls).volumeLitres;
    const flat = V.computeCrossSectionVolume(design.designCrossSectionInput(geometry, profile, rails, fields.outline.length)).volumeLitres;
    const gap = (S.enclosedVolumeMm3(surface) / 1e6 - litres) / litres;
    const walls = Array.from(surface.faceKinds).filter((k) => k === S.SURFACE_FACE.channelWall).length;
    console.log(id, half ? "all 1/2\"" : "start", JSON.stringify(S.meshCheck(surface)), `gap ${(gap * 100).toFixed(4)}%`, `walls ${walls}`, `ring ${surface.rings[5].right.length}`,
      `off ${(flat - litres).toFixed(4)} L (old run ${(flat - litresOld).toFixed(4)})`, `${ms.toFixed(0)} ms`);
  }
}

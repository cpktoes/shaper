/* Plan 17-06's picture: the channels, drawn from the app's own maths (lib/geometry/bottom.ts, the seam in volume.ts and
   the surface in board-surface.ts) against sketch 021's executed figures (bottom-golden.json) as dots: the sawtooth across
   the Shortboard at its front fins with 4, 6 and 8 channels; the three runs from above on the Fish and the Shortboard
   with the outer pair longest and a 2" stagger; the three length orders; a squeezed set's read-out; the litres each set
   takes on every board, and under three different centre cuts; and the 3D board's ring with its walls. Nothing is typed:
   every figure is read or computed by the app's functions, every inch through lib/geometry/units.ts.
   Usage (from the worktree root):
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> <out.html> */
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const units = await import(path.join(root, "lib/geometry/units.ts"));
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const S = await import(path.join(root, "lib/geometry/board-surface.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { frontFinStation } = await import(path.join(root, "lib/geometry/fins.ts"));
const { formatInchesFraction, inchesToMm, mm } = units;

const golden = JSON.parse(readFileSync(path.join(root, "lib/geometry/__fixtures__/bottom-golden.json"), "utf8"));

/* the five boards, built as the golden's script builds them */
const all = phase16Boards();
const jobs: { id: string; fields: any }[] = BOARD_PRESETS.map((preset: any) => {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  return { id: preset.id, fields: all.find((b: any) => b.label === label).fields };
});
const fishF = jobs.find((j) => j.id === "fish")!.fields;
const wing = { station: mm(frontFinStation(design.designFinPlacement(fishF)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
jobs.push({ id: "fishwing", fields: { ...fishF, outline: { ...fishF.outline, wings: [wing] } } });
const fieldsOf = (id: string) => jobs.find((j) => j.id === id)!.fields;
const parts = (fields: any) => {
  const geometry = buildOutline(fields.outline);
  const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
  const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = design.designBottomBoard(fields.outline, geometry, profile, design.designFinPlacement(fields));
  return { geometry, profile, rails, board };
};
const P: Record<string, any> = Object.fromEntries(jobs.map((j) => [j.id, parts(j.fields)]));
const NAME: Record<string, string> = { shortboard: "Shortboard", fish: "Fish", midlength: "Mid-length", longboard: "Longboard", fishwing: "Fish, winged" };
const frac = (v: number) => formatInchesFraction(mm(v));
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");

/** A bottom with the named sections at their starting numbers and `count` channels picked as the store picks them. */
const bottomOf = (id: string, names: Record<string, string>, count: 0 | 4 | 6 | 8, change: Record<string, unknown> = {}) => {
  const board = P[id].board;
  const b = structuredClone(B.DEFAULT_BOTTOM);
  for (const section of B.BOTTOM_SECTIONS) if (names[section]) b[section] = B.startingCut(section, names[section], board);
  if (count) b.channels = { ...B.startingChannels(count, board, b.channels), ...change };
  return b;
};
const litresOf = (id: string, bottom?: any) => design.summarizeDesign({ ...fieldsOf(id), bottom }).volumeLitres;
const sectionInput = (id: string, bottom: any) => {
  const { geometry, profile, rails, board } = P[id];
  return design.designCrossSectionInput(geometry, profile, rails, fieldsOf(id).outline.length, { bottom, board });
};

/* ---------- 1. the sawtooth across the Shortboard: 4, 6, 8 channels ---------- */
const EXAG = 4;
function sectionSvg(id: string, resolved: any, s: number, opts: { dots?: { y: number; off: number }[]; walls?: number[]; PW?: number; PH?: number; title?: string }) {
  const board = P[id].board;
  const PW = opts.PW ?? 540, PH = opts.PH ?? 150, padX = 18, base = 40;
  const W = board.railAt(mm(s));
  const sx = (PW - 2 * padX) / (2 * W);
  const X = (y: number) => PW / 2 + y * sx;
  const Y = (off: number) => base + off * sx * EXAG; // the board upside down: the bottom on top, a cut dips into it
  const N = 1400;
  const pts: string[] = [];
  for (let i = 0; i <= N; i++) {
    const y = -W + (2 * W * i) / N;
    pts.push(`${X(y).toFixed(2)},${Y(B.foamOff(resolved, board, mm(s), mm(Math.abs(y)))).toFixed(2)}`);
  }
  const fill = `M${X(-W)},${base} L${pts.join(" L")} L${X(W)},${base} Z`;
  const dots = (opts.dots ?? []).map((d) => `<circle cx="${X(d.y).toFixed(2)}" cy="${Y(d.off).toFixed(2)}" r="3.2" fill="none" stroke="#c0392b" stroke-width="1.5"/>`).join("");
  const walls = (opts.walls ?? []).flatMap((w) => [w, -w]).map((w) => `<line x1="${X(w)}" x2="${X(w)}" y1="${base - 9}" y2="${base - 2}" stroke="#2a6f97" stroke-width="1.4"/>`).join("");
  return `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}">
    <rect x="${X(-W)}" y="${base}" width="${2 * W * sx}" height="${PH - base - 20}" fill="#eef1f4"/>
    <path d="${fill}" fill="#f5d9b8"/>
    <line x1="${X(-W) - 6}" x2="${X(W) + 6}" y1="${base}" y2="${base}" stroke="#5b6772" stroke-width="1.1" stroke-dasharray="5 4"/>
    <polyline points="${pts.join(" ")}" fill="none" stroke="#1d2a36" stroke-width="1.6"/>
    ${dots}${walls}
    <line x1="${PW / 2}" x2="${PW / 2}" y1="${base - 14}" y2="${PH - 18}" stroke="#9aa3ad" stroke-width="1" stroke-dasharray="2 3"/>
    <text x="${PW / 2}" y="${PH - 5}" text-anchor="middle">stringer</text>
    <text x="${X(-W)}" y="${PH - 5}" text-anchor="start">rail</text><text x="${X(W)}" y="${PH - 5}" text-anchor="end">rail</text>
    ${opts.title ? `<text x="${padX}" y="14" style="font-size:12px;fill:#1d2a36;font-weight:600">${esc(opts.title)}</text>` : ""}
  </svg>`;
}

const SB = "shortboard";
const sbBoard = P[SB].board;
// the golden's 6" stations: the one nearest the front fins (the channels' deepest station)
const chCase = (id: string, count: number, run: string, longer: string) => golden.cases.find((c: any) => c.kind === "channels" && c.board === id && c.count === count && c.run === run && c.longer === longer);
const nearest = (list: number[], target: number) => list.reduce((best, s) => (Math.abs(s - target) < Math.abs(best - target) ? s : best), list[0]);
let worstWall = 0;
const sawPanels = [4, 6, 8].map((count) => {
  const bottom = bottomOf(SB, {}, count as 4 | 6 | 8);
  const resolved = B.resolveBottom(bottom, sbBoard);
  const c = chCase(SB, count, "parallel", "outer");
  const st = c.stations.find((x: any) => x.s === nearest(c.stations.map((x: any) => x.s), resolved.channels.deepest));
  // the sketch's walls at that station, as dots at each wall's top and foot (the app's own depth there)
  const dots: { y: number; off: number }[] = [];
  for (const [a, b, j] of st.edges) {
    const app = B.channelEdges(resolved.channels, sbBoard, "narrowest", mm(st.s)).find((e: any) => e[2] === j);
    worstWall = Math.max(worstWall, Math.abs(app[0] - a), Math.abs(app[1] - b));
    for (const side of [1, -1]) {
      if (b < sbBoard.railAt(mm(st.s))) {
        dots.push({ y: side * b, off: B.foamOff(resolved, sbBoard, mm(st.s), mm(b)) });
        dots.push({ y: side * b, off: B.foamOff(resolved, sbBoard, mm(st.s), mm(b + 1e-6)) });
      }
      dots.push({ y: side * a, off: 0 });
    }
  }
  const r = B.channelReadout(resolved.channels, sbBoard, "narrowest");
  const label = `${count} channels · Channel Width — ${frac(r.width)} · ramp ${r.rampDegrees}° · last wall ${frac(r.lastWallOffRail)} off the rail`;
  return `<div class="panel">${sectionSvg(SB, resolved, st.s, { dots, title: `${label} · ${frac(st.s)} from the tail` })}</div>`;
});
// the six-channel opening's foam off against the golden grid (the channels' term: the opening with six less without)
const grid = golden.boards.find((b: any) => b.id === SB).facts.grid;
const op6 = golden.cases.find((c: any) => c.kind === "opening" && c.board === SB && c.channels === 6);
const op0 = golden.cases.find((c: any) => c.kind === "opening" && c.board === SB && c.channels === 0);
let worstGrid = 0;
let probes = 0;
const sbOpen6 = B.resolveBottom(bottomOf(SB, { center: "Deep Single Concave" }, 6), sbBoard);
grid.s.forEach((s: number, k: number) => grid.y[k].forEach((y: number, j: number) => {
  probes++;
  worstGrid = Math.max(worstGrid, Math.abs(B.channelFoamOff(sbOpen6.channels, sbBoard, "narrowest", mm(s), mm(y)) - (op6.foamOff[k][j] - op0.foamOff[k][j])));
}));
const kGrid = grid.s.reduce((best: number, s: number, k: number) => (Math.abs(s - sbBoard.frontFins) < Math.abs(grid.s[best] - sbBoard.frontFins) ? k : best), 0);
const gridDots = grid.y[kGrid].flatMap((y: number, j: number) => [y, -y].map((yy: number) => ({ y: yy, off: op6.foamOff[kGrid][j] })));
const openPanel = `<div class="panel">${sectionSvg(SB, sbOpen6, grid.s[kGrid], { dots: gridDots, title: `The opening (Deep Single Concave) with six channels cut into it · ${frac(grid.s[kGrid])} from the tail · the sketch's own foam off as dots` })}</div>`;

/* ---------- 2. from above: the three runs on the Fish and the Shortboard, the outer pair longest ---------- */
function topSvg(id: string, run: string, longest: string, opts: { PW?: number; reach?: number } = {}) {
  const board = P[id].board;
  const bottom = bottomOf(id, {}, 6, { run, longest });
  const resolved = B.resolveBottom(bottom, board);
  const ch = resolved.channels;
  const reach = opts.reach ?? ch.start + inchesToMm(3);
  const PW = opts.PW ?? 340;
  const halfMax = Math.max(...Array.from({ length: 121 }, (_, i) => board.railAt(mm((reach * i) / 120))));
  const sx = (PW - 24) / reach;
  const PH = Math.round(2 * halfMax * sx + 46);
  const cy = (PH - 14) / 2;
  const X = (s: number) => PW - 12 - s * sx; // nose left, tail right, like the app's drawings
  const Y = (y: number) => cy + y * sx;
  const rail: string[] = [];
  for (let i = 0; i <= 200; i++) { const s = (reach * i) / 200; rail.push(`${X(s).toFixed(1)},${Y(board.railAt(mm(s))).toFixed(1)}`); }
  for (let i = 200; i >= 0; i--) { const s = (reach * i) / 200; rail.push(`${X(s).toFixed(1)},${Y(-board.railAt(mm(s))).toFixed(1)}`); }
  // each wall from its own channel's start to the tail, only where it is on the board
  const lines: string[] = [];
  for (let j = 0; j < ch.count / 2; j++) {
    const start = B.channelStart(ch, j);
    for (const side of [1, -1]) {
      let seg: string[] = [];
      const flush = () => { if (seg.length > 1) lines.push(`<polyline points="${seg.join(" ")}" fill="none" stroke="#2a6f97" stroke-width="1.3"/>`); seg = []; };
      for (let i = 0; i <= 160; i++) {
        const s = (start * i) / 160;
        const edge = B.channelEdges(ch, board, "narrowest", mm(s)).find((e: any) => e[2] === j);
        if (!edge || edge[1] >= board.railAt(mm(s))) { flush(); continue; }
        seg.push(`${X(s).toFixed(1)},${Y(side * edge[1]).toFixed(1)}`);
      }
      flush();
    }
  }
  // the sketch's walls every 6" as dots
  const c = chCase(id, 6, run, longest);
  const dots = c.stations.filter((x: any) => x.s <= reach).flatMap((x: any) => x.marks.filter((m: any) => m.on && m.y < board.railAt(mm(x.s))).flatMap((m: any) => [m.y, -m.y].map((y: number) => `<circle cx="${X(x.s).toFixed(1)}" cy="${Y(y).toFixed(1)}" r="2.6" fill="none" stroke="#c0392b" stroke-width="1.3"/>`))).join("");
  const fins = `<line x1="${X(board.frontFins)}" x2="${X(board.frontFins)}" y1="${Y(-halfMax) - 4}" y2="${Y(halfMax) + 4}" stroke="#7a8590" stroke-dasharray="3 3"/><text x="${X(board.frontFins)}" y="${PH - 2}" text-anchor="middle">front fins</text>`;
  const runWord = run === "parallel" ? "Parallel" : run === "rail" ? "With the rail" : board.toeDegrees > 0 ? `Toe-in · ${board.toeDegrees.toFixed(1)}°` : "Toe-in (no toe)";
  return { svg: `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}"><polygon points="${rail.join(" ")}" fill="#eef1f4" stroke="#1d2a36" stroke-width="1.2"/><line x1="${X(reach)}" x2="${X(0)}" y1="${cy}" y2="${cy}" stroke="#9aa3ad" stroke-dasharray="4 3"/>${fins}${lines.join("")}${dots}</svg>`, runWord, ch };
}
const runPanels = ["fish", "shortboard"].map((id) => {
  const cells = ["parallel", "rail", "toe"].map((run) => { const t = topSvg(id, run, "outer"); return `<div class="panel"><div class="ph"><b>${NAME[id]}</b> · ${esc(t.runWord)}</div>${t.svg}</div>`; }).join("");
  return `<div class="three">${cells}</div>`;
}).join("");
const longPanels = ["outer", "inner", "same"].map((longest) => {
  const t = topSvg(SB, "parallel", longest);
  const starts = Array.from({ length: t.ch.count / 2 }, (_, j) => frac(B.channelStart(t.ch, j))).join(" · ");
  const word = longest === "outer" ? "the outer pair longest" : longest === "inner" ? "the inner pair longest" : "all the same";
  return `<div class="panel"><div class="ph"><b>Shortboard</b> · Parallel · ${word}</div>${t.svg}<p class="sub">Starts, inner to outer: ${esc(starts)} from the tail; every channel deepest at ${esc(frac(t.ch.deepest))} and out the tail.</p></div>`;
}).join("");

/* ---------- 3. a squeezed set ---------- */
const squeezed = B.resolveBottom(bottomOf(SB, {}, 8, { width: inchesToMm(4) }), sbBoard).channels;
const sq = B.channelReadout(squeezed, sbBoard, "narrowest");
const readouts = ["shortboard", "fish", "longboard"].flatMap((id) => [4, 6, 8].map((count) => {
  const ch = B.resolveBottom(bottomOf(id, {}, count as 4 | 6 | 8), P[id].board).channels;
  const r = B.channelReadout(ch, P[id].board, "narrowest");
  return `<tr><td class="b">${NAME[id]}</td><td class="n">${count}</td><td>Channel Width — ${esc(frac(r.width))}${r.squeezed ? ` (${esc(frac(r.fittedWidth))} to fit)` : ""} · ramp ${r.rampDegrees}° · last wall ${esc(frac(r.lastWallOffRail))} off the rail</td><td>the inner pair starts ${esc(frac(r.shortestStart))} from the tail</td></tr>`;
})).join("");

/* ---------- 4. the litres ---------- */
const litresRows = jobs.map(({ id }) => {
  const before = litresOf(id);
  const takes = [4, 6, 8].map((count) => before - litresOf(id, bottomOf(id, {}, count as 4 | 6 | 8)));
  const g6 = golden.cases.find((c: any) => c.kind === "opening" && c.board === id && c.channels === 6).litresOff - golden.cases.find((c: any) => c.kind === "opening" && c.board === id && c.channels === 0).litresOff;
  return { id, before, takes, g6 };
});
const litresTable = litresRows.map((r) => `<tr><td class="b">${NAME[r.id]}</td><td class="n">${r.before.toFixed(2)} L</td>${r.takes.map((t) => `<td class="n">${t.toFixed(2)} L</td>`).join("")}<td class="n">${r.g6.toFixed(2)} L</td></tr>`).join("");
const centres = [["Deep Single Concave", "Deep Single Concave"], ["Deep Single Concave at 1/8\"", "Deep Single Concave"], ["Flat Center", ""]].map(([word, name], i) => {
  const base = bottomOf(SB, name ? { center: name } : {}, 0);
  if (i === 1) base.center = { ...base.center, depth: inchesToMm(1 / 8) };
  const six = structuredClone(base);
  six.channels = B.startingChannels(6, sbBoard, base.channels);
  return { word, take: litresOf(SB, base) - litresOf(SB, six) };
});

/* ---------- 5. the 3D board's ring with its walls ---------- */
const ringBottom = bottomOf(SB, {}, 6);
const ringInput = sectionInput(SB, ringBottom);
const surface = S.buildBoardSurface({ sections: ringInput, geometry: P[SB].geometry, rockerAt: P[SB].profile.rockerAt });
const check = S.meshCheck(surface);
const ringSections = V.boardSections(ringInput, S.surfaceStations({ sections: ringInput, geometry: P[SB].geometry, rockerAt: P[SB].profile.rockerAt }));
const kRing = ringSections.reduce((best: number, s: any, k: number) => (Math.abs(s.station - sbBoard.frontFins) < Math.abs(ringSections[best].station - sbBoard.frontFins) ? k : best), 0);
const ring = ringSections[kRing];
function ringSvg(section: any) {
  const PW = 1060, PH = 210;
  const half = section.drawn;
  const W = section.halfWidth;
  const sx = (PW - 40) / (2 * W);
  const T = Math.max(...half.map((p: number[]) => p[1]));
  const X = (y: number) => PW / 2 + y * sx;
  const Y = (h: number) => PH - 26 - h * sx * EXAG; // ×4 height, deck up
  const scale = Math.min(1, (PH - 40) / (T * sx * EXAG));
  const Yc = (h: number) => PH - 26 - h * sx * EXAG * scale;
  const path = (side: number) => half.map((p: number[]) => `${X(side * p[0]).toFixed(1)},${Yc(p[1]).toFixed(1)}`).join(" ");
  const wallRows = new Set(section.wallRows);
  const marks = half.map((p: number[], k: number) => {
    const wall = wallRows.has(k) || wallRows.has(k - 1);
    return k >= 78 ? `<circle cx="${X(p[0]).toFixed(1)}" cy="${Yc(p[1]).toFixed(1)}" r="${wall ? 3 : 1.6}" fill="${wall ? "#c0392b" : "#1d2a36"}"/>` : "";
  }).join("");
  void Y;
  return `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}"><polyline points="${path(1)}" fill="none" stroke="#1d2a36" stroke-width="1.4"/><polyline points="${path(-1)}" fill="none" stroke="#1d2a36" stroke-width="1.4"/>${marks}<line x1="${X(-W)}" x2="${X(W)}" y1="${Yc(0)}" y2="${Yc(0)}" stroke="#5b6772" stroke-dasharray="5 4"/><text x="${PW / 2}" y="${PH - 6}" text-anchor="middle">stringer · the ring at ${esc(frac(section.station))} from the tail, height ×${(EXAG * scale).toFixed(1)}</text></svg>`;
}
// an oblique view of the tail's bottom from the 3D board's own rings: each ring's bottom run as a line
function obliqueSvg() {
  const PW = 1060, PH = 300;
  const reach = sbBoard.frontFins + inchesToMm(14);
  const picked = surface.rings.filter((r: any) => r.station <= reach);
  const pos = surface.positions;
  const sx = (PW - 80) / (reach + 2 * 260 * 0.5);
  const px = (x: number, y: number, z: number) => [40 + (reach - x) * sx + y * sx * 0.55, 150 - y * sx * 0.32 + (z - P[SB].profile.rockerAt(mm(x))) * sx * -EXAG];
  const lines = picked.filter((_: any, i: number) => i % 2 === 0).map((r: any) => {
    const pts = [...r.right.slice(78).reverse(), ...r.left.slice(78)].map((v: number) => { const [x, y] = px(pos[3 * v], pos[3 * v + 1], pos[3 * v + 2]); return `${x.toFixed(1)},${y.toFixed(1)}`; });
    return `<polyline points="${pts.join(" ")}" fill="none" stroke="#1d2a36" stroke-width="0.8" opacity="0.8"/>`;
  }).join("");
  return `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}">${lines}<text x="40" y="${PH - 8}">the 3D board's own rings, the bottom from the tail (right) to 14" ahead of the front fins, every other ring, looked at from below and to one side, height ×${EXAG}</text></svg>`;
}
const wallFaces = Array.from(surface.faceKinds).filter((k: number) => k === S.SURFACE_FACE.channelWall).length;
const litresSix = V.computeCrossSectionVolume(ringInput).volumeLitres;
const meshGap = (S.enclosedVolumeMm3(surface) / 1e6 - litresSix) / litresSix;
const steps = ring.wallRows.map((row: number) => ring.drawn[row + 1][1] - ring.drawn[row][1]);

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a36; margin: 0; padding: 28px 32px; width: 1100px; background: #fff; }
  h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 16px; margin: 26px 0 6px; } h3 { font-size: 13px; margin: 14px 0 4px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; }
  p { margin: 4px 0 10px; max-width: 1060px; } .lede { color: #4a5763; }
  .stack { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 16px; } .three { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 10px; }
  .panel { border: 1px solid #dde2e7; border-radius: 6px; padding: 8px 10px; } .ph { font-size: 13px; margin-bottom: 4px; }
  table { border-collapse: collapse; } th, td { border-bottom: 1px solid #dde2e7; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; font-weight: 700; }
  td.n { font-variant-numeric: tabular-nums; font-size: 13px; white-space: nowrap; text-align: right; } td.b { font-weight: 600; font-size: 13px; } td { font-size: 13px; color: #4a5763; }
  .sub { font-size: 11.5px; color: #6a7580; } svg text { font-size: 10.5px; fill: #5b6772; }
  .key span { display: inline-block; margin-right: 18px; } .sw { display: inline-block; width: 22px; height: 0; vertical-align: middle; margin-right: 6px; }
  .dot { display: inline-block; width: 8px; height: 8px; border: 1.5px solid #c0392b; border-radius: 50%; vertical-align: middle; margin-right: 6px; }
  .foot { font-size: 11px; color: #7a8590; margin-top: 16px; }
</style></head><body>
<h1>The channels — your sawtooth, the three runs, Longest and Stagger, and real walls in the 3D board</h1>
<p class="lede">Channels are now cut into the bottom, last, into whatever the nose, center and tail cuts leave. Every line here is the app's own maths; every red dot is your sketch 021's own figure. Nothing on any screen changes yet, and no board opens with channels.</p>
<div class="key"><span><i class="sw" style="border-top:2px solid #1d2a36"></i>the app</span><span><i class="dot"></i>the sketch's own figure</span><span><i class="sw" style="border-top:1.1px dashed #5b6772"></i>the planed bottom (straightedge)</span><span><i class="sw" style="border-top:8px solid #f5d9b8"></i>foam taken off</span><span><i class="sw" style="border-top:2px solid #2a6f97"></i>a wall</span></div>

<h2>1. The sawtooth across the Shortboard at its front fins — the board upside down, height ×${EXAG}</h2>
<p>The stringer is the first peak. Each channel's floor deepens outward in a straight ramp (Smoothness 0) to a square wall at the rail side, and the top of that wall is the next channel's peak — no flat between. Each set opens at its own width (2 1/2" · 1 3/4" · 1 1/4"), 5/16" deep. The red dots are the sketch's walls at its 6" station nearest the fins: each wall's top, its foot and the next peak.</p>
<div class="stack">${sawPanels.join("")}${openPanel}</div>
<p class="sub">The walls agree with the sketch's to ${worstWall.toExponential(1)} mm; over ${probes} points the channels' foam off agrees with the sketch's (its six-channel opening less its opening without) to ${worstGrid.toExponential(1)} mm.</p>

<h2>2. From above — six channels, the outer pair longest, a 2" stagger: the three runs</h2>
<p>Nose to the left, tail to the right. <b>Parallel</b> rules the walls straight from the deepest station, so where the outline narrows toward the tail the outer walls run out through the rail. <b>With the rail</b> keeps the last wall the same distance off the rail, so the set narrows toward the tail together, and once the gaps close the outer channels run out through the rail. <b>Toe-in</b> splays the set at the front fins' own angle — inward toward the nose, out toward the tail. Each wall starts at its own channel's start, so the fronts step.</p>
${runPanels}
<h3>The three length orders on the Shortboard, Parallel — only the starts stagger</h3>
<div class="three">${longPanels}</div>

<h2>3. What the Width and Stagger labels will read (17-09 words them)</h2>
<p><b>A squeezed set:</b> eight channels asked at 4" on the Shortboard won't fit, so they are squeezed to leave 1/2" to the rail at the deepest station: <i>Channel Width — ${esc(frac(sq.width))} (${esc(frac(sq.fittedWidth))} to fit) · ramp ${sq.rampDegrees}° · last wall ${esc(frac(sq.lastWallOffRail))} off the rail</i>.</p>
<table><tr><th>Board</th><th>Count</th><th>Width label</th><th>Stagger label (outer pair longest)</th></tr>${readouts}</table>

<h2>4. The litres each set takes, at its starting numbers</h2>
<table><tr><th>Board</th><th>Litres now</th><th>4 channels take</th><th>6 take</th><th>8 take</th><th>Sketch, 6 (slab)</th></tr>${litresTable}</table>
<p><b>The same foam under any center cut</b> (the channels add their own term to whatever the sections leave): six channels on the Shortboard take ${centres.map((c) => `<b>${c.take.toFixed(4)} L</b> under the ${esc(c.word)}`).join(", ")}.</p>
<p class="sub">The sketch's slab figure counts out to the outline as a square-railed slab; VOLUME counts the finished board, so a little of the outer channels' foam is foam the rail takes anyway — most on the Longboard, whose rail starts furthest in.</p>

<h2>5. The 3D board and the CNC files carry the walls as real walls</h2>
<p>On a board with channels every ring is laid out with a top and a foot point at each wall's own distance across, so a wall is a vertical step in the ring, not a slope between two points. The ring below is the 3D board's own at the front fins (red: the wall points); the steps there are ${steps.map((v: number) => esc(frac(v))).join(", ")} (the channels' 5/16" depth). The whole Shortboard with six channels: ${check.openEdges} open edges, ${check.nonManifoldEdges} non-manifold, ${check.misWoundEdges} mis-wound, ${check.zeroAreaTriangles} zero-area triangles; ${wallFaces.toLocaleString()} wall faces, drawn sharp on screen; the mesh holds ${(meshGap * 100).toFixed(3)}% of the litres (inside Phase 16's limit of 0.15%).</p>
<div class="panel">${ringSvg(ring)}</div>
<p class="foot">Drawn by gen-page.mts from lib/geometry/bottom.ts, volume.ts and board-surface.ts, and lib/geometry/__fixtures__/bottom-golden.json (sketch 021's maths executed on the app's boards); litres from summarizeDesign; inches through lib/geometry/units.ts. Plan 17-06, 2026-11-08.</p>
</body></html>`;
writeFileSync(out, html);
console.log("wrote", out);
console.log({ worstWall, worstGrid, probes, squeezed: sq, centres, check, wallFaces, meshGap, steps });
console.log(litresRows.map((r) => `${r.id}: before ${r.before.toFixed(4)}; take 4/6/8 ${r.takes.map((t) => t.toFixed(4)).join(" / ")}; sketch 6 ${r.g6.toFixed(4)}`).join("\n"));

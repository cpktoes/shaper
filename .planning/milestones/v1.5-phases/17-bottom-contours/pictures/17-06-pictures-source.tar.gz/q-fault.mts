/* Scratch: where the Fish with every section and 8 channels at 1/2" has non-manifold / mis-wound edges. */
import path from "node:path";
const [root, idArg] = process.argv.slice(2);
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const S = await import(path.join(root, "lib/geometry/board-surface.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { inchesToMm } = await import(path.join(root, "lib/geometry/units.ts"));
const id = idArg ?? "fish";
const preset = BOARD_PRESETS.find((p: any) => p.id === id);
const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
const fields = phase16Boards().find((b: any) => b.label === label).fields;
const geometry = buildOutline(fields.outline);
const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const board = design.designBottomBoard(fields.outline, geometry, profile, design.designFinPlacement(fields));
const TRIO: Record<string, string> = { nose: "Rolled Belly Entry", center: "Deep Single Concave", tail: "Rolled Vee" };
const bottom = structuredClone(B.DEFAULT_BOTTOM);
for (const s of B.BOTTOM_SECTIONS) bottom[s] = { ...B.startingCut(s, TRIO[s], board), depth: inchesToMm(1 / 2) };
bottom.channels = { ...B.startingChannels(8, board, bottom.channels), depth: inchesToMm(1 / 2) };
const sections = design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
const p = surface.positions, ix = surface.indices;
const n = p.length / 3;
const und = new Map<number, number>();
for (let t = 0; t < ix.length; t += 3) for (let e = 0; e < 3; e++) { const a = ix[t + e], b = ix[t + ((e + 1) % 3)]; const u = a < b ? a * n + b : b * n + a; und.set(u, (und.get(u) ?? 0) + 1); }
const bad = [...und].filter(([, c]) => c > 2).map(([u]) => [Math.floor(u / n), u % n]);
// which ring/slot each vertex is
const where = new Map<number, string[]>();
surface.rings.forEach((r: any, i: number) => {
  r.right.forEach((v: number, j: number) => { const l = where.get(v) ?? []; l.push(`r${i}R${j}`); where.set(v, l); });
  r.left.forEach((v: number, j: number) => { const l = where.get(v) ?? []; l.push(`r${i}L${j}`); where.set(v, l); });
});
for (const [a, b] of bad.slice(0, 8)) {
  const fmt = (v: number) => `${p[3 * v].toFixed(2)},${p[3 * v + 1].toFixed(3)},${p[3 * v + 2].toFixed(3)} [${(where.get(v) ?? []).join(" ")}]`;
  console.log("edge", fmt(a), "--", fmt(b));
}
const secs = V.boardSections(sections, S.surfaceStations({ sections, geometry, rockerAt: profile.rockerAt }));
const ringIdx = Number((where.get(bad[0][0]) ?? ["r0"])[0].match(/^r(\d+)/)![1]);
for (const k of [ringIdx - 1, ringIdx, ringIdx + 1]) {
  const s = secs[k];
  console.log("section", k, s.station.toFixed(2), "railEdgeAt", s.railEdgeAt, "walls", sections.bottomWallsAt(s.station).map((w: number) => w.toFixed(2)).join(","), "rows", s.wallRows);
  console.log("  ", (s.drawn ?? []).slice(70).map((q: number[]) => `(${q[0].toFixed(2)},${q[1].toFixed(2)})`).join(" "));
}

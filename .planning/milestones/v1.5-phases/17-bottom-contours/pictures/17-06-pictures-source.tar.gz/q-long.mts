/* Scratch: where the Longboard's re-laid run counts less foam than the 24-point one, station by station. */
import path from "node:path";
const [root, idArg] = process.argv.slice(2);
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { formatInchesFraction, mm } = await import(path.join(root, "lib/geometry/units.ts"));
const id = idArg ?? "longboard";
const preset = BOARD_PRESETS.find((p: any) => p.id === id);
const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
const fields = phase16Boards().find((b: any) => b.label === label).fields;
const geometry = buildOutline(fields.outline);
const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const board = design.designBottomBoard(fields.outline, geometry, profile, design.designFinPlacement(fields));
const bottom = structuredClone(B.DEFAULT_BOTTOM);
bottom.channels = B.startingChannels(8, board, bottom.channels);
const input = design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
const { bottomWallsAt, ...old } = input;
const a = V.boardSections(input);
const b = V.boardSections(old);
let sum = 0;
a.forEach((s: any, k: number) => {
  const d = s.area - b[k].area;
  sum += d;
  if (Math.abs(d) > 0.5) {
    const walls = bottomWallsAt(s.station).map((w: number) => w.toFixed(1)).join(",");
    const edgeY = s.drawn ? s.drawn[78][0].toFixed(1) : "-";
    console.log(formatInchesFraction(mm(s.station)), "new−old area", d.toFixed(3), "mm²", "walls", walls, "edge", edgeY, "half", s.halfWidth.toFixed(1), s.railEdgeAt ?? "");
  }
});
console.log("sum", sum.toFixed(2));

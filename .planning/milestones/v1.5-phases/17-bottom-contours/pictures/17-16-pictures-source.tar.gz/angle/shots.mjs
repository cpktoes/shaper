// Real-page pictures of the Angle row: each angled run on its own angle and set by hand.
import { open, shot, gotoBottom, pickFrom, owned, retry } from "../golive/lib.mjs";
const BASE = process.argv[2];
const out = process.argv[3];
const profile = process.argv[4] ?? "desktop";
async function setAngle(page, target) {
  const slider = page.getByRole("slider", { name: "Channel Angle", exact: true });
  await slider.scrollIntoViewIfNeeded();
  await slider.focus();
  for (let i = 0; i < 80; i++) {
    const now = Number(await slider.getAttribute("aria-valuenow"));
    if (Math.abs(now - target) < 0.01) break;
    await page.keyboard.press(now > target ? "ArrowLeft" : "ArrowRight");
    await page.waitForTimeout(40);
  }
  await page.waitForTimeout(800);
}
for (const board of ["shortboard", "midlength"]) {
  const opts = profile === "desktop" ? { theme: "daylight", scale: 3, viewport: { width: 1440, height: 900 } } : { theme: "daylight", scale: 3 };
  const { browser, page } = await open(BASE, profile, opts);
  try {
    if (board === "shortboard") await gotoBottom(page);
    else {
      await page.goto("/", { timeout: 180000 });
      await owned(page, "button");
      await retry(async () => { await page.getByRole("button").filter({ hasText: "Mid-length" }).first().click({ timeout: 5000 }); });
      await page.waitForURL("**/design/outline", { timeout: 60000 });
      await page.goto("/design/bottom", { timeout: 180000 });
      await owned(page, '[role="tab"]');
      await page.locator("[data-bottom-top-view]").waitFor({ timeout: 60000 });
    }
    if (profile !== "desktop") {
      const t = page.locator("[data-bottom-phone-sections]").getByRole("tab", { name: "Tail", exact: true });
      if ((await t.count()) > 0 && (await t.isVisible())) await t.click();
    }
    await pickFrom(page, "Channels", "6 channels");
    for (const [run, slug, hand] of [["With the rail", "rail", 5], ["Toe-in", "toe", 8]]) {
      await pickFrom(page, "Channel Run", run);
      await page.waitForTimeout(1200);
      const slider = page.getByRole("slider", { name: "Channel Angle", exact: true });
      await slider.scrollIntoViewIfNeeded();
      console.log(board, run, "own", await slider.getAttribute("aria-valuenow"), await slider.getAttribute("aria-valuetext"));
      await shot(page, `${out}/${profile}-${board}-${slug}-own.png`);
      await page.locator("[data-bottom-top-view]").screenshot({ path: `${out}/${profile}-top-${board}-${slug}-own.png`, animations: "disabled" });
      await setAngle(page, hand);
      console.log(board, run, "hand", await slider.getAttribute("aria-valuenow"), await slider.getAttribute("aria-valuetext"));
      await shot(page, `${out}/${profile}-${board}-${slug}-hand.png`);
      await page.locator("[data-bottom-top-view]").screenshot({ path: `${out}/${profile}-top-${board}-${slug}-hand.png`, animations: "disabled" });
    }
    console.log("OK", board);
  } catch (e) { console.log("FAIL", board, String(e).slice(0, 400)); }
  await browser.close();
}

#!/bin/bash
# Production build of the branch tip with stand-in settings (no server, no tests).
source /private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/gate/standin-env.sh
cd /Users/kontoes/Code/shaper/.claude/worktrees/beautiful-fermi-ad3fb7
npx next typegen > /private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/angle/build.log 2>&1
npm run build >> /private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/angle/build.log 2>&1; echo "BUILD_EXIT=$?" >> /private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/angle/build.log

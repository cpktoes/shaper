#!/bin/bash
# usage: after.sh <base-url> <out-dir>  — takes every "after" picture, then renders the printed BOTTOM CONTOURS page.
set -e
node /tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/golive/after.mjs "$1" "$2"
python3 - "$2" <<'PY'
import sys
from pypdf import PdfReader, PdfWriter
out = sys.argv[1]
r = PdfReader(out + "/_order-form.pdf")
print("order form pages:", len(r.pages))
for i, page in enumerate(r.pages):
    text = page.extract_text() or ""
    if "BOTTOM CONTOURS" in text.upper():
        w = PdfWriter(); w.add_page(page)
        w.write(open(out + "/after-bottom-contours-page.pdf", "wb"))
        print("bottom contours page is page", i + 1)
        break
else:
    raise SystemExit("no BOTTOM CONTOURS page in the print")
PY
qlmanage -t -s 2000 -o "$2" "$2/after-bottom-contours-page.pdf" > /dev/null 2>&1
mv "$2/after-bottom-contours-page.pdf.png" "$2/after-bottom-contours-page.png"
rm -f "$2/_order-form.pdf" "$2/after-bottom-contours-page.pdf"
ls "$2"

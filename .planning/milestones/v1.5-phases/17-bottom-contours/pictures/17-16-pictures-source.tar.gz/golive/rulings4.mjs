// Toe-in only (its option's name carries the fins' toe, so it is matched by its first word).
import { open, shot, gotoBottom, pickFrom, owned, retry } from "./lib.mjs";
const BASE = process.argv[2];
const out = process.argv[3];
for (const board of ["shortboard", "midlength"]) {
  const { browser, page } = await open(BASE, "desktop", { theme: "daylight", scale: 3, viewport: { width: 1440, height: 900 } });
  try {
    if (board === "shortboard") await gotoBottom(page);
    else {
      await page.goto("/", { timeout: 180000 });
      await owned(page, "button");
      await retry(async () => { await page.getByRole("button").filter({ hasText: "Mid-length" }).first().click({ timeout: 5000 }); });
      await page.waitForURL("**/design/outline", { timeout: 60000 });
      await retry(async () => { await page.getByRole("link", { name: "BOTTOM", exact: true }).first().click({ timeout: 5000 }); });
      await page.waitForURL("**/design/bottom", { timeout: 60000 });
      await page.locator("[data-bottom-top-view]").waitFor({ timeout: 60000 });
    }
    await pickFrom(page, "Channels", "6 channels");
    await pickFrom(page, "Channel Run", /^Toe-in/);
    await page.waitForTimeout(1500);
    const slug = `${board}-toe-in`;
    await shot(page, `${out}/page-${slug}.png`);
    await page.locator("[data-bottom-top-view]").screenshot({ path: `${out}/top-${slug}.png`, animations: "disabled" });
    console.log("OK", slug);
  } catch (e) { console.log("FAIL", board, String(e).slice(0, 300)); }
  await browser.close();
}

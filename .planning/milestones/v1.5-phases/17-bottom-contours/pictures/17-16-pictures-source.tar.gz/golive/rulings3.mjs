// The three channel runs on the real page, Shortboard and Mid-length, six channels: whole page and the top view alone.
// node rulings3.mjs <base-url> <out-dir>
import { open, shot, gotoBottom, pickFrom, owned, retry } from "./lib.mjs";
const BASE = process.argv[2];
const out = process.argv[3];
for (const board of ["shortboard", "midlength"]) {
  for (const run of ["Parallel", "With the rail", "Toe-in"]) {
    const { browser, page } = await open(BASE, "desktop", { theme: "daylight", scale: 3, viewport: { width: 1440, height: 900 } });
    try {
      if (board === "shortboard") await gotoBottom(page);
      else {
        await page.goto("/", { timeout: 180000 });
        await owned(page, "button");
        await retry(async () => { await page.getByRole("button").filter({ hasText: "Mid-length" }).first().click({ timeout: 5000 }); });
        await page.waitForURL("**/design/outline", { timeout: 60000 });
        await retry(async () => { await page.getByRole("link", { name: "BOTTOM", exact: true }).first().click({ timeout: 5000 }); });
        await page.waitForURL("**/design/bottom", { timeout: 60000 });
        await page.locator("[data-bottom-top-view]").waitFor({ timeout: 60000 });
      }
      await pickFrom(page, "Channels", "6 channels");
      if (run !== "Parallel") await pickFrom(page, "Channel Run", run);
      await page.waitForTimeout(1500);
      const slug = `${board}-${run.toLowerCase().replace(/[^a-z]+/g, "-")}`;
      await shot(page, `${out}/page-${slug}.png`);
      await page.locator("[data-bottom-top-view]").screenshot({ path: `${out}/top-${slug}.png`, animations: "disabled" });
      console.log("OK", slug, JSON.stringify(await page.locator("[data-bottom-top-view]").boundingBox()));
    } catch (e) { console.log("FAIL", board, run, String(e).slice(0, 300)); }
    await browser.close();
  }
}

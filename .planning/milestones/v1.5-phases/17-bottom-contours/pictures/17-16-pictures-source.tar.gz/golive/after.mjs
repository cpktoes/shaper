// "After" pictures for BOTTOM's go-live: the phase branch's own production build, served on a private port.
// node after.mjs <base-url> <out-dir> [only]
import { open, owned, shot, gotoBottom, pickFrom, tab, phoneSection } from "./lib.mjs";
const BASE = process.argv[2];
const out = process.argv[3];
const only = process.argv[4];

async function cut(page) {
  await phoneSection(page, "Center");
  await pickFrom(page, "Center Cut", "Deep Single Concave");
  await phoneSection(page, "Tail");
  await pickFrom(page, "Channels", "6 channels");
}

const jobs = {
  // BOTTOM on a computer in each of the four themes, then DATA and GUIDE, then the cut carried to FINS, 3D and SUMMARY.
  async desktop() {
    for (const theme of ["daylight", "chalk", "slate", "phosphor"]) {
      const { browser, page } = await open(BASE, "desktop", { theme });
      await gotoBottom(page);
      await cut(page);
      await shot(page, `${out}/after-bottom-${theme}.png`);
      if (theme === "daylight") {
        await page.screenshot({ path: `${out}/after-top-row.png`, clip: { x: 0, y: 0, width: 1280, height: 82 } });
        await tab(page, "DATA");
        await shot(page, `${out}/after-bottom-data.png`);
        await tab(page, "GUIDE");
        await shot(page, `${out}/after-bottom-guide.png`);
        await tab(page, "VIEWER");
        await page.waitForTimeout(800);

        await page.goto("/design/fins", { timeout: 120000 });
        await owned(page, '[role="tab"]');
        const toggle = page.locator("[data-fins-contour-toggle]");
        await toggle.waitFor({ timeout: 30000 });
        if ((await page.locator("[data-fin-plot] [data-fins-contour]").count()) === 0) await toggle.click();
        await page.locator("[data-fin-plot] [data-fins-contour]").first().waitFor({ timeout: 30000 });
        await page.waitForTimeout(1200);
        await shot(page, `${out}/after-fins.png`);

        await page.goto("/design/3d", { timeout: 120000 });
        await page.locator('[data-board-3d][data-board-state="ready"]').waitFor({ timeout: 90000 });
        await page.waitForTimeout(4000);
        await shot(page, `${out}/after-3d.png`);
        await page.getByRole("button", { name: "Bottom", exact: true }).click();
        await page.waitForTimeout(2500);
        await shot(page, `${out}/after-3d-bottom.png`);
        for (let i = 0; i < 2; i++) await page.getByRole("button", { name: "Zoom in", exact: true }).click();
        await page.waitForTimeout(2000);
        await shot(page, `${out}/after-3d-bottom-close.png`);
        await page.getByRole("button", { name: "Contour Stripes", exact: true }).click();
        await page.waitForTimeout(2000);
        await shot(page, `${out}/after-3d-bottom-stripes.png`);

        await page.goto("/design/summary", { timeout: 120000 });
        await page.locator("[data-order-form-sheet]").first().waitFor({ timeout: 120000 });
        await owned(page, "[data-order-form-root]");
        await page.waitForTimeout(2500);
        await shot(page, `${out}/after-summary.png`);
        await page.locator("[data-bottom-sheet]").waitFor({ timeout: 90000 });
        await page.waitForTimeout(800);
        // The printed page itself: the order form printed as the browser's print dialog would, backgrounds off.
        await page.pdf({ path: `${out}/_order-form.pdf`, format: "Letter", printBackground: false, margin: { top: "8mm", bottom: "8mm", left: "8mm", right: "8mm" } });
      }
      await browser.close();
      console.log("done desktop", theme);
    }
  },
  // The phone: the ☰ sheet's eight tiles, and BOTTOM itself upright.
  async iphone() {
    const { browser, page } = await open(BASE, "iphone");
    await gotoBottom(page);
    await cut(page);
    await phoneSection(page, "Center");
    await page.locator('[data-bottom-card="center"]').evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(600);
    await page.screenshot({ path: `${out}/after-phone-bottom.png` });
    await page.goto("/design/fins", { timeout: 120000 });
    await owned(page, 'header button[aria-label="Menu"]');
    await page.getByRole("banner").getByRole("button", { name: "Menu" }).click();
    await page.waitForTimeout(1200);
    await page.screenshot({ path: `${out}/after-phone-menu.png` });
    await browser.close();
  },
  // The same phone held sideways: BOTTOM in the computer layout, and the ☰ sheet's eight tiles in one row.
  async sideways() {
    const { browser, page } = await open(BASE, "iphone", { viewport: { width: 844, height: 390 } });
    await gotoBottom(page);
    await cut(page);
    await page.locator("main").evaluate((el) => (el.scrollTop = 0));
    await page.locator("[data-design-controls-scroll]").evaluate((el) => (el.scrollTop = 0));
    await page.waitForTimeout(600);
    await page.screenshot({ path: `${out}/after-phone-sideways-bottom.png` });
    await page.getByRole("banner").getByRole("button", { name: "Menu" }).click();
    await page.waitForTimeout(1200);
    await page.screenshot({ path: `${out}/after-phone-sideways-menu.png` });
    await browser.close();
  },
};
for (const [name, job] of Object.entries(jobs)) {
  if (only && only !== name) continue;
  await job();
  console.log("done", name);
}

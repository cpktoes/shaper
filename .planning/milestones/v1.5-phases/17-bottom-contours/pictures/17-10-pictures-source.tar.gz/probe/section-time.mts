// Where a drag's time goes on BOTTOM's section (17-10): the Longboard with three cuts and 8 channels.
import { DEFAULT_BOTTOM, resolveBottom, startingCut, startingChannels, foamOff, type BoardBottom } from "@/lib/geometry/bottom";
import { bottomSection, sectionGauges, sectionRuler, ghostRail, ghostRailPath } from "@/lib/geometry/bottom-draw";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { deriveEffectiveRails, designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { mm } from "@/lib/geometry/units";
import { boardSections } from "@/lib/geometry/volume";

const id = process.argv[2] ?? "longboard";
const preset = BOARD_PRESETS.find((p) => p.id === id)!;
const found = phase16Boards().find((b) => b.label === `${id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`)!;
const fields = found.fields;
const geometry = buildOutline(fields.outline);
const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
const bottom: BoardBottom = structuredClone(DEFAULT_BOTTOM);
bottom.nose = startingCut("nose", "Blended Nose Concave", board);
bottom.center = startingCut("center", "Early Double Concave", board);
bottom.tail = startingCut("tail", "Spiral Vee", board, "Spiral Vee");
bottom.channels = startingChannels(8, board, bottom.channels);
const resolved = resolveBottom(bottom, board);
const sections = boardSections(designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }));
const box = { width: 404, height: 160 };

function time(label: string, f: () => unknown, n = 40) {
  f();
  const t0 = performance.now();
  for (let i = 0; i < n; i++) f();
  console.log(label, ((performance.now() - t0) / n).toFixed(2), "ms");
}
const stations = Array.from({ length: 40 }, (_, i) => mm(board.length * (0.05 + 0.9 * (i / 39))));
let k = 0;
const next = () => stations[k++ % stations.length];
time("foamOff x1000", () => {
  for (let i = 0; i < 1000; i++) foamOff(resolved, board, mm(1000), mm(i / 5));
});
time("bottomSection live=null", () => bottomSection(resolved, board, next(), 4, box, { live: null }));
time("bottomSection live=channels", () => bottomSection(resolved, board, next(), 4, box, { live: "channels" }));
time("section+gauges", () => {
  const d = bottomSection(resolved, board, next(), 4, box, { live: "channels" });
  sectionGauges(d, resolved, board, "imperial");
});
time("section+gauges+ruler(big box)", () => {
  const d = bottomSection(resolved, board, next(), 4, { width: 804, height: 234 }, { live: "channels" });
  sectionGauges(d, resolved, board, "imperial");
  sectionRuler(d, resolved, board, "channels", "imperial", (t) => t.length * 6.2);
});
time("ghost", () => {
  const s = next();
  const d = bottomSection(resolved, board, s, 4, box, { live: null });
  const ring = ghostRail(sections, s);
  if (ring) ghostRailPath(ring, d);
});

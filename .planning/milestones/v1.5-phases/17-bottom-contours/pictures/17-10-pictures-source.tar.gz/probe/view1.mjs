// Probe 17-10's viewer on the worktree dev server (3310): section box widths, ruler, height labels.
import { chromium } from "@playwright/test";

const BASE = "http://localhost:3310";
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.addInitScript(() => {
  sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"); localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
});

async function openPreset(name) {
  await page.goto(BASE + "/");
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: "Start Shaping" }).first();
  for (let i = 0; i < 30; i++) {
    try {
      await card.click({ timeout: 3000 });
      await page.waitForURL(/\/design\/outline$/, { timeout: 5000 });
      break;
    } catch {}
  }
  await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
  await page.waitForURL(/\/design\/bottom$/);
  await page.locator("[data-bottom-cut-line]").first().waitFor({ state: "attached" });
}

async function pick(section, name) {
  const echo = page.locator(`[data-bottom-card="${section}"] [data-bottom-cut-echo]`);
  for (let i = 0; i < 20; i++) {
    try {
      await page.getByRole("combobox", { name: `${section[0].toUpperCase() + section.slice(1)} Cut` }).click({ timeout: 3000 });
      await page.getByRole("option", { name, exact: true }).click({ timeout: 3000 });
      if ((await echo.textContent()) === name) return;
    } catch {}
  }
  throw new Error("pick failed " + name);
}

async function state(label) {
  const box = await page.locator("[data-bottom-section]").boundingBox();
  const ruler = await page.locator("[data-bottom-ruler]").getAttribute("data-bottom-ruler").catch(() => null);
  const hl = await page.locator("[data-bottom-height-label]").textContent();
  const caption = await page.locator("[data-bottom-section]").getAttribute("aria-label");
  const cutAt = await page.locator("[data-bottom-cut-at]").getAttribute("data-bottom-cut-at");
  console.log(label, JSON.stringify({ w: box?.width, h: box?.height, ruler, hl, caption, cutAt }));
}

await openPreset(process.argv[2] ?? "Shortboard");
await state("open");
await pick("center", process.argv[3] ?? "Deep Single Concave");
await page.waitForTimeout(500);
await state("picked 1280");
for (const [w, h] of [[1024, 768], [1100, 800], [820, 800], [1280, 800]]) {
  await page.setViewportSize({ width: w, height: h });
  await page.waitForTimeout(600);
  await state(`${w}x${h}`);
}
for (const f of [1, 2, 8, 4]) {
  await page.getByRole("button", { name: `Height ×${f}` }).click();
  await page.waitForTimeout(300);
  await state(`height ${f}`);
}
await page.screenshot({ path: process.env.SHOT ?? "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/probe/view1.png" });
await browser.close();

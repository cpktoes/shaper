// UI E13's backstop (17-10): the Longboard with three cuts and 8 channels — the top view's SVG node count and bytes,
// and a thumb drag's frame rate on the Pixel 7 profile with the CPU throttled 4× through CDP.
import { chromium, devices } from "@playwright/test";

const BASE = "http://localhost:3310";
const browser = await chromium.launch();
const context = await browser.newContext({ ...devices["Pixel 7"] });
const page = await context.newPage();
await page.addInitScript(() => {
  sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
  localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
});

// Open the Longboard from the home page (a phone's card carries its litres), then BOTTOM through ☰.
await page.goto(BASE + "/");
const card = page.getByRole("button").filter({ hasText: "Longboard" }).filter({ hasText: /\d\.\d L/ }).first();
for (let i = 0; i < 30 && !/\/design\/outline$/.test(page.url()); i++) {
  try {
    await card.scrollIntoViewIfNeeded({ timeout: 2000 });
    await card.click({ timeout: 2000 });
    await page.waitForURL(/\/design\/outline$/, { timeout: 5000 });
  } catch {}
}
await page.goto(BASE + "/design/bottom"); // the open board is kept across a load (quick 261019-ep5)
await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 120000 });

async function pickFrom(name, option) {
  for (let i = 0; i < 20; i++) {
    try {
      const trigger = page.getByRole("combobox", { name, exact: true });
      await trigger.scrollIntoViewIfNeeded({ timeout: 2000 });
      await trigger.click({ timeout: 3000 });
      await page.getByRole("option", { name: option, exact: true }).click({ timeout: 3000 });
      return;
    } catch {}
  }
  throw new Error(`could not pick ${option}`);
}
const cuts = (process.env.CUTS ?? "Blended Nose Concave|Early Double Concave|Spiral Vee").split("|");
await pickFrom("Nose Cut", cuts[0]);
await pickFrom("Center Cut", cuts[1]);
await pickFrom("Tail Cut", cuts[2]);
await pickFrom("Channels", "8 channels");
await page.waitForTimeout(1500);

const size = await page.evaluate(() => {
  const svg = document.querySelector("[data-bottom-top-view-press]") ?? document.querySelector("[data-bottom-top-view]");
  const section = document.querySelector("[data-bottom-section]");
  return {
    topNodes: svg.querySelectorAll("*").length,
    topBytes: svg.outerHTML.length,
    shadePaths: svg.querySelectorAll("[data-bottom-shade] path").length,
    sectionNodes: section.querySelectorAll("*").length,
    sectionBytes: section.outerHTML.length,
  };
});
console.log("size", JSON.stringify(size));

const cdp = await context.newCDPSession(page);
// An experiment only: hide parts of the page to see what a drag step pays for.
if (process.env.HIDE) await page.addStyleTag({ content: `${process.env.HIDE} { display: none !important; }` });
await cdp.send("Emulation.setCPUThrottlingRate", { rate: Number(process.env.RATE ?? 4) });
const box = await page.locator("[data-bottom-top-view]").boundingBox();
const y = box.y + box.height * 0.45;
const x0 = box.x + box.width * 0.15;
const x1 = box.x + box.width * 0.85;

// Count frames the browser paints while the thumb sweeps the board back and forth for about four seconds.
await page.evaluate(() => {
  window.__frames = [];
  const tick = (t) => {
    window.__frames.push(t);
    window.__raf = requestAnimationFrame(tick);
  };
  window.__raf = requestAnimationFrame(tick);
  window.__moves = 0;
  window.__lastCut = null;
  window.__cutChanges = 0;
  new MutationObserver(() => {
    const at = document.querySelector("[data-bottom-cut-at]")?.getAttribute("data-bottom-cut-at");
    if (at !== window.__lastCut) {
      window.__lastCut = at;
      window.__cutChanges++;
    }
  }).observe(document.querySelector("[data-bottom-top-view-press]") ?? document.querySelector("[data-bottom-top-view]"), { attributes: true, subtree: true, attributeFilter: ["data-bottom-cut-at"] });
});
await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: x0, y }] });
const started = Date.now();
let moves = 0;
const STEPS = 40;
// A finger reports about 60 moves a second whatever the page is doing: each is sent on the clock, never waiting for the
// page to answer the one before, so the browser coalesces what it cannot keep up with — as it does for a real thumb.
const pending = [];
while (Date.now() - started < 4000) {
  const phase = (moves % (2 * STEPS)) / STEPS;
  const share = phase <= 1 ? phase : 2 - phase;
  pending.push(cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: x0 + (x1 - x0) * share, y }] }));
  moves++;
  await new Promise((r) => setTimeout(r, 16));
}
await Promise.all(pending);
await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
const elapsed = (Date.now() - started) / 1000;
const result = await page.evaluate(() => {
  cancelAnimationFrame(window.__raf);
  const f = window.__frames;
  const gaps = f.slice(1).map((t, i) => t - f[i]).sort((a, b) => a - b);
  return { frames: f.length, span: (f.at(-1) - f[0]) / 1000, cutChanges: window.__cutChanges, medianGap: gaps[Math.floor(gaps.length / 2)], p95Gap: gaps[Math.floor(gaps.length * 0.95)] };
});
console.log(
  "drag",
  JSON.stringify({
    rate: Number(process.env.RATE ?? 4),
    moves,
    seconds: elapsed,
    fps: +(result.frames / result.span).toFixed(1),
    sectionUpdatesPerSecond: +(result.cutChanges / elapsed).toFixed(1),
    movesPerSecond: +(moves / elapsed).toFixed(1),
    medianFrameMs: +result.medianGap.toFixed(1),
    p95FrameMs: +result.p95Gap.toFixed(1),
  }),
);
await cdp.send("Emulation.setCPUThrottlingRate", { rate: 1 });
if (process.env.SHOT) await page.screenshot({ path: process.env.SHOT });
await browser.close();

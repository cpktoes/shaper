// Composes 17-10's shots into one captioned picture for the founder, two columns so it stays under 8,000 pixels tall.
// Each shot was taken at deviceScaleFactor 2 and is shown at its true size on a computer screen (half its pixels).
// Usage: node compose.mjs <shots-dir> <out.png> <facts-json>
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const [SHOTS, OUT, FACTS] = process.argv.slice(2);
const facts = FACTS ? JSON.parse(readFileSync(FACTS, "utf8")) : {};
const img = (name) => `data:image/png;base64,${readFileSync(`${SHOTS}/${name}.png`).toString("base64")}`;
const box = (w) => (facts[`box${w}`] ? `${Math.round(facts[`box${w}`])}-dot` : "");

const LEFT = [
  ["01-screen-before-drag", 640, `1 · The Shortboard with a Deep Single Concave and six channels, 1280 × 800, CENTER live. The section opens at the cut's deepest; the ruler under it ticks the concave's edge off the stringer.`],
  ["02-viewer-after-drag", 640, `2 · The same board after a drag on the bottom from above: the cutting line followed the pointer toward the tail, the section is taken there (${facts.dragTo ?? ""}), and Section at moved with it. A tap jumps it; the arrow keys on Section at move it 1/2" a press.`],
  ["03-height-1", 640, "3 · Height ×1: TRUE HEIGHT — the concave is a hairline at the board's real proportions."],
  ["04-height-4", 640, "4 · Height ×4, where the page opens."],
  ["05-height-8-fitted", 640, `5 · Height ×8 with the Depth at 1/2": the cut would leave the box, so it is fitted and the drawing says the factor it used — ${facts.fitted ?? ""}.`],
  ["07-ghost", 640, "6 · Show the finished rail from RAILS, ticked: the rail RAILS bands, sitting on what the bottom left, in the faint ghost line. Off until ticked; never saved."],
];
const RIGHT = [
  ["06-ruler-1280", 560, `7a · The ruler at a 1280 window (section box ${box(1280)}): OFF THE STRINGER and the gauge words.`],
  ["06-ruler-1024", 450, `7b · At 1024 (box ${box(1024)}): the ruler with its values only, and the gauges as values (D-30).`],
  ["06-ruler-820", 360, `7c · At 820 (box ${box(820)}): no ruler — DATA's layout-marks table carries the marks.`],
  ["08-data-cut", 640, "8 · DATA with the Deep Single and six channels: the litres line, Depths under a straightedge, then Layout marks · off the stringer — Center edge, Wall 1, Wall 2, Wall 3, each wall — until its own channel starts — and the three notes."],
  ["09-data-flat", 640, "9 · DATA on a flat board: Foam off 0.00 L, nothing cut in the depths, no layout-marks table, two notes."],
  ["10-data-floor", 640, `10 · The floor in DATA: the Shortboard planed to 1 1/8" at the center on ROCKER (17-09 used 1 3/8", where no DATA row reaches the floor) and a Blended Nose Concave at 1/2". Each Stringer left cell held at 1/4" reads in warning ink (${facts.floorCells ?? "?"} rows), and the note under the tables is the panel's own sentence for that cut.`],
];
const WIDE = [["11-locked", 1100, "11 · BOTTOM on a locked board (the practice rack, board 1 locked from its ⋯): the Cut menus greyed and still; the tabs, Height (×8 here), Section at, the drag and the finished-rail tick (ticked here) all live. Unlock in the top bar brings the panel back."]];

const fig = ([name, width, caption]) =>
  `<figure style="width:${width}px"><img src="${img(name)}" data-name="${name}"><figcaption>${caption}</figcaption></figure>`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { margin: 0; padding: 28px 32px 36px; background: #f4f2ec; font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a33; width: 1400px; }
  h1 { font-size: 22px; margin: 0 0 4px; letter-spacing: 0.04em; }
  .sub { color: #5b6770; margin-bottom: 22px; max-width: 1300px; }
  .cols { display: flex; gap: 28px; align-items: flex-start; }
  .col { display: flex; flex-direction: column; gap: 24px; }
  figure { margin: 0; background: #fff; border: 1px solid #d9d4c7; border-radius: 8px; padding: 12px; box-sizing: content-box; }
  figure img { display: block; max-width: 100%; }
  figcaption { margin-top: 10px; color: #33414b; font-size: 13px; }
  .wide { margin-top: 24px; }
</style></head><body>
<h1>BOTTOM — the viewer follows you, and DATA lays the bottom out (plan 17-10)</h1>
<div class="sub">From the running app (this plan's own dev server), each shot at its true size on a computer. Every number is the app's own.</div>
<div class="cols"><div class="col">${LEFT.map(fig).join("")}</div><div class="col">${RIGHT.map(fig).join("")}</div></div>
<div class="wide">${WIDE.map(fig).join("")}</div>
</body></html>`;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1464, height: 1000 }, deviceScaleFactor: 1.45 });
await page.setContent(html);
await page.evaluate(async () => {
  const imgs = [...document.querySelectorAll("img")];
  await Promise.all(imgs.map((im) => (im.complete ? null : new Promise((r) => (im.onload = r)))));
});
const height = await page.evaluate(() => document.documentElement.scrollHeight);
await page.screenshot({ path: OUT, fullPage: true });
await browser.close();
console.log("composed", OUT, "height", height);

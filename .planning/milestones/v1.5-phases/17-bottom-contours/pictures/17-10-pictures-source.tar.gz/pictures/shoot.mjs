// 17-10's pictures for the founder: BOTTOM's viewer following the shaper, Height, the ruler, the finished rail, DATA's two
// tables and notes, and a locked board — from the worktree's own dev server (3310, never the founder's 3005), Chromium,
// deviceScaleFactor 2. Usage: node shoot.mjs <out-dir> [only-ids,comma,separated]
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";

const OUT = process.argv[2];
mkdirSync(OUT, { recursive: true });
const BASE = "http://localhost:3310";
const ONLY = process.argv[3];
const want = (n) => !ONLY || ONLY.split(",").includes(String(n));
const browser = await chromium.launch();

async function newPage({ width = 1280, height = 800, keepBoard = false } = {}) {
  const context = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 2 });
  await context.addInitScript((keep) => {
    sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
    if (!keep && !sessionStorage.getItem("keep-board")) localStorage.removeItem("shaper-open-board");
    // The stringer-form pictures: the kept board planed to 1 3/8" at the center (17-09's recipe), written as the page
    // loads — before the app reads its kept copy and after the page that left wrote its own.
    if (sessionStorage.getItem("thin-nose")) {
      const raw = JSON.parse(localStorage.getItem("shaper-open-board"));
      raw.snapshot.design.foil.center = 28.575; // 1 1/8" at the center
      localStorage.setItem("shaper-open-board", JSON.stringify(raw));
    }
  }, keepBoard);
  return context.newPage();
}

async function retry(fn, tries = 40) {
  let last;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  throw last;
}

async function openBottom(page, preset) {
  await page.goto(`${BASE}/`);
  const card = page.getByRole("button").filter({ hasText: "Start Shaping" }).filter({ hasText: preset }).first();
  await retry(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) await card.click({ timeout: 3000 });
    await page.waitForURL(/\/design\/outline$/, { timeout: 5000 });
  });
  await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
  await page.waitForURL("**/design/bottom");
  await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 60000 });
}

async function pickFrom(page, name, option) {
  const trigger = page.getByRole("combobox", { name, exact: true });
  const value = trigger.locator("[data-slot=select-value]");
  await retry(async () => {
    if ((await value.textContent()) === option) return;
    await trigger.click({ timeout: 3000 });
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2000 });
    await page.waitForTimeout(300);
    if ((await value.textContent()) !== option) throw new Error(`${name} not ${option}`);
  });
  await page.keyboard.press("Escape").catch(() => {});
  await page.waitForTimeout(300);
}

async function press(page, slider, key, times = 1) {
  const s = page.getByRole("slider", { name: slider, exact: true });
  await s.focus();
  for (let i = 0; i < times; i++) await page.keyboard.press(key);
  await page.waitForTimeout(200);
}

const viewerCard = (page) => page.locator("[data-bottom-live]");
const sectionBlock = (page) => page.locator("[data-bottom-section]").locator("xpath=../..");
async function shot(locator, name) {
  await locator.page().waitForTimeout(700);
  await locator.screenshot({ path: `${OUT}/${name}.png` });
  console.log("shot", name);
}
async function heightTo(page, factor) {
  await page.getByRole("button", { name: `Height ×${factor}`, exact: true }).click();
  await page.waitForTimeout(300);
}
const facts = {};

// 1 + 2: the Shortboard with a Deep Single and six channels — the cutting line before and after a drag.
if (want(1)) {
  const page = await newPage();
  await openBottom(page, "Shortboard");
  await pickFrom(page, "Center Cut", "Deep Single Concave");
  await pickFrom(page, "Channels", "6 channels");
  await page.locator('[data-bottom-card="center"] [data-bottom-cut-echo]').click();
  await page.waitForTimeout(500);
  await page.mouse.move(10, 10);
  await shot(page.locator("body"), "01-screen-before-drag");
  const box = await page.locator("[data-bottom-top-view]").boundingBox();
  const y = box.y + box.height * 0.45;
  const from = (await page.locator("[data-bottom-cut-line]").boundingBox()).x;
  const to = box.x + box.width * 0.78;
  await page.mouse.move(from, y);
  await page.mouse.down();
  await page.mouse.move(to, y, { steps: 12 });
  await page.mouse.up();
  await page.mouse.move(10, 10);
  facts.dragTo = await page.locator("[data-bottom-section]").getAttribute("aria-label");
  await shot(viewerCard(page), "02-viewer-after-drag");

  // Height ×1 and ×4 at the Deep Single's deepest: picked again, the section goes back there.
  await pickFrom(page, "Center Cut", "Flat Center");
  await pickFrom(page, "Center Cut", "Deep Single Concave");
  await page.mouse.move(5, 5);
  await heightTo(page, 1);
  await shot(sectionBlock(page), "03-height-1");
  await heightTo(page, 4);
  await shot(sectionBlock(page), "04-height-4");
  // the finished rail from RAILS
  await page.getByRole("checkbox", { name: "Show the finished rail from RAILS" }).click();
  await shot(sectionBlock(page), "07-ghost");
  await page.getByRole("checkbox", { name: "Show the finished rail from RAILS" }).click();
  // Depth to 1/2" and ×8: fitted
  await press(page, "Center Depth", "End");
  await heightTo(page, 8);
  await page.mouse.move(5, 5);
  facts.fitted = await page.locator("[data-bottom-height-label]").textContent();
  await shot(sectionBlock(page), "05-height-8-fitted");
  await page.context().close();
}

// 6: the ruler at 1280 (captioned), 1024 (bare) and 820 (none), the Deep Single live at its deepest.
if (want(6)) {
  for (const [w, h] of [[1280, 800], [1024, 768], [820, 800]]) {
    const page = await newPage({ width: w, height: h });
    await openBottom(page, "Shortboard");
    await pickFrom(page, "Channels", "6 channels");
    await pickFrom(page, "Center Cut", "Deep Single Concave");
    await page.mouse.move(5, 5);
    facts[`box${w}`] = (await page.locator("[data-bottom-section]").boundingBox()).width;
    await shot(sectionBlock(page), `06-ruler-${w}`);
    await page.context().close();
  }
}

// 8 + 9: DATA's two tables and notes (the Deep Single and six channels), and a flat board's DATA.
if (want(8)) {
  const page = await newPage({ height: 1500 });
  await openBottom(page, "Shortboard");
  await page.getByRole("tab", { name: "DATA", exact: true }).click();
  await page.locator("[data-bottom-notes]").waitFor();
  await shot(page.locator("[data-bottom-data]"), "09-data-flat");
  await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
  await pickFrom(page, "Center Cut", "Deep Single Concave");
  await pickFrom(page, "Channels", "6 channels");
  await page.getByRole("tab", { name: "DATA", exact: true }).click();
  await page.locator("[data-bottom-marks]").waitFor();
  await shot(page.locator("[data-bottom-data]"), "08-data-cut");
  await page.context().close();
}

// 10: the floor cells in warning ink — the Shortboard planed to 1 3/8" at the center, a Blended Nose Concave at 1/2".
if (want(10)) {
  const page = await newPage({ height: 1500, keepBoard: true });
  await openBottom(page, "Shortboard");
  await page.evaluate(() => {
    sessionStorage.setItem("keep-board", "1");
    sessionStorage.setItem("thin-nose", "1");
  });
  await page.reload();
  await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 60000 });
  await page.evaluate(() => sessionStorage.removeItem("thin-nose"));
  await pickFrom(page, "Nose Cut", "Blended Nose Concave");
  await press(page, "Nose Depth", "End");
  await page.locator('[data-bottom-card="nose"] [data-bottom-floor]').waitFor();
  await page.getByRole("tab", { name: "DATA", exact: true }).click();
  await page.locator("[data-bottom-notes]").waitFor();
  console.log("floor notes", JSON.stringify(await page.locator("[data-bottom-floor-note]").allTextContents()));
  console.log("stringer left", JSON.stringify(await page.locator("[data-bottom-depths] tbody tr").evaluateAll((trs) => trs.map((tr) => tr.textContent))));
  facts.floorCells = await page.locator("[data-bottom-floor-cell]").count();
  await shot(page.locator("[data-bottom-data]"), "10-data-floor");
  await page.context().close();
}

// 11: BOTTOM on a locked board (the practice rack: board 1 locked from its ⋯, opened, BOTTOM).
if (want(11)) {
  const page = await newPage({ height: 1000 });
  await page.goto(`${BASE}/test-rack?boards=3`);
  await page.locator("[data-rack-board]").first().waitFor();
  const first = page.locator("[data-rack-board]").first();
  const name = (await page.locator("[data-rack-board]").count()) > 0 ? null : null;
  await retry(async () => {
    await page.getByRole("button", { name: /^Board actions for / }).first().click({ timeout: 3000 });
    await page.getByRole("menuitemcheckbox", { name: "Lock Board" }).click({ timeout: 3000 });
  });
  await page.waitForTimeout(800);
  await retry(async () => {
    if (!/\/design\/outline$/.test(page.url())) await page.getByRole("button", { name: "Open This Board" }).first().click({ timeout: 3000 });
    await page.waitForURL(/\/design\/outline$/, { timeout: 5000 });
  });
  await page.getByRole("button", { name: "Unlock" }).first().waitFor({ timeout: 20000 });
  await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
  await page.waitForURL("**/design/bottom");
  await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 60000 });
  await page.getByRole("button", { name: "Height ×8", exact: true }).click();
  await page.getByRole("checkbox", { name: "Show the finished rail from RAILS" }).click();
  const box = await page.locator("[data-bottom-top-view]").boundingBox();
  await page.mouse.click(box.x + box.width * 0.7, box.y + box.height * 0.45);
  await page.mouse.move(5, 5);
  void first;
  void name;
  await shot(page.locator("body"), "11-locked");
  await page.context().close();
}

console.log("facts", JSON.stringify(facts));
await browser.close();

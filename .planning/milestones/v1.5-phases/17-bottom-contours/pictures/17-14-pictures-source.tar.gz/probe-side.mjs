// A phone held sideways: what BOTTOM's three tabs measure. node probe-side.mjs <profile> <w> <h> [shotprefix]
import { open, gotoBottom, pickFrom, phoneSection, tab } from "./lib.mjs";

const which = process.argv[2] ?? "iphone";
const viewport = { width: Number(process.argv[3]), height: Number(process.argv[4]) };
const shot = process.argv[5];
const { browser, page } = await open(which, { viewport });
await gotoBottom(page);
await phoneSection(page, "Tail");
await pickFrom(page, "Center Cut", "Deep Single Concave");
await pickFrom(page, "Tail Cut", "Spiral Vee");
await pickFrom(page, "Channels", "6 channels");

const read = (what) =>
  page.evaluate((what) => {
    const r = (el) => {
      if (!el) return null;
      const b = el.getBoundingClientRect();
      return { x: +b.x.toFixed(1), y: +b.y.toFixed(1), w: +b.width.toFixed(1), h: +b.height.toFixed(1) };
    };
    const main = document.querySelector("main");
    const card = document.querySelector("[data-viewer-panel]");
    const header = [...document.querySelectorAll("header")].find((h) => h.getBoundingClientRect().height > 0);
    const inner = what === "data" ? document.querySelector("[data-bottom-data]") : what === "guide" ? document.querySelector("[data-bottom-guide]") : null;
    const cs = getComputedStyle(card);
    return {
      what,
      screen: [innerWidth, innerHeight],
      bar: r(header),
      main: { ...r(main), sh: main.scrollHeight, ch: main.clientHeight, ov: getComputedStyle(main).overflowY },
      card: { ...r(card), contentW: card.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) },
      live: r(document.querySelector("[data-bottom-live]")),
      top: r(document.querySelector("[data-bottom-top-view]")),
      section: r(document.querySelector("[data-bottom-section]")),
      label: r(document.querySelector("[data-bottom-height-label]")),
      sectionAt: r(document.querySelector("[data-bottom-section-at]")),
      inner: inner ? { ...r(inner), sh: inner.scrollHeight, ch: inner.clientHeight } : null,
      controls: r(document.querySelector("[data-design-controls-scroll]")),
      row: r(document.querySelector("[data-bottom-phone-sections]")),
      heights: [...document.querySelectorAll("[data-bottom-height] button")].map((b) => {
        const a = getComputedStyle(b, "::after");
        const d = b.getBoundingClientRect();
        return `${b.textContent.trim()} ${d.width.toFixed(1)}x${d.height.toFixed(1)} @${d.left.toFixed(1)} touch ${a.width}x${a.height}`;
      }),
      doc: [document.documentElement.scrollWidth, document.documentElement.scrollHeight],
    };
  }, what);

console.log(JSON.stringify(await read("viewer")));
if (shot) await page.screenshot({ path: `${shot}-viewer.png` });
await tab(page, "DATA");
console.log(JSON.stringify(await read("data")));
if (shot) await page.screenshot({ path: `${shot}-data.png` });
await tab(page, "GUIDE");
console.log(JSON.stringify(await read("guide")));
if (shot) await page.screenshot({ path: `${shot}-guide.png` });
await browser.close();

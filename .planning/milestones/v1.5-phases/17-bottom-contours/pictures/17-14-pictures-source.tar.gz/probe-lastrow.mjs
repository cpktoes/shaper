// Scratch: where DATA's last row lands on a sideways phone once the column is scrolled to its end.
// node probe-lastrow.mjs <profile> <w> <h>
import { open, gotoBottom, pickFrom, tab } from "./lib.mjs";

const [profile, w, h] = process.argv.slice(2);
const { browser, page } = await open(profile, { viewport: { width: +w, height: +h } });
await gotoBottom(page);
await pickFrom(page, "Center Cut", "Deep Single Concave");
await pickFrom(page, "Tail Cut", "Spiral Vee");
await pickFrom(page, "Channels", "6 channels");
await tab(page, "DATA");
await page.waitForTimeout(800);
for (const wait of [0, 300, 1500]) {
  const read = await page.evaluate(() => {
    const main = document.querySelector("main");
    main.scrollTop = main.scrollHeight;
    const r = (el) => {
      const b = el.getBoundingClientRect();
      return { l: Math.round(b.left), t: +b.top.toFixed(1), r: Math.round(b.right), b: +b.bottom.toFixed(1), h: +b.height.toFixed(1) };
    };
    const row = [...document.querySelectorAll("[data-bottom-marks] tbody tr")].at(-1);
    const cell = row.querySelector("th, td");
    return {
      screen: [innerWidth, innerHeight],
      doc: [document.documentElement.scrollHeight, document.documentElement.clientHeight, scrollY],
      main: { ...r(main), scrollTop: main.scrollTop, holds: main.scrollHeight, shows: main.clientHeight, padB: getComputedStyle(main).paddingBottom },
      cell: r(cell),
      cellText: cell.textContent,
      box: r(document.querySelector("[data-bottom-marks]").parentElement.parentElement),
      notes: r(document.querySelector("[data-bottom-notes]")),
      card: r(document.querySelector("[data-viewer-panel]")),
    };
  });
  console.log(wait, JSON.stringify(read));
  await page.waitForTimeout(wait || 1);
}
await browser.close();

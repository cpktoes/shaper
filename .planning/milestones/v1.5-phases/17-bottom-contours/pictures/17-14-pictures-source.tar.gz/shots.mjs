// The founder's-look pictures for 17-14: BOTTOM on phones, from the running page on port 3314, at twice life size.
// node shots.mjs <outdir> [only]
import { open, gotoBottom, pickFrom, tab, phoneSection, retry } from "./lib.mjs";

const out = process.argv[2];
const only = process.argv[3];

async function cutBoard(page, channels) {
  await phoneSection(page, "Center");
  await pickFrom(page, "Center Cut", "Deep Single Concave");
  await phoneSection(page, "Tail");
  await pickFrom(page, "Tail Cut", "Spiral Vee");
  await pickFrom(page, "Channels", `${channels} channels`);
}

const settle = (page) => page.waitForTimeout(500);

async function upright(profile) {
  const { browser, page } = await open(profile);
  await gotoBottom(page);
  await cutBoard(page, 6);

  await phoneSection(page, "Center");
  await page.locator('[data-bottom-card="center"]').evaluate((el) => el.scrollIntoView({ block: "start" }));
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-1-viewer-center.png` });

  await phoneSection(page, "Tail");
  await page.locator("[data-bottom-channels]").evaluate((el) => el.scrollIntoView({ block: "start" }));
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-2-viewer-tail-channels.png` });

  await tab(page, "DATA");
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-3-data.png` });

  await tab(page, "GUIDE");
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-5-guide.png` });

  // Eight channels, and DATA's layout marks pulled sideways to their last column.
  await tab(page, "VIEWER");
  await phoneSection(page, "Tail");
  await pickFrom(page, "Channels", "8 channels");
  await tab(page, "DATA");
  await page.locator("[data-bottom-marks]").evaluate((el) => {
    el.scrollIntoView({ block: "start" });
    const data = el.closest("[data-bottom-data]");
    data.scrollTop -= 34;
    const box = el.parentElement.parentElement;
    box.scrollLeft = Math.round((box.scrollWidth - box.clientWidth) * 0.6);
  });
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-4-data-marks.png` });
  await browser.close();
}

async function sideways(profile, viewport) {
  const { browser, page } = await open(profile, { viewport });
  await gotoBottom(page);
  await cutBoard(page, 6);
  await page.locator("main").evaluate((el) => (el.scrollTop = 0));
  await page.locator("[data-design-controls-scroll]").evaluate((el) => (el.scrollTop = 0));
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-6-sideways.png` });
  await page.locator("[data-bottom-channels]").evaluate((el) => el.scrollIntoView({ block: "start" }));
  await page.locator("main").evaluate((el) => (el.scrollTop = el.scrollHeight));
  await settle(page);
  await page.screenshot({ path: `${out}/${profile}-7-sideways-scrolled.png` });
  await browser.close();
}

/** One upright iPhone with every touch box outlined: the Selects, the tick row, the Height buttons and both tab rows. */
async function touch() {
  const { browser, page } = await open("iphone");
  await gotoBottom(page);
  await phoneSection(page, "Nose");
  await pickFrom(page, "Nose Cut", "Teardrop Nose Concave");
  await page.addStyleTag({
    content: `
      [role="tab"]::after, [data-bottom-height] button::after { outline: 1.5px solid #e11d48; outline-offset: -1px; background: rgba(225, 29, 72, 0.08); }
      [data-design-controls-scroll] [role="combobox"], [data-design-controls-scroll] label:has([data-slot="checkbox"]) { outline: 1.5px solid #e11d48; outline-offset: -1px; }
      [data-slot="slider-thumb"]::after { outline: 1.5px solid #2563eb; outline-offset: -1px; }
    `,
  });
  await retry(async () => {
    await page.getByRole("checkbox").first().scrollIntoViewIfNeeded({ timeout: 3000 });
  });
  await page.locator('[data-bottom-card="nose"]').evaluate((el) => el.scrollIntoView({ block: "start" }));
  await settle(page);
  await page.screenshot({ path: `${out}/touch-1-top.png` });
  const tick = page.locator('[data-design-controls-scroll] label:has([data-slot="checkbox"])').last();
  await tick.evaluate((el) => el.scrollIntoView({ block: "center" }));
  await settle(page);
  await page.screenshot({ path: `${out}/touch-2-tick.png` });
  await browser.close();
}

const jobs = {
  iphone: () => upright("iphone"),
  android: () => upright("android"),
  "iphone-sideways": () => sideways("iphone", { width: 844, height: 390 }),
  "android-sideways": () => sideways("android", { width: 863, height: 360 }),
  touch,
};
for (const [name, job] of Object.entries(jobs)) {
  if (only && only !== name) continue;
  await job();
  console.log("done", name);
}

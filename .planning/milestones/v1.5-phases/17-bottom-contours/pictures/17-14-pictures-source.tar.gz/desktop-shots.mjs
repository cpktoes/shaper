import { open, gotoBottom, pickFrom, tab } from "./lib.mjs";

/** BOTTOM on a computer at 1280 x 800: the same six pictures before and after the change, for a dot-by-dot compare. */
const out = process.argv[2];
if (!out) throw new Error("usage: desktop-shots.mjs <folder>");
const { browser, page } = await open("desktop", { scale: 1 });
const shot = async (name) => {
  await page.mouse.move(640, 2);
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${out}/${name}.png`, animations: "disabled", caret: "hide" });
};

await gotoBottom(page);
await shot("1-viewer-flat");
await pickFrom(page, "Center Cut", "Deep Single Concave");
await pickFrom(page, "Tail Cut", "Spiral Vee");
await pickFrom(page, "Channels", "6 channels");
await shot("2-viewer-cut");
await tab(page, "DATA");
await shot("3-data");
const data = await page.evaluate(() => {
  const root = document.querySelector("[data-bottom-data]");
  return {
    root: { h: root.clientHeight, sh: root.scrollHeight },
    kids: [...root.children].map((el) => ({ tag: el.tagName, h: Math.round(el.getBoundingClientRect().height), sh: el.scrollHeight })),
  };
});
console.log("DATA on a computer:", JSON.stringify(data));
await page.locator("[data-bottom-data]").evaluate((el) => el.scrollTo(0, el.scrollHeight));
await shot("4-data-end");
await tab(page, "GUIDE");
await shot("5-guide");
await tab(page, "VIEWER");
await page.locator("[data-design-controls-scroll]").evaluate((el) => el.scrollTo(0, el.scrollHeight));
await shot("6-viewer-controls-end");
await browser.close();

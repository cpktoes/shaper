import { defineConfig, devices } from "@playwright/test";
import repo from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5c3348348b0c6dd8/playwright.config";

// Scratch config for 17-13's pictures: the worktree's own dev server on PW_PORT (3313), started and stopped by this
// run exactly as the project's suite starts it. Two times the dots so the words are sharp.
const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5c3348348b0c6dd8";
const port = Number(process.env.PW_PORT ?? 3313);
const server = repo.webServer as { command: string; url: string; timeout: number; env: Record<string, string> };

export default defineConfig({
  testDir: ".",
  testMatch: /\.pictures\.spec\.ts$/,
  timeout: 420_000,
  workers: 1,
  reporter: "list",
  webServer: { ...server, cwd: WORKTREE, reuseExistingServer: true },
  use: { baseURL: `http://localhost:${port}`, actionTimeout: 30_000 },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 } },
    { name: "android", use: { ...devices["Pixel 7"], deviceScaleFactor: 2 } },
  ],
});

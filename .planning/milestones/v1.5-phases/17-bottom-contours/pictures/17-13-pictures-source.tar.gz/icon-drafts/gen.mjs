// Scratch: draws candidate "depth contour" icons for FINS' Bottom Contours button and renders them at the
// button's real size and enlarged, so the choice is made by looking, not by guessing.
// Run: node gen.mjs <out.png>
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { writeFileSync } from "node:fs";
import { chromium } from "playwright";

const here = dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] ?? join(here, "icons.png");

const r1 = (n) => {
  const s = (Math.round(n * 10) / 10).toFixed(1);
  return s.endsWith(".0") ? s.slice(0, -2) : s;
};

/** A closed, smooth ring: radius varies with the angle by a few harmonics; drawn through `n` points. */
function ring({ cx, cy, r, h = [], n = 8, rot = 0, pts: given }) {
  const pts = given ? given.map((p) => [...p]) : [];
  if (given) n = given.length;
  for (let i = 0; !given && i < n; i++) {
    const t = rot + (i / n) * Math.PI * 2;
    let rr = r;
    for (const [k, amp, phase] of h) rr += r * amp * Math.cos(k * t - phase);
    pts.push([cx + rr * Math.cos(t), cy + rr * Math.sin(t)]);
  }
  const at = (i) => pts[((i % n) + n) % n];
  let d = `M${r1(pts[0][0])} ${r1(pts[0][1])}`;
  for (let i = 0; i < n; i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += `C${r1(c1[0])} ${r1(c1[1])} ${r1(c2[0])} ${r1(c2[1])} ${r1(p2[0])} ${r1(p2[1])}`;
  }
  const samples = [];
  for (let i = 0; i < n; i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    for (let k = 0; k < 24; k++) {
      const t = k / 24, u = 1 - t;
      samples.push([0, 1].map((j) => u * u * u * p1[j] + 3 * u * u * t * c1[j] + 3 * u * t * t * c2[j] + t * t * t * p2[j]));
    }
  }
  const xs = samples.map((p) => p[0]), ys = samples.map((p) => p[1]);
  return { d: d + "Z", samples, box: [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)].map((v) => +v.toFixed(2)) };
}

import { readFileSync } from "node:fs";
const candidates = process.argv[3] ? JSON.parse(readFileSync(process.argv[3], "utf8")) : [
  {
    name: "A three rings, w2",
    width: 2,
    rings: [
      { cx: 12, cy: 12, r: 9.3, h: [[2, 0.07, 0.6], [3, 0.05, 2.0]] },
      { cx: 12.6, cy: 12.3, r: 5.5, h: [[2, 0.1, 1.2], [3, 0.06, 0.4]] },
      { cx: 13.2, cy: 12.6, r: 1.9, h: [[2, 0.18, 0.9]] },
    ],
  },
  {
    name: "B bolder wobble, w2",
    width: 2,
    rings: [
      { cx: 12, cy: 12, r: 9.1, h: [[2, 0.09, 0.4], [3, 0.08, 2.4]] },
      { cx: 12.9, cy: 12.5, r: 5.3, h: [[2, 0.14, 1.0], [3, 0.08, 0.2]] },
      { cx: 13.7, cy: 13, r: 1.8, h: [[2, 0.25, 0.7]] },
    ],
  },
  {
    name: "C three rings, w1.5",
    width: 1.5,
    rings: [
      { cx: 12, cy: 12, r: 9.4, h: [[2, 0.09, 0.4], [3, 0.08, 2.4]] },
      { cx: 12.9, cy: 12.5, r: 5.8, h: [[2, 0.14, 1.0], [3, 0.08, 0.2]] },
      { cx: 13.7, cy: 13, r: 2.3, h: [[2, 0.25, 0.7]] },
    ],
  },
  {
    name: "D two rings + mark, w2",
    width: 2,
    rings: [
      { cx: 12, cy: 12, r: 9.1, h: [[2, 0.09, 0.4], [3, 0.08, 2.4]] },
      { cx: 12.9, cy: 12.5, r: 5, h: [[2, 0.16, 1.0], [3, 0.08, 0.2]] },
    ],
    extra: "M12.2 12.2 14 13.2",
  },
];

const svgOf = (c, px) => {
  const paths = c.rings.map((spec) => ring(spec));
  const body = paths.map((p) => `<path d="${p.d}"/>`).join("") + (c.extra ? `<path d="${c.extra}"/>` : "");
  return {
    svg: `<svg viewBox="0 0 24 24" width="${px}" height="${px}" fill="none" stroke="currentColor" stroke-width="${c.width}" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`,
    paths,
  };
};

const ruler = (px) =>
  `<svg viewBox="0 0 24 24" width="${px}" height="${px}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 15v-3"/><path d="M14 15v-3"/><path d="M18 15v-3"/><path d="M2 8V4"/><path d="M22 6H2"/><path d="M22 8V4"/><path d="M6 15v-3"/><rect x="2" y="12" width="20" height="8" rx="2"/></svg>`;

let rows = "";
for (const c of candidates) {
  const small = svgOf(c, 24);
  const big = svgOf(c, 168);
  console.log(c.name);
  for (const p of small.paths) console.log("  ", p.d, " box", p.box.join(" "));
  if (c.extra) console.log("  ", c.extra);
  for (let i = 1; i < small.paths.length; i++) {
    let lo = Infinity, hi = 0;
    for (const a of small.paths[i].samples) {
      let near = Infinity;
      for (const b of small.paths[i - 1].samples) near = Math.min(near, Math.hypot(a[0] - b[0], a[1] - b[1]));
      lo = Math.min(lo, near); hi = Math.max(hi, near);
    }
    console.log(`   ring ${i} to ring ${i + 1}: centre lines ${lo.toFixed(2)} to ${hi.toFixed(2)} apart; clear ${(lo - c.width).toFixed(2)} to ${(hi - c.width).toFixed(2)}`);
  }
  rows += `<div class="row"><div class="name">${c.name}</div>
    <div class="pair"><span class="btn">${small.svg}</span><span class="btn">${ruler(24)}</span></div>
    <div class="pair"><span class="btn on">${small.svg}</span><span class="btn on">${ruler(24)}</span></div>
    <div class="big">${big.svg}</div><div class="big on">${big.svg}</div></div>`;
}

const html = `<!doctype html><meta charset="utf-8"><style>
body{margin:16px;font:13px -apple-system,Helvetica,Arial,sans-serif;background:#f3f1ea;color:#1f2937}
.row{display:flex;align-items:center;gap:22px;margin-bottom:18px}
.name{width:170px}
.pair{display:flex;gap:6px;background:#fff;padding:10px;border-radius:8px}
.btn{display:flex;box-sizing:border-box;width:34px;height:34px;padding:4px;border:1px solid #8a7a52;border-radius:6px;background:#fff;color:#4b5563}
.btn.on{background:#8fc1b5;color:#1f2937}
.big{display:flex;padding:6px;border:1px solid #8a7a52;border-radius:10px;background:#fff;color:#4b5563}
.big.on{background:#8fc1b5;color:#1f2937}
</style>${rows}`;
writeFileSync(join(here, "icons.html"), html);

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 760, height: 200 }, deviceScaleFactor: 2 });
await page.setContent(html);
await page.screenshot({ path: out, fullPage: true });
await browser.close();
console.log("saved", out);

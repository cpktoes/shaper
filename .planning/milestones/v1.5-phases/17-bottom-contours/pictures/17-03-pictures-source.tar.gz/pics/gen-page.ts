/* 17-03's picture: the litres flat and with this wave's cuts on the four presets and the winged Fish, beside the
   sketch's own figures from the golden; the mesh against the litres; and each board's finished section at the wide
   point and 12" from the tail, flat and bottomed (Height x4). Every figure is computed here by the app's own code.
   Run from the worktree root:
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <out.html>                                            */
import { writeFileSync } from "node:fs";
import golden from "@/lib/geometry/__fixtures__/bottom-golden.json";
import pin from "@/lib/geometry/__fixtures__/phase17-litres-pin.json";
import { phase16Boards, phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { buildBoardSurface, enclosedVolumeMm3, meshCheck } from "@/lib/geometry/board-surface";
import { BOTTOM_SECTIONS, DEFAULT_BOTTOM, bottomLitresLine, startingCut, type BoardBottom, type BottomCutName, type BottomSectionKey } from "@/lib/geometry/bottom";
import { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES, summarizeDesign, type DesignSummaryFields } from "@/lib/geometry/design";
import { sampledFinishedRail } from "@/lib/geometry/finished-rail";
import { frontFinStation } from "@/lib/geometry/fins";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { formatInchesFraction, inchesToMm, litres, mm, mmToInches, type Mm } from "@/lib/geometry/units";
import { boardSections, computeCrossSectionVolume, type BoardSection } from "@/lib/geometry/volume";
import { cncFiles } from "@/lib/export/cnc-files";

const out = process.argv[2];
const t0 = Date.now();
const all = phase16Boards();
const presets = BOARD_PRESETS.map((preset) => ({ id: preset.id, name: preset.name, fields: all.find((b) => b.label === `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`)!.fields }));
const fish = presets.find((p) => p.id === "fish")!;
const wing = { station: mm(frontFinStation(designFinPlacement(fish.fields)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
const boards = [...presets, { id: "fishwing", name: "Fish, winged", fields: { ...fish.fields, outline: { ...fish.fields.outline, wings: [wing] } } }];

const CUTS: Record<string, Partial<Record<BottomSectionKey, string>>> = {
  shortboard: { center: "Deep Single Concave" },
  fish: { tail: "Panel Vee" },
  fishwing: { tail: "Extending Single Concave" },
  midlength: { nose: "Rolled Belly Entry", center: "Shallow Single Concave", tail: "Rolled Vee" },
  longboard: { nose: "Rolled Belly Entry", center: "Shallow Single Concave", tail: "Rolled Vee" },
};

function parts(fields: DesignSummaryFields) {
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  return { geometry, profile, rails, board };
}
function bottomOf(fields: DesignSummaryFields, names: Partial<Record<BottomSectionKey, string>>, depth?: Mm): BoardBottom {
  const { board } = parts(fields);
  const bottom = structuredClone(DEFAULT_BOTTOM);
  for (const s of BOTTOM_SECTIONS) if (names[s]) { bottom[s] = startingCut(s, names[s] as BottomCutName, board); if (depth !== undefined) bottom[s].depth = depth; }
  return bottom;
}
const goldenCut = (id: string, name: string) => (golden.cases as any[]).find((c) => c.kind === "cut" && c.board === id && c.name === name)!.litresOff as number;

// the pin, three ways (the test's own check, re-run here for the table)
let pinned = 0;
for (const b of phase16SurfaceBoards()) {
  const want = (pin as any).litres[b.label];
  if ([undefined, DEFAULT_BOTTOM].every((bottom) => summarizeDesign({ ...b.fields, bottom }).volumeLitres.toPrecision(17) === want)) pinned++;
}

type Row = { name: string; cuts: string; flat: number; now: number; line: ReturnType<typeof bottomLitresLine>; sketch: number; meshGap: number; closed: boolean; ms: number };
const rows: Row[] = [];
const sectionPanels: string[] = [];
const W = 330;

function halfOf(s: BoardSection) { return s.result ? (s.drawn ?? s.blended ?? sampledFinishedRail(s.result, s.domed, s.halfWidth)) : null; }
function panel(title: string, flatS: BoardSection, cutS: BoardSection, maxHalf: number) {
  const fh = halfOf(flatS)!, ch = halfOf(cutS)!;
  const k = (W / 2 - 12) / maxHalf, v = 4 * k; // Height x4
  const H = Math.ceil(flatS.thickness * v) + 22;
  const base = H - 10;
  const path = (half: [number, number][]) => {
    const right = half.map(([y, h]) => `${(W / 2 + y * k).toFixed(2)},${(base - h * v).toFixed(2)}`);
    const left = [...half].reverse().map(([y, h]) => `${(W / 2 - y * k).toFixed(2)},${(base - h * v).toFixed(2)}`);
    return `M${right.join("L")}L${left.join("L")}Z`;
  };
  const thin = cutS.thinAt?.length ?? 0;
  const edge = cutS.railEdgeAt;
  return `<figure><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <path d="${path(fh)}" fill="#e8e3d8" stroke="#9a948a" stroke-width="1"/>
    <path d="${path(ch)}" fill="#cfe0ea" stroke="#1d4f6e" stroke-width="1.3"/>
    <line x1="4" x2="${W - 4}" y1="${base}" y2="${base}" stroke="#333" stroke-dasharray="5 4" stroke-width="1"/>
    <line x1="${W / 2}" x2="${W / 2}" y1="6" y2="${base + 6}" stroke="#bbb" stroke-width="0.6"/>
  </svg><figcaption>${title} · thickness ${formatInchesFraction(flatS.thickness)} · section area ${(100 * (1 - cutS.area / flatS.area)).toFixed(1)}% less${edge !== undefined ? ` · the lift meets the deck: the rail ends ${mmToInches(mm(flatS.halfWidth - edge)) < 1 / 32 ? "under 1/16\"" : formatInchesFraction(mm(flatS.halfWidth - edge))} in from where it was` : thin ? ` · rail under 1/4" (flagged)` : ""}</figcaption></figure>`;
}

for (const b of boards) {
  const names = CUTS[b.id];
  const bottom = bottomOf(b.fields, names);
  const flatL = summarizeDesign(b.fields).volumeLitres;
  const nowL = summarizeDesign({ ...b.fields, bottom }).volumeLitres;
  const { geometry, profile, rails, board } = parts(b.fields);
  const input = designCrossSectionInput(geometry, profile, rails, b.fields.outline.length, { bottom, board });
  const flatInput = designCrossSectionInput(geometry, profile, rails, b.fields.outline.length);
  const s0 = Date.now();
  const surface = buildBoardSurface({ sections: input, geometry, rockerAt: profile.rockerAt });
  const ms = Date.now() - s0;
  cncFiles(surface, b.name);
  const litresCut = computeCrossSectionVolume(input).volumeLitres;
  const check = meshCheck(surface);
  rows.push({
    name: b.name,
    cuts: BOTTOM_SECTIONS.filter((s) => names[s]).map((s) => names[s]).join(" · "),
    flat: flatL, now: nowL, line: bottomLitresLine(nowL, flatL),
    sketch: BOTTOM_SECTIONS.filter((s) => names[s]).reduce((sum, s) => sum + goldenCut(b.id, names[s]!), 0),
    meshGap: (enclosedVolumeMm3(surface) / 1e6 - litresCut) / litresCut,
    closed: Object.values(check).every((n) => n === 0), ms,
  });
  const stations = [geometry.widePointStation, inchesToMm(12)];
  const [fw, f12] = boardSections(flatInput, stations);
  const [cw, c12] = boardSections(input, stations);
  const maxHalf = fw.halfWidth;
  sectionPanels.push(`<div class="board"><h3>${b.name} — ${rows[rows.length - 1].cuts}</h3><div class="pair">${panel(`wide point (${formatInchesFraction(geometry.widePointStation, 8)} from the tail)`, fw, cw, maxHalf)}${panel(`12" from the tail`, f12, c12, maxHalf)}</div></div>`);
}

// the floor at a thin tip (D-33): the Shortboard with a Rolled Vee and a Rolled Belly Entry at full depth (1/2")
const sb = boards.find((b) => b.id === "shortboard")!;
{
  const { geometry, profile, rails, board } = parts(sb.fields);
  const deep = bottomOf(sb.fields, { nose: "Rolled Belly Entry", tail: "Rolled Vee" }, inchesToMm(1 / 2));
  const input = designCrossSectionInput(geometry, profile, rails, sb.fields.outline.length, { bottom: deep, board });
  const flatInput = designCrossSectionInput(geometry, profile, rails, sb.fields.outline.length);
  const L = sb.fields.outline.length;
  const st = [inchesToMm(3), mm(L - inchesToMm(6)), inchesToMm(1.5), mm(L - inchesToMm(4))];
  const [ft, fn, ft2, fn2] = boardSections(flatInput, st);
  const [ct, cn, ct2, cn2] = boardSections(input, st);
  sectionPanels.push(`<div class="board"><h3>At a thin tip (D-40) — Shortboard, Rolled Belly Entry and Rolled Vee both at 1/2": the lifted, thinned rail, no lip</h3><div class="pair">${panel(`3" from the tail`, ft, ct, ft.halfWidth)}${panel(`6" from the nose`, fn, cn, fn.halfWidth)}</div><div class="pair">${panel(`1 1/2" from the tail`, ft2, ct2, ft2.halfWidth)}${panel(`4" from the nose`, fn2, cn2, fn2.halfWidth)}</div></div>`);
}

const f2 = (x: number) => x.toFixed(2);
const html = `<!doctype html><meta charset="utf-8"><style>
body{font:13px/1.35 -apple-system,Helvetica,Arial,sans-serif;color:#222;margin:18px;width:760px}
h1{font-size:17px;margin:0 0 4px} h2{font-size:14px;margin:16px 0 6px} h3{font-size:12.5px;margin:10px 0 2px}
table{border-collapse:collapse;width:100%} td,th{border:1px solid #ccc;padding:3px 5px;text-align:right} th{background:#f3f1ec} td:first-child,td:nth-child(2),th:first-child,th:nth-child(2){text-align:left}
.pair{display:flex;gap:10px} figure{margin:0} figcaption{font-size:11px;color:#555;width:${W}px}
.key span{display:inline-block;width:14px;height:9px;margin:0 4px 0 10px;vertical-align:middle}
.note{font-size:11.5px;color:#444}
</style>
<h1>17-03 — the bottom in the litres, the 3D board and the CNC files (with D-40: no lip, the rail thinned)</h1>
<p class="note">Every flat board unchanged: ${pinned} of 102 pinned boards read their pinned litres to the last digit (no bottom, and the default flat bottom). No preset card moves — the presets stay flat.</p>
<h2>Litres with this wave's cuts (starting numbers), and the 3D board</h2>
<table><tr><th>Board</th><th>Cuts</th><th>Litres flat</th><th>With the cuts</th><th>Foam off (DATA's line)</th><th>Sketch's slab figure</th><th>App ÷ sketch</th><th>3D mesh vs litres</th><th>STL closed</th></tr>
${rows.map((r) => `<tr><td>${r.name}</td><td>${r.cuts}</td><td>${r.line.before}</td><td>${r.line.now}</td><td>${r.line.foamOff} L</td><td>${f2(r.sketch)} L</td><td>${((r.flat - r.now) / r.sketch).toFixed(3)}</td><td>${(100 * r.meshGap).toFixed(3)}%</td><td>${r.closed ? "yes" : "NO"}</td></tr>`).join("")}
</table>
<p class="note">"Sketch's slab figure" is sketch 021's own integral from the golden fixture (for three cuts, the sum of each alone). The app counts the finished board: a vee or belly lifts and thins the rail it runs out to (D-40), and near a rounded rail takes less than the sketch's slab. Mesh vs litres must lie in (−0.15%, 0].</p>
<h2>Sections, flat and bottomed (Height ×4)</h2>
<p class="key"><span style="background:#e8e3d8;border:1px solid #9a948a"></span>flat, as planed<span style="background:#cfe0ea;border:1px solid #1d4f6e"></span>bottomed<span style="border-top:1px dashed #333;height:0"></span>the planed bottom, a straightedge</p>
${sectionPanels.join("\n")}
`;
writeFileSync(out, html);
console.log(JSON.stringify(rows.map((r) => ({ ...r, line: r.line })), null, 1));
console.log("pinned", pinned, "ms", Date.now() - t0);

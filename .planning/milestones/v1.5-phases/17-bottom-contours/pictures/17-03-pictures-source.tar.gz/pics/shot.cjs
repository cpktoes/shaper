// Renders page.html to a PNG at deviceScaleFactor 2. Usage: node shot.cjs <node_modules dir> <page.html> <out.png>
const path = require("node:path");
const { chromium } = require(path.join(process.argv[2], "playwright"));
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 800, height: 600 }, deviceScaleFactor: 2 });
  await page.goto("file://" + path.resolve(process.argv[3]));
  await page.screenshot({ path: process.argv[4], fullPage: true });
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

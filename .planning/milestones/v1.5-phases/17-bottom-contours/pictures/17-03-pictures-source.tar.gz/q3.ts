// The Fish's Panel Vee fall with the column floor at 1/4" (the app) and at 0 (no floor) — how much is the floor.
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { sampledFinishedRail, sampledSectionArea } from "@/lib/geometry/finished-rail";
import { boardSections, bottomedHalfSection, computeCrossSectionVolume, simpsonIntegrate } from "@/lib/geometry/volume";
import { mm } from "@/lib/geometry/units";
import { boardFields, bottomBoardOf, bottomOf } from "./boards";
import golden from "@/lib/geometry/__fixtures__/bottom-golden.json";
const list: [string, Record<string, string>, number][] = [];
for (const c of golden.cases as any[]) if (c.kind === "cut" && c.litresOff > 0) list.push([c.board, { [c.section]: c.name }, c.litresOff]);
list.push(["midlength", { nose: "Rolled Belly Entry", center: "Deep Single Concave", tail: "Rolled Vee" }, NaN]);
for (const [id, names, gl] of list) {
  if (!["Rolled Belly Entry","Continuous Belly / Rolled Mid","Panel Vee","Rolled Vee","Reverse Vee Nose","Deep Single Concave"].includes(Object.values(names)[0])) continue;
  const { fields } = boardFields().find((b) => b.id === id)!;
  const board = bottomBoardOf(fields);
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const input = designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom: bottomOf(board, names), board });
  const flatInput = designCrossSectionInput(geometry, profile, rails, fields.outline.length);
  const flat = boardSections(flatInput);
  const v = computeCrossSectionVolume(flatInput);
  const deltas = flat.map((s) => {
    if (!s.result) return 0;
    const half = s.drawn ?? s.blended ?? sampledFinishedRail(s.result, s.domed, s.halfWidth);
    const cut = bottomedHalfSection(half, (y) => input.foamOffAt!(s.station, y), mm(0));
    return sampledSectionArea(cut.half) - sampledSectionArea(half);
  });
  const cs = input.cutStation ?? 0;
  const L = fields.outline.length;
  let litres: number;
  if (cs > 0 && cs < L) {
    const h = L / 50; const m = Math.min(48, Math.max(2, 2 * Math.round(cs / (2 * h))));
    litres = (simpsonIntegrate(deltas.slice(0, m + 1), cs / m) + simpsonIntegrate(deltas.slice(m), (L - cs) / (50 - m))) / 1e6;
  } else litres = simpsonIntegrate(deltas, L / 50) / 1e6;
  const withFloor = v.volumeLitres - computeCrossSectionVolume(input).volumeLitres;
  console.log(id.padEnd(10), JSON.stringify(names).padEnd(50), "floor", withFloor.toFixed(4), "nofloor", (-litres).toFixed(4), "golden", gl.toFixed(4), "r", (withFloor/gl).toFixed(4), (-litres/gl).toFixed(4));
}

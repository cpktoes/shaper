import golden from "@/lib/geometry/__fixtures__/bottom-golden.json";
import { summarizeDesign } from "@/lib/geometry/design";
import { boardFields, bottomBoardOf, bottomOf } from "./boards";
const cases = golden.cases as any[];
const t0 = Date.now();
for (const { id, fields } of boardFields()) {
  const board = bottomBoardOf(fields);
  const flat = summarizeDesign(fields).volumeLitres;
  const op = cases.find((c) => c.kind === "opening" && c.board === id && c.channels === 0);
  const names = Object.fromEntries(Object.entries(op.cuts).map(([k, v]: any) => [k, v.name]));
  let cutL = NaN;
  try { cutL = summarizeDesign({ ...fields, bottom: bottomOf(board, names) }).volumeLitres; } catch (e) { console.log(id, "opening err", (e as Error).message); }
  console.log(id, "flat", flat.toFixed(4), "opening", JSON.stringify(names), "fall", (flat - cutL).toFixed(4), "golden", op.litresOff.toFixed(4), "ratio", ((flat - cutL) / op.litresOff).toFixed(4));
  for (const c of cases.filter((c) => c.kind === "cut" && c.board === id && c.litresOff > 0)) {
    let L = NaN;
    try { L = summarizeDesign({ ...fields, bottom: bottomOf(board, { [c.section]: c.name }) }).volumeLitres; } catch { continue; }
    console.log("   ", c.section, c.name.padEnd(32), "fall", (flat - L).toFixed(4), "golden", c.litresOff.toFixed(4), "ratio", ((flat - L) / c.litresOff).toFixed(4));
  }
}
console.log("ms", Date.now() - t0);

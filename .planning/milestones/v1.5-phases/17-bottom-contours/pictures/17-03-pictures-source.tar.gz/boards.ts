import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { DEFAULT_BOTTOM, BOTTOM_SECTIONS, startingCut, type BoardBottom, type BottomBoard, type BottomCutName, type BottomSectionKey } from "@/lib/geometry/bottom";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, type DesignSummaryFields } from "@/lib/geometry/design";
import { frontFinStation } from "@/lib/geometry/fins";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { inchesToMm, mm } from "@/lib/geometry/units";
export function boardFields(): { id: string; fields: DesignSummaryFields }[] {
  const all = phase16Boards();
  const presets = BOARD_PRESETS.map((preset) => {
    const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
    const found = all.find((b) => b.label === label)!;
    return { id: preset.id, fields: found.fields };
  });
  const fish = presets.find((p) => p.id === "fish")!;
  const wing = { station: mm(frontFinStation(designFinPlacement(fish.fields)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
  return [...presets, { id: "fishwing", fields: { ...fish.fields, outline: { ...fish.fields.outline, wings: [wing] } } }];
}
export function bottomBoardOf(fields: DesignSummaryFields): BottomBoard {
  return designBottomBoard(fields.outline, buildOutline(fields.outline), designSideProfile(fields, LIVE_DESIGN_RULES), designFinPlacement(fields));
}
export function bottomOf(board: BottomBoard, names: Partial<Record<BottomSectionKey, string>>, depth?: number): BoardBottom {
  const bottom = structuredClone(DEFAULT_BOTTOM);
  for (const section of BOTTOM_SECTIONS) {
    const name = names[section];
    if (name) {
      bottom[section] = startingCut(section, name as BottomCutName, board);
      if (depth !== undefined && bottom[section].depth > 0) bottom[section].depth = mm(depth);
    }
  }
  return bottom;
}

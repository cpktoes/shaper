// Swallow: notch inner vs a single's half-width; diamond: foamOff inside the V; CNC stringer lift.
import { phase16Boards, phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { refAt, resolveBottom, foamOff, cutHalfWidth } from "@/lib/geometry/bottom";
import { buildOutline, sampleOutline, foamHalfWidth } from "@/lib/geometry/outline";
import { mm, mmToInches, inchesToMm } from "@/lib/geometry/units";
import { bottomBoardOf, bottomOf } from "./boards";
const sw = phase16Boards().find((b) => b.label === "shortboard|swallow|hard")!.fields;
const b = bottomBoardOf(sw);
const g = buildOutline(sw.outline);
console.log("close", mmToInches(g.centreCloseStation), "first", mmToInches(g.points[0].station));
for (let s = 0; s <= inchesToMm(4); s += inchesToMm(0.5)) {
  console.log(mmToInches(mm(s)).toFixed(1), "notch", mmToInches(b.notchInner(mm(s))).toFixed(2), "ref", mmToInches(refAt(b, "narrowest", mm(s))).toFixed(2), "foam", mmToInches(b.foamAt(mm(s))).toFixed(2), "rail", mmToInches(b.railAt(mm(s))).toFixed(2));
}
const dia = phase16SurfaceBoards().find((x) => x.label === "fish|diamond|hard")!.fields;
const db = bottomBoardOf(dia);
const dg = buildOutline(dia.outline);
console.log("diamond close", mmToInches(dg.centreCloseStation), "first", mmToInches(dg.points[0].station));
const r = resolveBottom(bottomOf(db, { tail: "Panel Vee" }), db);
for (let s = 0; s <= inchesToMm(4); s += inchesToMm(0.5)) {
  console.log(mmToInches(mm(s)).toFixed(1), "outline", mmToInches(sampleOutline(dg, mm(s))).toFixed(2), "foam", mmToInches(foamHalfWidth(dg, mm(s))).toFixed(2), "foamOff at half the foam", foamOff(r, db, mm(s), mm(foamHalfWidth(dg, mm(s)) * 0.9)).toFixed(3));
}

// D-40: every lift cut alone (starting numbers and 1/2"), tip to tip too, on the five boards + diamonds + swallows:
// the underside monotone out from the stringer, never above the deck, stringer untouched; knife edges; meshes closed.
import { phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { BOTTOM_CUT_NAMES, BOTTOM_SECTIONS, DEFAULT_BOTTOM, cutKind, keepStationsInOrder, startingCut, type BottomCutName } from "@/lib/geometry/bottom";
import { buildBoardSurface, enclosedVolumeMm3, meshCheck, surfaceStations } from "@/lib/geometry/board-surface";
import { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES, type DesignSummaryFields } from "@/lib/geometry/design";
import { SECTION_POINTS } from "@/lib/geometry/finished-rail";
import { buildOutline } from "@/lib/geometry/outline";
import { inchesToMm, mm } from "@/lib/geometry/units";
import { boardSections, computeCrossSectionVolume } from "@/lib/geometry/volume";
import { boardFields } from "./boards";
const D = SECTION_POINTS.deck;
function deckAt(half: [number, number][], y: number) {
  if (y <= half[0][0]) return half[0][1];
  for (let k = 0; k < D - 1; k++) { const [y0, h0] = half[k], [y1, h1] = half[k + 1]; if (y >= y0 && y <= y1) return y1 > y0 ? h0 + (h1 - h0) * (y - y0) / (y1 - y0) : Math.max(h0, h1); }
  return half[D - 1][1];
}
const extra = phase16SurfaceBoards().filter((b) => /^(fish|shortboard)\|(diamond|swallow)\|hard$/.test(b.label)).map((b) => ({ id: b.label, fields: b.fields }));
let worstDip = 0, above = 0, knives = 0, sections = 0, stringerMoved = 0, badMesh = 0; let gapMin = 0, gapMax = -1;
const dips: string[] = [];
for (const { id, fields } of [...boardFields(), ...extra] as { id: string; fields: DesignSummaryFields }[]) {
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  for (const section of BOTTOM_SECTIONS) for (const name of BOTTOM_CUT_NAMES[section].filter((n) => cutKind(n as BottomCutName) === "vee" || cutKind(n as BottomCutName) === "belly")) {
    for (const mode of ["start", "half", "tiptotip"] as const) {
      const bottom = structuredClone(DEFAULT_BOTTOM);
      bottom[section] = startingCut(section, name as BottomCutName, board);
      if (mode !== "start") bottom[section].depth = inchesToMm(0.5);
      if (mode === "tiptotip") {
        const t = section === "nose" ? { start: mm(0), end: mm(board.length) } : { start: mm(board.length), end: mm(0) };
        bottom[section] = keepStationsInOrder(section, { ...bottom[section], ...t }, "start", board);
        bottom[section] = keepStationsInOrder(section, { ...bottom[section], ...t }, "end", board);
      }
      const input = designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
      const sInput = { sections: input, geometry, rockerAt: profile.rockerAt };
      for (const sec of boardSections(input, surfaceStations(sInput))) {
        if (!sec.drawn) continue;
        sections++;
        if (sec.railEdgeAt !== undefined) knives++;
        const h = sec.drawn as [number, number][];
        if (h[h.length - 1][1] !== 0 && board.notchInner(sec.station) === 0) { stringerMoved++; if (dips.length < 8) dips.push(`STRINGER ${id} ${name} ${mode} s=${sec.station.toFixed(1)} h=${h[h.length-1][1]} edge=${sec.railEdgeAt}`); }
        let prev = -Infinity;
        for (let k = h.length - 1; k >= D - 1; k--) {
          const [y, z] = h[k];
          if (z > deckAt(h, y) + 1e-9) above++;
          if (z < prev - 1e-9) { const d = prev - z; if (d > worstDip) worstDip = d; if (dips.length < 8) dips.push(`${id} ${name} ${mode} s=${sec.station.toFixed(0)} k=${k} dip ${d.toFixed(4)}`); }
          prev = Math.max(prev, z);
        }
      }
      if (mode !== "start") {
        const surface = buildBoardSurface(sInput);
        const c = meshCheck(surface);
        if (Object.values(c).some((n) => n !== 0)) { badMesh++; console.log("MESH", id, name, mode, JSON.stringify(c)); }
        const L = computeCrossSectionVolume(input).volumeLitres;
        const gap = (enclosedVolumeMm3(surface) / 1e6 - L) / L;
        gapMin = Math.min(gapMin, gap); gapMax = Math.max(gapMax, gap);
      }
    }
  }
}
console.log({ sections, knives, above, stringerMoved, worstDip, badMesh, gapMin, gapMax });
console.log(dips.join("\n"));

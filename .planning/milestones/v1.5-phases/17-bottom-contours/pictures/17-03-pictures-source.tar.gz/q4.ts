// Mesh vs litres on the five boards with the trio at starting depth and at 1/2"; smoothness 0/50/100.
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES, summarizeDesign } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { buildBoardSurface, enclosedVolumeMm3, meshCheck } from "@/lib/geometry/board-surface";
import { boardSections, computeCrossSectionVolume } from "@/lib/geometry/volume";
import { inchesToMm } from "@/lib/geometry/units";
import { boardFields, bottomBoardOf, bottomOf } from "./boards";
const trio = { nose: "Rolled Belly Entry", center: "Deep Single Concave", tail: "Rolled Vee" };
for (const { id, fields } of boardFields()) {
  const board = bottomBoardOf(fields);
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  for (const depth of [undefined, inchesToMm(0.5)]) {
    const input = designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom: bottomOf(board, trio, depth), board });
    const t0 = Date.now();
    const surface = buildBoardSurface({ sections: input, geometry, rockerAt: profile.rockerAt });
    const ms = Date.now() - t0;
    const litres = computeCrossSectionVolume(input).volumeLitres;
    const gap = (enclosedVolumeMm3(surface) / 1e6 - litres) / litres;
    const secs = boardSections(input);
    const bad = secs.filter((s) => !Number.isFinite(s.area)).length;
    let inverted = 0;
    for (const s of secs) if (s.drawn) { const deck = s.drawn.slice(0, 48); for (const [y, h] of s.drawn.slice(48)) { /* compare against deck height */ let top = deck[deck.length-1][1]; for (let k=0;k<47;k++){ if (y>=deck[k][0]&&y<=deck[k+1][0]){ top = deck[k+1][0]>deck[k][0]? deck[k][1]+(deck[k+1][1]-deck[k][1])*(y-deck[k][0])/(deck[k+1][0]-deck[k][0]) : Math.max(deck[k][1],deck[k+1][1]); break; } } if (h > top + 1e-9) inverted++; } }
    console.log(id.padEnd(10), depth ? "1/2\"" : "start", JSON.stringify(meshCheck(surface)), "gap %", (gap * 100).toFixed(4), "ms", ms, "NaN", bad, "inverted", inverted, "floored stations", secs.filter((s) => s.flooredAt).length);
  }
}
const sb = boardFields().find((b) => b.id === "shortboard")!.fields;
const sbb = bottomBoardOf(sb);
const out: number[] = [];
for (const r of [0, 50, 100]) {
  const b = bottomOf(sbb, { center: "Deep Single Concave" });
  b.center.smoothness = r;
  out.push(summarizeDesign({ ...sb, bottom: b }).volumeLitres);
}
console.log("smoothness 0/50/100", out, "spread", Math.max(...out) - Math.min(...out));

import { chromium, webkit, devices } from "@playwright/test";

export const BASE = "http://localhost:3314";

/** A browser page shaped like one of the suite's profiles (or a computer), at twice life size. */
export async function open(profile, { viewport, scale = 2 } = {}) {
  const device =
    profile === "iphone"
      ? devices["iPhone 14"]
      : profile === "android"
        ? devices["Pixel 7"]
        : { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 } };
  const browser = await (profile === "iphone" ? webkit : chromium).launch();
  const context = await browser.newContext({
    ...device,
    ...(viewport ? { viewport } : {}),
    deviceScaleFactor: scale,
    baseURL: BASE,
  });
  const page = await context.newPage();
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  return { browser, context, page };
}

export async function retry(fn, tries = 20) {
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === tries - 1) throw error;
    }
  }
}

/** Opens BOTTOM on the stock board and waits until React owns the tabs. */
export async function gotoBottom(page) {
  await page.goto("/design/bottom", { timeout: 180000 });
  await page.waitForFunction(
    () => {
      const el = document.querySelector('[role="tab"]');
      return !!el && Object.keys(el).some((k) => k.startsWith("__reactFiber"));
    },
    null,
    { timeout: 120000 },
  );
  await page.locator("[data-bottom-top-view]").waitFor({ timeout: 60000 });
}

/** Taps a tab of the phone's NOSE · CENTER · TAIL row when the row is on the page. */
export async function phoneSection(page, word) {
  const tab = page.locator("[data-bottom-phone-sections]").getByRole("tab", { name: word, exact: true });
  if ((await tab.count()) > 0 && (await tab.isVisible())) await tab.click();
}

export async function pickFrom(page, selectName, option) {
  const trigger = page.getByRole("combobox", { name: selectName, exact: true });
  await retry(async () => {
    await trigger.scrollIntoViewIfNeeded({ timeout: 3000 });
    await trigger.click({ timeout: 3000 });
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 3000 });
  });
  await page.waitForTimeout(300);
}

export async function tab(page, name) {
  await retry(async () => {
    await page.getByRole("tab", { name, exact: true }).click({ timeout: 5000 });
  });
  await page.waitForTimeout(300);
}

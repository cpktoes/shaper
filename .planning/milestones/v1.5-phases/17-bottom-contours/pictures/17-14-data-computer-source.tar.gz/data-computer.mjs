import { open, gotoBottom, pickFrom, tab } from "./lib.mjs";

/** DATA on a computer at 1280 x 800: a flat board, one cut, and three cuts — pictured and measured. */
const out = process.argv[2];
if (!out) throw new Error("usage: data-computer.mjs <folder>");
const { browser, page } = await open("desktop", { scale: 1 });

const shot = async (name) => {
  await page.mouse.move(640, 2);
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${out}/${name}.png`, animations: "disabled", caret: "hide" });
};
const measure = async (label) => {
  const data = await page.evaluate(() => {
    const root = document.querySelector("[data-bottom-data]");
    const tables = [...root.querySelectorAll("table")].map((table) => {
      const box = table.parentElement.parentElement;
      return {
        table: table.hasAttribute("data-bottom-depths") ? "depths" : "marks",
        boxHeight: Math.round(box.getBoundingClientRect().height),
        tableHeight: Math.round(table.getBoundingClientRect().height),
        boxScrollsDown: box.scrollHeight > box.clientHeight + 1,
      };
    });
    return {
      card: { height: root.clientHeight, content: root.scrollHeight },
      page: { height: document.documentElement.clientHeight, content: document.documentElement.scrollHeight },
      tables,
      notes: root.querySelectorAll("[data-bottom-notes] p").length,
    };
  });
  console.log(label, JSON.stringify(data));
};
const settled = () => page.locator('[data-bottom-floor-scan="settled"]').waitFor({ state: "attached", timeout: 20000 }).catch(() => {});

await gotoBottom(page);
await tab(page, "DATA");
await settled();
await measure("flat");
await shot("1-flat");

await tab(page, "VIEWER");
await pickFrom(page, "Center Cut", "Deep Single Concave");
await tab(page, "DATA");
await settled();
await measure("one cut");
await shot("2-one-cut");

await tab(page, "VIEWER");
await pickFrom(page, "Tail Cut", "Spiral Vee");
await pickFrom(page, "Channels", "6 channels");
await tab(page, "DATA");
await settled();
await page.waitForTimeout(500);
await measure("three cuts");
await shot("3-three-cuts");
await page.locator("[data-bottom-data]").evaluate((el) => el.scrollTo(0, el.scrollHeight));
await shot("4-three-cuts-end");
await browser.close();

// Scratch: lays the before/after pictures of DATA on a computer out on one captioned sheet (compose.html).
// Run from the scratch folder that holds lib.mjs: node data-sheet/compose.mjs <out.png>
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "@playwright/test";

const here = dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] ?? join(here, "17-14-data-computer.png");

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 2800, height: 900 }, deviceScaleFactor: 1 });
await page.goto(pathToFileURL(join(here, "compose.html")).href);
await page.waitForFunction(() => [...document.images].every((img) => img.complete));
const size = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight }));
const missing = await page.evaluate(() => [...document.images].filter((img) => img.naturalWidth === 0).map((img) => img.getAttribute("src")));
await page.screenshot({ path: out, fullPage: true });
await browser.close();
console.log(`saved ${out} — ${size.width} x ${size.height} dots${missing.length ? `; MISSING ${missing.join(", ")}` : ""}`);

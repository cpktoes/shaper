import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { DEFAULT_BOTTOM, startingCut, resolveBottom } from "@/lib/geometry/bottom";
import { bottomSection } from "@/lib/geometry/bottom-draw";
import { deriveEffectiveRails, designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { inchesToMm, mm } from "@/lib/geometry/units";
import { boardSections } from "@/lib/geometry/volume";
const all = phase16Boards();
for (const preset of BOARD_PRESETS) {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b) => b.label === label)!.fields;
  const g = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const board = designBottomBoard(fields.outline, g, profile, designFinPlacement(fields));
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  for (const [sec, name, depthIn] of [["tail", "Panel Vee", 3 / 16], ["tail", "Panel Vee", 1 / 2], ["tail", "Rolled Vee", 1 / 2], ["nose", "Rolled Belly Entry", 1 / 2]] as const) {
    const b = structuredClone(DEFAULT_BOTTOM);
    b[sec] = { ...startingCut(sec, name, board), depth: inchesToMm(depthIn) };
    const secs = boardSections(designCrossSectionInput(g, profile, rails, fields.outline.length, { bottom: b, board }));
    const edged = secs.filter((x) => x.railEdgeAt !== undefined);
    const thin = secs.filter((x) => x.thinAt && x.thinAt.length);
    const r = resolveBottom(b, board);
    const e = edged[Math.floor(edged.length / 2)];
    let slab = "";
    if (e) { const d = bottomSection(r, board, e.station, 4, { width: 804, height: 200 }, { live: sec, seam: e }); slab = `station ${(e.station / 25.4).toFixed(2)}" rail ${(board.railAt(e.station) / 25.4).toFixed(3)} seam edge ${((board.notchInner(e.station) + e.railEdgeAt!) / 25.4).toFixed(3)} drawn edge ${(d.railEdge / 25.4).toFixed(3)} T ${(board.thicknessAt(e.station) / 25.4).toFixed(3)}`; }
    console.log(preset.id, name, depthIn, "edged", edged.length, "thin", thin.length, slab);
  }
}
const _ = mm;

import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { BOTTOM_CUT_NAMES, BOTTOM_SECTIONS, DEFAULT_BOTTOM, foamOff, resolveBottom, startingCut, cutKind } from "@/lib/geometry/bottom";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { mm } from "@/lib/geometry/units";
const all = phase16Boards();
let worst = 0;
for (const preset of BOARD_PRESETS) {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b) => b.label === label)!.fields;
  const g = buildOutline(fields.outline);
  const board = designBottomBoard(fields.outline, g, designSideProfile(fields, LIVE_DESIGN_RULES), designFinPlacement(fields));
  for (const sec of BOTTOM_SECTIONS) for (const name of BOTTOM_CUT_NAMES[sec]) {
    if (cutKind(name) === "flat") continue;
    const b = structuredClone(DEFAULT_BOTTOM); b[sec] = startingCut(sec, name, board);
    const r = resolveBottom(b, board);
    let max = 0; const L = board.length;
    for (let a = 0; a < 120; a++) { const s = (a + 0.5) / 120 * L; const W = board.railAt(mm(s)); const inner = board.notchInner(mm(s)); for (let j = 0; j <= 64; j++) max = Math.max(max, foamOff(r, board, mm(s), mm(inner + (W - inner) * j / 64))); }
    let dense = 0; for (let a = 0; a <= 4000; a++) { const s = a / 4000 * L; const W = board.railAt(mm(s)); for (let j = 0; j <= 64; j++) dense = Math.max(dense, foamOff(r, board, mm(s), mm(W * j / 64))); }
    const d = dense - max; worst = Math.max(worst, d);
    console.log(preset.id.padEnd(11), name.padEnd(30), "grid", max.toFixed(4), "dense", dense.toFixed(4), "deficit", d.toFixed(4), "levels", Math.floor(max / (25.4/32) + 1e-9), Math.floor(dense / (25.4/32) + 1e-9));
  }
}
console.log("worst", worst);

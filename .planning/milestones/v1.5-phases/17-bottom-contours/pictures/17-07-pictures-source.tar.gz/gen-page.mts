/* Plan 17-07's picture: every BOTTOM drawing as pure geometry, painted straight to SVG with no React — the shapes come
   from lib/geometry/bottom-draw.ts and bottom-tile-art.ts, every number from the app's own functions, every inch
   through lib/geometry/units.ts. The colours are the UI-SPEC's tokens in Daylight (hex only so the page stands alone).
   Beside them, sketch 021's own pictures of the same board, for the founder to compare.
   Usage (from the worktree root):
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> <out.html> */
import { writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const U = await import(path.join(root, "lib/geometry/units.ts"));
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const D = await import(path.join(root, "lib/geometry/bottom-draw.ts"));
const T = await import(path.join(root, "lib/geometry/bottom-tile-art.ts"));
const M = await import(path.join(root, "lib/geometry/measure-display.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const V = await import(path.join(root, "lib/geometry/volume.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { silhouette } = await import(path.join(root, "lib/geometry/screen-tiles.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { inchesToMm, mm } = U;
const SYSTEM = "imperial";

/* Daylight */
const C = {
  ink: "#1f2a3b",
  muted: "#566171",
  fill: "#d9f2ed",
  accent: "#8ec1b8",
  accentInk: "#48605c",
  panel: "#ffffff",
  station: "rgba(86,97,113,0.36)",
  pencil: "rgba(86,97,113,0.78)",
  ghost: "rgba(86,97,113,0.55)",
  wide: "rgba(86,97,113,0.45)",
  warn: "#ac3811",
};

const all = phase16Boards();
const boardOf = (id: string) => {
  const preset = BOARD_PRESETS.find((p: any) => p.id === id)!;
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b: any) => b.label === label)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
  const placement = design.designFinPlacement(fields);
  const board = design.designBottomBoard(fields.outline, geometry, profile, placement);
  const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const sections = (bottom: any, stations?: any[]) => V.boardSections(design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), stations);
  return { id, name: preset.name ?? id, fields, geometry, placement, board, sections };
};
const OPENINGS: Record<string, Record<string, string>> = {
  shortboard: { center: "Deep Single Concave" },
  fish: { tail: "Panel Vee" },
  midlength: { nose: "Blended Nose Concave", center: "Shallow Single Concave", tail: "Spiral Vee" },
  longboard: { nose: "Teardrop Nose Concave", center: "Continuous Belly / Rolled Mid", tail: "Rolled Vee" },
};
const bottomOf = (board: any, names: Record<string, string>, count = 0, change: any = {}) => {
  const bottom = structuredClone(B.DEFAULT_BOTTOM);
  for (const s of B.BOTTOM_SECTIONS) if (names[s]) bottom[s] = B.startingCut(s, names[s], board);
  if (count) bottom.channels = { ...B.startingChannels(count, board, bottom.channels), ...change };
  return bottom;
};
const esc = (t: string) => t.replace(/&/g, "&amp;").replace(/</g, "&lt;");
const textW = (t: string) => t.length * 6.4;

/* ---------- the top view ---------- */
function topView(t: any, bottom: any, live: any, station: number, box: { width: number; height: number }) {
  const resolved = B.resolveBottom(bottom, t.board);
  const f = D.topViewFrame(t.board, box.width, box.height);
  const map = D.topViewMap(f);
  const px = f.px;
  const X = (s: number) => D.topViewX(f, s);
  const Y = (y: number) => D.topViewY(f, y);
  const sw = (n: number) => (n * px).toFixed(2);
  const da = (...n: number[]) => n.map((v) => (v * px).toFixed(2)).join(" ");
  const outline = silhouette(t.geometry).map(({ station: s, w }: any) => map(s, w));
  const boardD = outline.map((p: any, q: number) => `${q ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join("") + "Z";
  let o = `<path d="${boardD}" fill="${C.fill}" stroke="${C.ink}" stroke-width="${sw(1.1)}"/>`;
  o += `<defs><clipPath id="clip-${t.id}-${box.width}"><path d="${boardD}"/></clipPath></defs><g clip-path="url(#clip-${t.id}-${box.width})">`;
  for (const level of D.bottomShadeBands(resolved, t.board)) o += `<path d="${D.shadePathData(level.rects, map)}" fill="${C.muted}" fill-opacity="0.04"/>`;
  for (const c of D.bottomContourLines(resolved, t.board)) o += `<path d="${D.polylinesPathData(c.lines, map)}" fill="none" stroke="${C.station}" stroke-width="${sw(1)}"/>`;
  for (const p of D.bottomPencilLines(resolved, t.board, live)) {
    const d = D.polylinesPathData(p.runs, map);
    if (p.kind === "trough") o += `<path d="${d}" fill="none" stroke="${C.station}" stroke-width="${sw(1)}" stroke-dasharray="${da(1, 3)}"/>`;
    else o += `<path d="${d}" fill="none" stroke="${p.live ? C.ink : C.pencil}" stroke-width="${sw(p.live ? 1.1 : 1)}"/>`;
  }
  o += `</g>`;
  // stringer, wide point, front fins
  const L = t.board.length;
  o += `<line x1="${X(L)}" y1="${f.cy}" x2="${X(Math.max(0, t.geometry.centreCloseStation))}" y2="${f.cy}" stroke="${C.station}" stroke-width="${sw(1)}" stroke-dasharray="${da(16, 4, 4, 4)}"/>`;
  const hw = (s: number) => t.board.railAt(mm(s));
  o += `<line x1="${X(t.board.widePoint)}" y1="${Y(-hw(t.board.widePoint))}" x2="${X(t.board.widePoint)}" y2="${Y(hw(t.board.widePoint))}" stroke="${C.wide}" stroke-width="${sw(1)}" stroke-dasharray="${da(2, 3)}"/>`;
  o += `<line x1="${X(t.board.frontFins)}" y1="${Y(-hw(t.board.frontFins))}" x2="${X(t.board.frontFins)}" y2="${Y(hw(t.board.frontFins))}" stroke="${C.station}" stroke-width="${sw(1)}" stroke-dasharray="${da(5, 4)}"/>`;
  // the fins: FINS' own base lines
  for (const fin of D.bottomFinLines(t.placement)) {
    const a = map(fin.from[0], fin.from[1]);
    const b = map(fin.to[0], fin.to[1]);
    o += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${C.accentInk}" stroke-width="${sw(2.5)}" stroke-linecap="round"/>`;
  }
  // the two rails
  const marks = D.topViewMarks(t.board, resolved, live, t.placement, SYSTEM);
  const yRail = f.padTop - 6 * px;
  const upper = D.placeRailLabels(marks.upper.map((m: any) => ({ x: X(m.station) / px, text: `${m.name} · ${m.value}` })), box.width, (s: string) => textW(s));
  marks.upper.forEach((m: any, q: number) => {
    const l = upper[q];
    o += `<line x1="${X(m.station)}" y1="${Y(-hw(m.station)) - 3 * px}" x2="${X(m.station)}" y2="${yRail + 3 * px}" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
    if (l.show) o += `<text x="${l.textX * px}" y="${yRail}" text-anchor="${l.anchor}" font-size="${sw(9)}" font-weight="700" letter-spacing="${sw(0.6)}" fill="${C.muted}">${esc(l.text)}</text>`;
  });
  const yLow = f.height - f.padBottom + 6 * px;
  if (marks.lower) {
    o += `<line x1="${X(marks.lower.deepest)}" y1="${Y(-hw(marks.lower.deepest))}" x2="${X(marks.lower.deepest)}" y2="${Y(hw(marks.lower.deepest))}" stroke="${C.station}" stroke-width="${sw(1)}" stroke-dasharray="${da(1, 3)}"/>`;
    const lower = D.placeRailLabels(marks.lower.marks.map((m: any) => ({ x: X(m.station) / px, text: `${m.name} ${m.value}` })), box.width, (s: string) => textW(s));
    marks.lower.marks.forEach((m: any, q: number) => {
      const l = lower[q];
      o += `<line x1="${X(m.station)}" y1="${Y(hw(m.station)) + 3 * px}" x2="${X(m.station)}" y2="${yLow + 2 * px}" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
      if (l.show) o += `<text x="${l.textX * px}" y="${yLow + 13 * px}" text-anchor="${l.anchor}" font-size="${sw(9)}" font-weight="700" letter-spacing="${sw(0.6)}" fill="${C.muted}">${m.name} <tspan font-weight="400" font-size="${sw(11)}" letter-spacing="0">${esc(m.value)}</tspan></text>`;
    });
  }
  // the cutting line and its grab dot
  const sx = X(station);
  o += `<line x1="${sx}" y1="${Y(-hw(station)) - 8 * px}" x2="${sx}" y2="${yLow + 2 * px}" stroke="${C.ink}" stroke-width="${sw(1.1)}" stroke-dasharray="${da(9, 3, 2, 3)}"/>`;
  o += `<circle cx="${sx}" cy="${yLow + 30 * px}" r="${sw(7)}" fill="${C.accent}" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
  return `<svg viewBox="0 0 1000 ${f.height}" width="${box.width}" height="${box.height}">${o}</svg>`;
}

/* ---------- the section ---------- */
let ghostCount = 0;
function section(t: any, bottom: any, live: any, station: number, height: any, box: { width: number; height: number }, ghost = false) {
  const resolved = B.resolveBottom(bottom, t.board);
  const seams = t.sections(bottom, [station]);
  const sec = D.bottomSection(resolved, t.board, mm(station), height, box, { live, seam: seams[0] });
  const px = sec.px;
  const sw = (n: number) => (n * px).toFixed(2);
  const da = (...n: number[]) => n.map((v) => (v * px).toFixed(2)).join(" ");
  let o = "";
  for (const d of sec.pieces) o += `<path d="${d}" fill="${C.fill}" stroke="${C.ink}" stroke-width="${sw(1.1)}"/>`;
  if (sec.breakPath) o += `<path d="${sec.breakPath}" fill="none" stroke="${C.panel}" stroke-width="${sw(7)}"/><path d="${sec.breakPath}" fill="none" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
  if (ghost) {
    const ring = D.ghostRail(seams, mm(station));
    // clipped to the slab, as the component clips it (sketch line 744)
    const id = `slab${ghostCount++}`;
    if (ring) o += `<defs><clipPath id="${id}"><rect x="0" y="${sec.yTop - (sec.breakLine ? 0 : 2 * px)}" width="1000" height="${sec.height - sec.yTop}"/></clipPath></defs><g clip-path="url(#${id})"><path d="${D.ghostRailPath(ring, sec)}" fill="none" stroke="${C.ghost}" stroke-width="${sw(1.4)}"/></g>`;
  }
  if (sec.stringer) o += `<line x1="${sec.stringer.x}" y1="${sec.stringer.y1}" x2="${sec.stringer.x}" y2="${sec.stringer.y2}" stroke="${C.station}" stroke-width="${sw(1)}" stroke-dasharray="${da(16, 4, 4, 4)}"/>`;
  o += `<line x1="${sec.straightedge.x1}" y1="${sec.y0}" x2="${sec.straightedge.x2}" y2="${sec.y0}" stroke="${C.ink}" stroke-width="${sw(1)}" stroke-dasharray="${da(5, 4)}"/>`;
  const words = box.width >= D.SECTION_WORDS_MIN_BOX;
  if (words && sec.pieces.length) o += `<text x="${sec.straightedge.x1}" y="${sec.y0 + 13 * px}" font-size="${sw(9)}" font-weight="700" letter-spacing="${sw(0.6)}" fill="${C.muted}">PLANED BOTTOM</text>`;
  o += `<text x="${8 * px}" y="${14 * px}" font-size="${sw(9)}" font-weight="700" letter-spacing="${sw(0.6)}" fill="${C.muted}">${D.sectionHeightLabel(sec)}</text>`;
  const WORDS: Record<string, string> = { stringer: " at the stringer", railLift: " rail lift", trough: " in the trough", channel: " in the channel", stringerLeft: " stringer left" };
  for (const g of D.sectionGauges(sec, resolved, t.board, SYSTEM)) {
    for (const e of g.extensions) o += `<line x1="${e.x1}" y1="${e.y1}" x2="${e.x2}" y2="${e.y2}" stroke="${C.station}" stroke-width="${sw(1)}"/>`;
    for (const l of g.lines) o += `<line x1="${l.x}" y1="${l.y1}" x2="${l.x}" y2="${l.y2}" stroke="${C.ink}" stroke-width="${sw(1)}"/><line x1="${l.x - 4 * px}" y1="${l.y1}" x2="${l.x + 4 * px}" y2="${l.y1}" stroke="${C.ink}" stroke-width="${sw(1)}"/><line x1="${l.x - 4 * px}" y1="${l.y2}" x2="${l.x + 4 * px}" y2="${l.y2}" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
    const value = M.formatMark(g.value, SYSTEM);
    for (const lab of g.labels) {
      // the stringer, trough and channel always carry their words; the rail lift and stringer left only in a 625-dot box
      const w = g.kind === "stringer" || g.kind === "trough" || g.kind === "channel" ? true : lab.words;
      o += `<text x="${lab.x}" y="${lab.y}" text-anchor="${lab.anchor}" font-size="${sw(11)}" fill="${C.ink}">${esc(value + (w ? WORDS[g.kind] : ""))}</text>`;
    }
  }
  const ruler = D.sectionRuler(sec, resolved, t.board, live, SYSTEM, (s: string) => s.length * 6.2);
  if (ruler) {
    o += `<line x1="${ruler.x1}" y1="${ruler.y}" x2="${ruler.x2}" y2="${ruler.y}" stroke="${C.ink}" stroke-width="${sw(1)}"/><line x1="${ruler.x1}" y1="${ruler.y - 5 * px}" x2="${ruler.x1}" y2="${ruler.y + 5 * px}" stroke="${C.ink}" stroke-width="${sw(1)}"/>`;
    if (ruler.caption) o += `<text x="${ruler.x1 - 8 * px}" y="${ruler.y + 3 * px}" text-anchor="end" font-size="${sw(9)}" font-weight="700" letter-spacing="${sw(0.6)}" fill="${C.muted}">${ruler.caption}</text>`;
    for (const k of ruler.ticks) o += `<line x1="${k.x}" y1="${ruler.y - 4 * px}" x2="${k.x}" y2="${ruler.y + 4 * px}" stroke="${C.ink}" stroke-width="${sw(1)}"/><text x="${k.x}" y="${ruler.y + (16 + 11 * k.row) * px}" text-anchor="middle" font-size="${sw(11)}" font-weight="600" fill="${C.ink}">${esc(k.text)}</text>`;
  }
  const caption = `SECTION · ${M.formatDim(mm(station), SYSTEM)} FROM THE TAIL · ${M.formatDim(sec.widthAtStation, SYSTEM)} WIDE`;
  return { svg: `<svg viewBox="0 0 1000 ${sec.height}" width="${box.width}" height="${box.height}">${o}</svg>`, caption, sec };
}

/* ---------- the cartoon and the tile ---------- */
let cartoonCount = 0;
function cartoon(t: any, key: any) {
  const c = D.guideCartoon(key, t.board, t.geometry);
  let o = `<path d="${c.board}" fill="${C.fill}" stroke="${C.ink}" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
  const clip = `cc${cartoonCount++}`;
  o += `<defs><clipPath id="${clip}"><path d="${c.board}"/></clipPath></defs><g clip-path="url(#${clip})">`;
  for (const d of c.shade) o += `<path d="${d}" fill="${C.muted}" fill-opacity="${D.CARTOON_SHADE_OPACITY}"/>`;
  if (c.pencil) o += `<path d="${c.pencil}" fill="none" stroke="${C.pencil}" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
  if (c.trough) o += `<path d="${c.trough}" fill="none" stroke="${C.station}" stroke-width="1" stroke-dasharray="1 3" vector-effect="non-scaling-stroke"/>`;
  o += `</g>`;
  o += `<line x1="${c.stringer.x1}" y1="${c.stringer.y1}" x2="${c.stringer.x2}" y2="${c.stringer.y2}" stroke="${C.station}" stroke-width="1" stroke-dasharray="12 3 3 3" vector-effect="non-scaling-stroke"/>`;
  o += `<line x1="${c.cutLine.x}" y1="${c.cutLine.y1}" x2="${c.cutLine.x}" y2="${c.cutLine.y2}" stroke="${C.ink}" stroke-width="1" stroke-dasharray="7 2.5 1.5 2.5" vector-effect="non-scaling-stroke"/>`;
  for (const d of c.section.pieces) o += `<path d="${d}" fill="${C.fill}" stroke="${C.ink}" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
  if (c.section.breakPath) o += `<path d="${c.section.breakPath}" fill="none" stroke="${C.panel}" stroke-width="5"/><path d="${c.section.breakPath}" fill="none" stroke="${C.ink}" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
  if (c.section.stringer) o += `<line x1="${c.section.stringer.x}" y1="${c.section.stringer.y1}" x2="${c.section.stringer.x}" y2="${c.section.stringer.y2}" stroke="${C.station}" stroke-width="1" stroke-dasharray="12 3 3 3" vector-effect="non-scaling-stroke"/>`;
  const se = c.section.straightedge;
  o += `<line x1="${se.x1}" y1="${se.y}" x2="${se.x2}" y2="${se.y}" stroke="${C.ink}" stroke-width="1" stroke-dasharray="4 3" vector-effect="non-scaling-stroke"/>`;
  const name = key.section === "channels" ? "Channels (six)" : key.name;
  const note = `${t.name} · section ${M.formatDim(c.station, SYSTEM)} from the tail · Height ×${c.section.fitted ? c.section.heightDrawn.toFixed(1) : 8}`;
  return `<div class="card"><h4>${esc(name)}</h4><svg viewBox="${c.viewBox}" width="300" height="154">${o}</svg><p class="small">${esc(note)}</p></div>`;
}
function tile(t: any, bottom: any, label: string) {
  const resolved = B.resolveBottom(bottom, t.board);
  const art = T.bottomTileArt(t.geometry, resolved, t.board);
  let o = `<path d="${art.board}" fill="${C.fill}" stroke="${C.ink}" stroke-width="1.4" vector-effect="non-scaling-stroke"/>`;
  for (const d of art.shade) o += `<path d="${d}" fill="${C.muted}" fill-opacity="0.04"/>`;
  if (art.pencil) o += `<path d="${art.pencil}" fill="none" stroke="${C.pencil}" stroke-width="1" vector-effect="non-scaling-stroke"/>`;
  o += `<line x1="${art.cutLine.x1}" y1="${art.cutLine.y1}" x2="${art.cutLine.x2}" y2="${art.cutLine.y2}" stroke="${C.ink}" stroke-width="1" stroke-dasharray="4 2 1.5 2" vector-effect="non-scaling-stroke"/>`;
  const svg = (w: number, h: number) => `<svg viewBox="${art.viewBox}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet">${o}</svg>`;
  return `<div class="tile"><div class="tilebox">${svg(108, 46)}<div class="tilename">BOTTOM</div><div class="tileline">${esc(T.bottomTileLine(resolved))}</div></div><div>${svg(324, 138)}</div><p class="small">${esc(label)}</p></div>`;
}

/* ---------- the page ---------- */
const sb = boardOf("shortboard");
const lb = boardOf("longboard");
const sbChannels = bottomOf(sb.board, OPENINGS.shortboard, 6, { longest: "inner" });
const sbResolved = B.resolveBottom(sbChannels, sb.board);
const eightIn = inchesToMm(8);
const sketchPics = path.join(root, ".planning/sketches/021-bottom-guide/pictures");

let body = `<h1>17-07 · Every BOTTOM drawing, as pure geometry</h1>
<p class="lede">Painted straight from <code>lib/geometry/bottom-draw.ts</code> and <code>bottom-tile-art.ts</code>, no React: the shade, the lines, the pencil lines, the fins, the rails of marks, the section with its gauges and ruler, the GUIDE cartoons and the ☰ tile. Every number is the app's own (<code>foamOff</code>, DATA's marks, the fins' placement). Daylight colours.</p>`;

body += `<h2>1 · The Shortboard from above — Deep Single Concave + six channels (inner pair longest), CHANNELS live</h2>
<div class="row"><div><p class="cap">BOTTOM VIEW <span>Nose left · ${M.formatLength(sb.board.length, SYSTEM)}</span></p>${topView(sb, sbChannels, "channels", eightIn, { width: 876, height: 250 })}
<p class="cap">${section(sb, sbChannels, "channels", eightIn, 4, { width: 876, height: 200 }).caption}</p>${section(sb, sbChannels, "channels", eightIn, 4, { width: 876, height: 200 }).svg}</div>
<div><p class="small">Sketch 021, the page he approved (desktop-tail-channels.png)</p><img src="file://${sketchPics}/desktop-tail-channels.png" width="560"/></div></div>
<p class="small">New since the sketch (D-31): the fins, FINS' own base lines in the fin colour. Lines a shaper would rule: the single's edge (pencil), each channel wall from its own channel's start, so the fronts step 2".</p>`;

const wideAndFins = [
  ["at the wide point", sb.board.widePoint],
  ["at the front fins", sb.board.frontFins],
] as const;
body += `<h2>2 · The section — one scale at every station, the gauges where a gauge would sit, the ruler from a 548-dot box</h2>`;
for (const [label, s] of wideAndFins) {
  body += `<div class="row">`;
  for (const [win, w] of [["1280 window · 804-dot box: ruler, caption and words", 804], ["1024 window · 548-dot box: ruler bare, values alone", 548], ["820 window · 344-dot box: no ruler", 344]] as const) {
    const s1 = section(sb, sbChannels, "center", s, 4, { width: w, height: 210 });
    body += `<div><p class="small">${win}</p><p class="cap">${s1.caption}</p>${s1.svg}</div>`;
  }
  body += `</div><p class="small">Shortboard ${label}, CENTER live (the single's edge on the ruler), Height ×4.</p>`;
}
{
  const s1 = section(sb, sbChannels, "channels", sb.board.frontFins, 4, { width: 804, height: 210 }, true);
  const s2 = section(sb, sbChannels, "channels", sb.board.frontFins, 8, { width: 804, height: 210 });
  body += `<div class="row"><div><p class="small">At the front fins, CHANNELS live: every wall on the ruler; the finished rail from RAILS as a ghost (its box ticked)</p><p class="cap">${s1.caption}</p>${s1.svg}</div><div><p class="small">The same at ×8: the cut fitted, the factor drawn</p><p class="cap">${s2.caption}</p>${s2.svg}</div></div>`;
}

body += `<h2>3 · The four presets on their sketch openings — the section at the wide point and at the front fins</h2><div class="grid2">`;
for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  const t = boardOf(id);
  const bottom = bottomOf(t.board, OPENINGS[id]);
  const live = OPENINGS[id].center ? "center" : "tail";
  const s1 = section(t, bottom, live, t.board.widePoint, 4, { width: 640, height: 150 });
  const s2 = section(t, bottom, live, t.board.frontFins, 4, { width: 640, height: 150 }, true);
  body += `<div><p class="cap">${esc(t.name)} · ${Object.values(OPENINGS[id]).join(" · ")} <span>${live.toUpperCase()} live</span></p>${topView(t, bottom, live, t.board.widePoint, { width: 640, height: 200 })}<p class="cap">${s1.caption}</p>${s1.svg}<p class="cap">${s2.caption} <span>with the finished rail's ghost</span></p>${s2.svg}</div>`;
}
body += `</div>`;
{
  const fish = boardOf("fish");
  const bottom = bottomOf(fish.board, OPENINGS.fish);
  bottom.tail = { ...bottom.tail, depth: inchesToMm(1 / 2) };
  const edged = fish.sections(bottom).filter((x: any) => x.railEdgeAt !== undefined && x.station > 1);
  const e = edged[edged.length - 1];
  if (e) {
    const s1 = section(fish, bottom, "tail", e.station, 4, { width: 640, height: 170 }, true);
    body += `<div class="row"><div><p class="small">D-40 — the Fish's Panel Vee taken to 1/2": ${M.formatDim(mm(e.station), SYSTEM)} from the tail it lifts the finished rail to the deck, and the foam ends at the seam's knife edge, ${U.mmToInches(fish.board.railAt(e.station) - fish.board.notchInner(e.station) - e.railEdgeAt).toFixed(3)}" inside the outline — the slab stops there, no lip; the ghost is the thinned rail.</p><p class="cap">${s1.caption}</p>${s1.svg}</div></div>`;
  }
}

body += `<h2>4 · GUIDE cartoons — one cut alone at its starting numbers on the open board, the section where it is deepest at ×8</h2><div class="row wrap">`;
for (const key of [
  { section: "nose", name: "Flat Entry" },
  { section: "nose", name: "Rolled Belly Entry" },
  { section: "nose", name: "Teardrop Nose Concave" },
  { section: "tail", name: "Panel Vee" },
  { section: "tail", name: "Spiral Vee" },
  { section: "channels" },
]) body += cartoon(sb, key);
body += cartoon(lb, { section: "nose", name: "Teardrop Nose Concave" });
body += `</div><div class="row"><div><p class="small">Sketch 021's GUIDE on the Shortboard (desktop-guide.png)</p><img src="file://${sketchPics}/desktop-guide.png" width="760"/></div></div>`;

body += `<h2>5 · The ☰ tile — this board's own bottom, the cutting line at the wide point</h2><div class="row">`;
body += tile(sb, B.DEFAULT_BOTTOM, "Shortboard, flat: the board and its cutting line — never a made-up cut");
body += tile(sb, sbChannels, "Shortboard, Deep Single + six channels");
body += tile(lb, bottomOf(lb.board, OPENINGS.longboard), "Longboard, its three opening cuts");
body += `</div>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{font-family:-apple-system,system-ui,sans-serif;margin:24px;color:${C.ink};background:#dfdcd3;width:1700px}
h1{font-size:20px;margin:0 0 6px}h2{font-size:14px;margin:26px 0 8px;text-transform:none}
.lede{font-size:13px;max-width:1100px;color:${C.muted}}code{font-size:12px}
.row{display:flex;gap:18px;align-items:flex-start}.wrap{flex-wrap:wrap}
.row>div,.grid2>div{background:#fff;border:1px solid #897c58;border-radius:8px;padding:10px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.cap{font-size:10px;font-weight:700;letter-spacing:.08em;color:${C.muted};margin:4px 0;display:flex;justify-content:space-between}
.cap span{font-weight:400;letter-spacing:0}
.small{font-size:12px;color:${C.muted};margin:4px 0;max-width:820px}
.card{width:300px}.card h4{margin:0 0 6px;font-size:14px}
.tile{display:flex;gap:12px;align-items:center}.tilebox{border:1px solid #897c58;border-radius:8px;padding:6px;width:108px;text-align:center}
.tilename{font-size:10px;font-weight:800;letter-spacing:.08em;margin-top:4px}.tileline{font-size:10px;color:${C.muted}}
svg text{font-family:-apple-system,system-ui,sans-serif}
</style></head><body>${body}</body></html>`;
writeFileSync(out, html);
console.log("wrote", out);

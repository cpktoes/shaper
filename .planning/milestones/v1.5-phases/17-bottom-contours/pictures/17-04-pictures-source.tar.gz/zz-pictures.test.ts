// Scratch picture generator for 17-04 (archived in pictures/17-04-pictures-source.tar.gz). Copied into
// components/rails/ only while it runs, so the real RailSectionPlot renders through vitest with the units action
// stubbed; it writes page.html beside itself in the scratchpad. Every figure is the app's own.
import { describe, it, vi } from "vitest";
vi.mock("@/app/actions/units", () => ({ saveUnitsPreference: async () => {} }));
import { writeFileSync } from "node:fs";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { UnitsProvider } from "@/components/units-provider";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import {
  BOTTOM_SECTIONS,
  DEFAULT_BOTTOM,
  foamOff,
  resolveBottom,
  startingCut,
  type BoardBottom,
  type BottomCutName,
  type BottomSectionKey,
} from "@/lib/geometry/bottom";
import {
  bottomRailLift,
  deriveEffectiveRails,
  designBottomBoard,
  designCrossSectionInput,
  designFinPlacement,
  designSideProfile,
  LIVE_DESIGN_RULES,
  railAnchorStations,
  railBandsOnTheBottom,
  railsOnTheBottom,
  summarizeDesign,
  type DesignSummaryFields,
} from "@/lib/geometry/design";
import { finishedRail, finishedRailPath, sampledFinishedRail, type FinishedRail } from "@/lib/geometry/finished-rail";
import { formatMark } from "@/lib/geometry/measure-display";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { computeRailBands, type RailBandsOutput, type RailSectionKey } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom } from "@/lib/geometry/rail-bottom";
import { mm, mmToInches, type Mm } from "@/lib/geometry/units";
import { boardSections } from "@/lib/geometry/volume";
import { RailSectionPlot } from "./rail-section-plot";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/a6d92625-d457-4168-abef-fe2122d412e3/scratchpad/pics1704/page.html";
const KEYS: RailSectionKey[] = ["nose", "center", "tail"];
const TITLE: Record<RailSectionKey, string> = { nose: "Nose", center: "Center", tail: "Tail" };
const all = phase16Boards();
const fieldsOf = (id: string): DesignSummaryFields => {
  const preset = BOARD_PRESETS.find((p) => p.id === id)!;
  return all.find((b) => b.label === `${id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`)!.fields;
};
const mark = (v: number) => formatMark(mm(v), "imperial");
const inch3 = (v: number) => `${mmToInches(mm(v)).toFixed(3)}"`;

function setup(id: string, names: Partial<Record<BottomSectionKey, BottomCutName>>) {
  const fields = fieldsOf(id);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const geometry = buildOutline(fields.outline);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: BoardBottom = structuredClone(DEFAULT_BOTTOM);
  for (const s of BOTTOM_SECTIONS) if (names[s]) bottom[s] = startingCut(s, names[s]!, board);
  const resolved = resolveBottom(bottom, board);
  const effectiveRails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
  const rails = railsOnTheBottom(effectiveRails, bottomRailLift(resolved, board), anchors);
  const flat = computeRailBands(effectiveRails);
  const lifted = rails === effectiveRails ? flat : railBandsOnTheBottom(computeRailBands(rails), resolved, board, anchors);
  const input = designCrossSectionInput(geometry, profile, effectiveRails, fields.outline.length, { bottom, board });
  const flatInput = designCrossSectionInput(geometry, profile, effectiveRails, fields.outline.length);
  return { fields, board, resolved, anchors, effectiveRails, rails, flat, lifted, input, flatInput, bottom };
}

function plots(bands: RailBandsOutput): string {
  const shared = mm(Math.min(...KEYS.map((k) => bands[k].bounds.xAxisMin)));
  return KEYS.map((key) => {
    const svg = renderToStaticMarkup(
      createElement(UnitsProvider, {
        handoff: { system: "imperial", adoptIntoBrowser: null, promoteToAccount: null } as never,
        children: createElement(RailSectionPlot, { sectionKey: key, output: bands[key], xAxisMin: shared, finishedRail: true }),
      }),
    );
    return `<div class="plot"><div class="ptitle">${TITLE[key]}</div>${svg}</div>`;
  }).join("");
}

function figures(s: ReturnType<typeof setup>): string {
  const rows = KEYS.map((key) => {
    const station = s.anchors[key];
    const lift = foamOff(s.resolved, s.board, station, s.board.railAt(station));
    return `<tr><th>${TITLE[key]}</th><td>${mark(s.effectiveRails[key].boardThickness)}</td><td>${lift > 0 ? `${inch3(lift)}` : "0"}</td><td><b>${mark(s.rails[key].boardThickness)}</b></td><td>${mark(s.flat[key].railThicknessClamped)} → ${mark(s.lifted[key].railThicknessClamped)}</td></tr>`;
  }).join("");
  return `<table><tr><th></th><th>Planed</th><th>Rail lift</th><th>RAILS bands</th><th>Tapered</th></tr>${rows}</table>`;
}

/** Points along a finished rail's steps, for the gap measure. */
function railSamples(rail: FinishedRail): [number, number][] {
  const out: [number, number][] = [[rail.start.x, rail.start.y]];
  let at = rail.start;
  for (const step of rail.steps) {
    for (let k = 1; k <= 32; k++) {
      const t = k / 32;
      if (step.kind === "line") out.push([at.x + (step.to.x - at.x) * t, at.y + (step.to.y - at.y) * t]);
      else if (step.kind === "quad") {
        const u = 1 - t;
        out.push([u * u * at.x + 2 * u * t * step.control.x + t * t * step.to.x, u * u * at.y + 2 * u * t * step.control.y + t * t * step.to.y]);
      } else {
        const u = 1 - t;
        out.push([
          u * u * u * at.x + 3 * u * u * t * step.c1.x + 3 * u * t * t * step.c2.x + t * t * t * step.to.x,
          u * u * u * at.y + 3 * u * u * t * step.c1.y + 3 * u * t * t * step.c2.y + t * t * t * step.to.y,
        ]);
      }
    }
    at = step.to;
  }
  return out;
}

/** D-35's comparison at one anchor: RAILS' finished rail on the lifted bottom beside the 3D board's rail. */
function overlay(s: ReturnType<typeof setup>, key: RailSectionKey, caption: string): { html: string; gap: number; flatGap: number } {
  const station = s.anchors[key];
  const W = s.board.railAt(station);
  const lift = foamOff(s.resolved, s.board, station, W);
  const out = s.lifted[key];
  const x0 = out.bounds.xAxisMin;
  const raw = finishedRail(out, x0);
  const rails = out.bottom ? finishedRailOnBottom(raw, out.bottom, out.boardThickness) : raw;
  const flatRail = finishedRail(s.flat[key], s.flat[key].bounds.xAxisMin);
  const [sec] = boardSections(s.input, [station]);
  const [flatSec] = boardSections(s.flatInput, [station]);
  const half = (b: typeof sec) => b.drawn ?? b.blended ?? sampledFinishedRail(b.result!, b.domed, b.halfWidth);
  const D = half(sec);
  const F = half(flatSec);
  // the absolute frame: across from the stringer, height above the planed bottom; RAILS' frame sits `lift` up at the rail
  const railsAbs = railSamples(rails).map(([x, y]) => [W + x, y + lift] as [number, number]);
  const flatAbs = railSamples(flatRail).map(([x, y]) => [W + x, y] as [number, number]);
  const gapOf = (pts: [number, number][], ref: [number, number][]) => {
    let worst = 0;
    for (const p of pts) {
      if (p[0] < W + x0 + 1) continue;
      let best = Infinity;
      for (const q of ref) best = Math.min(best, Math.hypot(p[0] - q[0], p[1] - q[1]));
      worst = Math.max(worst, best);
    }
    return worst;
  };
  const gap = gapOf(D, railsAbs);
  const flatGap = gapOf(F, flatAbs);
  const T = s.effectiveRails[key].boardThickness;
  const S = 2.4; // px per mm
  const left = W + x0 - 6;
  const right = W + 6;
  const top = T + 8;
  const bottomY = -6;
  const w = (right - left) * S;
  const h = (top - bottomY) * S;
  const X = (x: number) => ((x - left) * S).toFixed(1);
  const Y = (y: number) => ((top - y) * S).toFixed(1);
  const poly = (pts: [number, number][]) => pts.filter((p) => p[0] >= left).map((p) => `${X(p[0])},${Y(p[1])}`).join(" ");
  const railsPath = finishedRailPath(rails, (p) => ({ x: Number(X(W + p.x)), y: Number(Y(p.y + lift)) }));
  const svg = `<svg width="${w.toFixed(0)}" height="${h.toFixed(0)}" viewBox="0 0 ${w.toFixed(1)} ${h.toFixed(1)}">
    <line x1="0" y1="${Y(0)}" x2="${w}" y2="${Y(0)}" stroke="#566171" stroke-dasharray="3 3" stroke-width="1"/>
    <polyline points="${poly(F)}" fill="none" stroke="#9aa3ad" stroke-width="1.5" stroke-dasharray="4 3"/>
    <polyline points="${poly(D)}" fill="none" stroke="#b5563a" stroke-width="2.5"/>
    <path d="${railsPath}" fill="none" stroke="#1f2a3b" stroke-width="1.5"/>
    <line x1="${X(W)}" y1="${Y(-3)}" x2="${X(W)}" y2="${Y(T + 4)}" stroke="#566171" stroke-dasharray="2 3"/>
  </svg>`;
  const html = `<div class="ov"><div class="ovt">${caption}</div>${svg}<div class="ovk">Station ${mmToInches(station).toFixed(1)}" from the tail · rail lift ${inch3(lift)} · RAILS bands ${mark(s.rails[key].boardThickness)} (planed ${mark(T)})<br/>Widest gap between the two rails: <b>${gap.toFixed(1)} mm (${mmToInches(mm(gap)).toFixed(2)}")</b> · the same two readings with a flat bottom: ${flatGap.toFixed(1)} mm</div></div>`;
  return { html, gap, flatGap };
}

describe("scratch: 17-04 pictures", () => {
  it("writes the page", () => {
    const fishFlat = setup("fish", {});
    const fishVee = setup("fish", { tail: "Panel Vee" });
    const longFlat = setup("longboard", {});
    const longBelly = setup("longboard", { center: "Continuous Belly / Rolled Mid" });
    const longVee = setup("longboard", { tail: "Rolled Vee" });
    const short = setup("shortboard", {});
    const thick = (s: ReturnType<typeof setup>) => mark(summarizeDesign({ ...s.fields, bottom: s.bottom }).centerThickness);

    const fishOv = [overlay(fishVee, "tail", "Fish · Panel Vee · tail 12\"")];
    const longOv = [
      overlay(longBelly, "center", "Longboard · Continuous Belly / Rolled Mid · centre"),
      overlay(longBelly, "tail", "Longboard · Continuous Belly / Rolled Mid · tail 12\""),
      overlay(longVee, "tail", "Longboard · Rolled Vee · tail 12\""),
    ];
    const lines: string[] = [];
    for (const o of [...fishOv, ...longOv]) lines.push(`${o.gap.toFixed(2)} mm (flat ${o.flatGap.toFixed(2)} mm)`);

    const page = `<!doctype html><html><head><meta charset="utf-8"><style>
      :root { --color-surf-ink:#1f2a3b; --color-surf-ink-muted:#566171; --color-surf-accent-ink:#48605c; --color-surf-board-fill:#d9f2ed; --outline-page-bg:#ffffff; }
      body { font-family: -apple-system, Helvetica, Arial, sans-serif; margin: 24px; background:#f4f2ec; color:#1f2a3b; width: 1500px; }
      h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 17px; margin: 26px 0 6px; } p { margin: 4px 0; font-size: 13px; max-width: 1450px; }
      .row { display:flex; gap: 18px; align-items:flex-start; }
      .col { background:#fff; border:1px solid #d7d3c8; border-radius:8px; padding:10px 12px; width: 470px; }
      .col h3 { font-size: 14px; margin: 0 0 6px; }
      .plot { margin-bottom: 4px; } .ptitle { font-weight: 800; font-size: 13px; text-align:center; }
      table { border-collapse: collapse; font-size: 12px; margin-top: 6px; } th, td { border-bottom:1px solid #e4e0d6; padding: 2px 8px; text-align:left; }
      .ov { background:#fff; border:1px solid #d7d3c8; border-radius:8px; padding:10px 12px; }
      .ovt { font-weight:800; font-size: 13px; margin-bottom: 4px; } .ovk { font-size: 12px; margin-top: 4px; max-width: 560px; }
      .key span { display:inline-block; width: 22px; height: 0; border-top: 3px solid; vertical-align: middle; margin: 0 4px 0 12px; }
    </style></head><body>
      <h1>17-04 · RAILS works from what the bottom leaves</h1>
      <p>RAILS' own three rail plots, drawn by the app's real plot. A vee or a belly is cut before the rails are shaped, so RAILS now bands the thinner rail it leaves, and draws the planed bottom falling away under the rail toward the stringer at the cut's own angle. The bottom marks sit on that bottom. The deck and the rail edge stay where they were. Finished Rail is on in every plot.</p>

      <h2>1 · The Fish, flat and with a Panel Vee at its starting numbers</h2>
      <div class="row">
        <div class="col"><h3>Flat (what RAILS shows today)</h3>${plots(fishFlat.flat)}${figures(fishFlat)}</div>
        <div class="col"><h3>Panel Vee — what RAILS will show</h3>${plots(fishVee.lifted)}${figures(fishVee)}</div>
        <div class="col"><h3>Why only the tail moved</h3><p>The Panel Vee runs from 12" ahead of the front fins out the tail, so of RAILS' three stations only the tail 12" sits on it. Its rail there is lifted ${inch3(fishVee.lifted.tail.bottom!.lift)}, so RAILS bands a ${mark(fishVee.rails.tail.boardThickness)} rail instead of ${mark(fishVee.effectiveRails.tail.boardThickness)}.</p><p>The board's headline thickness does not move: ${thick(fishFlat)} flat, ${thick(fishVee)} with the vee. VOLUME's rows do not move either.</p>${fishOv[0].html}</div>
      </div>

      <h2>2 · The Longboard, flat and with a Continuous Belly / Rolled Mid (D-35: RAILS' rail against the 3D board's)</h2>
      <div class="row">
        <div class="col"><h3>Flat</h3>${plots(longFlat.flat)}${figures(longFlat)}</div>
        <div class="col"><h3>Continuous Belly / Rolled Mid</h3>${plots(longBelly.lifted)}${figures(longBelly)}</div>
        <div class="col"><h3>The question for you (D-35)</h3><p>RAILS bands the planed thickness less the lift at the rail, and stands that thinner rail on the cut bottom. The 3D board lifts its own finished rail point by point. Below, at each station: <span style="color:#b5563a"><b>the 3D board's rail</b></span>, <b>RAILS' rail on the lifted bottom</b> (black), and the flat board's 3D rail (grey dashes).</p><p>The research measured these two parting by up to an inch on the Longboard. That was before your 17-03 ruling (a vee or belly thins the rail, no lip). With that rule they now lie within ${Math.max(...longOv.map((o) => o.gap)).toFixed(1)} mm of each other here; with a flat bottom the same two readings already differ by up to ${Math.max(...longOv.map((o) => o.flatGap)).toFixed(1)} mm (the 3D board's own sampling of the rail). The widest place is the deck shoulder at the centre, where RAILS' thinner rail rounds a little higher.</p></div>
      </div>
      <div class="row" style="margin-top:12px">${longOv.map((o) => o.html).join("")}</div>

      <h2>3 · A flat board is unchanged</h2>
      <div class="row">
        <div class="col"><h3>Shortboard, flat</h3>${plots(short.flat)}${figures(short)}</div>
        <div class="col"><h3>How that is checked</h3><p>Every rail plot of the 102 test boards (nose, centre and tail, Imperial and Metric, Finished Rail on and off) was drawn by the new code and by the code before this plan: all 612 drawings are the same, character for character. The desktop reference pictures did not move.</p></div>
      </div>
    </body></html>`;
    writeFileSync(OUT, page);
    console.log(lines.join("\n"));
    writeFileSync(OUT.replace("page.html", "gaps.txt"), lines.join("\n") + "\n");
  }, 600000);
});

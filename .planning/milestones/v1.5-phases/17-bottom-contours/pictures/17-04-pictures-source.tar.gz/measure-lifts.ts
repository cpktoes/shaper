import { phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { BOTTOM_SECTIONS, DEFAULT_BOTTOM, foamOff, resolveBottom, startingCut, type BottomCutName, type BottomSectionKey } from "@/lib/geometry/bottom";
import { bottomRailLift, deriveEffectiveRails, designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, railAnchorStations, railsOnTheBottom } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { mm } from "@/lib/geometry/units";

const all = phase16SurfaceBoards();
const IN = 25.4;
function run(id: string, names: Partial<Record<BottomSectionKey, BottomCutName>>) {
  const preset = BOARD_PRESETS.find((p) => p.id === id)!;
  const fields = all.find((b) => b.label === `${id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`)!.fields;
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const geometry = buildOutline(fields.outline);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom = structuredClone(DEFAULT_BOTTOM);
  for (const s of BOTTOM_SECTIONS) if (names[s]) bottom[s] = startingCut(s, names[s]!, board);
  const resolved = resolveBottom(bottom, board);
  const eff = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
  const on = railsOnTheBottom(eff, bottomRailLift(resolved, board), anchors);
  const bands = computeRailBands(eff), bandsOn = computeRailBands(on);
  for (const k of ["tail", "center", "nose"] as const) {
    const s = anchors[k];
    const W = board.railAt(s);
    const L = foamOff(resolved, board, s, W);
    const xMin = bands[k].bounds.xAxisMin;
    const drops = [0, -2, -4, -6, -9].map((xi) => (foamOff(resolved, board, s, mm(Math.abs(W + xi * IN))) - L) / IN);
    console.log(id, k, "station", (s / IN).toFixed(2), "half", (W / IN).toFixed(2), "T", (eff[k].boardThickness / IN).toFixed(3), "lift", (L / IN).toFixed(3), "T-lift", (on[k].boardThickness / IN).toFixed(3), "xMin", (xMin / IN).toFixed(2), "drops@0,2,4,6,9in", drops.map((d) => d.toFixed(3)).join(" "), "tuck3", (bandsOn[k].result.bottomTuck3 / IN).toFixed(2));
  }
}
run("fish", { tail: "Panel Vee" });
run("longboard", { center: "Continuous Belly / Rolled Mid" });
run("longboard", { nose: "Rolled Belly Entry", center: "Shallow Single Concave", tail: "Rolled Vee" });
run("midlength", { tail: "Rolled Vee" });
run("shortboard", { center: "Deep Single Concave" });

import { phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { DEFAULT_BOTTOM } from "@/lib/geometry/bottom";
import { deriveEffectiveRails, designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { boardSections, computeCrossSectionVolume } from "@/lib/geometry/volume";

for (const label of ["shortboard|asis|hard", "longboard|asis|soft"]) {
  const b = phase16SurfaceBoards().find((x) => x.label === label) ?? phase16SurfaceBoards()[0];
  const f = b.fields;
  const p = designSideProfile(f, LIVE_DESIGN_RULES);
  const g = buildOutline(f.outline);
  const board = designBottomBoard(f.outline, g, p, designFinPlacement(f));
  const input = designCrossSectionInput(g, p, deriveEffectiveRails(f.rails, p.effectiveFoil, f.railsImportFoilThickness), f.outline.length, { bottom: DEFAULT_BOTTOM, board });
  for (let i = 0; i < 5; i++) { boardSections(input); computeCrossSectionVolume(input); }
  let t = performance.now();
  for (let i = 0; i < 20; i++) boardSections(input);
  const a = (performance.now() - t) / 20;
  t = performance.now();
  for (let i = 0; i < 20; i++) computeCrossSectionVolume(input);
  console.log(b.label, "boardSections ms", a.toFixed(2), "litres ms", ((performance.now() - t) / 20).toFixed(2));
}

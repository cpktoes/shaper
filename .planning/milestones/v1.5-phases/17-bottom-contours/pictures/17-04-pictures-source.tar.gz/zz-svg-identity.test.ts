import { describe, expect, it, vi } from "vitest";
vi.mock("@/app/actions/units", () => ({ saveUnitsPreference: async () => {} }));
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { UnitsProvider } from "@/components/units-provider";
import { phase16SurfaceBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { deriveEffectiveRails, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { mm } from "@/lib/geometry/units";
import { RailSectionPlot as NewPlot } from "./rail-section-plot";
import { RailSectionPlot as OldPlot } from "./zz-old-plot";

describe("scratch: flat boards draw byte for byte as before", () => {
  it("every section of the 102 boards, both systems, finished rail on and off", () => {
    let n = 0;
    for (const { fields } of phase16SurfaceBoards()) {
      const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
      const bands = computeRailBands(deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness));
      const shared = mm(Math.min(bands.nose.bounds.xAxisMin, bands.center.bounds.xAxisMin, bands.tail.bounds.xAxisMin));
      for (const key of ["nose", "center", "tail"] as const) {
        for (const system of ["imperial", "metric"] as const) {
          for (const finishedRail of [true, false]) {
            const render = (Plot: typeof NewPlot) =>
              renderToStaticMarkup(
                createElement(UnitsProvider, {
                  handoff: { system, adoptIntoBrowser: null, promoteToAccount: null } as never,
                  children: createElement(Plot, { sectionKey: key, output: bands[key], xAxisMin: shared, finishedRail, ghostBands: true }),
                }),
              );
            const fresh = render(NewPlot); expect(fresh).toContain("data-rail-section-plot"); expect(fresh.length).toBeGreaterThan(3000); expect(fresh).toBe(render(OldPlot));
            n++;
          }
        }
      }
    }
    expect(n).toBe(102 * 3 * 2 * 2);
  }, 600000);
});

/* Renders page.html to a PNG at deviceScaleFactor 2 with Playwright's Chromium.
   Usage: node shot.cjs <page.html> <out.png>   (run with a node_modules link beside this file) */
const { chromium } = require("playwright");
const [page, out] = process.argv.slice(2);
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1164, height: 900 }, deviceScaleFactor: 2 });
  const p = await ctx.newPage();
  await p.goto("file://" + page);
  await p.screenshot({ path: out, fullPage: true });
  await browser.close();
  console.log("wrote", out);
})();

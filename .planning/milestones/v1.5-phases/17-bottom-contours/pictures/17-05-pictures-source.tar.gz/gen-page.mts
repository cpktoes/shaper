/* Plan 17-05's picture: the five new cuts (the doubles, the Spiral Vee, the Tri-Plane, the Teardrop) drawn from the app's
   own maths (lib/geometry/bottom.ts) as a line through the sketch's executed figures (bottom-golden.json) as dots; the five
   vees side by side; D-42's fade before and after; the Longboard's litres as VOLUME counts them beside the sketch's slab
   figure; and DATA's two tables for the Shortboard's Deep Single. Nothing is typed: every figure is read or computed by the
   app's functions, every inch through lib/geometry/units.ts.
   Usage (from the worktree root):
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> <out.html> */
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const units = await import(path.join(root, "lib/geometry/units.ts"));
const B = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const { boardSections } = await import(path.join(root, "lib/geometry/volume.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { frontFinStation } = await import(path.join(root, "lib/geometry/fins.ts"));
const { formatInchesFraction, inchesToMm, mm } = units;

const golden = JSON.parse(readFileSync(path.join(root, "lib/geometry/__fixtures__/bottom-golden.json"), "utf8"));

/* the five boards, built as the golden's script builds them */
const all = phase16Boards();
const jobs: { id: string; fields: any }[] = BOARD_PRESETS.map((preset: any) => {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  return { id: preset.id, fields: all.find((b: any) => b.label === label).fields };
});
const fishF = jobs.find((j) => j.id === "fish")!.fields;
const wing = { station: mm(frontFinStation(design.designFinPlacement(fishF)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
jobs.push({ id: "fishwing", fields: { ...fishF, outline: { ...fishF.outline, wings: [wing] } } });
const fieldsOf = (id: string) => jobs.find((j) => j.id === id)!.fields;
const boardOf = (fields: any) => design.designBottomBoard(fields.outline, buildOutline(fields.outline), design.designSideProfile(fields, design.LIVE_DESIGN_RULES), design.designFinPlacement(fields));
const BOARDS: Record<string, any> = Object.fromEntries(jobs.map((j) => [j.id, boardOf(j.fields)]));
const NAME: Record<string, string> = { shortboard: "Shortboard", fish: "Fish", midlength: "Mid-length", longboard: "Longboard", fishwing: "Fish, winged" };
const SECTION_WORD: Record<string, string> = { nose: "Nose", center: "Center", tail: "Tail" };
const frac = (v: number) => formatInchesFraction(mm(v));
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");

const bottomOf = (board: any, names: Record<string, string>, tail?: string) => {
  const b = structuredClone(B.DEFAULT_BOTTOM);
  for (const section of B.BOTTOM_SECTIONS) if (names[section]) b[section] = B.startingCut(section, names[section], board, section === "center" ? (tail ?? names.tail) : undefined);
  return b;
};
const litresOf = (id: string, bottom?: any) => design.summarizeDesign({ ...fieldsOf(id), bottom }).volumeLitres;

/* ---------- 1. the five new cuts, the app's line through the sketch's dots ---------- */
const NEW = [
  { board: "shortboard", section: "center", name: "Early Double Concave" },
  { board: "shortboard", section: "tail", name: "Double Concave Exit" },
  { board: "midlength", section: "tail", name: "Spiral Vee" },
  { board: "midlength", section: "center", name: "Tri-Plane Hull Center" },
  { board: "longboard", section: "nose", name: "Teardrop Nose Concave" },
];
const EXAG = 8;
let worstNew = 0, probesNew = 0;
for (const c of golden.cases.filter((x: any) => x.kind === "cut" && NEW.some((n) => n.name === x.name))) {
  const board = BOARDS[c.board];
  const grid = golden.boards.find((b: any) => b.id === c.board).facts.grid;
  const r = B.resolveBottom(bottomOf(board, { [c.section]: c.name }), board);
  grid.s.forEach((s: number, k: number) => grid.y[k].forEach((y: number, j: number) => {
    probesNew++;
    worstNew = Math.max(worstNew, Math.abs(B.cutFoamOff(r[c.section], board, "narrowest", mm(s), mm(y)) - c.cutOff[k][j]));
  }));
}

function sectionSvg(board: any, resolved: any, s: number, opts: { dots?: number[]; ys?: number[]; PW?: number; PH?: number; exag?: number; scaleW?: number; marks?: number[] }) {
  const PW = opts.PW ?? 520, PH = opts.PH ?? 150, padX = 22, base = PH - 34;
  const W = board.railAt(mm(s));
  const span = opts.scaleW ?? W;
  const sx = (PW - 2 * padX) / (2 * span);
  const X = (y: number) => PW / 2 + y * sx;
  const scaleY = sx * (opts.exag ?? EXAG);
  const Y = (off: number) => base - off * scaleY;
  const N = 320;
  const pts: string[] = [];
  for (let i = 0; i <= N; i++) {
    const y = -W + (2 * W * i) / N;
    pts.push(`${X(y).toFixed(2)},${Y(B.foamOff(resolved, board, mm(s), mm(Math.abs(y)))).toFixed(2)}`);
  }
  const shade = `M${X(-W)},${base} L${pts.join(" L")} L${X(W)},${base} Z`;
  const dots = (opts.ys ?? []).flatMap((y: number, j: number) => [y, -y].map((yy) => `<circle cx="${X(yy).toFixed(2)}" cy="${Y(opts.dots![j]).toFixed(2)}" r="3.4" fill="none" stroke="#c0392b" stroke-width="1.5"/>`)).join("");
  const marks = (opts.marks ?? []).flatMap((m) => [m, -m]).map((m) => `<line x1="${X(m)}" x2="${X(m)}" y1="${base + 2}" y2="${base + 9}" stroke="#2a6f97" stroke-width="1.4"/>`).join("");
  return `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}">
    <rect x="${X(-W)}" y="${base - (PH - 60)}" width="${2 * W * sx}" height="${PH - 60}" fill="#eef1f4"/>
    <path d="${shade}" fill="#f5d9b8" stroke="none"/>
    <line x1="${X(-W) - 6}" x2="${X(W) + 6}" y1="${base}" y2="${base}" stroke="#5b6772" stroke-width="1.1" stroke-dasharray="5 4"/>
    <polyline points="${pts.join(" ")}" fill="none" stroke="#1d2a36" stroke-width="2"/>
    ${dots}${marks}
    <line x1="${PW / 2}" x2="${PW / 2}" y1="${base - (PH - 66)}" y2="${PH - 20}" stroke="#9aa3ad" stroke-width="1" stroke-dasharray="2 3"/>
    <text x="${PW / 2}" y="${PH - 6}" text-anchor="middle">stringer</text>
    <text x="${X(-W)}" y="${PH - 6}" text-anchor="start">rail</text><text x="${X(W)}" y="${PH - 6}" text-anchor="end">rail</text>
  </svg>`;
}

function newPanel(p: (typeof NEW)[number]) {
  const board = BOARDS[p.board];
  const facts = golden.boards.find((b: any) => b.id === p.board).facts;
  const c = golden.cases.find((x: any) => x.kind === "cut" && x.board === p.board && x.name === p.name);
  const r = B.resolveBottom(bottomOf(board, { [p.section]: p.name }), board);
  const cut = r[p.section];
  // the golden's stations are every 1/24 of the board: draw at the one nearest Deepest At (inside the Teardrop's closing
  // for the Teardrop, so the point it closes to shows)
  const target = p.name === "Teardrop Nose Concave" ? (cut.deepest + cut.end) / 2 : cut.deepest;
  let k = 0;
  facts.grid.s.forEach((s: number, i: number) => { if (Math.abs(s - target) < Math.abs(facts.grid.s[k] - target)) k = i; });
  const s = facts.grid.s[k];
  const ys: number[] = facts.grid.y[k];
  const worst = Math.max(...ys.map((y: number, j: number) => Math.abs(B.foamOff(r, board, mm(s), mm(y)) - c.foamOff[k][j])));
  const atS = B.foamOff(r, board, mm(s), mm(0));
  const deepest = B.deepestCutAt(r, board, mm(s));
  const atRail = B.foamOff(r, board, mm(s), board.railAt(mm(s)));
  const C = B.cutHalfWidth(cut, board, "narrowest", mm(s));
  const marks: number[] = [];
  let note = "";
  if (cut.kind === "double") {
    const { flat, trough } = B.doubleMarks(cut, C);
    marks.push(flat, trough, C);
    note = `flat ${frac(flat)} · trough ${frac(trough)} · edge ${frac(C)} off the stringer`;
  } else if (cut.kind === "vee") {
    marks.push(cut.offStringer);
    note = `flat panel ${frac(cut.offStringer)} either side of the stringer`;
  } else {
    marks.push(C);
    note = `the cut ${frac(2 * C)} wide here, closing to a point at its End ${frac(board.length - cut.end)} from the nose`;
  }
  const where = p.section === "nose" ? `${frac(board.length - s)} from the nose` : `${frac(s)} from the tail`;
  return `<div class="panel">
  <div class="ph"><b>${NAME[p.board]}</b> · ${SECTION_WORD[p.section]}: ${esc(p.name)}</div>
  <div class="sub">at ${esc(where)} · ${esc(note)}</div>
  ${sectionSvg(board, r, s, { ys, dots: c.foamOff[k], marks })}
  <div class="sub">at the stringer ${esc(frac(atS))} · deepest ${esc(frac(deepest))} · at the rail ${esc(frac(atRail))} · the app against the sketch's 13 dots: largest gap ${worst.toExponential(1)} mm</div>
</div>`;
}

/* ---------- 2. the five vees side by side, one board, one scale ---------- */
const VEES = [
  { section: "nose", name: "Reverse Vee Nose" },
  { section: "tail", name: "Panel Vee" },
  { section: "tail", name: "Rolled Vee" },
  { section: "center", name: "Tri-Plane Hull Center" },
  { section: "tail", name: "Spiral Vee" },
];
function veePanel(v: (typeof VEES)[number]) {
  const id = "midlength";
  const board = BOARDS[id];
  const r = B.resolveBottom(bottomOf(board, { [v.section]: v.name }), board);
  const s = r[v.section].deepest;
  const where = v.section === "nose" ? `${frac(board.length - s)} from the nose` : `${frac(s)} from the tail`;
  return `<div class="vee"><div class="ph"><b>${esc(v.name)}</b></div><div class="sub">deepest, ${esc(where)} · at the rail ${esc(frac(B.foamOff(r, board, s, board.railAt(s))))}</div>
  ${sectionSvg(board, r, s, { PW: 200, PH: 104, exag: 8, scaleW: board.widePointWidth / 2 })}</div>`;
}

/* ---------- 3. D-42: a center single fades out before a tail vee peaks ---------- */
function alongSvg(id: string, bottom: any) {
  const board = BOARDS[id];
  const r = B.resolveBottom(bottom, board);
  const PW = 520, PH = 150, pad = 24, base = PH - 32;
  const L = board.length;
  const X = (s: number) => pad + ((PW - 2 * pad) * s) / L;
  const Y = (v: number) => base - v * 9;
  const N = 300;
  const single: string[] = [], vee: string[] = [];
  for (let i = 0; i <= N; i++) {
    const s = mm((L * i) / N);
    single.push(`${X(s).toFixed(1)},${Y(B.cutFoamOff(r.center, board, "narrowest", s, mm(0))).toFixed(1)}`);
    vee.push(`${X(s).toFixed(1)},${Y(B.cutFoamOff(r.tail, board, "narrowest", s, board.railAt(s))).toFixed(1)}`);
  }
  const fin = X(board.frontFins), wide = X(board.widePoint);
  return `<svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}">
    <line x1="${pad}" x2="${PW - pad}" y1="${base}" y2="${base}" stroke="#5b6772" stroke-width="1"/>
    <line x1="${fin}" x2="${fin}" y1="${base - 90}" y2="${base + 6}" stroke="#9aa3ad" stroke-dasharray="3 3"/><text x="${fin}" y="${PH - 12}" text-anchor="middle">front fins ${esc(frac(board.frontFins))}</text>
    <line x1="${wide}" x2="${wide}" y1="${base - 90}" y2="${base + 6}" stroke="#9aa3ad" stroke-dasharray="2 3"/><text x="${wide}" y="${PH - 12}" text-anchor="middle">wide point ${esc(frac(board.widePoint))}</text>
    <text x="${pad}" y="${PH - 2}">tail</text><text x="${PW - pad}" y="${PH - 2}" text-anchor="end">nose</text>
    <polyline points="${vee.join(" ")}" fill="none" stroke="#2a6f97" stroke-width="2"/>
    <polyline points="${single.join(" ")}" fill="none" stroke="#b5651d" stroke-width="2.2"/>
  </svg>`;
}
const D42_BOARD = "midlength";
const d42b = BOARDS[D42_BOARD];
const d42Before = bottomOf(d42b, { center: "Shallow Single Concave", tail: "Flat Exit" });
d42Before.tail = B.startingCut("tail", "Rolled Vee", d42b); // the sketch's numbers: the single picked before the vee, and not re-seated
const d42After = B.pickCut(B.pickCut(B.DEFAULT_BOTTOM, "center", "Shallow Single Concave", d42b), "tail", "Rolled Vee", d42b);
const rB = B.resolveCut("center", d42Before.center, d42b), rA = B.resolveCut("center", d42After.center, d42b);
const deepA = B.resolveCut("center", B.startingCut("center", "Deep Single Concave", d42b), d42b);
const deepV = B.resolveCut("center", B.startingCut("center", "Deep Single Concave", d42b, "Rolled Vee"), d42b);
const d42Rows = ["shortboard", "fish", "midlength", "longboard", "fishwing"].map((id) => {
  const b = BOARDS[id];
  const cell = (name: string, tail?: string) => {
    const r = B.resolveCut("center", B.startingCut("center", name, b, tail), b);
    return `${frac(r.start)} · ${frac(r.deepest)} · ${frac(r.end)}`;
  };
  return `<tr><td class="b">${NAME[id]}<div class="sub">wide point ${esc(frac(b.widePoint))} · fins ${esc(frac(b.frontFins))}</div></td><td class="n">${esc(cell("Deep Single Concave"))}</td><td class="n">${esc(cell("Deep Single Concave", "Rolled Vee"))}</td><td class="n">${esc(cell("Shallow Single Concave"))}</td><td class="n">${esc(cell("Shallow Single Concave", "Rolled Vee"))}</td></tr>`;
}).join("");

/* ---------- 4. the litres: VOLUME's fall against the sketch's slab figure ---------- */
const openings = golden.cases.filter((c: any) => c.kind === "opening" && c.channels === 0);
const litresRows = openings.map((op: any) => {
  const board = BOARDS[op.board];
  const names = Object.fromEntries(B.BOTTOM_SECTIONS.map((s: string) => [s, op.cuts[s].name]));
  // the sketch's own starting numbers for every section (no D-42 re-seat), so the comparison is like for like
  const b = structuredClone(B.DEFAULT_BOTTOM);
  for (const s of B.BOTTOM_SECTIONS) b[s] = B.startingCut(s, names[s], board);
  const before = litresOf(op.board), now = litresOf(op.board, b);
  const line = B.bottomLitresLine(now, before);
  const cutsWord = B.BOTTOM_SECTIONS.map((s: string) => names[s]).filter((n: string) => B.cutKind(n) !== "flat").join(" · ");
  return { id: op.board, cutsWord, before, now, fall: before - now, slab: op.litresOff, line };
});
const litresTable = litresRows.map((r: any) => `<tr${r.id === "longboard" ? ' class="hl"' : ""}><td class="b">${NAME[r.id]}</td><td>${esc(r.cutsWord)}</td><td class="n">${r.line.before} L</td><td class="n">${r.line.now} L</td><td class="n">${r.line.foamOff} L</td><td class="n">${r.slab.toFixed(2)} L</td><td class="n">${((r.fall / r.slab) * 100).toFixed(1)}%</td></tr>`).join("");
const lb = litresRows.find((r: any) => r.id === "longboard");

/* ---------- 5. DATA's two tables for the Shortboard's Deep Single ---------- */
const sb = BOARDS.shortboard;
const sbBottom = bottomOf(sb, { center: "Deep Single Concave" });
const sbR = B.resolveBottom(sbBottom, sb);
const dataRows = B.bottomDataRows(sbR, sb);
const dash = (v: number | null, min = B.BOTTOM_DATA_DEPTH_SHOWN) => (v === null || v <= min ? "—" : frac(v));
const label = (r: any) => (r.label === "tail" ? "Tail" : r.label === "nose" ? "Nose tip" : frac(r.station));
const depthTable = dataRows.map((r: any) => `<tr class="${r.reference ? "ref" : ""}"><td class="n">${esc(label(r))}${r.reference ? ` <span class="sub">${r.reference === "wide" ? "wide point" : "front fins"}</span>` : ""}</td><td class="n">${r.width === null ? "—" : esc(frac(r.width))}</td><td class="n">${esc(dash(r.deepest))}</td><td class="n">${esc(dash(r.railLift))}</td><td class="n${r.atFloor ? " warn" : ""}">${r.stringerLeft === null ? "—" : esc(frac(r.stringerLeft))}</td></tr>`).join("");
const marks = B.bottomLayoutMarks(sbR, sb);
const colWord = (c: any) => `${SECTION_WORD[c.section]} ${c.mark}`;
const marksTable = `<tr><th>From the tail</th>${marks.columns.map((c: any) => `<th>${esc(colWord(c))}</th>`).join("")}</tr>` + marks.rows.map((row: any, k: number) => `<tr class="${dataRows[k].reference ? "ref" : ""}"><td class="n">${esc(label(dataRows[k]))}</td>${row.cells.map((v: any) => `<td class="n">${v === null ? "—" : esc(frac(v))}</td>`).join("")}</tr>`).join("");
const sbLine = B.bottomLitresLine(litresOf("shortboard", sbBottom), litresOf("shortboard"));
const centre = mm(sb.length / 2);

/* ---------- the floor: the openings' flags ---------- */
const sectionsOf = (id: string, bottom: any) => {
  const fields = fieldsOf(id);
  const geometry = buildOutline(fields.outline);
  const profile = design.designSideProfile(fields, design.LIVE_DESIGN_RULES);
  const rails = design.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  return boardSections(design.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board: BOARDS[id] }));
};
const floorNotes = openings.flatMap((op: any) => {
  const board = BOARDS[op.board];
  const b = structuredClone(B.DEFAULT_BOTTOM);
  for (const s of B.BOTTOM_SECTIONS) b[s] = B.startingCut(s, op.cuts[s].name, board);
  return B.bottomFloorFlags(B.resolveBottom(b, board), board, sectionsOf(op.board, b)).map((f: any) => `${NAME[op.board]}'s ${op.cuts[f.section].name}: the rail's edge is left under 1/4" at ${f.rails.map((x: number) => frac(x)).join(", ")} from the tail; the stringer never meets the floor`);
});

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a36; margin: 0; padding: 28px 32px; width: 1100px; background: #fff; }
  h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 16px; margin: 26px 0 6px; } h3 { font-size: 13px; margin: 14px 0 4px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; }
  p { margin: 4px 0 10px; max-width: 1060px; } .lede { color: #4a5763; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px 24px; } .vees { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; }
  .panel, .vee { border: 1px solid #dde2e7; border-radius: 6px; padding: 10px 12px; } .vee { padding: 8px; } .ph { font-size: 14px; }
  table { border-collapse: collapse; } th, td { border-bottom: 1px solid #dde2e7; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; font-weight: 700; }
  td.n { font-variant-numeric: tabular-nums; font-size: 13px; white-space: nowrap; text-align: right; } td.b { font-weight: 600; font-size: 13px; }
  tr.ref td { color: #1d2a36; font-weight: 600; } tr td { color: #4a5763; } tr.hl td { background: #fff6e8; } td.warn { color: #b03a2e; }
  .sub { font-size: 11px; color: #7a8590; font-weight: 400; }
  svg text { font-size: 10.5px; fill: #5b6772; }
  .key span { display: inline-block; margin-right: 18px; } .sw { display: inline-block; width: 22px; height: 0; vertical-align: middle; margin-right: 6px; }
  .dot { display: inline-block; width: 8px; height: 8px; border: 1.5px solid #c0392b; border-radius: 50%; vertical-align: middle; margin-right: 6px; }
  .two { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; } .foot { font-size: 11px; color: #7a8590; margin-top: 16px; }
</style></head><body>
<h1>The doubles, the Spiral Vee, the Tri-Plane and the Teardrop — and DATA's numbers</h1>
<p class="lede">All eighteen names now cut. Each new cut is drawn across the board from the app's own maths (the line), through the sketch you approved (the dots), the height 8 times its true size against the width. Nothing on any screen changes yet.</p>
<div class="key"><span><i class="sw" style="border-top:2px solid #1d2a36"></i>the app: foam off across the board</span><span><i class="dot"></i>the sketch's own figure</span><span><i class="sw" style="border-top:1.1px dashed #5b6772"></i>the straightedge on the planed bottom</span><span><i class="sw" style="border-top:8px solid #f5d9b8"></i>foam taken off</span><span><i class="sw" style="border-top:7px solid #2a6f97;width:2px"></i>a layout mark</span></div>
<h2>1. The five new cuts against the sketch</h2>
<div class="grid">${NEW.map(newPanel).join("\n")}
<div class="panel"><div class="ph"><b>All five, every probe</b></div><p>Over ${probesNew.toLocaleString()} points (each of the five names alone on all five boards), the app and the sketch differ by at most ${worstNew.toExponential(1)} mm.</p><p class="sub">A double takes nothing inside its flat, so a single stacked on it leaves the stringer as the ridge. The Spiral Vee is the Double Concave Exit's double with a 3/16" vee under it; its vee runs out through the rail and never touches the stringer (D-40). The Teardrop is drawn at the sketch's station nearest halfway between its Deepest At and its End, so the narrowing toward its point shows.</p></div>
</div>
<h2>2. The five vees side by side — the Mid-length, each at its deepest, one scale</h2>
<div class="vees">${VEES.map(veePanel).join("\n")}</div>
<h2>3. D-42: a center single runs out before a tail vee peaks</h2>
<p>The Mid-length with a Shallow Single Concave (orange, the foam off at the stringer) and a Rolled Vee (blue, the lift at the rail), along the board. <b>Before</b>: the sketch's numbers, both deepest at the front fins. <b>After</b>: the single picked, then the Rolled Vee picked — in that one step the single moves to deepest ${esc(frac(rA.deepest))} (halfway from the wide point to the fins) and ends at the fins, ${esc(frac(rA.end))}, so it has run out where the vee is deepest.</p>
<div class="two"><div class="panel"><div class="ph"><b>Before</b> · Start ${esc(frac(rB.start))} · Deepest ${esc(frac(rB.deepest))} · End ${esc(frac(rB.end))}</div>${alongSvg(D42_BOARD, d42Before)}</div>
<div class="panel"><div class="ph"><b>After</b> · Start ${esc(frac(rA.start))} · Deepest ${esc(frac(rA.deepest))} · End ${esc(frac(rA.end))}</div>${alongSvg(D42_BOARD, d42After)}</div></div>
<h3>A center single's Start · Deepest At · End, from the tail, with no tail vee and with one</h3>
<table><tr><th>Board</th><th>Deep Single</th><th>Deep Single, tail vee</th><th>Shallow Single</th><th>Shallow Single, tail vee</th></tr>${d42Rows}</table>
<p class="sub">The Deep Single already peaked halfway (Mid-length: ${esc(frac(deepA.deepest))} both ways); only its End moves, ${esc(frac(deepA.end))} → ${esc(frac(deepV.end))}. A single set by hand is never moved. Picking a tail that is not a vee puts a single still on the vee's numbers back on the sketch's.</p>
<h2>4. The litres: what VOLUME counts against the sketch's slab figure (D-34)</h2>
<table><tr><th>Board</th><th>Opening cuts</th><th>Before</th><th>Now</th><th>Foam off</th><th>Sketch's slab</th><th>Share</th></tr>${litresTable}</table>
<p>The Longboard's three cuts take <b>${lb.line.foamOff} L</b> as VOLUME counts them, where the sketch said <b>${lb.slab.toFixed(2)} L</b>: the sketch counted foam out to the outline that the Longboard's rolled rail takes anyway, and since D-40 a vee or belly lifts the rail by less the higher a point stands on it. DATA's <i>Foam off</i> will read VOLUME's figure, so the two screens never disagree.</p>
<h2>5. DATA for the Shortboard's Deep Single Concave</h2>
<p class="sub">Foam off ${sbLine.foamOff} L · ${sbLine.now} L now, ${sbLine.before} L before contours · the stringer finishes ${esc(frac(sb.thicknessAt(centre) - B.foamOff(sbR, sb, centre, mm(0))))} at the center, planed ${esc(frac(sb.thicknessAt(centre)))} · contours only take foam away.</p>
<div class="two"><div><h3>Depths under a straightedge</h3><table><tr><th>From the tail</th><th>Width</th><th>Deepest cut</th><th>Rail lift</th><th>Stringer left</th></tr>${depthTable}</table></div>
<div><h3>Layout marks · off the stringer</h3><table>${marksTable}</table>
<h3>The 1/4" floor on the five openings</h3><p class="sub">${floorNotes.length ? floorNotes.map(esc).join(".<br>") + "." : "Nothing meets it."}</p></div></div>
<p class="foot">Drawn by gen-page.mts from lib/geometry/bottom.ts and lib/geometry/__fixtures__/bottom-golden.json (sketch 021's maths, executed on the app's boards in 17-01); litres from summarizeDesign; inches through lib/geometry/units.ts. Plan 17-05, 2026-11-08.</p>
</body></html>`;
writeFileSync(out, html);
console.log("wrote", out, { probesNew, worstNew, longboard: lb, floorNotes, d42: { before: [rB.start, rB.deepest, rB.end], after: [rA.start, rA.deepest, rA.end] } });
console.log(litresRows.map((r: any) => `${r.id}: ${r.line.before} → ${r.line.now}, off ${r.line.foamOff} (fall ${r.fall.toFixed(4)}), slab ${r.slab.toFixed(4)}`).join("\n"));

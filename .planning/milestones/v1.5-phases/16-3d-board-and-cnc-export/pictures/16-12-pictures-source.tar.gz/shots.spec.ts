// Plan 16-12's pictures and timings, on the real 3D screen (the worktree's server, port 3212):
// - desktop 1280 x 800: the panel before and after an export (the done line), the window after it, the can't-build
//   state; the export's time per preset (performance.now round the tap's own work, median of 7 taps), written to
//   out/times.json; one downloaded Fish 5'10" zip kept beside this folder.
// - iphone (iPhone 14, WebKit): the page scrolled to EXPORT, before and after a tap.
import { writeFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/geometry/presets";
import { inchesToMm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/lib/models/toolbar-tip";

const OUT = __dirname + "/out";
const ZIP_KEPT = __dirname + "/../Fish 5'10-3d.zip";
const FISH_NAME = `Fish 5'10"`;

async function setUp(page: Page, presetName: string, boardName: string, lengthMm?: number) {
  await page.addInitScript(
    ([bannerKey, tipKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY] as const,
  );
  const preset = BOARD_PRESETS.find((p) => p.name === presetName);
  if (!preset) throw new Error(`no ${presetName} preset`);
  const base = presetDesignFields(preset);
  const fields: DesignSnapshotFields = {
    ...base,
    outline: lengthMm === undefined ? base.outline : { ...base.outline, length: lengthMm as typeof base.outline.length },
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName,
    finSystem: "fcs2",
  };
  const raw = openBoardCopyJson(fields, { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(([key, value]) => window.localStorage.setItem(key, value), [OPEN_BOARD_STORAGE_KEY, raw] as const);
}

const exportButton = (page: Page) => page.getByRole("button", { name: THREE_D_COPY.exportButton, exact: true });
const status = (page: Page) => page.locator("[data-three-d-export] [role='status']");

async function ready(page: Page, state = "ready") {
  await expect(page.locator("[data-board-3d]")).toHaveAttribute("data-board-state", state, { timeout: 60_000 });
  // The development server's own badge is not part of the app; keep it out of the founder's pictures.
  await page.addStyleTag({ content: "nextjs-portal{display:none!important}" });
  await page.waitForTimeout(600);
}

/** The panel's scroller run to its end, so EXPORT is in the window. */
async function scrollToExport(page: Page) {
  await page.locator("[data-three-d-export]").evaluate((el) => el.scrollIntoView({ block: "end" }));
  await page.waitForTimeout(300);
}

test("desktop: panel before and after, window after, can't build", async ({ page }, info) => {
  test.skip(info.project.name !== "desktop");
  await setUp(page, "Fish", FISH_NAME);
  await page.goto("/design/3d");
  await ready(page);
  const panel = page.locator("[data-three-d-controls]");
  // The whole panel, before and after, at the 1280 window's panel width, in a taller window so it fits.
  await page.setViewportSize({ width: 1280, height: 1040 });
  await page.waitForTimeout(600);
  await panel.screenshot({ path: `${OUT}/panel-before.png` });
  const [download] = await Promise.all([page.waitForEvent("download"), exportButton(page).click()]);
  await download.saveAs(ZIP_KEPT);
  await expect(status(page)).not.toHaveText("");
  // The mouse off the button, so it shows its resting colour rather than its hover shade.
  await page.mouse.move(1270, 10);
  await page.waitForTimeout(300);
  await panel.screenshot({ path: `${OUT}/panel-after.png` });
  await page.setViewportSize({ width: 1280, height: 800 });
  await scrollToExport(page);
  await page.screenshot({ path: `${OUT}/window-after.png` });
});

test("desktop: can't build", async ({ page }, info) => {
  test.skip(info.project.name !== "desktop");
  await setUp(page, "Fish", FISH_NAME, inchesToMm(40));
  await page.goto("/design/3d");
  await ready(page, "cant-build");
  await scrollToExport(page);
  await page.screenshot({ path: `${OUT}/cant-build.png` });
});

test("desktop: the export's time per preset", async ({ page }, info) => {
  test.skip(info.project.name !== "desktop");
  const times: Record<string, { median: number; all: number[]; zip: string; bytes: number; slices: string }> = {};
  for (const preset of ["Shortboard", "Fish", "Mid-length", "Longboard"]) {
    await page.context().clearCookies();
    const fresh = await page.context().newPage();
    await setUp(fresh, preset, "");
    await fresh.goto("/design/3d");
    await ready(fresh);
    const all: number[] = [];
    let zip = "";
    let bytes = 0;
    for (let i = 0; i < 7; i++) {
      const [download, ms] = await Promise.all([
        fresh.waitForEvent("download"),
        fresh.evaluate((name) => {
          const button = [...document.querySelectorAll("button")].find((b) => b.textContent === name)!;
          const t0 = performance.now();
          button.click();
          return performance.now() - t0;
        }, THREE_D_COPY.exportButton),
      ]);
      all.push(Math.round(ms));
      zip = download.suggestedFilename();
      const path = await download.path();
      bytes = path ? (await import("node:fs")).statSync(path).size : 0;
    }
    const sorted = [...all].sort((a, b) => a - b);
    times[preset] = { median: sorted[3], all, zip, bytes, slices: (await status(fresh).textContent()) ?? "" };
    await fresh.close();
  }
  writeFileSync(`${OUT}/times.json`, JSON.stringify(times, null, 2));
});

test("iphone: scrolled to EXPORT, before and after", async ({ page }, info) => {
  test.skip(info.project.name !== "iphone");
  await setUp(page, "Fish", FISH_NAME);
  await page.goto("/design/3d");
  await ready(page);
  await scrollToExport(page);
  await page.screenshot({ path: `${OUT}/iphone-before.png` });
  const [download] = await Promise.all([page.waitForEvent("download"), exportButton(page).click()]);
  expect(download.suggestedFilename()).toBe("Fish 5'10-3d.zip");
  await expect(status(page)).not.toHaveText("");
  await scrollToExport(page);
  await page.screenshot({ path: `${OUT}/iphone-after.png` });
});

// Scratch config for plan 16-12's pictures and timings: the repo's own config, this folder's spec, the worktree's dev
// server on 3212. Run: npx playwright test -c <abs>/pictures.config.ts (a node_modules symlink sits beside it).
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665/playwright.config";
import { defineConfig, devices } from "@playwright/test";

const worktree = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a9136a208fb152665";
const port = 3212;

export default defineConfig({
  ...base,
  testDir: __dirname,
  testIgnore: [],
  testMatch: ["shots.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 600_000,
  workers: 1,
  webServer: {
    ...(base.webServer as object),
    command: `npm run dev -- --port ${port}`,
    url: `http://localhost:${port}/design/outline`,
    cwd: worktree,
    env: { ...((base.webServer as { env: Record<string, string> }).env), IS_WEBPACK_TEST: "1" },
  },
  use: { ...base.use, baseURL: `http://localhost:${port}`, acceptDownloads: true },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
});

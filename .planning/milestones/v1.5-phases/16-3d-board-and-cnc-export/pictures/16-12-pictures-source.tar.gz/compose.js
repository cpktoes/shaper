// Composes plan 16-12's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, cap) => `<figure><img src="${img(n)}"><figcaption>${cap}</figcaption></figure>`;
const section = (title, text, cols, figs) =>
  `<section><h3>${title}</h3><p>${text}</p><div class="row ${cols}">${figs.join("")}</div></section>`;
const times = JSON.parse(fs.readFileSync(path.join(dir, "times.json"), "utf8"));
const rows = Object.entries(times)
  .map(([preset, t]) => `<tr><td>${preset}</td><td>${t.zip}</td><td>${(t.bytes / 1048576).toFixed(2)} MB</td><td>${t.median} ms</td></tr>`)
  .join("");

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1500px;line-height:1.45}
section{padding:0 36px 24px}h3{font-size:19px;margin:6px 0 2px}section p{margin:0 0 10px;font-size:14px;color:#374151;line-height:1.45;max-width:1500px}
.row{display:grid;gap:14px;align-items:start}.panels{grid-template-columns:330px 330px 1fr}.phone{grid-template-columns:300px 300px 1fr}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:6px 12px 8px;font-size:13px;color:#4b5563;border-top:1px solid #e5e1d6}
table{border-collapse:collapse;font-size:14px;margin-top:6px}td,th{border:1px solid #e5e1d6;padding:6px 12px;text-align:left}th{background:#f6f3ec}
</style></head><body>
<h1>Phase 16, plan 12: Export for CNC…</h1>
<p class="lead">The real app at /design/3d, shot from this plan's own server. One tap on the last button of the 3D panel downloads one zip:
the board's DXF, its STL and the text set (the outline, the profile and one file per slice), in millimetres, named from the board.
It is the bare board only — ticking Fins, Blank or Contour Stripes never changes a byte of it.</p>
${section(
  "1. The panel on a computer — before and after a tap",
  "EXPORT is the panel's last section, under VIEW. Export for CNC… is the screen's one filled button; the note under it names Shape3D only. After the tap the line under the note says what arrived: the file's name in full ink, and the slice count read from the files themselves.",
  "panels",
  [
    fig("panel-before", "Before: the line under the note is empty"),
    fig("panel-after", "After one tap: the done line"),
    fig("window-after", "The whole window at 1280 × 800, scrolled to EXPORT"),
  ],
)}
${section(
  "2. A board that can't be drawn, and the iPhone",
  "A board whose figures the 3D board can't be built from (here a Fish set to 40\", outside the app's 60\"–120\") has nothing to export: the button is dimmed and the line says why. On an iPhone the panel sits under the drawing; scrolled to EXPORT, one tap downloads the same zip — the download starts inside the tap, which is what Safari needs.",
  "phone",
  [
    fig("iphone-before", "iPhone 14, scrolled to EXPORT"),
    fig("iphone-after", "iPhone 14, after one tap"),
    fig("cant-build", "A board that can't be built: Export dimmed, the reason on the line"),
  ],
)}
<section><h3>3. How long the tap takes, per preset (this Mac's desktop browser, median of 7 taps)</h3>
<p>Measured round the tap's own work — making every file and starting the download. The 3D board itself is already built when the screen opens.</p>
<table><tr><th>Preset</th><th>Download</th><th>Size</th><th>Tap</th></tr>${rows}</table></section>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.screenshot({ path: process.argv[2], fullPage: true });
  await browser.close();
})();

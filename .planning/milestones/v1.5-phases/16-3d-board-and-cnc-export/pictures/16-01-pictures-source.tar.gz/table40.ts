// Scratch (Phase 16, plan 16-01): prints the 40-board litres table as Markdown — today's litres (the old switch,
// HARD_EDGE_SWITCH) and the fade ending at 14", 18" and 24". Every figure from the app's own functions.
// Run: npx --no-install tsx --tsconfig <WT>/tsconfig.json <this file> <WT>
const WT = process.argv[2];

async function main() {
  const { phase16Boards } = await import(`${WT}/lib/geometry/__fixtures__/phase16-boards.ts`);
  const { summarizeDesign, summarizeDesignWith, LIVE_DESIGN_RULES } = await import(`${WT}/lib/geometry/design.ts`);
  const { HARD_EDGE_SWITCH } = await import(`${WT}/lib/geometry/volume.ts`);
  const { inchesToMm } = await import(`${WT}/lib/geometry/units.ts`);
  const pin = (await import(`${WT}/lib/geometry/__fixtures__/phase16-litres-pin.json`, { with: { type: "json" } })).default;

  const rows: string[] = [
    '| Board | Today (L) | Fade to 14" (L) | Fade to 18" — live (L) | Fade to 24" (L) | Move at 18" (L) |',
    "|---|---:|---:|---:|---:|---:|",
  ];
  for (const board of phase16Boards()) {
    const today = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_SWITCH }).volumeLitres;
    if (today.toPrecision(17) !== pin.litres[board.label]) throw new Error(`${board.label} disagrees with the pin`);
    const at = (inches: number) =>
      summarizeDesign({ ...board.fields, rails: { ...board.fields.rails, tailHardEdgeEndsAt: inchesToMm(inches) } })
        .volumeLitres;
    const [f14, f18, f24] = [at(14), at(18), at(24)];
    const live = summarizeDesign(board.fields).volumeLitres;
    if (live !== f18) throw new Error(`${board.label}: absent does not read 18"`);
    const move = f18 - today;
    rows.push(
      `| ${board.label.replaceAll("|", " · ")} | ${today.toFixed(4)} | ${f14.toFixed(4)} | ${f18.toFixed(4)} | ${f24.toFixed(4)} | ${move === 0 ? "0" : move.toFixed(4)} |`,
    );
  }
  console.log(rows.join("\n"));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

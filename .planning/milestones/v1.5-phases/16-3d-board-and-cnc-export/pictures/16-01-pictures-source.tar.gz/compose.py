# Scratch (Phase 16, plan 16-01): composes VOLUME before (left) and after (right), one row per board, each row
# captioned, and prints where each pair's pixels differ. Args: <shots dir> <out png>
import sys
from PIL import Image, ImageChops, ImageDraw, ImageFont

shots, out = sys.argv[1], sys.argv[2]
ROWS = [
    ("default", "The default board (desktop reference picture)"),
    ("shortboard", "Shortboard preset"),
    ("fish", "Fish preset"),
    ("midlength", "Mid-length preset"),
    ("longboard", "Longboard preset (tail not hard-edged)"),
]
SCALE = 0.5
W, H = int(1280 * SCALE), int(800 * SCALE)
GAP, CAP, PAD = 16, 44, 16
try:
    font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 22)
    small = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 16)
except OSError:
    font = small = ImageFont.load_default()

sheet = Image.new("RGB", (PAD * 2 + W * 2 + GAP, PAD + len(ROWS) * (CAP + H + PAD)), "white")
draw = ImageDraw.Draw(sheet)
y = PAD
for key, caption in ROWS:
    before = Image.open(f"{shots}/{key}-before.png").convert("RGB")
    after = Image.open(f"{shots}/{key}-after.png").convert("RGB")
    box = ImageChops.difference(before, after).getbbox()
    print(key, "changed box", box)
    draw.text((PAD, y + 4), caption, fill="black", font=font)
    draw.text((PAD + W + GAP, y + 10), "before (left) · after (right) — Phase 16 hard-edge fade", fill="#555", font=small)
    y += CAP
    sheet.paste(before.resize((W, H), Image.LANCZOS), (PAD, y))
    sheet.paste(after.resize((W, H), Image.LANCZOS), (PAD + W + GAP, y))
    draw.rectangle([PAD - 1, y - 1, PAD + W, y + H], outline="#999")
    draw.rectangle([PAD + W + GAP - 1, y - 1, PAD + W * 2 + GAP, y + H], outline="#999")
    y += H + PAD
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

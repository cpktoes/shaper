// Scratch (Phase 16, plan 16-01): shoots VOLUME at 1280 x 800 for each preset, as its card opens it.
// OUT_DIR and SHOT_PHASE ("before" | "after") come from the environment; WT is the worktree root.
import { expect, test } from "@playwright/test";
import path from "node:path";

const WT = process.env.WT!;
const OUT_DIR = process.env.OUT_DIR!;
const SHOT_PHASE = process.env.SHOT_PHASE!;

const PRESETS = [
  { id: "shortboard", name: "Shortboard" },
  { id: "fish", name: "Fish" },
  { id: "midlength", name: "Mid-length" },
  { id: "longboard", name: "Longboard" },
];

test.use({ viewport: { width: 1280, height: 800 } });

for (const preset of PRESETS) {
  test(`VOLUME on the ${preset.name}`, async ({ page }) => {
    const { forgetOpenBoardOnEveryLoad } = await import(path.join(WT, "e2e/helpers/open-board.ts"));
    const { goToScreen } = await import(path.join(WT, "e2e/helpers/screens.ts"));
    await forgetOpenBoardOnEveryLoad(page);
    await page.addInitScript(() => {
      window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
    });
    await page.goto("/");
    const card = page.getByRole("button").filter({ hasText: preset.name }).filter({ hasText: "Start Shaping" });
    await expect(async () => {
      await card.first().click();
      await page.waitForURL("**/design/outline", { timeout: 2_000 });
    }).toPass({ timeout: 30_000 });
    await goToScreen(page, "VOLUME");
    await expect(page.getByText("Estimated Volume")).toBeVisible();
    await page.waitForTimeout(1500);
    await page.screenshot({ path: path.join(OUT_DIR, `${preset.id}-${SHOT_PHASE}.png`), animations: "disabled" });
  });
}

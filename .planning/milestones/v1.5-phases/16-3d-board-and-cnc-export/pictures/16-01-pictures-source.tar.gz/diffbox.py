# Scratch (16-01): the bounding box and count of pixels that differ between two PNGs of the same size.
import sys
from PIL import Image, ImageChops

a = Image.open(sys.argv[1]).convert("RGB")
b = Image.open(sys.argv[2]).convert("RGB")
assert a.size == b.size, (a.size, b.size)
diff = ImageChops.difference(a, b)
px = diff.load()
w, h = a.size
pts = [(x, y) for y in range(h) for x in range(w) if px[x, y] != (0, 0, 0)]
print("size", a.size, "changed", len(pts))
if pts:
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    print("bbox x", min(xs), max(xs), "y", min(ys), max(ys))

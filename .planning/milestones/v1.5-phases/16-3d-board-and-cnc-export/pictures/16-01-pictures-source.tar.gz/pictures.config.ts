// Scratch (Phase 16, plan 16-01): a Playwright config that serves the worktree (WT) with the webpack dev
// server on PW_PORT and runs only volume-presets.spec.ts beside it. The env block copies the repo config's
// deliberate non-secrets (never a real key).
import { defineConfig, devices } from "@playwright/test";

const port = Number(process.env.PW_PORT ?? 3201);
const WT = process.env.WT!;

export default defineConfig({
  testDir: __dirname,
  testMatch: "volume-presets.spec.ts",
  workers: 1,
  timeout: 180_000,
  webServer: {
    command: `npm run dev -- --port ${port}`,
    cwd: WT,
    url: `http://localhost:${port}/design/outline`,
    reuseExistingServer: false,
    timeout: 180_000,
    env: {
      IS_WEBPACK_TEST: "1",
      NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: "pk_live_ZXhhbXBsZS5jbGVyay5hY2NvdW50cy5kZXYk",
      CLERK_SECRET_KEY: "sk_live_fake-not-a-secret-for-playwright-only",
      DATABASE_URL: "postgresql://user:pass@localhost:5432/shaper",
      SHAPER_BLANKS_SOURCE: "seed-csv",
    },
  },
  use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, baseURL: `http://localhost:${port}` },
});

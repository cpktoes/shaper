// Rewrites 16-06-SUMMARY.md's lighting/ground section for the founder's final pick. Usage: node summary-final.cjs <abs SUMMARY path>
const fs = require("node:fs");
const f = process.argv[2];
let s = fs.readFileSync(f, "utf8");
const a = s.indexOf("## Second look (2026-11-04)");
const b = s.indexOf("## What changes for the founder (first look)");
if (a < 0 || b < 0) throw new Error("anchors");
const section = `## What shipped after the founder's two looks (2026-11-04): lighting B everywhere, ground #9d9b95 in the light themes

- **First look:** *"The shadowing can be stronger. Maybe no overhead light just the side lights. Also the dark themes
  look good, the light themes may need a darker background to make the foam pop."*
- **From the candidates picture:** *"I like the look of B best with ground 2, even on the slate/dark background."*
- **Then:** *"The darker themes also need the additional shadowing on the board."*

**Shipped:**
- **Lighting B in every theme.** The two low rail tubes at 1.0 and 0.7 of the key, the overhead off, and the fill
  down from 0.2 to 0.08 (key 2.9, exposure 1). There is no light-or-dark switch in the lighting any more:
  \`ROOM_LIGHTING\` is \`LIGHTING_CANDIDATES.B\`. The table and the dev-only candidate hook stay, so a later picture
  can try another setting without editing the app.
- **The light themes' ground:** \`--ramp-daylight-3d-ground\` and \`--ramp-chalk-3d-ground\` are \`#9d9b95\`, about
  30% under the canvas grey. Slate and Phosphor keep their own canvas colours (\`#1a1d25\`, \`#142414\`) as the 3D
  ground. No other screen's ground changed.
- **The dark themes get the stronger shadowing too.** Measured in the re-shot picture, the deck beside the stringer
  reads about 124 in Slate and in Phosphor, against about 180 at the first look. The near rail still catches the
  tube at about 224. The Slate frame is identical, pixel for pixel, to the candidates picture's B-in-Slate shot.
- **The canvas messages stay on the lighter canvas grey.** On the darker ground their small second line would fall
  to 2.26:1 against the app's 4.5:1 for text.

**The edge, as shipped (Daylight and Chalk, walked along the whole board at 1280 × 800):**
- **The near (bottom) edge is crisp:** 52–75 levels lighter than the ground.
- **The far (top) edge is soft:** 8–27 levels darker than the ground on the Fish, and as little as 4 at mid-board
  on the Shortboard. It's visible by eye in the picture, but it's the weak edge of this choice.
- **The outline is ready if wanted.** The contract's pre-committed fix, a one-dot outline in \`--outline-ink\` in the
  two light themes only, is not added, because the founder chose this look as it stands.

**The candidates considered** (strengths are shares of one key level, 2.9; the Fish in Daylight, sampled down its
middle):

| Candidate | Near tube / far tube / overhead / fill | Far edge vs ground 1 (#aeaca5) | vs ground 2 (#9d9b95) | Dome (far half → near half) | Stringer on deck | Slate deck by the stringer |
|---|---|---|---|---|---|---|
| First look | 1.0 / 0.7 / 0.2 / 0.2 | (on #dfdcd3: −29) | — | 184 → 189 | 114 on 185 | about 180 |
| A | 1.0 / 0.7 / 0 / 0.2 | −5 (nearly lost) | +12 | 155 → 160 | 100 on 156 | — |
| **B (shipped, every theme, on ground 2)** | 1.0 / 0.7 / 0 / 0.08 | −29 | **−12** | 128 → 135 | 87 on 130 | about 124–130 |
| C | 1.0 / 0.45 / 0 / 0.04 | −64 | −50 | 107 → 122 | 77 on 112 | about 100 |

- **The interim step:** commit 31bcc2be shipped C on ground 1 for the light themes and kept the dark themes on the
  first look's lighting. The founder's pick replaced it.
- **No floor-bounce light:** this room has no hemisphere or floor-bounce light (that was the mock-up's), so C
  lowered the far tube instead.
- **The candidates were shot without editing the app between shots:** the named table (\`LIGHTING_CANDIDATES\`) plus a
  development-only \`window.__shaper3dLighting\` a picture script can set. A production build never reads it.

**Tests:**
- \`e2e/three-d-screen.spec.ts\` reads every tone from the app's own tokens, so it follows the new values unchanged.
  - Case 2 measures the drawn board against \`--surf-3d-ground\`.
  - Case 3 checks a message sits on \`--surf-canvas\`.
  - Case 11 checks Daylight's board ground is the 3D token and darker than the canvas.
  - Case 10 (the Slate ground) still fails on the old colour-reading timing, 131 levels off under B, and passes now.
- The spec on all three projects: 28 passed, 5 skipped by design.
- \`npm test\`: 7190 passed. \`rack-stand-in\` and \`blank-fit\` timed out under load and pass alone (120/120).
- tsc and lint: 0 errors.

`;
s = s.slice(0, a) + section + s.slice(b);
const rep = (x, y) => {
  if (!s.includes(x)) throw new Error("missing: " + x.slice(0, 60));
  s = s.replace(x, y);
};
rep(`ROOM_LIGHTING (light → C, dark → firstLook); SceneColours.scheme"`, `ROOM_LIGHTING (B, every theme)"`);
rep(
  `    - "The lighting is picked by the theme's own color-scheme (light or dark); a dev-only window.__shaper3dLighting names a candidate for picture scripts, never read by a production build"`,
  `    - "One lighting for every theme (ROOM_LIGHTING); a dev-only window.__shaper3dLighting names a candidate for picture scripts, never read by a production build"`,
);
rep(
  `Second look (the founder: stronger shadowing, side lights only): the light themes take candidate C (near tube 1.0, far tube 0.45, overhead 0, fill 0.04, key 2.9, exposure 1); the dark themes keep the first look's 1.0 / 0.7 / 0.2 / 0.2"`,
  `Shipped after the founder's second look: lighting B in every theme (rail tubes 1.0 / 0.7, overhead 0, fill 0.08, key 2.9, exposure 1)"`,
);
rep(
  `  - "Second look: the light themes draw the 3D board on a darker ground, --surf-3d-ground #aeaca5 (the canvas warm grey 22% darker); Slate and Phosphor keep their canvas colour. The canvas messages stay on --surf-canvas, because their muted line would fall to 2.76:1 on the darker ground"
  - "No one-dot outline: on the darker ground the edge reads all round (in Chalk the far rail is 59–77 levels under the ground, the near rail 34–56 over it)"`,
  `  - "The light themes draw the 3D board on a darker ground, --surf-3d-ground #9d9b95 (the founder's ground 2, about 30% under the canvas grey); Slate and Phosphor keep their canvas colour. The canvas messages stay on --surf-canvas, because their muted line would fall to 2.26:1 on the darker ground"
  - "No one-dot outline (the founder chose this look as it stands); the far edge is soft on ground 2 (4–27 levels under the ground), the near edge crisp (52–75 over)"`,
);
rep(`  commits: 6`, `  commits: 7`);
const fl = s.indexOf("## Founder's look");
if (fl < 0) throw new Error("founder's look");
s =
  s.slice(0, fl) +
  `## Founder's look

First look 2026-11-04: "The shadowing can be stronger. Maybe no overhead light just the side lights. Also the dark themes look good, the light themes may need a darker background to make the foam pop." Second look, from the candidates picture: "I like the look of B best with ground 2, even on the slate/dark background." Shipped: lighting B in every theme, ground #9d9b95 in Daylight and Chalk, the dark themes' own ground.
`;
fs.writeFileSync(f, s);
console.log("ok");

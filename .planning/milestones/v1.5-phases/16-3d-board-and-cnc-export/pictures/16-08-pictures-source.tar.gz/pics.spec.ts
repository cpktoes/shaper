// Plan 16-08's pictures: the top row at 820 / 1024 / 1280, the ☰ sheet upright at 360 and 390 and
// sideways at 844 x 390, SUMMARY's Back/Next and 3D's Back — composed into one sheet.
import { chromium, devices, expect, test, webkit, type Browser, type BrowserContextOptions, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import path from "node:path";

const SHOTS = path.join(__dirname, "shots");
const OUT =
  "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a1f564f5fa396e029/.planning/phases/16-3d-board-and-cnc-export/pictures/16-08-seven-screens.png";
const BASE = `http://localhost:${process.env.PW_PORT ?? 3208}`;

async function newPage(browser: Browser, options: BrowserContextOptions): Promise<Page> {
  const context = await browser.newContext({ ...options, baseURL: BASE });
  await context.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  return context.newPage();
}

async function settle(page: Page) {
  await page.waitForLoadState("load");
  await page.waitForTimeout(1500);
}

async function sheet(page: Page, file: string, label: string): Promise<Record<string, number>> {
  await page.goto("/design/outline");
  await settle(page);
  const menu = page.getByRole("button", { name: "Menu", exact: true });
  await expect(async () => {
    await menu.click();
    await expect(page.locator("[data-screen-tile]")).toHaveCount(7, { timeout: 3000 });
  }).toPass({ timeout: 60_000 });
  await page.waitForTimeout(800);
  const measures = await page.evaluate(() => {
    const out: Record<string, number> = {};
    const tile = document.querySelector<HTMLElement>('[data-screen-tile="/design/outline"]')!;
    const name = Array.from(tile.querySelectorAll("span")).find((s) => s.textContent === "TEMPLATE")!;
    const t = tile.getBoundingClientRect();
    const n = name.getBoundingClientRect();
    const border = parseFloat(getComputedStyle(tile).borderLeftWidth);
    out.templateTileWidth = t.width;
    out.templateNameWidth = n.width;
    out.templateInsetLeft = n.left - t.left - border;
    out.templateInsetRight = t.right - n.right - border;
    const tiles = Array.from(document.querySelectorAll<HTMLElement>("[data-screen-tile]"));
    const tops = new Set(tiles.map((el) => Math.round(el.getBoundingClientRect().top)));
    out.rows = tops.size;
    const heights = new Set(tiles.map((el) => Math.round(el.getBoundingClientRect().height)));
    out.distinctHeights = heights.size;
    const three = document.querySelector<HTMLElement>('[data-screen-tile="/design/3d"]')!;
    out.threeDLabelMatches = three.getAttribute("aria-label") === "3D — Spin and export" ? 1 : 0;
    return out;
  });
  console.log(`[16-08] ${label}`, JSON.stringify(measures));
  await page.getByRole("menu").screenshot({ path: path.join(SHOTS, file) });
  for (const [href, name] of [
    ["/design/3d", "3d"],
    ["/design/outline", "template"],
  ] as const) {
    const tile = page.locator(`[data-screen-tile="${href}"]`);
    measures[`${name}TileWidth`] = (await tile.boundingBox())?.width ?? 0;
    await tile.screenshot({ path: path.join(SHOTS, file.replace(".png", `-${name}.png`)) });
  }
  return measures;
}

test("16-08 pictures", async () => {
  test.setTimeout(900_000);
  const chrome = await chromium.launch();
  const safari = await webkit.launch();

  // The top row, on 3D so the seventh link is the lit one.
  const desk = await newPage(chrome, { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  await desk.goto("/design/3d");
  await settle(desk);
  for (const width of [820, 1024, 1280]) {
    await desk.setViewportSize({ width, height: 800 });
    await desk.waitForTimeout(800);
    const row = desk.locator("nav.gap-10");
    const box = await row.boundingBox();
    const scroll = await desk.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    console.log(`[16-08] row ${width}: height ${box?.height}, horizontal overflow ${scroll}`);
    await row.screenshot({ path: path.join(SHOTS, `row-${width}.png`) });
  }

  // Back and Next on SUMMARY and on 3D (computer, 1280 wide).
  await desk.setViewportSize({ width: 1280, height: 800 });
  const stepWidths: Record<string, number> = {};
  for (const [href, file] of [
    ["/design/summary", "step-summary.png"],
    ["/design/3d", "step-3d.png"],
  ] as const) {
    await desk.goto(href);
    await settle(desk);
    const nav = desk.locator("[data-step-nav]").filter({ visible: true }).first();
    await nav.scrollIntoViewIfNeeded();
    await expect(nav).toBeVisible({ timeout: 60_000 });
    stepWidths[file] = (await nav.boundingBox())?.width ?? 300;
    await nav.screenshot({ path: path.join(SHOTS, file) });
  }

  // The ☰ sheet: upright at 360 (Android-sized, Chromium) and 390 (iPhone 14, WebKit), sideways 844 x 390.
  const p360 = await newPage(chrome, {
    viewport: { width: 360, height: 780 },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
    userAgent: devices["Pixel 7"].userAgent,
  });
  const m360 = await sheet(p360, "sheet-360.png", "sheet 360x780");
  const { defaultBrowserType: _a, ...iphone } = devices["iPhone 14"];
  void _a;
  const p390 = await newPage(safari, iphone);
  const m390 = await sheet(p390, "sheet-390.png", "sheet 390x664 (iPhone 14)");
  const { defaultBrowserType: _b, ...iphoneSideways } = devices["iPhone 14 landscape"];
  void _b;
  // Playwright's "iPhone 14 landscape" is an emulated 750 x 340; a real iPhone held sideways is about
  // 844 x 390 (CLAUDE.md's Layout section), over the 820 line, so the desktop shell.
  const p844 = await newPage(safari, { ...iphoneSideways, viewport: { width: 844, height: 390 } });
  const m844 = await sheet(p844, "sheet-844.png", "sheet 844x390 (iPhone 14 sideways)");

  // Compose.
  const img = (file: string) => `data:image/png;base64,${readFileSync(path.join(SHOTS, file)).toString("base64")}`;
  const fmt = (n: number) => n.toFixed(1);
  const html = `<!doctype html><html><head><style>
    body { margin: 0; padding: 28px; background: #f4f3ef; font: 14px/1.4 -apple-system, Helvetica, sans-serif; color: #222; width: 1360px; }
    h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 15px; margin: 22px 0 8px; }
    p.note { margin: 2px 0 8px; color: #555; }
    .frame { border: 1px solid #ccc; background: white; display: inline-block; }
    .frame img { display: block; }
    .row { display: flex; gap: 24px; align-items: flex-start; }
    .cap { font-size: 12px; color: #555; margin-top: 4px; }
  </style></head><body>
    <h1>Plan 16-08 — seven screens: 3D in the top row, on the ☰ sheet and at the end of Back/Next</h1>
    <p class="note">Shot from the plan's worktree (dev server, signed out, default board). Worktree branch, not yet merged.</p>
    <h2>1. The top row on a computer — 3D last, nothing wraps (gaps 12 below 1024, 16 to 1279, 20 from 1280)</h2>
    ${[820, 1024, 1280].map((w) => `<div class="cap">${w} wide</div><div class="frame"><img src="${img(`row-${w}.png`)}" style="width:${w}px"></div>`).join("")}
    <h2>2. The ☰ sheet — four over three upright, one row of seven sideways</h2>
    <div class="row">
      <div><div class="frame"><img src="${img("sheet-360.png")}" style="width:360px"></div>
        <div class="cap">360 wide upright · TEMPLATE sits ${fmt(m360.templateInsetLeft)} / ${fmt(m360.templateInsetRight)} dots inside its tile's border (open item 4)</div></div>
      <div><div class="frame"><img src="${img("sheet-390.png")}" style="width:390px"></div>
        <div class="cap">390 wide upright (iPhone 14) · TEMPLATE ${fmt(m390.templateInsetLeft)} / ${fmt(m390.templateInsetRight)} dots inside</div></div>
    </div>
    <div style="margin-top:16px"><div class="frame"><img src="${img("sheet-844.png")}" style="width:844px"></div>
      <div class="cap">844 × 390, an iPhone held sideways · ${m844.rows} row of seven</div></div>
    <h2>2b. The 3D tile beside TEMPLATE's, three times larger (390 wide, iPhone 14) — the board turned 50°, its stringer down the deck</h2>
    <div class="row">
      <div><div class="frame"><img src="${img("sheet-390-3d.png")}" style="width:${3 * m390["3dTileWidth"]}px"></div><div class="cap">3D — Spin and export</div></div>
      <div><div class="frame"><img src="${img("sheet-390-template.png")}" style="width:${3 * m390.templateTileWidth}px"></div><div class="cap">TEMPLATE, for comparison</div></div>
    </div>
    <h2>3. Back and Next — SUMMARY reads Fins and 3D; 3D has only Back to Summary</h2>
    <div class="row">
      <div><div class="frame"><img src="${img("step-summary.png")}" style="width:${stepWidths["step-summary.png"]}px"></div><div class="cap">SUMMARY</div></div>
      <div><div class="frame"><img src="${img("step-3d.png")}" style="width:${stepWidths["step-3d.png"]}px"></div><div class="cap">3D</div></div>
    </div>
  </body></html>`;
  const composer = await newPage(chrome, { viewport: { width: 1416, height: 900 }, deviceScaleFactor: 1 });
  await composer.setContent(html);
  await composer.waitForTimeout(500);
  await composer.screenshot({ path: OUT, fullPage: true });
  console.log("[16-08] measures", JSON.stringify({ m360, m390, m844 }));

  await chrome.close();
  await safari.close();
});

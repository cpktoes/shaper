// Scratch config for plan 16-08's pictures: the worktree's own dev server on PW_PORT (3208), the
// project's own non-secret env block, the specs in this scratch folder.
import { defineConfig } from "@playwright/test";
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a1f564f5fa396e029/playwright.config";

const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a1f564f5fa396e029";
const baseServer = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer!;

export default defineConfig({
  testDir: __dirname,
  testMatch: /pics\.spec\.ts$/,
  workers: 1,
  timeout: 600_000,
  webServer: { ...baseServer, cwd: WORKTREE },
  use: { baseURL: base.use?.baseURL },
  projects: [{ name: "pics" }],
});

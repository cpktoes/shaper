// Scratch (Phase 16, plan 16-02): a Playwright config that serves the worktree (WT) with the webpack dev server
// on PW_PORT (3202) and runs only shots.spec.ts beside it, on a 1280 x 800 computer and an iPhone 14. It spreads
// the repo's own config, so the env block is the repo's deliberate non-secrets (never a real key).
import { devices } from "@playwright/test";
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a1393e3c134bf09b4/playwright.config";

const port = Number(process.env.PW_PORT ?? 3202);
const WT = process.env.WT!;

export default {
  ...base,
  testDir: __dirname,
  testMatch: "shots.spec.ts",
  testIgnore: [],
  workers: 1,
  timeout: 180_000,
  webServer: {
    ...(base.webServer as object),
    command: `npm run dev -- --port ${port}`,
    cwd: WT,
    url: `http://localhost:${port}/design/outline`,
    reuseExistingServer: false,
    timeout: 180_000,
    env: { ...((base.webServer as { env: Record<string, string> }).env), IS_WEBPACK_TEST: "1" },
  },
  use: { baseURL: `http://localhost:${port}` },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 } } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
};

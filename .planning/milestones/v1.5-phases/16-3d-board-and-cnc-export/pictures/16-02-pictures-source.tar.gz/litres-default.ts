import { summarizeDesign } from "@/lib/geometry/design";
import { DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { DEFAULT_RAIL_BAND_SPEC } from "@/lib/geometry/rail-bands";
import { DEFAULT_FOIL_SPEC } from "@/lib/geometry/foil";
import { DEFAULT_VOLUME_SPEC } from "@/lib/geometry/volume";
import { inchesToMm } from "@/lib/geometry/units";
const base = { outline: DEFAULT_BOARD_SPEC.outline, rocker: DEFAULT_BOARD_SPEC.rocker, rails: DEFAULT_RAIL_BAND_SPEC, foil: DEFAULT_BOARD_SPEC.foil, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
for (const inch of [14, 18, 23.5, 24]) console.log(inch, summarizeDesign({ ...base, rails: { ...base.rails, tailHardEdgeEndsAt: inchesToMm(inch) } }).volumeLitres);

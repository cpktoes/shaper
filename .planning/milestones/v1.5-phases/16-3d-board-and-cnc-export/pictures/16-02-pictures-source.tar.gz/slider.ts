import { hardEdgeEndsAtSlider } from "@/lib/geometry/blank-reasons";
import { inchesToMm } from "@/lib/geometry/units";
const s = hardEdgeEndsAtSlider(inchesToMm(18), "metric");
console.log(s.value, s.min, s.max, s.step, s.toMm(s.value), s.toMm(470), s.toMm(46.7));
const i = hardEdgeEndsAtSlider(inchesToMm(18), "imperial"); console.log(i.value, i.min, i.max, i.step);

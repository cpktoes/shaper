// Scratch (Phase 16, plan 16-02, D-30): 16-01's 40-board litres table printer, adapted — today's litres (the old
// switch, HARD_EDGE_SWITCH, checked against the pin), the founder's old 16-01 fade (12" to 18") for reference, and
// the live rule at the D-30 defaults (18" to 30", read from a board that says nothing), plus the move at the new
// defaults. Every figure from the app's own functions.
// Run: npx --no-install tsx --tsconfig <WT>/tsconfig.json <this file> <WT>
const WT = process.argv[2];

async function main() {
  const { phase16Boards } = await import(`${WT}/lib/geometry/__fixtures__/phase16-boards.ts`);
  const { summarizeDesign, summarizeDesignWith, LIVE_DESIGN_RULES } = await import(`${WT}/lib/geometry/design.ts`);
  const { HARD_EDGE_SWITCH } = await import(`${WT}/lib/geometry/volume.ts`);
  const { inchesToMm } = await import(`${WT}/lib/geometry/units.ts`);
  const pin = (await import(`${WT}/lib/geometry/__fixtures__/phase16-litres-pin.json`, { with: { type: "json" } })).default;

  const { defaultHardEdgeEndsAt } = await import(`${WT}/lib/geometry/rail-bands.ts`);
  const { formatDim } = await import(`${WT}/lib/geometry/measure-display.ts`);
  const rows: string[] = [
    '| Board | Length | Default end | Today (L) | Old fade 12"→18" (L) | D-30 default — live (L) | Move at the D-30 default (L) |',
    "|---|---:|---:|---:|---:|---:|---:|",
  ];
  for (const board of phase16Boards()) {
    const today = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_SWITCH }).volumeLitres;
    if (today.toPrecision(17) !== pin.litres[board.label]) throw new Error(`${board.label} disagrees with the pin`);
    const length = board.fields.outline.length;
    const pair = (from: number, to: number) =>
      summarizeDesign({
        ...board.fields,
        rails: { ...board.fields.rails, tailHardEdgeBlendsFrom: inchesToMm(from), tailHardEdgeEndsAt: to },
      }).volumeLitres;
    const old = pair(12, inchesToMm(18));
    const end = defaultHardEdgeEndsAt(length);
    const said = pair(18, end);
    const live = summarizeDesign(board.fields).volumeLitres;
    if (live !== said) throw new Error(`${board.label}: a board that says nothing does not read 18" and its default end`);
    const move = live - today;
    rows.push(
      `| ${board.label.replaceAll("|", " · ")} | ${formatDim(length, "imperial")} | ${formatDim(end, "imperial")} | ${today.toFixed(4)} | ${old.toFixed(4)} | ${live.toFixed(4)} | ${move === 0 ? "0" : move.toFixed(4)} |`,
    );
  }
  console.log(rows.join("\n"));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

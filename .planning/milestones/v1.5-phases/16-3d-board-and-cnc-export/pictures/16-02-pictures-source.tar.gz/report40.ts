// Scratch (Phase 16, plan 16-02): the --hard-edge-report's lines on the 40 Phase 16 test boards (never a real
// database), each board's label standing in for a saved board's id. Run with npx tsx from the worktree.
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { hardEdgeReportLines } from "@/lib/models/hard-edge-report";

for (const line of hardEdgeReportLines(phase16Boards().map(({ label, fields }) => ({ id: label, fields })))) {
  console.log(line);
}

# Scratch (Phase 16, plan 16-02): composes RAILS' tail Advanced menu for the founder's look, one captioned row
# per shot: the window on the left, a close-up of the tail rail's controls on the right.
# Args: <shots dir> <out png>
import sys
from PIL import Image, ImageDraw, ImageFont

shots, out = sys.argv[1], sys.argv[2]
ROWS = [
    ("imperial-on", "Computer, 1280 x 800, Imperial, Hard Edge on: Blends From (18 in) then Ends At (30 in), above Reset", 0.6, 1.0),
    ("metric-on", "Computer, 1280 x 800, Metric, Hard Edge on: Blends From 45.7 cm, Ends At 76.2 cm", 0.6, 1.0),
    ("imperial-off", "Computer, 1280 x 800, Hard Edge off: neither row; Use Single Tuck, the tuck rows and Sharp Bottom Tuck are back", 0.6, 1.0),
    ("iphone-on", "iPhone 14, TAIL picked, Hard Edge on: the same two rows in the same place, above Reset", 1 / 3, None),
]
GAP, CAP, PAD = 24, 40, 20
try:
    font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 20)
except OSError:
    font = ImageFont.load_default()

prepared = []
for key, caption, window_scale, tail_scale in ROWS:
    window = Image.open(f"{shots}/{key}-window.png").convert("RGB")
    window = window.resize((round(window.width * window_scale), round(window.height * window_scale)), Image.LANCZOS)
    tail = None
    # The phone's window shot already shows the row full size; its element close-up repeats the pinned top bar.
    if tail_scale is not None:
        tail = Image.open(f"{shots}/{key}-tail.png").convert("RGB")
        tail = tail.resize((round(tail.width * tail_scale), round(tail.height * tail_scale)), Image.LANCZOS)
    prepared.append((caption, window, tail))

width = PAD * 2 + max(w.width + (GAP + t.width if t else 0) for _, w, t in prepared)
width = max(width, 1200)
height = PAD + sum(CAP + max(w.height, t.height if t else 0) + PAD for _, w, t in prepared)
sheet = Image.new("RGB", (width, height), "white")
draw = ImageDraw.Draw(sheet)
y = PAD
for caption, window, tail in prepared:
    draw.text((PAD, y + 8), caption, fill="black", font=font)
    y += CAP
    sheet.paste(window, (PAD, y))
    draw.rectangle([PAD - 1, y - 1, PAD + window.width, y + window.height], outline="#999")
    if tail:
        tx = PAD + window.width + GAP
        sheet.paste(tail, (tx, y))
        draw.rectangle([tx - 1, y - 1, tx + tail.width, y + tail.height], outline="#999")
    y += max(window.height, tail.height if tail else 0) + PAD
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

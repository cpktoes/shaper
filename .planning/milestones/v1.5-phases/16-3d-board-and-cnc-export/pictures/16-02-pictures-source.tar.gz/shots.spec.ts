// Scratch (Phase 16, plan 16-02): shoots RAILS' tail Advanced menu for the founder's look — on a 1280 x 800
// computer with Hard Edge on (Imperial), the same in Metric, the same with Hard Edge off, and on an iPhone 14
// with Hard Edge on. Each shot is the window plus a close-up of the tail rail's controls. OUT names the folder.
import { expect, test, type Page } from "@playwright/test";

const OUT = process.env.OUT!;

async function openRails(page: Page, metric: boolean) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  if (metric) await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
  await page.goto("/design/rails");
  await page.waitForFunction(
    () => {
      const button = document.querySelector("[data-viewer-toolbar] button");
      return !!button && Object.keys(button).some((k) => k.startsWith("__reactProps"));
    },
    undefined,
    { timeout: 60_000 },
  );
}

async function shoot(page: Page, name: string, metric: boolean, hardEdgeOn: boolean, phone: boolean) {
  await openRails(page, metric);
  if (phone) {
    const tab = page.getByRole("tablist").filter({ hasText: "NOSE" }).getByRole("tab", { name: "TAIL" });
    await expect(async () => {
      await tab.click();
      await expect(tab).toHaveAttribute("aria-selected", "true", { timeout: 1_000 });
    }).toPass({ timeout: 15_000 });
  }
  const tail = page.locator('[data-rail-group="tail"]');
  await expect(tail.getByText(/^Deck Profile — /)).toBeVisible();
  if (!hardEdgeOn) {
    const box = tail.getByRole("checkbox", { name: "Hard Edge" });
    await box.click();
    await expect(box).not.toBeChecked();
  }
  const heading = tail.getByRole("button", { name: /^Advanced [▾▸]$/ });
  await heading.click();
  const reset = tail.getByRole("button", { name: /Reset Advanced Settings/ });
  await expect(reset).toBeVisible();
  // Bring the bottom of the menu (the new row, or the tuck rows, then Reset) into view, then let anything
  // animating settle before the shot.
  await reset.scrollIntoViewIfNeeded();
  await page.evaluate(async () => {
    await Promise.all(document.getAnimations().map((a) => a.finished.catch(() => undefined)));
  });
  await page.screenshot({ path: `${OUT}/${name}-window.png` });
  await tail.screenshot({ path: `${OUT}/${name}-tail.png` });
  const rows = await tail
    .getByRole("button", { name: /^Advanced [▾▸]$/ })
    .locator("xpath=following-sibling::div[1]")
    .evaluate((el) => Array.from(el.children).map((c) => (c.textContent ?? "").trim()));
  console.log(name, JSON.stringify(rows));
}

// One test per shot, so each starts from a fresh browser (the Metric pick never carries into the next).
for (const [name, metric, on] of [
  ["imperial-on", false, true],
  ["metric-on", true, true],
  ["imperial-off", false, false],
] as const) {
  test(`computer shot ${name}`, async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await shoot(page, name, metric, on, false);
  });
}

test("iPhone shot", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone");
  await shoot(page, "iphone-on", false, true, true);
});

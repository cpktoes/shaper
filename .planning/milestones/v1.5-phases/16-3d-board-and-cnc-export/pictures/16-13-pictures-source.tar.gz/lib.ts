// Scratch helpers for 16-18's pictures.
import { expect, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/lib/models/toolbar-tip";

export const OUT = __dirname + "/out";

export async function prepare(page: Page, presetName: string, hooks: Record<string, unknown> = {}, theme?: string) {
  const preset = BOARD_PRESETS.find((p) => p.name === presetName);
  if (!preset) throw new Error(presetName);
  const fields: DesignSnapshotFields = {
    ...presetDesignFields(preset),
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: presetName,
    finSystem: "fcs2",
  };
  const raw = openBoardCopyJson(fields, { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, set, chosen]) => {
      window.sessionStorage.setItem(bannerKey as string, "true");
      window.localStorage.setItem(tipKey as string, "true");
      window.localStorage.setItem(boardKey as string, board as string);
      Object.assign(globalThis, set);
      if (chosen) window.localStorage.setItem("theme", chosen as string);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, hooks, theme ?? null] as const,
  );
}

export async function ready(page: Page) {
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 300_000 });
  await expect.poll(async () => Number((await host.getAttribute("data-frames")) ?? 0), { timeout: 60_000 }).toBeGreaterThanOrEqual(1);
  return host;
}

/** Hides the corner row so a canvas screenshot shows the picture alone. */
export async function bareCanvas(page: Page) {
  await page.addStyleTag({ content: "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }" });
}

export async function settled(page: Page) {
  await page.waitForTimeout(700);
}

export async function shoot(page: Page, name: string) {
  await settled(page);
  await page.locator("[data-board-3d]").screenshot({ path: `${OUT}/${name}.png` });
}

/** Sets a slider by its spoken name to a value on its own scale. */
export async function setSlider(page: Page, name: string, value: number) {
  const input = page.getByRole("slider", { name, exact: true });
  await input.evaluate((el, v) => {
    const i = el as HTMLInputElement;
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    set?.call(i, String(v));
    i.dispatchEvent(new Event("input", { bubbles: true }));
    i.dispatchEvent(new Event("change", { bubbles: true }));
  }, value);
}

#!/bin/bash
cd /private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/gate-final/live-copy || exit 1
export NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_ZXhhbXBsZS5jbGVyay5hY2NvdW50cy5kZXYk CLERK_SECRET_KEY=sk_live_fake-not-a-secret-for-playwright-only DATABASE_URL=postgresql://user:pass@localhost:5432/shaper
export SHAPER_BLANKS_SOURCE=seed-csv SHAPER_CONTACT_STAND_IN=1 SHAPER_FORCED_ERROR=1 SHAPER_RACK_STAND_IN=1 IS_WEBPACK_TEST=1
exec npm run dev -- --port 3219

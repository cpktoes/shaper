// Go-live 2's pictures: the top row and the sheet on both sides, the 3D screen on the new side.
import { expect, test, type Page } from "@playwright/test";
import { OUT, prepare, ready, setSlider } from "./lib";

const side = process.env.SIDE as "before" | "after";
const png = (n: string) => `${OUT}/${side}-${n}.png`;
const THEME_KEY = "shaper-theme";
const press = (page: Page, name: string) => page.getByRole("group", { name: "Views", exact: true }).getByRole("button", { name, exact: true }).click();
const walk = (page: Page) => page.getByRole("group", { name: "What a drag does", exact: true }).getByRole("button", { name: "Walk Around", exact: true }).click();
const corner = (page: Page, name: string) => page.locator(`[data-three-d-show="${name}"]`);
const theme = (page: Page, t: string) => page.addInitScript(([k, v]) => window.localStorage.setItem(k, v), [THEME_KEY, t]);
const canvasShot = async (page: Page, n: string) => {
  await page.waitForTimeout(2200);
  await page.locator("[data-board-3d]").screenshot({ path: png(n) });
};

test("top row or sheet", async ({ page }, info) => {
  await prepare(page, "Fish");
  await page.goto("/design/outline");
  await expect(page.getByRole("link", { name: /TEMPLATE/i }).first()).toBeAttached({ timeout: 120_000 });
  await page.waitForTimeout(4000);
  if (info.project.name === "phone") {
    await page.getByRole("banner").getByRole("button", { name: "Menu" }).click();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: png("sheet") });
  } else {
    await page.screenshot({ path: png("top-row"), clip: { x: 0, y: 0, width: 1280, height: 130 } });
  }
});

for (const t of ["daylight", "chalk", "slate", "phosphor"]) {
  test(`first view ${t}`, async ({ page }, info) => {
    test.skip(side === "before" || info.project.name !== "computer");
    await theme(page, t);
    await prepare(page, "Fish");
    await page.goto("/design/3d");
    await ready(page);
    await page.waitForTimeout(2500);
    await page.screenshot({ path: png(`3d-first-${t}`) });
  });
}

test("first view on a phone", async ({ page }, info) => {
  test.skip(side === "before" || info.project.name !== "phone");
  await prepare(page, "Fish");
  await page.goto("/design/3d");
  await ready(page);
  await page.waitForTimeout(2500);
  await page.screenshot({ path: png("3d-first-iphone14") });
});

test("views, switches and the export", async ({ page }, info) => {
  test.skip(side === "before" || info.project.name !== "computer");
  await prepare(page, "Fish");
  await page.goto("/design/3d");
  await ready(page);
  await walk(page);
  for (const name of ["Deck", "Bottom", "Side", "Nose", "Tail"]) {
    await press(page, name);
    await canvasShot(page, `3d-view-${name.toLowerCase()}`);
  }
  await page.getByRole("button", { name: "Reset View", exact: true }).click();
  await page.waitForTimeout(1200);

  const stripes = corner(page, "stripes");
  await stripes.evaluate((b) => (b as HTMLButtonElement).click());
  await canvasShot(page, "3d-contour-stripes");
  await stripes.evaluate((b) => (b as HTMLButtonElement).click());

  const blank = corner(page, "blank");
  await blank.evaluate((b) => (b as HTMLButtonElement).click());
  await canvasShot(page, "3d-blank-ghost");
  await blank.evaluate((b) => (b as HTMLButtonElement).click());

  await page.getByRole("group", { name: "What a drag does", exact: true }).getByRole("button", { name: "Turn the Board", exact: true }).click();
  await page.waitForTimeout(1200);
  await press(page, "Bottom");
  await canvasShot(page, "3d-fins");
  await press(page, "Deck");

  const button = page.getByRole("button", { name: "Export 3D Files", exact: true });
  await button.scrollIntoViewIfNeeded();
  const [download] = await Promise.all([page.waitForEvent("download"), button.click()]);
  await download.saveAs(`${OUT}/${download.suggestedFilename()}`);
  console.log("ZIP", download.suggestedFilename());
  await expect(page.getByText(/^Downloaded /)).toBeVisible({ timeout: 30_000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: png("3d-export-done") });
});

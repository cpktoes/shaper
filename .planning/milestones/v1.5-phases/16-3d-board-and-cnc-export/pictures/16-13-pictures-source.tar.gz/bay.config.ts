// Scratch config for go-live 2's before-and-after pictures.
import { defineConfig, devices } from "@playwright/test";

const gpu = { args: ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu-rasterization"] };

export default defineConfig({
  testDir: __dirname,
  testMatch: ["shots.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 900_000,
  workers: 1,
  fullyParallel: false,
  reporter: "line",
  use: { baseURL: process.env.BASE, acceptDownloads: true },
  projects: [
    { name: "computer", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, launchOptions: gpu } },
    { name: "phone", use: { ...devices["Pixel 7"], viewport: { width: 390, height: 664 }, deviceScaleFactor: 3, launchOptions: gpu } },
  ],
});

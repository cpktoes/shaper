// Composes plan 16-09's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, title, text, cls = "") =>
  `<figure class="${cls}"><img src="${img(n)}"><figcaption><b>${title}</b>${text}</figcaption></figure>`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 22px;font-size:16px;color:#4b5563;max-width:1480px;line-height:1.45}
h2{font-size:19px;margin:8px 36px 12px}
.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px 20px;padding:0 36px 28px}
.two{display:grid;grid-template-columns:1.6fr 1fr;gap:18px 20px;padding:0 36px 28px;align-items:start}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:10px 14px 12px;font-size:14px;line-height:1.4;border-top:1px solid #e5e1d6}
figcaption b{display:block;font-size:15px;margin-bottom:2px}
.phones{display:flex;gap:20px;align-items:flex-start}.phones figure{width:270px;flex:none}
.note{font-size:14px;line-height:1.55;color:#374151;max-width:1480px;padding:0 36px 36px}
</style></head><body>
<h1>Phase 16, plan 09: zooming and sliding the 3D board, and Wide view</h1>
<p class="lead">The real app at /design/3d, Daylight, the Fish. Zooming never moves the camera or the lights: it shows a closer crop of the very picture the camera takes, so the foam is lit the same zoomed in as at 1x. The zoom row is the one every other drawing has: zoom out, the level, zoom in, Back to 1x.</p>
<h2>On a computer (1280 × 800)</h2>
<div class="two">
${fig("desktop-1x", "The 3D screen at 1x", "Top right: Wide view, and under it the zoom row every drawing has. At 1x, zoom out and Back to 1x are dimmed.")}
${fig("wide-2x", "Wide view, at 2x", "Wide view hides the sidebar exactly as on TEMPLATE and ROCKER; the board re-frames for the wider window and keeps its 2x.")}
</div>
<div class="grid">
${fig("bottom-1x", "Bottom view, 1x", "The Bottom view button, at 1x: the whole board, nose left.")}
${fig("bottom-tail-4x", "The same, 4x on the tail", "Six wheel notches over the tail (each zooms toward the pointer), then a right-drag to bring it to the middle: the swallow's walls and points close up, in the same light as at 1x.")}
${fig("slid", "Slid aside, 1x", "A right-drag slides the board, following the pointer exactly; it can't be slid further than its centre reaching the window's edge. Back to 1x is live now, to undo the slide.")}
</div>
<h2>On an iPhone 14, upright</h2>
<div class="two"><div class="phones">
${fig("iphone-1x", "At 1x", "Nothing over the board: no zoom row (a pinch does the zooming) and no Wide view (there's no sidebar to hide).")}
${fig("iphone-3x", "After a two-finger pinch: 3x", "Only the level and Back to 1x draw, as on every other drawing on a phone.")}
</div><div class="note" style="padding:0"><b>What to look at.</b><br>1. The zoom row matches the other screens'. Zoomed in on the tail, the swallow's walls read close up, and the shading is the same zoomed as at 1x.<br>2. After the merge, on localhost:3005/design/3d: scroll to zoom toward the pointer, right-drag (or Shift-drag) to slide, double-click to come back to 1x. On your Mac's trackpad, pinch, in Safari and in Chrome.<br>3. On your iPhone and iPad: two fingers pinch and slide, one finger still turns, a double-tap comes back to 1x, and the page never scrolls from the drawing.<br>4. The keys, with the drawing clicked: + and − zoom, Shift with an arrow slides, 0 comes back to 1x.</div></div>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.evaluate(() => document.fonts.ready);
  const out = process.argv[2];
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

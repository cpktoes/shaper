// Plan 16-09's pictures for the founder: the Fish zoomed and slid on the real 3D screen (port 3209), Wide view, and an
// iPhone zoomed in. Run: npx playwright test -c <abs>/pictures.config.ts
import { expect, test, type Locator, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/lib/theme";
import { decodePng } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/e2e/helpers/canvas-pixels";

const OUT = __dirname + "/out";

function fishFields(): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === "Fish")!;
  const base = presetDesignFields(preset);
  return {
    ...base,
    rails: { ...base.rails, tailHardEdge: true },
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page) {
  const raw = openBoardCopyJson(fishFields(), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY] as const,
  );
}

async function ready(page: Page) {
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForFunction(() => {
    const el = document.querySelector("[data-viewer-zoom] button, [data-viewer-toolbar] button");
    return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
  });
  await page.waitForTimeout(1200);
  return host;
}

/** The board's box on the canvas (pixels unlike the ground near the top-left corner), in CSS dots. */
async function litBox(host: Locator) {
  const pic = decodePng(
    await host.screenshot({ scale: "css", style: "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }" }),
  );
  const at = (x: number, y: number) => 4 * (y * pic.width + x);
  const g = [pic.rgba[at(10, 10)], pic.rgba[at(10, 10) + 1], pic.rgba[at(10, 10) + 2]];
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (let y = 8; y < pic.height - 8; y++) {
    for (let x = 8; x < pic.width - 8; x++) {
      const i = at(x, y);
      if ([0, 1, 2].every((c) => Math.abs(pic.rgba[i + c] - g[c]) <= 12)) continue;
      left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
    }
  }
  return { left, right, top, bottom };
}

async function wheelNotches(page: Page, host: Locator, x: number, y: number, n: number) {
  const box = (await host.boundingBox())!;
  await page.mouse.move(box.x + x, box.y + y);
  for (let i = 0; i < n; i++) {
    await page.waitForTimeout(250);
    await page.mouse.wheel(0, -100);
  }
  await page.waitForTimeout(1500);
}

const desktop = { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 };

test("desktop", async ({ browser }, testInfo) => {
  test.skip(testInfo.project.name !== "shots");
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page);
  await page.goto("/design/3d");
  const host = await ready(page);
  await page.screenshot({ path: `${OUT}/desktop-1x.png` });

  // The Bottom view, then 4x on the tail: the swallow's two points and the hard edge's fade, close up.
  await page.getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true }).getByRole("button", { name: THREE_D_COPY.views.bottom, exact: true }).click();
  await page.waitForTimeout(2000);
  await host.screenshot({ path: `${OUT}/bottom-1x.png` });
  const box = await litBox(host);
  const tailX = box.right - (box.right - box.left) * 0.07;
  const midY = (box.top + box.bottom) / 2;
  await wheelNotches(page, host, tailX, midY, 6);
  await expect(page.locator("[data-viewer-zoom] [data-zoom-level]")).toHaveText("4x");
  // Then a right-drag that brings the tail toward the middle of the window (as far as the slide's hold allows).
  const tb = (await host.boundingBox())!;
  await page.mouse.move(tb.x + tailX, tb.y + midY);
  await page.mouse.down({ button: "right" });
  await page.mouse.move(tb.x + tb.width * 0.55, tb.y + tb.height / 2, { steps: 8 });
  await page.mouse.up({ button: "right" });
  await page.waitForTimeout(1500);
  await host.screenshot({ path: `${OUT}/bottom-tail-4x.png` });

  // Back to 1x, Reset View, then slid aside by a right-drag.
  await page.getByRole("button", { name: "Back to 1x — the whole drawing", exact: true }).click();
  await page.getByRole("button", { name: THREE_D_COPY.resetView, exact: true }).click();
  await page.waitForTimeout(1500);
  const hb = (await host.boundingBox())!;
  await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2);
  await page.mouse.down({ button: "right" });
  await page.mouse.move(hb.x + hb.width / 2 + 230, hb.y + hb.height / 2 - 150, { steps: 8 });
  await page.mouse.up({ button: "right" });
  await page.waitForTimeout(1500);
  await host.screenshot({ path: `${OUT}/slid.png` });

  // Wide view at 2x: the sidebar gone, the canvas wider, the level kept.
  await page.getByRole("button", { name: "Back to 1x — the whole drawing", exact: true }).click();
  await page.getByRole("button", { name: "Zoom in", exact: true }).click();
  await page.getByRole("button", { name: "Zoom in", exact: true }).click();
  await page.getByRole("button", { name: "Hide the sidebar for a wider view", exact: true }).click();
  await page.waitForTimeout(2000);
  await page.screenshot({ path: `${OUT}/wide-2x.png` });
  await context.close();
});

test("iphone", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone");
  await prepare(page);
  await page.goto("/design/3d");
  const host = await ready(page);
  await page.screenshot({ path: `${OUT}/iphone-1x.png` });
  // Two fingers spreading from 80 to 240 dots apart about the board's middle — fired inside the page, as the suite's
  // flick is, since the harness has no real fingers on WebKit.
  await host.evaluate(async (el) => {
    const b = el.getBoundingClientRect();
    const cx = b.left + b.width / 2;
    const cy = b.top + b.height / 2;
    const fire = (type: string, id: number, x: number) =>
      el.dispatchEvent(new PointerEvent(type, { pointerId: id, pointerType: "touch", isPrimary: id === 51, clientX: x, clientY: cy, bubbles: true, cancelable: true }));
    fire("pointerdown", 51, cx - 40);
    fire("pointerdown", 52, cx + 40);
    for (let i = 1; i <= 8; i++) {
      const d = 40 + (80 * i) / 8;
      fire("pointermove", 51, cx - d);
      fire("pointermove", 52, cx + d);
      await new Promise((r) => setTimeout(r, 30));
    }
    fire("pointerup", 51, cx - 120);
    fire("pointerup", 52, cx + 120);
  });
  await expect(page.locator("[data-viewer-zoom] [data-zoom-level]")).toHaveText("3x");
  await page.waitForTimeout(2500);
  await page.screenshot({ path: `${OUT}/iphone-3x.png` });
});

// Scratch config for plan 16-09's pictures: the repo's own config, this folder's spec, the worktree's dev server on 3209.
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09/playwright.config";
import { defineConfig, devices } from "@playwright/test";

const worktree = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ab6089b955f436b09";
const port = 3209;

export default defineConfig({
  ...base,
  testDir: __dirname,
  testIgnore: [],
  testMatch: ["shots.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 300_000,
  workers: 1,
  webServer: {
    ...(base.webServer as object),
    command: `npm run dev -- --port ${port}`,
    url: `http://localhost:${port}/design/outline`,
    cwd: worktree,
    env: { ...((base.webServer as { env: Record<string, string> }).env), IS_WEBPACK_TEST: "1" },
  },
  use: { ...base.use, baseURL: `http://localhost:${port}` },
  projects: [
    { name: "shots", use: { ...devices["Desktop Chrome"] } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
});

// Plan 16-11's pictures for the founder: the blank ghost, Contour Stripes, the four themes, the hand-set board's SHOW
// section and the loading picture, on the real 3D screen (port 3211). Run: npx playwright test -c <abs>/pictures.config.ts
// SHOTS=name1,name2 picks a few.
import { writeFileSync } from "node:fs";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ace9a504721143192/lib/theme";

const OUT = __dirname + "/out";

type View = "rest" | "side" | "bottom" | "turned" | "deck" | "nose" | "tail";
interface Case {
  name: string;
  preset: string;
  theme?: string;
  blank?: boolean;
  stripes?: boolean;
  handSet?: boolean;
  view?: View;
  /** Arrow presses after the view (15° each). */
  keys?: string[];
  /** Shoot the panel instead of the canvas. */
  panel?: boolean;
  /** Delay the scene's chunk and shoot the loading picture. */
  loading?: boolean;
  /** A stripe density candidate, degrees of slope per pair (dev server only). */
  slope?: number;
}

const CASES: Case[] = [
  { name: "fish-blank-rest", preset: "Fish", blank: true },
  { name: "fish-blank-side", preset: "Fish", blank: true, view: "side" },
  { name: "fish-blank-deck", preset: "Fish", blank: true, view: "deck" },
  { name: "longboard-blank-rest", preset: "Longboard", blank: true },
  { name: "fish-stripes-rest", preset: "Fish", stripes: true },
  { name: "fish-stripes-turned", preset: "Fish", stripes: true, keys: ["ArrowLeft", "ArrowLeft", "ArrowUp"] },
  { name: "shortboard-stripes-deck", preset: "Shortboard", stripes: true, view: "deck" },
  { name: "shortboard-stripes-bottom", preset: "Shortboard", stripes: true, view: "bottom" },
  { name: "fish-stripes-rest-6", preset: "Fish", stripes: true, slope: 6 },
  { name: "fish-stripes-turned-6", preset: "Fish", stripes: true, slope: 6, keys: ["ArrowLeft", "ArrowLeft", "ArrowUp"] },
  { name: "shortboard-stripes-deck-6", preset: "Shortboard", stripes: true, view: "deck", slope: 6 },
  { name: "fish-stripes-rest-9", preset: "Fish", stripes: true, slope: 9 },
  { name: "fish-stripes-turned-9", preset: "Fish", stripes: true, slope: 9, keys: ["ArrowLeft", "ArrowLeft", "ArrowUp"] },
  { name: "theme-daylight", preset: "Fish", theme: "daylight" },
  { name: "theme-chalk", preset: "Fish", theme: "chalk" },
  { name: "theme-slate", preset: "Fish", theme: "slate" },
  { name: "theme-phosphor", preset: "Fish", theme: "phosphor" },
  { name: "theme-slate-blank", preset: "Fish", theme: "slate", blank: true },
  { name: "theme-phosphor-stripes", preset: "Fish", theme: "phosphor", stripes: true },
  { name: "handset-panel", preset: "Fish", handSet: true, panel: true },
  { name: "fish-panel", preset: "Fish", panel: true },
  { name: "loading", preset: "Fish", loading: true },
];

function fields(c: Case): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === c.preset);
  if (!preset) throw new Error(`no ${c.preset}`);
  return {
    ...presetDesignFields(preset),
    ...(c.handSet ? { blank: null } : {}),
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page, c: Case) {
  const raw = openBoardCopyJson(fields(c), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey, theme]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, theme);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY, c.theme ?? "daylight"] as const,
  );
  if (c.slope) await page.addInitScript((deg) => ((window as { __shaper3dStripeSlopeDeg?: number }).__shaper3dStripeSlopeDeg = deg), c.slope);
}

async function ready(page: Page) {
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForFunction(() => {
    const el = document.querySelector("[data-viewer-zoom] button, [data-viewer-toolbar] button");
    return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
  });
  await page.waitForTimeout(1200);
  return host;
}

const HIDE_CHROME = "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }";

async function shot(host: Locator) {
  await host.page().waitForTimeout(1200);
  return host.screenshot({ scale: "css", style: HIDE_CHROME });
}

async function view(page: Page, name: Exclude<View, "rest" | "turned">) {
  await page.getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true }).getByRole("button", {
    name: THREE_D_COPY.views[name],
    exact: true,
  }).click();
  await page.waitForTimeout(1500);
}

test("probe-chunks", async ({ page }) => {
  test.skip(!process.env.PROBE, "probe only");
  const urls: string[] = [];
  page.on("request", (r) => {
    if (r.url().endsWith(".js") || r.url().includes(".js?")) urls.push(r.url());
  });
  await page.goto("/design/3d");
  await ready(page);
  writeFileSync(`${OUT}/chunks.txt`, urls.join("\n"));
});

const wanted = process.env.SHOTS?.split(",");
for (const c of CASES) {
  if (wanted && !wanted.includes(c.name)) continue;
  test(c.name, async ({ page }) => {
    await prepare(page, c);
    if (c.loading) {
      // Hold every script chunk the 3D screen fetches after the page is live, so the loading picture stays up.
      let live = false;
      await page.route("**/_next/static/**/*.js", async (route) => {
        if (live) await new Promise((r) => setTimeout(r, 4000));
        await route.continue();
      });
      await page.goto("/design/3d");
      await page.waitForLoadState("networkidle").catch(() => {});
      live = true;
      await page.reload();
      await page.waitForSelector("[data-loading-picture]", { timeout: 60_000 });
      await page.waitForTimeout(1300);
      const host = page.locator("[data-board-3d]").locator("..");
      writeFileSync(`${OUT}/${c.name}.png`, await host.screenshot({ style: HIDE_CHROME }));
      return;
    }
    await page.goto("/design/3d");
    const host = await ready(page);
    if (c.blank) await page.getByRole("checkbox", { name: THREE_D_COPY.blank, exact: true }).click();
    if (c.stripes) await page.getByRole("checkbox", { name: THREE_D_COPY.contourStripes, exact: true }).click();
    if (c.panel) {
      writeFileSync(`${OUT}/${c.name}.png`, await page.locator("[data-three-d-controls]").screenshot());
      return;
    }
    if (c.view && c.view !== "rest" && c.view !== "turned") await view(page, c.view);
    if (c.keys) {
      await host.focus();
      for (const k of c.keys) await page.keyboard.press(k);
      await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
      await page.waitForTimeout(800);
    }
    writeFileSync(`${OUT}/${c.name}.png`, await shot(host));
  });
}

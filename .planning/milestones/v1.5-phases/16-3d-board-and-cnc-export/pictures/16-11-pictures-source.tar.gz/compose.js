// Composes plan 16-11's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, cap) => `<figure><img src="${img(n)}"><figcaption>${cap}</figcaption></figure>`;
const section = (title, text, cols, figs) =>
  `<section><h3>${title}</h3><p>${text}</p><div class="row c${cols}">${figs.join("")}</div></section>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1500px;line-height:1.45}
section{padding:0 36px 24px}h3{font-size:19px;margin:6px 0 2px}section p{margin:0 0 10px;font-size:14px;color:#374151;line-height:1.45;max-width:1500px}
.row{display:grid;gap:14px;align-items:start}.c2{grid-template-columns:1fr 1fr}.c3{grid-template-columns:1fr 1fr 1fr}.c4{grid-template-columns:1fr 1fr 1fr 1fr}
.cp{grid-template-columns:320px 320px 1fr}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:6px 12px 8px;font-size:13px;color:#4b5563;border-top:1px solid #e5e1d6}
.note{font-size:15px;line-height:1.55;color:#374151;max-width:1500px;padding:4px 36px 36px}
</style></head><body>
<h1>Phase 16, plan 11: the blank, Contour Stripes, the four themes and the loading picture</h1>
<p class="lead">The real app at /design/3d, shot from this plan's own server. Lighting B in every theme, white foam everywhere. Both new
tick boxes start unticked; neither is saved, neither changes the board or the CNC files, and ticking either keeps the view exactly as it was.</p>
${section(
  "1. Blank — the picked blank as a see-through ghost round the board",
  "The blank the board sits in on ROCKER: its printed widths (the top view's line) and its prepared bottom and deck (the side view's), each station a plain rounded section with a one-dot line round its widest point. The veil is the muted ink at 18%, lit by the room's lights, drawn over the board without ever hiding it. The Fish's blank prints a width at its nose, so its nose is square; the Longboard's prints 0 and is drawn round. The framing stays the board's.",
  2,
  [
    fig("fish-blank-rest", "Fish, first view, Blank ticked"),
    fig("fish-blank-deck", "Fish, Deck view: the foam that comes off all round"),
    fig("fish-blank-side", "Fish, Side view: the blank's deck and bottom above and below the board's"),
    fig("longboard-blank-rest", "Longboard, first view: a round-nosed blank"),
  ],
)}
${section(
  "2. Contour Stripes — one dark-and-light pair for every 12° of slope (the starting density)",
  "The foam's shading is replaced by the reflections of a row of long tubes overhead in the room, running along the board's length. They stay put in the room, slide over the board as it turns, and bend where the shape bends: one broad band on a flat, a tight run on a rail, a kink at a bump or a flat spot. Fins and the ghost draw as usual; the stringer stays on top.",
  4,
  [
    fig("fish-stripes-rest", "Fish, first view"),
    fig("fish-stripes-turned", "Fish, turned 30° and tipped 15°"),
    fig("shortboard-stripes-deck", "Shortboard, Deck view"),
    fig("shortboard-stripes-bottom", "Shortboard, Bottom view: the flat bottom is one broad band"),
  ],
)}
${section(
  "2b. The same at finer densities, for comparison — 9° and 6° per pair",
  "Density is one number. Finer bands show more of the deck's shape at once; coarser bands read calmer. Say which you prefer, or another number.",
  4,
  [
    fig("fish-stripes-rest-9", "9° per pair, first view"),
    fig("fish-stripes-turned-9", "9° per pair, turned"),
    fig("fish-stripes-rest-6", "6° per pair, first view"),
    fig("fish-stripes-turned-6", "6° per pair, turned"),
  ],
)}
${section(
  "3. The four themes — white foam everywhere, the colours following the theme while the screen is open",
  "Switching the theme in App Default Settings with the 3D screen open repaints the ground, the stringer, the fins, the ghost and the stripes at once, with the turn, the zoom and the slide kept.",
  3,
  [
    fig("theme-daylight", "Daylight"),
    fig("theme-chalk", "Chalk"),
    fig("theme-slate", "Slate"),
    fig("theme-phosphor", "Phosphor"),
    fig("theme-slate-blank", "Slate, Blank ticked"),
    fig("theme-phosphor-stripes", "Phosphor, Contour Stripes"),
  ],
)}
${section(
  "4. The SHOW section, and the loading picture",
  "On a hand-set board (no blank picked on ROCKER) the Blank row is dimmed and can't be ticked, with its reason under it. Contour Stripes' line is always there. While the drawing's code is still on its way, the board's turned outline (the 3D tile's own drawing) stands in at the size the lit board will take, and after a second the line under it says so; the lit board then replaces it in one frame.",
  "p",
  [
    fig("handset-panel", "A hand-set board"),
    fig("fish-panel", "A board in a blank"),
    fig("loading", "Loading (the drawing's code held back on purpose)"),
  ],
)}
<div class="note"><b>Your four questions.</b> 1. Does the ghost read as the blank, glassy, showing the foam that comes off, without hiding the board?
2. Do the stripes read as a shaping check (bands bending where the shape bends) rather than decoration? Density is one number: 12° per pair to start, with 9° and 6° shown above.
3. The four themes: white foam everywhere, Phosphor included; the board's edge visible all round in Daylight and Chalk.
4. The hand-set board's Blank row is dimmed with its reason.</div>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.screenshot({ path: process.argv[2], fullPage: true });
  await browser.close();
})();

"""Plan 16-14: one picture of the five desktop reference pictures' differences, for the founder.

Each screen gets a row: on the left Playwright's own diff image (the whole 1280x800 screen at half size, every
changed pixel in red), on the right the top row before and after at full size, and a caption with the counts.
Below the top row a pixel only counts as moved when a colour channel changed by more than 2 levels — the
anti-aliased corners of FINS' sidebar cards flicker by one level between renders and are reported separately.

Usage: python3 compose_diffs.py <test-results dir> <output png>
"""
import glob
import os
import sys

from PIL import Image, ImageChops, ImageDraw, ImageFont

results, out = sys.argv[1], sys.argv[2]
SCREENS = [("outline", "TEMPLATE"), ("rocker", "ROCKER"), ("rails", "RAILS"), ("volume", "VOLUME"), ("fins", "FINS")]
ROW_TOP = 60  # the desktop top row ends above this line at 1280x800
CROP = (420, 18, 1020, 64)  # the six links, 3D and the chrome beside them

font = ImageFont.load_default(size=15)
small = ImageFont.load_default(size=13)
THUMB = (640, 400)
PAD = 16
crop_w, crop_h = CROP[2] - CROP[0], CROP[3] - CROP[1]
row_h = THUMB[1] + PAD * 2 + 22
width = PAD + THUMB[0] + PAD + crop_w + PAD
height = 70 + row_h * len(SCREENS)
sheet = Image.new("RGB", (width, height), (250, 250, 248))
draw = ImageDraw.Draw(sheet)
draw.text((PAD, 16), "Plan 16-14: the five desktop pictures, old against new (1280 x 800)", fill=(20, 20, 20), font=font)
draw.text(
    (PAD, 38),
    "Red marks every changed pixel. On every screen the change is the top row only: the six links a little to the left, 3D at the end.",
    fill=(60, 60, 60),
    font=small,
)

report = []
for index, (name, label) in enumerate(SCREENS):
    [expected] = glob.glob(os.path.join(results, "*", f"{name}-desktop-expected.png"))
    actual = expected.replace("-expected.png", "-actual.png")
    diff_png = expected.replace("-expected.png", "-diff.png")
    a = Image.open(expected).convert("RGB")
    b = Image.open(actual).convert("RGB")
    d = ImageChops.difference(a, b)
    pa, pb = a.load(), b.load()
    w, h = a.size
    in_row = moved = faint = 0
    for y in range(h):
        for x in range(w):
            p, q = pa[x, y], pb[x, y]
            if p == q:
                continue
            if y < ROW_TOP:
                in_row += 1
            elif max(abs(p[i] - q[i]) for i in range(3)) > 2:
                moved += 1
            else:
                faint += 1
    box = ImageChops.difference(a.crop((0, 0, w, ROW_TOP)), b.crop((0, 0, w, ROW_TOP))).getbbox()
    report.append((label, in_row, box, moved, faint))

    top = 70 + index * row_h
    caption = f"{label}: {in_row} pixels changed in the top row (x {box[0]}-{box[2]}, y {box[1]}-{box[3]}); below it, {moved} moved"
    if faint:
        caption += f" ({faint} anti-aliased corner pixels flickered by one colour level)"
    draw.text((PAD, top), caption, fill=(20, 20, 20), font=small)
    thumb = Image.open(diff_png).convert("RGB").resize(THUMB, Image.LANCZOS)
    sheet.paste(thumb, (PAD, top + 22))
    draw.rectangle((PAD - 1, top + 21, PAD + THUMB[0], top + 22 + THUMB[1]), outline=(180, 180, 180))
    cx = PAD + THUMB[0] + PAD
    draw.text((cx, top + 22), "Before (the six links)", fill=(60, 60, 60), font=small)
    sheet.paste(a.crop(CROP), (cx, top + 40))
    draw.text((cx, top + 40 + crop_h + 10), "After (3D at the end)", fill=(60, 60, 60), font=small)
    sheet.paste(b.crop(CROP), (cx, top + 58 + crop_h + 10))
    draw.text((cx, top + 58 + crop_h * 2 + 20), "Changed pixels in the top row", fill=(60, 60, 60), font=small)
    sheet.paste(Image.open(diff_png).convert("RGB").crop(CROP), (cx, top + 76 + crop_h * 2 + 20))

sheet.save(out)
for row in report:
    print(row)

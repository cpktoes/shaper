"""List the changed pixels below the top row for one picture, with old and new colours.
Usage: python3 below_row.py <test-results dir> <name>
"""
import glob
import os
import sys

from PIL import Image

results, name = sys.argv[1], sys.argv[2]
[expected] = glob.glob(os.path.join(results, "*", f"{name}-desktop-expected.png"))
a = Image.open(expected).convert("RGB")
b = Image.open(expected.replace("-expected.png", "-actual.png")).convert("RGB")
pa, pb = a.load(), b.load()
w, h = a.size
for y in range(60, h):
    for x in range(w):
        if pa[x, y] != pb[x, y]:
            print(x, y, pa[x, y], pb[x, y])

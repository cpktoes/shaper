"""Plan 16-14: compare each desktop picture's old (expected) and new (actual) renders pixel by pixel and report
where every changed pixel sits, so the re-record happens only if they all sit in the top row.

Usage: python3 -I analyse_diffs.py <test-results dir>
"""
import glob
import os
import sys

from PIL import Image, ImageChops

results = sys.argv[1]
for name in ["outline", "rocker", "rails", "volume", "fins"]:
    [expected] = glob.glob(os.path.join(results, "*", f"{name}-desktop-expected.png"))
    actual = expected.replace("-expected.png", "-actual.png")
    a = Image.open(expected).convert("RGB")
    b = Image.open(actual).convert("RGB")
    assert a.size == b.size, (name, a.size, b.size)
    diff = ImageChops.difference(a, b).convert("L").point(lambda v: 255 if v else 0)
    box = diff.getbbox()
    count = sum(1 for v in diff.getdata() if v)
    below = 0
    if box:
        w, h = a.size
        px = diff.load()
        below = sum(1 for y in range(60, h) for x in range(w) if px[x, y])
    print(f"{name}: size {a.size}, changed pixels {count}, bounding box {box}, changed pixels below y=60: {below}")

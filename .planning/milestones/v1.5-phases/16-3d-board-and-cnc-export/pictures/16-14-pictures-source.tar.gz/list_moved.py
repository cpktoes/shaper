"""List pixels below the top row that changed by more than 2 colour levels, plus where the faint ones cluster.
Usage: python3 list_moved.py <old png> <new png>
"""
import sys
from collections import Counter
from PIL import Image

a = Image.open(sys.argv[1]).convert("RGB")
b = Image.open(sys.argv[2]).convert("RGB")
pa, pb = a.load(), b.load()
w, h = a.size
faint = Counter()
for y in range(60, h):
    for x in range(w):
        p, q = pa[x, y], pb[x, y]
        if p == q:
            continue
        delta = max(abs(p[i] - q[i]) for i in range(3))
        if delta > 2:
            print("moved", x, y, p, q, delta)
        else:
            faint[(x // 40 * 40, y // 40 * 40)] += 1
print("faint by 40-dot cell:", sorted(faint.items()))

"""Compare each old committed picture with its re-recorded file: changed pixels in the top row, and below it.
Usage: python3 compare_recorded.py <old dir> <new dir>
"""
import sys
from PIL import Image

old, new = sys.argv[1], sys.argv[2]
for name in ["outline", "rocker", "rails", "volume", "fins"]:
    f = f"{name}-desktop-desktop-darwin.png"
    a = Image.open(f"{old}/{f}").convert("RGB")
    b = Image.open(f"{new}/{f}").convert("RGB")
    pa, pb = a.load(), b.load()
    w, h = a.size
    row = moved = faint = 0
    for y in range(h):
        for x in range(w):
            p, q = pa[x, y], pb[x, y]
            if p == q:
                continue
            if y < 60:
                row += 1
            elif max(abs(p[i] - q[i]) for i in range(3)) > 2:
                moved += 1
            else:
                faint += 1
    print(f"{name}: top row {row}, below moved {moved}, below one-level flicker {faint}")

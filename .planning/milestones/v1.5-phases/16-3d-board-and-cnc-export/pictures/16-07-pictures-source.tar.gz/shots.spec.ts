// Plan 16-07's pictures for the founder: the Fish turned to each view on the real 3D screen (port 3207), and the
// panel's Hard Edge and View sections. Run: npx playwright test -c <abs>/pictures.config.ts
import { expect, test, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/geometry/presets";
import { VIEW_NAMES, VIEW_TURNS, type Quat } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/geometry/view-3d";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a819b872ae634fafc/lib/theme";

const OUT = __dirname + "/out";

function fieldsOf(presetName: string, hardEdge = true): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === presetName)!;
  const base = presetDesignFields(preset);
  return {
    ...base,
    rails: { ...base.rails, tailHardEdge: hardEdge },
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page, fields: DesignSnapshotFields) {
  const raw = openBoardCopyJson(fields, { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY] as const,
  );
}

const isTurn = (got: number[], want: Quat) =>
  got.every((v, i) => Math.abs(v - want[i]) <= 1e-3) || got.every((v, i) => Math.abs(v + want[i]) <= 1e-3);

const desktop = { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 };

test("views", async ({ browser }) => {
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page, fieldsOf("Fish"));
  await page.goto("/design/3d");
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${OUT}/full-first.png` });
  await host.screenshot({ path: `${OUT}/view-first.png` });
  await page.locator("[data-three-d-controls]").screenshot({ path: `${OUT}/panel-on.png` });
  const group = page.getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true });
  for (const name of VIEW_NAMES) {
    await group.getByRole("button", { name: THREE_D_COPY.views[name], exact: true }).click();
    await expect
      .poll(async () => isTurn(((await host.getAttribute("data-turn")) ?? "").split(" ").map(Number), VIEW_TURNS[name]), {
        timeout: 30_000,
      })
      .toBe(true);
    await page.waitForTimeout(1200);
    await host.screenshot({ path: `${OUT}/view-${name}.png` });
  }
  // A turn by hand: a drag a quarter of the shorter side right and an eighth down, from the first view.
  await group.getByRole("button", { name: THREE_D_COPY.resetView, exact: true }).click();
  await expect.poll(async () => isTurn(((await host.getAttribute("data-turn")) ?? "").split(" ").map(Number), [0, 0, 0, 1]), { timeout: 30_000 }).toBe(true);
  await page.waitForTimeout(800);
  const box = (await host.boundingBox())!;
  const short = Math.min(box.width, box.height);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width / 2 + short / 8, box.y + box.height / 2 + short / 10, { steps: 6 });
  await page.mouse.up();
  await page.waitForTimeout(2000);
  await host.screenshot({ path: `${OUT}/view-dragged.png` });
  await context.close();
});

test("panel-off", async ({ browser }) => {
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page, fieldsOf("Fish", false));
  await page.goto("/design/3d");
  await expect(page.locator("[data-three-d-hard-edge]")).toHaveAttribute("data-three-d-hard-edge", "off", { timeout: 120_000 });
  await expect(page.locator("[data-board-3d]")).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForTimeout(800);
  await page.locator("[data-three-d-controls]").screenshot({ path: `${OUT}/panel-off.png` });
  await context.close();
});

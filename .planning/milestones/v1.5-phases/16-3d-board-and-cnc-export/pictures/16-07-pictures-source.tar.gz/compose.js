// Composes plan 16-07's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, title, text) => `<figure><img src="${img(n)}"><figcaption><b>${title}</b>${text}</figcaption></figure>`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 22px;font-size:16px;color:#4b5563;max-width:1480px;line-height:1.45}
h2{font-size:19px;margin:8px 36px 12px}
.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px 20px;padding:0 36px 28px}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:10px 14px 12px;font-size:14px;line-height:1.4;border-top:1px solid #e5e1d6}
figcaption b{display:block;font-size:15px;margin-bottom:2px}
.panels{display:flex;gap:24px;align-items:flex-start;padding:0 36px 36px}.panels figure{width:340px;flex:none}
.note{font-size:14px;line-height:1.55;color:#374151;max-width:640px;padding-top:6px}
</style></head><body>
<h1>Phase 16, plan 07: turning the 3D board, the five views, and the hard edge on the 3D panel</h1>
<p class="lead">The real app at /design/3d, 1280 × 800, Daylight: the Fish as its card opens it, each view picked with its button. The camera and the lights never move; only the board turns, so the light rakes differently across the foam in every view. Each view turns the board the short way round in 0.4 s and fits it back to 1x, centred. (Each board picture is the drawing area only.)</p>
<h2>The first view and the five preset views</h2>
<div class="grid">
${fig("view-first", "First view (Reset View)", "Flat, deck up, nose left, seen from 50° above: what the screen opens with.")}
${fig("view-deck", "Deck", "The deck square on, nose left: exactly TEMPLATE's outline lying nose-left (a test proves it vertex by vertex). The stringer runs straight across.")}
${fig("view-side", "Side", "The near rail square on, deck up, nose left: exactly ROCKER's side view, the rocker and the deck line.")}
${fig("view-bottom", "Bottom", "Turned over along its length, nose left; the swallow's two points. The flat bottom is lit flatter than the domed deck.")}
${fig("view-nose", "Nose", "End on from the nose, deck up. The lifted nose is nearest you, so it looms; the stringer runs from the nose tip down the deck.")}
${fig("view-tail", "Tail", "End on from the tail, deck up: the swallow's wide, thin tail nearest you, the stringer at the crotch.")}
</div>
<h2>Turned by hand, and the panel</h2>
<div class="panels">
${fig("view-dragged", "A drag from the first view", "A short drag right and down: the board rolls toward you and swings its nose, under the same fixed lights.")}
${fig("panel-on", "The panel, Hard Edge on", "HARD EDGE: RAILS' own two rows over the same two values (D-30). VIEW: Deck · Bottom · Side, Nose · Tail, Reset View.")}
${fig("panel-off", "The panel, Hard Edge off", "The two rows stay in place, dimmed and out of reach, under one line of reason.")}
</div>
<div class="panels"><div class="note"><b>What to look at.</b><br>1. Deck looks like TEMPLATE lying nose-left; Side looks like ROCKER's side view; Bottom shows the bottom and the swallow's two pieces; Nose and Tail are end on, deck up.<br>2. After the merge, on localhost:3005/design/3d: drag the board around (the light rakes across it as it turns, and it glides to a stop when you let go), press the view buttons, press Reset View.<br>3. On your iPad or iPhone: one finger turns the board and the page never scrolls from the drawing.<br>4. The HARD EDGE rows: move Hard Edge Ends At on 3D, then open RAILS' tail Advanced menu; it reads the same distance, and the other way round.</div></div>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.evaluate(() => document.fonts.ready);
  const out = process.argv[2];
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

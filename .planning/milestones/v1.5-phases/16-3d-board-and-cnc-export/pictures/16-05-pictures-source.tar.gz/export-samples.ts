// Scratch (16-05, Task 2/3): writes the four presets' CNC zips (as their cards open them), times cncZip with the
// surface build (median of 7 after a warm-up), and dumps the Fish's zip READ BACK through the readers for the picture.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <abs this> <abs worktree> <abs out dir>
import { writeFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const C = await import(`${ROOT}/lib/export/cnc-files`);
  const Z = await import(`${ROOT}/lib/export/zip`);
  const X = await import(`${ROOT}/lib/export/dxf`);
  const T = await import(`${ROOT}/lib/export/xyz`);
  const L = await import(`${ROOT}/lib/export/stl`);
  const rows: string[] = [];
  rows.push("| Preset | Zip | Size | Slices | DXF | STL (triangles) | Text set | cncZip ms (median of 7) |");
  rows.push("|---|---|---:|---:|---:|---:|---:|---:|");
  const kb = (n: number) => `${(n / 1024 / 1024).toFixed(2)} MB`;
  for (const preset of P.BOARD_PRESETS) {
    const fields = PB.presetDesignFields(preset);
    const build = () => {
      const geometry = O.buildOutline(fields.outline);
      const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
      const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, true);
      const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
      const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
      return { zip: C.cncZip(surface, preset.name), surface, sections, rails };
    };
    build();
    const times: number[] = [];
    let last = build();
    for (let k = 0; k < 7; k++) {
      const t0 = performance.now();
      last = build();
      times.push(performance.now() - t0);
    }
    times.sort((a, b) => a - b);
    const { zip, surface, sections, rails } = last;
    writeFileSync(join(OUT, "zips", zip.name), zip.data);
    const entries = Z.readZip(zip.data);
    const size = (suffix: RegExp) => entries.filter((e: any) => suffix.test(e.name)).reduce((n: number, e: any) => n + e.data.length, 0);
    const stl = L.readStl(entries.find((e: any) => e.name.endsWith(".stl")).data);
    rows.push(
      `| ${preset.name} | \`${zip.name}\` | ${kb(zip.data.length)} (${zip.data.length.toLocaleString("en-US")} B) | ${zip.sliceCount} | ${kb(size(/\.dxf$/))} | ${kb(size(/\.stl$/))} (${stl.count.toLocaleString("en-US")}) | ${(size(/\.txt$/) / 1024).toFixed(0)} KB | ${times[3].toFixed(0)} |`,
    );
    console.log(preset.name, zip.name, zip.data.length, "slices", zip.sliceCount, "ms", times.map((t) => t.toFixed(0)).join(","), "crc", entries.every((e: any) => e.crcOk), "tail", fields.outline.tail.kind, "hard", rails.tailHardEdge, "litres", V.computeCrossSectionVolume(sections).volumeLitres.toFixed(3), "mesh", (S.enclosedVolumeMm3(surface) / 1e6).toFixed(3));
    if (preset.id === "fish") {
      const dec = new TextDecoder();
      const text = (name: string) => dec.decode(entries.find((e: any) => e.name === name).data);
      const dxf = X.readDxf(text(`${preset.name}.dxf`));
      const slicesText = entries.filter((e: any) => /-slice-\d+\.txt$/.test(e.name)).map((e: any) => ({ name: e.name, loops: T.readXyz(dec.decode(e.data)) }));
      writeFileSync(
        join(OUT, "fish-readback.json"),
        JSON.stringify({
          zipName: zip.name,
          zipBytes: zip.data.length,
          sliceCount: zip.sliceCount,
          header: dxf.header,
          layers: dxf.polylines.map((p: any) => ({ layer: p.layer, flags: p.flags, points: p.points })),
          outlineTxt: T.readXyz(text(`${preset.name}-outline.txt`)),
          profileTxt: T.readXyz(text(`${preset.name}-profile.txt`)),
          slicesText,
          stlCount: stl.count,
          stlHeader: stl.header,
          files: entries.map((e: any) => ({ name: e.name, bytes: e.data.length, crcOk: e.crcOk })),
          length: surface.length,
        }),
      );
    }
  }
  writeFileSync(join(OUT, "sizes.md"), rows.join("\n") + "\n");
  console.log(rows.join("\n"));
})();

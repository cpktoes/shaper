// Scratch (16-05, Task 3): draws what is inside the Fish's CNC zip, READ BACK through the app's own readers
// (fish-readback.json from export-samples.ts): the DXF's outline from above, its deck and bottom lines from the side,
// every slice end on, and the zip's file list. SVG in a page, rendered by headless Chromium (no server, no port).
// node compose-files-inside.js <abs dir holding fish-readback.json> <abs output png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const out = process.argv[3];
const d = JSON.parse(fs.readFileSync(path.join(dir, "fish-readback.json"), "utf8"));

const layer = (name) => d.layers.filter((p) => p.layer === name);
const outline = layer("OUTLINE")[0];
const deck = layer("PROFILE-DECK")[0];
const bottom = layer("PROFILE-BOTTOM")[0];
const sliceLoops = layer("SLICES");
const W = 1480;
const pad = 20;
const L = d.length;

// The slices grouped as the files hold them (one file = one slice, one or two loops).
const slices = d.slicesText.map((s) => ({ name: s.name, loops: s.loops, x: s.loops[0][0][0] }));

const poly = (pts, fx, fy, closed, attrs) =>
  `<${closed ? "polygon" : "polyline"} points="${pts.map((p) => `${fx(p).toFixed(2)},${fy(p).toFixed(2)}`).join(" ")}" ${attrs}/>`;

// 1. From above: x along, y across (true scale).
const maxY = Math.max(...outline.points.map((p) => Math.abs(p[1])));
const s1 = (W - 2 * pad) / L;
const h1 = 2 * maxY * s1 + 2 * pad;
const top = `<svg width="${W}" height="${h1.toFixed(0)}" viewBox="0 0 ${W} ${h1.toFixed(0)}">
${slices.map((s) => `<line x1="${(pad + s.x * s1).toFixed(2)}" x2="${(pad + s.x * s1).toFixed(2)}" y1="${pad}" y2="${(h1 - pad).toFixed(2)}" stroke="#c9c2b3" stroke-width="1"/>`).join("")}
${poly(outline.points, (p) => pad + p[0] * s1, (p) => h1 / 2 - p[1] * s1, true, 'fill="#f3efe6" stroke="#1f2a37" stroke-width="2"')}
<text x="${pad}" y="${h1 - 4}" font-size="12" fill="#6b7280">tail, x = 0</text><text x="${W - pad}" y="${h1 - 4}" font-size="12" fill="#6b7280" text-anchor="end">nose, x = ${L.toFixed(0)} mm</text>
</svg>`;

// 2. From the side: x along, z up — drawn 4x taller than true so the rocker reads.
const EX = 4;
const maxZ = Math.max(...deck.points.map((p) => p[2]));
const h2 = maxZ * s1 * EX + 2 * pad + 10;
const fy2 = (p) => h2 - pad - p[2] * s1 * EX;
const side = `<svg width="${W}" height="${h2.toFixed(0)}" viewBox="0 0 ${W} ${h2.toFixed(0)}">
<line x1="${pad}" x2="${W - pad}" y1="${fy2([0, 0, 0]).toFixed(2)}" y2="${fy2([0, 0, 0]).toFixed(2)}" stroke="#c9c2b3" stroke-dasharray="4 4"/>
${poly(deck.points, (p) => pad + p[0] * s1, fy2, false, 'fill="none" stroke="#b45309" stroke-width="2.5"')}
${poly(bottom.points, (p) => pad + p[0] * s1, fy2, false, 'fill="none" stroke="#1d4ed8" stroke-width="2.5"')}
<text x="${W - pad}" y="${(fy2([0, 0, 0]) + 14).toFixed(0)}" font-size="12" fill="#6b7280" text-anchor="end">z = 0, the bottom's lowest point</text>
</svg>`;

// 3. End on: every slice overlaid (y across, z up, true scale), tail slices warm, nose slices cool.
const maxZs = Math.max(...sliceLoops.flatMap((p) => p.points.map((q) => q[2])));
const minZs = Math.min(...sliceLoops.flatMap((p) => p.points.map((q) => q[2])));
const s3 = Math.min(700 / (2 * maxY), 260 / (maxZs - minZs));
const w3 = 2 * maxY * s3 + 2 * pad;
const h3 = (maxZs - minZs) * s3 + 2 * pad;
const colour = (i, n) => `hsl(${(20 + (200 * i) / Math.max(1, n - 1)).toFixed(0)} 70% 42%)`;
const endOn = `<svg width="${w3.toFixed(0)}" height="${h3.toFixed(0)}" viewBox="0 0 ${w3.toFixed(0)} ${h3.toFixed(0)}">
${slices.map((s, i) => s.loops.map((loop) => poly(loop, (p) => w3 / 2 + p[1] * s3, (p) => h3 - pad - (p[2] - minZs) * s3, true, `fill="none" stroke="${colour(i, slices.length)}" stroke-width="1.2" stroke-opacity="0.85"`)).join("")).join("\n")}
</svg>`;

// 4. Every slice file on its own, in file order (01 nearest the tail), each to its own scale.
const cell = (s, i) => {
  const pts = s.loops.flat();
  const ys = pts.map((p) => p[1]);
  const zs = pts.map((p) => p[2]);
  const spanY = Math.max(...ys) - Math.min(...ys) || 1;
  const spanZ = Math.max(...zs) - Math.min(...zs) || 1;
  const cw = 170;
  const ch = 70;
  const k = Math.min((cw - 16) / spanY, (ch - 16) / spanZ);
  const cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  const cz = (Math.max(...zs) + Math.min(...zs)) / 2;
  const svg = `<svg width="${cw}" height="${ch}">${s.loops
    .map((loop, j) => poly(loop, (p) => cw / 2 + (p[1] - cy) * k, (p) => ch / 2 - (p[2] - cz) * k, true, `fill="${j ? "#dbeafe" : "#fde7c7"}" stroke="${colour(i, slices.length)}" stroke-width="1.3"`))
    .join("")}</svg>`;
  const nn = s.name.match(/-slice-(\d+)\.txt$/)[1];
  return `<div class="cell">${svg}<div class="lab"><b>${nn}</b> · x ${s.x.toFixed(0)} mm${s.loops.length === 2 ? " · <span class='two'>2 pieces</span>" : ""}</div></div>`;
};

const f = d.files;
const sliceFiles = f.filter((e) => /-slice-\d+\.txt$/.test(e.name));
const kb = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(2)} MB` : `${(n / 1024).toFixed(1)} KB`);
const twoPiece = slices.filter((s) => s.loops.length === 2).length;
const list = `<table>
<tr><th>File in ${d.zipName}</th><th>Size</th><th>What it holds (as read back)</th></tr>
${f.slice(0, 4).map((e) => `<tr><td>${e.name}</td><td>${kb(e.bytes)}</td><td>${
  e.name.endsWith(".dxf") ? `R12 DXF, $ACADVER ${d.header.$ACADVER}, $INSUNITS ${d.header.$INSUNITS} (mm): ${d.layers.length} polylines — OUTLINE 1, PROFILE-DECK 1, PROFILE-BOTTOM 1, SLICES ${sliceLoops.length}`
  : e.name.endsWith(".stl") ? `binary STL, ${d.stlCount.toLocaleString("en-US")} triangles, header “${d.stlHeader}”`
  : e.name.endsWith("-outline.txt") ? `${d.outlineTxt[0].length} points, one closed outline`
  : `deck line ${d.profileTxt[0].length} points, a blank line, bottom line ${d.profileTxt[1].length} points`}</td></tr>`).join("")}
<tr><td>${sliceFiles[0].name} … ${sliceFiles[sliceFiles.length - 1].name}</td><td>${kb(Math.min(...sliceFiles.map((e) => e.bytes)))} – ${kb(Math.max(...sliceFiles.map((e) => e.bytes)))} each</td><td>${sliceFiles.length} slice files, one per litres station with foam, from the tail; ${twoPiece === 1 ? "slice 01 holds two pieces (the only litres station inside the notch)" : `the first ${twoPiece} hold two pieces (inside the notch)`}</td></tr>
<tr><td><b>${f.length} files, every CRC ${f.every((e) => e.crcOk) ? "good" : "BAD"}</b></td><td><b>${kb(d.zipBytes)}</b></td><td>the zip itself, stored (no compression)</td></tr>
</table>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1560px;padding:0 40px 30px;box-sizing:border-box}
h1{font-size:26px;margin:26px 0 6px}p.lead{margin:0 0 14px;font-size:16px;color:#4b5563;line-height:1.45}
h2{font-size:17px;margin:18px 0 6px}h2 small{font-weight:400;color:#6b7280;font-size:14px}
.row{display:flex;gap:30px;align-items:flex-start}
.grid{display:grid;grid-template-columns:repeat(8,170px);gap:8px 10px}
.cell{border:1px solid #e5e1d6;border-radius:6px;background:#fbfaf7}.lab{font-size:11px;padding:0 6px 4px;color:#374151}.two{color:#1d4ed8}
table{border-collapse:collapse;font-size:13.5px}td,th{border-bottom:1px solid #e5e1d6;padding:5px 10px;text-align:left;vertical-align:top}th{background:#f3efe6}
.key{font-size:13px;color:#4b5563}.sw{display:inline-block;width:22px;height:3px;vertical-align:middle;margin:0 4px}
</style></head><body>
<h1>Phase 16, plan 05 — what is inside the Fish's CNC zip</h1>
<p class="lead">Every line below was drawn from <b>${d.zipName}</b> after reading it back through the app's own readers (the zip, then the DXF and the text files), not from the 3D board directly. So this is what Shape3D would be handed: the Fish as its card opens (swallow, Hard Edge on), in millimetres, tail at x = 0, deck up, the bottom's lowest point at z = 0. Fins and the blank are never in the files.</p>
<h2>The DXF's OUTLINE, from above <small>— true scale; the grey lines are where the ${slices.length} slices sit</small></h2>
${top}
<h2>The DXF's PROFILE-DECK and PROFILE-BOTTOM, from the side <small>— drawn ${EX}× taller than true so the rocker reads</small></h2>
<div class="key"><span class="sw" style="background:#b45309"></span>deck line &nbsp; <span class="sw" style="background:#1d4ed8"></span>bottom line</div>
${side}
<div class="row" style="margin-top:8px">
<div><h2>All ${slices.length} slices, end on <small>— true scale, tail warm → nose cool</small></h2>${endOn}</div>
<div style="flex:1"><h2>The zip's files</h2>${list}</div>
</div>
<h2>Each slice file on its own <small>— in file order from the tail, each to its own scale; two pieces where the notch is</small></h2>
<div class="grid">${slices.map(cell).join("")}</div>
</body></html>`;
fs.writeFileSync(path.join(dir, "compose-files-inside.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1560, height: 900 }, deviceScaleFactor: 1 });
  await page.setContent(html);
  await page.screenshot({ path: out, fullPage: true });
  await browser.close();
  console.log("wrote", out);
})();

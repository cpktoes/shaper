| Preset | Zip | Size | Slices | DXF | STL (triangles) | Text set | cncZip ms (median of 7) |
|---|---|---:|---:|---:|---:|---:|---:|
| Shortboard | `Shortboard-3d.zip` | 4.75 MB (4,979,223 B) | 50 | 0.72 MB | 3.78 MB (79,184) | 257 KB | 112 |
| Fish | `Fish-3d.zip` | 4.49 MB (4,704,086 B) | 49 | 0.70 MB | 3.53 MB (74,062) | 253 KB | 141 |
| Mid-length | `Mid-length-3d.zip` | 5.30 MB (5,562,631 B) | 49 | 0.71 MB | 4.33 MB (90,900) | 257 KB | 164 |
| Longboard | `Longboard-3d.zip` | 6.09 MB (6,386,135 B) | 50 | 0.74 MB | 5.09 MB (106,656) | 267 KB | 152 |

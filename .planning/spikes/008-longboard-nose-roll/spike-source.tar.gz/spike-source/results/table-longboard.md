| Trial | Back as a concave with a roll | Roll and depth within 1/16" | Depth within 1/16" | Written roll vs roll back (correlation) | No other cut | Stray centre/tail cut | Bottom widest / typical mm | Rails widest / typical mm | Read rails first | Invented rolls (roll 0) | False concaves | Mean open s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Today | 15 of 48 | 5 | 26 | -0.06 | 12 | 6 | 1.07 / 0.12 | 4.99 / 0.67 | 43 of 48 | 4 of 12 | 0 of 12 | 13.6 |
| T1 | 16 of 48 | 5 | 26 | 0.04 | 13 | 6 | 1.07 / 0.12 | 4.99 / 0.67 | 43 of 48 | 4 of 12 | 0 of 12 | 9.9 |
| T1b | 16 of 48 | 3 | 25 | 0.10 | 13 | 6 | 1.07 / 0.12 | 4.99 / 0.67 | 43 of 48 | 4 of 12 | 0 of 12 | 9.9 |
| T2 | 27 of 48 | 9 | 26 | 0.00 | 23 | 6 | 1.14 / 0.12 | 4.98 / 0.67 | 43 of 48 | 2 of 12 | 0 of 12 | 14.3 |
| T4 | 26 of 48 | 9 | 26 | 0.11 | 22 | 6 | 1.14 / 0.12 | 4.98 / 0.67 | 43 of 48 | 1 of 12 | 0 of 12 | 14.2 |
| T3a | 30 of 48 | 6 | 16 | 0.11 | 0 | 46 | 2.43 / 0.46 | 5.29 / 0.91 | 1 of 48 | 9 of 12 | 0 of 12 | 16.2 |
| T3b | 11 of 48 | 4 | 32 | -0.13 | 8 | 5 | 1.07 / 0.12 | 4.98 / 0.67 | 43 of 48 | 1 of 12 | 0 of 12 | 20.1 |
| T3a+T3b | 30 of 48 | 6 | 16 | 0.11 | 0 | 45 | 2.41 / 0.46 | 5.29 / 0.90 | 1 of 48 | 9 of 12 | 0 of 12 | 17.6 |

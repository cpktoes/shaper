Spike 008 (longboard-nose-roll): scripts, the trial code and raw outputs (2026-11-26). The founder's .brd files are not in here.

trial-code.diff   against main f8cecca8 (lib/geometry/brd-bottom.ts, lib/export/brd-fit-preview.ts). With no S8_ switch set it is
                  today's code exactly (74 Longboards and the twelve files identical). It also exports bottomOn, liftedStep and
                  settleLook from brd-fit-preview.ts for the probes. Switches: S8_T1=1|2, S8_JUDGE=whole|nose, S8_T3=wide|iter|wide+iter.
scripts/          board.mts (one app board written to .brd, shared), grid.mts (spike 007 / v2f's grid, logs __s8; NOT= excludes),
                  run-grid.sh, run-trials.sh, run-twelve.sh, measure.mts (twelve files, logs __s8), plain.mts (plain presets),
                  probe1..5.mts (the Investigation Trail), picdata.mts + picture.cjs (longboard-nose.png), time8.mts (paired
                  open times), analyze.mjs, same.mjs, realdiff.mjs, findingb.mjs (v2f's), table.mjs, lbroll.mjs, s8stats.mjs,
                  judged.mjs, replay-t4g.mjs.
results/          lb-<trial>.*.jsonl (74 Longboards per trial), oth-<trial>.*.jsonl (222 other boards), v2f-after.*.jsonl (quick
                  v2f's after-run = today), t12-<trial>.json (twelve files: names, figures, digests, the trial log), plain-*.json,
                  probe*.txt, times-*.log/json, table-longboard.md, lbroll.txt, realdiff-*.txt, same-*.txt, trials-*.log.

// Spike 007: scores one or more grid runs. node analyze.mjs <label> [<label>...] [--detail <label>]
import { readFileSync, readdirSync } from "node:fs";
const OUT = new URL("../out/", import.meta.url);
const CONCAVES = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
export const load = (label) => readdirSync(OUT).filter((f) => f.startsWith(label + ".") && f.endsWith(".jsonl")).flatMap((f) => readFileSync(new URL(f, OUT), "utf8").trim().split("\n").filter(Boolean).map((l) => JSON.parse(l)));
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN);
const f2 = (v) => (Number.isFinite(v) ? v.toFixed(2) : "-");
const f3 = (v) => (Number.isFinite(v) ? v.toFixed(3) : "-");
export function score(rows, filter = () => true) {
  const R = rows.filter((r) => r.kind === "roll" && filter(r));
  const N = rows.filter((r) => r.kind === "noroll" && filter(r));
  const B = rows.filter((r) => r.kind === "belly" && filter(r));
  const isConc = (r) => CONCAVES.includes(r.back[0].name);
  const hasRoll = (r) => r.back[0].roll > 0.005;
  const both = R.filter((r) => isConc(r) && hasRoll(r));
  const rollErr = both.map((r) => Math.abs(r.back[0].roll - r.wrote.nose.roll));
  const depthErr = both.map((r) => Math.abs(r.back[0].depth - r.wrote.nose.depth));
  const close16 = both.filter((r) => Math.abs(r.back[0].roll - r.wrote.nose.roll) <= 1 / 16 + 1e-6 && Math.abs(r.back[0].depth - r.wrote.nose.depth) <= 1 / 16 + 1e-6);
  const close32 = both.filter((r) => Math.abs(r.back[0].roll - r.wrote.nose.roll) <= 1 / 32 + 1e-6 && Math.abs(r.back[0].depth - r.wrote.nose.depth) <= 1 / 32 + 1e-6);
  const clean = both.filter((r) => r.back[1].depth === 0 && r.back[2].depth === 0);
  const stray = R.filter((r) => r.back[1].depth > 0 || r.back[2].depth > 0);
  const bellyOnly = B.filter((r) => !CONCAVES.includes(r.wrote.nose.name));
  const falseConc = bellyOnly.filter((r) => isConc(r));
  const mixed = B.filter((r) => CONCAVES.includes(r.wrote.nose.name));
  return {
    roll: R.length, concave: R.filter(isConc).length, sameKind: R.filter((r) => r.back[0].name === r.wrote.nose.name).length,
    concaveRoll: both.length, close16: close16.length, close32: close32.length, clean: clean.length, stray: stray.length,
    rollErr: mean(rollErr), depthErr: mean(depthErr), widest: mean(R.map((r) => r.largest)), worst: Math.max(...R.map((r) => r.largest)), typical: mean(R.map((r) => r.typical)),
    rails: mean(R.map((r) => r.rails?.[0] ?? NaN)), secs: mean(R.map((r) => r.secs)),
    noroll: N.length, invented: N.filter(hasRoll).length, norollConc: N.filter(isConc).length, norollWidest: mean(N.map((r) => r.largest)), norollSecs: mean(N.map((r) => r.secs)),
    belly: bellyOnly.length, falseConc: falseConc.length, falseIds: falseConc.map((r) => r.id), mixed: mixed.length, mixedRoll: mixed.filter(hasRoll).length, mixedLostBelly: mixed.filter((r) => r.back[1].depth === 0).length,
    bellyWidest: mean(B.map((r) => r.largest)), bellySecs: mean(B.map((r) => r.secs)),
  };
}
const line = (label, s) => `| ${label} | ${s.concaveRoll}/${s.roll} | ${s.close16} | ${s.close32} | ${s.clean} | ${s.stray} | ${s.sameKind} | ${f3(s.rollErr)}" | ${f3(s.depthErr)}" | ${f2(s.widest)} / ${f2(s.typical)} (worst ${f2(s.worst)}) | ${f2(s.rails)} | ${s.invented}/${s.noroll} | ${s.falseConc}/${s.belly} | ${s.mixedRoll}/${s.mixed} | ${f2(s.secs)} / ${f2(s.norollSecs)} / ${f2(s.bellySecs)} |`;
if (process.argv[1].endsWith("analyze.mjs")) {
  const args = process.argv.slice(2);
  const di = args.indexOf("--detail");
  const labels = di >= 0 ? args.slice(0, di) : args;
  console.log("| run | concave+roll back | roll & depth within 1/16\" | within 1/32\" | with no other cut | rows with a stray centre/tail cut | same concave name | mean roll err | mean depth err | bottom widest / typical mm | rails widest | invented rolls (roll 0 boards) | false concaves (belly boards) | rolls on concave+belly boards | secs roll / noroll / belly |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|");
  for (const label of labels) {
    const rows = load(label);
    console.log(line(label + ` (${rows.length})`, score(rows)));
    if (process.env.BY) for (const b of ["shortboard", "midlength", "fish", "longboard"]) console.log(line(`  ${label} ${b}`, score(rows, (r) => r.board === b)));
    const s = score(rows);
    if (s.falseIds.length) console.log("   false concaves:", s.falseIds.join(", "));
  }
  if (di >= 0) {
    for (const r of load(args[di + 1]).sort((a, b) => a.id.localeCompare(b.id))) {
      if (args[di + 2] && !r.id.includes(args[di + 2])) continue;
      console.log(`${r.id.padEnd(46)} ${r.back.map((k) => `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")}${k.depth ? " " + k.depth.toFixed(3) : ""}${k.roll ? " r" + k.roll.toFixed(3) : ""}`).join(" · ")}  ${r.largest.toFixed(2)}/${r.typical.toFixed(2)} rails ${r.rails?.join("/")} ${r.order === "rails-first" ? "RF" : "bf"} ${r.secs}s ${r.log?.kept ?? ""}`);
    }
  }
}

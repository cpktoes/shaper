// Plan-time check (quick 261125-v2f): the planned unit slice through the real import (brdLookFromBytes), timed one by one.
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut, cutKind } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const IN = 25.4;
const SL: [string, string, string | null, number, number, string | null, number][] = [
  // board, nose name, depth/16, roll/16, centre name, centre depth/16
  ["midlength", "Blended Nose Concave", null, 3, 2, null, 0],
  ["fish", "Blended Nose Concave", null, 2, 1, null, 0],
  ["midlength", "Teardrop Nose Concave", null, 2, 2, null, 0],
  ["midlength", "Slight Single Concave Entry", null, 3, 2, null, 0],
  ["midlength", "Slight Single Concave Entry", null, 3, 4, null, 0],
  ["midlength", "Blended Nose Concave", null, 4, 4, null, 0],
  ["shortboard", "Blended Nose Concave", null, 3, 1, null, 0],
  ["midlength", "Flat Entry", null, 0, 0, "Continuous Belly / Rolled Mid", 2],
  ["midlength", "Rolled Belly Entry", null, 2, 0, null, 0],
  ["shortboard", "Blended Nose Concave", null, 3, 0, null, 0],
  ["midlength", "Blended Nose Concave", null, 3, 0, null, 0],
  ["fish", "Blended Nose Concave", null, 3, 0, null, 0],
];
const w = (c: any) => `${c.name}${c.depth > 0 ? ` ${(c.depth / IN * 64).toFixed(1)}/64` : ""}${c.railRoll ? ` roll ${(c.railRoll / IN * 64).toFixed(1)}/64` : ""}`;
let total = 0;
for (const [bd, nose, , d, r, ctr, cd] of SL) {
  const fields = phase16Boards().find((b: any) => b.label === `${bd}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: any = structuredClone(DEFAULT_BOTTOM);
  if (d > 0) { bottom.nose = { ...startingCut("nose", nose, board), depth: inchesToMm(d / 16) }; if (r > 0) bottom.nose.railRoll = inchesToMm(r / 16); }
  if (ctr) bottom.center = { ...startingCut("center", ctr, board), depth: inchesToMm(cd / 16) };
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  const t0 = performance.now();
  const res = brdLookFromBytes(bytes, "x.brd");
  const secs = (performance.now() - t0) / 1000; total += secs;
  const b = res.look.bottom;
  const n = b.bottom.nose;
  const okRoll = r > 0 ? (cutKind(n.name) === "single" && (n.railRoll ?? 0) > 0 && Math.abs((n.railRoll ?? 0) - inchesToMm(r / 16)) <= inchesToMm(1 / 16) && Math.abs(n.depth - inchesToMm(d / 16)) <= inchesToMm(1 / 16)) : null;
  const clean = b.bottom.center.depth === 0 && b.bottom.tail.depth === 0 && cutKind(b.bottom.center.name) === "flat" && cutKind(b.bottom.tail.name) === "flat";
  console.log(`${`${bd} ${nose} ${d}/16 roll ${r}/16${ctr ? ` + ${ctr} ${cd}/16` : ""}`.padEnd(62)} -> ${[b.bottom.nose, b.bottom.center, b.bottom.tail].map(w).join(" · ")}  ${b.closeness.largest.toFixed(3)}/${b.closeness.typical.toFixed(3)}  within16=${okRoll} clean=${clean} openedRoll=${res.fields?.bottom?.nose?.railRoll === n.railRoll} ${secs.toFixed(2)}s`);
}
console.log("total", total.toFixed(1), "s");

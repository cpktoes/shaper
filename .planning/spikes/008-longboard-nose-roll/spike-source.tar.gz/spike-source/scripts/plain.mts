// Spike 008: the plain boards (no cut at all) of every preset through the real import, under whatever S8_ switches are set:
// the cuts, the figures and one digest (fitted cuts, measured sections, fitted rails), so a trial can be shown to leave them alone.
//   ROOT=<wt> npx --no-install tsx --tsconfig ./tsconfig.json plain.mts <label>
import { createHash } from "node:crypto";
import { writeFileSync, mkdirSync } from "node:fs";
import { build, imp, IN } from "./board.mts";
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const rows: any[] = [];
for (const board of ["longboard", "shortboard", "midlength", "fish"]) {
  const w = build({ board });
  const t0 = performance.now();
  const r = brdLookFromBytes(w.bytes, "x.brd");
  const secs = (performance.now() - t0) / 1000;
  const b = r.look.bottom, ra = r.look.rails;
  const digest = createHash("sha1").update(JSON.stringify({ cuts: [b.bottom.nose, b.bottom.center, b.bottom.tail], ours: b.sections.map((s: any) => [s.station, s.ours, s.gap]), rails: ra ? [ra.rails, ra.closeness] : null })).digest("hex").slice(0, 16);
  const row = { board, cuts: [b.bottom.nose, b.bottom.center, b.bottom.tail].map((c: any) => `${c.name}${c.depth ? " " + (c.depth / IN * 64).toFixed(1) + "/64" : ""}`), widest: +b.closeness.largest.toFixed(3), typical: +b.closeness.typical.toFixed(3), rails: ra ? [+ra.closeness.largest.toFixed(2), +ra.closeness.typical.toFixed(2)] : null, order: ra?.order, secs: +secs.toFixed(2), digest };
  rows.push(row);
  console.log(JSON.stringify(row));
}
mkdirSync(new URL("../out/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../out/plain-${process.argv[2] ?? "run"}.json`, import.meta.url), JSON.stringify(rows, null, 1));

import { readFileSync, readdirSync } from "node:fs";
const R = process.argv[2];
const load = (p) => readdirSync(R).filter((f) => f.startsWith(p + ".") && f.endsWith(".jsonl")).flatMap((f) => readFileSync(`${R}/${f}`, "utf8").trim().split("\n").map((l) => JSON.parse(l)));
const base = new Map(load("base").map((r) => [r.id, r]));
const hyb = load("hyb");
const fmt = (r) => r.back.map((k) => `${k.name.replace(/ Nose Concave| Single Concave Entry| \/ Rolled Mid/,"")}${k.depth ? " d" + (k.depth*64).toFixed(1) : ""}${k.roll ? " r" + (k.roll*64).toFixed(1) : ""}`).join(" | ") + ` ${r.largest}/${r.typical} ${r.secs}s`;
for (const r of hyb.sort((a,b)=>a.id.localeCompare(b.id))) {
  const b = base.get(r.id);
  let ok = "";
  if (r.kind === "roll") {
    const [nm, d, rr] = r.id.split("|").slice(1);
    const D = Number(d.slice(1)) / 16, RR = Number(rr.slice(1)) / 16;
    const n = r.back[0];
    const isC = ["Teardrop Nose Concave","Blended Nose Concave","Slight Single Concave Entry"].includes(n.name);
    const within = isC && n.roll > 0 && Math.abs(n.roll - RR) <= 1/16 + 1e-6 && Math.abs(n.depth - D) <= 1/16 + 1e-6;
    const clean = r.back[1].depth === 0 && r.back[2].depth === 0 && r.back[1].name.startsWith("Flat") && r.back[2].name.startsWith("Flat");
    ok = `${isC && n.roll > 0 ? "C+R" : "---"} ${within ? "W16" : "---"} ${clean ? "CLEAN" : "-----"} sameName=${n.name===nm}`;
  }
  console.log(`${r.id.padEnd(48)} ${ok}\n    hyb : ${fmt(r)} kept=${r.log?.kept} trig=${r.log?.triggered} over=${r.log?.overGate}\n    base: ${b ? fmt(b) : "?"}`);
}

// Quick 261125-v2f: are two runs the same, board by board?
//   node same.mjs <labelA> <labelB>
// Two grid runs (../out/<label>.*.jsonl): by board id, the three fitted cuts (name, depth, roll, Off Rail, stations, to the
// figures grid.mts writes), the widest and typical bottom miss and the rails' figures. Two twelve-file runs (../out/<label>.json,
// from measure.mts): by file, the digest (fitted cuts, every measured section value and the fitted rails). Prints every board or
// file that differs and a count. Timing is never compared.
import { existsSync, readFileSync, readdirSync } from "node:fs";
const OUT = new URL("../out/", import.meta.url);
const [a, b] = process.argv.slice(2);
if (!a || !b) throw new Error("usage: node same.mjs <labelA> <labelB>");
const twelve = (label) => existsSync(new URL(`${label}.json`, OUT));
if (twelve(a) && twelve(b)) {
  const A = new Map(JSON.parse(readFileSync(new URL(`${a}.json`, OUT), "utf8")).map((r) => [r.file, r]));
  const B = JSON.parse(readFileSync(new URL(`${b}.json`, OUT), "utf8"));
  let differ = 0;
  for (const r of B) {
    const o = A.get(r.file);
    if (!o) { console.log(`${r.file}: not in ${a}`); differ++; continue; }
    if (o.digest !== r.digest) {
      differ++;
      console.log(`${r.file}: DIFFERS  ${o.cuts.join(" · ")} ${o.widest}/${o.typical} rails ${o.rails}  ->  ${r.cuts.join(" · ")} ${r.widest}/${r.typical} rails ${r.rails}`);
    }
  }
  console.log(`${B.length} files compared, ${differ} differ (${a} -> ${b})`);
} else {
  const load = (label) =>
    readdirSync(OUT)
      .filter((f) => f.startsWith(label + ".") && f.endsWith(".jsonl"))
      .flatMap((f) => readFileSync(new URL(f, OUT), "utf8").trim().split("\n").filter(Boolean).map((l) => JSON.parse(l)));
  const key = (r) => JSON.stringify({ back: r.back, largest: r.largest, typical: r.typical, rails: r.rails, order: r.order, openedRoll: r.openedRoll });
  const A = new Map(load(a).map((r) => [r.id, r]));
  const B = load(b);
  let differ = 0;
  for (const r of B) {
    const o = A.get(r.id);
    if (!o) { console.log(`${r.id}: not in ${a}`); differ++; continue; }
    if (key(o) !== key(r)) {
      differ++;
      const w = (x) => x.back.map((k) => `${k.name}${k.depth ? ` ${k.depth}` : ""}${k.roll ? ` r${k.roll}` : ""}`).join(" · ") + ` ${x.largest}/${x.typical}`;
      console.log(`${r.id}: ${w(o)}  ->  ${w(r)}`);
    }
  }
  console.log(`${B.length} boards compared (${A.size} in ${a}), ${differ} differ (${a} -> ${b})`);
}

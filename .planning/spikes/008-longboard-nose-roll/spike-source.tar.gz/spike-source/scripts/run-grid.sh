#!/bin/bash
# Quick 261125-v2f: spike 007's round-trip grid (296 of the app's own boards written to .brd and opened again through the real
# import, brdLookFromBytes) in N shards at once, then waits for all of them. Writes ../out/<label>.<shard>.jsonl and .log.
#   <this folder>/scripts/run-grid.sh <checkout root> <label> [shards, default 6] [first shard, default 0] [last shard + 1]
# Shards first..last-1 run in parallel; to stay inside one call's time limit on a busy machine, run 0..3 and then 3..6.
# Call it by its absolute path. It never changes directory: the archive's root is read off its own path.
here="${0%/scripts/*}"
root=$1
label=$2
n=${3:-6}
first=${4:-0}
last=${5:-$n}
if [ -z "$root" ] || [ -z "$label" ]; then echo "usage: run-grid.sh <checkout root> <label> [shards] [first] [last]" >&2; exit 2; fi
mkdir -p "$here/out"
for ((i = first; i < last; i++)); do
  (ROOT="$root" npx --no-install tsx --tsconfig "$root/tsconfig.json" "$here/scripts/grid.mts" "$label" "$i" "$n" all > "$here/out/$label.$i.log" 2>&1) &
done
wait
echo "done $label shards $first..$((last - 1)) of $n: $(cat "$here"/out/"$label".*.jsonl 2>/dev/null | wc -l | tr -d ' ') boards so far (296 when every shard is done)"

// Spike 008: paired open times. One process; each board opened under each trial's switches in turn (the trial code reads
// process.env on every call), fastest of REPS, so every trial is timed back to back with today on the same machine load.
// Boards are the app's own (ids as grid.mts) and, with FILES=1, the founder's twelve (read in place, never copied).
//   ROOT=<wt> REPS=3 [FILES=1] npx --no-install tsx --tsconfig ./tsconfig.json time8.mts <out.json> "id;id;..."
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { execSync } from "node:child_process";
import { build, parseId, imp } from "./board.mts";
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const MODES: Record<string, Record<string, string>> = { today: {}, T1: { S8_T1: "1" }, T4: { S8_JUDGE: "nose" }, T3b: { S8_T3: "iter" } };
const KEYS = ["S8_T1", "S8_JUDGE", "S8_T3"];
const reps = Number(process.env.REPS ?? 3);
const items: { name: string; bytes: Uint8Array }[] = [];
for (const id of (process.argv[3] ?? "").split(";").filter(Boolean)) items.push({ name: id, bytes: build(parseId(id)).bytes });
if (process.env.FILES) {
  const DL = homedir() + "/Downloads";
  for (const f of readdirSync(DL).filter((f) => f.endsWith(".brd") && !f.includes("_decrypt") && f !== "test-curves-v2.brd").filter((f) => !process.env.ONLY || process.env.ONLY.split(",").some((w) => f.includes(w))).sort()) items.push({ name: f, bytes: new Uint8Array(readFileSync(DL + "/" + f)) });
}
const set = (m: string) => { for (const k of KEYS) delete process.env[k]; Object.assign(process.env, MODES[m]); };
brdLookFromBytes(items[0].bytes, "x.brd");
const rows: any[] = [];
for (const it of items) {
  const row: any = { name: it.name, load: execSync("uptime").toString().trim().replace(/.*averages: /, "") };
  for (const m of Object.keys(MODES)) {
    set(m);
    let best = Infinity;
    for (let r = 0; r < reps; r++) { const t0 = performance.now(); brdLookFromBytes(it.bytes, "x.brd"); best = Math.min(best, (performance.now() - t0) / 1000); }
    row[m] = +best.toFixed(2);
  }
  set("today");
  rows.push(row);
  console.log(JSON.stringify(row));
}
writeFileSync(process.argv[2], JSON.stringify(rows, null, 1));

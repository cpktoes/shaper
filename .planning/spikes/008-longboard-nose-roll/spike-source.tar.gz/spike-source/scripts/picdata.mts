// Spike 008: the picture's data. For each case, three nose sections (about 2", 8" and 16" back from the tip): the written file's
// half (and the same board written with no roll), and the finished half that opens (our bottom with our rails standing on it),
// under whatever S8_ switches are set. Also where the bottom reading stops, the written concave's edge, and the cuts.
//   ROOT=<wt> [S8_...] CASES="a;b" npx --no-install tsx --tsconfig ./tsconfig.json picdata.mts <out.json>
import { writeFileSync } from "node:fs";
import { build, parseId, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const out: any[] = [];
for (const id of (process.env.CASES ?? "").split(";")) {
  const spec = parseId(id);
  const w = build(spec);
  const board = readAnyBrd(w.bytes).board;
  const b0 = readAnyBrd(build({ ...spec, nose: spec.nose ? [spec.nose[0], spec.nose[1], 0] : undefined }).bytes).board;
  const look = P.brdFitLook(board);
  const L = board.length;
  const lines = P.brdRailLines(board).lines, lines0 = P.brdRailLines(b0).lines;
  const onBoard = R.brdRailBoard(look.fit, look.bottom.bottom, look.fins?.spec);
  const secs: any[] = [];
  for (const want of [2, 8, 16]) {
    const l = lines.reduce((a: any, c: any) => (Math.abs(L - c.station - want * IN) < Math.abs(L - a.station - want * IN) ? c : a));
    const l0 = lines0.reduce((a: any, c: any) => (Math.abs(c.station - l.station) < Math.abs(a.station - l.station) ? c : a));
    const bs = look.bottom.sections.find((s: any) => Math.abs(s.station - l.station) < 1);
    secs.push({ fromNose: (L - l.station) / IN, file: l.points, file0: l0.points, ours: R.brdOurRailHalf(onBoard, look.rails.rails, l.station), window: bs?.window ?? null, edge: w.board.railAt(l.station) - (w.bottom.nose.offRail ?? 0) });
  }
  const k = (c: any) => ({ name: c.name, depth: c.depth / IN, roll: (c.railRoll ?? 0) / IN });
  out.push({ id, order: look.rails.order, cuts: [k(look.bottom.bottom.nose), k(look.bottom.bottom.center), k(look.bottom.bottom.tail)], bottom: [look.bottom.closeness.largest, look.bottom.closeness.typical], rails: [look.rails.closeness.largest, look.rails.closeness.typical], secs });
  console.log(id, look.rails.order, JSON.stringify(out.at(-1).cuts));
}
writeFileSync(process.argv[2], JSON.stringify(out));

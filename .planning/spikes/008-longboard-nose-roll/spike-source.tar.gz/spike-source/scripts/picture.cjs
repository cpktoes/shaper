// Spike 008: longboard-nose.png. node picture.cjs <today.json> <trial.json> <trial label> <out.png>
// Rows: one Longboard each; columns: about 2", 8" and 16" back from the nose tip. Each panel is the outer part of the half
// section, bottom and rail together: the written file (black), the same board written with NO roll (grey, dotted), what opens
// today (blue, dashed) and with the trial (orange). Ticks mark the written concave's edge (Off Rail) and where the bottom
// reading stops (today). Heights are mm above the stringer's bottom; across is inches out from the stringer.
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [aFile, bFile, trialLabel, outFile] = process.argv.slice(2);
const A = JSON.parse(fs.readFileSync(aFile)), B = JSON.parse(fs.readFileSync(bFile));
const INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", NOROLL = "#9a9892", TODAY = "#2a78d6", TRIAL = "#eb6834";
const IN = 25.4;
const frac = (inch) => { const n = Math.round(inch * 64); if (!n) return "0"; let a = n, b = 64; while (a % 2 === 0 && b > 1) { a /= 2; b /= 2; } return `${a}/${b}"`; };
const words = (cuts) => cuts.filter((k) => k.depth > 0).map((k) => `${k.name.replace(" / Rolled Mid", "")} ${frac(k.depth)}${k.roll > 0.004 ? `, Rail Roll ${frac(k.roll)}` : ""}`).join(" + ") || "flat";
const under = (pts) => { let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k; return pts.slice(0, apex + 1).concat(pts.slice(apex + 1).filter((p) => p[1] < pts[apex][1] + 25)); };
function panel(s, t, W, H) {
  const reach = Math.max(...s.file.map((p) => p[0]));
  const x0 = Math.max(0, reach - 4 * IN);
  const clip = (pts) => under(pts).filter((p) => p[0] >= x0 - 2);
  const all = [...clip(s.file), ...clip(s.ours), ...clip(t.ours)];
  const lo = Math.min(...all.map((p) => p[1])) - 1, hi = Math.min(Math.max(...all.map((p) => p[1])), lo + 26) + 1;
  const L = 40, R = 10, T = 26, Bm = 30;
  const sx = (W - L - R) / (reach + 0.1 * IN - x0), sy = (H - T - Bm) / (hi - lo), k = Math.min(sx, sy * 1);
  const x = (v) => L + (v - x0) * sx, y = (v) => T + (hi - v) * sy;
  const path = (pts) => clip(pts).map((p, j) => `${j ? "L" : "M"}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join("");
  let g = "";
  for (let v = Math.ceil(lo / 5) * 5; v <= hi; v += 5) g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="${GRID}"/><text x="${L - 4}" y="${y(v) + 4}" text-anchor="end" class="t">${v}</text>`;
  for (let i = Math.ceil(x0 / IN); i <= reach / IN; i++) g += `<text x="${x(i * IN)}" y="${H - Bm + 14}" text-anchor="middle" class="t">${i}"</text>`;
  const mark = (v, c, lab, dy) => (v > x0 ? `<line x1="${x(v)}" x2="${x(v)}" y1="${T}" y2="${H - Bm}" stroke="${c}" stroke-dasharray="2 3"/><text x="${x(v) + 3}" y="${T + dy}" class="t" fill="${c}">${lab}</text>` : "");
  return `<svg width="${W}" height="${H}"><text x="${L}" y="14" class="h">${s.fromNose.toFixed(1)}" back from the nose tip</text>${g}
  ${mark(s.edge, INK, "concave's edge", 10)}${s.window ? mark(s.window, TODAY, "bottom read to", 24) : ""}
  <path d="${path(s.file0)}" fill="none" stroke="${NOROLL}" stroke-width="1.6" stroke-dasharray="1.5 3"/>
  <path d="${path(s.ours)}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(t.ours)}" fill="none" stroke="${TRIAL}" stroke-width="2"/>
  <path d="${path(s.file)}" fill="none" stroke="${INK}" stroke-width="1.4"/></svg>`;
}
const W = 330, H = 230;
let rows = "";
for (const a of A) {
  const b = B.find((q) => q.id === a.id);
  const [board, name, d, r] = a.id.split("|");
  rows += `<div class="row"><div class="cap"><b>Longboard, ${name} ${frac(+d.slice(1) / 16)} with a ${frac(+r.slice(1) / 16)} Rail Roll written</b><br>
  <span style="color:${TODAY}">Today: ${words(a.cuts)} (bottom ${a.bottom[0].toFixed(2)} / ${a.bottom[1].toFixed(2)} mm, rails ${a.rails[0].toFixed(2)} / ${a.rails[1].toFixed(2)})</span><br>
  <span style="color:${TRIAL}">${trialLabel}: ${words(b.cuts)} (bottom ${b.bottom[0].toFixed(2)} / ${b.bottom[1].toFixed(2)} mm, rails ${b.rails[0].toFixed(2)} / ${b.rails[1].toFixed(2)})</span></div>
  ${a.secs.map((s, i) => panel(s, b.secs[i], W, H)).join("")}</div>`;
}
const html = `<html><head><style>body{font:13px -apple-system,Helvetica,sans-serif;color:${INK};margin:16px;background:#fff}.t{font-size:10px;fill:${SUB}}.h{font-size:12px;font-weight:600;fill:${INK}}.row{margin-bottom:14px}.cap{margin:4px 0 2px 40px;line-height:1.45}</style></head><body>
<div style="font-size:15px;font-weight:600;margin-left:40px">The Longboard's nose rail, written and opened again (outer 4" of the half section, bottom and rail)</div>
<div style="margin:4px 0 10px 40px;color:${SUB}">Black: the written file. Grey dotted: the same board written with no Rail Roll. Blue dashed: what opens today. Orange: ${trialLabel}.<br>Heights in mm above the stringer's bottom; across in inches out from the stringer.</div>${rows}</body></html>`;
(async () => { const br = await chromium.launch(); const p = await br.newPage({ viewport: { width: 40 + 3 * W + 40, height: 400 } }); await p.setContent(html); await p.screenshot({ path: outFile, fullPage: true }); await br.close(); console.log("wrote", outFile); })();

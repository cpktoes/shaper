// Spike 008, probe 4 (the oracle): after the real import, put the WRITTEN nose (or the written roll on the fitted concave) on
// the board that opens, refit the rails from where they stood (as brdFitLook does), and measure: is the truth closer to the
// file? If the finished section cannot tell the written roll from none, no judge can bring it back.
//   ROOT=<wt> CASES="..." npx --no-install tsx --tsconfig ./tsconfig.json probe4.mts
import { build, parseId, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const B = await imp("lib/geometry/brd-bottom.ts");
const { fitBoardToBrd } = await imp("lib/geometry/brd-fit.ts");
const { mm } = await imp("lib/geometry/units.ts");
const f2 = (v: number) => v.toFixed(2);
const cut1 = (k: any) => `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")}${k.depth ? " " + (k.depth / IN * 64).toFixed(1) + "/64" : ""}${k.railRoll ? " r" + (k.railRoll / IN * 64).toFixed(1) + "/64" : ""}`;
for (const id of (process.env.CASES ?? "").split(";")) {
  const w = build(parseId(id));
  const board = readAnyBrd(w.bytes).board;
  const L = board.length;
  const t0 = performance.now();
  const look = P.brdFitLook(board);
  const secs = (performance.now() - t0) / 1000;
  const lines = { length: board.length, outline: board.outline, bottom: board.bottom, deck: board.deck };
  const first = fitBoardToBrd(lines);
  const fins = look.fins?.spec;
  const board0 = B.brdFittedBottomBoard(first, fins);
  const { lines: railLines } = P.brdRailLines(board);
  const nose = railLines.filter((l: any) => l.station >= L / 2);
  const evalBottom = (bottom: any, label: string) => {
    const t1 = performance.now();
    const step = P.liftedStep(board, lines, first, fins, board0, bottom, look.bottom.sections);
    const onBoard = R.brdRailBoard(step.fit, step.bottom.bottom, fins);
    const settings = R.fitBrdRails(railLines, onBoard, look.rails.settings);
    const rails = R.measureBrdRails(railLines, onBoard, settings, { order: look.rails.order, read: look.rails.read, narrowed: look.rails.narrowed, blend: look.rails.blend });
    const wholeNose = R.brdRailWholeValue(nose, onBoard, rails.rails);
    const whole = R.brdRailWholeValue(railLines, onBoard, rails.rails);
    const railNose = (() => { let lg = 0, s = 0; for (const sec of rails.sections) if (sec.station >= L / 2) { lg = Math.max(lg, sec.gap.largest); s += sec.gap.mean; } return { lg, m: s / rails.sections.filter((x: any) => x.station >= L / 2).length }; })();
    console.log(`  ${label.padEnd(26)} ${["nose", "center", "tail"].map((k) => cut1(bottom[k])).join(" · ").padEnd(46)} bottom ${f2(step.bottom.closeness.largest)}/${f2(step.bottom.closeness.typical)}  rails ${f2(rails.closeness.largest)}/${f2(rails.closeness.typical)} (worst ${((L - rails.closeness.station) / IN).toFixed(1)}" from nose, ${rails.closeness.where}, ${(rails.closeness.inFromRail / IN).toFixed(2)}" in)  rails-nose ${f2(railNose.lg)}/${f2(railNose.m)}  whole-nose ${f2(wholeNose.largest)}/${f2(wholeNose.mean)}  whole ${f2(whole.largest)}/${f2(whole.mean)}  [${((performance.now() - t1) / 1000).toFixed(1)}s]`);
  };
  console.log(`\n=== ${id}  order ${look.rails?.order}  open ${secs.toFixed(1)}s`);
  const got = look.bottom.bottom;
  evalBottom(got, "as opened");
  const wn = w.bottom.nose;
  if (wn.name !== "Flat Entry") {
    evalBottom({ ...got, nose: { ...wn } }, "written nose");
    evalBottom({ ...got, nose: { ...wn, railRoll: undefined } }, "written nose, no roll");
    if ((got.nose.depth ?? 0) > 0) for (const r of [1, 2, 3, 4, 6]) evalBottom({ ...got, nose: { ...got.nose, railRoll: mm((r / 16) * IN) } }, `opened concave, roll ${r}/16`);
  }
}

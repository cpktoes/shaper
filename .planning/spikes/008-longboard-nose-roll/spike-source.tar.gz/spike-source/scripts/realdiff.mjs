// Spike 007: two real grid runs case by case: boards whose widest miss grew, roll-0 boards that came back with a roll,
// belly boards that came back with a nose concave, and what the mixed (nose concave + centre belly) boards did.
//   node realdiff.mjs <today label> <trial label>
import { load } from "./analyze.mjs";
const [aL, bL] = process.argv.slice(2);
const A = new Map(load(aL).map((r) => [r.id, r])), B = load(bL);
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const frac = (inch) => { const n = Math.round(inch * 64); if (!n) return "0"; let a = n, b = 64; while (a % 2 === 0 && b > 1) { a /= 2; b /= 2; } return `${a}/${b}"`; };
const w = (c) => c.filter((k) => k.depth > 0).map((k) => `${k.name.replace(" / Rolled Mid", "")} ${frac(k.depth)}${k.roll > 0.004 ? `, Rail Roll ${frac(k.roll)}` : ""}`).join(" + ") || "Flat";
const line = (a, b) => `| ${b.id} | ${w(a.back)}; ${a.largest.toFixed(2)} / ${a.typical.toFixed(2)} | ${w(b.back)}; ${b.largest.toFixed(2)} / ${b.typical.toFixed(2)} |`;
const sec = (title, f) => { const L = B.filter((b) => f(A.get(b.id), b)); console.log(`\n${title}: ${L.length}\n| Board | Today | Trial |\n|---|---|---|`); for (const b of L) console.log(line(A.get(b.id), b)); };
sec("Widest miss grew by more than 0.005 mm", (a, b) => b.largest - a.largest > 0.005);
sec("Roll-0 boards with a roll back (either run)", (a, b) => b.kind === "noroll" && (a.back[0].roll > 0.004 || b.back[0].roll > 0.004));
sec("Belly boards (no nose concave written) back with a nose concave (either run)", (a, b) => b.kind === "belly" && !CONC.includes(b.wrote.nose.name) && (CONC.includes(a.back[0].name) || CONC.includes(b.back[0].name)));
sec("Belly boards that changed at all", (a, b) => b.kind === "belly" && (w(a.back) !== w(b.back) || Math.abs(a.largest - b.largest) > 0.005));

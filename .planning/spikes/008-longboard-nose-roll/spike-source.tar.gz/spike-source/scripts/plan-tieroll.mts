// Plan-time check: does requiring the tie's winner to carry a roll above 0 change any of spike 007's 296 boards (hyb run)?
import { readFileSync, readdirSync } from "node:fs";
const ROOT = process.env.ROOT!;
const { cutKind } = await import(`${ROOT}/lib/geometry/bottom.ts`);
const R = process.argv[2];
const rows = readdirSync(R).filter((f) => f.startsWith("hyb.") && f.endsWith(".jsonl")).flatMap((f) => readFileSync(`${R}/${f}`, "utf8").trim().split("\n").map((l) => JSON.parse(l)));
const EXTRA = 0.25, NOISE = 1e-9, TIE = 0.05;
let tried = 0, diff = 0, tieUsed = 0, tieNoRoll = 0, mismatch = 0;
for (const r of rows) {
  const L = r.log; if (!L || !L.triggered || !L.cands?.length) continue;
  tried++;
  const today = L.today; const nk = cutKind(today.cuts[0].name), ck = cutKind(today.cuts[1].name);
  const centreLift = ck === "belly" || ck === "vee";
  const cutsToday = today.cuts.filter((c: any) => cutKind(c.name) !== "flat").length;
  const judged = today.largest + today.typical;
  const pick = (needRoll: boolean) => {
    const ok = L.cands.filter((c: any) => {
      const replaces = (nk === "belly" && cutKind(c.cuts[0].name) === "single") || (centreLift && cutKind(c.cuts[1].name) === "flat");
      const rollOk = !needRoll || c.cuts[0].roll > 0;
      let bar = EXTRA;
      if (c.cuts[0].name === today.cuts[0].name && c.n === cutsToday) bar = Math.min(bar, NOISE);
      if (c.n < cutsToday) bar = Math.min(bar, -EXTRA);
      if (replaces && rollOk && c.n <= cutsToday) bar = Math.min(bar, -TIE);
      const shown = c.largest + c.typical;
      return shown < judged - bar;
    });
    if (!ok.length) return "today";
    const closest = Math.min(...ok.map((c: any) => c.largest + c.typical));
    const near = ok.filter((c: any) => c.largest + c.typical <= closest + EXTRA);
    const fewest = Math.min(...near.map((c: any) => c.n));
    return near.filter((c: any) => c.n === fewest).sort((a: any, b: any) => a.largest + a.typical - (b.largest + b.typical))[0].tag;
  };
  const a = pick(false), b = pick(true);
  if (a !== (L.kept ?? "today")) mismatch++;
  if (a !== b) { diff++; console.log("DIFF", r.id, a, b); }
}
console.log({ tried, diff, replayMismatchWithRealRun: mismatch });

// Spike 008: one of the app's own boards (phase16Boards' "<preset>|asis|hard") with a nose and/or centre cut, written to .brd
// with the app's own export, exactly as grid.mts does. Shared by the probes.
const ROOT = process.env.ROOT!;
export const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
export const IN = 25.4;
export interface Spec { board: string; nose?: [string, number, number]; center?: [string, number] }
/** "longboard|Blended Nose Concave|d3|r4" (grid id) or "longboard|none" */
export function parseId(id: string): Spec {
  const [board, a, b, c] = id.split("|");
  if (!a || a === "none") return { board };
  if (a === "CB") return { board, center: ["Continuous Belly / Rolled Mid", +b.slice(1)] };
  if (a === "RBE") return { board, nose: ["Rolled Belly Entry", +b.slice(1), 0] };
  return { board, nose: [a, +b.slice(1), +(c ?? "r0").slice(1)] };
}
export function build(spec: Spec) {
  const fields = phase16Boards().find((b: any) => b.label === `${spec.board}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: any = structuredClone(DEFAULT_BOTTOM);
  if (spec.nose) {
    bottom.nose = { ...startingCut("nose", spec.nose[0], board), depth: inchesToMm(spec.nose[1] / 16) };
    if (spec.nose[2] > 0) bottom.nose.railRoll = inchesToMm(spec.nose[2] / 16);
  }
  if (spec.center) bottom.center = { ...startingCut("center", spec.center[0], board), depth: inchesToMm(spec.center[1] / 16) };
  const input = designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board });
  const surface = buildBoardSurface({ sections: input, geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  return { fields, geometry, profile, rails, board, bottom, input, bytes, resolved: resolveBottom(bottom, board) };
}

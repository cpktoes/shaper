// Spike 008: what the trial code logged per board (dish readings, whether the retry ran, what was kept), tallied by kind.
//   node s8stats.mjs <label>
import { load } from "./analyze.mjs";
const rows = load(process.argv[2]).filter((r) => r.board === (process.env.BOARD ?? "longboard"));
const t = {};
for (const r of rows) { const p = r.s8?.polish ?? {}; const k = `${r.kind} ${r.order} narrowDish:${!!p.narrowDish} wideDish:${!!p.wideDish} t3wide:${r.s8?.t3wideDish ?? "-"} kept:${p.kept ?? "-"} iterKeep:${r.s8?.iter?.keep ?? "-"}`; t[k] = (t[k] ?? 0) + 1; }
for (const [k, v] of Object.entries(t).sort()) console.log(String(v).padStart(3), k);

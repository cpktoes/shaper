// Spike 008, probe 5: is the written roll findable at all on the finished board? The written nose concave (true depth, Off
// Rail, stations) on the board that opens, the roll swept 0..1/2", the rails refit two ways (descent from where they stood,
// and afresh), and three judges over the nose half: the whole section both ways (brdRailWholeValue), the rail region (RAILS'
// own score), and the underside alone (straight-up gap, stringer to the widest point).
//   ROOT=<wt> CASES="..." npx --no-install tsx --tsconfig ./tsconfig.json probe5.mts
import { build, parseId, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const B = await imp("lib/geometry/brd-bottom.ts");
const { fitBoardToBrd } = await imp("lib/geometry/brd-fit.ts");
const { mm } = await imp("lib/geometry/units.ts");
const under = (pts: [number, number][]) => { let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k; return pts.slice(0, apex + 1); };
const hAt = (p: [number, number][], x: number) => { for (let k = 0; k + 1 < p.length; k++) { const [x0, y0] = p[k], [x1, y1] = p[k + 1]; if (x >= x0 && x <= x1) return x1 === x0 ? y0 : y0 + ((y1 - y0) * (x - x0)) / (x1 - x0); } return NaN; };
export function undersideGap(file: [number, number][], ours: [number, number][]) {
  const uf = under(file), uo = under(ours);
  const reach = Math.min(uf[uf.length - 1][0], uo[uo.length - 1][0]);
  let lg = 0, s = 0, n = 0;
  for (let j = 0; j <= 60; j++) { const x = (reach * 0.995 * j) / 60; const d = Math.abs(hAt(uf, x) - hAt(uo, x)); if (Number.isFinite(d)) { lg = Math.max(lg, d); s += d; n++; } }
  return { largest: lg, mean: s / n };
}
for (const id of (process.env.CASES ?? "").split(";")) {
  const w = build(parseId(id));
  const board = readAnyBrd(w.bytes).board;
  const L = board.length;
  const look = P.brdFitLook(board);
  const lines = { length: board.length, outline: board.outline, bottom: board.bottom, deck: board.deck };
  const first = fitBoardToBrd(lines);
  const fins = look.fins?.spec;
  const board0 = B.brdFittedBottomBoard(first, fins);
  const { lines: railLines } = P.brdRailLines(board);
  const nose = railLines.filter((l: any) => l.station >= L / 2);
  console.log(`\n=== ${id} (${look.rails.order}); opened nose ${look.bottom.bottom.nose.name} ${(look.bottom.bottom.nose.depth / IN * 64).toFixed(1)}/64 r${((look.bottom.bottom.nose.railRoll ?? 0) / IN * 64).toFixed(1)}/64`);
  for (const which of ["written", "opened"]) for (const fresh of [false, true]) {
    const row: string[] = [];
    const baseNose = which === "written" ? w.bottom.nose : look.bottom.bottom.nose;
    if (!(baseNose.depth > 0)) continue;
    for (const r of [0, 1, 2, 3, 4, 6, 8]) {
      const bottom = { ...look.bottom.bottom, nose: { ...baseNose, railRoll: r ? mm((r / 16) * IN) : undefined } };
      const step = P.liftedStep(board, lines, first, fins, board0, bottom, look.bottom.sections);
      const onBoard = R.brdRailBoard(step.fit, step.bottom.bottom, fins);
      const settings = fresh ? R.fitBrdRails(railLines, onBoard) : R.fitBrdRails(railLines, onBoard, look.rails.settings);
      const rails = R.brdRailsSpec(settings, onBoard.foil, look.rails.blend.blend);
      const halves = R.brdOurRailHalves(onBoard, rails, nose.map((l: any) => l.station));
      let wl = 0, wm = 0, rl = 0, rm = 0, ul = 0, um = 0;
      nose.forEach((l: any, i: number) => { const g = R.brdRailWholeGap(l.points, halves[i]); wl = Math.max(wl, g.largest); wm += g.mean; const rg = R.brdRailLineGap(l, halves[i]); rl = Math.max(rl, rg.largest); rm += rg.mean; const u = undersideGap(l.points, halves[i]); ul = Math.max(ul, u.largest); um += u.mean; });
      const n = nose.length;
      row.push(`r${r}: whole ${(wm / n).toFixed(3)} rail ${(rm / n).toFixed(3)} under ${ul.toFixed(2)}/${(um / n).toFixed(3)}`);
    }
    console.log(`  ${which} concave, rails ${fresh ? "afresh " : "descent"} (written roll r${parseId(id).nose?.[2]}):`);
    for (const x of row) console.log("     " + x);
  }
}

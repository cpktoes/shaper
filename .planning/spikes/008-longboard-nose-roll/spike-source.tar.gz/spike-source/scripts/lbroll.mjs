// Spike 008: is the Longboard's roll that comes back MEASURED or just landed on? For each run: the rolled Longboards' written
// roll against the roll back (mean back roll per written roll; correlation), and the same for the depth.
//   node lbroll.mjs <label> [<label>...]
import { load } from "./analyze.mjs";
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const corr = (xs, ys) => { const n = xs.length; if (n < 3) return NaN; const mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n; let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } return sxy / Math.sqrt(sxx * syy); };
for (const label of process.argv.slice(2)) {
  const rows = load(label).filter((r) => r.board === (process.env.BOARD ?? "longboard") && r.kind === "roll");
  const per = {};
  for (const r of rows) { const w = Math.round(r.wrote.nose.roll * 16); (per[w] ??= []).push(CONC.includes(r.back[0].name) ? r.back[0].roll : 0); }
  const back = rows.filter((r) => CONC.includes(r.back[0].name) && r.back[0].roll > 0.005);
  const line = Object.entries(per).map(([w, v]) => `wrote ${w}/16: back ${(v.reduce((a, b) => a + b, 0) / v.length * 64).toFixed(1)}/64 avg (${v.filter((x) => x > 0.005).length} of ${v.length} with a roll)`).join("; ");
  console.log(`${label}: ${line}\n   roll corr (boards back with a roll) ${corr(back.map((r) => r.wrote.nose.roll), back.map((r) => r.back[0].roll)).toFixed(2)}; depth corr (all back as a concave) ${(() => { const c = rows.filter((r) => CONC.includes(r.back[0].name)); return corr(c.map((r) => r.wrote.nose.depth), c.map((r) => r.back[0].depth)).toFixed(2) + ` over ${c.length}`; })()}; depth within 1/16" ${rows.filter((r) => CONC.includes(r.back[0].name) && Math.abs(r.back[0].depth - r.wrote.nose.depth) <= 1 / 16 + 1e-6).length}/48`);
}

// Spike 008, probe 3: the roll's signal station by station on the written file: the largest straight-up change a Rail Roll
// makes to the file's nose section, where across it sits, and the written rail's height there (h/a: how far up the rail).
//   ROOT=<wt> CASE="longboard|Blended Nose Concave|3|4" npx --no-install tsx --tsconfig ./tsconfig.json probe3.mts
import { build, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const [preset, name, d, r] = (process.env.CASE ?? "longboard|Blended Nose Concave|3|4").split("|");
const under = (pts: [number, number][]) => { let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k; return { apex, pts: pts.slice(0, apex + 1), a: pts[apex][1] }; };
const hAt = (u: any, x: number) => { const p = u.pts; for (let k = 0; k + 1 < p.length; k++) { const [x0, y0] = p[k], [x1, y1] = p[k + 1]; if (x >= x0 && x <= x1) return x1 === x0 ? y0 : y0 + ((y1 - y0) * (x - x0)) / (x1 - x0); } return NaN; };
const b0 = readAnyBrd(build({ board: preset, nose: [name, +d, 0] }).bytes).board;
const w = build({ board: preset, nose: [name, +d, +r] });
const b = readAnyBrd(w.bytes).board;
const L0 = P.brdRailLines(b0).lines;
for (const l of P.brdRailLines(b).lines) {
  if (l.station < b.length * 0.55) continue;
  const l0 = L0.find((x: any) => Math.abs(x.station - l.station) < 0.5); if (!l0) continue;
  const u = under(l.points), u0 = under(l0.points);
  const reach = u.pts[u.apex][0];
  let best = 0, at = 0;
  for (let x = 0; x < reach; x += reach / 400) { const dv = hAt(u, x) - hAt(u0, x); if (Math.abs(dv) > Math.abs(best)) { best = dv; at = x; } }
  const edge = w.board.railAt(l.station) - (w.bottom.nose.offRail ?? 0);
  console.log(`${((b.length - l.station) / IN).toFixed(1).padStart(5)}" from nose  reach ${(reach / IN).toFixed(2)}"  concave edge ${(edge / IN).toFixed(2)}"  apex height ${u0.a.toFixed(1)} mm  roll changes the file by ${best.toFixed(2)} mm at ${(at / IN).toFixed(2)}" out (${((reach - at) / IN).toFixed(2)}" in from the rail), where the rail stands ${hAt(u0, at).toFixed(1)} mm up`);
}

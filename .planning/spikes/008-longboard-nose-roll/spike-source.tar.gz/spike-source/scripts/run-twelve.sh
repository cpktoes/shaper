#!/bin/bash
# Spike 008: the founder's twelve files once per trial (measure.mts, fastest of N), one after another, from the repo root.
#   run-twelve.sh <checkout> <reps> "<label>:<ENV=..,ENV=..>" ...
here="${0%/scripts/*}"; root=$1; reps=$2; shift 2
for spec in "$@"; do
  label="${spec%%:*}"; envs="${spec#*:}"
  echo "== $label ($envs) $(uptime)"
  ( IFS=','; for e in $envs; do [ -n "$e" ] && export "$e"; done; cd /Users/kontoes/Code/shaper && ROOT="$root" npx --no-install tsx --tsconfig "$root/tsconfig.json" "$here/scripts/measure.mts" "$label" "$reps" )
done
echo "twelve done $(uptime)"

// Spike 008, probe 2: how much a Rail Roll changes the written file's own nose sections, on each preset (the roll's signal).
//   ROOT=<wt> npx --no-install tsx --tsconfig ./tsconfig.json probe2.mts
import { build, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const heightAt = (pts: [number, number][], x: number) => { // underside: stringer bottom out to the apex
  let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k;
  for (let k = 0; k < apex; k++) { const [x0, y0] = pts[k], [x1, y1] = pts[k + 1]; if (x >= x0 && x <= x1) return x1 === x0 ? y0 : y0 + ((y1 - y0) * (x - x0)) / (x1 - x0); }
  return NaN;
};
for (const preset of (process.env.PRESETS ?? "longboard,midlength").split(",")) for (const name of ["Blended Nose Concave"]) for (const d of [1, 3]) {
  const base = readAnyBrd(build({ board: preset, nose: [name, d, 0] }).bytes).board;
  const lines0 = P.brdRailLines(base).lines;
  for (const r of [1, 2, 4]) {
    const b = readAnyBrd(build({ board: preset, nose: [name, d, r] }).bytes).board;
    const lines = P.brdRailLines(b).lines;
    let worst = 0, worstAt = "", sumW = 0, n = 0, vmax = 0;
    for (const l of lines) {
      if (l.station < b.length * 0.6) continue;
      const l0 = lines0.find((x: any) => Math.abs(x.station - l.station) < 0.5);
      if (!l0) continue;
      const g = R.brdRailWholeGap(l.points, l0.points);
      sumW += g.mean; n++;
      if (g.largest > worst) { worst = g.largest; worstAt = `${((b.length - l.station) / IN).toFixed(1)}"`; }
      const reach = Math.max(...l.points.map((p: any) => p[0]));
      for (let x = 0; x < reach * 0.999; x += reach / 200) { const dv = Math.abs(heightAt(l.points, x) - heightAt(l0.points, x)); if (dv > vmax) vmax = dv; }
    }
    console.log(`${preset.padEnd(10)} ${name} ${d}/16 roll ${r}/16 (${(r / 16 * 25.4).toFixed(2)} mm): file vs no-roll file, nose sections: widest ${worst.toFixed(2)} mm (at ${worstAt} from nose), mean ${(sumW / n).toFixed(3)}, largest straight-up difference ${vmax.toFixed(2)} mm`);
  }
}

// Spike 008, probe 1: why a Longboard is read rails first, step by step through settleLook's own pieces (exported for the
// spike only), and what the nose looks like to the bottom in each order.
//   ROOT=<wt> CASES="longboard|Blended Nose Concave|d3|r4;longboard|none" npx --no-install tsx --tsconfig ./tsconfig.json probe1.mts
import { build, parseId, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const B = await imp("lib/geometry/brd-bottom.ts");
const { fitBoardToBrd } = await imp("lib/geometry/brd-fit.ts");
const { fitBrdFins } = await imp("lib/geometry/brd-fins.ts");
const { cutKind, sectionsFoamOff } = await imp("lib/geometry/bottom.ts");
const f2 = (v: number) => v.toFixed(2);
const cuts = (b: any) => ["nose", "center", "tail"].map((k) => `${b[k].name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")}${b[k].depth ? " " + (b[k].depth / IN).toFixed(3) : ""}${b[k].railRoll ? " r" + (b[k].railRoll / IN).toFixed(3) : ""}${b[k].offRail ? " OR" + (b[k].offRail / IN).toFixed(2) : ""}`).join(" · ");
for (const id of (process.env.CASES ?? "").split(";")) {
  const w = build(parseId(id));
  const read = readAnyBrd(w.bytes);
  const board = read.board;
  const L = board.length;
  const lines = { length: board.length, outline: board.outline, bottom: board.bottom, deck: board.deck };
  const first = fitBoardToBrd(lines);
  const fins = fitBrdFins(board.fins, board.outline, first.outline)?.spec;
  const asRead = P.bottomOn(board, lines, first, fins);
  const { lines: railLines, index } = P.brdRailLines(board);
  const stations = railLines.map((l: any) => l.station);
  const sw = (ws: any[]) => { const all = board.sections.map(() => undefined); ws.forEach((x: any, k: number) => (all[index[k]] = x)); return all; };
  const onBoard = (step: any) => R.brdRailBoard(step.fit, step.bottom.bottom, fins);
  let current = asRead;
  let settings = R.fitBrdRails(railLines, onBoard(current));
  const found = R.brdRailWindows(railLines, R.brdRailBegins(current.fit, R.brdRailsSpec(settings, current.fit.foil), stations));
  if (found.narrowed) { const again = P.bottomOn(board, lines, first, fins, sw(found.windows)); if (again) { current = again; settings = R.fitBrdRails(railLines, onBoard(current), settings); } }
  const rs = R.brdRailsSpec(settings, current.fit.foil);
  const whole = R.brdRailWholeValue(railLines, onBoard(current), rs);
  console.log(`\n=== ${id}  L=${(L / IN).toFixed(1)}"`);
  console.log(`bottom-first: ${cuts(current.bottom.bottom)}  bottom ${f2(current.bottom.closeness.largest)}/${f2(current.bottom.closeness.typical)} at ${((L - current.bottom.closeness.station) / IN).toFixed(1)}" from nose; whole ${f2(whole.largest)}/${f2(whole.mean)} narrowed=${found.narrowed}`);
  const kinds = ["nose", "center", "tail"].map((k) => cutKind(current.bottom.bottom[k].name));
  const tryRF = whole.largest > R.BRD_RAIL_FIRST_TRY_MM && kinds.some((k: string) => k === "vee" || k === "belly");
  // where each whole section is worst in bottom-first
  const halves = R.brdOurRailHalves(onBoard(current), rs, stations);
  const per = railLines.map((l: any, i: number) => ({ st: l.station, g: R.brdRailWholeGap(l.points, halves[i]) }));
  const worst = per.reduce((a: any, b: any) => (a.g.largest >= b.g.largest ? a : b));
  console.log(`  bottom-first worst whole section ${f2(worst.g.largest)} at ${((L - worst.st) / IN).toFixed(1)}" from nose; try rails-first: ${tryRF}`);
  const flat = R.brdRailBoard(first, null, fins);
  const flatSettings = R.fitBrdRails(railLines, flat);
  const begins = R.brdRailBegins(first, R.brdRailsSpec(flatSettings, flat.foil), stations);
  const flatW = R.brdRailWindows(railLines, begins);
  const rf = P.bottomOn(board, lines, first, fins, sw(flatW.windows));
  const pol = R.fitBrdRails(railLines, onBoard(rf), flatSettings);
  const wholeFirst = R.brdRailWholeValue(railLines, onBoard(rf), R.brdRailsSpec(pol, rf.fit.foil));
  const begins2 = R.brdRailBegins(rf.fit, R.brdRailsSpec(pol, rf.fit.foil), stations);
  const look = P.brdFitLook(board);
  const begins3 = R.brdRailBegins(look.fit, look.rails.rails, stations);
  console.log(`rails-first: ${cuts(rf.bottom.bottom)}  bottom ${f2(rf.bottom.closeness.largest)}/${f2(rf.bottom.closeness.typical)}; whole ${f2(wholeFirst.largest)}/${f2(wholeFirst.mean)}  (wins if <= ${f2(whole.value - 0.25)}: ${wholeFirst.value <= whole.value - 0.25})`);
  console.log(`  flat-bottom rails nose: ${JSON.stringify(flatSettings.nose)}`);
  console.log(`  bottom-first rails nose: ${JSON.stringify(settings.nose)}`);
  // the nose, section by section: reach, the written concave's edge, the written rail begins, the windows
  const wide = B.brdBottomSections(board.sections, L);
  const narrow = B.brdBottomSections(board.sections, L, sw(flatW.windows));
  const wnose = w.bottom.nose;
  const edgeIn = wnose.offRail ?? 0;
  for (let i = 0; i < railLines.length; i++) {
    const st = railLines[i].station;
    if (st < L * 0.55) continue;
    const reach = Math.max(...railLines[i].points.map((p: any) => p[0]));
    // the written board's own bottom (cuts alone) vs the file's half: where the file first rises 0.3 mm above the cuts
    const at0 = sectionsFoamOff(w.resolved, w.board, st, 0);
    const pts = railLines[i].points as [number, number][];
    let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k;
    let leave = null as null | number;
    for (let k = 0; k <= apex; k++) { const [x, y] = pts[k]; const cut = sectionsFoamOff(w.resolved, w.board, st, x) - at0; if (y - cut > 0.3) { leave = x; break; } }
    const nw = narrow.find((s: any) => Math.abs(s.station - st) < 1);
    const ww = wide.find((s: any) => Math.abs(s.station - st) < 1);
    console.log(`  ${((L - st) / IN).toFixed(1).padStart(5)}" from nose: reach ${(reach / IN).toFixed(2)}" | concave edge ${((w.board.railAt(st) - edgeIn) / IN).toFixed(2)}" (railAt ${(w.board.railAt(st) / IN).toFixed(2)}) | written rail leaves its bottom ${leave === null ? "-" : (leave / IN).toFixed(2) + '" (' + Math.round((100 * leave) / reach) + "%)"} | flat-rail begins ${((reach - begins[i]) / IN).toFixed(2)}" polished ${((reach - begins2[i]) / IN).toFixed(2)}" final ${((reach - begins3[i]) / IN).toFixed(2)}" | windows wide ${(ww.window / IN).toFixed(2)} narrow ${(nw.window / IN).toFixed(2)}`);
  }
  console.log(`  dish wide: ${JSON.stringify(B.brdNoseDish(wide, B.brdFittedBottomBoard(first, fins)), (k, v) => (typeof v === "number" ? +(k === "out" ? v.toFixed(2) : (v / IN).toFixed(3)) : v))}`);
  console.log(`  dish narrow: ${JSON.stringify(B.brdNoseDish(narrow, B.brdFittedBottomBoard(first, fins)), (k, v) => (typeof v === "number" ? +(k === "out" ? v.toFixed(2) : (v / IN).toFixed(3)) : v))}`);
}

// Plan-time check (quick 261125-v2f): exact sections on the Shortboard, through the trial's polish, and the dish reading alone.
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const B = await imp("lib/geometry/bottom.ts");
const BB = await imp("lib/geometry/brd-bottom.ts");
const { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards, asD30Read } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { inchesToMm: I, mm } = await imp("lib/geometry/units.ts");
const IN = 25.4;
const f = asD30Read(phase16Boards().find((b: any) => b.label === "shortboard|asis|hard").fields);
const geometry = buildOutline(f.outline);
const profile = designSideProfile(f, LIVE_DESIGN_RULES);
const board = designBottomBoard(f.outline, geometry, profile, designFinPlacement(f));
function exact(bottom: any) {
  const resolved = B.resolveBottom(bottom, board);
  return Array.from({ length: 40 }, (_, k) => 0.03 + (0.94 * k) / 39).map((share) => {
    const station = mm(share * board.length);
    const reach = board.railAt(station) / BB.BRD_BOTTOM_WINDOW;
    const at0 = B.sectionsFoamOff(resolved, board, station, mm(0));
    const run = Array.from({ length: 61 }, (_, k) => { const x = (reach * k) / 60; return [x, B.sectionsFoamOff(resolved, board, station, mm(x)) - at0]; });
    return { station, points: [...run, [reach, run[60][1] + 20], [0, run[60][1] + 40]] };
  });
}
const dish = (sections: any[]) => {
  const L = board.length, J = BB.BRD_BOTTOM_ACROSS_STEPS;
  let sig: any = null, dishMax = 0;
  for (const s of sections) {
    if (s.station < L / 2) continue;
    let vmin = Infinity; for (const v of s.file) if (v < vmin) vmin = v;
    let jm = 0; for (let j = 0; j <= J; j++) if (s.file[j] <= vmin + 0.05) jm = j;
    const turn = s.file[J] - vmin, d = -vmin; if (d > dishMax) dishMax = d;
    if (jm < J && jm >= 0.3 * J && turn >= 0.3 && d >= 0.5) {
      const C = s.across[jm];
      const offRail = Math.min(I(B.BOTTOM_MARK_RANGES_IN.offRail.max), Math.max(0, board.railAt(s.station) - C));
      const share = B.railRollAcross({ offRail: mm(offRail) }, board, "narrowest", s.station, s.window);
      const roll = share > 0.1 ? Math.min(I(0.5), Math.max(I(1 / 16), turn / share)) : I(1 / 8);
      if (!sig || turn > sig.turn) sig = { st: +(s.station / IN).toFixed(1), dish: +d.toFixed(2), turn: +turn.toFixed(2), onset: +(jm / J).toFixed(2), offRailIn: +(offRail / IN).toFixed(3), share: +share.toFixed(3), roll64: +(roll / IN * 64).toFixed(1) };
    }
  }
  return sig ? { ...sig, dishMax: +dishMax.toFixed(2) } : null;
};
const w = (c: any) => `${c.name}${c.depth > 0 ? ` ${(c.depth / IN * 64).toFixed(1)}/64` : ""}${c.railRoll ? ` roll ${(c.railRoll / IN * 64).toFixed(1)}/64` : ""}`;
const withCuts = (cuts: any) => ({ ...structuredClone(B.DEFAULT_BOTTOM), ...cuts });
const sc = (k: string, n: string, d: number, extra: any = {}) => ({ ...B.startingCut(k, n, board), depth: I(d), ...extra });
const CASES: [string, any][] = [
  ["Blended 3/16 roll 1/16", withCuts({ nose: sc("nose", "Blended Nose Concave", 3 / 16, { railRoll: I(1 / 16) }) })],
  ["Blended 3/16 roll 1/8", withCuts({ nose: sc("nose", "Blended Nose Concave", 3 / 16, { railRoll: I(1 / 8) }) })],
  ["Blended 3/16 roll 1/4", withCuts({ nose: sc("nose", "Blended Nose Concave", 3 / 16, { railRoll: I(1 / 4) }) })],
  ["Blended 3/16 no roll", withCuts({ nose: sc("nose", "Blended Nose Concave", 3 / 16) })],
  ["Teardrop 1/4 no roll", withCuts({ nose: sc("nose", "Teardrop Nose Concave", 1 / 4) })],
  ["Rolled Belly Entry 1/8", withCuts({ nose: sc("nose", "Rolled Belly Entry", 1 / 8) })],
  ["Reverse Vee Nose 1/8", withCuts({ nose: sc("nose", "Reverse Vee Nose", 1 / 8) })],
  ["centre Continuous Belly 1/8", withCuts({ center: sc("center", "Continuous Belly / Rolled Mid", 1 / 8) })],
  ["flat", withCuts({})],
];
for (const [name, wanted] of CASES) {
  const t0 = performance.now();
  const grid = BB.fitBottomToBrd(exact(wanted), board);
  const polished = BB.polishBrdBottom(grid.bottom, grid.sections, board);
  const m = BB.measureBrdBottom(polished, grid.sections, board).closeness;
  console.log(`${name.padEnd(30)} dish=${JSON.stringify(dish(grid.sections))}\n   grid: ${[grid.bottom.nose, grid.bottom.center, grid.bottom.tail].map(w).join(" · ")} ${grid.closeness.largest.toFixed(3)}/${grid.closeness.typical.toFixed(3)}\n   now : ${[polished.nose, polished.center, polished.tail].map(w).join(" · ")} ${m.largest.toFixed(3)}/${m.typical.toFixed(3)}  ${((performance.now() - t0) / 1000).toFixed(1)}s`);
}

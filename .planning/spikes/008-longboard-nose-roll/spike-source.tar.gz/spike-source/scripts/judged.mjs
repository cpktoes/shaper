// Spike 008: the T2/T4 judge's own figures per board: the finished value of today, each try and each roll of the sweep.
//   node judged.mjs <label> <id substring> ...
import { load } from "./analyze.mjs";
const [label, ...ids] = process.argv.slice(2);
for (const r of load(label).filter((r) => ids.some((i) => r.id.includes(i)))) {
  console.log(r.id);
  for (const j of r.s8?.judged ?? []) console.log(`   ${j.tag.padEnd(8)} ${j.nose.padEnd(28)} d${(j.depth / 25.4 * 64).toFixed(1).padStart(5)}/64 r${(j.roll / 25.4 * 64).toFixed(1).padStart(5)}/64  finished ${j.f.toFixed(3)} (${j.fl.toFixed(2)} / ${j.fm.toFixed(3)})  bottom ${j.b.toFixed(2)} ${j.kept ? "<= kept" : ""}`);
}

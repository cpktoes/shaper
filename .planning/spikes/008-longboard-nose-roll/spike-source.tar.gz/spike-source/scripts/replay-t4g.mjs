// Spike 008: T4 with a guard, replayed from T4's own logs (each candidate's finished-nose figure and the bottom figure it
// opens with are both logged, and they are exactly what the board then opens with): the finished nose chooses, but only among
// candidates whose shown bottom (widest + typical) is no further off than today's. The chooser's bars as chooseBrdNoseRetry
// (same name and cuts: rounding noise; a renamed nose or a cut more: 0.25 mm); the tail is never changed by a try here.
//   node replay-t4g.mjs <label>
import { load } from "./analyze.mjs";
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const flat = (n) => /Flat/.test(n);
const corr = (xs, ys) => { const n = xs.length; if (n < 3) return NaN; const mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n; let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } return sxy / Math.sqrt(sxx * syy); };
const rows = load(process.argv[2]).filter((r) => r.board === "longboard");
let back = 0, close = 0, inv = 0, changed = 0; const xs = [], ys = [];
for (const r of rows) {
  const J = r.s8?.judged;
  let pick = null;
  if (J) {
    const t = J[0];
    const cuts = (j) => (j.depth > 0 ? 1 : 0) + (flat(j.center) ? 0 : 1);
    const ok = J.slice(1).filter((j) => j.b <= t.b + 1e-9).filter((j) => { let bar = 0.25; if (j.nose === t.nose && cuts(j) === cuts(t)) bar = 1e-9; if (cuts(j) < cuts(t)) bar = -0.25; return j.f < t.f - bar; });
    pick = ok.length ? ok.reduce((a, b) => (a.f <= b.f ? a : b)) : t;
  }
  const nose = pick ? { name: pick.nose, depth: pick.depth / 25.4, roll: pick.roll / 25.4 } : r.back[0];
  if (pick && pick !== J[0]) changed++;
  const isCR = CONC.includes(nose.name) && nose.roll > 0.005;
  if (r.kind === "roll" && isCR) { back++; xs.push(r.wrote.nose.roll); ys.push(nose.roll); if (Math.abs(nose.roll - r.wrote.nose.roll) <= 1 / 16 + 1e-6 && Math.abs(nose.depth - r.wrote.nose.depth) <= 1 / 16 + 1e-6) close++; }
  if (r.kind === "noroll" && isCR) inv++;
}
console.log(`T4 guarded (replay of ${process.argv[2]}): back as a concave with a roll ${back} of 48, within 1/16" ${close}, roll correlation ${corr(xs, ys).toFixed(2)}, invented rolls ${inv} of 12, boards whose answer the judge changed ${changed}`);

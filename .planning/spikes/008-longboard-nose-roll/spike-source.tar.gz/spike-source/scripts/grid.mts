// Spike 008 (from spike 007 / quick v2f's grid.mts; logs spike 008's __s8 instead of __s7): the round-trip grid. The app's own presets, a nose concave with a Rail Roll written to .brd with the app's own
// export and opened again through the real import (brdLookFromBytes).
//   ROOT=<checkout> [S7_*=...] npx --no-install tsx --tsconfig <checkout>/tsconfig.json grid.mts <label> <shard> <of> [set]
// set: all (default) | roll | noroll | belly | quick. Writes ../out/<label>.<shard>.jsonl (one case a line).
import { appendFileSync, mkdirSync, writeFileSync } from "node:fs";
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");

const [label = "run", shardS = "0", ofS = "1", set = "all"] = process.argv.slice(2);
const shard = Number(shardS), of = Number(ofS);
const IN = 25.4;
const BOARDS = ["shortboard", "midlength", "fish", "longboard"];
const NOSES = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
interface Case { id: string; kind: string; board: string; nose?: [string, number, number]; center?: [string, number] }
const cases: Case[] = [];
for (const board of BOARDS) {
  for (const name of NOSES) for (const d of [1, 2, 3, 4]) for (const r of [1, 2, 3, 4]) cases.push({ id: `${board}|${name}|d${d}|r${r}`, kind: "roll", board, nose: [name, d, r] });
  for (const name of NOSES) for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|${name}|d${d}|r0`, kind: "noroll", board, nose: [name, d, 0] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|RBE|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|CB|d${d}`, kind: "belly", board, center: ["Continuous Belly / Rolled Mid", d] });
  for (const d of [2, 4]) cases.push({ id: `${board}|RBE+CB|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|RVN|d2`, kind: "belly", board, nose: ["Reverse Vee Nose", 2, 0] });
  for (const d of [2, 4]) cases.push({ id: `${board}|BNC2+CB|d${d}`, kind: "belly", board, nose: ["Blended Nose Concave", 2, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|TPH|d4`, kind: "belly", board, center: ["Tri-Plane Hull Center", 4] });
}
const QUICK = new Set(["midlength|Blended Nose Concave|d2|r2", "midlength|Blended Nose Concave|d3|r3", "midlength|Blended Nose Concave|d4|r4", "midlength|Slight Single Concave Entry|d3|r4", "longboard|Blended Nose Concave|d3|r4", "midlength|RBE|d2", "midlength|CB|d2", "shortboard|Blended Nose Concave|d3|r1"]);
const wanted = cases.filter((c) => (set === "all" ? true : set === "quick" ? QUICK.has(c.id) : set.split(",").includes(c.kind)) && (!process.env.ONLY || c.id.includes(process.env.ONLY)) && (!process.env.NOT || !c.id.includes(process.env.NOT)));
const mine = wanted.filter((_, i) => i % of === shard);
const outDir = new URL("../out/", import.meta.url);
mkdirSync(outDir, { recursive: true });
const outFile = new URL(`${label}.${shard}.jsonl`, outDir);
writeFileSync(outFile, "");
const cutOut = (k: any) => ({ name: k.name, depth: +(k.depth / IN).toFixed(4), roll: +((k.railRoll ?? 0) / IN).toFixed(4), offRail: +((k.offRail ?? 0) / IN).toFixed(3), offStringer: +((k.offStringer ?? 0) / IN).toFixed(3), start: k.start !== undefined ? +(k.start / IN).toFixed(2) : null, deepest: k.deepest !== undefined ? +(k.deepest / IN).toFixed(2) : null, end: k.end !== undefined ? +(k.end / IN).toFixed(2) : null });
for (const c of mine) {
  const fields = phase16Boards().find((b: any) => b.label === `${c.board}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: any = structuredClone(DEFAULT_BOTTOM);
  if (c.nose) {
    bottom.nose = { ...startingCut("nose", c.nose[0], board), depth: inchesToMm(c.nose[1] / 16) };
    if (c.nose[2] > 0) bottom.nose.railRoll = inchesToMm(c.nose[2] / 16);
  }
  if (c.center) bottom.center = { ...startingCut("center", c.center[0], board), depth: inchesToMm(c.center[1] / 16) };
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  (globalThis as any).__s8 = [];
  const t0 = performance.now();
  const r = brdLookFromBytes(bytes, "x.brd");
  const secs = (performance.now() - t0) / 1000;
  if (!r.ok) { appendFileSync(outFile, JSON.stringify({ id: c.id, kind: c.kind, problem: r.problem }) + "\n"); continue; }
  const b = r.look.bottom!;
  const log8 = ((globalThis as any).__s8 as any[]).at(-1) ?? null;
  const log: any = null;
  const slim = log && {
    overGate: log.overGate, bellyInNose: log.bellyInNose, triggered: log.triggered, kept: log.kept ?? null,
    sig: log.sig && { station: +(log.sig.station / IN).toFixed(1), dish: +log.sig.dish.toFixed(2), turn: +log.sig.turn.toFixed(2), onset: +log.sig.onset.toFixed(2), offRail: +(log.sig.offRail / IN).toFixed(2), roll: +(log.sig.roll / IN).toFixed(3) },
    today: { cuts: [cutOut(log.today.nose), cutOut(log.today.center), cutOut(log.today.tail)], largest: +log.today.largest.toFixed(3), typical: +log.today.typical.toFixed(3) },
    cands: log.cands.map((k: any) => ({ tag: k.tag, cuts: [cutOut(k.nose), cutOut(k.center), cutOut(k.tail)], largest: +k.largest.toFixed(3), typical: +k.typical.toFixed(3), n: k.cuts, bar: k.bar, rule: k.rule })),
  };
  const row = {
    id: c.id, kind: c.kind, board: c.board,
    wrote: { nose: cutOut(bottom.nose), center: cutOut(bottom.center) },
    back: [cutOut(b.bottom.nose), cutOut(b.bottom.center), cutOut(b.bottom.tail)],
    openedRoll: +(((r.fields?.bottom?.nose as any)?.railRoll ?? 0) / IN).toFixed(4),
    largest: +b.closeness.largest.toFixed(3), typical: +b.closeness.typical.toFixed(3),
    rails: r.look.rails ? [+r.look.rails.closeness.largest.toFixed(2), +r.look.rails.closeness.typical.toFixed(2)] : null,
    order: r.look.rails?.order ?? null, secs: +secs.toFixed(2), log: slim, s8: log8,
  };
  appendFileSync(outFile, JSON.stringify(row) + "\n");
  console.log(`${c.id.padEnd(46)} -> ${row.back.map((k: any) => `${k.name}${k.depth ? " " + k.depth.toFixed(3) : ""}${k.roll ? " roll " + k.roll.toFixed(3) : ""}`).join(" · ")}  ${row.largest.toFixed(2)}/${row.typical.toFixed(2)} rails ${row.rails?.join("/")} ${row.order} ${row.secs}s ${log8?.polish?.kept ?? ""}`);
}

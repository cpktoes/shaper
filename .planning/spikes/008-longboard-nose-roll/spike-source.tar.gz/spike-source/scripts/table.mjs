// Spike 008: the Longboard grid per trial as one markdown table (the README's), from the lb-* runs.
//   node table.mjs <label>=<name> ...
import { load, score } from "./analyze.mjs";
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const corr = (xs, ys) => { const n = xs.length; if (n < 3) return NaN; const mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n; let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } return sxy / Math.sqrt(sxx * syy); };
console.log("| Trial | Back as a concave with a roll | Roll and depth within 1/16\" | Depth within 1/16\" | Written roll vs roll back (correlation) | No other cut | Stray centre/tail cut | Bottom widest / typical mm | Rails widest / typical mm | Read rails first | Invented rolls (roll 0) | False concaves | Mean open s |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|");
for (const arg of process.argv.slice(2)) {
  const [label, name] = arg.split("=");
  const all = load(label).filter((r) => r.board === "longboard");
  const s = score(all);
  const R = all.filter((r) => r.kind === "roll");
  const back = R.filter((r) => CONC.includes(r.back[0].name) && r.back[0].roll > 0.005);
  const depth = R.filter((r) => CONC.includes(r.back[0].name) && Math.abs(r.back[0].depth - r.wrote.nose.depth) <= 1 / 16 + 1e-6).length;
  const rt = (R.reduce((a, r) => a + (r.rails?.[1] ?? 0), 0) / R.length).toFixed(2);
  const rf = R.filter((r) => r.order === "rails-first").length;
  const secs = (all.reduce((a, r) => a + r.secs, 0) / all.length).toFixed(1);
  console.log(`| ${name} | ${s.concaveRoll} of 48 | ${s.close16} | ${depth} | ${corr(back.map((r) => r.wrote.nose.roll), back.map((r) => r.back[0].roll)).toFixed(2)} | ${s.clean} | ${s.stray} | ${s.widest.toFixed(2)} / ${s.typical.toFixed(2)} | ${s.rails.toFixed(2)} / ${rt} | ${rf} of 48 | ${s.invented} of 12 | ${s.falseConc} of ${s.belly} | ${secs} |`);
}

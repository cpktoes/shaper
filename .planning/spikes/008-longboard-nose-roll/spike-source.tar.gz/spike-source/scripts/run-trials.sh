#!/bin/bash
# Spike 008: the Longboard grid (74 boards: 48 rolled, 12 roll-0, 14 belly/mixed controls) once per trial, one after another.
#   run-trials.sh <checkout> "<label>:<ENV=..,ENV=..>" ...
here="${0%/scripts/*}"; root=$1; shift
for spec in "$@"; do
  label="${spec%%:*}"; envs="${spec#*:}"
  echo "== $label ($envs) $(uptime)"
  ( IFS=','; for e in $envs; do [ -n "$e" ] && export "$e"; done; ONLY=${ONLY-longboard} "$here/scripts/run-grid.sh" "$root" "$label" 6 )
done
echo "all done $(uptime)"

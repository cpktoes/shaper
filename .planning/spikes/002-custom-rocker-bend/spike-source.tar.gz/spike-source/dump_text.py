import sys
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
from pypdf import PdfReader
src, out = sys.argv[1], sys.argv[2]
r = PdfReader(src)
with open(out, 'w') as f:
    for i, p in enumerate(r.pages, 1):
        try:
            t = p.extract_text() or ''
        except Exception as e:
            t = f'<<error {e}>>'
        f.write(f'\n===== PAGE {i} ({len(t)} chars, {len(p.images) if hasattr(p,"images") else "?"} imgs) =====\n')
        f.write(t)
print(src, len(r.pages))

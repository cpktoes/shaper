const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const [html, out] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 960, height: 800 }, deviceScaleFactor: 2 });
  await p.goto('file://' + html);
  await p.screenshot({ path: out, fullPage: true });
  await b.close();
})();

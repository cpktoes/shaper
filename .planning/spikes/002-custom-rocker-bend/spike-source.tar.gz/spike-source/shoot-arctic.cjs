const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const [html, outdir] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 780, height: 900 }, deviceScaleFactor: 2 });
  await p.goto('file://' + html);
  await p.waitForFunction(() => [...document.images].every(i => i.complete), null, { timeout: 60000 });
  const info = await p.evaluate(() => [...document.images].map(i => i.naturalWidth + 'x' + i.naturalHeight));
  console.log(info.join(' '));
  const divs = await p.$$('div');
  for (let i = 0; i < divs.length; i++) await divs[i].screenshot({ path: `${outdir}/a${String(i).padStart(2,'0')}.png` });
  await b.close();
})();

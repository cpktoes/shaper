import sys, re
txt = open(sys.argv[1]).read()
pat = re.compile(sys.argv[2], re.I)
pages = re.split(r'\n===== PAGE (\d+) [^\n]*=====\n', txt)
# pages: ['', '1', text1, '2', text2,...]
for i in range(1, len(pages), 2):
    num, body = pages[i], pages[i+1]
    flat = re.sub(r'\s*\n\s*', ' ', body)
    hits = [m.start() for m in pat.finditer(flat)]
    if not hits: continue
    out = []
    last = -1
    for h in hits:
        a, b = max(0, h-220), min(len(flat), h+220)
        if a < last: continue
        out.append(flat[a:b]); last = b
    print(f'--- p{num}: ' + ' … '.join(out))

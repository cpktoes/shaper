import csv, sys, glob, collections
for f in sorted(glob.glob(sys.argv[1] + '/*.csv')):
    rows = list(csv.DictReader(open(f, newline='')))
    by = collections.OrderedDict()
    for r in rows: by.setdefault(r['blank_name'], []).append(r)
    cnz = []; labels = collections.Counter(); neg = []
    for name, rs in by.items():
        st = {r['station']: float(r['rocker_in']) for r in rs if r['rocker_in'] != ''}
        labels[tuple(r['station'] for r in rs)] += 1
        c = st.get('C')
        if c is None or abs(c) > 1e-9: cnz.append((name, c))
        mn = min(st.values())
        if mn < -1e-9: neg.append((name, mn))
    print(f.split('/')[-1], 'blanks', len(by))
    print('  C rocker not 0:', cnz)
    print('  any negative rocker:', neg)
    for k, n in labels.most_common(6): print('  ', n, ' '.join(k))

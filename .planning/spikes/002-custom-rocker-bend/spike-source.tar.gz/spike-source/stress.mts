// Stress: on EVERY pickable blank, apply large minus and plus changes from centre and from 18"/24";
// report dips (a step backwards walking away from the low point) and low-point moves.
const ROOT = "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275";
const { readSeedCatalog } = await import(`${ROOT}/lib/blanks/seed-files.ts`);
const { prepareBlank, levelCurve } = await import(`${ROOT}/lib/geometry/blank-fit.ts`);
const { isPickable } = await import(`${ROOT}/lib/blanks/catalog.ts`);
const IN = 25.4;
type Change = { end: "nose" | "tail"; amountIn: number; fromTipIn: number | null };
function pivot(rec: any, c: Change) {
  const centre = rec.stations.find((s: any) => s.label === "C").fromTailMm;
  if (c.fromTipIn === null) return centre;
  return c.end === "nose" ? rec.lengthMm - c.fromTipIn * IN : c.fromTipIn * IN;
}
function delta(rec: any, changes: Change[], x: number) {
  let s = 0;
  for (const c of changes) {
    const p = pivot(rec, c);
    const L = rec.lengthMm;
    if (c.end === "nose" && x > p) s += c.amountIn * IN * ((x - p) / (L - p)) ** 2;
    if (c.end === "tail" && x < p) s += c.amountIn * IN * ((p - x) / p) ** 2;
  }
  return s;
}
function steadiness(f: (x: number) => number, L: number) {
  const n = Math.round(L / (IN / 8)); let lowI = 0; const ys: number[] = [];
  for (let i = 0; i <= n; i++) ys.push(f((i * L) / n));
  ys.forEach((y, i) => { if (y < ys[lowI]) lowI = i; });
  let worst = 0;
  for (let i = lowI + 1; i < ys.length; i++) worst = Math.max(worst, ys[i - 1] - ys[i]);
  for (let i = lowI - 1; i >= 0; i--) worst = Math.max(worst, ys[i + 1] - ys[i]);
  return { worst, lowAt: (lowI * L) / n, low: ys[lowI] };
}
const cat = readSeedCatalog().filter(isPickable);
const cases: [string, Change[]][] = [
  ['-1"N', [{ end: "nose", amountIn: -1, fromTipIn: null }]],
  ['-1"T', [{ end: "tail", amountIn: -1, fromTipIn: null }]],
  ['-2"N', [{ end: "nose", amountIn: -2, fromTipIn: null }]],
  ['-2"T', [{ end: "tail", amountIn: -2, fromTipIn: null }]],
  ['-1"N18"', [{ end: "nose", amountIn: -1, fromTipIn: 18 }]],
  ['-1"T18"', [{ end: "tail", amountIn: -1, fromTipIn: 18 }]],
  ['-1/2"T12"', [{ end: "tail", amountIn: -0.5, fromTipIn: 12 }]],
  ['+2"N +2"T', [{ end: "nose", amountIn: 2, fromTipIn: null }, { end: "tail", amountIn: 2, fromTipIn: null }]],
];
const out: Record<string, { dips: string[]; moved: string[]; belowZero: string[] }> = {};
for (const [label, ch] of cases) {
  out[label] = { dips: [], moved: [], belowZero: [] };
  for (const rec of cat) {
    const p = prepareBlank(rec);
    const L = rec.lengthMm;
    const nat = steadiness((x) => p.rocker.sample(x), L);
    const f = (x: number) => p.rocker.sample(x) + delta(rec, ch, x);
    const s = steadiness(f, L);
    const tag = `${rec.vendor} ${rec.name}`;
    if (s.worst > 0.05) out[label].dips.push(`${tag} (${s.worst.toFixed(2)} mm)`);
    if (Math.abs(s.lowAt - nat.lowAt) > IN) out[label].moved.push(`${tag} (${((s.lowAt - nat.lowAt) / IN).toFixed(1)}")`);
    if (s.low < -0.05) out[label].belowZero.push(`${tag} (${(s.low / IN).toFixed(2)}")`);
  }
}
for (const [k, v] of Object.entries(out)) console.log(k.padEnd(12), "dips", v.dips.length, "low moved", v.moved.length, "below old low", v.belowZero.length, v.dips.slice(0, 4).join("; "), v.moved.slice(0,3).join("; "));
console.log("blanks", cat.length);

/**
 * Spike: can the app hold a blank maker's custom rocker as a bend applied AFTER the blank's natural
 * curve (the app's own square-root rule), and does it matter to the fit?
 *
 * Run from the worktree root:
 *   npx --no-install tsx --tsconfig ./tsconfig.json <this file> <listings.txt> <out.json>
 *
 * Reads the committed catalogue CSVs through the app's own reader, US Blanks' public rocker
 * listings (collected by hand from usblanks.com, July 2026 sheets), and writes a JSON of results.
 */
import { readFileSync, writeFileSync } from "node:fs";

const ROOT = "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275";
const { readSeedCatalog } = await import(`${ROOT}/lib/blanks/seed-files.ts`);
const { prepareBlank, levelCurve, judgeBlank, boardOnBlank } = await import(`${ROOT}/lib/geometry/blank-fit.ts`);
const { presetFitContext } = await import(`${ROOT}/lib/blanks/preset-blanks.ts`);
const { BOARD_PRESETS } = await import(`${ROOT}/lib/geometry/presets.ts`);
const { DEFAULT_FIT_DEFAULTS, toFitSettings } = await import(`${ROOT}/lib/fit-defaults-preference.ts`);
const { prepareRootCurve } = await import(`${ROOT}/lib/geometry/root-curve.ts`);

const IN = 25.4;
const [listingsPath, outPath] = process.argv.slice(2);

// ---------------------------------------------------------------- the rocker note parser
type End = "nose" | "tail";
interface Change { end: End; amountIn: number; fromTipIn: number | null }
interface Parsed {
  blank: string;
  text: string;
  kind: "natural" | "changes" | "named" | "named+changes" | "transfer" | "transfer+changes";
  changes: Change[];
  rest: string;
  naturalIn?: { nose: number; tail: number };
}

function amount(s: string): number {
  const t = s.trim();
  const m = t.match(/^(\d+)\s+(\d+)\/(\d+)$/);
  if (m) return Number(m[1]) + Number(m[2]) / Number(m[3]);
  const f = t.match(/^(\d+)\/(\d+)$/);
  if (f) return Number(f[1]) / Number(f[2]);
  return Number(t);
}

// sign, amount (whole, fraction, or whole + fraction), optional inch mark, N or T, optional from-tip length
const CHANGE = /([+-])\s*(\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?)\s*"?\s*([NT])(?:\s*(\d+(?:\.\d+)?)\s*"?)?/g;

function parseLine(line: string): Parsed | null {
  const m = line.match(/^(\d+'\d+"[A-Z]*)\s+(.*)$/);
  if (!m) return null;
  const blank = m[1];
  let body = m[2].replace(/\s*Rocker\s*$/i, "").replace(/Rocker$/i, "").trim();
  const nat = body.match(/^Natural\s+Rocker\s+N\s+([\d\-\/ ]+)["']\s*T\s+([\d\-\/ ]+)["']/i);
  if (nat) {
    const f = (s: string) => amount(s.replace("-", " "));
    return { blank, text: line, kind: "natural", changes: [], rest: "", naturalIn: { nose: f(nat[1]), tail: f(nat[2]) } };
  }
  const changes: Change[] = [];
  const rest = body
    .replace(CHANGE, (_all, sign, amt, nt, from) => {
      changes.push({
        end: nt === "N" ? "nose" : "tail",
        amountIn: (sign === "-" ? -1 : 1) * amount(amt),
        fromTipIn: from === undefined ? null : Number(from),
      });
      return " ";
    })
    .replace(/\s+/g, " ")
    .trim();
  const transfer = /\b(B\/C|D\/C|B\/T|D\/N)\b/.test(rest);
  const kind: Parsed["kind"] = transfer
    ? changes.length ? "transfer+changes" : "transfer"
    : rest ? (changes.length ? "named+changes" : "named") : "changes";
  return { blank, text: line, kind, changes, rest };
}

// ---------------------------------------------------------------- the bend
type Shape = "even" | "beam";
const bend = (u: number, shape: Shape) => (shape === "even" ? u * u : (u * u * (3 - u)) / 2);

interface Rec { vendor: string; name: string; lengthMm: number; stations: { label: string; fromTailMm: number; rockerMm: number | null }[] }

function pivotOf(rec: Rec, c: Change): number {
  const centre = rec.stations.find((s) => s.label === "C")!.fromTailMm;
  if (c.fromTipIn === null) return centre;
  const d = c.fromTipIn * IN;
  return c.end === "nose" ? rec.lengthMm - d : d;
}

function deltaAt(rec: Rec, changes: Change[], x: number, shape: Shape): number {
  let sum = 0;
  for (const c of changes) {
    const p = pivotOf(rec, c);
    if (c.end === "nose" && x > p) sum += c.amountIn * IN * bend((x - p) / (rec.lengthMm - p), shape);
    if (c.end === "tail" && x < p) sum += c.amountIn * IN * bend((p - x) / p, shape);
  }
  return sum;
}

/** A dense PreparedPchip-shaped curve: natural + bend, knots every 1/8" so the app's knot-minimum reads true. */
function customCurve(prepared: any, changes: Change[], shape: Shape) {
  const rec: Rec = prepared.record;
  const L = rec.lengthMm;
  const nat = prepared.rocker.curve;
  const f = (x: number) => nat.sample(x) + deltaAt(rec, changes, Math.min(Math.max(x, 0), L), shape);
  const step = IN / 8;
  const xs: number[] = [];
  for (let x = 0; x < L; x += step) xs.push(x);
  xs.push(L);
  const ys = xs.map(f);
  const h = 0.01;
  return {
    xs, ys, slopes: xs.map((x) => (f(Math.min(L, x + h)) - f(Math.max(0, x - h))) / (2 * h)),
    sample: f,
    slopeAt: (x: number) => (f(Math.min(L, x + h)) - f(Math.max(0, x - h))) / (2 * h),
  };
}

function withRocker(prepared: any, curve: any) {
  return { ...prepared, rocker: levelCurve(curve, 0, prepared.lengthMm) };
}

/** Steadiness: largest drop (mm) while walking away from the low point on either side. */
function steadiness(sample: (x: number) => number, L: number) {
  const n = Math.round(L / (IN / 8));
  const xs = Array.from({ length: n + 1 }, (_, i) => (i * L) / n);
  const ys = xs.map(sample);
  let lowI = 0;
  ys.forEach((y, i) => { if (y < ys[lowI]) lowI = i; });
  let worst = 0;
  for (let i = lowI + 1; i < ys.length; i++) worst = Math.max(worst, ys[i - 1] - ys[i]);
  for (let i = lowI - 1; i >= 0; i--) worst = Math.max(worst, ys[i + 1] - ys[i]);
  return { worstDropMm: worst, lowAtMm: xs[lowI], lowMm: ys[lowI] };
}

// ---------------------------------------------------------------- run
const catalogue: Rec[] = readSeedCatalog();
const usb = new Map(catalogue.filter((r) => r.vendor === "US Blanks").map((r) => [r.name, r]));
const lines = readFileSync(listingsPath, "utf8").split(/\r?\n/).filter(Boolean);
const parsed = lines.map(parseLine);
const failures = lines.filter((_, i) => parsed[i] === null);
const items = parsed.filter((p): p is Parsed => p !== null);

const kinds: Record<string, number> = {};
for (const p of items) kinds[p.kind] = (kinds[p.kind] ?? 0) + 1;

// natural check: listing's natural vs catalogue N0/T0
const naturals = items.filter((p) => p.kind === "natural").map((p) => {
  const rec = usb.get(p.blank);
  const n0 = rec?.stations.find((s) => s.label === "N0")?.rockerMm ?? null;
  const t0 = rec?.stations.find((s) => s.label === "T0")?.rockerMm ?? null;
  return {
    blank: p.blank, inCatalogue: !!rec,
    listing: p.naturalIn,
    catalogueIn: rec ? { nose: n0 === null ? null : n0 / IN, tail: t0 === null ? null : t0 / IN } : null,
  };
});

// bends on every listed change whose blank is in the catalogue
const bendRows: any[] = [];
for (const p of items) {
  if (!p.changes.length) continue;
  const rec = usb.get(p.blank);
  if (!rec) continue;
  const prepared = prepareBlank(rec as any);
  const L = rec.lengthMm;
  const natSteady = steadiness((x) => prepared.rocker.sample(x), L);
  const out: any = { blank: p.blank, text: p.text, kind: p.kind, changes: p.changes };
  for (const shape of ["even", "beam"] as Shape[]) {
    const curve = customCurve(prepared, p.changes, shape);
    const lev = levelCurve(curve as any, 0, L);
    const st = steadiness((x) => lev.sample(x), L);
    const tipN = lev.sample(L) - prepared.rocker.sample(L);
    const tipT = lev.sample(0) - prepared.rocker.sample(0);
    out[shape] = {
      noseTipChangeIn: tipN / IN, tailTipChangeIn: tipT / IN,
      lowShiftIn: (st.lowAtMm - natSteady.lowAtMm) / IN, relevelIn: lev.minimum / IN,
      worstDropMm: st.worstDropMm,
    };
  }
  // even vs beam: largest difference anywhere
  const ce = customCurve(prepared, p.changes, "even");
  const cb = customCurve(prepared, p.changes, "beam");
  let maxDiff = 0;
  for (let x = 0; x <= L; x += IN / 4) maxDiff = Math.max(maxDiff, Math.abs(ce.sample(x) - cb.sample(x)));
  out.evenVsBeamMaxMm = maxDiff;
  out.naturalWorstDropMm = natSteady.worstDropMm;
  bendRows.push(out);
}

// fit impact: Shortboard preset in its 6'3"RP, Longboard preset in its 9'4"B
const settings = toFitSettings(DEFAULT_FIT_DEFAULTS);
const fitRows: any[] = [];
for (const presetId of ["shortboard", "longboard"]) {
  const preset = BOARD_PRESETS.find((p: any) => p.id === presetId);
  const ctx = presetFitContext(preset);
  const blankName = preset.blank.name;
  const rec = usb.get(blankName)!;
  const prepared = prepareBlank(rec as any);
  const base = judgeBlank(prepared, ctx, settings);
  const row = (label: string, v: any) => ({
    preset: presetId, blank: blankName, rocker: label, fits: v.fits,
    placementIn: v.placement / IN, worst: { ...v.worst, amountIn: v.worst?.amount === undefined ? undefined : v.worst.amount / IN },
  });
  fitRows.push(row("Natural", base));
  for (const p of items.filter((q) => q.blank === blankName && q.changes.length && q.kind === "changes")) {
    const v = judgeBlank(withRocker(prepared, customCurve(prepared, p.changes, "even")), ctx, settings);
    fitRows.push(row(p.text.replace(`${blankName} `, ""), v));
  }
}

// the board's own five-station rocker, natural vs custom (what VIEWER / DATASHEET would read)
const boardRows: any[] = [];
for (const [presetId, picks] of [
  ["shortboard", ["+1/2\"T Rocker", "-1/2\"N Rocker", "+1/4\"T18\" Rocker"]],
  ["longboard", ["-1/2\"N24\" Rocker", "-1/4\"N18\" +1/8\"T36\" +1/8\"T18\" Rocker", "+1/2\"N +1/2\"T Rocker", "-1 1/2\"N Rocker"]],
] as [string, string[]][]) {
  const preset = BOARD_PRESETS.find((p: any) => p.id === presetId);
  const ctx = presetFitContext(preset);
  const rec = usb.get(preset.blank.name)!;
  const prepared = prepareBlank(rec as any);
  const L = ctx.board.length;
  const read = (pb: any) => {
    const ob = boardOnBlank(pb, ctx.board, preset.blank.placement);
    const at = (s: number) => ob.rockerAt(s) / IN;
    return { tail: at(0), t12: at(12 * IN), centre: at(L / 2), n12: at(L - 12 * IN), nose: at(L) };
  };
  boardRows.push({ preset: presetId, blank: rec.name, boardLengthIn: L / IN, rocker: "Natural", ...read(prepared) });
  for (const label of picks) {
    const p = items.find((q) => q.blank === rec.name && q.text.replace(/\s+/g, " ").endsWith(label))!;
    boardRows.push({ preset: presetId, blank: rec.name, boardLengthIn: L / IN, rocker: label, ...read(withRocker(prepared, customCurve(prepared, p.changes, "even"))) });
  }
}

// Arctic: is a named stock rocker just a change at the tips from centre? (rows read by eye from arcticfoam.us)
const F = (s: string) => amount(s);
const arcticTables: Record<string, Record<string, [string, string, string, string]>> = {
  "5'8\" SB": {
    "HG9": ["5", "1 3/16", "13/16", "2 1/4"], NAT: ["4 3/8", "1 1/8", "3/4", "2"], M06: ["4 3/16", "1 1/16", "9/16", "2"],
    M07: ["4 3/16", "1 1/8", "1/2", "1 11/16"], M09: ["5 3/16", "1 1/4", "1/2", "2 3/16"], FLIPPER: ["4 13/16", "1", "3/8", "1 1/2"],
    TP: ["5 7/16", "1 3/16", "1/2", "1 15/16"], PCE: ["6", "1 3/8", "3/4", "2 3/8"], C5: ["4 1/2", "1 1/8", "3/4", "2 3/8"],
    R3: ["5", "1 1/16", "1 7/8", "2 1/4"], "ROR-08": ["4 1/8", "1", "15/16", "2 1/2"], "ROR-05": ["4 5/8", "1 1/8", "7/8", "2 5/8"],
    "ROR-05-2": ["4 7/8", "1 1/8", "13/16", "2 1/2"],
  },
  "9'3\" LB": {
    NAT: ["4 9/16", "2 1/16", "1 7/8", "3 1/2"], BORST: ["3 7/8", "1 9/16", "1 7/16", "2 7/8"], "BI HOPPER": ["4 11/16", "2 3/16", "2 15/16", "5 3/8"],
    LSP: ["4 1/4", "1 15/16", "1 15/16", "3 11/16"], "ROR-02": ["5", "2 3/4", "1 9/16", "2 11/16"], HP: ["5 7/8", "3 1/8", "1 5/16", "2 1/2"],
    "HY NECTAR": ["3 1/4", "1 5/8", "1 3/4", "3 1/4"], MARTIN: ["3 7/16", "1 7/16", "1 11/16", "3 1/16"], NOSERIDER: ["3 1/4", "1 1/4", "2 3/16", "4"],
    NR: ["4 1/8", "2 1/8", "1 13/16", "3 1/2"], YATER: ["4 3/16", "1 15/16", "2 1/8", "3 11/16"],
  },
};
const arc = new Map(catalogue.filter((r) => r.vendor === "Arctic Foam").map((r) => [r.name, r]));
const arcticRows: any[] = [];
for (const [name, table] of Object.entries(arcticTables)) {
  const rec = arc.get(name)!;
  const pos = (label: string) => rec.stations.find((s) => s.label === label)!.fromTailMm;
  const pts = (row: [string, string, string, string]) => [
    { x: pos("T0"), y: F(row[3]) * IN }, { x: pos("T12"), y: F(row[2]) * IN }, { x: pos("C"), y: 0 },
    { x: pos("N12"), y: F(row[1]) * IN }, { x: pos("N0"), y: F(row[0]) * IN },
  ];
  const natCurve = prepareRootCurve(pts(table.NAT), "rise");
  const natRec: Rec = { ...rec, stations: rec.stations };
  const cat = (label: string) => (rec.stations.find((s) => s.label === label)!.rockerMm ?? NaN) / IN;
  for (const [rocker, row] of Object.entries(table)) {
    const dN = (F(row[0]) - F(table.NAT[0])), dT = (F(row[3]) - F(table.NAT[3]));
    const ch: Change[] = [{ end: "nose", amountIn: dN, fromTipIn: null }, { end: "tail", amountIn: dT, fromTipIn: null }];
    const at = (label: string) => (natCurve.sample(pos(label)) + deltaAt(natRec, ch, pos(label), "even")) / IN;
    arcticRows.push({
      blank: name, rocker,
      tipChanges: { nose: dN, tail: dT },
      n12: { table: F(row[1]), fromCentreChange: at("N12"), offBy: F(row[1]) - at("N12") },
      t12: { table: F(row[2]), fromCentreChange: at("T12"), offBy: F(row[2]) - at("T12") },
      catalogueNow: { N0: cat("N0"), N12: cat("N12"), T12: cat("T12"), T0: cat("T0") },
    });
  }
}

// Marko 10'2" M: a from-centre change on a blank whose printed centre is not its low point
const marko = catalogue.find((r) => r.vendor === "Marko Foam" && r.name === "10'2\" M")!;
const mp = prepareBlank(marko as any);
const markoRows = [["+1\"N", [{ end: "nose", amountIn: 1, fromTipIn: null }]], ["-1/2\"T", [{ end: "tail", amountIn: -0.5, fromTipIn: null }]]].map(
  ([label, ch]: any) => {
    const lev = levelCurve(customCurve(mp, ch, "even") as any, 0, mp.lengthMm);
    const s = steadiness((x) => lev.sample(x), mp.lengthMm);
    const n = steadiness((x) => mp.rocker.sample(x), mp.lengthMm);
    return { label, naturalLowAtIn: n.lowAtMm / IN, customLowAtIn: s.lowAtMm / IN, centreAtIn: mp.record.stations.find((x: any) => x.label === "C").fromTailMm / IN,
      noseTipIn: lev.sample(mp.lengthMm) / IN, naturalNoseTipIn: mp.rocker.sample(mp.lengthMm) / IN, worstDropMm: s.worstDropMm };
  },
);

// picture data: three examples, natural vs custom (even bend), sampled every inch
const pictures = [
  ["9'3\"Y", "9'3\"Y -1/2\"N24\" +1/2\"T24\" Rocker"],
  ["9'4\"B", "9'4\"B -1/4\"N18\" +1/8\"T36\" +1/8\"T18\" Rocker"],
  ["6'3\"RP", "6'3\"RP +1/4\"T18\" Rocker"],
  ["6'4\"EA", "6'4\"EA -1/2\"N12\" +1/2\"T24\" Rocker"],
].map(([blank, text]) => {
  const p = items.find((q) => q.text.replace(/\s+/g, " ") === text.replace(/\s+/g, " "))!;
  const rec = usb.get(blank)!;
  const prepared = prepareBlank(rec as any);
  const lev = levelCurve(customCurve(prepared, p.changes, "even") as any, 0, rec.lengthMm);
  const levB = levelCurve(customCurve(prepared, p.changes, "beam") as any, 0, rec.lengthMm);
  const pts: number[][] = [];
  for (let x = 0; x <= rec.lengthMm + 1e-9; x += IN) pts.push([x / IN, prepared.rocker.sample(x) / IN, lev.sample(x) / IN, levB.sample(x) / IN]);
  const printed = rec.stations.filter((s) => s.rockerMm !== null).map((s) => ({ label: s.label, xIn: s.fromTailMm / IN, natIn: prepared.rocker.sample(s.fromTailMm) / IN, customIn: lev.sample(s.fromTailMm) / IN }));
  return { blank, text, changes: p.changes, lengthIn: rec.lengthMm / IN, pts, printed, pivotsIn: p.changes.map((c) => pivotOf(rec, c) / IN) };
});

const summary = {
  listings: { lines: lines.length, parseFailures: failures, kinds },
  naturals,
  bends: {
    count: bendRows.length,
    tipExact: bendRows.every((r) => ["even", "beam"].every((s) => {
      const want = (end: End) => r.changes.filter((c: Change) => c.end === end).reduce((a: number, c: Change) => a + c.amountIn, 0);
      return Math.abs(r[s].noseTipChangeIn + r[s].relevelIn - want("nose")) < 1e-6 && Math.abs(r[s].tailTipChangeIn + r[s].relevelIn - want("tail")) < 1e-6;
    })),
    relevelled: bendRows.filter((r) => Math.abs(r.even.relevelIn) > 1e-4).map((r) => ({ text: r.text, relevelIn: r.even.relevelIn, lowShiftIn: r.even.lowShiftIn })),
    worstDropEvenMm: Math.max(...bendRows.map((r) => r.even.worstDropMm)),
    worstDropBeamMm: Math.max(...bendRows.map((r) => r.beam.worstDropMm)),
    naturalWorstDropMm: Math.max(...bendRows.map((r) => r.naturalWorstDropMm)),
    evenVsBeamMaxMm: Math.max(...bendRows.map((r) => r.evenVsBeamMaxMm)),
    evenVsBeamPerHalfInchMm: Math.max(...bendRows.map((r) => r.evenVsBeamMaxMm / (Math.max(...r.changes.map((c: Change) => Math.abs(c.amountIn))) * 2))),
  },
};
writeFileSync(outPath, JSON.stringify({ summary, bendRows, fitRows, boardRows, arcticRows, markoRows, pictures, parsed: items }, null, 1));
console.log(JSON.stringify(summary, null, 1));
console.log("FIT");
for (const r of fitRows) console.log(r.preset, r.blank, r.rocker.padEnd(36), r.fits ? "FITS" : "won't", "placement", r.placementIn.toFixed(2), JSON.stringify(r.worst));
console.log("BOARD"); for (const r of boardRows) console.log(r.preset, r.blank, r.rocker.padEnd(40), ["tail","t12","centre","n12","nose"].map((k) => k + " " + r[k].toFixed(3)).join("  "));
console.log("ARCTIC");
for (const r of arcticRows) console.log(r.blank, r.rocker.padEnd(10), "tipΔ N", r.tipChanges.nose.toFixed(3), "T", r.tipChanges.tail.toFixed(3), "| N12 off", r.n12.offBy.toFixed(3), "T12 off", r.t12.offBy.toFixed(3));
console.log("CATALOGUE NOW", JSON.stringify(arcticRows.filter((r) => r.rocker === "NAT").map((r) => [r.blank, r.catalogueNow])));
console.log("MARKO", JSON.stringify(markoRows));

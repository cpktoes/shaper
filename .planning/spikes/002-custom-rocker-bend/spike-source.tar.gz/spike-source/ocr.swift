import Foundation
import Vision
import AppKit
// usage: ocr <png> [png...]  -> prints lines with y (top=0..1)
for path in CommandLine.arguments.dropFirst() {
  guard let img = NSImage(contentsOfFile: path), let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else { print("ERR \(path)"); continue }
  let req = VNRecognizeTextRequest()
  req.recognitionLevel = .accurate
  req.usesLanguageCorrection = true
  try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([req])
  print("##### \(path)")
  let obs = (req.results ?? []).sorted { a, b in
    let ay = 1 - a.boundingBox.maxY, by = 1 - b.boundingBox.maxY
    return abs(ay - by) > 0.01 ? ay < by : a.boundingBox.minX < b.boundingBox.minX }
  for o in obs { if let t = o.topCandidates(1).first { print(String(format: "%.3f %.3f ", 1 - o.boundingBox.maxY, o.boundingBox.minX) + t.string) } }
}

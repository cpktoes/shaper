import re, csv, sys
txt = open(sys.argv[1]).read()
pages = re.split(r'\n===== PAGE (\d+) [^\n]*=====\n', txt)
rows = list(csv.DictReader(open(sys.argv[2], newline='')))
byp = {}
for r in rows: byp.setdefault(int(r['pdf_page']), {})[r['station']] = r
for i in range(1, len(pages), 2):
    num, body = int(pages[i]), pages[i+1]
    blank = re.search(r'Blank: *([^\n]*)', body); code = re.search(r'Stock Rocker: *(\S+)', body)
    st = byp.get(num, {})
    name = next(iter(st.values()))['blank_name'] if st else '?'
    rk = ' '.join(f"{k}={float(st[k]['rocker_in']):.3f}" for k in ['N0','N3','N12','C','T12','T0'] if k in st and st[k]['rocker_in'] != '')
    L = next(iter(st.values()))['length_in'] if st else ''
    print(f"p{num:2d} {name:10s} L={L:7s} code={code.group(1) if code else '-':4s} {rk}")

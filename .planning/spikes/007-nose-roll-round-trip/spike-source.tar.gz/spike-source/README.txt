Spike 007 (nose-roll-round-trip): scripts, the trial code and raw outputs (2026-11-25).

trial-code.diff   the trial polishBrdBottom, against main d36cb614 (lib/geometry/brd-bottom.ts only). With no S7_ switch it
                  is today's code exactly. Built by scripts/patch1.py .. patch4.py in that order.
scripts/          grid.mts (the 296-board round trip), measure.mts (the twelve sample files, read in place, never copied),
                  run-grid.sh / run-twelve.sh, analyze.mjs (scores), sim.mjs (replays the choice from a collect run),
                  sweep.mjs, sweep2.mjs, tiediff.mjs, prune.mjs, hybrid.mjs, sigcombos.mjs, kinds.mjs, namepref.mjs,
                  detail.mjs, vsreal.mjs, findingb.mjs, realdiff.mjs, names.mjs, triggers.mjs, where.mts, picdata.mts,
                  picture.cjs
results/          base.* (today, the trial with every switch off = main), collect.* (every start logged), rec.*, recsig.*,
                  hyb.* (the recommendation), lbnose.* (Longboard, nose-only judging), q*.log (quiet timings of 8 boards),
                  main-loaded.json / t12-*.json (the twelve files: names, figures, digests only), and the text tables
                  quoted in the README.
The founder's .brd files are not in here.

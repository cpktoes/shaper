# Spike 007 trial patch: replaces polishBrdBottom in the WORKTREE's lib/geometry/brd-bottom.ts with an env-switched trial.
import sys, re
p = sys.argv[1]
src = open(p).read()
i = src.index("export function polishBrdBottom(")
head = src[:i]
new = r'''export function polishBrdBottom(bottom: BoardBottom, sections: readonly BrdBottomSection[], board0: BottomBoard): BoardBottom {
  const env = (k: string): string => (typeof process !== "undefined" && process.env[k]) || "";
  const TRIG = env("S7_TRIG") || "gate"; // gate | belly | sig | belly+sig | always
  const START = env("S7_START") || "fresh"; // fresh | own | both
  const SEED = env("S7_SEED"); // "" | sig
  const DROP = env("S7_DROP") === "1";
  const KINDS = env("S7_KINDS"); // "" | all
  const TIE = env("S7_TIE") === "" ? null : Number(env("S7_TIE"));
  const FLATROLL = env("S7_FLATROLL") === "1";
  const log: any[] = ((globalThis as any).__s7 ??= []);

  const scorer = brdBottomScorer(board0, brdBottomBlends(sections));
  const { specs } = scorer.polish({ nose: bottom.nose, center: bottom.center, tail: bottom.tail });
  const polished = { ...bottom, nose: specs.nose, center: specs.center, tail: specs.tail };
  const close = (b: BoardBottom) => measureBrdBottom(b, sections, board0).closeness;
  const shown = (b: BoardBottom): number => {
    const { largest, typical } = close(b);
    return largest + typical;
  };
  const today = shown(polished) <= shown(bottom) + NOISE ? polished : bottom;
  const todayClose = close(today);
  const overGate = todayClose.largest > BRD_BOTTOM_NOSE_RETRY_MM;

  // --- idea 2: the shape across the nose. A dish that turns up outside it (a concave with a roll), per nose section. ---
  const L = board0.length;
  const J = BRD_BOTTOM_ACROSS_STEPS;
  let sig: { station: number; dish: number; turn: number; onset: number; offRail: number; roll: number } | null = null;
  let dishMax = 0;
  for (const s of sections) {
    if (s.station < L / 2) continue;
    let vmin = Infinity;
    for (const v of s.file) if (v < vmin) vmin = v;
    let jm = 0;
    for (let j = 0; j <= J; j++) if (s.file[j] <= vmin + 0.05) jm = j;
    const turn = s.file[J] - vmin;
    const dish = -vmin;
    if (dish > dishMax) dishMax = dish;
    if (jm < J && jm >= 0.3 * J && turn >= 0.3 && dish >= 0.5) {
      const C = s.across[jm];
      const offRail = Math.min(inchesToMm(BOTTOM_MARK_RANGES_IN.offRail.max), Math.max(0, board0.railAt(s.station) - C));
      const share = railRollAcross({ offRail: mm(offRail) }, board0, "narrowest", s.station, s.window);
      const roll = share > 0.1 ? Math.min(inchesToMm(0.5), Math.max(inchesToMm(1 / 16), turn / share)) : inchesToMm(1 / 8);
      if (!sig || turn > sig.turn) sig = { station: s.station, dish, turn, onset: jm / J, offRail, roll };
    }
  }

  const noseKind = cutKind(today.nose.name);
  const centreKind = cutKind(today.center.name);
  const centreLift = centreKind === "belly" || centreKind === "vee";
  const bellyInNose = noseKind === "belly" || centreLift;
  const triggered =
    overGate ||
    TRIG === "always" ||
    (TRIG.includes("belly") && bellyInNose) ||
    (TRIG.includes("sig") && sig !== null);
  const entry: any = {
    today: { nose: today.nose, center: today.center, tail: today.tail, largest: todayClose.largest, typical: todayClose.typical },
    overGate, bellyInNose, sig, triggered, cands: [] as any[],
  };
  log.push(entry);
  if (!triggered) return today;

  // --- the starts ---
  const fresh = (name: BottomCutName): BottomCutSpec => {
    const base = startingCut("nose", name, board0);
    if (SEED === "sig" && sig) {
      return {
        ...base,
        depth: mm(Math.min(inchesToMm(0.5), Math.max(inchesToMm(BOTTOM_MARK_STEP_IN), dishMax))),
        offRail: mm(sig.offRail),
        railRoll: mm(sig.roll),
      };
    }
    return { ...base, depth: inchesToMm(BOTTOM_MARK_STEP_IN), railRoll: inchesToMm(BRD_BOTTOM_NOSE_RETRY_ROLL_IN) };
  };
  const starts: { tag: string; nose: BottomCutSpec }[] = [];
  const ownIs = takesRailRoll("nose", today.nose.name) && today.nose.depth > 0;
  // S7_STARTS: a comma list of fresh | own | seed | slight | teardrop (overrides S7_START / S7_SEED / S7_KINDS).
  const LIST = env("S7_STARTS") ? env("S7_STARTS").split(",") : null;
  const plain = (name: BottomCutName): BottomCutSpec => ({ ...startingCut("nose", name, board0), depth: inchesToMm(BOTTOM_MARK_STEP_IN), railRoll: inchesToMm(BRD_BOTTOM_NOSE_RETRY_ROLL_IN) });
  const seeded = (name: BottomCutName): BottomCutSpec => ({
    ...startingCut("nose", name, board0),
    depth: mm(Math.min(inchesToMm(0.5), Math.max(inchesToMm(BOTTOM_MARK_STEP_IN), dishMax))),
    offRail: mm(sig!.offRail),
    railRoll: mm(sig!.roll),
  });
  const ownStart = (): BottomCutSpec => ({ ...today.nose, railRoll: today.nose.railRoll && today.nose.railRoll > 0 ? today.nose.railRoll : inchesToMm(BRD_BOTTOM_NOSE_RETRY_ROLL_IN) });
  if (LIST) {
    if (LIST.includes("own") && ownIs) starts.push({ tag: "own", nose: ownStart() });
    if (LIST.includes("fresh") || (LIST.includes("freshelse") && !ownIs)) starts.push({ tag: "fresh", nose: plain("Blended Nose Concave") });
    if (LIST.includes("seed") && sig) starts.push({ tag: "seed", nose: seeded("Blended Nose Concave") });
    if (LIST.includes("slight")) starts.push({ tag: "slight", nose: plain("Slight Single Concave Entry") });
    if (LIST.includes("teardrop")) starts.push({ tag: "teardrop", nose: plain("Teardrop Nose Concave") });
  } else {
    if ((START === "own" || START === "both") && ownIs) starts.push({ tag: "own", nose: ownStart() });
    if (START === "fresh" || START === "both" || !ownIs) {
      starts.push({ tag: "fresh", nose: fresh("Blended Nose Concave") });
      if (KINDS === "all" && !ownIs) {
        starts.push({ tag: "slight", nose: fresh("Slight Single Concave Entry") });
        starts.push({ tag: "teardrop", nose: fresh("Teardrop Nose Concave") });
      }
    }
  }
  const flatCentre = startingCut("center", FLAT_CUT_NAMES.center, board0);
  const centres: { tag: string; center: BottomCutSpec }[] = [{ tag: "", center: today.center }];
  if (DROP && centreKind !== "flat") centres.push({ tag: "+drop", center: flatCentre });

  const cutsOf = (b: BoardBottom) => cutsIn({ nose: b.nose, center: b.center, tail: b.tail });
  const shownToday = shown(today);
  const cutsToday = cutsOf(today);
  (globalThis as any).__s7flat = FLATROLL;
  interface Cand { tag: string; b: BoardBottom; shown: number; cuts: number; bar: number; rule: string }
  const cands: Cand[] = [];
  for (const st of starts) {
    for (const ce of centres) {
      const more = scorer.polish({ nose: st.nose, center: ce.center, tail: today.tail }, true).specs;
      const b: BoardBottom = { ...today, nose: more.nose, center: more.center, tail: more.tail };
      const c = close(b);
      const cuts = cutsOf(b);
      const replacesBelly = (noseKind === "belly" && cutKind(b.nose.name) === "single") || (centreLift && cutKind(b.center.name) === "flat");
      let bar: number;
      let rule: string;
      if (TIE !== null && replacesBelly) { bar = -TIE; rule = "tie"; }
      else if (cuts < cutsToday) { bar = -BRD_BOTTOM_EXTRA_CUT_MM; rule = "fewer"; }
      else if (b.nose.name === today.nose.name && cuts === cutsToday) { bar = NOISE; rule = "same"; }
      else { bar = BRD_BOTTOM_EXTRA_CUT_MM; rule = "extra"; }
      // Without a tie margin and without DROP this is today's rule exactly.
      if (TIE === null && !DROP) { bar = today.nose.name === b.nose.name ? NOISE : BRD_BOTTOM_EXTRA_CUT_MM; rule = "legacy"; }
      cands.push({ tag: st.tag + ce.tag, b, shown: c.largest + c.typical, cuts, bar, rule });
      entry.cands.push({ tag: st.tag + ce.tag, nose: b.nose, center: b.center, tail: b.tail, largest: c.largest, typical: c.typical, cuts, bar, rule, replacesBelly });
    }
  }
  (globalThis as any).__s7flat = false;
  const ok = cands.filter((c) => c.shown < shownToday - c.bar);
  if (ok.length === 0) { entry.kept = "today"; return today; }
  const closest = Math.min(...ok.map((c) => c.shown));
  const near = ok.filter((c) => c.shown <= closest + BRD_BOTTOM_EXTRA_CUT_MM);
  const fewest = Math.min(...near.map((c) => c.cuts));
  const pick = near.filter((c) => c.cuts === fewest).sort((a, b) => a.shown - b.shown)[0];
  entry.kept = pick.tag;
  return pick.b;
}
'''
src = head + new
# idea 5 (measured apart): a rolled nose concave's Depth may fall to almost nothing in the roll polish.
old = '      if (field === "depth") return Math.min(BOTTOM_DEPTH_RANGE_IN.max * IN, Math.max(BOTTOM_MARK_STEP_IN * IN, inches * IN));'
assert old in src
src = src.replace(old, '      if (field === "depth") return Math.min(BOTTOM_DEPTH_RANGE_IN.max * IN, Math.max(rollFree && (globalThis as any).__s7flat ? 0.01 : BOTTOM_MARK_STEP_IN * IN, inches * IN));')
open(p, "w").write(src)

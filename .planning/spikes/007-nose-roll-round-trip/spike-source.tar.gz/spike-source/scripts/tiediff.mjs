// Spike 007: which boards a tie margin decides (tie A vs tie B), for one trigger + starts with the drop on.
import { load, score } from "./analyze.mjs";
import { replay, STARTS } from "./sim.mjs";
const [trig, st, a, b, fb = "0.25", label = "collect"] = process.argv.slice(2);
const rows = load(label);
const P = (t) => replay(rows, { trig, starts: STARTS[st], drop: true, tie: t === "null" ? null : Number(t), fewerBar: Number(fb) });
const A = P(a), B = P(b);
const w = (c) => c.map((k) => (k.depth > 0 ? `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")} ${(k.depth * 64).toFixed(0)}/64${k.roll > 0.005 ? " r" + (k.roll * 64).toFixed(0) + "/64" : ""}` : "Flat")).join(" · ");
for (const x of [A, B]) { const s = score(x); console.log(`c+r ${s.concaveRoll} clean ${s.clean} falseConc ${s.falseConc} invented ${s.invented}`); }
for (let i = 0; i < rows.length; i++) if (A[i].kept !== B[i].kept) console.log(`${rows[i].id.padEnd(44)} tie ${a}: ${A[i].largest.toFixed(2)}/${A[i].typical.toFixed(2)} ${w(A[i].back)}  |  tie ${b}: ${B[i].largest.toFixed(2)}/${B[i].typical.toFixed(2)} ${w(B[i].back)}`);

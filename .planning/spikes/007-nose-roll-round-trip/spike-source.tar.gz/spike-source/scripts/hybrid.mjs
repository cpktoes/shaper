// Spike 007: a cheaper recommended search: over 1 mm, all three starts (fitted, fresh, seed); under 1 mm (tried only for
// the dish), the fitted concave or else the fresh one, plus the seed; then the drop on the best. Signature trigger.
import { load, score } from "./analyze.mjs";
import { pick } from "./sim.mjs";
const rows = load("collect");
const sh = (c) => c.largest + c.typical;
for (const hybrid of [false, true]) {
  let pol = 0, n = 0;
  const out = rows.map((r) => {
    const l = r.log;
    if (!(l.overGate || l.sig)) return { ...r, back: l.today.cuts, largest: l.today.largest, typical: l.today.typical };
    const own = l.cands.some((c) => c.tag === "own");
    const set = hybrid && !l.overGate ? [own ? "own" : "fresh", "seed"] : ["own", "fresh", "seed"];
    const base = l.cands.filter((c) => set.includes(c.tag));
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    const tags = new Set([...base.map((c) => c.tag), best.tag + "+drop"]);
    const cands = l.cands.filter((c) => tags.has(c.tag)); pol += cands.length; n++;
    const p = pick({ ...l, cands }, { trig: "always", starts: () => set, drop: true, tie: 0.05 });
    return { ...r, back: p.cuts, largest: p.largest, typical: p.typical };
  });
  const s = score(out);
  console.log(`${hybrid ? "hybrid" : "recommended"} polishes/tried ${(pol / n).toFixed(2)} c+r ${s.concaveRoll} ≤1/16 ${s.close16} clean ${s.clean} widest ${s.widest.toFixed(3)}/${s.typical.toFixed(3)} invented ${s.invented} falseConc ${s.falseConc}`);
}

// Spike 007: how well the offline replay agrees with a real run through the import, case by case.
//   node vsreal.mjs <real label> <trig> <starts> <drop 0|1> <tie|null> [collect label] [--prune]
import { load } from "./analyze.mjs";
import { replay, STARTS, pick } from "./sim.mjs";
const [realL, trig, st, drop, tie, colL = "collect", pr] = process.argv.slice(2);
const real = new Map(load(realL).map((r) => [r.id, r]));
const rows = load(colL);
const sh = (c) => c.largest + c.typical;
const sim = pr ? rows.map((r) => { const l = r.log; const t = l.overGate || l.bellyInNose || l.sig; if (!t) return { ...r, back: l.today.cuts, largest: l.today.largest, typical: l.today.typical }; const base = l.cands.filter((c) => ["own", "fresh", "seed"].includes(c.tag)); const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b)); const tags = new Set([...base.map((c) => c.tag), best.tag + "+drop"]); const p = pick({ ...l, cands: l.cands.filter((c) => tags.has(c.tag)) }, { trig: "always", starts: () => ["own", "fresh", "seed"], drop: true, tie: Number(tie) }); return { ...r, back: p.cuts, largest: p.largest, typical: p.typical, kept: p.tag }; })
  : replay(rows, { trig, starts: STARTS[st], drop: drop === "1", tie: tie === "null" ? null : Number(tie) });
let same = 0, diffs = [];
for (const s of sim) { const r = real.get(s.id); if (!r) continue; const d = Math.abs(r.largest - s.largest) + Math.abs(r.typical - s.typical); const names = r.back.map((k) => k.name).join() === s.back.map((k) => k.name).join(); if (d < 0.011 && names) same++; else diffs.push(`${s.id.padEnd(44)} sim ${s.largest.toFixed(2)}/${s.typical.toFixed(2)} ${s.back.map((k) => k.name.split(" ")[0] + (k.depth ? (k.depth * 64).toFixed(0) : "") + (k.roll > 0.005 ? "r" + (k.roll * 64).toFixed(0) : "")).join(",")}  real ${r.largest.toFixed(2)}/${r.typical.toFixed(2)} ${r.back.map((k) => k.name.split(" ")[0] + (k.depth ? (k.depth * 64).toFixed(0) : "") + (k.roll > 0.005 ? "r" + (k.roll * 64).toFixed(0) : "")).join(",")}`); }
console.log(`agree ${same}, differ ${diffs.length}`); for (const d of diffs) console.log(" ", d);

# Spike 007 trial patch 4 (after patch3.py): S7_HYBRID=1, the cheaper search: a file still over 1 mm gets all three starts
# as before; a file tried only for its dish gets the fitted concave (or, with none, the fresh one) and the dish seed.
import sys
p = sys.argv[1]; s = open(p).read()
a = '''    if (ownIs) rs.push({ tag: "own", nose: ownStart() });
    rs.push({ tag: "fresh", nose: plain("Blended Nose Concave") });
'''
assert s.count(a) == 1
s = s.replace(a, '''    const cheap = env("S7_HYBRID") === "1" && !overGate;
    if (ownIs) rs.push({ tag: "own", nose: ownStart() });
    if (!(cheap && ownIs)) rs.push({ tag: "fresh", nose: plain("Blended Nose Concave") });
''')
open(p, "w").write(s); print("patched")

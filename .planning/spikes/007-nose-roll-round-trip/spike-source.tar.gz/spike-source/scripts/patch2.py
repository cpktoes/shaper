# Spike 007 trial patch 2: adds S7_MODE=rec to the trial polishBrdBottom (patch1.py must be applied first): the recommended
# search (the fitted concave, a fresh 1/16" Blended Nose Concave and the seeded start, each with the centre kept, then the
# centre dropped from the best of them) and the recommended choice (the founder's tie margin S7_TIE, the fewest-cuts rule,
# the 0.25 mm bar), exactly as sim.mjs replays it.
import sys
p = sys.argv[1]
src = open(p).read()
anchor = "  (globalThis as any).__s7flat = FLATROLL;\n"
assert src.count(anchor) == 1
block = anchor + r'''  if (env("S7_MODE") === "rec") {
    const tie = TIE ?? 0.05;
    const run = (tag: string, nose: BottomCutSpec, center: BottomCutSpec) => {
      const more = scorer.polish({ nose, center, tail: today.tail }, true).specs;
      const b: BoardBottom = { ...today, nose: more.nose, center: more.center, tail: more.tail };
      const c = close(b);
      entry.cands.push({ tag, nose: b.nose, center: b.center, tail: b.tail, largest: c.largest, typical: c.typical, cuts: cutsOf(b) });
      return { tag, b, nose, shown: c.largest + c.typical, cuts: cutsOf(b) };
    };
    const rs: { tag: string; nose: BottomCutSpec }[] = [];
    if (ownIs) rs.push({ tag: "own", nose: ownStart() });
    rs.push({ tag: "fresh", nose: plain("Blended Nose Concave") });
    if (sig) rs.push({ tag: "seed", nose: seeded("Blended Nose Concave") });
    const cs = rs.map((s) => run(s.tag, s.nose, today.center));
    if (centreKind !== "flat") {
      const best = cs.reduce((a, b) => (a.shown <= b.shown ? a : b));
      cs.push(run(best.tag + "+drop", best.nose, flatCentre));
    }
    (globalThis as any).__s7flat = false;
    const ok2 = cs.filter((c) => {
      const replaces = (noseKind === "belly" && cutKind(c.b.nose.name) === "single") || (centreLift && cutKind(c.b.center.name) === "flat");
      let bar = BRD_BOTTOM_EXTRA_CUT_MM;
      if (c.b.nose.name === today.nose.name && c.cuts === cutsToday) bar = Math.min(bar, NOISE);
      if (c.cuts < cutsToday) bar = Math.min(bar, -BRD_BOTTOM_EXTRA_CUT_MM);
      if (replaces && c.cuts <= cutsToday) bar = Math.min(bar, -tie);
      return c.shown < shownToday - bar;
    });
    if (ok2.length === 0) { entry.kept = "today"; return today; }
    const closest2 = Math.min(...ok2.map((c) => c.shown));
    const near2 = ok2.filter((c) => c.shown <= closest2 + BRD_BOTTOM_EXTRA_CUT_MM);
    const fewest2 = Math.min(...near2.map((c) => c.cuts));
    const pick2 = near2.filter((c) => c.cuts === fewest2).sort((a, b) => a.shown - b.shown)[0];
    entry.kept = pick2.tag;
    return pick2.b;
  }
'''
src = src.replace(anchor, block)
open(p, "w").write(src)
print("patched")

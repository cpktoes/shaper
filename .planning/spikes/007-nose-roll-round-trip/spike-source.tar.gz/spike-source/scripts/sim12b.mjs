// Spike 007: the twelve files replayed for the recommended search (fitted concave + fresh + seeded starts, then the drop on the best).
import { readFileSync } from "node:fs";
import { pick } from "./sim.mjs";
const rows = JSON.parse(readFileSync(new URL(`../out/${process.argv[2] ?? "twelve-collect"}.json`, import.meta.url), "utf8"));
const TIE = Number(process.argv[3] ?? 0.05);
const sh = (c) => c.largest + c.typical;
const w = (c) => c.map((k) => (k.depth > 0 ? `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")} ${Math.round(k.depth * 64)}/64${k.roll > 0 ? " r" + Math.round(k.roll * 64) + "/64" : ""}` : "Flat")).join(" · ");
for (const r of rows) {
  const l = r.log;
  const trig = l.overGate || l.bellyInNose || l.sig;
  let p = { tag: "untouched", ...l.today };
  if (trig) {
    const base = l.cands.filter((c) => ["own", "fresh", "seed"].includes(c.tag));
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    const tags = new Set([...base.map((c) => c.tag), best.tag + "+drop"]);
    p = pick({ ...l, cands: l.cands.filter((c) => tags.has(c.tag)) }, { trig: "always", starts: () => ["own", "fresh", "seed"], drop: true, tie: TIE });
  }
  console.log(`${r.file.padEnd(36)} ${trig ? "tried" : "     "} ${p.largest.toFixed(2)} / ${p.typical.toFixed(2)}  ${w(p.cuts)} (${p.tag})`);
}

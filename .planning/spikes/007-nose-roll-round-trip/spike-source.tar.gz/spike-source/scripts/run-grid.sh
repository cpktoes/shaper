#!/bin/bash
# Spike 007: one grid run in N shards through the trial worktree. run-grid.sh <label> <shards> [ENV=VALUE ...]
S=/private/tmp/claude-501/-Users-kontoes-Code-shaper/002e2a58-3c43-4c8e-bbb5-e9c435113dd2/scratchpad/spike007
label=$1; n=$2; shift 2
for ((i=0; i<n; i++)); do
  ( env ROOT=$S/wt "$@" npx --no-install tsx --tsconfig $S/wt/tsconfig.json $S/scripts/grid.mts "$label" $i $n all > $S/out/$label.$i.log 2>&1 ) &
done
wait
echo "done $label"; cat $S/out/$label.*.jsonl | wc -l

// Spike 007: where a board's widest bottom miss sits after the round trip, and how far out the bottom is read in the nose.
//   ROOT=<checkout> CASES="longboard|Blended Nose Concave|3|4;..." npx tsx --tsconfig <checkout>/tsconfig.json where.mts
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const IN = 25.4;
for (const c of (process.env.CASES ?? "").split(";")) {
  const [bn, name, d, r] = c.split("|");
  const fields = phase16Boards().find((b: any) => b.label === `${bn}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: any = structuredClone(DEFAULT_BOTTOM);
  if (name !== "none") bottom.nose = { ...startingCut("nose", name, board), depth: inchesToMm(+d / 16), ...(+r > 0 ? { railRoll: inchesToMm(+r / 16) } : {}) };
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  const look = brdLookFromBytes(bytes, "x.brd").look;
  const L = fields.outline.length;
  const cl = look.bottom.closeness;
  console.log(`${c}: widest ${cl.largest.toFixed(2)} mm at ${((L - cl.station) / IN).toFixed(1)}" from the nose, ${(cl.across / IN).toFixed(1)}" out; order ${look.rails.order}`);
  for (const s of look.bottom.sections) if (s.gap.largest > 0.5 || s.station > L * 0.6) console.log(`   ${((L - s.station) / IN).toFixed(1).padStart(5)}" from nose  read ${(s.window / IN).toFixed(1)}" of ${(s.reach / IN).toFixed(1)}" (${Math.round((100 * s.window) / s.reach)}%)  gap ${s.gap.largest.toFixed(2)} at ${(s.gap.across / IN).toFixed(1)}"`);
}

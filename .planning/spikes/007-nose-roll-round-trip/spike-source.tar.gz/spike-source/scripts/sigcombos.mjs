// Spike 007: the signature as the trigger (idea 2) with the other ideas, replayed (every start with and without the drop).
import { load, score } from "./analyze.mjs";
import { replay, STARTS } from "./sim.mjs";
const rows = load("collect");
for (const [name, st, drop] of [["2 (signature, fresh start)", "fresh", false], ["2 (signature + seeded start)", "seed", false], ["2+3", "seed", true], ["2+4 (fitted concave + fresh + seed)", "ownfreshseed", false], ["2+3+4", "ownfreshseed", true], ["1+2+3+4 (belly or signature)", "ownfreshseed", true, "belly+sig"]]) {
  const s = score(replay(rows, { trig: "sig", starts: STARTS[st], drop, tie: 0.05 }));
  console.log(`${name.padEnd(40)} c+r ${s.concaveRoll}/${s.roll} ≤1/16 ${s.close16} ≤1/32 ${s.close32} clean ${s.clean} stray ${s.stray} widest ${s.widest.toFixed(2)}/${s.typical.toFixed(2)} invented ${s.invented}/${s.noroll} falseConc ${s.falseConc}/${s.belly}`);
}

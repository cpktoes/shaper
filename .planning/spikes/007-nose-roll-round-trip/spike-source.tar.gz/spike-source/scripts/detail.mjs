// Spike 007: one configuration replayed from the collect run, case by case against today.
//   node detail.mjs <trig> <starts> <drop 0|1> <tie|null> [collect label]
import { load, score } from "./analyze.mjs";
import { replay, STARTS } from "./sim.mjs";
const [trig, st, drop, tieS, label = "collect"] = process.argv.slice(2);
const rows = load(label);
const cfg = { trig, starts: STARTS[st], drop: drop === "1", tie: tieS === "null" ? null : Number(tieS) };
const today = replay(rows, { trig: "gate", starts: STARTS.fresh, drop: false, tie: null });
const trial = replay(rows, cfg);
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const w = (c) => c.map((k) => (k.depth > 0 ? `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")} ${(k.depth * 64).toFixed(0)}/64${k.roll > 0.005 ? " r" + (k.roll * 64).toFixed(0) + "/64" : ""}` : "Flat")).join(" · ");
const kept = {};
for (const r of trial) kept[r.kept] = (kept[r.kept] ?? 0) + 1;
console.log("kept:", JSON.stringify(kept));
let worse = [], better = 0, same = 0;
for (let i = 0; i < rows.length; i++) {
  const a = today[i], b = trial[i];
  const d = b.largest - a.largest;
  if (d > 0.005) worse.push({ id: a.id, a, b, d });
  else if (d < -0.005) better++; else same++;
}
console.log(`widest vs today: better ${better}, same ${same}, worse ${worse.length}`);
for (const x of worse.sort((p, q) => q.d - p.d)) console.log(`  WORSE ${x.id.padEnd(44)} ${x.a.largest.toFixed(2)}/${x.a.typical.toFixed(2)} ${w(x.a.back)}  ->  ${x.b.largest.toFixed(2)}/${x.b.typical.toFixed(2)} ${w(x.b.back)} (${x.b.kept})`);
console.log("-- roll-0 boards with a roll back (today | trial):");
for (let i = 0; i < rows.length; i++) if (rows[i].kind === "noroll" && (today[i].back[0].roll > 0.005 || trial[i].back[0].roll > 0.005)) console.log(`  ${rows[i].id.padEnd(44)} ${today[i].largest.toFixed(2)} ${w(today[i].back)} | ${trial[i].largest.toFixed(2)} ${w(trial[i].back)} (${trial[i].kept})`);
console.log("-- belly boards (no concave written), today | trial:");
for (let i = 0; i < rows.length; i++) if (rows[i].kind === "belly") console.log(`  ${rows[i].id.padEnd(30)} ${today[i].largest.toFixed(2)}/${today[i].typical.toFixed(2)} ${w(today[i].back).padEnd(44)} | ${trial[i].largest.toFixed(2)}/${trial[i].typical.toFixed(2)} ${w(trial[i].back)} (${trial[i].kept})`);
console.log("-- roll boards not back as concave+roll under the trial:");
for (let i = 0; i < rows.length; i++) { const b = trial[i]; if (rows[i].kind === "roll" && !(CONC.includes(b.back[0].name) && b.back[0].roll > 0.005)) console.log(`  ${rows[i].id.padEnd(44)} today ${today[i].largest.toFixed(2)} ${w(today[i].back)} | trial ${b.largest.toFixed(2)} ${w(b.back)} (${b.kept})`); }

// Spike 007: the twelve files' choice replayed from a collect run of measure.mts, for a few configurations.
import { readFileSync } from "node:fs";
import { pick, STARTS } from "./sim.mjs";
const rows = JSON.parse(readFileSync(new URL(`../out/${process.argv[2] ?? "twelve-collect"}.json`, import.meta.url), "utf8"));
const T = (trig, starts, drop, tie) => ({ trig, starts: STARTS[starts], drop, tie });
const cfgs = { today: T("gate", "fresh", false, null), "1": T("belly", "fresh", false, 0), "3": T("gate", "fresh", true, 0), "4": T("gate", "own", false, 0), "4both": T("gate", "both", false, 0), "1+3+4": T("belly", "own", true, 0.1), "1+3+4both": T("belly", "both", true, 0.1), "1+2+3+4": T("belly+sig", "ownseed", true, 0.1), "1+2+3+4 all": T("belly+sig", "ownfreshseed", true, 0.1), "1+3+4 tie.25": T("belly", "own", true, 0.25) };
const w = (c) => c.map((k) => (k.depth > 0 ? `${k.name.replace(/ (Nose )?Concave( Entry)?| \/ Rolled Mid| Entry| Center| Exit/g, "")} ${Math.round(k.depth * 64)}/64${k.roll > 0 ? " r" + Math.round(k.roll * 64) + "/64" : ""}` : "Flat")).join(" · ");
for (const r of rows) {
  console.log(`${r.file}  [gate ${r.log.overGate ? "over" : "under"}, belly ${r.log.bellyInNose ? "y" : "n"}, sig ${r.log.sig ? `dish ${r.log.sig.dish.toFixed(2)} turn ${r.log.sig.turn.toFixed(2)} onset ${r.log.sig.onset.toFixed(2)}` : "none"}]`);
  let last = "";
  for (const [name, cfg] of Object.entries(cfgs)) {
    const p = pick(r.log, cfg);
    const line = `${p.largest.toFixed(2)} / ${p.typical.toFixed(2)}  ${w(p.cuts)}  (${p.tag})`;
    console.log(`   ${name.padEnd(14)} ${line === last ? "same" : line}`);
    last = line;
  }
}

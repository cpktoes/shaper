// Spike 007: cheaper searches replayed from the collect run. Each variant names which polished candidates it would have run
// (so how many polishes it costs) and then applies the same choice rule as sim.mjs (tie margin, fewest cuts, 0.25 mm bar).
import { load, score } from "./analyze.mjs";
import { pick, replay, STARTS } from "./sim.mjs";
const rows = load(process.argv[2] ?? "collect");
const TIE = Number(process.argv[3] ?? 0.05);
const today = replay(rows, { trig: "gate", starts: STARTS.fresh, drop: false, tie: null });
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const sh = (c) => c.largest + c.typical;
// variant(log) -> the candidate tags it runs
const V = {
  "own+fresh+seed, each with and without the drop (6)": (l) => ["own", "fresh", "seed"].flatMap((t) => [t, t + "+drop"]),
  "own+fresh+seed, then the drop on the best start only (3+1)": (l) => {
    const base = l.cands.filter((c) => ["own", "fresh", "seed"].includes(c.tag));
    if (!base.length) return [];
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    return [...base.map((c) => c.tag), best.tag + "+drop"];
  },
  "own-or-fresh + seed, with and without the drop (4)": (l) => { const own = l.cands.some((c) => c.tag === "own"); return [own ? "own" : "fresh", "seed"].flatMap((t) => [t, t + "+drop"]); },
  "own-or-fresh + seed, then the drop on the best (2+1)": (l) => {
    const own = l.cands.some((c) => c.tag === "own");
    const base = l.cands.filter((c) => [own ? "own" : "fresh", "seed"].includes(c.tag));
    if (!base.length) return [];
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    return [...base.map((c) => c.tag), best.tag + "+drop"];
  },
  "own+fresh, then the drop on the best (2+1)": (l) => {
    const base = l.cands.filter((c) => ["own", "fresh"].includes(c.tag));
    if (!base.length) return [];
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    return [...base.map((c) => c.tag), best.tag + "+drop"];
  },
  "fresh+seed, then the drop on the best (2+1)": (l) => {
    const base = l.cands.filter((c) => ["fresh", "seed"].includes(c.tag));
    if (!base.length) return [];
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    return [...base.map((c) => c.tag), best.tag + "+drop"];
  },
};
for (const [name, f] of Object.entries(V)) {
  let polishes = 0, trig = 0;
  const out = rows.map((r) => {
    const l = r.log;
    const trigd = l.overGate || (process.env.TRIG !== "sig" && l.bellyInNose) || l.sig;
    if (!trigd) return { ...r, back: l.today.cuts, largest: l.today.largest, typical: l.today.typical };
    trig++;
    const tags = new Set(f(l));
    const have = l.cands.filter((c) => tags.has(c.tag));
    polishes += have.length;
    const p = pick({ ...l, cands: have }, { trig: "always", starts: () => ["own", "fresh", "seed", "slight", "teardrop"], drop: true, tie: TIE });
    return { ...r, back: p.cuts, largest: p.largest, typical: p.typical, kept: p.tag };
  });
  const s = score(out);
  let worse = 0; out.forEach((r, i) => { if (r.largest - today[i].largest > 0.005) worse++; });
  console.log(`${name.padEnd(62)} polishes/triggered ${(polishes / trig).toFixed(2)}  c+r ${s.concaveRoll}/${s.roll} ≤1/16 ${s.close16} clean ${s.clean} widest ${s.widest.toFixed(3)}/${s.typical.toFixed(3)} worse ${worse} invented ${s.invented} falseConc ${s.falseConc} mixedRoll ${s.mixedRoll}/${s.mixed}`);
}

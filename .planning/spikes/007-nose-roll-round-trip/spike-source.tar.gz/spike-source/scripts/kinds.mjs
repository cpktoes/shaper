// Spike 007: idea 4 with the other two names as fresh starts too (Teardrop and Slight Single Concave Entry from 1/16"), the
// signature trigger, then the drop on the best. How often the written name comes back, at what cost in polishes.
import { load, score } from "./analyze.mjs";
import { pick } from "./sim.mjs";
const rows = load("collect");
const sh = (c) => c.largest + c.typical;
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
for (const [label, set] of [["own+fresh+seed", ["own", "fresh", "seed"]], ["+ teardrop + slight", ["own", "fresh", "seed", "teardrop", "slight"]]]) {
  let pol = 0, trig = 0;
  const out = rows.map((r) => {
    const l = r.log;
    if (!(l.overGate || l.sig)) return { ...r, back: l.today.cuts, largest: l.today.largest, typical: l.today.typical };
    trig++;
    const base = l.cands.filter((c) => set.includes(c.tag));
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    // the drop exists in the collect run only for own/fresh/seed/teardrop/slight starts that were run with it
    const tags = new Set([...base.map((c) => c.tag), best.tag + "+drop"]);
    const cands = l.cands.filter((c) => tags.has(c.tag)); pol += cands.length;
    const p = pick({ ...l, cands }, { trig: "always", starts: () => set, drop: true, tie: 0.05 });
    return { ...r, back: p.cuts, largest: p.largest, typical: p.typical, kept: p.tag };
  });
  const s = score(out);
  const R = out.filter((r) => r.kind === "roll" && CONC.includes(r.back[0].name) && r.back[0].roll > 0.005);
  const byW = {}; for (const r of R) { const k = r.wrote.nose.name.split(" ")[0]; byW[k] = (byW[k] ?? 0) + (r.back[0].name === r.wrote.nose.name ? 1 : 0); }
  console.log(`${label.padEnd(22)} polishes/tried ${(pol / trig).toFixed(2)} c+r ${s.concaveRoll}/${s.roll} written name ${R.filter((r) => r.back[0].name === r.wrote.nose.name).length} ${JSON.stringify(byW)} widest ${s.widest.toFixed(3)}/${s.typical.toFixed(3)} falseConc ${s.falseConc} invented ${s.invented}`);
}

// Spike 007: the tie-margin sweep and the per-board tables, replayed from the collect run.
import { load, score } from "./analyze.mjs";
import { replay, STARTS, pick } from "./sim.mjs";
const rows = load(process.argv[2] ?? "collect");
const f2 = (v) => v.toFixed(2);
const T = (trig, starts, drop, tie, extra = {}) => ({ trig, starts: STARTS[starts], drop, tie, ...extra });
const show = (name, cfg, filter) => {
  const s = score(replay(rows, cfg), filter);
  console.log(`${name.padEnd(40)} c+r ${String(s.concaveRoll).padStart(3)}/${s.roll} ≤1/16 ${String(s.close16).padStart(3)} ≤1/32 ${String(s.close32).padStart(3)} clean ${String(s.clean).padStart(3)} stray ${String(s.stray).padStart(3)} rollErr ${s.rollErr.toFixed(3)} depthErr ${s.depthErr.toFixed(3)} widest ${f2(s.widest)}/${f2(s.typical)} worst ${f2(s.worst)} | invented ${s.invented}/${s.noroll} falseConc ${s.falseConc}/${s.belly} mixedRoll ${s.mixedRoll}/${s.mixed} lostBelly ${s.mixedLostBelly}${s.falseIds.length ? "  [" + s.falseIds.join(", ") + "]" : ""}`);
};
const mode = process.argv[3] ?? "main";
if (mode === "main") {
  show("today (gate, fresh)", T("gate", "fresh", false, null));
  console.log("-- one idea at a time (no tie margin) --");
  show("1 belly trigger", T("belly", "fresh", false, 0));
  show("2 signature trigger", T("sig", "fresh", false, 0));
  show("2 signature trigger + seeded start", T("sig", "seed", false, 0));
  show("2 seeded start only (gate)", T("gate", "seed", false, 0));
  show("3 drop the centre cut (gate)", T("gate", "fresh", true, 0));
  show("4 start from the fitted concave (gate)", T("gate", "own", false, 0));
  show("4 fitted concave and fresh (gate)", T("gate", "both", false, 0));
  show("4 all three names fresh (gate)", T("gate", "kinds", false, 0));
  console.log("-- pairs --");
  show("1+3", T("belly", "fresh", true, 0));
  show("1+4", T("belly", "own", false, 0));
  show("1+2", T("belly+sig", "seed", false, 0));
  show("3+4", T("gate", "own", true, 0));
  console.log("-- together, tie margin swept --");
  for (const [trig, st] of [["belly", "own"], ["belly", "both"], ["belly+sig", "own"], ["belly+sig", "ownseed"], ["belly+sig", "both"], ["belly+sig", "ownfreshseed"], ["belly", "kinds"]])
    for (const tie of [0, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.75]) show(`1+3+4 ${trig} ${st} tie ${tie}`, T(trig, st, true, tie));
}
if (mode === "boards") {
  const [trig, st, tie] = [process.argv[4], process.argv[5], Number(process.argv[6])];
  for (const b of ["shortboard", "midlength", "fish", "longboard"]) {
    show(`today ${b}`, T("gate", "fresh", false, null), (r) => r.board === b);
    show(`trial ${b}`, T(trig, st, true, tie), (r) => r.board === b);
  }
  for (const n of ["Teardrop", "Blended", "Slight"]) { show(`today ${n}`, T("gate", "fresh", false, null), (r) => r.id.includes(n)); show(`trial ${n}`, T(trig, st, true, tie), (r) => r.id.includes(n)); }
  for (const r of ["r1", "r2", "r3", "r4"]) { show(`today ${r}`, T("gate", "fresh", false, null), (x) => x.id.endsWith(r)); show(`trial ${r}`, T(trig, st, true, tie), (x) => x.id.endsWith(r)); }
  for (const d of ["d1", "d2", "d3", "d4"]) { show(`today ${d}`, T("gate", "fresh", false, null), (x) => x.id.includes("|" + d + "|")); show(`trial ${d}`, T(trig, st, true, tie), (x) => x.id.includes("|" + d + "|")); }
}
if (mode === "margins") {
  // For each belly board (no nose concave written): how much further off the closest nose-concave candidate is than today's answer.
  const [trig, st] = [process.argv[4], process.argv[5]];
  const cfg0 = T(trig, st, true, 0);
  const out = [];
  for (const r of rows) {
    const t = r.log.today; const shownT = t.largest + t.typical;
    const ownIs = /Concave/.test(t.cuts[0].name) && t.cuts[0].depth > 0;
    const starts = cfg0.starts(ownIs, r.log);
    const trigd = r.log.overGate || (trig.includes("belly") && r.log.bellyInNose) || (trig.includes("sig") && r.log.sig);
    const c = r.log.cands.filter((k) => starts.includes(k.tag.split("+")[0]));
    const best = c.length ? Math.min(...c.map((k) => k.largest + k.typical)) : NaN;
    out.push({ id: r.id, kind: r.kind, trig: !!trigd, delta: best - shownT, today: `${t.cuts.map((k) => k.name.split(" ").slice(0, 2).join(" ") + (k.depth ? " " + k.depth.toFixed(3) : "")).join(" · ")} ${f2(t.largest)}/${f2(t.typical)}` });
  }
  for (const k of ["belly", "noroll"]) { console.log("== " + k); for (const o of out.filter((o) => o.kind === k).sort((a, b) => a.delta - b.delta)) console.log(`${o.id.padEnd(44)} trig ${o.trig ? "y" : "n"} closest concave+roll is ${o.delta >= 0 ? "+" : ""}${f2(o.delta)} mm vs today  (${o.today})`); }
}

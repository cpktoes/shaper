// Spike 007: how often each trigger fires, by the kind of board written (from the collect run's log).
import { load } from "./analyze.mjs";
const rows = load(process.argv[2] ?? "collect");
const g = {};
for (const r of rows) {
  const k = r.kind === "belly" ? (/Concave/.test(r.wrote.nose.name) ? "belly + nose concave" : "belly, no nose concave") : r.kind === "roll" ? "nose concave + roll" : "nose concave, roll 0";
  const x = (g[k] ??= { boards: 0, overGate: 0, bellyInNose: 0, signature: 0, any: 0 });
  x.boards++; if (r.log.overGate) x.overGate++; if (r.log.bellyInNose) x.bellyInNose++; if (r.log.sig) x.signature++; if (r.log.sig || r.log.bellyInNose || r.log.overGate) x.any++;
}
console.table(g);

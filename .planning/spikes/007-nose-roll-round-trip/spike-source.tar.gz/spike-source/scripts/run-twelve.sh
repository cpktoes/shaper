#!/bin/bash
# Spike 007: the twelve files, today (main) and the trials, one after another in separate processes, fastest of 3 each.
# main is timed first and last to bracket the machine's load.
S=/private/tmp/claude-501/-Users-kontoes-Code-shaper/002e2a58-3c43-4c8e-bbb5-e9c435113dd2/scratchpad/spike007
M=/Users/kontoes/Code/shaper
cd $M
one() { label=$1; root=$2; shift 2; echo "== $label  $(uptime)"; env ROOT=$root "$@" npx --no-install tsx --tsconfig $root/tsconfig.json $S/scripts/measure.mts $label 3 > $S/out/$label.log 2>&1; tail -1 $S/out/$label.log; }
one t12-main-a $M
one t12-rec $S/wt S7_MODE=rec S7_TRIG=sig S7_TIE=0.05
one t12-rec-bellytrig $S/wt S7_MODE=rec S7_TRIG=belly+sig S7_TIE=0.05
one t12-main-b $M
env ROOT=$S/wt S7_MODE=rec S7_TRIG=sig S7_TIE=0.05 S7_FLATROLL=1 npx --no-install tsx --tsconfig $S/wt/tsconfig.json $S/scripts/measure.mts t12-flat 1 > $S/out/t12-flat.log 2>&1; echo "== flat done"
echo "== end $(uptime)"

// Spike 007: idea 4's second half replayed: among the closest candidates with the fewest cuts, keep the nose name the fit
// already found (the "own" start) when it is within NAME mm of the closest. Recommended search (3+1), signature trigger.
import { load, score } from "./analyze.mjs";
import { pick } from "./sim.mjs";
const rows = load("collect");
const sh = (c) => c.largest + c.typical;
const nC = (c) => c.filter((k) => k.depth > 0).length;
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
for (const NAME of [null, 0.05, 0.1, 0.25]) {
  const out = rows.map((r) => {
    const l = r.log;
    if (!(l.overGate || l.sig)) return { ...r, back: l.today.cuts, largest: l.today.largest, typical: l.today.typical };
    const base = l.cands.filter((c) => ["own", "fresh", "seed"].includes(c.tag));
    const best = base.reduce((a, b) => (sh(a) <= sh(b) ? a : b));
    const tags = new Set([...base.map((c) => c.tag), best.tag + "+drop"]);
    const cands = l.cands.filter((c) => tags.has(c.tag));
    let p = pick({ ...l, cands }, { trig: "always", starts: () => ["own", "fresh", "seed"], drop: true, tie: 0.05 });
    if (NAME !== null && p.tag !== "today" && !p.tag.startsWith("own")) {
      // the own-name candidate with the same cut count, if it also passes today's bars, within NAME of the pick
      const own = cands.filter((c) => c.tag.startsWith("own") && nC(c.cuts) === nC(p.cuts) && sh(c) <= sh(p) + NAME);
      if (own.length) { const o = own.reduce((a, b) => (sh(a) <= sh(b) ? a : b)); const q = pick({ ...l, cands: [o] }, { trig: "always", starts: () => ["own", "fresh", "seed"], drop: true, tie: 0.05 }); if (q.tag !== "today") p = q; }
    }
    return { ...r, back: p.cuts, largest: p.largest, typical: p.typical, kept: p.tag };
  });
  const s = score(out);
  const R = out.filter((r) => r.kind === "roll" && CONC.includes(r.back[0].name) && r.back[0].roll > 0.005);
  const same = R.filter((r) => r.back[0].name === r.wrote.nose.name).length;
  const byW = {}; for (const r of R) { const k = r.wrote.nose.name.split(" ")[0]; byW[k] = (byW[k] ?? 0) + (r.back[0].name === r.wrote.nose.name ? 1 : 0); }
  console.log(`name margin ${NAME}: c+r ${s.concaveRoll}/${s.roll}, of which the written name ${same} (${JSON.stringify(byW)}); widest ${s.widest.toFixed(3)}/${s.typical.toFixed(3)} ≤1/16 ${s.close16} clean ${s.clean} falseConc ${s.falseConc} invented ${s.invented}`);
}

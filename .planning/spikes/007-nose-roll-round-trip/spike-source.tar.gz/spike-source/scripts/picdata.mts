// Spike 007: data for the picture. A few of the app's own boards written to .brd with a nose concave and a Rail Roll, then
// opened by today's import (MAIN) and by the recommended trial (the worktree with S7_MODE=rec): the nose sections of each.
//   ROOT=<checkout> [S7_MODE=rec S7_TRIG=belly+sig S7_TIE=0.05] OUT=<json> npx tsx --tsconfig <checkout>/tsconfig.json picdata.mts
// Run once on main (today) and once on the worktree (the trial); picture.cjs puts the two side by side. One checkout per
// process, because lib code imports "@/lib/..." through the tsconfig it was started with.
import { writeFileSync } from "node:fs";
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const IN = 25.4;
const CASES: [string, string, number, number][] = (process.env.CASES ?? "midlength|Blended Nose Concave|2|2;midlength|Blended Nose Concave|4|4;midlength|Slight Single Concave Entry|3|4;fish|Teardrop Nose Concave|3|2")
  .split(";").map((s) => { const [b, n, d, r] = s.split("|"); return [b, n, Number(d), Number(r)]; });
const out: any[] = [];
for (const [boardName, name, d, r] of CASES) {
  const fields = phase16Boards().find((b: any) => b.label === `${boardName}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const bottom: any = structuredClone(DEFAULT_BOTTOM);
  bottom.nose = { ...startingCut("nose", name, board), depth: inchesToMm(d / 16), railRoll: inchesToMm(r / 16) };
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  const a = brdLookFromBytes(bytes, "x.brd");
  const cut = (k: any) => ({ name: k.name, depth: k.depth / IN, roll: (k.railRoll ?? 0) / IN, offRail: (k.offRail ?? 0) / IN });
  const L = fields.outline.length;
  out.push({
    key: `${boardName}|${name}|${d}|${r}`, length: L / IN, wrote: cut(bottom.nose),
    cuts: [a.look.bottom.bottom.nose, a.look.bottom.bottom.center, a.look.bottom.bottom.tail].map(cut),
    whole: [a.look.bottom.closeness.largest, a.look.bottom.closeness.typical],
    sections: a.look.bottom.sections.filter((s: any) => s.station > L * 0.55).map((s: any) => ({ station: s.station / IN, across: s.across.map((v: number) => v / IN), file: s.file, ours: s.ours, gap: s.gap.largest })),
  });
  console.log(out.at(-1).key, out.at(-1).whole.map((v: number) => v.toFixed(2)).join("/"), out.at(-1).cuts.map((k: any) => k.name + " " + k.depth.toFixed(3) + " r" + k.roll.toFixed(3)).join(" · "));
}
writeFileSync(process.env.OUT!, JSON.stringify(out));

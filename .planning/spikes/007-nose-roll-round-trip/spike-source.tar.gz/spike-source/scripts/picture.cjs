// Spike 007: nose-sections.png. node picture.cjs <today.json> <trial.json> <out.png>
// For each test board, the nose section (at least 6" back from the tip) where today's import is furthest off: the written board (black), today's import
// (blue, dashed) and the recommended trial (orange), out from the stringer to the edge of the reading width.
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [todayFile, trialFile, outFile] = process.argv.slice(2);
const A = JSON.parse(fs.readFileSync(todayFile)), B = JSON.parse(fs.readFileSync(trialFile));
const INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", TODAY = "#2a78d6", TRIAL = "#eb6834";
const frac = (inch) => { const n = Math.round(inch * 64); if (!n) return "0"; let a = n, b = 64; while (a % 2 === 0 && b > 1) { a /= 2; b /= 2; } return `${a}/${b}"`; };
const words = (cuts) => cuts.filter((k) => k.depth > 0).map((k) => `${k.name} ${frac(k.depth)}${k.roll > 0.004 ? `, Rail Roll ${frac(k.roll)}` : ""}`).join(" + ") || "flat";
const BOARD = { shortboard: "Shortboard", midlength: "Mid-length", fish: "Fish", longboard: "Longboard" };
function panel(a, b, W) {
  const s = a.sections.filter((q) => a.length - q.station >= 6).reduce((p, q) => (q.gap > p.gap ? q : p));
  const t = b.sections.find((q) => Math.abs(q.station - s.station) < 0.01);
  const H = 330, L = 50, R = 16, T = 92, Bm = 40;
  const all = [...s.file, ...s.ours, ...t.ours];
  let lo = Math.min(0, ...all), hi = Math.max(0, ...all); const pad = (hi - lo) * 0.1 + 0.2; lo -= pad; hi += pad;
  const xMax = s.across[s.across.length - 1];
  const x = (v) => L + (v / xMax) * (W - L - R), y = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - Bm);
  const path = (vals) => vals.map((v, j) => `${j ? "L" : "M"}${x(s.across[j]).toFixed(1)},${y(v).toFixed(1)}`).join("");
  const span = hi - lo, step = span > 8 ? 2 : span > 4 ? 1 : 0.5;
  let g = "";
  for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="${Math.abs(v) < 1e-9 ? "#b9b8b2" : GRID}"/><text x="${L - 6}" y="${y(v) + 4}" text-anchor="end" class="t">${+v.toFixed(1)}</text>`;
  for (let i = 0; i <= xMax + 1e-6; i += xMax > 8 ? 2 : 1) g += `<text x="${x(i)}" y="${H - Bm + 16}" text-anchor="middle" class="t">${i}"</text>`;
  const [board, name, d, r] = a.key.split("|");
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <text x="${L}" y="16" class="h">${BOARD[board]}: ${name} ${frac(d / 16)} with a ${frac(r / 16)} Rail Roll</text>
  <text x="${L}" y="34" class="t">${(a.length - s.station).toFixed(1)}" back from the nose tip</text>
  <text x="${L}" y="54" class="t" fill="${TODAY}"><tspan fill="${TODAY}">Today: ${words(a.cuts)}, ${a.whole[0].toFixed(2)} mm widest</tspan></text>
  <text x="${L}" y="72" class="t"><tspan fill="${TRIAL}">Trial: ${words(b.cuts)}, ${b.whole[0].toFixed(2)} mm widest</tspan></text>
  ${g}
  <path d="${path(s.ours)}" fill="none" stroke="${TODAY}" stroke-width="2.2" stroke-dasharray="6 4"/>
  <path d="${path(t.ours)}" fill="none" stroke="${TRIAL}" stroke-width="2.2"/>
  <path d="${path(s.file)}" fill="none" stroke="${INK}" stroke-width="1.6"/>
  <text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="t">out from the stringer, to the edge of what is read (mm up from the stringer's height)</text></svg>`;
}
const W = 600;
const panels = A.map((a, i) => panel(a, B.find((b) => b.key === a.key), W));
const html = `<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#fcfcfb;font-family:-apple-system,Helvetica,Arial,sans-serif;color:${INK}}
.wrap{width:${2 * W + 40}px;padding:20px 20px 16px} h1{font-size:19px;margin:0 0 4px;font-weight:600} p{margin:0 0 6px;font-size:13px;color:${SUB};line-height:1.45}
.t{font-size:11.5px;fill:${SUB}} .h{font-size:13.5px;font-weight:600;fill:${INK}} .grid{display:grid;grid-template-columns:${W}px ${W}px;gap:10px 20px;margin-top:8px}
.key{display:flex;gap:22px;font-size:13px;margin-top:8px} .key svg{vertical-align:middle;margin-right:6px}</style><div class="wrap">
<h1>A nose concave with a Rail Roll, written by the app and opened again</h1>
<p>Each panel is one cross-section near the nose: half the bottom, from the stringer out to where the import stops reading. Heights are millimetres above the stringer's own height, so the rocker is not in it.</p>
<div class="key"><span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${INK}" stroke-width="2"/></svg>The board as written</span>
<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/></svg>Today's import</span>
<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TRIAL}" stroke-width="2"/></svg>Recommended trial</span></div>
<div class="grid">${panels.join("")}</div></div>`;
(async () => { const br = await chromium.launch(); const pg = await br.newPage({ viewport: { width: 2 * W + 40, height: 400 }, deviceScaleFactor: 2 }); await pg.setContent(html); await pg.screenshot({ path: outFile, fullPage: true }); await br.close(); console.log("wrote", outFile); })();

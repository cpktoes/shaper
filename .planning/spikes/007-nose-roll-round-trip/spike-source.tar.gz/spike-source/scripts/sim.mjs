// Spike 007: replays the choice offline from a collect run (every candidate polished and logged), for any trigger, set of
// starts, drop on/off and tie margin. The figures are each candidate's own (measured before the board is refitted to the
// stringer), so a confirm run through the real import follows for the configurations that matter.
import { load, score } from "./analyze.mjs";
const KIND = { "Rolled Belly Entry": "belly", "Continuous Belly / Rolled Mid": "belly", "Tri-Plane Hull Center": "belly", "Reverse Vee Nose": "vee", "Flat Entry": "flat", "Flat Center": "flat", "Flat Exit": "flat" };
const CONC = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const kind = (n) => KIND[n] ?? (CONC.includes(n) ? "single" : "other");
const NOISE = 1e-9, BAR = 0.25;
export function pick(log, cfg) {
  const t = log.today;
  const todayOut = { tag: "today", cuts: t.cuts, largest: t.largest, typical: t.typical };
  const trig = log.overGate || cfg.trig === "always" || (cfg.trig.includes("belly") && log.bellyInNose) || (cfg.trig.includes("sig") && log.sig);
  if (!trig) return todayOut;
  const ownIs = CONC.includes(t.cuts[0].name) && t.cuts[0].depth > 0;
  const starts = cfg.starts(ownIs, log);
  const nCuts = (c) => c.filter((k) => k.depth > 0).length;
  const shownT = t.largest + t.typical, cutsT = nCuts(t.cuts);
  const nk = kind(t.cuts[0].name), ck = kind(t.cuts[1].name);
  const ok = [];
  for (const c of log.cands) {
    const [base, drop] = c.tag.split("+");
    if (!starts.includes(base) || (drop && !cfg.drop)) continue;
    const n = nCuts(c.cuts);
    const replaces = (nk === "belly" && kind(c.cuts[0].name) === "single") || ((ck === "belly" || ck === "vee") && c.cuts[1].depth === 0);
    // The lowest bar that applies: the founder's tie rule (a nose concave with a roll replaces a belly, with no more cuts),
    // the fewest-cuts rule (fewer cuts may be 0.25 mm further off), the polish's own (same names: any gain), else an extra
    // cut or a renamed nose must earn 0.25 mm.
    let bar = BAR;
    if (c.cuts[0].name === t.cuts[0].name && n === cutsT) bar = Math.min(bar, NOISE);
    if (n < cutsT) bar = Math.min(bar, -(cfg.fewerBar ?? BAR));
    if (cfg.tie !== null && replaces && n <= cutsT) bar = Math.min(bar, -cfg.tie);
    const shown = c.largest + c.typical;
    if (shown < shownT - bar) ok.push({ ...c, shown, n });
  }
  if (!ok.length) return todayOut;
  const closest = Math.min(...ok.map((c) => c.shown));
  const near = ok.filter((c) => c.shown <= closest + BAR);
  const fewest = Math.min(...near.map((c) => c.n));
  return near.filter((c) => c.n === fewest).sort((a, b) => a.shown - b.shown)[0];
}
export function replay(rows, cfg) {
  return rows.map((r) => {
    const p = pick(r.log, cfg);
    return { ...r, back: p.cuts, largest: p.largest, typical: p.typical, kept: p.tag };
  });
}
export const STARTS = {
  fresh: () => ["fresh"],
  own: (ownIs) => (ownIs ? ["own"] : ["fresh"]),
  both: () => ["own", "fresh"],
  seed: (ownIs, log) => (log.sig ? ["seed"] : ["fresh"]),
  ownseed: (ownIs, log) => (ownIs ? ["own"] : log.sig ? ["seed"] : ["fresh"]),
  ownfreshseed: () => ["own", "fresh", "seed"],
  kinds: (ownIs) => (ownIs ? ["own"] : ["fresh", "slight", "teardrop"]),
  all: () => ["own", "fresh", "seed", "slight", "teardrop"],
};

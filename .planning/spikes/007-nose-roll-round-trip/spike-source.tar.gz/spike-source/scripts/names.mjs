// Spike 007: which nose name comes back, by the name written (roll boards only). node names.mjs <label>...
import { load } from "./analyze.mjs";
for (const label of process.argv.slice(2)) {
  const rows = load(label).filter((r) => r.kind === "roll");
  const t = {};
  for (const r of rows) { const w = r.wrote.nose.name, b = r.back[0].name + (r.back[0].roll > 0.005 ? " + roll" : ""); (t[w] ??= {})[b] = (t[w][b] ?? 0) + 1; }
  console.log("== " + label); for (const [w, m] of Object.entries(t)) console.log(`  ${w}: ${Object.entries(m).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(", ")}`);
}

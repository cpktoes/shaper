// Spike 007: the tie margin and the fewest-cuts bar swept together for one trigger + starts, with a "worse than today" count.
//   node sweep2.mjs <trig> <starts> [collect label]
import { load, score } from "./analyze.mjs";
import { replay, STARTS } from "./sim.mjs";
const [trig, st, label = "collect"] = process.argv.slice(2);
const rows = load(label);
const today = replay(rows, { trig: "gate", starts: STARTS.fresh, drop: false, tie: null });
const run = (tie, fewerBar, drop = true) => {
  const tr = replay(rows, { trig, starts: STARTS[st], drop, tie, fewerBar });
  const s = score(tr);
  let worse = 0, worst = 0, sumW = 0;
  tr.forEach((r, i) => { const d = r.largest - today[i].largest; if (d > 0.005) { worse++; worst = Math.max(worst, d); } });
  console.log(`tie ${String(tie).padEnd(5)} fewerBar ${String(fewerBar).padEnd(5)} drop ${drop ? 1 : 0}  c+r ${s.concaveRoll}/${s.roll} ≤1/16 ${s.close16} ≤1/32 ${s.close32} clean ${s.clean} stray ${s.stray} widest ${s.widest.toFixed(3)}/${s.typical.toFixed(3)} worse ${worse} (max +${worst.toFixed(2)}) invented ${s.invented}/${s.noroll} falseConc ${s.falseConc}/${s.belly}${s.falseIds.length ? " [" + s.falseIds.join(", ") + "]" : ""}`);
};
for (const fb of [0.25, 0.15, 0.1, 0.05, 0]) for (const tie of [0, 0.05, 0.1, 0.15]) run(tie, fb);

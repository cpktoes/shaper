# Spike 007 trial patch 3 (after patch2.py): S7_NOSESCORE=1 makes the recommended search judge its candidates on the nose
# half's sections only (widest + typical there), while never letting the whole board's widest miss grow (a sixth idea,
# followed up because the Longboard's widest miss sits in its tail, where no nose choice can move it).
import sys
p = sys.argv[1]; s = open(p).read()
def rep(a, b):
    global s
    assert s.count(a) == 1, a
    s = s.replace(a, b)
rep('''    const tie = TIE ?? 0.05;
''', '''    const tie = TIE ?? 0.05;
    const NS = env("S7_NOSESCORE") === "1";
    const noseSecs = sections.filter((q) => q.station > L / 2);
    const judge = (b: BoardBottom): number => { const c = NS ? measureBrdBottom(b, noseSecs, board0).closeness : close(b); return c.largest + c.typical; };
    const judgedToday = judge(today);
''')
rep('''      return { tag, b, nose, shown: c.largest + c.typical, cuts: cutsOf(b) };''', '''      return { tag, b, nose, shown: judge(b), whole: c.largest, cuts: cutsOf(b) };''')
rep('''      return c.shown < shownToday - bar;''', '''      return c.shown < judgedToday - bar && (!NS || c.whole <= todayClose.largest + 0.005);''')
open(p, "w").write(s); print("patched")

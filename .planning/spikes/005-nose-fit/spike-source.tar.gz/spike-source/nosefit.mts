// Off line (not through the import): what each nose section could reach on its OWN, every number free, under four across-models,
// read today's way (ours = the cuts alone) and the rail-aware way (the file less our fitted rail's own rise).
//  A  one concave, today's curve (Depth, Off Rail, Smoothness)
//  B  one concave, a power curve 1 - u^p (Depth, Off Rail, p)
//  C  A plus a roll outside it: a belly/vee lift from a panel edge out to the rail (Depth, Off Stringer, Smoothness)
//  D  B plus that roll
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdRailBoard, brdOurRailHalf } = await import(`${ROOT}/lib/geometry/brd-rails.ts`);
const IN = 25.4;
const sec = (u: number, r: number) => (1 - r) * (1 - u) + r * (1 + Math.cos(Math.PI * u)) / 2;
const rise = (u: number, r: number) => (1 - r) * u + r * (1 - Math.cos(Math.PI * u / 2));
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const at = (r: number[][], x: number) => { for (let k = 0; k + 1 < r.length; k++) if (x >= r[k][0] && x <= r[k + 1][0]) return r[k][1] + (r[k + 1][1] - r[k][1]) * (x - r[k][0]) / (r[k + 1][0] - r[k][0] || 1); return x <= r[0][0] ? r[0][1] : r[r.length - 1][1]; };
const pick: Record<string, number> = { "92Log": 90, "Scoop-Noserider": 70, "testLB": 80 };
for (const name of Object.keys(pick)) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  console.log(`\n=== ${name}`);
  for (const s of look.bottom.sections) {
    if (s.station / IN < pick[name]) continue;
    const rs = look.rails.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    const o = run(rs.ours); let on = false;
    const rr: number[] = s.across.map((y: number, j: number) => { const d = at(o, y) - s.ours[j]; if (!on && Math.abs(d) > 0.05) on = true; return on ? d : 0; });
    const W = s.reach, ys: number[] = s.across, n = ys.length;
    const fit = (target: number[], power: boolean, roll: boolean) => {
      let best = { v: 1e9, mx: 0, typ: 0, txt: "" };
      const ks = power ? [1, 1.3, 1.6, 2, 2.5, 3, 4] : [0, 0.25, 0.5, 0.7, 1];
      const conc = new Float64Array(n);
      for (const k of ks) for (let Cs = 0.4; Cs <= 1.0001; Cs += 0.02) { const C = Cs * W;
        for (let j = 0; j < n; j++) conc[j] = ys[j] < C ? (power ? 1 - Math.pow(ys[j] / C, k) : sec(ys[j] / C, k)) - 1 : -1;
        const lifts: { D: number; F: number; r2: number; l: Float64Array }[] = [{ D: 0, F: 0, r2: 0, l: new Float64Array(n) }];
        if (roll) for (const r2 of [0, 0.6, 1]) for (let Fs = 0.3; Fs <= 0.95; Fs += 0.05) { const F = Fs * W; const l = new Float64Array(n); for (let j = 0; j < n; j++) l[j] = ys[j] > F ? rise((ys[j] - F) / (W - F), r2) : 0; lifts.push({ D: 1, F, r2, l }); }
        for (const lf of lifts) for (let d = 0; d <= 12.71; d += 0.2) for (let D = lf.D ? 0.4 : 0; D <= (lf.D ? 12.71 : 0); D += 0.4) {
          let mx = 0, sum = 0;
          for (let j = 0; j < n; j++) { const e = Math.abs(target[j] - (d * conc[j] + D * lf.l[j])); sum += e; if (e > mx) mx = e; }
          if (mx + sum / n < best.v) best = { v: mx + sum / n, mx, typ: sum / n, txt: `depth ${(d / IN).toFixed(2)}" edge ${((W - C) / IN).toFixed(1)}" in ${power ? "p" : "sm"} ${power ? k : k * 100}${lf.D ? `; roll ${(D / IN).toFixed(2)}" from ${(lf.F / IN).toFixed(1)}" out sm ${lf.r2 * 100}` : ""}` };
        } }
      return best; };
    const plain: number[] = s.file, aware = s.file.map((v: number, j: number) => v - rr[j]);
    const f = (b: any) => `${b.mx.toFixed(2)}/${b.typ.toFixed(2)}`;
    const A = fit(plain, false, false), B = fit(plain, true, false), C = fit(plain, false, true), D = fit(plain, true, true);
    const A2 = fit(aware, false, false), B2 = fit(aware, true, false), C2 = fit(aware, false, true), D2 = fit(aware, true, true);
    console.log(` st ${(s.station / IN).toFixed(1)}" in the import ${s.gap.largest.toFixed(2)} | read today's way: A ${f(A)}  B ${f(B)}  C ${f(C)}  D ${f(D)} | rail-aware: A ${f(A2)}  B ${f(B2)}  C ${f(C2)}  D ${f(D2)}`);
    console.log(`      A: ${A.txt}\n      B: ${B.txt}\n      C: ${C.txt}\n      aware A: ${A2.txt}\n      aware B: ${B2.txt}\n      aware C: ${C2.txt}`);
  }
}

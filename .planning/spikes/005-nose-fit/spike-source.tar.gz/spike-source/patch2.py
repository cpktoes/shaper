# Spike 005 trial code, part 2: the rail-aware reading (SPIKE_READ=rail | railmeasure | window). python3 -I patch2.py <worktree>
import sys, pathlib
wt = pathlib.Path(sys.argv[1])
p = wt / "lib/export/brd-fit-preview.ts"; s = p.read_text()
old = s[s.index("export function brdFitLook(board: ReadBrdBoard): BrdFitLook {"):s.index("/** The top and side views laid out for a box this wide")]
new = r'''export function brdFitLook(board: ReadBrdBoard): BrdFitLook {
  const { look, first, lines } = settleLook(board);
  if (!look.bottom) return look;
  const fins = look.fins?.spec;
  const board0 = brdFittedBottomBoard(first, fins);
  // SPIKE 005: how the bottom is read near the rail. "" is today's.
  const READ = process.env.SPIKE_READ ?? "";
  const rise0 = READ && look.rails ? spikeRailRise(look.bottom, brdRailBoard(look.fit, look.bottom.bottom, fins), look.rails.rails) : null;
  const anyRise = rise0 !== null && rise0.some((r) => r.some((v) => v !== 0));
  let sections = look.bottom.sections;
  let polished: BoardBottom;
  if ((READ === "rail" || READ === "railnames") && rise0 && anyRise) {
    // The polish scores the file less our rail's own rise: what the cuts alone must draw for the finished section to match.
    const adjusted = sections.map((sec, i): BrdBottomSection => {
      const file = sec.file.map((v, j) => mm(v - rise0[i][j]));
      return { ...sec, file, flat: file.every((v) => Math.abs(v) <= 1) };
    });
    const today = polishBrdBottom(look.bottom.bottom, sections, board0);
    const aware = polishBrdBottom(look.bottom.bottom, adjusted, board0);
    const shown = (b: BoardBottom): number => {
      const c = spikeWithRise(measureBrdBottom(b, sections, board0), rise0).closeness;
      return c.largest + c.typical;
    };
    polished = shown(aware) < shown(today) - 1e-9 ? aware : today;
  } else if (READ === "window" && rise0 && anyRise) {
    // The reading width stops where the settled rail begins, when that is more than 1/4" inside today's width.
    const windows: (Mm | undefined)[] = board.sections.map(() => undefined);
    sections.forEach((sec, i) => {
      const j = rise0[i].findIndex((v) => v !== 0);
      if (j < 1) return;
      const at = sec.across[j - 1];
      const index = board.sections.findIndex((q) => q.station === sec.station);
      windows[index] = at < sec.window - 6.35 ? at : sec.window < 0.9 * sec.reach - 1e-6 ? sec.window : undefined;
    });
    sections.forEach((sec) => {
      const index = board.sections.findIndex((q) => q.station === sec.station);
      if (windows[index] === undefined && sec.window < 0.9 * sec.reach - 1e-6) windows[index] = sec.window;
    });
    sections = brdBottomSections(board.sections, board0.length, windows);
    polished = polishBrdBottom(look.bottom.bottom, sections, board0);
  } else polished = polishBrdBottom(look.bottom.bottom, sections, board0);
  const step = liftedStep(board, lines, first, fins, board0, polished, sections);
  if (!look.rails) return { ...look, ...step };
  const { lines: railLines } = brdRailLines(board);
  const onBoard = brdRailBoard(step.fit, step.bottom.bottom, fins);
  const winner = look.rails;
  const settings = fitBrdRails(railLines, onBoard, winner.settings);
  const rails = measureBrdRails(railLines, onBoard, settings, { order: winner.order, read: winner.read, narrowed: winner.narrowed, blend: winner.blend });
  if (READ === "rail" || READ === "railmeasure" || READ === "railnames") {
    // What is shown: the file against our finished section (the cuts with the final rail standing on them).
    return { ...look, ...step, bottom: spikeWithRise(step.bottom, spikeRailRise(step.bottom, onBoard, rails.rails)), rails };
  }
  return { ...look, ...step, rails };
}

/** SPIKE 005: how far our finished rail stands above the bottom's cuts at each read point (0 inside where the rail begins). */
export function spikeRailRise(found: BrdBottomFit, railBoard: BrdRailBoard, rails: RailBandSpec): number[][] {
  return found.sections.map((sec) => {
    const half = brdOurRailHalf(railBoard, rails, sec.station);
    if (half.length === 0) return sec.across.map(() => 0);
    let apex = 0;
    for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k;
    const run: P2[] = [];
    for (let k = 0; k <= apex; k++) if (run.length === 0 || half[k][0] > run[run.length - 1][0]) run.push(half[k]);
    const at = (x: number): number => {
      for (let k = 0; k + 1 < run.length; k++) if (x >= run[k][0] && x <= run[k + 1][0]) return run[k][1] + ((run[k + 1][1] - run[k][1]) * (x - run[k][0])) / (run[k + 1][0] - run[k][0] || 1);
      return x <= run[0][0] ? run[0][1] : run[run.length - 1][1];
    };
    let on = false;
    return sec.across.map((y, j) => {
      const d = at(y) - sec.ours[j];
      if (!on && Math.abs(d) > 0.05) on = true;
      return on ? d : 0;
    });
  });
}

/** SPIKE 005: a measured bottom with our rail's rise added to ours, the gaps and the closeness worked out again. */
export function spikeWithRise(found: BrdBottomFit, rise: readonly (readonly number[])[]): BrdBottomFit {
  let largest = 0;
  let sum = 0;
  let count = 0;
  let where = { station: mm(0), across: mm(0) };
  const sections = found.sections.map((sec, i): BrdBottomSection => {
    const ours = sec.ours.map((v, j) => mm(v + rise[i][j]));
    let widest = 0;
    let widestAt = 0;
    ours.forEach((v, j) => {
      const gap = Math.abs(sec.file[j] - v);
      sum += gap;
      count++;
      if (gap > widest) {
        widest = gap;
        widestAt = sec.across[j];
      }
    });
    if (widest > largest) {
      largest = widest;
      where = { station: sec.station, across: mm(widestAt) };
    }
    return { ...sec, ours, gap: { largest: mm(widest), across: mm(widestAt) } };
  });
  return { ...found, sections, closeness: { largest: mm(largest), typical: mm(count > 0 ? sum / count : 0), station: where.station, across: where.across } };
}

'''
s = s.replace(old, new)
p.write_text(s)

# Puts the README together from its three parts. python3 -I assemble.py <scratch folder> <out file>
import pathlib, sys
S = pathlib.Path(sys.argv[1])
d = (S / "README-draft.md").read_text()
def sub(old, new):
    global d
    assert d.count(old) == 1, old[:60]
    d = d.replace(old, new)
sub("**8. The app's own round trips.** FILLME",
    "**8. The app's own round trips.** `bottom.test.ts`, `brd-bottom.test.ts`, `brd-fit-preview.test.ts` and `brd-look.test.ts`\n"
    "(1,385 cases, among them the boards the app writes and reads back) pass in the worktree with the Edge Roll trial\n"
    "switched on (`results/vitest-roll.txt`).")
sub("- *Smoothness freed* (an existing slider), on the nose cut or on every cut: Scoop 1.18 to 1.14, 92Log and testLB unmoved.",
    "- *Smoothness freed* (an existing slider) on the nose cut: Scoop 1.18 to 1.14; 92Log 1.57 (a second polish pass alone\n"
    "  does that) and testLB unmoved.")
sub("(36 starts a file)", "(24 to 28 starts a file)")
sub("files within 0.6 mm; a concave alone, of any shape, leaves 0.55 to 2.08 mm.",
    "files within 0.62 mm (most within 0.3); on the sections that hold each file's widest miss a concave alone, of any\nshape, leaves 0.55 to 2.08 mm.")
pathlib.Path(sys.argv[2]).write_text(d + (S / "README-part2.md").read_text() + (S / "README-part3.md").read_text())

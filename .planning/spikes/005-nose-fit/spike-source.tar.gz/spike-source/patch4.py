# Spike 005 trial code, part 4: the Edge Roll scored the fast way, and offered in the grid search too (SPIKE_ROLL=grid).
# python3 -I patch4.py <worktree>
import sys, pathlib
wt = pathlib.Path(sys.argv[1])
def sub(path, old, new):
    p = wt / path; s = p.read_text()
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    p.write_text(s.replace(old, new))
F = "lib/geometry/brd-bottom.ts"
sub(F, "  edgeRollShare,\n", "") if False else None
sub(F, "  cutKind,\n  fadeAt,", "  cutKind,\n  edgeRollShare,\n  smoothstep,\n  fadeAt,")
# state and buffers
sub(F, "  /** What `base` depends on: when this is unchanged, `base` is too. */\n  marks: string;\n}",
       "  /** What `base` depends on: when this is unchanged, `base` is too. */\n  marks: string;\n  /** SPIKE 005: a fast cut's Edge Roll at each point at the whole roll (null without one), and the roll x its share along the board at each section. */\n  roll: Float64Array | null;\n  rollMult: Float64Array | null;\n}")
sub(F, "interface Buffers {\n  base: Float64Array;\n  mult: Float64Array;\n}", "interface Buffers {\n  base: Float64Array;\n  mult: Float64Array;\n  roll: Float64Array;\n  rollMult: Float64Array;\n}")
sub(F, "  const newBuffers = (): Buffers => ({ base: new Float64Array(2 * P), mult: new Float64Array(NS) });",
       "  const newBuffers = (): Buffers => ({ base: new Float64Array(2 * P), mult: new Float64Array(NS), roll: new Float64Array(P), rollMult: new Float64Array(NS) });")
# the unit base never holds the roll
sub(F, "      ? { ...cut, start: mm(L), deepest: mm(0), end: mm(0), depth: mm(1), veeLift: mm(cut.depth > 0 ? cut.veeLift / cut.depth : 0) }",
       "      ? { ...cut, start: mm(L), deepest: mm(0), end: mm(0), depth: mm(1), veeLift: mm(cut.depth > 0 ? cut.veeLift / cut.depth : 0), edgeRoll: undefined }")
sub(F, "|${s.closesToPoint}|${s.acrossShape}|${s.edgeRoll}`;", "|${s.closesToPoint}|${s.acrossShape}${s.closesToPoint ? `|${s.edgeRoll}` : \"\"}`;")
sub(F, "    if (flat) return { spec, flat, slow: false, base: ZERO_BASE, mult: ZERO_MULT, marks: \"\" };\n    const slow = spec.closesToPoint || (spec.edgeRoll ?? 0) > 0;",
       "    if (flat) return { spec, flat, slow: false, base: ZERO_BASE, mult: ZERO_MULT, marks: \"\", roll: null, rollMult: null };\n    const slow = spec.closesToPoint;")
sub(F, """      for (let i = 0; i < NS; i++) mult[i] = c.depth * fadeAt(c.start, c.deepest, c.end, st[i], L);
    }
    return { spec, flat, slow, base, mult, marks };""",
"""      for (let i = 0; i < NS; i++) mult[i] = c.depth * fadeAt(c.start, c.deepest, c.end, st[i], L);
      // SPIKE 005: the Edge Roll beside a fast concave: its across part once per Off Rail, its share along the board per trial.
      const amount = spec.edgeRoll ?? 0;
      if (amount > 0 && cutKind(spec.name) === "single") {
        let roll = into.roll;
        if (prev && prev.roll && !prev.flat && !prev.slow && prev.marks === marks) roll = prev.roll;
        else {
          const whole = { ...c, deepest: mm(0), end: mm(0) };
          for (let i = 0; i < NS; i++) for (let j = 0; j < J; j++) roll[i * J + j] = edgeRollShare(whole, board, "narrowest", mm(st[i]), mm(ys[i * J + j]));
        }
        const rollMult = into.rollMult;
        for (let i = 0; i < NS; i++) {
          const s = st[i];
          rollMult[i] = s < c.end ? 0 : amount * (s >= c.deepest || c.deepest - c.end < 1e-6 ? 1 : smoothstep((s - c.end) / (c.deepest - c.end)));
        }
        return { spec, flat, slow, base, mult, marks, roll, rollMult };
      }
    }
    return { spec, flat, slow, base, mult, marks, roll: null, rollMult: null };""")
sub(F, "    state.flat ? state : { ...state, base: state.base === shared.base ? state.base.slice() : state.base, mult: state.mult.slice() };",
       "    state.flat ? state : { ...state, base: state.base === shared.base ? state.base.slice() : state.base, mult: state.mult.slice(), roll: state.roll && state.roll === shared.roll ? state.roll.slice() : state.roll, rollMult: state.rollMult ? state.rollMult.slice() : null };")
sub(F, """          const lift = ma * a.base[q + 1] + mb * b.base[q + 1] + mc * c.base[q + 1];
          foam = Math.min(Math.max(0, concave), cap[i]) + Math.max(0, lift);
        }
        if (j === 0) at0 = foam;""",
"""          let lift = ma * a.base[q + 1] + mb * b.base[q + 1] + mc * c.base[q + 1];
          if (a.roll !== null) lift += a.rollMult![i] * a.roll[i * J + j];
          if (b.roll !== null) lift += b.rollMult![i] * b.roll[i * J + j];
          if (c.roll !== null) lift += c.rollMult![i] * c.roll[i * J + j];
          foam = Math.min(Math.max(0, concave), cap[i]) + Math.max(0, lift);
        }
        if (j === 0) at0 = foam;""")
# the grid search: a nose concave's Edge Roll swept like an across mark
sub(F, """        const marks: ("offRail" | "offStringer" | "troughAt")[] =
          kind === "double"
            ? ["troughAt", "offRail"]
            : kind === "single"
              ? ["offRail"]""",
"""        const rollInGrid = process.env.SPIKE_ROLL === "grid" && key === "nose" && kind === "single";
        const marks: ("offRail" | "offStringer" | "troughAt" | "edgeRoll")[] =
          kind === "double"
            ? ["troughAt", "offRail"]
            : kind === "single"
              ? rollInGrid ? ["offRail", "edgeRoll"] : ["offRail"]""")
sub(F, """          const { min, max } = BOTTOM_MARK_RANGES_IN[field];
          const make = (x: number): BottomCutSpec => {
            const spec = { ...s[key].spec, [field]: inchesToMm(x) };""",
"""          const { min, max } = field === "edgeRoll" ? { min: 0, max: BOTTOM_DEPTH_RANGE_IN.max } : BOTTOM_MARK_RANGES_IN[field];
          const make = (x: number): BottomCutSpec => {
            const spec: BottomCutSpec = { ...s[key].spec, [field]: inchesToMm(x) };
            if (field === "edgeRoll" && !(x > 0)) delete spec.edgeRoll;""")
# the polish: with SPIKE_ROLL=grid the roll is one of a nose concave's own sliders, in the one polish
sub(F, "      if (kind === \"single\" && key === \"nose\" && free.includes(\"roll-nose\")) fields.push({ key, field: \"edgeRoll\" });",
       "      if (kind === \"single\" && key === \"nose\" && (free.includes(\"roll-nose\") || process.env.SPIKE_ROLL === \"grid\")) fields.push({ key, field: \"edgeRoll\" });")

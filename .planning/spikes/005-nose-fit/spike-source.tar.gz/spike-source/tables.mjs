// Markdown tables from the timing rounds: node tables.mjs <out folder> <rounds>
import { readFileSync } from "node:fs";
const [dir, rounds] = [process.argv[2], Number(process.argv[3])];
const modes = ["before", "starts", "roll", "rolltail", "shape", "rail"];
const data = {};
for (const m of modes) data[m] = Array.from({ length: rounds }, (_, i) => JSON.parse(readFileSync(`${dir}/time-${m}-${i + 1}.json`, "utf8")));
const names = data.before[0].map((r) => r.name);
const row = (m, n) => data[m][0].find((r) => r.name === n);
const secs = (m, n) => Math.min(...data[m].map((run) => run.find((r) => r.name === n).secs));
const f = (x) => `${x[0].toFixed(2)} / ${x[1].toFixed(2)}`;
const cutNames = (r) => ["nose", "center", "tail"].map((k) => r.specs[k].name).join(" · ");
const same = (a, b) => JSON.stringify(a.specs) === JSON.stringify(b.specs) && JSON.stringify(a.sections) === JSON.stringify(b.sections);
for (const m of modes.slice(1)) {
  console.log(`\n### ${m}\n| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |\n|---|---|---|---|---|---|---|---|`);
  let tb = 0, ta = 0;
  for (const n of names) { const b = row("before", n), a = row(m, n); tb += secs("before", n); ta += secs(m, n);
    console.log(`| ${n} | ${f(b.bottom)} | ${same(a, b) ? "identical" : f(a.bottom)} | ${f(b.rails)} | ${same(a, b) ? "identical" : f(a.rails)} | ${same(a, b) ? "same" : a.cuts.join(" · ").replace(/ sm \d+/g, "")} | ${secs("before", n).toFixed(2)} s | ${secs(m, n).toFixed(2)} s |`); }
  console.log(`| Total | | | | | | ${tb.toFixed(1)} s | ${ta.toFixed(1)} s |`);
}
// every round must agree on the numbers
for (const m of modes) for (let i = 1; i < rounds; i++) for (const n of names) if (!same(data[m][0].find((r) => r.name === n), data[m][i].find((r) => r.name === n))) console.log(`!! ${m} round ${i + 1} differs on ${n}`);

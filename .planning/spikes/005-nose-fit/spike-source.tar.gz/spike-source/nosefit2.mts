// Off line: model E, one concave (today's curve) plus a roll that starts at the concave's OWN edge and runs to the rail:
// one new number (the roll's height at the rail). The roll's curve tried straight (a chine/bevel, 0), 60 and 100 (a rolled belly).
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const IN = 25.4;
const sec = (u: number, r: number) => (1 - r) * (1 - u) + r * (1 + Math.cos(Math.PI * u)) / 2;
const rise = (u: number, r: number) => (1 - r) * u + r * (1 - Math.cos(Math.PI * u / 2));
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const at = (r: number[][], x: number) => { for (let k = 0; k + 1 < r.length; k++) if (x >= r[k][0] && x <= r[k + 1][0]) return r[k][1] + (r[k + 1][1] - r[k][1]) * (x - r[k][0]) / (r[k + 1][0] - r[k][0] || 1); return x <= r[0][0] ? r[0][1] : r[r.length - 1][1]; };
const pick: Record<string, number> = { "92Log": 90, "Scoop-Noserider": 70, "testLB": 80 };
for (const name of Object.keys(pick)) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  console.log(`\n=== ${name}`);
  for (const s of look.bottom.sections) {
    if (s.station / IN < pick[name]) continue;
    const rs = look.rails.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    const o = run(rs.ours); let on = false;
    const rr: number[] = s.across.map((y: number, j: number) => { const d = at(o, y) - s.ours[j]; if (!on && Math.abs(d) > 0.05) on = true; return on ? d : 0; });
    const W = s.reach, ys: number[] = s.across, n = ys.length;
    const fit = (target: number[], r2s: number[], rollMax = 12.71) => {
      let best = { v: 1e9, mx: 0, typ: 0, txt: "" };
      for (const k of [0, 0.25, 0.5, 0.7, 1]) for (let Cs = 0.3; Cs <= 1.0001; Cs += 0.02) { const C = Cs * W;
        for (const r2 of r2s) for (let d = 0; d <= 12.71; d += 0.2) for (let D = 0; D <= rollMax; D += 0.4) {
          let mx = 0, sum = 0;
          for (let j = 0; j < n; j++) { const y = ys[j]; const m = y < C ? d * (sec(y / C, k) - 1) : -d + (W > C ? D * rise((y - C) / (W - C), r2) : 0); const e = Math.abs(target[j] - m); sum += e; if (e > mx) mx = e; }
          if (mx + sum / n < best.v) best = { v: mx + sum / n, mx, typ: sum / n, txt: `depth ${(d / IN).toFixed(2)}" edge ${((W - C) / IN).toFixed(1)}" in sm ${k * 100}; roll ${(D / IN).toFixed(2)}" curve ${r2 * 100}` };
        } }
      return best; };
    const plain: number[] = s.file, aware = s.file.map((v: number, j: number) => v - rr[j]);
    const f = (b: any) => `${b.mx.toFixed(2)}/${b.typ.toFixed(2)}`;
    const E0 = fit(plain, [0]), E6 = fit(plain, [0.6]), E1 = fit(plain, [1]), Ea = fit(aware, [0, 0.6, 1]), Eb = fit(plain, [0, 0.6, 1]);
    console.log(` st ${(s.station / IN).toFixed(1)}" in the import ${s.gap.largest.toFixed(2)} | E straight ${f(E0)}  E 60 ${f(E6)}  E 100 ${f(E1)} | best ${Eb.txt} | rail-aware best ${f(Ea)}: ${Ea.txt}`);
  }
}

// Open times the way spike 004 took them: one process, warmed, every mode on every file three times over, the fastest kept.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { brdLookFromBytes } = await import(`${ROOT}/lib/export/brd-look.ts`);
const FILES = ["92Log", "Scoop-Noserider", "testLB", "quadtesting", "SAtri", "SAtwin", "mid", "JFS_BigTwin", "6'10-Widepoint-Fwd-Egg", "6'2-Round-Tail---Double-Concave", "6'4-Double-Wing-Groveler", "Fryer-5'7-Squash-Flyer-Twin"];
const KEYS = ["SPIKE_STARTS", "SPIKE_POLISH", "SPIKE_GATE_MM", "SPIKE_ONE", "SPIKE_READ", "SPIKE_SHAPE"];
const modes: [string, Record<string, string>][] = [
  ["today", {}],
  ["nose restart alone", { SPIKE_STARTS: "nose", SPIKE_GATE_MM: "1", SPIKE_ONE: "1" }],
  ["Edge Roll", { SPIKE_STARTS: "nose", SPIKE_POLISH: "roll-nose", SPIKE_GATE_MM: "1", SPIKE_ONE: "1" }],
  ["Edge Roll + tail offered", { SPIKE_STARTS: "nose,tail", SPIKE_POLISH: "roll-nose", SPIKE_GATE_MM: "1", SPIKE_ONE: "1" }],
  ["power curve", { SPIKE_STARTS: "nose", SPIKE_POLISH: "shape-nose", SPIKE_SHAPE: "power", SPIKE_GATE_MM: "1", SPIKE_ONE: "1" }],
  ["rail-aware reading", { SPIKE_READ: "rail" }],
];
const bytesOf = (f: string) => new Uint8Array(readFileSync(`${homedir()}/Downloads/${f}.brd`));
brdLookFromBytes(bytesOf(FILES[0]), FILES[0] + ".brd");
const best: Record<string, number[]> = {}; const shown: Record<string, string[]> = {};
for (let rep = 0; rep < 3; rep++) for (const f of FILES) for (const [m, [, env]] of modes.entries()) {
  for (const k of KEYS) delete process.env[k];
  Object.assign(process.env, env);
  const b = bytesOf(f); const t0 = performance.now(); const r = brdLookFromBytes(b, f + ".brd"); const s = (performance.now() - t0) / 1000;
  (best[f] ??= modes.map(() => 99))[m] = Math.min(best[f][m], s);
  const c = r.look.bottom.closeness, q = r.look.rails.closeness;
  (shown[f] ??= [])[m] = `${c.largest.toFixed(2)} / ${c.typical.toFixed(2)} (rails ${q.largest.toFixed(2)} / ${q.typical.toFixed(2)})`;
}
const tot = modes.map(() => 0);
let out = `| File | ${modes.map((m) => m[0]).join(" | ")} |\n|---|${modes.map(() => "---").join("|")}|\n`;
for (const f of FILES) { out += `| ${f} | ${best[f].map((v) => v.toFixed(2) + " s").join(" | ")} |\n`; best[f].forEach((v, i) => (tot[i] += v)); }
out += `| Total | ${tot.map((v) => v.toFixed(1) + " s").join(" | ")} |\n\n`;
for (const f of FILES) out += `${f}: ${shown[f].join(" ; ")}\n`;
writeFileSync(process.env.OUT!, out); console.log(out);

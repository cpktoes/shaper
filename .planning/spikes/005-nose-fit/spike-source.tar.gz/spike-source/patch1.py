# Spike 005 trial code, part 1. Applies to a detached worktree only: python3 -I patch1.py <worktree>
import sys, pathlib
wt = pathlib.Path(sys.argv[1])
def sub(path, old, new, count=1):
    p = wt / path; s = p.read_text()
    assert s.count(old) >= 1, (path, old[:60])
    if count == 1: assert s.count(old) == 1, (path, old[:60], s.count(old))
    p.write_text(s.replace(old, new)); 

# ---- bottom.ts: a single concave's across-shape (trial; absent = today's curve to the last bit)
B = "lib/geometry/bottom.ts"
sub(B, "  closesToPoint: boolean;\n  /**\n   * How a double's trough runs along the board (quick 261115-mc1, D-01).",
       "  closesToPoint: boolean;\n  /** SPIKE 005: a single concave's across-shape number; absent reads today's curve. */\n  acrossShape?: number;\n  /**\n   * How a double's trough runs along the board (quick 261115-mc1, D-01).")
sub(B, "  closesToPoint: boolean;\n  /** How a double's trough runs (D-01): the stored rule, Parallel when none is stored (D-06). */",
       "  closesToPoint: boolean;\n  acrossShape?: number;\n  /** How a double's trough runs (D-01): the stored rule, Parallel when none is stored (D-06). */")
sub(B, "    closesToPoint: spec.closesToPoint,\n    troughRun: spec.troughRun ?? \"parallel\",",
       "    closesToPoint: spec.closesToPoint,\n    acrossShape: spec.acrossShape,\n    troughRun: spec.troughRun ?? \"parallel\",")
sub(B, "      if (cut.kind === \"single\") concave += cut.depth * f * Math.min(1, C / PINCH) * sec(y / C, r);",
       "      if (cut.kind === \"single\") concave += cut.depth * f * Math.min(1, C / PINCH) * (cut.acrossShape === undefined ? sec(y / C, r) : spikeSec(y / C, r, cut.acrossShape));")
sub(B, "/** The across-section curve of a lift: nothing at the stringer (u = 0), full at the rail (u = 1). */",
       """/**
 * SPIKE 005: the trial across-curves of a single concave. SPIKE_SHAPE=power: 1 - u^k (k 1 to 4: 1 is Smoothness 0's straight
 * line, 2 a parabola that deepens steadily to a crisp edge, 4 a flat-bottomed concave). SPIKE_SHAPE=edge: today's curve blended
 * toward that parabola by k (0 to 1), so 0 is today's exactly.
 */
export const spikeSec = (u: number, r: number, k: number): number =>
  (typeof process !== "undefined" && process.env.SPIKE_SHAPE === "edge") ? (1 - k) * sec(u, r) + k * (1 - u * u) : 1 - Math.pow(u, k);
/** The across-section curve of a lift: nothing at the stringer (u = 0), full at the rail (u = 1). */""")

# ---- brd-bottom.ts: the polish's extra freedoms, and a rail-aware measure
F = "lib/geometry/brd-bottom.ts"
sub(F, "|${s.smoothness}|${s.closesToPoint}`;", "|${s.smoothness}|${s.closesToPoint}|${s.acrossShape}`;")
sub(F, "  const polish = (specs: Specs): { specs: Specs; value: number } => {\n    const IN = inchesToMm(1);\n    const startValue = valueOfSpecs(specs);\n    type PolishField = \"start\" | \"deepest\" | \"end\" | \"depth\" | \"offRail\" | \"offStringer\" | \"troughAt\";",
       "  const polish = (specs: Specs, free: readonly string[] = []): { specs: Specs; value: number } => {\n    const IN = inchesToMm(1);\n    const startValue = valueOfSpecs(specs);\n    type PolishField = \"start\" | \"deepest\" | \"end\" | \"depth\" | \"offRail\" | \"offStringer\" | \"troughAt\" | \"smoothness\" | \"acrossShape\";\n    const edge = process.env.SPIKE_SHAPE === \"edge\";")
sub(F, "      for (const field of marks) fields.push({ key, field });\n    }\n    if (fields.length === 0) return { specs, value: startValue };",
       """      for (const field of marks) fields.push({ key, field });
      // SPIKE 005: the extra freedoms. smooth-nose / smooth-single / smooth-all; shape-nose / shape-single.
      if (free.includes("smooth-all") || (free.includes("smooth-single") && kind === "single") || (free.includes("smooth-nose") && key === "nose")) fields.push({ key, field: "smoothness" });
      if (kind === "single" && (free.includes("shape-single") || (free.includes("shape-nose") && key === "nose"))) fields.push({ key, field: "acrossShape" });
    }
    if (fields.length === 0) return { specs, value: startValue };""")
sub(F, "    const x0 = fields.map(({ key, field }) => (isStation(field) ? resolveCut(key, specs[key], board)[field] : specs[key][field]) / IN);",
       "    const x0 = fields.map(({ key, field }) =>\n      field === \"smoothness\" ? specs[key].smoothness : field === \"acrossShape\" ? (specs[key].acrossShape ?? (edge ? 0 : 2)) : (isStation(field) ? resolveCut(key, specs[key], board)[field] : specs[key][field]) / IN);")
sub(F, "      isStation(field) ? BRD_BOTTOM_POLISH_STATION_IN : field === \"depth\" ? BRD_BOTTOM_POLISH_DEPTH_IN : BRD_BOTTOM_POLISH_MARK_IN,",
       "      field === \"smoothness\" ? 10 : field === \"acrossShape\" ? (edge ? 0.25 : 0.5) : isStation(field) ? BRD_BOTTOM_POLISH_STATION_IN : field === \"depth\" ? BRD_BOTTOM_POLISH_DEPTH_IN : BRD_BOTTOM_POLISH_MARK_IN,")
sub(F, "    const heldTo = (field: PolishField, inches: number): number => {\n      if (isStation(field))",
       "    const heldTo = (field: PolishField, inches: number): number => {\n      if (field === \"smoothness\") return Math.min(100, Math.max(0, inches));\n      if (field === \"acrossShape\") return edge ? Math.min(1, Math.max(0, inches)) : Math.min(4, Math.max(1, inches));\n      if (isStation(field))")
sub(F, "      const range = BOTTOM_MARK_RANGES_IN[field];\n      return Math.min(range.max * IN, Math.max(range.min * IN, inches * IN));\n    };\n    const build",
       "      const range = BOTTOM_MARK_RANGES_IN[field as \"offRail\"];\n      return Math.min(range.max * IN, Math.max(range.min * IN, inches * IN));\n    };\n    const build")
sub(F, "          spec = isStation(field) ? { ...base, ...storeCutStation(key, field, mm(at), board) } : { ...base, [field]: mm(at) };",
       "          spec = isStation(field) ? { ...base, ...storeCutStation(key, field, mm(at), board) } : { ...base, [field]: mm(at) };\n          if (field === \"acrossShape\" && edge && at === 0) delete (spec as BottomCutSpec).acrossShape;")
# the two-step polish: today's first, then the extra freedoms from there, kept only when the shown figure is better
sub(F, """  const { specs } = scorer.polish({ nose: bottom.nose, center: bottom.center, tail: bottom.tail });
  const polished = { ...bottom, nose: specs.nose, center: specs.center, tail: specs.tail };
  const shown = (b: BoardBottom): number => {
    const { largest, typical } = measureBrdBottom(b, sections, board0).closeness;
    return largest + typical;
  };
  return shown(polished) <= shown(bottom) + NOISE ? polished : bottom;""",
"""  const { specs } = scorer.polish({ nose: bottom.nose, center: bottom.center, tail: bottom.tail });
  const polished = { ...bottom, nose: specs.nose, center: specs.center, tail: specs.tail };
  const shown = (b: BoardBottom): number => {
    const { largest, typical } = measureBrdBottom(b, sections, board0).closeness;
    return largest + typical;
  };
  const today = shown(polished) <= shown(bottom) + NOISE ? polished : bottom;
  // SPIKE 005: today's polish first, untouched; then the extra freedoms from there, kept only when the shown figure is better.
  const free = (process.env.SPIKE_POLISH ?? "").split(",").filter(Boolean);
  if (free.length === 0) return today;
  const more = scorer.polish({ nose: today.nose, center: today.center, tail: today.tail }, free).specs;
  const freed = { ...today, nose: more.nose, center: more.center, tail: more.tail };
  return shown(freed) < shown(today) - NOISE ? freed : today;""")

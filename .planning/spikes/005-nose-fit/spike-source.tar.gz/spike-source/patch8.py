# Spike 005 trial code, part 8: SPIKE_STARTS=nose. After today's polish, the nose is also tried afresh (a Blended Nose Concave
# from 1/16", and the fitted nose concave once more), each polished with SPIKE_POLISH's freedoms; the closest shown is kept, and a
# start that changes a name must be BRD_BOTTOM_EXTRA_CUT_MM closer. SPIKE_STARTS=nose,tail adds a Rolled Vee tail from 1/4" where
# the tail is flat. python3 -I patch8.py <worktree>
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/geometry/brd-bottom.ts"; s = p.read_text()
old = s[s.index("  // SPIKE 005: today's polish first, untouched; then the extra freedoms"):s.index("  return shown(freed) < shown(today) - NOISE ? freed : today;") + len("  return shown(freed) < shown(today) - NOISE ? freed : today;")]
new = '''  // SPIKE 005: today's polish first, untouched; then the extra freedoms from there, kept only when the shown figure is better.
  const free = (process.env.SPIKE_POLISH ?? "").split(",").filter(Boolean);
  const startsOn = (process.env.SPIKE_STARTS ?? "").split(",").filter(Boolean);
  if (free.length === 0 && startsOn.length === 0) return today;
  const board = rememberBoard(board0);
  const rollSeed = free.includes("roll-nose") ? { edgeRoll: inchesToMm(1 / 8) } : {};
  const starts: Specs[] = [];
  const mine: Specs = { nose: today.nose, center: today.center, tail: today.tail };
  if (free.length > 0) starts.push(mine);
  if (startsOn.includes("nose")) {
    const blended: BottomCutSpec = { ...startingCut("nose", "Blended Nose Concave", board), depth: inchesToMm(BOTTOM_MARK_STEP_IN), ...rollSeed };
    starts.push({ ...mine, nose: blended });
    if (startsOn.includes("tail") && cutKind(today.tail.name) === "flat") {
      const vee: BottomCutSpec = { ...startingCut("tail", "Rolled Vee", board), depth: inchesToMm(1 / 4) };
      starts.push({ ...mine, tail: vee }, { ...mine, nose: blended, tail: vee });
    }
  }
  let best = today;
  let bestShown = shown(today);
  const namesOf = (b: Specs) => `${b.nose.name}|${b.center.name}|${b.tail.name}`;
  for (const start of starts) {
    const more = scorer.polish(start, free).specs;
    const tried = { ...today, nose: more.nose, center: more.center, tail: more.tail };
    const v = shown(tried);
    const bar = namesOf(more) === namesOf(mine) ? NOISE : BRD_BOTTOM_EXTRA_CUT_MM;
    if (v < Math.min(bestShown, shown(today) - bar)) {
      best = tried;
      bestShown = v;
    }
  }
  return best;'''
s = s.replace(old, new); p.write_text(s)

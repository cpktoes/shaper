# part 2b: the imports patch 2 needs. python3 -I patch2b.py <worktree>
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/export/brd-fit-preview.ts"; s = p.read_text()
s = s.replace("  brdFittedBottomBoard,\n  brdStringerLift,", "  brdBottomSections,\n  brdFittedBottomBoard,\n  brdStringerLift,", 1)
s = s.replace("  brdAnchorSections,\n  brdRailBegins,\n  brdRailBoard,", "  brdAnchorSections,\n  brdOurRailHalf,\n  brdRailBegins,\n  brdRailBoard,", 1)
s = s.replace("  type BrdRailGap,\n", "  type BrdRailBoard,\n  type BrdRailGap,\n", 1)
if "RailBandSpec" not in s.split("export function brdFitLook")[0]:
    s = s.replace('import type { P2 } from "../geometry/bezier-fit";', 'import type { P2 } from "../geometry/bezier-fit";\nimport type { RailBandSpec } from "../geometry/rail-bands";', 1)
p.write_text(s)

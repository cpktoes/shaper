# Spike 005 trial code, part 7: SPIKE_DEBUG=2 prints the grid search's Edge Roll sweep.
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/geometry/brd-bottom.ts"; s = p.read_text()
old = "          for (let k = 0; min + k * coarse <= max + NOISE; k++) tryMark(min + k * coarse);"
new = "          if (field === \"edgeRoll\" && process.env.SPIKE_DEBUG === \"2\") console.error(`   [roll sweep] ${s.nose.spec.name} · ${s.center.spec.name} · ${s.tail.spec.name} now ${current.toFixed(3)}: ` + Array.from({ length: 9 }, (_, k) => trial(key, make(k / 16)).toFixed(3)).join(\" \"));\n" + old
assert s.count(old) == 1; s = s.replace(old, new); p.write_text(s)

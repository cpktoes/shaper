// Runs the real import on the founder's twelve files; ROOT picks the checkout (main or the trial worktree).
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const OUT = process.env.OUT!;
const { brdLookFromBytes } = await import(`${ROOT}/lib/export/brd-look.ts`);
const FILES = ["92Log", "Scoop-Noserider", "testLB", "quadtesting", "SAtri", "SAtwin", "mid", "JFS_BigTwin", "6'10-Widepoint-Fwd-Egg", "6'2-Round-Tail---Double-Concave", "6'4-Double-Wing-Groveler", "Fryer-5'7-Squash-Flyer-Twin"];
const only = process.env.ONLY?.split(",");
const IN = 25.4;
const rows: any[] = [];
for (const name of FILES) {
  if (only && !only.includes(name)) continue;
  const bytes = new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`));
  const t0 = performance.now();
  const r = brdLookFromBytes(bytes, `${name}.brd`);
  const secs = (performance.now() - t0) / 1000;
  if (!r.ok) { rows.push({ name, problem: r.problem }); continue; }
  const b = r.look.bottom!;
  const cut = (c: any) => `${c.name} ${(c.depth / IN).toFixed(3)}"${c.offStringer > 0.3 ? ` os ${(c.offStringer / IN).toFixed(2)}"` : ""}${c.acrossShape !== undefined ? ` shape ${Number(c.acrossShape).toFixed(2)}` : ""}${c.edgeRoll ? ` roll ${(c.edgeRoll / IN).toFixed(3)}"` : ""}${c.smoothness !== undefined && c.depth > 0 ? ` sm ${Number(c.smoothness).toFixed(0)}` : ""}`;
  const row = {
    name, secs,
    bottom: [b.closeness.largest, b.closeness.typical, b.closeness.station, b.closeness.across],
    rails: r.look.rails ? [r.look.rails.closeness.largest, r.look.rails.closeness.typical] : null,
    cuts: [cut(b.bottom.nose), cut(b.bottom.center), cut(b.bottom.tail)],
    specs: b.bottom,
    sections: b.sections.map((s: any) => ({ station: s.station, reach: s.reach, window: s.window, across: s.across, file: s.file, ours: s.ours, gap: s.gap, flat: s.flat, reads: s.reads })),
    length: r.look.fit.outline?.length ?? r.look.board.length,
  };
  rows.push(row);
  console.log(`${name.padEnd(34)} bottom ${row.bottom[0].toFixed(2)} / ${row.bottom[1].toFixed(2)}  rails ${row.rails ? row.rails[0].toFixed(2) + " / " + row.rails[1].toFixed(2) : "-"}  ${secs.toFixed(2)} s  | ${row.cuts.join(" · ")}`);
}
if (OUT) writeFileSync(OUT, JSON.stringify(rows));

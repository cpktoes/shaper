# Spike 005 trial code, part 10: SPIKE_ONE=1 drops the second polish of the fitted nose (it never won), leaving one restart.
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/geometry/brd-bottom.ts"; s = p.read_text()
old = "  if (free.length > 0 && (process.env.SPIKE_GATE_MM === undefined"
assert s.count(old) == 1; s = s.replace(old, "  if (free.length > 0 && !process.env.SPIKE_ONE && (process.env.SPIKE_GATE_MM === undefined"); p.write_text(s)

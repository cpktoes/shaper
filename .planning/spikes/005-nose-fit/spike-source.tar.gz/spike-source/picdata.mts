// The whole half section, the file's and ours as it opens (cuts with the fitted rail), for the picture of where the miss sits.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const IN = 25.4;
const pick: Record<string, number[]> = { "92Log": [94.5, 106.9], "Scoop-Noserider": [73.7, 97.7], "testLB": [96.0, 102.5] };
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const out: any[] = [];
for (const name of Object.keys(pick)) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  for (const s of look.bottom.sections) {
    if (!pick[name].some((p) => Math.abs(p - s.station / IN) < 0.3)) continue;
    const rs = look.rails.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    out.push({ name, station: s.station, reach: s.reach, window: s.window, across: s.across, cuts: s.ours, gap: s.gap, file: run(rs.file), ours: run(rs.ours) });
  }
}
writeFileSync(process.env.OUT!, JSON.stringify(out));
console.log(out.length, "sections");

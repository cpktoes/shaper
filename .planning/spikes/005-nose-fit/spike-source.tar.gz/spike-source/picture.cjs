// Two PNGs. node picture.cjs <before.json> <trial.json> <whole.json> <out folder> "<trial label>"
//  nose-sections.png  the file's bottom, today's fit and the trial at the nose sections of the three files
//  nose-where.png     the file's whole half section against ours as it opens, with the reading width marked
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [beforeFile, trialFile, wholeFile, outDir, trialLabel] = process.argv.slice(2);
const before = JSON.parse(fs.readFileSync(beforeFile)), trial = JSON.parse(fs.readFileSync(trialFile)), whole = JSON.parse(fs.readFileSync(wholeFile));
const IN = 25.4;
const INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", TODAY = "#2a78d6", TRIAL = "#eb6834", BAND = "#f1efe8";
const CSS = `body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:${INK}}
  .wrap{width:1240px;padding:22px 24px 20px} h1{font-size:19px;margin:0 0 4px;font-weight:600} h2{font-size:14px;margin:16px 0 2px;font-weight:600} p{margin:0 0 4px;font-size:13px;color:${SUB};line-height:1.45}
  .t{font-size:11px;fill:${SUB}} .h{font-size:13px;font-weight:600;fill:${INK}} .row{display:flex;gap:10px;margin-top:6px}
  .key{display:flex;gap:22px;font-size:13px;margin-top:10px;color:${INK}} .key svg{vertical-align:middle;margin-right:6px}`;
const key = (third) => `<div class="key"><span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${INK}" stroke-width="2"/></svg>The file</span>
  <span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/></svg>Today's fit</span>${third}</div>`;
function axes(W, H, L, R, T, B, lo, hi, xMax, x, yy) {
  const span = hi - lo, step = span > 16 ? 5 : span > 8 ? 2 : span > 4 ? 1 : span > 1.6 ? 0.5 : 0.25;
  let g = "";
  for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) g += `<line x1="${L}" x2="${W - R}" y1="${yy(v)}" y2="${yy(v)}" stroke="${Math.abs(v) < 1e-9 ? "#b9b8b2" : GRID}"/><text x="${L - 6}" y="${yy(v) + 4}" text-anchor="end" class="t">${+v.toFixed(2)}</text>`;
  for (let i = 0; i <= xMax; i += 2) g += `<text x="${x(i * IN)}" y="${H - B + 16}" text-anchor="middle" class="t">${i}"</text>`;
  return g;
}
function panel(sb, st, W) {
  const H = 290, L = 46, R = 14, T = 48, B = 40;
  const all = [...sb.file, ...sb.ours, ...st.ours];
  let lo = Math.min(0, ...all), hi = Math.max(0, ...all); const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const xMax = sb.window / IN;
  const x = (y) => L + ((y / IN) / xMax) * (W - L - R), yy = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const path = (s, vals) => vals.map((v, j) => `${j ? "L" : "M"}${x(s.across[j]).toFixed(1)},${yy(v).toFixed(1)}`).join("");
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <text x="${L}" y="16" class="h">${(sb.station / IN).toFixed(1)}" from the tail</text>
  <text x="${L}" y="32" class="t">Widest gap: today ${sb.gap.largest.toFixed(2)} mm, trial ${st.gap.largest.toFixed(2)} mm</text>
  ${axes(W, H, L, R, T, B, lo, hi, xMax, x, yy)}
  <path d="${path(sb, sb.ours)}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(st, st.ours)}" fill="none" stroke="${TRIAL}" stroke-width="2"/>
  <path d="${path(sb, sb.file)}" fill="none" stroke="${INK}" stroke-width="2"/>
  <text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="t">out from the stringer, to the edge of the reading width</text></svg>`;
}
function wholePanel(s, W) {
  const H = 300, L = 46, R = 14, T = 48, B = 40;
  const xMax = s.reach / IN, cap = Math.max(4, ...s.cuts.map(Math.abs), ...s.file.filter((p) => p[0] <= s.window).map((p) => Math.abs(p[1]))) * 2.2;
  const pts = (r) => r.filter((p) => p[1] <= cap * 1.05);
  let lo = Math.min(0, ...s.file.map((p) => p[1]), ...s.ours.map((p) => p[1]), ...s.cuts), hi = cap; const pad = (hi - lo) * 0.06; lo -= pad;
  const x = (y) => L + ((y / IN) / xMax) * (W - L - R), yy = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const path = (r) => pts(r).map((p, j) => `${j ? "L" : "M"}${x(p[0]).toFixed(1)},${yy(p[1]).toFixed(1)}`).join("");
  const cuts = s.cuts.map((v, j) => `${j ? "L" : "M"}${x(s.across[j]).toFixed(1)},${yy(v).toFixed(1)}`).join("");
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect x="${x(s.window)}" y="${T}" width="${W - R - x(s.window)}" height="${H - T - B}" fill="${BAND}"/>
  <text x="${L}" y="16" class="h">${s.name === "Scoop-Noserider" ? "Scoop" : s.name}, ${(s.station / IN).toFixed(1)}" from the tail</text>
  <text x="${L}" y="32" class="t">Bottom miss shown today ${s.gap.largest.toFixed(2)} mm, ${(s.gap.across / IN).toFixed(1)}" out; half-width ${(s.reach / IN).toFixed(1)}"</text>
  ${axes(W, H, L, R, T, B, lo, hi, xMax, x, yy)}
  <path d="${path(s.ours)}" fill="none" stroke="${TRIAL}" stroke-width="2"/>
  <path d="${cuts}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(s.file)}" fill="none" stroke="${INK}" stroke-width="2"/>
  <text x="${(x(s.window) + W - R) / 2}" y="${T + 12}" text-anchor="middle" class="t">not read</text>
  <text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="t">out from the stringer to the rail</text></svg>`;
}
const near = (r, s) => r.sections.find((q) => Math.abs(q.station / IN - s) < 0.3);
const rows = [["92Log", [94.5, 106.9]], ["Scoop-Noserider", [73.7, 85.7, 97.7]], ["testLB", [93.0, 96.0, 102.5]]];
const sectionsPage = () => `<!doctype html><meta charset="utf-8"><style>${CSS}</style><div class="wrap">
  <h1>The three noses: the file's bottom, today's fit and the trial</h1>
  <p>Through the real import. Trial: ${trialLabel}. Heights are stretched many times against the width; each panel has its own height scale. Up is toward the deck.</p>
  ${key(`<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TRIAL}" stroke-width="2"/></svg>The trial</span>`)}
  ${rows.map(([name, st]) => { const b = before.find((r) => r.name === name), t = trial.find((r) => r.name === name);
    return `<h2>${name}: bottom widest / typical ${b.bottom[0].toFixed(2)} / ${b.bottom[1].toFixed(2)} mm today, ${t.bottom[0].toFixed(2)} / ${t.bottom[1].toFixed(2)} mm with the trial</h2>
    <p>Today: ${b.cuts.join(" · ").replace(/ sm \d+/g, "")}</p><p>Trial: ${t.cuts.join(" · ").replace(/ sm \d+/g, "")}</p>
    <div class="row">${st.map((s) => panel(near(b, s), near(t, s), st.length === 2 ? 600 : 396)).join("")}</div>`; }).join("")}</div>`;
const wherePage = () => `<!doctype html><meta charset="utf-8"><style>${CSS}</style><div class="wrap">
  <h1>Where the nose miss sits: the file's whole half section against the board that opens today</h1>
  <p>The solid orange line is our finished section: BOTTOM's cuts with the fitted rail standing on them. The dashed blue line is what the bottom miss is measured against today: the cuts alone. The shaded band is outside the reading width. Heights are stretched; the rail runs off the top.</p>
  ${key(`<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TRIAL}" stroke-width="2"/></svg>Our finished section (cuts and rail)</span>`).replace("Today's fit", "Our bottom's cuts alone (what is scored)")}
  <div class="row">${whole.slice(0, 3).map((s) => wholePanel(s, 396)).join("")}</div><div class="row">${whole.slice(3, 6).map((s) => wholePanel(s, 396)).join("")}</div></div>`;
(async () => {
  const browser = await chromium.launch();
  const pg = await browser.newPage({ viewport: { width: 1290, height: 900 }, deviceScaleFactor: 2 });
  await pg.setContent(sectionsPage()); await pg.locator(".wrap").screenshot({ path: `${outDir}/nose-sections.png` });
  await pg.setContent(wherePage()); await pg.locator(".wrap").screenshot({ path: `${outDir}/nose-where.png` });
  await browser.close();
})();

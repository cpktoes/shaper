# Spike 005 trial code, part 9: SPIKE_GATE_MM (the restarts run only when today's shown widest miss is over this), and the
# fitted nose is polished again only when it is a concave (the only cut the new numbers belong to). python3 -I patch9.py <worktree>
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/geometry/brd-bottom.ts"; s = p.read_text()
def sub(old, new):
    global s
    assert s.count(old) == 1, (old[:70], s.count(old)); s = s.replace(old, new)
sub("  if (free.length === 0 && startsOn.length === 0) return today;",
    "  if (free.length === 0 && startsOn.length === 0) return today;\n  const gate = Number(process.env.SPIKE_GATE_MM ?? 0);\n  if (gate > 0 && !(measureBrdBottom(today, sections, board0).closeness.largest > gate)) return today;")
sub("  if (free.length > 0) starts.push(mine);",
    "  if (free.length > 0 && (process.env.SPIKE_GATE_MM === undefined || cutKind(today.nose.name) === \"single\" || free.some((f) => f.endsWith(\"-all\")))) starts.push(mine);")
p.write_text(s)

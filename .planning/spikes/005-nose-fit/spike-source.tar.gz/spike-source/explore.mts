// Exploration on one file: today's polished bottom, then the polish again with extra freedoms from several starts.
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdFittedBottomBoard, brdBottomScorer, brdBottomBlends, measureBrdBottom } = await import(`${ROOT}/lib/geometry/brd-bottom.ts`);
const IN = 25.4;
const name = process.argv[2];
const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
const look = brdFitLook(read.board);
const board = brdFittedBottomBoard(look.fit, look.fins?.spec);
const sections = look.bottom.sections.map((s: any) => ({ ...s, ours: [], gap: { largest: 0, across: 0 } }));
const scorer = brdBottomScorer(board, brdBottomBlends(sections));
const b = look.bottom.bottom;
const base = { nose: b.nose, center: b.center, tail: b.tail };
const show = (label: string, specs: any) => {
  const m = measureBrdBottom({ ...b, ...specs }, sections, board);
  const cut = (c: any) => `${c.name.split(" ").slice(0, 2).join(" ")} ${(c.depth / IN).toFixed(3)}" sm ${Number(c.smoothness).toFixed(0)}${c.acrossShape !== undefined ? ` shape ${c.acrossShape.toFixed(2)}` : ""} or ${(c.offRail / IN).toFixed(2)} os ${(c.offStringer / IN).toFixed(2)}`;
  console.log(`${label.padEnd(34)} score ${scorer.valueOfSpecs(specs).toFixed(3)} shown ${m.closeness.largest.toFixed(2)}/${m.closeness.typical.toFixed(2)} @${(m.closeness.station / IN).toFixed(1)}" | ${cut(specs.nose)} · ${cut(specs.center)} · ${cut(specs.tail)}`);
  console.log("      per section: " + m.sections.map((s: any) => `${(s.station / IN).toFixed(0)}":${s.gap.largest.toFixed(2)}`).join(" "));
};
show("today", base);
const t = (label: string, start: any, free: string[]) => { const t0 = performance.now(); const r = scorer.polish(start, free); show(`${label} (${((performance.now() - t0) / 1000).toFixed(1)} s)`, r.specs); return r.specs; };
t("polish again, nothing new", base, []);
for (const sm of [0, 30, 50, 100]) t(`smooth-nose from ${sm}`, { ...base, nose: { ...base.nose, smoothness: sm } }, ["smooth-nose"]);
for (const sm of [0, 50]) t(`smooth-all, nose from ${sm}`, { ...base, nose: { ...base.nose, smoothness: sm } }, ["smooth-all"]);
if (process.env.SPIKE_SHAPE) for (const k of (process.env.SPIKE_SHAPE === "edge" ? [0, 0.5, 1] : [1.3, 1.6, 2, 3, 4])) t(`shape-nose from ${k}`, { ...base, nose: { ...base.nose, acrossShape: k } }, ["shape-nose"]);

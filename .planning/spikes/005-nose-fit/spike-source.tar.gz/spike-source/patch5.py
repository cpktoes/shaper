# Spike 005 trial code, part 5: SPIKE_DEBUG prints which order won and by how much. python3 -I patch5.py <worktree>
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/export/brd-fit-preview.ts"; s = p.read_text()
def sub(old, new):
    global s
    assert s.count(old) == 1, (old[:70], s.count(old)); s = s.replace(old, new)
sub("  if (!(whole.largest > BRD_RAIL_FIRST_TRY_MM) || !kinds.some((kind) => kind === \"vee\" || kind === \"belly\")) return settled(result);",
    "  const dbg = (m: string) => { if (process.env.SPIKE_DEBUG) console.error(\"   [order] \" + m); };\n  const nm = (st: BottomStep) => BOTTOM_KEYS.map((k) => st.bottom.bottom[k].name).join(\" · \") + ` bottom ${st.bottom.closeness.largest.toFixed(2)}/${st.bottom.closeness.typical.toFixed(2)}`;\n  dbg(`bottom-first: ${nm(current)}; whole largest ${whole.largest.toFixed(2)} value ${whole.value.toFixed(2)}; rails ${bottomFirst.closeness.largest.toFixed(2)}/${bottomFirst.closeness.typical.toFixed(2)}`);\n  if (!(whole.largest > BRD_RAIL_FIRST_TRY_MM) || !kinds.some((kind) => kind === \"vee\" || kind === \"belly\")) return settled(result);")
sub("  if (!(wholeFirst.value <= whole.value - BRD_RAIL_FIRST_GAIN_MM)) return settled(result);",
    "  dbg(`rails-first: ${nm(railsFirst)}; whole largest ${wholeFirst.largest.toFixed(2)} value ${wholeFirst.value.toFixed(2)}; rails ${measured.closeness.largest.toFixed(2)}/${measured.closeness.typical.toFixed(2)} -> ${wholeFirst.value <= whole.value - BRD_RAIL_FIRST_GAIN_MM ? \"rails-first wins\" : \"bottom-first stays\"}`);\n  if (!(wholeFirst.value <= whole.value - BRD_RAIL_FIRST_GAIN_MM)) return settled(result);")
p.write_text(s)

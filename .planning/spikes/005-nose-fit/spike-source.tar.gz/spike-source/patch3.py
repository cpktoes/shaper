# Spike 005 trial code, part 3: an Edge Roll on a nose concave (SPIKE_POLISH=roll-nose). python3 -I patch3.py <worktree>
import sys, pathlib
wt = pathlib.Path(sys.argv[1])
def sub(path, old, new):
    p = wt / path; s = p.read_text()
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    p.write_text(s.replace(old, new))
B = "lib/geometry/bottom.ts"
sub(B, "  acrossShape?: number;\n  /**\n   * How a double's trough runs along the board",
       "  acrossShape?: number;\n  /** SPIKE 005: a nose concave's Edge Roll, the bottom's rise at the rail outside the concave's edge (a mark); absent reads 0. */\n  edgeRoll?: Mm;\n  /**\n   * How a double's trough runs along the board")
sub(B, "  acrossShape?: number;\n  /** How a double's trough runs (D-01)", "  acrossShape?: number;\n  edgeRoll?: Mm;\n  /** How a double's trough runs (D-01)")
sub(B, "    acrossShape: spec.acrossShape,\n", "    acrossShape: spec.acrossShape,\n    edgeRoll: spec.edgeRoll,\n")
sub(B, "    if (cut.spiral && cut.veeLift > 0 && W > 0) lift += cut.veeLift * f * rise(Math.min(1, y / W), 0);",
       "    if (cut.spiral && cut.veeLift > 0 && W > 0) lift += cut.veeLift * f * rise(Math.min(1, y / W), 0);\n    if (cut.kind === \"single\" && cut.edgeRoll !== undefined && cut.edgeRoll > 0) lift += cut.edgeRoll * edgeRollShare(cut, board, rule, s, y);")
# the roll is worked out before the concave's own fade test, so it holds to the tip ahead of the concave's Start
sub(B, "  const f = fadeAt(cut.start, cut.deepest, cut.end, s, board.length); if (f <= 0) return none;",
       "  const f = fadeAt(cut.start, cut.deepest, cut.end, s, board.length);\n  if (f <= 0) return cut.kind === \"single\" && cut.edgeRoll !== undefined && cut.edgeRoll > 0 ? { concave: 0, lift: cut.edgeRoll * edgeRollShare(cut, board, rule, s, y) } : none;")
sub(B, "/**\n * One cut alone, in its two kinds of work (D-40)",
"""/** SPIKE 005: the Edge Roll's curve from the concave's edge to the rail (the Rolled Vee's own Smoothness). */
export const EDGE_ROLL_SMOOTHNESS = 0.6;
/**
 * SPIKE 005: how much of a nose concave's Edge Roll stands at station `s`, `y` out: nothing inside the concave's edge (the
 * reference rail less Off Rail, never the Teardrop's closing width), rising to the whole roll at the rail; along the board the
 * whole of it from the nose tip back to the concave's Deepest At, then fading to nothing at its End.
 */
export function edgeRollShare(cut: ResolvedCut, board: BottomBoard, rule: BottomWingRule, s: Mm, y: Mm): number {
  const W = board.railAt(s);
  const C = Math.max(0, refAt(board, rule, s) - cut.offRail);
  if (!(W > C) || y <= C || s < cut.end) return 0;
  const along = s >= cut.deepest || cut.deepest - cut.end < FADE_GUARD ? 1 : smoothstep((s - cut.end) / (cut.deepest - cut.end));
  return along * rise(Math.min(1, (y - C) / (W - C)), EDGE_ROLL_SMOOTHNESS);
}

/**
 * One cut alone, in its two kinds of work (D-40)""")

F = "lib/geometry/brd-bottom.ts"
sub(F, "|${s.closesToPoint}|${s.acrossShape}`;", "|${s.closesToPoint}|${s.acrossShape}|${s.edgeRoll}`;")
# first cut of the trial: a cut with a roll is scored the slow way, like the Teardrop
sub(F, "    const slow = spec.closesToPoint;\n    const marks = marksKey(spec);", "    const slow = spec.closesToPoint || (spec.edgeRoll ?? 0) > 0;\n    const marks = marksKey(spec);")
sub(F, "\"smoothness\" | \"acrossShape\";\n    const edge", "\"smoothness\" | \"acrossShape\" | \"edgeRoll\";\n    const edge")
sub(F, "      if (kind === \"single\" && (free.includes(\"shape-single\")", "      if (kind === \"single\" && key === \"nose\" && free.includes(\"roll-nose\")) fields.push({ key, field: \"edgeRoll\" });\n      if (kind === \"single\" && (free.includes(\"shape-single\")")
sub(F, "field === \"acrossShape\" ? (specs[key].acrossShape ?? (edge ? 0 : 2)) : (isStation",
       "field === \"acrossShape\" ? (specs[key].acrossShape ?? (edge ? 0 : 2)) : field === \"edgeRoll\" ? (specs[key].edgeRoll ?? 0) / IN : (isStation")
sub(F, "      field === \"smoothness\" ? 10 : field === \"acrossShape\" ? (edge ? 0.25 : 0.5) : isStation(field)",
       "      field === \"smoothness\" ? 10 : field === \"acrossShape\" ? (edge ? 0.25 : 0.5) : field === \"edgeRoll\" ? 1 / 16 : isStation(field)")
sub(F, "      if (field === \"smoothness\") return Math.min(100, Math.max(0, inches));",
       "      if (field === \"smoothness\") return Math.min(100, Math.max(0, inches));\n      if (field === \"edgeRoll\") return Math.min(Number(process.env.SPIKE_ROLL_MAX_IN ?? BOTTOM_DEPTH_RANGE_IN.max) * IN, Math.max(0, inches * IN));")
sub(F, "          if (field === \"acrossShape\" && edge && at === 0) delete (spec as BottomCutSpec).acrossShape;",
       "          if (field === \"acrossShape\" && edge && at === 0) delete (spec as BottomCutSpec).acrossShape;\n          if (field === \"edgeRoll\" && at === 0) delete (spec as BottomCutSpec).edgeRoll;")

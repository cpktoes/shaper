#!/bin/bash
# timing.sh <first round> <last round>: the trials one after another, <rounds> times over, so every mode sees the same machine
S=/private/tmp/claude-501/-Users-kontoes-Code-shaper/002e2a58-3c43-4c8e-bbb5-e9c435113dd2/scratchpad/spike005
for r in $(seq $1 $2); do
  $S/src/run.sh time-before-$r
  $S/src/run.sh time-starts-$r SPIKE_STARTS=nose SPIKE_GATE_MM=1
  $S/src/run.sh time-roll-$r SPIKE_STARTS=nose SPIKE_POLISH=roll-nose SPIKE_GATE_MM=1
  $S/src/run.sh time-rolltail-$r SPIKE_STARTS=nose,tail SPIKE_POLISH=roll-nose SPIKE_GATE_MM=1
  $S/src/run.sh time-shape-$r SPIKE_STARTS=nose SPIKE_POLISH=shape-nose SPIKE_SHAPE=power SPIKE_GATE_MM=1
  $S/src/run.sh time-rail-$r SPIKE_READ=rail
done

import { readFileSync } from "node:fs";
const rows = JSON.parse(readFileSync(process.argv[2], "utf8"));
const names = process.argv[3].split(",");
const IN = 25.4;
for (const r of rows) {
  if (!names.includes(r.name)) continue;
  console.log(`\n=== ${r.name}  ${r.bottom[0].toFixed(2)}/${r.bottom[1].toFixed(2)}  ${r.cuts.join(" · ")}`);
  for (const k of ["nose","center","tail"]) { const c = r.specs[k]; console.log(`  ${k}: ${c.name} start ${(c.start/IN).toFixed(1)} deepest ${(c.deepest/IN).toFixed(1)} end ${(c.end/IN).toFixed(1)} depth ${c.depth.toFixed(2)}mm os ${(c.offStringer/IN).toFixed(2)} or ${(c.offRail/IN).toFixed(2)} sm ${c.smoothness}`); }
  for (const s of r.sections) {
    const idx = [0,3,6,9,12,15,18,21,24];
    console.log(` st ${(s.station/IN).toFixed(1)}" reach ${(s.reach/IN).toFixed(2)}" win ${(s.window/IN).toFixed(2)}" ${s.flat?"FLAT":s.reads.kind} gap ${s.gap.largest.toFixed(2)} @${(s.gap.across/IN).toFixed(1)}"`);
    console.log("   file " + idx.map(j => s.file[j].toFixed(2).padStart(6)).join(" "));
    console.log("   ours " + idx.map(j => s.ours[j].toFixed(2).padStart(6)).join(" "));
    console.log("   diff " + idx.map(j => (s.file[j]-s.ours[j]).toFixed(2).padStart(6)).join(" "));
  }
}

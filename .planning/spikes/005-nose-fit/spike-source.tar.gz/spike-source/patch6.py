# Spike 005 trial code, part 6: the grid search sweeps the Edge Roll at every 1/16" (a 1/4" first pass stepped over the answer).
import sys, pathlib
p = pathlib.Path(sys.argv[1]) / "lib/geometry/brd-bottom.ts"; s = p.read_text()
old = "          for (let k = 0; min + k * BRD_BOTTOM_MARK_COARSE_IN <= max + NOISE; k++) tryMark(min + k * BRD_BOTTOM_MARK_COARSE_IN);"
new = "          const coarse = field === \"edgeRoll\" ? BOTTOM_MARK_STEP_IN : BRD_BOTTOM_MARK_COARSE_IN;\n          for (let k = 0; min + k * coarse <= max + NOISE; k++) tryMark(min + k * coarse);"
assert s.count(old) == 1; s = s.replace(old, new); p.write_text(s)

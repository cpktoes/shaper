// What an Edge Roll could reach with a wider search than the import would ship: today's polished bottom, the nose swapped for
// each nose concave at a few depths and rolls, everything polished (the roll free), the closest few shown. Bottom-only reading.
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdFittedBottomBoard, brdBottomScorer, brdBottomBlends, measureBrdBottom } = await import(`${ROOT}/lib/geometry/brd-bottom.ts`);
const { startingCut } = await import(`${ROOT}/lib/geometry/bottom.ts`);
const IN = 25.4;
const free = (process.env.FREE ?? "roll-nose").split(",");
for (const name of process.argv[2].split(",")) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  const board = brdFittedBottomBoard(look.fit, look.fins?.spec);
  const sections = look.bottom.sections.map((s: any) => ({ ...s, ours: [], gap: { largest: 0, across: 0 } }));
  const scorer = brdBottomScorer(board, brdBottomBlends(sections));
  const b = look.bottom.bottom;
  const base = { nose: b.nose, center: b.center, tail: b.tail };
  const out: any[] = [];
  const show = (label: string, specs: any, secs = 0) => {
    const m = measureBrdBottom({ ...b, ...specs }, sections, board);
    const cut = (c: any) => c.depth > 0 ? `${c.name.split(" ").slice(0, 2).join(" ")} ${(c.depth / IN).toFixed(3)}"${c.edgeRoll ? ` roll ${(c.edgeRoll / IN).toFixed(3)}"` : ""}${c.acrossShape !== undefined ? ` shape ${c.acrossShape.toFixed(2)}` : ""} or ${(c.offRail / IN).toFixed(2)} os ${(c.offStringer / IN).toFixed(2)}` : "Flat";
    out.push({ v: m.closeness.largest + m.closeness.typical, txt: `${label.padEnd(40)} ${secs.toFixed(1)} s shown ${m.closeness.largest.toFixed(2)}/${m.closeness.typical.toFixed(2)} @${(m.closeness.station / IN).toFixed(1)}" | ${cut(specs.nose)} · ${cut(specs.center)} · ${cut(specs.tail)}\n      per section: ${m.sections.filter((s: any) => s.gap.largest > 0.5).map((s: any) => `${(s.station / IN).toFixed(0)}":${s.gap.largest.toFixed(2)}`).join(" ")}` });
  };
  console.log(`\n=== ${name}`);
  show("today", base);
  const names = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
  for (const nm of names) for (const d of [0, 1 / 16, 3 / 16]) for (const roll of [0, 1 / 8, 1 / 4, 3 / 8]) {
    const keep = d === 0;
    if (keep && b.nose.name !== nm) continue;
    const nose = keep ? { ...b.nose } : { ...startingCut("nose", nm, board), depth: d * IN };
    if (roll > 0) nose.edgeRoll = roll * IN; else delete nose.edgeRoll;
    const t0 = performance.now();
    const tails = process.env.TAILS ? [null, ["tail", "Rolled Vee", 1 / 8], ["tail", "Rolled Vee", 1 / 4], ["tail", "Panel Vee", 1 / 8], ["center", "Continuous Belly / Rolled Mid", 1 / 4]] : [null];
    for (const tl of tails as any[]) {
      const start: any = { ...base, nose };
      if (tl) start[tl[0]] = { ...startingCut(tl[0], tl[1], board), depth: tl[2] * IN };
      const r = scorer.polish(start, free);
      show(nm.split(" ")[0] + (keep ? " as fitted" : " from " + d) + " roll from " + roll + (tl ? " + " + tl[1].split(" ")[0] + " " + tl[2] : ""), r.specs, (performance.now() - t0) / 1000);
    }
  }
  out.sort((x, y) => x.v - y.v);
  for (const o of out.slice(0, 6)) console.log(o.txt);
  console.log("   ... today: " + out.find((o) => o.txt.startsWith("today")).txt.split("\n")[0]);
}

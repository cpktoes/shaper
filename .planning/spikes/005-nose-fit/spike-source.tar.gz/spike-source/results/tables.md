
### starts
| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |
|---|---|---|---|---|---|---|---|
| 92Log | 1.58 / 0.44 | 1.23 / 0.40 | 1.65 / 0.44 | 1.50 / 0.51 | Blended Nose Concave 0.063" · Continuous Belly / Rolled Mid 0.500" os 4.91" · Rolled Vee 0.407" | 2.03 s | 3.41 s |
| Scoop-Noserider | 1.18 / 0.36 | 1.04 / 0.43 | 2.70 / 0.78 | 2.99 / 0.68 | Blended Nose Concave 0.361" · Continuous Belly / Rolled Mid 0.310" os 5.84" · Panel Vee 0.119" | 2.32 s | 3.90 s |
| testLB | 2.08 / 0.26 | identical | 5.01 / 0.80 | identical | same | 4.93 s | 4.98 s |
| quadtesting | 6.43 / 0.82 | identical | 55.49 / 2.08 | identical | same | 1.53 s | 1.88 s |
| SAtri | 0.40 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.98 s | 1.84 s |
| SAtwin | 0.39 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.95 s | 1.89 s |
| mid | 0.56 / 0.09 | identical | 1.76 / 0.42 | identical | same | 2.30 s | 2.24 s |
| JFS_BigTwin | 0.70 / 0.32 | identical | 1.42 / 0.35 | identical | same | 0.70 s | 0.79 s |
| 6'10-Widepoint-Fwd-Egg | 0.77 / 0.21 | identical | 1.67 / 0.49 | identical | same | 0.71 s | 0.67 s |
| 6'2-Round-Tail---Double-Concave | 0.55 / 0.17 | identical | 2.08 / 0.42 | identical | same | 3.55 s | 3.49 s |
| 6'4-Double-Wing-Groveler | 0.54 / 0.12 | identical | 1.20 / 0.43 | identical | same | 1.13 s | 1.14 s |
| Fryer-5'7-Squash-Flyer-Twin | 0.49 / 0.21 | identical | 0.93 / 0.30 | identical | same | 3.22 s | 3.09 s |
| Total | | | | | | 26.3 s | 29.3 s |

### roll
| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |
|---|---|---|---|---|---|---|---|
| 92Log | 1.58 / 0.44 | 1.28 / 0.38 | 1.65 / 0.44 | 1.64 / 0.45 | Blended Nose Concave 0.063" roll 0.169" · Continuous Belly / Rolled Mid 0.500" os 4.82" · Rolled Vee 0.419" | 2.03 s | 4.52 s |
| Scoop-Noserider | 1.18 / 0.36 | 1.01 / 0.37 | 2.70 / 0.78 | 2.20 / 0.68 | Blended Nose Concave 0.351" roll 0.301" · Continuous Belly / Rolled Mid 0.307" os 4.26" · Panel Vee 0.063" | 2.32 s | 5.67 s |
| testLB | 2.08 / 0.26 | 1.45 / 0.21 | 5.01 / 0.80 | 4.98 / 0.72 | Blended Nose Concave 0.371" roll 0.113" · Flat Center 0.000" · Flat Exit 0.000" | 4.93 s | 5.75 s |
| quadtesting | 6.43 / 0.82 | identical | 55.49 / 2.08 | identical | same | 1.53 s | 2.21 s |
| SAtri | 0.40 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.98 s | 1.98 s |
| SAtwin | 0.39 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.95 s | 1.96 s |
| mid | 0.56 / 0.09 | identical | 1.76 / 0.42 | identical | same | 2.30 s | 2.35 s |
| JFS_BigTwin | 0.70 / 0.32 | identical | 1.42 / 0.35 | identical | same | 0.70 s | 0.71 s |
| 6'10-Widepoint-Fwd-Egg | 0.77 / 0.21 | identical | 1.67 / 0.49 | identical | same | 0.71 s | 0.70 s |
| 6'2-Round-Tail---Double-Concave | 0.55 / 0.17 | identical | 2.08 / 0.42 | identical | same | 3.55 s | 3.52 s |
| 6'4-Double-Wing-Groveler | 0.54 / 0.12 | identical | 1.20 / 0.43 | identical | same | 1.13 s | 1.11 s |
| Fryer-5'7-Squash-Flyer-Twin | 0.49 / 0.21 | identical | 0.93 / 0.30 | identical | same | 3.22 s | 3.10 s |
| Total | | | | | | 26.3 s | 33.6 s |

### rolltail
| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |
|---|---|---|---|---|---|---|---|
| 92Log | 1.58 / 0.44 | 1.28 / 0.38 | 1.65 / 0.44 | 1.64 / 0.45 | Blended Nose Concave 0.063" roll 0.169" · Continuous Belly / Rolled Mid 0.500" os 4.82" · Rolled Vee 0.419" | 2.03 s | 4.39 s |
| Scoop-Noserider | 1.18 / 0.36 | 1.01 / 0.37 | 2.70 / 0.78 | 2.20 / 0.68 | Blended Nose Concave 0.351" roll 0.301" · Continuous Belly / Rolled Mid 0.307" os 4.26" · Panel Vee 0.063" | 2.32 s | 5.31 s |
| testLB | 2.08 / 0.26 | 1.00 / 0.16 | 5.01 / 0.80 | 4.99 / 0.61 | Blended Nose Concave 0.371" roll 0.128" · Flat Center 0.000" · Rolled Vee 0.250" | 4.93 s | 7.91 s |
| quadtesting | 6.43 / 0.82 | identical | 55.49 / 2.08 | identical | same | 1.53 s | 2.26 s |
| SAtri | 0.40 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.98 s | 1.99 s |
| SAtwin | 0.39 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.95 s | 1.92 s |
| mid | 0.56 / 0.09 | identical | 1.76 / 0.42 | identical | same | 2.30 s | 2.30 s |
| JFS_BigTwin | 0.70 / 0.32 | identical | 1.42 / 0.35 | identical | same | 0.70 s | 0.71 s |
| 6'10-Widepoint-Fwd-Egg | 0.77 / 0.21 | identical | 1.67 / 0.49 | identical | same | 0.71 s | 0.68 s |
| 6'2-Round-Tail---Double-Concave | 0.55 / 0.17 | identical | 2.08 / 0.42 | identical | same | 3.55 s | 3.57 s |
| 6'4-Double-Wing-Groveler | 0.54 / 0.12 | identical | 1.20 / 0.43 | identical | same | 1.13 s | 1.13 s |
| Fryer-5'7-Squash-Flyer-Twin | 0.49 / 0.21 | identical | 0.93 / 0.30 | identical | same | 3.22 s | 3.31 s |
| Total | | | | | | 26.3 s | 35.5 s |

### shape
| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |
|---|---|---|---|---|---|---|---|
| 92Log | 1.58 / 0.44 | 1.24 / 0.35 | 1.65 / 0.44 | 1.52 / 0.51 | Blended Nose Concave 0.064" shape 4.00 · Continuous Belly / Rolled Mid 0.500" os 4.72" · Rolled Vee 0.413" | 2.03 s | 5.21 s |
| Scoop-Noserider | 1.18 / 0.36 | 0.84 / 0.26 | 2.70 / 0.78 | 2.74 / 0.58 | Blended Nose Concave 0.356" shape 1.79 · Continuous Belly / Rolled Mid 0.299" os 4.44" · Panel Vee 0.086" | 2.32 s | 8.46 s |
| testLB | 2.08 / 0.26 | 2.08 / 0.24 | 5.01 / 0.80 | 5.01 / 0.82 | Teardrop Nose Concave 0.355" shape 1.62 · Flat Center 0.000" · Flat Exit 0.000" | 4.93 s | 5.65 s |
| quadtesting | 6.43 / 0.82 | identical | 55.49 / 2.08 | identical | same | 1.53 s | 2.36 s |
| SAtri | 0.40 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.98 s | 1.86 s |
| SAtwin | 0.39 / 0.06 | identical | 2.52 / 0.32 | identical | same | 1.95 s | 1.89 s |
| mid | 0.56 / 0.09 | identical | 1.76 / 0.42 | identical | same | 2.30 s | 2.30 s |
| JFS_BigTwin | 0.70 / 0.32 | identical | 1.42 / 0.35 | identical | same | 0.70 s | 0.71 s |
| 6'10-Widepoint-Fwd-Egg | 0.77 / 0.21 | identical | 1.67 / 0.49 | identical | same | 0.71 s | 0.67 s |
| 6'2-Round-Tail---Double-Concave | 0.55 / 0.17 | identical | 2.08 / 0.42 | identical | same | 3.55 s | 3.40 s |
| 6'4-Double-Wing-Groveler | 0.54 / 0.12 | identical | 1.20 / 0.43 | identical | same | 1.13 s | 1.10 s |
| Fryer-5'7-Squash-Flyer-Twin | 0.49 / 0.21 | identical | 0.93 / 0.30 | identical | same | 3.22 s | 3.17 s |
| Total | | | | | | 26.3 s | 36.8 s |

### rail
| File | Bottom before | Bottom after | Rails before | Rails after | Cuts after | Open before | Open after |
|---|---|---|---|---|---|---|---|
| 92Log | 1.58 / 0.44 | 1.58 / 0.41 | 1.65 / 0.44 | 1.65 / 0.44 | Flat Entry 0.000" · Continuous Belly / Rolled Mid 0.500" os 4.28" · Rolled Vee 0.443" | 2.03 s | 2.44 s |
| Scoop-Noserider | 1.18 / 0.36 | identical | 2.70 / 0.78 | identical | same | 2.32 s | 2.14 s |
| testLB | 2.08 / 0.26 | 1.45 / 0.22 | 5.01 / 0.80 | 5.01 / 0.92 | Teardrop Nose Concave 0.376" · Flat Center 0.000" · Flat Exit 0.000" | 4.93 s | 4.89 s |
| quadtesting | 6.43 / 0.82 | 6.43 / 0.82 | 55.49 / 2.08 | 55.49 / 2.08 | Flat Entry 0.000" · Continuous Belly / Rolled Mid 0.500" · Panel Vee 0.500" | 1.53 s | 1.63 s |
| SAtri | 0.40 / 0.06 | 0.38 / 0.05 | 2.52 / 0.32 | 2.52 / 0.32 | Flat Entry 0.000" · Flat Center 0.000" · Spiral Vee 0.118" os 0.77" | 1.98 s | 2.29 s |
| SAtwin | 0.39 / 0.06 | 0.39 / 0.06 | 2.52 / 0.32 | 2.52 / 0.32 | Flat Entry 0.000" · Flat Center 0.000" · Spiral Vee 0.119" os 0.67" | 1.95 s | 2.24 s |
| mid | 0.56 / 0.09 | 0.56 / 0.09 | 1.76 / 0.42 | 1.76 / 0.42 | Blended Nose Concave 0.500" · Flat Center 0.000" · Panel Vee 0.186" | 2.30 s | 2.88 s |
| JFS_BigTwin | 0.70 / 0.32 | identical | 1.42 / 0.35 | identical | same | 0.70 s | 0.69 s |
| 6'10-Widepoint-Fwd-Egg | 0.77 / 0.21 | identical | 1.67 / 0.49 | identical | same | 0.71 s | 0.66 s |
| 6'2-Round-Tail---Double-Concave | 0.55 / 0.17 | identical | 2.08 / 0.42 | identical | same | 3.55 s | 3.45 s |
| 6'4-Double-Wing-Groveler | 0.54 / 0.12 | identical | 1.20 / 0.43 | identical | same | 1.13 s | 1.11 s |
| Fryer-5'7-Squash-Flyer-Twin | 0.49 / 0.21 | identical | 0.93 / 0.30 | identical | same | 3.22 s | 3.02 s |
| Total | | | | | | 26.3 s | 27.4 s |

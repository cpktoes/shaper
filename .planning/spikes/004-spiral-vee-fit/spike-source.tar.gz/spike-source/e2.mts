// Is today's model the limit? The Spiral Vee alone, then the same shape as a centre double + a tail Panel Vee (which is the
// Spiral Vee with its vee given its own Start / Deepest / End, Smoothness and Off Stringer), freed further.
import { setup, B, optimise, freeFor, report, fitScore, bottomOf } from "./harness.mts";
import { cutWords, IN } from "./common.mts";
for (const name of process.argv.slice(2)) {
  const ctx = setup(name); const bd = ctx.board0;
  console.log(`\n== ${ctx.f}`);
  const sv0 = { nose: B.startingCut("nose", "Flat Entry", bd), center: B.startingCut("center", "Flat Center", bd), tail: B.startingCut("tail", "Spiral Vee", bd) };
  const sv = optimise(ctx, sv0, freeFor(ctx, "tail", sv0.tail)).specs;
  report(ctx, "Spiral Vee alone (today's polish fields)", sv);
  console.log("     T: " + cutWords(sv.tail));
  const r = B.resolveCut("tail", sv.tail, bd);
  const pair = {
    nose: sv.nose,
    center: { ...B.startingCut("center", "Early Double Concave", bd), offRail: sv.tail.offRail, offStringer: sv.tail.offStringer, troughAt: sv.tail.troughAt, start: r.start, deepest: r.deepest, end: r.end, depth: sv.tail.depth, smoothness: sv.tail.smoothness },
    tail: { ...B.startingCut("tail", "Panel Vee", bd), start: sv.tail.start, deepest: sv.tail.deepest, end: sv.tail.end, depth: sv.tail.veeLift, smoothness: 0 },
  };
  // exactness: the pair draws the Spiral Vee
  const ra = B.resolveBottom(bottomOf(sv), bd), rb = B.resolveBottom(bottomOf(pair), bd);
  let worst = 0;
  for (let s = 0; s <= bd.length; s += 25.4) for (let y = 0; y < 250; y += 5) worst = Math.max(worst, Math.abs(B.sectionsFoamOff(ra, bd, s, y) - B.sectionsFoamOff(rb, bd, s, y)));
  console.log(`  the pair (centre double + tail Panel Vee, same numbers) differs from the Spiral Vee by at most ${worst.toExponential(2)} mm anywhere`);
  report(ctx, "same shape as double + Panel Vee", pair);
  const run = (label: string, extra: string[], veeOff = false) => {
    const free = [...freeFor(ctx, "tail", pair.tail, extra), ...freeFor(ctx, "center", pair.center, extra)];
    if (veeOff) free.push({ key: "tail", field: "offStringer", step: 0.25, min: 0, max: 9 });
    const o = optimise(ctx, structuredClone(pair), free);
    report(ctx, label, o.specs, o.value);
    console.log("     C: " + cutWords(o.specs.center) + "\n     T: " + cutWords(o.specs.tail));
  };
  run("(c1) vee with its own Start/Deepest/End", []);
  run("(c2) + its own Smoothness (panel to rolled)", ["smoothness"]);
  run("(c3) + its own Off Stringer (flat panel)", ["smoothness"], true);
}

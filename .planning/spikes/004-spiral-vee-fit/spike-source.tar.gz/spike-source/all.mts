import { FILES, bytesOf, WT, cutWords } from "./common.mts";
import { writeFileSync } from "node:fs";
const { brdLookFromBytes } = await import(WT + "/lib/export/brd-look.ts");
const label = process.argv[2] ?? "run";
const only = process.argv[3];
const rows: any[] = [];
// warm up
brdLookFromBytes(bytesOf(FILES[0]), FILES[0]);
for (const f of FILES) {
  if (only && !f.includes(only)) continue;
  const t0 = performance.now();
  const r = brdLookFromBytes(bytesOf(f), f);
  const secs = (performance.now() - t0) / 1000;
  if (!r.ok) { console.log(f, "NOT OK", r.problem); continue; }
  const b = r.look.bottom!; const ra = r.look.rails;
  const row = { file: f, names: [b.bottom.nose.name, b.bottom.center.name, b.bottom.tail.name], widest: +b.closeness.largest.toFixed(3), typical: +b.closeness.typical.toFixed(3), at: [+(b.closeness.station / 25.4).toFixed(1), +(b.closeness.across / 25.4).toFixed(2)], rails: ra ? [+ra.closeness.largest.toFixed(2), +ra.closeness.typical.toFixed(2)] : null, order: ra?.order, secs: +secs.toFixed(2), cuts: { nose: cutWords(b.bottom.nose), center: cutWords(b.bottom.center), tail: cutWords(b.bottom.tail) } };
  rows.push(row);
  console.log(`${f.padEnd(36)} ${row.widest.toFixed(2)} / ${row.typical.toFixed(2)}  rails ${row.rails?.join(" / ")} ${row.order}  ${row.secs}s  @${row.at}\n    ${row.cuts.nose}\n    ${row.cuts.center}\n    ${row.cuts.tail}`);
}
console.log("total secs", rows.reduce((a, r) => a + r.secs, 0).toFixed(1));
writeFileSync(new URL("../out/" + label + ".json", import.meta.url), JSON.stringify(rows, null, 1));

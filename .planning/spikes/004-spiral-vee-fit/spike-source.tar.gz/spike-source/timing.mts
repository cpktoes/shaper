import { FILES, bytesOf, WT } from "./common.mts";
const { brdLookFromBytes } = await import(WT + "/lib/export/brd-look.ts");
const modes = ["", "spiral", "drop"];
brdLookFromBytes(bytesOf(FILES[0]), FILES[0]);
const best: Record<string, number[]> = {};
for (let rep = 0; rep < 3; rep++) for (const f of FILES) for (const [m, mode] of modes.entries()) {
  if (mode) process.env.SPIKE_B = mode; else delete process.env.SPIKE_B;
  const b = bytesOf(f); const t0 = performance.now(); brdLookFromBytes(b, f); const s = (performance.now() - t0) / 1000;
  (best[f] ??= [9, 9, 9])[m] = Math.min(best[f][m], s);
}
const tot = [0, 0, 0];
console.log("| File | today | (b) Spiral Vee alone | (b') drop any one cut |\n|---|---|---|---|");
for (const f of FILES) { console.log(`| ${f.replace(".brd", "")} | ${best[f].map((v) => v.toFixed(2) + " s").join(" | ")} |`); best[f].forEach((v, i) => (tot[i] += v)); }
console.log(`| Total | ${tot.map((v) => v.toFixed(1) + " s").join(" | ")} |`);

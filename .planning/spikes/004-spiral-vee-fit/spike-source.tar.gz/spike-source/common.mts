import { readFileSync, readdirSync } from "node:fs";
import { homedir } from "node:os";
export const WT = process.env.SPIKE_ROOT ?? "/private/tmp/claude-501/-Users-kontoes-Code-shaper/002e2a58-3c43-4c8e-bbb5-e9c435113dd2/scratchpad/spike004/wt";
export const DL = homedir() + "/Downloads";
export const FILES = readdirSync(DL).filter((f) => f.endsWith(".brd") && !f.includes("_decrypt") && f !== "test-curves-v2.brd").sort();
export const bytesOf = (f: string) => new Uint8Array(readFileSync(DL + "/" + f));
export const IN = 25.4;
export const frac = (mmv: number, den = 64) => { const n = Math.round((mmv / IN) * den); return `${(n / den).toFixed(3)}"`; };
export function cutWords(c: any) {
  if (c.depth <= 0) return c.name;
  return `${c.name} d${frac(c.depth)} st${(c.start / IN).toFixed(2)} dp${(c.deepest / IN).toFixed(2)} en${(c.end / IN).toFixed(2)} oR${frac(c.offRail)} oS${frac(c.offStringer)} tr${frac(c.troughAt)} vl${frac(c.veeLift)} sm${c.smoothness}` + (c.veeEnd !== undefined ? ` veeExtra=${JSON.stringify({ vs: c.veeStart, ve: c.veeEnd, vo: c.veeOffStringer })}` : "");
}

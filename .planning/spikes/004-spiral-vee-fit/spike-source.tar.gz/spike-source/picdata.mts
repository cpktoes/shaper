import { FILES, bytesOf, WT } from "./common.mts";
import { writeFileSync } from "node:fs";
const { brdLookFromBytes } = await import(WT + "/lib/export/brd-look.ts");
const f = FILES.find((x) => x.includes("SAtwin"))!;
const r = brdLookFromBytes(bytesOf(f), f);
const b = r.look.bottom;
writeFileSync(new URL("../out/pic-" + process.argv[2] + ".json", import.meta.url), JSON.stringify({ names: [b.bottom.nose.name, b.bottom.center.name, b.bottom.tail.name], closeness: b.closeness, sections: b.sections.map((s: any) => ({ station: s.station, reach: s.reach, across: s.across, file: s.file, ours: s.ours, gap: s.gap })) }));

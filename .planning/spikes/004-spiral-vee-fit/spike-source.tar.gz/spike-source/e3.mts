import { setup, B, optimise, freeFor, bottomOf } from "./harness.mts";
const ctx = setup("SAtwin"); const bd = ctx.board0;
const sv0 = { nose: B.startingCut("nose", "Flat Entry", bd), center: B.startingCut("center", "Flat Center", bd), tail: B.startingCut("tail", "Spiral Vee", bd) };
for (const sv of [sv0, optimise(ctx, sv0, freeFor(ctx, "tail", sv0.tail)).specs]) {
  const r = B.resolveCut("tail", sv.tail, bd);
  const pair = { nose: sv.nose,
    center: { ...B.startingCut("center", "Early Double Concave", bd), offRail: sv.tail.offRail, offStringer: sv.tail.offStringer, troughAt: sv.tail.troughAt, start: r.start, deepest: r.deepest, end: r.end, depth: sv.tail.depth, smoothness: sv.tail.smoothness },
    tail: { ...B.startingCut("tail", "Panel Vee", bd), start: sv.tail.start, deepest: sv.tail.deepest, end: sv.tail.end, depth: sv.tail.veeLift, smoothness: 0 } };
  const ra = B.resolveBottom(bottomOf(sv), bd), rb = B.resolveBottom(bottomOf(pair), bd);
  let worst = 0, n = 0;
  for (let s = 5; s <= bd.length - 5; s += 12.7) { const W = bd.railAt(s); for (let k = 0; k <= 40; k++) { const y = (W * k) / 40; worst = Math.max(worst, Math.abs(B.sectionsFoamOff(ra, bd, s, y) - B.sectionsFoamOff(rb, bd, s, y))); n++; } }
  console.log(`pair vs Spiral Vee, ${n} points inside the rail: worst difference ${worst.toExponential(2)} mm`);
}

const fs = require("fs");
const S = __dirname + "/../out/";
const a = JSON.parse(fs.readFileSync(S + "pic-today.json")), b = JSON.parse(fs.readFileSync(S + "pic-trial.json"));
const IN = 25.4, W = 560, H = 250, L = 52, R = 16, T = 34, Bm = 34, XMAX = 5.8, YMAX = 6.5;
const sx = (inch) => L + (inch / XMAX) * (W - L - R), sy = (v) => T + (v / YMAX) * (H - T - Bm);
const path = (xs, ys) => xs.map((x, i) => `${i ? "L" : "M"}${sx(x / IN).toFixed(1)},${sy(ys[i]).toFixed(1)}`).join("");
const frac = (v) => { const n = Math.round(v * 2); return n % 2 ? `${Math.floor(n / 2) || ""}${n > 1 ? " " : ""}1/2"` : `${n / 2}"`; };
let panels = "";
for (const i of [0, 1, 2, 3]) {
  const s = a.sections[i], t = b.sections[i];
  let g = "";
  for (let v = 0; v <= 6; v += 2) g += `<line x1="${L}" x2="${W - R}" y1="${sy(v)}" y2="${sy(v)}" class="grid"/><text x="${L - 8}" y="${sy(v) + 4}" class="tick" text-anchor="end">${v}</text>`;
  for (let x = 0; x <= 5; x++) g += `<text x="${sx(x)}" y="${H - Bm + 16}" class="tick" text-anchor="middle">${x}"</text>`;
  const worstJ = s.across.findIndex((y) => Math.abs(y - s.gap.across) < 1e-6);
  const mark = i === 1 ? `<line x1="${sx(s.across[worstJ] / IN)}" x2="${sx(s.across[worstJ] / IN)}" y1="${sy(s.file[worstJ])}" y2="${sy(s.ours[worstJ])}" class="miss"/><text x="${sx(s.across[worstJ] / IN) + 8}" y="${sy((s.file[worstJ] + s.ours[worstJ]) / 2) + 4}" class="note">widest miss today,</text><text x="${sx(s.across[worstJ] / IN) + 8}" y="${sy((s.file[worstJ] + s.ours[worstJ]) / 2) + 19}" class="note">1.61 mm</text>` : "";
  panels += `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
  <text x="12" y="${sy(3)}" class="tick" transform="rotate(-90 12 ${sy(3)})" text-anchor="middle">foam off, mm</text><text x="${L}" y="16" class="ptitle">${frac(s.station / IN)} from the tail</text>
  <text x="${W - R}" y="16" class="psub" text-anchor="end">today ${s.gap.largest.toFixed(2)} mm off · trial ${t.gap.largest.toFixed(2)} mm off</text>
  ${g}
  <line x1="${L}" x2="${W - R}" y1="${sy(0)}" y2="${sy(0)}" class="axis"/>
  <path d="${path(s.across, s.ours)}" class="today"/>
  <path d="${path(t.across, t.ours)}" class="trial"/>
  <path d="${path(s.across, s.file)}" class="file"/>
  ${mark}
  <text x="${L}" y="${H - 2}" class="tick">stringer</text><text x="${W - R}" y="${H - 2}" class="tick" text-anchor="end">toward the rail (read to 9/10 of the way)</text>
</svg>`;
}
const html = `<!doctype html><meta charset="utf-8"><title>SAtwin tail</title><style>
body{margin:0;background:#fcfcfb;color:#0b0b0b;font:14px/1.4 -apple-system,Helvetica,Arial,sans-serif;padding:24px 28px;width:1160px}
h1{font-size:19px;margin:0 0 4px;font-weight:600} p{margin:0 0 12px;color:#52514e;max-width:1050px}
.legend{display:flex;gap:26px;margin:0 0 10px;color:#0b0b0b} .legend span{display:inline-flex;align-items:center;gap:8px}
.grid2{display:grid;grid-template-columns:${W}px ${W}px;gap:14px 24px}
.grid{stroke:#e4e3df;stroke-width:1}.axis{stroke:#8c8b85;stroke-width:1}.tick{font-size:11px;fill:#52514e}.ptitle{font-size:13px;font-weight:600;fill:#0b0b0b}.psub{font-size:11.5px;fill:#52514e}
.file{fill:none;stroke:#0b0b0b;stroke-width:2}.today{fill:none;stroke:#eb6834;stroke-width:2;stroke-dasharray:7 4}.trial{fill:none;stroke:#2a78d6;stroke-width:2}
.miss{stroke:#52514e;stroke-width:1}.note{font-size:11.5px;fill:#0b0b0b}
</style>
<h1>SAtwin.brd: the last 9" of the bottom, half a cross-section at each of the file's tail sections</h1>
<p>Foam taken off below the stringer's level, in millimetres, drawn bottom-up as the board lies on the rack and stretched about 20 times in height. Today the import draws the double concave as a centre cut that stops 6 1/2" from the tail, so the last two sections come out as a plain vee. The trial opens the same file as a Spiral Vee on its own, and the double runs out through the tail as the file's does.</p>
<div class="legend"><span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="#0b0b0b" stroke-width="2"/></svg>the file</span>
<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="#eb6834" stroke-width="2" stroke-dasharray="7 4"/></svg>today's fit: Early Double Concave + Panel Vee (1.61 mm widest)</span>
<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="#2a78d6" stroke-width="2"/></svg>trial: Spiral Vee alone (0.39 mm widest)</span></div>
<div class="grid2">${panels}</div>`;
fs.writeFileSync(S + "pic.html", html);
(async () => {
  const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
  const br = await chromium.launch(); const pg = await br.newPage({ viewport: { width: 1216, height: 700 }, deviceScaleFactor: 2 });
  await pg.goto("file://" + fs.realpathSync(S + "pic.html")); await pg.screenshot({ path: S + "satwin-tail-sections.png", fullPage: true }); await br.close();
})();

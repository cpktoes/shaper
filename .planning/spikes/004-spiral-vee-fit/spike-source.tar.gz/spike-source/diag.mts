import { FILES, bytesOf, WT, cutWords, IN } from "./common.mts";
const { brdLookFromBytes } = await import(WT + "/lib/export/brd-look.ts");
const want = process.argv[2] ?? "SAtwin";
const f = FILES.find((x) => x.includes(want))!;
let n = 0;
(globalThis as any).__spikeFit = (x: any) => {
  n++;
  console.log(`--- fitBottomToBrd call ${n}: seed ${JSON.stringify(x.seedPicks)}`);
  const cuts = (s: any) => ["nose", "center", "tail"].filter((k) => s[k].depth > 0).length;
  for (const p of [...x.pool].sort((a: any, b: any) => a.value - b.value)) {
    console.log(`  ${p.value.toFixed(3)} cuts${cuts(p.specs)} ${p === x.best ? "SEED " : ""}${p === x.chosen ? "CHOSEN " : ""}| ${p.specs.nose.name} | ${p.specs.center.name} | ${p.specs.tail.name}`);
    if (p === x.chosen || p.specs.tail.name === "Spiral Vee") console.log("       C: " + cutWords(p.specs.center) + "\n       T: " + cutWords(p.specs.tail));
  }
};
const r = brdLookFromBytes(bytesOf(f), f);
const b = r.look.bottom;
console.log("length in", (r.look.board.length / IN).toFixed(2), "frontFins?", "sections", r.look.board.sections.length);
for (const s of b.sections) {
  console.log(`station ${(s.station / IN).toFixed(2)}" reach ${(s.reach / IN).toFixed(2)} window ${(s.window / IN).toFixed(2)} reads ${s.reads.kind} ${s.reads.depth.toFixed(2)} flat ${s.flat} gap ${s.gap.largest.toFixed(2)}@${(s.gap.across / IN).toFixed(2)}`);
  console.log("   y  : " + s.across.filter((_: any, j: number) => j % 2 === 0).map((v: number) => (v / IN).toFixed(1).padStart(6)).join(""));
  console.log("   file: " + s.file.filter((_: any, j: number) => j % 2 === 0).map((v: number) => v.toFixed(2).padStart(6)).join(""));
  console.log("   ours: " + s.ours.filter((_: any, j: number) => j % 2 === 0).map((v: number) => v.toFixed(2).padStart(6)).join(""));
}

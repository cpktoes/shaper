// A slow, general optimiser over any set of cut fields, scored the fit's own way (largest + typical gap over read sections + blends).
import { bytesOf, WT, IN, FILES } from "./common.mts";
export const B = await import(WT + "/lib/geometry/bottom.ts");
export const BB = await import(WT + "/lib/geometry/brd-bottom.ts");
const { readAnyBrd } = await import(WT + "/lib/export/brd-read.ts");
const { fitBoardToBrd } = await import(WT + "/lib/geometry/brd-fit.ts");
const { fitBrdFins } = await import(WT + "/lib/geometry/brd-fins.ts");

export function setup(want: string) {
  const f = FILES.find((x) => x.includes(want))!;
  const read = readAnyBrd(bytesOf(f));
  const board = read.board;
  const lines = { length: board.length, outline: board.outline, bottom: board.bottom, deck: board.deck };
  const first = fitBoardToBrd(lines);
  const fins = fitBrdFins(board.fins, board.outline, first.outline)?.spec;
  const board0raw = BB.brdFittedBottomBoard(first, fins);
  const memo = (fn: any) => { const m = new Map(); return (s: number) => { let v = m.get(s); if (v === undefined) { v = fn(s); m.set(s, v); } return v; }; };
  const board0 = { ...board0raw, railAt: memo(board0raw.railAt), curveAt: memo(board0raw.curveAt), narrowestAt: memo(board0raw.narrowestAt), foamAt: memo(board0raw.foamAt), thicknessAt: memo(board0raw.thicknessAt), notchInner: memo(board0raw.notchInner) };
  const sections = BB.brdBottomSections(board.sections, board0.length);
  const targets = BB.brdBottomBlends(sections);
  return { f, board, board0, sections, targets };
}
export type Ctx = ReturnType<typeof setup>;
export function bottomOf(specs: any) { return { ...structuredClone(B.DEFAULT_BOTTOM), nose: specs.nose, center: specs.center, tail: specs.tail }; }
export function fitScore(ctx: Ctx, specs: any): number {
  const r = B.resolveBottom(bottomOf(specs), ctx.board0);
  let largest = 0, sum = 0, n = 0;
  for (const t of ctx.targets) {
    const at0 = B.sectionsFoamOff(r, ctx.board0, t.station, 0);
    for (let j = 0; j < t.across.length; j++) {
      const g = Math.abs(t.target[j] - (B.sectionsFoamOff(r, ctx.board0, t.station, t.across[j]) - at0));
      sum += g; n++; if (g > largest) largest = g;
    }
  }
  return largest + sum / n;
}
export function shown(ctx: Ctx, specs: any) {
  const m = BB.measureBrdBottom(bottomOf(specs), ctx.sections, ctx.board0);
  return m;
}
export interface Free { key: "nose" | "center" | "tail"; field: string; step: number; min: number; max: number } // inches (or smoothness units)
const STATION = new Set(["start", "deepest", "end"]);
export function getX(ctx: Ctx, specs: any, free: Free[]) {
  return free.map(({ key, field }) => STATION.has(field) ? B.resolveCut(key, specs[key], ctx.board0)[field] / IN : field === "smoothness" ? specs[key][field] : (specs[key][field] ?? 0) / IN);
}
export function build(ctx: Ctx, specs: any, free: Free[], x: number[]) {
  const out: any = { nose: { ...specs.nose }, center: { ...specs.center }, tail: { ...specs.tail } };
  const touched = new Set<string>();
  free.forEach(({ key, field, min, max }, i) => {
    const v = Math.min(max, Math.max(min, x[i]));
    touched.add(key);
    if (STATION.has(field)) Object.assign(out[key], B.storeCutStation(key, field, v * IN, ctx.board0));
    else if (field === "smoothness") out[key][field] = v;
    else out[key][field] = v * IN;
  });
  for (const key of touched) out[key] = B.keepStationsInOrder(key, out[key], "deepest", ctx.board0, "narrowest");
  return out;
}
export function optimise(ctx: Ctx, specs: any, free: Free[], restarts = 3) {
  const score = (x: number[]) => fitScore(ctx, build(ctx, specs, free, x));
  let x = getX(ctx, specs, free); let best = score(x);
  const step0 = free.map((f) => f.step); let step = [...step0];
  for (let round = 0; round < 40; round++) {
    let improved = false;
    for (let i = 0; i < x.length; i++) for (const dir of [1, -1]) for (let run = 0; run < 20; run++) {
      const y = [...x]; y[i] += dir * step[i]; const v = score(y); if (!(v < best - 1e-9)) break; best = v; x = y; improved = true;
    }
    for (let i = 0; i + 1 < x.length; i++) for (const a of [1, -1]) for (const b of [1, -1]) {
      const y = [...x]; y[i] += a * step[i]; y[i + 1] += b * step[i + 1]; const v = score(y); if (v < best - 1e-9) { best = v; x = y; improved = true; }
    }
    if (!improved) { step = step.map((q) => q / 2); if (step.every((q, i) => q < step0[i] / 1000)) break; }
  }
  const n = x.length;
  for (let restart = 0; restart < restarts; restart++) {
    let simplex = [x, ...x.map((_, i) => x.map((v, j) => (j === i ? v + step0[i] * 0.5 ** restart : v)))];
    let vals = simplex.map(score);
    for (let it = 0; it < 400 * n; it++) {
      const order = vals.map((_, i) => i).sort((a, b) => vals[a] - vals[b]);
      simplex = order.map((i) => simplex[i]); vals = order.map((i) => vals[i]);
      if (vals[n] - vals[0] < 1e-7) break;
      const c = new Array(n).fill(0); for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) c[j] += simplex[i][j] / n;
      const along = (a: number) => c.map((cv: number, j: number) => cv + a * (simplex[n][j] - cv));
      const r = along(-1), rv = score(r);
      if (rv < vals[0]) { const e = along(-2), ev = score(e); if (ev < rv) { simplex[n] = e; vals[n] = ev; } else { simplex[n] = r; vals[n] = rv; } }
      else if (rv < vals[n - 1]) { simplex[n] = r; vals[n] = rv; }
      else { const k = along(0.5), kv = score(k); if (kv < vals[n]) { simplex[n] = k; vals[n] = kv; } else for (let i = 1; i <= n; i++) { simplex[i] = simplex[i].map((v: number, j: number) => simplex[0][j] + 0.5 * (v - simplex[0][j])); vals[i] = score(simplex[i]); } }
    }
    if (vals[0] < best) { best = vals[0]; x = simplex[0]; }
  }
  return { specs: build(ctx, specs, free, x), value: best };
}
export const R = B.BOTTOM_MARK_RANGES_IN;
export function freeFor(ctx: Ctx, key: any, spec: any, extra: string[] = []): Free[] {
  const kind = B.cutKind(spec.name); if (kind === "flat") return [];
  const L = ctx.board0.length / IN;
  const out: Free[] = ["start", "deepest", "end"].map((field) => ({ key, field, step: 1, min: 0, max: L }));
  out.push({ key, field: "depth", step: 1 / 32, min: 1 / 16, max: 0.5 });
  const marks = kind === "double" ? ["troughAt", "offRail", "offStringer"] : kind === "single" ? ["offRail"] : kind === "belly" || spec.name === "Tri-Plane Hull Center" ? ["offStringer"] : [];
  for (const m of marks) out.push({ key, field: m, step: 0.25, min: (R as any)[m].min, max: (R as any)[m].max });
  for (const e of extra) {
    if (e === "veeLift") { if (spec.name === "Spiral Vee") out.push({ key, field: e, step: 1 / 32, min: 0, max: 0.5 }); }
    else if (e === "smoothness") out.push({ key, field: e, step: 10, min: 0, max: 100 });
    else if (e === "troughStart" || e === "troughEnd") { if (kind === "double") out.push({ key, field: e, step: 0.25, min: 0.5, max: 8 }); }
  }
  return out;
}
export function report(ctx: Ctx, label: string, specs: any, value?: number) {
  const m = shown(ctx, specs);
  console.log(`${label.padEnd(50)} fit-score ${(value ?? fitScore(ctx, specs)).toFixed(3)}  shown ${m.closeness.largest.toFixed(2)} / ${m.closeness.typical.toFixed(2)} @ st ${(m.closeness.station / IN).toFixed(1)}" y ${(m.closeness.across / IN).toFixed(2)}"`);
  return m;
}

import { readFileSync } from "node:fs";
const dir = new URL("../out/", import.meta.url);
const [a, ...rest] = process.argv.slice(2);
const A = JSON.parse(readFileSync(new URL(a + ".json", dir), "utf8"));
const short = (n: string[]) => n.map((x) => x.replace(/ (Entry|Center|Exit)$/, "").replace("Concave", "Conc.")).join(" · ");
for (const b of rest) {
  const Bv = JSON.parse(readFileSync(new URL(b + ".json", dir), "utf8"));
  console.log(`\n### ${a} -> ${b}\n| File | Bottom before | Bottom after | Rails before | Rails after | Names after (changed only) | Open before | Open after |\n|---|---|---|---|---|---|---|---|`);
  let ta = 0, tb = 0;
  for (const ra of A) {
    const rb = Bv.find((x: any) => x.file === ra.file); ta += ra.secs; tb += rb.secs;
    const changed = ra.names.join() !== rb.names.join();
    const mark = rb.widest > ra.widest + 0.005 ? " WORSE" : rb.widest < ra.widest - 0.005 ? " better" : "";
    console.log(`| ${ra.file.replace(".brd", "")} | ${ra.widest.toFixed(2)} / ${ra.typical.toFixed(2)} | ${rb.widest.toFixed(2)} / ${rb.typical.toFixed(2)}${mark} | ${ra.rails.map((v: number) => v.toFixed(2)).join(" / ")} | ${rb.rails.map((v: number) => v.toFixed(2)).join(" / ")} | ${changed ? short(rb.names) : "same"}${ra.order !== rb.order ? " ORDER " + rb.order : ""} | ${ra.secs.toFixed(2)} s | ${rb.secs.toFixed(2)} s |`);
  }
  console.log(`| Total | | | | | | ${ta.toFixed(1)} s | ${tb.toFixed(1)} s |`);
}

Spike 009 (rail-from-concave-mark): scripts, the trial code and raw outputs (2026-11-26). The founder's .brd files are not in here.

trial-code.diff   against main dff59dc0 (lib/geometry/bottom.ts, design.ts, volume.ts, lib/export/brd-fit-preview.ts). With no S9_
                  switch set it is today's code exactly (74 Longboards, 222 other boards and the twelve files identical). Switches:
                  S9_RULE=a|a2|af|b|ab|c (S9_FRAC for c, default 0.5), S9_IMPORT=1|2. It also exports bottomOn, liftedStep and
                  settleLook from brd-fit-preview.ts for the probes, and logs both import orders into globalThis.__s9 when set.
scripts/          spike 008's scripts reused unchanged (board.mts, grid.mts, run-grid.sh, run-trials.sh, run-twelve.sh, measure.mts,
                  analyze.mjs, same.mjs, table.mjs, lbroll.mjs, probe*.mts ...) plus spike 009's: rules.mts (tucks, rail start, litres,
                  .brd digest per rule), litres.mts (340-board identity and litres check), picdata9.mts + picture9.cjs (the PNG),
                  oracle2.mts (is the written roll findable), signal.mts (the roll's trace in the file), railspage.mts (RAILS' nose
                  card), anchors.mts (how far each concave's pull reaches), steps.mts (the import's two orders), opened.mts (the
                  three rolled files' litres), time9.mts (paired open times).
out/              lb-<rule>.*.jsonl (74 Longboards per rule), oth-a.*.jsonl (222 other boards, rule A), s8-* (spike 008 / quick v2f
                  baselines, copied), t12-<rule>.json (twelve files: names, figures, digests), litres.json, pic9.json, pic-a.png,
                  pic-c.png, times-*.json/log, trials-*.log, twelve-1.log.
results/          rules-longboard.txt, litres.txt, oracle2-<rule>.txt, oracle9-partial.txt (first oracle, stopped: it kept the
                  opened board's stray centre belly), signal.txt, railspage.txt, anchors.txt, opened.txt, times-*.log.

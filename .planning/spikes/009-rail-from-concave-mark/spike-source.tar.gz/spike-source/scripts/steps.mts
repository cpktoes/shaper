// Spike 009: the import's two orders on one board under each rule — bottom first and rails first, their whole-section value
// and their cuts (logged by the trial code into globalThis.__s9), and what opens.
//   ROOT=<wt> RULES=",c" CASES="..." [S9_IMPORT=1] npx --no-install tsx --tsconfig ./tsconfig.json steps.mts
import { build, parseId, imp, IN } from "./board.mts";
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
for (const rule of (process.env.RULES ?? ",c").split(",")) for (const id of (process.env.CASES ?? "").split(";")) {
  process.env.S9_RULE = rule;
  (globalThis as any).__s9 = [];
  const r = brdLookFromBytes(build(parseId(id)).bytes, "x.brd");
  const b = r.look.bottom;
  console.log(`== ${rule || "today"} ${id}: opens ${[b.bottom.nose, b.bottom.center, b.bottom.tail].map((c: any) => `${c.name} ${(c.depth / IN * 64).toFixed(1)}${c.railRoll ? " r" + (c.railRoll / IN * 64).toFixed(1) : ""}`).join(" · ")} ${r.look.rails.order}`);
  for (const s of (globalThis as any).__s9) console.log(`   ${s.step}: whole ${s.whole.toFixed(3)} (widest ${s.largest.toFixed(2)})  ${s.cuts}`);
}

// Spike 009, the oracle: can the finished board tell the written roll at all, under each rule? The WRITTEN bottom (all three
// cuts exactly as written) put on the board the file's outline, rocker and foil fit makes, the nose's Rail Roll swept 0..1/2",
// and the rails fitted to the file each time two ways: afresh, and by descent from the rails fitted with the written roll.
// Judged over the front half's sections: the whole section (bottom and rail together, the import's own brdRailWholeGap), and
// the underside alone. A roll the file carries shows as a clear low point at the written roll; a flat line means the rails
// take the roll up.
//   ROOT=<wt> RULES=",a,b" CASES="..." npx --no-install tsx --tsconfig ./tsconfig.json oracle2.mts
import { build, parseId, imp, IN } from "./board.mts";
const { readAnyBrd } = await imp("lib/export/brd-read.ts");
const P = await imp("lib/export/brd-fit-preview.ts");
const R = await imp("lib/geometry/brd-rails.ts");
const B = await imp("lib/geometry/brd-bottom.ts");
const { fitBoardToBrd } = await imp("lib/geometry/brd-fit.ts");
const { mm } = await imp("lib/geometry/units.ts");
const under = (pts: [number, number][]) => { let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k; return pts.slice(0, apex + 1); };
const hAt = (p: [number, number][], x: number) => { for (let k = 0; k + 1 < p.length; k++) { const [x0, y0] = p[k], [x1, y1] = p[k + 1]; if (x >= x0 && x <= x1) return x1 === x0 ? y0 : y0 + ((y1 - y0) * (x - x0)) / (x1 - x0); } return NaN; };
function undersideGap(file: [number, number][], ours: [number, number][]) {
  const uf = under(file), uo = under(ours);
  const reach = Math.min(uf[uf.length - 1][0], uo[uo.length - 1][0]);
  let lg = 0, s = 0, n = 0;
  for (let j = 0; j <= 60; j++) { const x = (reach * 0.995 * j) / 60; const d = Math.abs(hAt(uf, x) - hAt(uo, x)); if (Number.isFinite(d)) { lg = Math.max(lg, d); s += d; n++; } }
  return { largest: lg, mean: s / n };
}
const ROLLS = (process.env.ROLLS ?? "0,1,2,3,4,6,8").split(",").map(Number);
for (const rule of (process.env.RULES ?? ",a,b").split(",")) for (const id of (process.env.CASES ?? "").split(";")) {
  process.env.S9_RULE = rule;
  const spec = parseId(id);
  const w = build(spec);
  const board = readAnyBrd(w.bytes).board;
  const L = board.length;
  const lines = { length: board.length, outline: board.outline, bottom: board.bottom, deck: board.deck };
  const first = fitBoardToBrd(lines);
  const fins = undefined;
  const board0 = B.brdFittedBottomBoard(first, fins);
  const found = P.bottomOn(board, lines, first, fins);
  const { lines: railLines } = P.brdRailLines(board);
  const nose = railLines.filter((l: any) => l.station >= L / 2);
  const at = (r: number) => {
    const bottom = { ...w.bottom, nose: { ...w.bottom.nose, railRoll: r ? mm((r / 16) * IN) : undefined } };
    const step = P.liftedStep(board, lines, first, fins, board0, bottom, found.bottom.sections);
    return R.brdRailBoard(step.fit, step.bottom.bottom, fins);
  };
  const judge = (onBoard: any, settings: any) => {
    const rails = R.brdRailsSpec(settings, onBoard.foil, null);
    const halves = R.brdOurRailHalves(onBoard, rails, nose.map((l: any) => l.station));
    let wl = 0, wm = 0, ul = 0, um = 0;
    nose.forEach((l: any, i: number) => { const g = R.brdRailWholeGap(l.points, halves[i]); wl = Math.max(wl, g.largest); wm += g.mean; const u = undersideGap(l.points, halves[i]); ul = Math.max(ul, u.largest); um += u.mean; });
    return { whole: wm / nose.length, wholeMax: wl, under: um / nose.length, underMax: ul };
  };
  const written = spec.nose![2];
  const s0 = R.fitBrdRails(railLines, at(written));
  console.log(`\n=== rule ${rule || "today"}: ${id} (written roll ${written}/16)`);
  for (const r of ROLLS) {
    const ob = at(r);
    const fresh = judge(ob, R.fitBrdRails(railLines, ob));
    const desc = judge(ob, R.fitBrdRails(railLines, ob, s0));
    console.log(`  roll ${r}/16${r === written ? " (written)" : ""}: whole afresh ${fresh.whole.toFixed(3)} (widest ${fresh.wholeMax.toFixed(2)}), descent ${desc.whole.toFixed(3)}; underside afresh ${fresh.under.toFixed(3)}, descent ${desc.under.toFixed(3)}`);
  }
}

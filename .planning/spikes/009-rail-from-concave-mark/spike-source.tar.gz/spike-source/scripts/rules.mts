// Spike 009: one app board built under each trial rule (S9_RULE set in-process before each build): litres, a digest of the
// .brd bytes, and at a few stations from the nose the rail's bottom band start (Bottom Tuck 3, in from the rail) against the
// concave's mark (in from the rail).
//   ROOT=<wt> CASES="longboard|Blended Nose Concave|d3|r4;..." RULES=",a,a2,b,ab" npx --no-install tsx --tsconfig ./tsconfig.json rules.mts
import { createHash } from "node:crypto";
import { build, imp, parseId, IN } from "./board.mts";
const { computeCrossSectionVolume, boardSections } = await imp("lib/geometry/volume.ts");
const { s9RailStartLimiter } = await imp("lib/geometry/bottom.ts");
const { sectionFinishedRail } = await imp("lib/geometry/finished-rail.ts");
/** Where the finished rail (blends and all, on the planed bottom) leaves the bottom, in from the rail's edge. */
const leaves = (result: any, domed: boolean) => { const smp = sectionFinishedRail(result, domed).samples; let m = 0; for (const p of smp) if (p.y <= 1e-6 && p.x < m) m = p.x; let best = m; for (const p of smp) if (p.y <= 1e-6 && p.x > best && p.x < 0) { /* first flat point walking in */ } return smp; };
const startIn = (result: any, domed: boolean) => { const smp = sectionFinishedRail(result, domed).samples as any[]; let x = -Infinity; for (const p of smp) if (Math.abs(p.y) <= 1e-6 && p.x < -1e-6) x = Math.max(x, p.x); return -x; };
const CASES = (process.env.CASES ?? "longboard|Blended Nose Concave|d3|r4").split(";");
const RULES = (process.env.RULES ?? ",a,a2,b,ab").split(",");
const FROM = (process.env.FROM ?? "2,8,16,24,32").split(",").map(Number);
for (const id of CASES) {
  console.log(`\n== ${id}`);
  for (const rule of RULES) {
    process.env.S9_RULE = rule;
    const w = build(parseId(id));
    const L = w.fields.outline.length;
    const litres = computeCrossSectionVolume(w.input).volumeLitres;
    const digest = createHash("sha1").update(w.bytes).digest("hex").slice(0, 12);
    const lim = s9RailStartLimiter(w.resolved, w.board);
    const st = FROM.map((d) => L - d * IN);
    const secs = boardSections(w.input, st);
    const cells = secs.map((s: any, i: number) => {
      const l = lim ? lim(st[i]) : null;
      const t3 = s.result ? s.result.bottomTuck3 / IN : NaN;
      const st0 = s.result ? startIn(s.result, s.domed) / IN : NaN;
      return `${FROM[i]}": W ${(s.halfWidth / IN).toFixed(2)} BT3 ${t3.toFixed(2)} leaves ${st0.toFixed(2)}${l ? ` mark ${(l.inFromRail / IN).toFixed(2)} share ${l.share.toFixed(2)}` : ""}`;
    });
    console.log(`${(rule || "today").padEnd(5)} ${(+litres).toFixed(3)} L  brd ${digest}  ${cells.join(" | ")}`);
  }
}

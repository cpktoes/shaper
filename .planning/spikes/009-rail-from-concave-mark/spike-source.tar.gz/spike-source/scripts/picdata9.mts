// Spike 009: the picture's data — the BOARD itself, not the import. For each case and each rule (S9_RULE set in-process),
// the finished half section the app draws (the litres', 3D board's and .brd file's ring: `boardSections` at the station,
// bottom and rail together) at about 2", 8" and 16" back from the nose tip, plus the same board with no roll; the concave's
// mark (in from the rail), and where each finished rail leaves the bottom.
//   ROOT=<wt> CASES="a;b" RULES=",a" npx --no-install tsx --tsconfig ./tsconfig.json picdata9.mts <out.json>
import { writeFileSync } from "node:fs";
import { build, parseId, imp, IN } from "./board.mts";
const { boardSections, computeCrossSectionVolume } = await imp("lib/geometry/volume.ts");
const { ghostRail } = await imp("lib/geometry/bottom-draw.ts");
const { sectionFinishedRail } = await imp("lib/geometry/finished-rail.ts");
const startIn = (s: any) => { if (!s.result) return NaN; let x = -Infinity; for (const p of sectionFinishedRail(s.result, s.domed).samples as any[]) if (Math.abs(p.y) <= 1e-6 && p.x < -1e-6) x = Math.max(x, p.x); return -x; };
const RULES = (process.env.RULES ?? ",a").split(",");
const FROM = (process.env.FROM ?? "2,8,16").split(",").map(Number);
const out: any[] = [];
for (const id of (process.env.CASES ?? "").split(";")) {
  const spec = parseId(id);
  const row: any = { id, rules: {} };
  const ring = (w: any, d: number) => { const st = w.fields.outline.length - d * IN; const secs = boardSections(w.input, [st]); const s = secs[0]; return { half: ghostRail(secs, st), W: s.halfWidth, leaves: startIn(s), bt3: s.result?.bottomTuck3 ?? NaN }; };
  process.env.S9_RULE = "";
  const w0 = build({ ...spec, nose: spec.nose ? [spec.nose[0], spec.nose[1], 0] : undefined });
  row.noRoll = { litres: +computeCrossSectionVolume(w0.input).volumeLitres, secs: FROM.map((d) => ring(w0, d)) };
  for (const rule of RULES) {
    process.env.S9_RULE = rule;
    const w = build(spec);
    row.rules[rule || "today"] = {
      litres: +computeCrossSectionVolume(w.input).volumeLitres,
      secs: FROM.map((d) => { const r = ring(w, d); const st = w.fields.outline.length - d * IN; return { ...r, fromNose: d, mark: w.board.railAt(st) - Math.max(0, w.board.railAt(st) - (w.resolved.nose.offRail ?? 0)) }; }),
    };
  }
  out.push(row);
  console.log(id, Object.entries(row.rules).map(([k, v]: any) => `${k} ${v.litres.toFixed(2)} L`).join(", "), `no roll ${row.noRoll.litres.toFixed(2)} L`);
}
process.env.S9_RULE = "";
writeFileSync(process.argv[2], JSON.stringify(out));

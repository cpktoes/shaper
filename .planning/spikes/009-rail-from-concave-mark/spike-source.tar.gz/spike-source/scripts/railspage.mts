// Spike 009: what RAILS' nose card (12" back from the tip) reads today and would read under the pulled rail (rule a / af):
// Bottom Tuck 1, 2, 3 on the rail RAILS bands (railsOnTheBottom: the roll already thins it), and the pull's share there.
//   ROOT=<wt> npx --no-install tsx --tsconfig ./tsconfig.json railspage.mts
import { build, parseId, imp, IN } from "./board.mts";
const { railsOnTheBottom, bottomRailLift, railAnchorStations } = await imp("lib/geometry/design.ts");
const { computeRailBands } = await imp("lib/geometry/rail-bands.ts");
const { s9RailStartLimiter } = await imp("lib/geometry/bottom.ts");
const { s9PulledToMark } = await imp("lib/geometry/volume.ts");
const f = (v: number) => (v / IN).toFixed(2) + '"';
for (const id of (process.env.CASES ?? "longboard|Blended Nose Concave|d3|r4;longboard|Teardrop Nose Concave|d3|r4;longboard|Slight Single Concave Entry|d2|r2;longboard|Blended Nose Concave|d1|r1;shortboard|Blended Nose Concave|d3|r4;midlength|Blended Nose Concave|d3|r4;fish|Blended Nose Concave|d3|r4").split(";")) {
  process.env.S9_RULE = "";
  const w = build(parseId(id));
  const anchors = railAnchorStations(w.profile.effectiveFoil, w.fields.outline.length);
  const onB = railsOnTheBottom(w.rails, bottomRailLift(w.resolved, w.board), anchors);
  const bands = computeRailBands(onB);
  const r = bands.nose.result;
  const lim = s9RailStartLimiter(w.resolved, w.board)?.(anchors.nose) ?? null;
  const a = s9PulledToMark(r, lim, "all");
  const af = s9PulledToMark(r, lim, "finished", false);
  console.log(`${id.padEnd(44)} nose card at ${f(w.fields.outline.length - anchors.nose)} from tip, Sym ${w.rails.nose.symmetrical}: BT1/2/3 today ${f(r.bottomTuck1)} ${f(r.bottomTuck2)} ${f(r.bottomTuck3)}; mark ${lim ? f(lim.inFromRail) : "-"} share ${lim?.share.toFixed(2) ?? "-"}; rule a ${f(a.bottomTuck1)} ${f(a.bottomTuck2)} ${f(a.bottomTuck3)}; rule af ${f(af.bottomTuck1)} ${f(af.bottomTuck2)} ${f(af.bottomTuck3)}`);
}

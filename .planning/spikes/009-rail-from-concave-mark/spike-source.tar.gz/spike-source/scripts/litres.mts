// Spike 009: every grid board (the 296 of spike 007/008's grid, plus each preset plain) built under each rule (S9_RULE set
// in-process): litres, and digests of the .brd bytes and of the drawn surface (every ring of buildBoardSurface). Writes
// ../out/litres.json and prints, per rule, how many boards differ from today and the litres change on the rolled ones.
//   ROOT=<wt> RULES="a,af,a2,b,ab" npx --no-install tsx --tsconfig ./tsconfig.json litres.mts
import { createHash } from "node:crypto";
import { writeFileSync } from "node:fs";
import { build, imp } from "./board.mts";
const { computeCrossSectionVolume, boardSections } = await imp("lib/geometry/volume.ts");
const RULES = ["", ...(process.env.RULES ?? "a,af,a2,b,ab").split(",")];
const BOARDS = ["shortboard", "midlength", "fish", "longboard"];
const NOSES = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const cases: any[] = [];
for (const board of BOARDS) {
  cases.push({ id: `${board}|none`, kind: "plain", board });
  for (const name of NOSES) for (const d of [1, 2, 3, 4]) for (const r of [0, 1, 2, 3, 4]) cases.push({ id: `${board}|${name}|d${d}|r${r}`, kind: r ? "roll" : "noroll", board, nose: [name, d, r] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|RBE|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|CB|d${d}`, kind: "belly", board, center: ["Continuous Belly / Rolled Mid", d] });
  for (const d of [2, 4]) cases.push({ id: `${board}|RBE+CB|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|RVN|d2`, kind: "belly", board, nose: ["Reverse Vee Nose", 2, 0] });
  for (const d of [2, 4]) cases.push({ id: `${board}|BNC2+CB|d${d}`, kind: "belly", board, nose: ["Blended Nose Concave", 2, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|TPH|d4`, kind: "belly", board, center: ["Tri-Plane Hull Center", 4] });
}
const h = (x: any) => createHash("sha1").update(typeof x === "string" ? x : JSON.stringify(x)).digest("hex").slice(0, 12);
const rows: any[] = [];
for (const c of cases) {
  const row: any = { id: c.id, kind: c.kind, board: c.board, rules: {} };
  for (const rule of RULES) {
    process.env.S9_RULE = rule;
    const w = build(c);
    const vol = computeCrossSectionVolume(w.input);
    const rings = boardSections(w.input).map((s: any) => s.drawn ?? s.blended ?? null);
    row.rules[rule || "today"] = { litres: +vol.volumeLitres, brd: h(Buffer.from(w.bytes).toString("latin1")), surface: h({ rings, areas: vol.stationAreas }) };
  }
  rows.push(row);
}
process.env.S9_RULE = "";
writeFileSync(new URL("../out/litres.json", import.meta.url), JSON.stringify(rows));
for (const rule of RULES.slice(1)) {
  const diff = (r: any) => r.rules[rule].brd !== r.rules.today.brd || r.rules[rule].surface !== r.rules.today.surface || r.rules[rule].litres !== r.rules.today.litres;
  const lines = [`== rule ${rule}`];
  for (const kind of ["plain", "noroll", "belly", "roll"]) for (const b of BOARDS) {
    const R = rows.filter((r) => r.kind === kind && r.board === b);
    const n = R.filter(diff).length;
    const dl = R.map((r) => r.rules[rule].litres - r.rules.today.litres);
    lines.push(`  ${kind.padEnd(6)} ${b.padEnd(10)} ${n} of ${R.length} differ${kind === "roll" ? `; litres change ${Math.min(...dl).toFixed(3)} to ${Math.max(...dl).toFixed(3)} L (mean ${(dl.reduce((a, x) => a + x, 0) / dl.length).toFixed(3)})` : ""}`);
  }
  console.log(lines.join("\n"));
}

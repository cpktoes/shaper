// Spike 009: rail-from-concave-mark.png. node picture9.cjs <picdata9.json> <rule key> <rule label> <out.png>
// Rows: one Longboard each; columns: 2", 8" and 16" back from the nose tip. Each panel is the outer part of the finished half
// section the app draws (the ring the litres, the 3D board and the .brd file carry), bottom and rail together: today (blue,
// dashed), the trial rule (orange), and the same board with no Rail Roll (grey, dotted; the same under both rules). Ticks: the
// concave's edge (Off Rail, black) and where each rail leaves the bottom (blue today, orange the rule).
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [dataFile, key, label, outFile] = process.argv.slice(2);
const D = JSON.parse(fs.readFileSync(dataFile));
const INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", NOROLL = "#9a9892", TODAY = "#2a78d6", TRIAL = "#eb6834";
const IN = 25.4;
const frac = (inch) => { const n = Math.round(inch * 64); if (!n) return "0"; let a = n, b = 64; while (a % 2 === 0 && b > 1) { a /= 2; b /= 2; } return `${a}/${b}"`; };
const lowerHalf = (pts) => { let apex = 0; for (let k = 1; k < pts.length; k++) if (pts[k][0] > pts[apex][0]) apex = k; return pts.slice(apex); };
function panel(t, r, n, W, H) {
  const reach = t.W;
  const x0 = Math.max(0, reach - 6 * IN);
  const clip = (pts) => lowerHalf(pts).filter((p) => p[0] >= x0 - 2);
  const all = [...clip(t.half), ...clip(r.half), ...clip(n.half)];
  const hi = Math.min(Math.max(...all.map((p) => p[1])), 30) + 1, lo = -1;
  const L = 40, R = 12, T = 26, Bm = 30;
  const sx = (W - L - R) / (reach + 0.15 * IN - x0), sy = (H - T - Bm) / (hi - lo);
  const x = (v) => L + (v - x0) * sx, y = (v) => T + (hi - v) * sy;
  const path = (pts) => clip(pts).filter((p) => p[1] <= hi).map((p, j) => `${j ? "L" : "M"}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join("");
  let g = "";
  for (let v = 0; v <= hi; v += 5) g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="${GRID}"/><text x="${L - 4}" y="${y(v) + 4}" text-anchor="end" class="t">${v}</text>`;
  for (let i = 0; i <= 6; i++) { const v = reach - i * IN; if (v >= x0) g += `<text x="${x(v)}" y="${H - Bm + 14}" text-anchor="middle" class="t">${i ? i + '"' : "rail"}</text>`; }
  const mark = (v, c, lab, dy, dash) => (v > x0 ? `<line x1="${x(v)}" x2="${x(v)}" y1="${T + 2}" y2="${H - Bm}" stroke="${c}" stroke-dasharray="${dash}"/><text x="${x(v) - 3}" y="${T + dy}" text-anchor="end" class="t" fill="${c}">${lab}</text>` : "");
  return `<svg width="${W}" height="${H}"><text x="${L}" y="14" class="h">${t.fromNose}" back from the nose tip</text>${g}
  ${mark(reach - r.mark, INK, "mark", 10, "2 3")}
  ${mark(reach - t.leaves, TODAY, "today", 22, "5 3")}
  ${mark(reach - r.leaves, TRIAL, label, 34, "5 3")}
  <path d="${path(n.half)}" fill="none" stroke="${NOROLL}" stroke-width="1.6" stroke-dasharray="1.5 3"/>
  <path d="${path(t.half)}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(r.half)}" fill="none" stroke="${TRIAL}" stroke-width="2"/></svg>`;
}
const W = 340, H = 240;
let rows = "";
for (const c of D) {
  const [board, name, d, rr] = c.id.split("|");
  const t = c.rules.today, r = c.rules[key];
  rows += `<div class="row"><div class="cap"><b>Longboard, ${name} ${frac(+d.slice(1) / 16)} with a ${frac(+rr.slice(1) / 16)} Rail Roll</b>
  &nbsp; litres: no roll ${c.noRoll.litres.toFixed(2)} L · <span style="color:${TODAY}">today ${t.litres.toFixed(2)} L</span> · <span style="color:${TRIAL}">${label} ${r.litres.toFixed(2)} L</span></div>
  ${t.secs.map((s, i) => panel(s, r.secs[i], c.noRoll.secs[i], W, H)).join("")}</div>`;
}
const html = `<html><head><style>body{font:13px -apple-system,Helvetica,sans-serif;color:${INK};margin:16px;background:#fff}.t{font-size:10px;fill:${SUB}}.h{font-size:12px;font-weight:600;fill:${INK}}.row{margin-bottom:14px}.cap{margin:4px 0 2px 40px;line-height:1.45}</style></head><body>
<div style="font-size:15px;font-weight:600;margin-left:40px">The Longboard's nose rail as the app draws it: today, and with the rail started from the concave's mark (${label})</div>
<div style="margin:4px 0 10px 40px;color:${SUB}">The outer 6" of the half section, bottom and rail, board upright (deck up). Blue dashed: today. Orange: ${label}. Grey dotted: the same board with no Rail Roll (today's rail, under either rule).<br>Upright lines: the concave's edge, its Off Rail "mark" (black dotted), and where each finished rail leaves the bottom (blue today, orange ${label}).<br>Heights in mm above the planed bottom; across in inches in from the rail's edge.</div>${rows}</body></html>`;
(async () => { const br = await chromium.launch(); const p = await br.newPage({ viewport: { width: 40 + 3 * W + 40, height: 400 } }); await p.setContent(html); await p.screenshot({ path: outFile, fullPage: true }); await br.close(); console.log("wrote", outFile); })();

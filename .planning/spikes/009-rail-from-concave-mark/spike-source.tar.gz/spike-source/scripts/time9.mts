// Spike 009 (from spike 008's time8): paired open times, today against rule A. One process; each board opened under each trial's switches in turn (the trial code reads
// process.env on every call), fastest of REPS, so every trial is timed back to back with today on the same machine load.
// Boards are the app's own (ids as grid.mts) and, with FILES=1, the founder's twelve (read in place, never copied).
//   ROOT=<wt> REPS=3 [FILES=1] npx --no-install tsx --tsconfig ./tsconfig.json time8.mts <out.json> "id;id;..."
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { execSync } from "node:child_process";
import { build, parseId, imp } from "./board.mts";
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const MODES: Record<string, Record<string, string>> = { today: {}, A: { S9_RULE: "a" } };
const KEYS = ["S9_RULE", "S9_IMPORT"];
const reps = Number(process.env.REPS ?? 3);
const items: { name: string; bytes: Uint8Array; id?: string }[] = [];
// An app board is written under each rule in turn (the written file differs), so it is built again per mode below.
for (const id of (process.argv[3] ?? "").split(";").filter(Boolean)) items.push({ name: id, bytes: build(parseId(id)).bytes, id });
if (process.env.FILES) {
  const DL = homedir() + "/Downloads";
  for (const f of readdirSync(DL).filter((f) => f.endsWith(".brd") && !f.includes("_decrypt") && f !== "test-curves-v2.brd").filter((f) => !process.env.ONLY || process.env.ONLY.split(",").some((w) => f.includes(w))).sort()) items.push({ name: f, bytes: new Uint8Array(readFileSync(DL + "/" + f)) });
}
const set = (m: string) => { for (const k of KEYS) delete process.env[k]; Object.assign(process.env, MODES[m]); };
brdLookFromBytes(items[0].bytes, "x.brd");
const rows: any[] = [];
for (const it of items) {
  const row: any = { name: it.name, load: execSync("uptime").toString().trim().replace(/.*averages: /, "") };
  for (const m of Object.keys(MODES)) {
    set(m);
    const bytes = it.id ? build(parseId(it.id)).bytes : it.bytes;
    let best = Infinity;
    for (let r = 0; r < reps; r++) { const t0 = performance.now(); brdLookFromBytes(bytes, "x.brd"); best = Math.min(best, (performance.now() - t0) / 1000); }
    row[m] = +best.toFixed(2);
  }
  set("today");
  rows.push(row);
  console.log(JSON.stringify(row));
}
writeFileSync(process.argv[2], JSON.stringify(rows, null, 1));

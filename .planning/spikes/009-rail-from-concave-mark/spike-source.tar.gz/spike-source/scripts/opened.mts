// Spike 009: the three founder's longboard files that open with a Rail Roll — the board that opens today, and that same board
// (its fields exactly as today's import found them) drawn under rule A: litres, and the opened board's nose rail start.
// Then the file opened under rule A (the import run under the rule): its litres. Files read in place, never copied.
//   ROOT=<wt> npx --no-install tsx --tsconfig ./tsconfig.json opened.mts
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const { summarizeDesign } = await imp("lib/geometry/design.ts");
for (const f of ["92Log.brd", "Scoop-Noserider.brd", "testLB.brd"]) {
  const bytes = new Uint8Array(readFileSync(homedir() + "/Downloads/" + f));
  process.env.S9_RULE = "";
  const r = brdLookFromBytes(bytes, f);
  const fields = r.fields;
  const litres = (rule: string) => { process.env.S9_RULE = rule; const v = +summarizeDesign(fields).volumeLitres; process.env.S9_RULE = ""; return v; };
  const today = litres(""), drawnA = litres("a");
  process.env.S9_RULE = "a";
  const rA = brdLookFromBytes(bytes, f);
  const openedA = +summarizeDesign(rA.fields).volumeLitres;
  process.env.S9_RULE = "";
  const n = fields.bottom.nose;
  console.log(`${f.padEnd(22)} opens with ${n.name} ${(n.depth / 25.4 * 64).toFixed(0)}/64", roll ${((n.railRoll ?? 0) / 25.4 * 64).toFixed(0)}/64", Off Rail ${(n.offRail / 25.4).toFixed(2)}": litres today ${today.toFixed(2)} L; the same board drawn under A ${drawnA.toFixed(2)} L; opened under A ${openedA.toFixed(2)} L`);
}

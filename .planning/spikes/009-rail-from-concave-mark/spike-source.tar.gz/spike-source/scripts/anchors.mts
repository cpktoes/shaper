// Spike 009: where each nose concave's pull reaches along the board (its Deepest At and End, from the nose), and how much of it
// stands at RAILS' three cards (nose 12" from the tip, centre, tail 12"), per preset.
//   ROOT=<wt> npx --no-install tsx --tsconfig ./tsconfig.json anchors.mts
import { build, imp, IN } from "./board.mts";
const { railAnchorStations } = await imp("lib/geometry/design.ts");
const { s9RailStartLimiter } = await imp("lib/geometry/bottom.ts");
for (const board of ["longboard", "midlength", "fish", "shortboard"]) for (const name of ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"]) {
  const w = build({ board, nose: [name, 3, 4] });
  const L = w.fields.outline.length;
  const a = railAnchorStations(w.profile.effectiveFoil, L);
  const lim = s9RailStartLimiter(w.resolved, w.board)!;
  const share = (s: number) => lim(s)?.share ?? 0;
  const c = w.resolved.nose;
  console.log(`${board.padEnd(10)} ${name.padEnd(28)} ${(L / IN).toFixed(0)}": Start ${((L - c.start) / IN).toFixed(1)}" Deepest ${((L - c.deepest) / IN).toFixed(1)}" End ${((L - c.end) / IN).toFixed(1)}" from the nose; share at nose card ${share(a.nose).toFixed(2)}, centre card (${((L - a.center) / IN).toFixed(0)}") ${share(a.center).toFixed(2)}, tail card ${share(a.tail).toFixed(2)}`);
}

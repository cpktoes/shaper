import { readFileSync } from "node:fs";
const [a, b] = [2, 3].map((i) => JSON.parse(readFileSync(process.argv[i], "utf8")));
let same = true;
for (const r of a) { const q = b.find((x) => x.name === r.name); if (!q) continue;
  const names = (x) => ["nose","center","tail"].map((k) => x.specs[k].name).join(" · ");
  const id = JSON.stringify(r.specs) === JSON.stringify(q.specs) && JSON.stringify(r.sections) === JSON.stringify(q.sections);
  if (!id) same = false;
  const f = (x) => `${x.bottom[0].toFixed(2)}/${x.bottom[1].toFixed(2)}`;
  const fr = (x) => x.rails ? `${x.rails[0].toFixed(2)}/${x.rails[1].toFixed(2)}` : "-";
  console.log(`${r.name.padEnd(32)} bottom ${f(r)} -> ${f(q)}  rails ${fr(r)} -> ${fr(q)}  ${r.secs.toFixed(2)}s -> ${q.secs.toFixed(2)}s ${id ? "IDENTICAL" : names(r) === names(q) ? "names same" : "NAMES: " + q.cuts.join(" · ")}`);
  if (!id && process.argv[4]) console.log("      " + q.cuts.join(" · "));
}
console.log(same ? "ALL IDENTICAL (specs and every section value)" : "differs");

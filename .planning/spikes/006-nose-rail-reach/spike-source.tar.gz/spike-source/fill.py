# Fills the README's times and the twelve-file table from the result files. python3 -I fill.py <scratch> <out file>
import json, pathlib, sys
S = pathlib.Path(sys.argv[1]); d = (S / "README.md").read_text()
t = {}
for line in (S / "out/timing-warm.md").read_text().splitlines():
    c = [x.strip() for x in line.strip("|").split("|")]
    if len(c) == 5 and c[1].endswith(" s"): t[c[0]] = c[1:]
for tag, name in (("T92", "92Log"), ("TSC", "Scoop-Noserider"), ("TLB", "testLB")):
    for i, k in enumerate("ABCD"): d = d.replace(tag + k, t[name][i])
base = json.loads((S / "out/all-base.json").read_text()); bt3 = json.loads((S / "out/all-bt3.json").read_text())
f = lambda x: "%.2f / %.2f" % (x[0], x[1])
rows = []
for b in base:
    a = next(x for x in bt3 if x["name"] == b["name"])
    same = a["specs"] == b["specs"] and a["rail"] == b["rail"] and a["f90"] == b["f90"]
    cell = lambda k: f(b[k]) + (" → identical" if same else " → " + f(a[k]))
    rows.append("| %s | %s | %s | %s | %s | %s |" % (b["name"].replace("-", " ").replace("   ", " "), cell("bottom"), cell("f90"), cell("rails"), t[b["name"]][0], t[b["name"]][1]))
rows.append("| Total | | | | %s | %s |" % (t["Total"][0], t["Total"][1]))
d = d.replace("TWELVE", "\n".join(rows))
d = d.replace("its rails typical from 0.49 to 0.47; its whole-file figures do not move.", "its rails typical from 0.49 to 0.47; its whole-file bottom figures barely move (0.77 / 0.21 to 0.77 / 0.20).")
d = d.replace("No file gets worse. Nothing gets usefully better either.", "No file gets worse. Nothing gets usefully better either. The Egg and quadtesting open about 0.3 s and 0.9 s slower\n(the rail fit has more to try); the three nose files cost nothing because nothing is taken.")
pathlib.Path(sys.argv[2]).write_text(d)

# Spike 006 trial code (on top of spike 005's trial-code.diff). python3 -I patch-rail.py <worktree>
#  SPIKE_BT3_IN=n   a rail's Bottom Tuck 3 nudge may reach +n inches (today +3/4"); the import tries it on the nose rail only
#  SPIKE_BT3_ALL=1  ... and on the centre and tail rails too
#  SPIKE_STRIP_IN=n the rail fit scores the outer n inches of the bottom (today 3")
import sys, pathlib
wt = pathlib.Path(sys.argv[1])
def sub(path, old, new):
    p = wt / path; s = p.read_text()
    assert s.count(old) == 1, (path, old[:70], s.count(old))
    p.write_text(s.replace(old, new))
sub("lib/geometry/rail-bands.ts",
    "clamp(input.nudgesIn[k], -RAIL_NUDGE_LIMIT_IN[k], k === \"domedDeckBand\" ? RAIL_DOME_NUDGE_MAX_IN : RAIL_NUDGE_LIMIT_IN[k]),",
    "clamp(input.nudgesIn[k], -RAIL_NUDGE_LIMIT_IN[k], k === \"domedDeckBand\" ? RAIL_DOME_NUDGE_MAX_IN : k === \"bottomTuck3\" && typeof process !== \"undefined\" && process.env.SPIKE_BT3_IN ? Number(process.env.SPIKE_BT3_IN) : RAIL_NUDGE_LIMIT_IN[k]),")
sub("lib/geometry/brd-rails.ts",
    "      const top = nudge === \"domedDeckBand\" ? domedDeckBandNudgeTop(board.input.halfWidthAt(board.anchors[key]), board.foil[FOIL_KEY[key]]) : limit;\n      const tries = nudge === \"domedDeckBand\" ? DOME_TRIES : NUDGE_TRIES;",
    "      const wideTuck = nudge === \"bottomTuck3\" && !!process.env.SPIKE_BT3_IN && (key === \"nose\" || !!process.env.SPIKE_BT3_ALL);\n      const top = nudge === \"domedDeckBand\" ? domedDeckBandNudgeTop(board.input.halfWidthAt(board.anchors[key]), board.foil[FOIL_KEY[key]]) : wideTuck ? Number(process.env.SPIKE_BT3_IN) : limit;\n      const tries = nudge === \"domedDeckBand\" || wideTuck ? DOME_TRIES : NUDGE_TRIES;")
sub("lib/geometry/brd-rails.ts",
    "  while (first < apex && half[first][0] < reach - BRD_RAIL_STRIP_MM) first++;",
    "  const strip = process.env.SPIKE_STRIP_IN ? Number(process.env.SPIKE_STRIP_IN) * 25.4 : BRD_RAIL_STRIP_MM;\n  while (first < apex && half[first][0] < reach - strip) first++;")

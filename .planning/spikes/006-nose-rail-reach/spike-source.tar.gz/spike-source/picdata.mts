// The finished half sections for the picture: the file, today's board, the nose rail's Bottom Tuck 3 forced a further 1 1/4" in,
// and spike 005's Edge Roll ("Rail Roll") through the import.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdRailBoard, brdOurRailHalf, brdRailsSpec } = await import(`${ROOT}/lib/geometry/brd-rails.ts`);
const IN = 25.4;
const pick: Record<string, number[]> = { "92Log": [94.5, 106.9], "Scoop-Noserider": [73.7, 97.7], "testLB": [96.0, 102.5] };
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const out: any[] = [];
for (const name of Object.keys(pick)) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  for (const k of ["SPIKE_STARTS", "SPIKE_POLISH", "SPIKE_GATE_MM", "SPIKE_ONE"]) delete process.env[k];
  process.env.SPIKE_BT3_IN = "4";
  const today = brdFitLook(read.board);
  Object.assign(process.env, { SPIKE_STARTS: "nose", SPIKE_POLISH: "roll-nose", SPIKE_GATE_MM: "1", SPIKE_ONE: "1" });
  const roll = brdFitLook(read.board);
  const st = today.rails.settings;
  const board = brdRailBoard(today.fit, today.bottom.bottom, today.fins?.spec);
  const wide = brdRailsSpec({ ...st, nose: { ...st.nose, nudges: { ...st.nose.nudges, bottomTuck3: st.nose.nudges.bottomTuck3 + 1.25 * IN } } }, board.foil, today.rails.blend?.blend);
  for (const s of today.rails.sections) {
    if (!pick[name].some((p) => Math.abs(p - s.station / IN) < 0.3)) continue;
    const r = roll.rails.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    out.push({ name, station: s.station, file: run(s.file), today: run(s.ours), wide: run(brdOurRailHalf(board, wide, s.station)), roll: run(r.ours) });
  }
}
writeFileSync(process.env.OUT!, JSON.stringify(out)); console.log(out.length);

#!/bin/bash
# run.sh <label> [VAR=value ...]   one trial through the real import (all twelve files, or ONLY=...), from the repo root
S=/private/tmp/claude-501/-Users-kontoes-Code-shaper/002e2a58-3c43-4c8e-bbb5-e9c435113dd2/scratchpad/spike006
label=$1; shift
cd /Users/kontoes/Code/shaper && env "$@" ROOT=$S/wt OUT=$S/out/$label.json npx --no-install tsx --tsconfig ./tsconfig.json $S/src/measure.mts > $S/out/$label.log 2>&1

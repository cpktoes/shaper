// node picture.cjs <picdata.json> <out.png>
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [dataFile, outFile] = process.argv.slice(2);
const data = JSON.parse(fs.readFileSync(dataFile));
const IN = 25.4, INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", TODAY = "#2a78d6", WIDE = "#8a4fd0", ROLL = "#eb6834";
const at = (q, x) => { for (let k = 0; k + 1 < q.length; k++) if (x >= q[k][0] && x <= q[k + 1][0]) return q[k][1] + (q[k + 1][1] - q[k][1]) * (x - q[k][0]) / (q[k + 1][0] - q[k][0] || 1); return x <= q[0][0] ? q[0][1] : q[q.length - 1][1]; };
function panel(s) {
  const W = 396, H = 310, L = 46, R = 14, T = 64, B = 40;
  const reach = s.file[s.file.length - 1][0], x0 = reach * 0.35;
  const inside = (r) => r.filter((p) => p[0] >= x0 && p[0] <= 0.97 * reach);
  const vals = [...inside(s.file), ...inside(s.today), ...inside(s.roll)].map((p) => p[1]);
  let lo = Math.min(0, ...vals), hi = Math.max(1, ...vals.filter((v, i) => true)); hi = Math.min(hi, lo + 9); const pad = (hi - lo) * 0.06; lo -= pad;
  const x = (y) => L + ((y - x0) / (reach - x0)) * (W - L - R), yy = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const path = (r) => r.filter((p) => p[0] >= x0 && p[1] <= hi * 1.02).map((p, j) => `${j ? "L" : "M"}${x(p[0]).toFixed(1)},${yy(p[1]).toFixed(1)}`).join("");
  const miss = (r) => { let w = 0; for (let j = 0; j <= 24; j++) { const xx = 0.9 * reach * j / 24; w = Math.max(w, Math.abs(at(s.file, xx) - at(r, Math.min(xx, r[r.length - 1][0])))); } return w.toFixed(2); };
  const span = hi - lo, step = span > 8 ? 2 : span > 4 ? 1 : 0.5; let g = "";
  for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) g += `<line x1="${L}" x2="${W - R}" y1="${yy(v)}" y2="${yy(v)}" stroke="${Math.abs(v) < 1e-9 ? "#b9b8b2" : GRID}"/><text x="${L - 6}" y="${yy(v) + 4}" text-anchor="end" class="t">${+v.toFixed(1)}</text>`;
  for (let i = Math.ceil(x0 / IN); i <= reach / IN; i += 1) g += `<text x="${x(i * IN)}" y="${H - B + 16}" text-anchor="middle" class="t">${i}"</text>`;
  g += `<line x1="${x(0.9 * reach)}" x2="${x(0.9 * reach)}" y1="${T}" y2="${H - B}" stroke="#b9b8b2" stroke-dasharray="2 3"/>`;
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <text x="${L}" y="16" class="h">${s.name === "Scoop-Noserider" ? "Scoop" : s.name}, ${(s.station / IN).toFixed(1)}" from the tail</text>
  <text x="${L}" y="32" class="t">Widest miss out to nine-tenths of the way (dotted line):</text>
  <text x="${L}" y="46" class="t">today ${miss(s.today)} · wider rail ${miss(s.wide)} · Rail Roll ${miss(s.roll)} mm</text>
  ${g}
  <path d="${path(s.today)}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(s.wide)}" fill="none" stroke="${WIDE}" stroke-width="2" stroke-dasharray="2 3"/>
  <path d="${path(s.roll)}" fill="none" stroke="${ROLL}" stroke-width="2"/>
  <path d="${path(s.file)}" fill="none" stroke="${INK}" stroke-width="2"/>
  <text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="t">out from the stringer (the outer two-thirds of the half), to the rail</text></svg>`;
}
const key = (c, dash, label) => `<span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${c}" stroke-width="2" ${dash ? `stroke-dasharray="${dash}"` : ""}/></svg>${label}</span>`;
const html = `<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:${INK}}
 .wrap{width:1240px;padding:22px 24px 20px} h1{font-size:19px;margin:0 0 4px;font-weight:600} p{margin:0 0 4px;font-size:13px;color:${SUB};line-height:1.45}
 .t{font-size:11px;fill:${SUB}} .h{font-size:13px;font-weight:600;fill:${INK}} .row{display:flex;gap:10px;margin-top:8px}
 .key{display:flex;gap:22px;font-size:13px;margin-top:10px} .key svg{vertical-align:middle;margin-right:6px}</style><div class="wrap">
 <h1>The finished nose sections: the file, today's board, a wider nose rail, and the Rail Roll</h1>
 <p>Every line but the file's is our finished section: BOTTOM's cuts with the rail standing on them. "Wider rail" is today's board with the nose rail's Bottom Tuck 3 moved a further 1 1/4" in by hand (the import, left free to do so, never does). "Rail Roll" is spike 005's Edge Roll through the import. Heights are stretched; the rail runs off the top.</p>
 <div class="key">${key(INK, "", "The file")}${key(TODAY, "6 4", "Today's board")}${key(WIDE, "2 3", "Wider nose rail (Bottom Tuck 3 +1 1/4\")")}${key(ROLL, "", "Rail Roll")}</div>
 <div class="row">${data.slice(0, 3).map(panel).join("")}</div><div class="row">${data.slice(3, 6).map(panel).join("")}</div></div>`;
(async () => { const b = await chromium.launch(); const pg = await b.newPage({ viewport: { width: 1290, height: 800 }, deviceScaleFactor: 2 }); await pg.setContent(html); await pg.locator(".wrap").screenshot({ path: outFile }); await b.close(); })();

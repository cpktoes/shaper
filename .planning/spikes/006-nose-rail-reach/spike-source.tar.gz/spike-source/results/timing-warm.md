| File | today | wider nose rail allowed | Rail Roll | both |
|---|---|---|---|---|
| 92Log | 1.81 s | 1.80 s | 4.26 s | 4.13 s |
| Scoop-Noserider | 2.06 s | 2.24 s | 4.61 s | 4.69 s |
| testLB | 4.72 s | 4.74 s | 5.34 s | 5.38 s |
| quadtesting | 1.60 s | 2.52 s | 2.15 s | 3.06 s |
| SAtri | 1.91 s | 1.90 s | 1.90 s | 1.93 s |
| SAtwin | 1.89 s | 1.89 s | 1.87 s | 1.86 s |
| mid | 2.23 s | 2.22 s | 2.25 s | 2.34 s |
| JFS_BigTwin | 0.72 s | 0.71 s | 0.72 s | 0.71 s |
| 6'10-Widepoint-Fwd-Egg | 0.69 s | 0.96 s | 0.75 s | 0.91 s |
| 6'2-Round-Tail---Double-Concave | 3.54 s | 3.54 s | 3.45 s | 3.46 s |
| 6'4-Double-Wing-Groveler | 1.05 s | 1.12 s | 1.07 s | 1.09 s |
| Fryer-5'7-Squash-Flyer-Twin | 3.13 s | 3.13 s | 3.12 s | 3.16 s |
| Total | 25.3 s | 26.8 s | 31.5 s | 32.7 s |

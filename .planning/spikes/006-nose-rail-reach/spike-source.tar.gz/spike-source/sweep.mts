// Forced sweep: today's fitted board, the NOSE rail's Bottom Tuck 3 pushed further in by hand (and Symmetrical ticked), nothing
// else moved. Per nose section: the bottom zone's finished miss (file against cuts + rail, stringer to nine-tenths of the way out)
// and the rail fit's own score there. Run with SPIKE_BT3_IN=4 so the wider nudge is not clamped.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook, brdRailLines } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdRailBoard, brdOurRailHalves, brdRailsSpec, brdRailLineGap } = await import(`${ROOT}/lib/geometry/brd-rails.ts`);
const IN = 25.4;
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const q: number[][] = []; for (let k = 0; k <= apex; k++) if (!q.length || half[k][0] > q[q.length - 1][0]) q.push(half[k]); return q; };
const at = (q: number[][], x: number) => { for (let k = 0; k + 1 < q.length; k++) if (x >= q[k][0] && x <= q[k + 1][0]) return q[k][1] + (q[k + 1][1] - q[k][1]) * (x - q[k][0]) / (q[k + 1][0] - q[k][0] || 1); return x <= q[0][0] ? q[0][1] : q[q.length - 1][1]; };
const dump: any[] = [];
for (const name of (process.argv[2] ?? "92Log,Scoop-Noserider,testLB").split(",")) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  const L = read.board.length, st = look.rails.settings;
  const board = brdRailBoard(look.fit, look.bottom.bottom, look.fins?.spec);
  const lines = brdRailLines(read.board).lines.filter((l: any) => l.station > L * 2 / 3);
  const stations = lines.map((l: any) => l.station);
  console.log(`\n=== ${name}: nose rail today ${JSON.stringify({ ratio: st.nose.ratio, sym: st.nose.symmetrical, scale: st.nose.scale, bt3: +(st.nose.nudges.bottomTuck3 / IN).toFixed(2) })}; nose sections ${stations.map((s: number) => (s / IN).toFixed(1)).join(", ")}`);
  const variants: [string, any][] = [["today", st.nose]];
  for (const add of [0.75, 1.25, 1.75, 2.25, 3, 4]) variants.push([`Bottom Tuck 3 nudge +${add}"`, { ...st.nose, nudges: { ...st.nose.nudges, bottomTuck3: add * IN } }]);
  variants.push([`Symmetrical ${st.nose.symmetrical ? "off" : "on"}`, { ...st.nose, symmetrical: !st.nose.symmetrical }]);
  variants.push([`scale 1`, { ...st.nose, scale: 1 }]);
  for (const [label, nose] of variants) {
    const rails = brdRailsSpec({ ...st, nose }, board.foil, look.rails.blend?.blend);
    const halves = brdOurRailHalves(board, rails, stations);
    let out = "", worst = 0, sum = 0, n = 0, rw = 0, rm = 0;
    lines.forEach((line: any, i: number) => {
      const f = run(line.points.map((p: number[]) => [p[0], p[1] - line.points[0][1]])), o = run(halves[i]); const reach = f[f.length - 1][0];
      let w = 0, begins = reach;
      for (let j = 0; j <= 24; j++) { const x = 0.9 * reach * j / 24; const g = Math.abs(at(f, x) - at(o, Math.min(x, o[o.length - 1][0]))); sum += g; n++; if (g > w) w = g; }
      // where our rail leaves the bottom: the first point (walking in from the apex) whose slope falls under 2%
      for (let k = o.length - 1; k > 0; k--) if ((o[k][1] - o[k - 1][1]) / (o[k][0] - o[k - 1][0] || 1) < 0.02) { begins = o[k][0]; break; }
      const g = brdRailLineGap(line, halves[i]);
      if (w > worst) worst = w; if (g.largest > rw) rw = g.largest; rm += g.mean;
      out += ` ${(line.station / IN).toFixed(0)}":${w.toFixed(2)}(${((reach - begins) / IN).toFixed(1)}" in)`;
      if (label === "today" || label.includes("+1.75") || label.includes("+3")) dump.push({ name, label, station: line.station, file: f, ours: o });
    });
    console.log(`${label.padEnd(30)} bottom zone finished ${worst.toFixed(2)} / ${(sum / n).toFixed(2)}  rail score ${rw.toFixed(2)} / ${(rm / lines.length).toFixed(2)} |${out}`);
  }
}
if (process.env.OUT) writeFileSync(process.env.OUT, JSON.stringify(dump));

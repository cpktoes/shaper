// Per section: today's bottom gap (ours = the bottom's cuts alone) against the gap when ours is the finished section (the cuts
// with our fitted rail standing on them), in the same window; and where our finished rail really begins against the window.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const IN = 25.4;
const FILES = ["92Log", "Scoop-Noserider", "testLB", "quadtesting", "SAtri", "SAtwin", "mid", "JFS_BigTwin", "6'10-Widepoint-Fwd-Egg", "6'2-Round-Tail---Double-Concave", "6'4-Double-Wing-Groveler", "Fryer-5'7-Squash-Flyer-Twin"];
const names = process.argv[2] ? process.argv[2].split(",") : FILES;
const verbose = process.argv[3] === "v";
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const at = (r: number[][], x: number) => { for (let k = 0; k + 1 < r.length; k++) if (x >= r[k][0] && x <= r[k + 1][0]) return r[k][1] + (r[k + 1][1] - r[k][1]) * (x - r[k][0]) / (r[k + 1][0] - r[k][0] || 1); return x <= r[0][0] ? r[0][1] : r[r.length - 1][1]; };
const out: any[] = [];
for (const name of names) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  const b = look.bottom!; const L = read.board.length;
  let wToday = 0, wWhole = 0, wInside = 0, sToday = 0, sWhole = 0, n = 0, whereToday = "", whereWhole = "";
  for (const s of b.sections) {
    const rs = look.rails?.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    if (!rs || rs.ours.length === 0) continue;
    const o = run(rs.ours);
    let today = 0, whole = 0, inside = 0, begins = s.window, tAt = 0, wAt = 0;
    let found = false;
    s.across.forEach((y: number, j: number) => {
      const fin = at(o, y);
      if (!found && Math.abs(fin - s.ours[j]) > 0.05) { found = true; begins = j > 0 ? s.across[j - 1] : 0; }
      const gT = Math.abs(s.file[j] - s.ours[j]), gW = Math.abs(s.file[j] - fin);
      if (gT > today) { today = gT; tAt = y; } if (gW > whole) { whole = gW; wAt = y; }
      if (!found && gT > inside) inside = gT;
      sToday += gT; sWhole += gW; n++;
    });
    if (today > wToday) { wToday = today; whereToday = `${(s.station / IN).toFixed(1)}" ${(tAt / IN).toFixed(1)}" out`; }
    if (whole > wWhole) { wWhole = whole; whereWhole = `${(s.station / IN).toFixed(1)}" ${(wAt / IN).toFixed(1)}" out`; }
    if (inside > wInside) wInside = inside;
    if (verbose) console.log(`   st ${(s.station / IN).toFixed(1).padStart(5)}" reach ${(s.reach / IN).toFixed(2)}" window ${(s.window / IN).toFixed(2)}" (${(s.window / s.reach * 100).toFixed(0)}%) our rail begins ${(begins / IN).toFixed(2)}" (${(begins / s.reach * 100).toFixed(0)}%)  gap today ${today.toFixed(2)} @${(tAt / IN).toFixed(1)}"  finished section ${whole.toFixed(2)} @${(wAt / IN).toFixed(1)}"  inside our rail ${inside.toFixed(2)}`);
  }
  console.log(`${name.padEnd(32)} today ${wToday.toFixed(2)}/${(sToday / n).toFixed(2)} @${whereToday} | ours as the finished section ${wWhole.toFixed(2)}/${(sWhole / n).toFixed(2)} @${whereWhole} | only inside where our rail begins ${wInside.toFixed(2)} | order ${look.rails?.order}`);
}

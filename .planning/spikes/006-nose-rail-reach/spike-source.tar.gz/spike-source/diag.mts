// Where the nose miss really is: the file's whole half section against ours (bottom AND rail), out to the widest point.
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLook } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdFittedBottomBoard } = await import(`${ROOT}/lib/geometry/brd-bottom.ts`);
const IN = 25.4;
const names = (process.argv[2] ?? "92Log,Scoop-Noserider,testLB").split(",");
const from = Number(process.argv[3] ?? 0.6);
const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const r: number[][] = []; for (let k = 0; k <= apex; k++) if (!r.length || half[k][0] > r[r.length - 1][0]) r.push(half[k]); return r; };
const at = (r: number[][], x: number) => { for (let k = 0; k + 1 < r.length; k++) if (x >= r[k][0] && x <= r[k + 1][0]) return r[k][1] + (r[k + 1][1] - r[k][1]) * (x - r[k][0]) / (r[k + 1][0] - r[k][0] || 1); return x <= r[0][0] ? r[0][1] : r[r.length - 1][1]; };
for (const name of names) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLook(read.board);
  const L = read.board.length;
  const b = look.bottom!;
  const board = brdFittedBottomBoard(look.fit, look.fins?.spec);
  console.log(`\n=== ${name} length ${(L / IN).toFixed(1)}" order ${look.rails?.order} narrowed ${look.rails?.narrowed} bottom ${b.closeness.largest.toFixed(2)}/${b.closeness.typical.toFixed(2)} @${(b.closeness.station / IN).toFixed(1)}" ${(b.closeness.across / IN).toFixed(1)}" out; rails ${look.rails?.closeness.largest.toFixed(2)}/${look.rails?.closeness.typical.toFixed(2)} @${((look.rails?.closeness.station ?? 0) / IN).toFixed(1)}" ${look.rails?.closeness.where} read ${JSON.stringify(Object.fromEntries(Object.entries(look.rails?.read ?? {}).map(([k, v]) => [k, v === null ? null : +((v as number) / IN).toFixed(1)])))}`);
  for (const s of b.sections) {
    if (s.station < from * L) continue;
    const rs = look.rails?.sections.find((q: any) => Math.abs(q.station - s.station) < 0.01);
    const f = run(rs.file), o = run(rs.ours);
    const fr = f[f.length - 1][0], or = o[o.length - 1][0];
    // where our bottom ends: last point of our run whose height equals the bottom's own (foam off) within 0.02
    console.log(` st ${(s.station / IN).toFixed(1)}" (${((L - s.station) / IN).toFixed(1)}" from nose) file half-width ${(fr / IN).toFixed(2)}" ours ${(or / IN).toFixed(2)}" (railAt ${(board.railAt(s.station) / IN).toFixed(2)}") window ${(s.window / IN).toFixed(2)}" = ${(s.window / s.reach * 100).toFixed(0)}% | bottom gap ${s.gap.largest.toFixed(2)} @${(s.gap.across / IN).toFixed(2)}" | rail gap ${rs.gap.largest.toFixed(2)}/${rs.gap.mean.toFixed(2)} ${rs.gap.where} ${(rs.gap.inFromRail / IN).toFixed(2)}" in | apex height file ${f[f.length - 1][1].toFixed(1)} ours ${o[o.length - 1][1].toFixed(1)}`);
    const xs = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.925, 0.95, 0.975, 1];
    console.log("   share " + xs.map((u) => (u * 100).toFixed(0).padStart(6)).join(""));
    console.log("   in out" + xs.map((u) => (u * fr / IN).toFixed(1).padStart(6)).join(""));
    console.log("   file  " + xs.map((u) => at(f, u * fr).toFixed(2).padStart(6)).join(""));
    console.log("   ours  " + xs.map((u) => (u * fr <= or ? at(o, u * fr).toFixed(2) : "  -").padStart(6)).join(""));
    console.log("   diff  " + xs.map((u) => (u * fr <= or ? (at(f, u * fr) - at(o, u * fr)).toFixed(2) : "  -").padStart(6)).join(""));
    // the file's lowest point and where it turns up
    let lo = 0; for (let k = 1; k < f.length; k++) if (f[k][1] < f[lo][1]) lo = k;
    console.log(`   file's lowest point ${f[lo][1].toFixed(2)} mm at ${(f[lo][0] / IN).toFixed(2)}" out (${(f[lo][0] / fr * 100).toFixed(0)}% of the way, ${((fr - f[lo][0]) / IN).toFixed(2)}" in from the rail)`);
  }
}

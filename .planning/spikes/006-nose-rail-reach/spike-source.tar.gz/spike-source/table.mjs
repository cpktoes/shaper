// node table.mjs <out folder> <label> ...   one line a file and label: the three bottom scores and the rails
import { readFileSync } from "node:fs";
const [dir, ...labels] = process.argv.slice(2);
const data = labels.map((l) => JSON.parse(readFileSync(`${dir}/${l}.json`, "utf8")));
const f = (x) => `${x[0].toFixed(2)} / ${x[1].toFixed(2)}`;
for (const r of data[0]) { console.log(`\n${r.name}`);
  labels.forEach((l, i) => { const q = data[i].find((x) => x.name === r.name); const same = JSON.stringify(q.specs) === JSON.stringify(r.specs) && JSON.stringify(q.rail) === JSON.stringify(r.rail) && JSON.stringify(q.f90) === JSON.stringify(r.f90);
    console.log(`  ${l.padEnd(12)} cuts alone ${f(q.bottom)} | finished, reading width ${f(q.finished)} | finished, to 90% ${f(q.f90)} | nose third to 90% ${f(q.nose90)} | rails ${f(q.rails)} | ${q.order}${i && same ? " | IDENTICAL to " + labels[0] : ""}`); }); }

// Runs the real import on the founder's twelve files; ROOT picks the checkout (main or the trial worktree).
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT ?? "/Users/kontoes/Code/shaper";
const OUT = process.env.OUT!;
const { brdLookFromBytes } = await import(`${ROOT}/lib/export/brd-look.ts`);
const FILES = ["92Log", "Scoop-Noserider", "testLB", "quadtesting", "SAtri", "SAtwin", "mid", "JFS_BigTwin", "6'10-Widepoint-Fwd-Egg", "6'2-Round-Tail---Double-Concave", "6'4-Double-Wing-Groveler", "Fryer-5'7-Squash-Flyer-Twin"];
const only = process.env.ONLY?.split(",");
const IN = 25.4;
const rows: any[] = [];
for (const name of FILES) {
  if (only && !only.includes(name)) continue;
  const bytes = new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`));
  const t0 = performance.now();
  const r = brdLookFromBytes(bytes, `${name}.brd`);
  const secs = (performance.now() - t0) / 1000;
  if (!r.ok) { rows.push({ name, problem: r.problem }); continue; }
  const b = r.look.bottom!;
  const cut = (c: any) => `${c.name} ${(c.depth / IN).toFixed(3)}"${c.offStringer > 0.3 ? ` os ${(c.offStringer / IN).toFixed(2)}"` : ""}${c.acrossShape !== undefined ? ` shape ${Number(c.acrossShape).toFixed(2)}` : ""}${c.edgeRoll ? ` roll ${(c.edgeRoll / IN).toFixed(3)}"` : ""}${c.smoothness !== undefined && c.depth > 0 ? ` sm ${Number(c.smoothness).toFixed(0)}` : ""}`;
  const row = {
    name, secs,
    bottom: [b.closeness.largest, b.closeness.typical, b.closeness.station, b.closeness.across],
    rails: r.look.rails ? [r.look.rails.closeness.largest, r.look.rails.closeness.typical] : null,
    cuts: [cut(b.bottom.nose), cut(b.bottom.center), cut(b.bottom.tail)],
    specs: b.bottom,
    sections: b.sections.map((s: any) => ({ station: s.station, reach: s.reach, window: s.window, across: s.across, file: s.file, ours: s.ours, gap: s.gap, flat: s.flat, reads: s.reads })),
    length: r.look.fit.outline?.length ?? r.look.board.length,
  };
  {
    const run = (half: number[][]) => { let apex = 0; for (let k = 1; k < half.length; k++) if (half[k][0] > half[apex][0]) apex = k; const q: number[][] = []; for (let k = 0; k <= apex; k++) if (!q.length || half[k][0] > q[q.length - 1][0]) q.push(half[k]); return q; };
    const at = (q: number[][], x: number) => { for (let k = 0; k + 1 < q.length; k++) if (x >= q[k][0] && x <= q[k + 1][0]) return q[k][1] + (q[k + 1][1] - q[k][1]) * (x - q[k][0]) / (q[k + 1][0] - q[k][0] || 1); return x <= q[0][0] ? q[0][1] : q[q.length - 1][1]; };
    let fw = 0, fs = 0, fn = 0, nw = 0, ns = 0, nn = 0, gw = 0, gs = 0, gn = 0; const per: any[] = [];
    const L = r.look.board.length;
    for (const sec of b.sections) {
      const rs = r.look.rails?.sections.find((q: any) => Math.abs(q.station - sec.station) < 0.01);
      if (!rs || rs.ours.length === 0) continue;
      const f = run(rs.file), o = run(rs.ours); let w = 0, begins = sec.reach;
      for (let j = 0; j <= 24; j++) { const x = 0.9 * sec.reach * j / 24; const g = Math.abs(at(f, x) - at(o, Math.min(x, o[o.length - 1][0]))); fs += g; fn++; if (g > w) w = g; if (sec.station > L * 2 / 3) { ns += g; nn++; } }
      if (w > fw) fw = w; if (sec.station > L * 2 / 3 && w > nw) nw = w;
      let ww = 0; sec.across.forEach((y: number, j: number) => { const g = Math.abs(sec.file[j] - at(o, y)); gs += g; gn++; if (g > ww) ww = g; });
      if (ww > gw) gw = ww;
      for (let k = 0; k < o.length; k++) if (o[k][1] - (k ? o[k - 1][1] : 0) > 0.05 && o[k][1] > Math.min(...o.slice(0, k + 1).map((p) => p[1])) + 0.3) { begins = o[k][0]; break; }
      per.push({ station: sec.station, reach: sec.reach, window: sec.window, f90: w, fw: ww, cuts: sec.gap.largest });
    }
    (row as any).finished = [gw, gn ? gs / gn : 0]; (row as any).f90 = [fw, fn ? fs / fn : 0]; (row as any).nose90 = [nw, nn ? ns / nn : 0]; (row as any).per = per;
    (row as any).order = r.look.rails?.order;
    const st = r.look.rails?.settings; const nz = (n: any) => Object.entries(n).filter(([, v]) => v !== 0).map(([k, v]) => `${k} ${((v as number) / IN).toFixed(2)}"`).join(" ");
    (row as any).rail = st ? ["nose", "center", "tail"].map((k) => `${k}: F${st[k].family} ${st[k].ratio}/${100 - st[k].ratio} deck ${st[k].deckPercent.toFixed(0)}%${st[k].symmetrical ? " Sym" : ""}${st[k].singleTuck ? " SingleTuck" : ""}${st[k].sharpBottomTuck ? " SharpTuck" : ""}${st[k].hardEdge ? " HardEdge" : ""} scale ${st[k].scale} ${nz(st[k].nudges)}`) : [];
  }
  rows.push(row);
  console.log(`${name.padEnd(34)} bottom ${row.bottom[0].toFixed(2)} / ${row.bottom[1].toFixed(2)}  rails ${row.rails ? row.rails[0].toFixed(2) + " / " + row.rails[1].toFixed(2) : "-"}  ${secs.toFixed(2)} s  finished ${(row as any).finished.map((v: number) => v.toFixed(2)).join(" / ")}  to 90% ${(row as any).f90.map((v: number) => v.toFixed(2)).join(" / ")}  nose to 90% ${(row as any).nose90.map((v: number) => v.toFixed(2)).join(" / ")}  ${(row as any).order} | ${row.cuts.join(" · ")}\n      ${(row as any).rail.join("\n      ")}`);
}
if (OUT) writeFileSync(OUT, JSON.stringify(rows));

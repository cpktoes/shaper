// Step 1, off line: each belly-reading section of the three files on its own. What single across-curve matches it?
// (Ignores the along-board coupling; an upper bound per section, and a read of how the file's roll differs from ours.)
import { readFileSync } from "node:fs";
const rows = JSON.parse(readFileSync(process.argv[2], "utf8"));
const IN = 25.4, CAP = 12.7;
const rise = (u, r) => (1 - r) * u + r * (1 - Math.cos(Math.PI * u / 2));
const fams = {
  "today (cos, panel)":        { n: 0, g: (u) => rise(u, 1) },
  "smoothness free":           { n: 1, lo: 0, hi: 1, g: (u, k) => rise(u, k) },
  "power rise^k":              { n: 1, lo: 0.5, hi: 4, g: (u, k) => Math.pow(rise(u, 1), k) },
  "blend cos->u^4":            { n: 1, lo: 0, hi: 1, g: (u, k) => (1 - k) * rise(u, 1) + k * u ** 4 },
  "u^p":                       { n: 1, lo: 1, hi: 6, g: (u, k) => u ** k },
};
function best(sec, fam, cap, panel) {
  const W = sec.reach; let bestV = Infinity, bestP = null;
  const ks = fam.n ? Array.from({ length: 71 }, (_, i) => fam.lo + (fam.hi - fam.lo) * i / 70) : [0];
  const Fs = panel ? Array.from({ length: 37 }, (_, i) => i * 0.25 * IN) : [0];
  for (const k of ks) for (const F of Fs) {
    if (F >= W) continue;
    const g = sec.across.map((y) => (y > F ? fam.g((y - F) / (W - F), k) : 0));
    // best depth by scan
    for (let d = 0.5; d <= cap + 1e-9; d += 0.1) {
      let mx = 0, sum = 0;
      for (let j = 0; j < g.length; j++) { const e = Math.abs(sec.file[j] - d * g[j]); sum += e; if (e > mx) mx = e; }
      const v = mx + sum / g.length;
      if (v < bestV) { bestV = v; bestP = { k, F, d, mx, typ: sum / g.length }; }
    }
  }
  return bestP;
}
const pick = { "92Log": [15.7, 51.5], "Scoop-Noserider": [12.0, 57.7], "testLB": [1.0, 5.5, 12.0, 106.0] };
for (const r of rows) {
  if (!pick[r.name]) continue;
  for (const s of r.sections) {
    const st = s.station / IN; if (!pick[r.name].some((p) => Math.abs(p - st) < 0.3)) continue;
    // local log-log slope of the file's rise against distance out
    const j1 = 8, j2 = 16, j3 = 24;
    const slope = (a, b) => Math.log(s.file[b] / s.file[a]) / Math.log(s.across[b] / s.across[a]);
    console.log(`\n${r.name} st ${st.toFixed(1)}"  reach ${(s.reach / IN).toFixed(2)}" window ${(s.window / IN).toFixed(2)}"  file at edge ${s.file[24].toFixed(2)} mm; file's power (log slope): inner third→mid ${slope(j1, j2).toFixed(2)}, mid→edge ${slope(j2, j3).toFixed(2)}`);
    for (const [name, fam] of Object.entries(fams)) for (const cap of [CAP, 40]) for (const panel of [true, false]) {
      if (name.startsWith("today") && !panel && cap === 40) continue;
      const p = best(s, fam, cap, panel);
      console.log(`  ${name.padEnd(20)} depth≤${cap === CAP ? '1/2"' : "any "} ${panel ? "panel free" : "no panel  "}: widest ${p.mx.toFixed(2)} typical ${p.typ.toFixed(2)}  (k ${p.k.toFixed(2)}, panel ${(p.F / IN).toFixed(2)}", depth ${p.d.toFixed(1)} mm)`);
    }
  }
}

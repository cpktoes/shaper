// Draws the file's bottom against today's fit and the trial's, at the worst spots, and captures a PNG per file.
const fs = require("fs");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const [dir, outDir] = process.argv.slice(2);
const before = JSON.parse(fs.readFileSync(`${dir}/final-before.json`));
const trial = JSON.parse(fs.readFileSync(`${dir}/final-power.json`));
const IN = 25.4;
const INK = "#0b0b0b", SUB = "#52514e", GRID = "#e4e3df", TODAY = "#2a78d6", TRIAL = "#eb6834";
function panel(sb, st, note) {
  const W = 400, H = 316, L = 46, R = 14, T = 60, B = 40;
  const all = [...sb.file, ...sb.ours, ...st.ours];
  let lo = Math.min(0, ...all), hi = Math.max(0, ...all); const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const xMax = sb.window / IN;
  const x = (y) => L + ((y / IN) / xMax) * (W - L - R), yy = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const path = (vals) => vals.map((v, j) => `${j ? "L" : "M"}${x(sb.across[j]).toFixed(1)},${yy(v).toFixed(1)}`).join("");
  const step = (hi - lo) > 8 ? 4 : (hi - lo) > 4 ? 2 : (hi - lo) > 1.6 ? 1 : 0.5;
  let g = "";
  for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) g += `<line x1="${L}" x2="${W - R}" y1="${yy(v)}" y2="${yy(v)}" stroke="${v === 0 ? "#b9b8b2" : GRID}"/><text x="${L - 6}" y="${yy(v) + 4}" text-anchor="end" class="t">${v}</text>`;
  for (let i = 0; i <= xMax; i += 2) g += `<text x="${x(i * IN)}" y="${H - B + 16}" text-anchor="middle" class="t">${i}"</text>`;
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <text x="${L}" y="16" class="h">${(sb.station / IN).toFixed(1)}" from the tail</text>
  <text x="${L}" y="31" class="t">${note}</text><text x="${L}" y="45" class="t">Widest gap: today ${sb.gap.largest.toFixed(2)} mm, trial ${st.gap.largest.toFixed(2)} mm</text>
  ${g}
  <path d="${path(sb.ours)}" fill="none" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${path(st.ours)}" fill="none" stroke="${TRIAL}" stroke-width="2"/>
  <path d="${path(sb.file)}" fill="none" stroke="${INK}" stroke-width="2"/>
  <text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="t">out from the stringer (read to where the rail begins)</text>
  <text x="12" y="${(T + H - B) / 2}" text-anchor="middle" class="t" transform="rotate(-90 12 ${(T + H - B) / 2})">mm above the stringer</text></svg>`;
}
const cuts = (r) => r.cuts.join(" · ");
function page(name, stations, notes, title) {
  const b = before.find((r) => r.name === name), t = trial.find((r) => r.name === name);
  const near = (r, s) => r.sections.find((q) => Math.abs(q.station / IN - s) < 0.3);
  return `<!doctype html><meta charset="utf-8"><style>
  body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:${INK}}
  .wrap{width:1240px;padding:22px 24px 20px} h1{font-size:19px;margin:0 0 4px;font-weight:600} p{margin:0 0 4px;font-size:13px;color:${SUB};line-height:1.45}
  .t{font-size:11px;fill:${SUB}} .h{font-size:13px;font-weight:600;fill:${INK}} .row{display:flex;gap:10px;margin-top:12px}
  .key{display:flex;gap:22px;font-size:13px;margin-top:10px;color:${INK}} .key svg{vertical-align:middle;margin-right:6px}</style>
  <div class="wrap"><h1>${title}</h1>
  <p>Whole file, through the real import: bottom widest / typical miss today ${b.bottom[0].toFixed(2)} / ${b.bottom[1].toFixed(2)} mm, with the trial shape number ${t.bottom[0].toFixed(2)} / ${t.bottom[1].toFixed(2)} mm.</p>
  <p>Today: ${cuts(b)}</p><p>Trial (power family, searched in the polish): ${cuts(t)}</p>
  <div class="key"><span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${INK}" stroke-width="2"/></svg>The file's own bottom</span>
  <span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TODAY}" stroke-width="2" stroke-dasharray="6 4"/></svg>Today's fit</span>
  <span><svg width="34" height="6"><line x1="0" x2="34" y1="3" y2="3" stroke="${TRIAL}" stroke-width="2"/></svg>Fit with the trial shape number</span></div>
  <div class="row">${stations.map((s, i) => panel(near(b, s), near(t, s), notes[i])).join("")}</div>
  <p style="margin-top:8px">Heights are stretched many times against the width, and each panel has its own height scale. Up is toward the deck.</p></div>`;
}
(async () => {
  const browser = await chromium.launch();
  const pg = await browser.newPage({ viewport: { width: 1290, height: 520 }, deviceScaleFactor: 2 });
  const jobs = [
    ["92Log", [15.7, 51.5, 94.5], ["Belly, near the tail", "Belly, at the wide point", "Nose: the dip beside the rail no cut draws"], "92Log: the file's bottom, today's fit and the trial", "92log-sections.png"],
    ["Scoop-Noserider", [12.0, 57.7, 73.7], ["Belly, near the tail", "Belly, at the wide point", "Nose concave with a turned-up edge"], "Scoop-Noserider: the file's bottom, today's fit and the trial", "scoop-sections.png"],
  ];
  for (const [name, st, notes, title, file] of jobs) {
    await pg.setContent(page(name, st, notes, title));
    await pg.locator(".wrap").screenshot({ path: `${outDir}/${file}` });
  }
  await browser.close();
})();

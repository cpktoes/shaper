# Third trial patch: a fair heavy baseline (many starts with no shape number), a light three-start search, and a
# diagnostic that leaves out the sections ahead of a station (to see the belly without the nose pinning the score).
import sys
W = sys.argv[1]
p = f"{W}/lib/geometry/brd-bottom.ts"; s = open(p).read()
a = s.index("    let best = polishOnce(specs);\n    if (!SPIKE_STARTS) return best;")
b = s.index("  const polishOnce = (specs: Specs)")
s = s[:a] + '''    let best = polishOnce(specs);
    if (!SPIKE_STARTS) return best;
    for (const key of ["center", "nose", "tail"] as const) {
      if (cutKind(specs[key].name) !== "belly" || specs[key].depth <= 0) continue;
      const carries = carriesBellyShape("belly", specs[key].name);
      const span = BELLY_SHAPE.max - BELLY_SHAPE.min;
      const far = BELLY_SHAPE.family === "power" ? BELLY_SHAPE.max : BELLY_SHAPE.max; // the harder end of either family
      const mid = BELLY_SHAPE.def + (far - BELLY_SHAPE.def) / 2;
      const deepest = inchesToMm(BOTTOM_DEPTH_RANGE_IN.max);
      type Start = { k: number; os: number; depth: number };
      const starts: Start[] = [];
      if (SPIKE_STARTS === "lite") {
        // Three starts: the hard end with no panel, halfway with no panel, the hard end with the panel kept.
        if (carries) starts.push({ k: far, os: 0, depth: specs[key].depth }, { k: mid, os: 0, depth: specs[key].depth }, { k: far, os: specs[key].offStringer, depth: specs[key].depth });
      } else {
        const ks = carries ? [0, 1, 2, 3, 4, 5, 6].map((i) => BELLY_SHAPE.min + (span * i) / 6) : [BELLY_SHAPE.def];
        const panels = carries ? [specs[key].offStringer, 0] : [specs[key].offStringer, 0, 1, 2, 3, 4.5, 6].map((x, i) => (i < 2 ? x : inchesToMm(x)));
        for (const k of ks) for (const os of panels) for (const depth of [specs[key].depth, deepest]) starts.push({ k, os, depth });
      }
      for (const st of starts) {
        const cut: BottomCutSpec = { ...best.specs[key], offStringer: mm(st.os), depth: mm(st.depth), ...(carries ? { bellyShape: st.k } : {}) };
        const got = polishOnce({ ...best.specs, [key]: cut });
        if (got.value < best.value - NOISE) best = got;
      }
    }
    return best;
  };
''' + s[b:]
s = s.replace('const SPIKE_STARTS = Boolean(typeof process !== "undefined" && process.env.SPIKE_STARTS);', 'const SPIKE_STARTS = (typeof process !== "undefined" && process.env.SPIKE_STARTS) || "";\n/** SPIKE 003 diagnostic only: sections ahead of this station (inches from the tail) are left out of the reading. */\nconst SPIKE_SKIP_ABOVE_IN = Number((typeof process !== "undefined" && process.env.SPIKE_SKIP_ABOVE_IN) || 0);')
old = "    if (section.station < near || section.station > length - near) continue;"
assert old in s
s = s.replace(old, old + "\n    if (SPIKE_SKIP_ABOVE_IN > 0 && section.station > inchesToMm(SPIKE_SKIP_ABOVE_IN)) continue;")
open(p, "w").write(s); print("ok")

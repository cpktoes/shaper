# Fourth trial patch: the search a real build could ship ("safe"). Today's polish runs first, exactly as it is (the trial
# number held at its default); then four restarts with the number free; the answer is kept only when the SHOWN miss is no
# worse than today's polish. A file with no belly never enters the second step, so it opens exactly as today.
import sys
W = sys.argv[1]
p = f"{W}/lib/geometry/brd-bottom.ts"; s = open(p).read()
def sub(old, new):
    global s
    assert old in s, old[:70]
    s = s.replace(old, new, 1)
sub("  const polish = (specs: Specs): { specs: Specs; value: number } => {\n    let best = polishOnce(specs);\n    if (!SPIKE_STARTS) return best;",
'''  const polish = (specs: Specs): { specs: Specs; value: number; plain?: Specs } => {
    if (SPIKE_SEARCH === "safe") {
      const plain = polishOnce(specs, false);
      let best = plain;
      for (const key of ["center", "nose", "tail"] as const) {
        const cut = plain.specs[key];
        if (!carriesBellyShape(cutKind(cut.name), cut.name) || cut.depth <= 0) continue;
        const far = BELLY_SHAPE.max;
        const mid = BELLY_SHAPE.def + (far - BELLY_SHAPE.def) / 2;
        for (const k of [far, mid]) {
          for (const os of [mm(0), cut.offStringer]) {
            const got = polishOnce({ ...best.specs, [key]: { ...best.specs[key], bellyShape: k, offStringer: os } }, true);
            if (got.value < best.value - NOISE) best = got;
          }
        }
      }
      return { ...best, plain: plain.specs };
    }
    let best = polishOnce(specs);
    if (!SPIKE_STARTS) return best;''')
sub("  const polishOnce = (specs: Specs): { specs: Specs; value: number } => {", "  const polishOnce = (specs: Specs, withShape = true): { specs: Specs; value: number } => {")
sub('if (SPIKE_SEARCH !== "off" && carriesBellyShape(kind, specs[key].name)) fields.push', 'if (SPIKE_SEARCH !== "off" && withShape && carriesBellyShape(kind, specs[key].name)) fields.push')
sub('''  const { specs } = scorer.polish({ nose: bottom.nose, center: bottom.center, tail: bottom.tail });
  const polished = { ...bottom, nose: specs.nose, center: specs.center, tail: specs.tail };
  const shown = (b: BoardBottom): number => {
    const { largest, typical } = measureBrdBottom(b, sections, board0).closeness;
    return largest + typical;
  };''', '''  const { specs, plain } = scorer.polish({ nose: bottom.nose, center: bottom.center, tail: bottom.tail });
  const shown = (b: BoardBottom): number => {
    const { largest, typical } = measureBrdBottom(b, sections, board0).closeness;
    return largest + typical;
  };
  let polished = { ...bottom, nose: specs.nose, center: specs.center, tail: specs.tail };
  if (plain) {
    // SPIKE 003 ("safe"): the answer with the trial number is kept only when its shown miss is no worse than today's polish.
    const today = { ...bottom, nose: plain.nose, center: plain.center, tail: plain.tail };
    if (!(shown(polished) <= shown(today) + NOISE)) polished = today;
  }''')
open(p, "w").write(s); print("ok")

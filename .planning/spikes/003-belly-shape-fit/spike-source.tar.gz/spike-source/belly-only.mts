// The belly sections on their own: the grid answer's names kept, the score taken only over the sections behind CUT_IN
// (so the nose's own misses cannot pin a largest-gap score), every belly slider and the trial number polished from many starts.
import { readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
const ROOT = process.env.ROOT!;
const { readAnyBrd } = await import(`${ROOT}/lib/export/brd-read.ts`);
const { brdFitLookGrid } = await import(`${ROOT}/lib/export/brd-fit-preview.ts`);
const { brdFittedBottomBoard, brdBottomScorer, brdBottomBlends, measureBrdBottom } = await import(`${ROOT}/lib/geometry/brd-bottom.ts`);
const IN = 25.4;
const out: any = {};
for (const [name, cutIn] of [["92Log", 90], ["Scoop-Noserider", 60]] as const) {
  const read = readAnyBrd(new Uint8Array(readFileSync(`${homedir()}/Downloads/${name}.brd`)));
  const look = brdFitLookGrid(read.board);
  const board0 = brdFittedBottomBoard(look.fit, look.fins?.spec);
  const sub = look.bottom.sections.filter((s: any) => s.station < cutIn * IN);
  const scorer = brdBottomScorer(board0, brdBottomBlends(sub));
  const b = look.bottom.bottom;
  const t0 = performance.now();
  const { specs } = scorer.polish({ nose: b.nose, center: b.center, tail: b.tail });
  const m = measureBrdBottom({ ...b, ...specs }, sub, board0);
  const c = specs.center, t = specs.tail;
  console.log(`${name.padEnd(16)} sections behind ${cutIn}": widest ${m.closeness.largest.toFixed(2)} typical ${m.closeness.typical.toFixed(2)}  | centre ${c.name} ${(c.depth / IN).toFixed(3)}" panel ${(c.offStringer / IN).toFixed(2)}" shape ${c.bellyShape ?? "-"} · tail ${t.name} ${(t.depth / IN).toFixed(3)}"  (${((performance.now() - t0) / 1000).toFixed(1)} s)`);
  out[name] = { closeness: m.closeness, specs, sections: m.sections.map((s: any) => ({ station: s.station, reach: s.reach, window: s.window, across: s.across, file: s.file, ours: s.ours, gap: s.gap })) };
}
if (process.env.OUT) writeFileSync(process.env.OUT, JSON.stringify(out));

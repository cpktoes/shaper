# Applies the spike's trial code to the scratch worktree (never the app's own checkout).
import sys, re
W = sys.argv[1]
def sub(path, old, new, count=1):
    p = f"{W}/{path}"; s = open(p).read()
    assert s.count(old) >= 1, (path, old[:60])
    s = s.replace(old, new, count); open(p, "w").write(s)

B = "lib/geometry/bottom.ts"
# 1. the stored number and the read one
sub(B, "  /** A nose single that closes to a point toward the center (the Teardrop's, D-06 / D-32). */\n  closesToPoint: boolean;\n  /**\n   * How a double's trough",
       "  /** A nose single that closes to a point toward the center (the Teardrop's, D-06 / D-32). */\n  closesToPoint: boolean;\n  /** SPIKE 003: a belly's across-shape number. Absent reads the family's default, which draws today's belly exactly. */\n  bellyShape?: number;\n  /**\n   * How a double's trough")
sub(B, "  smoothness: number;\n  closesToPoint: boolean;\n  /** How a double's trough runs (D-01): the stored rule",
       "  smoothness: number;\n  closesToPoint: boolean;\n  /** SPIKE 003 */\n  bellyShape: number;\n  /** How a double's trough runs (D-01): the stored rule")
sub(B, "  if (kind === \"flat\") return { ...flatSpec(spec.name), section, kind, spiral: false,",
       "  if (kind === \"flat\") return { ...flatSpec(spec.name), section, kind, bellyShape: BELLY_SHAPE.def, spiral: false,")
sub(B, "    closesToPoint: spec.closesToPoint,\n    troughRun: spec.troughRun ?? \"parallel\",",
       "    closesToPoint: spec.closesToPoint,\n    bellyShape: spec.bellyShape ?? BELLY_SHAPE.def,\n    troughRun: spec.troughRun ?? \"parallel\",")
# 2. the trial families
sub(B, "/** The fade along the board, 0 to 1 (the sketch's `sm`). */", '''/**
 * SPIKE 003: the trial across-shape of a belly's lift. `g` is today's `rise(u, r)`, `u` the share of the way from the panel's
 * edge to the rail, `k` the shape number. At `def` each family returns `g` untouched (the caller skips the call), so a board
 * with no number stored draws today's belly to the last bit.
 *  - power:  g^k. Over 1 the middle stays flatter and the roll comes later and harder; under 1 it rolls from nearer the stringer.
 *  - blend:  (1 - k) g + k u^4. 0 is today's; 1 is a quartic: flat for most of the width, then up hard at the rail.
 *  - late:   (1 - k) g + k u^3. The same blend toward a cubic (the file's own measured power is about 3).
 */
const SPIKE_FAMILY = (typeof process !== "undefined" && process.env.SPIKE_FAMILY) || "none";
/** Which lifts carry the number: "belly" (the two belly names) or "lift" (every vee too, a pivot check). */
const SPIKE_KINDS = (typeof process !== "undefined" && process.env.SPIKE_KINDS) || "belly";
export const BELLY_SHAPE: { family: string; def: number; min: number; max: number; step: number; kinds: string } =
  SPIKE_FAMILY === "power" ? { family: "power", def: 1, min: 0.5, max: 3, step: 0.25, kinds: SPIKE_KINDS }
  : SPIKE_FAMILY === "blend" ? { family: "blend", def: 0, min: 0, max: 1, step: 0.125, kinds: SPIKE_KINDS }
  : SPIKE_FAMILY === "late" ? { family: "late", def: 0, min: 0, max: 1, step: 0.125, kinds: SPIKE_KINDS }
  : { family: "none", def: 0, min: 0, max: 0, step: 0, kinds: SPIKE_KINDS };
export const bellyShaped = (g: number, u: number, k: number): number =>
  BELLY_SHAPE.family === "power" ? Math.pow(g, k)
  : BELLY_SHAPE.family === "blend" ? (1 - k) * g + k * u * u * u * u
  : BELLY_SHAPE.family === "late" ? (1 - k) * g + k * u * u * u
  : g;
/** Whether a cut's lift carries the trial number. */
export const carriesBellyShape = (kind: string, name: string): boolean =>
  BELLY_SHAPE.family !== "none" && (kind === "belly" || (BELLY_SHAPE.kinds === "lift" && kind === "vee" && name !== "Tri-Plane Hull Center"));
/** The fade along the board, 0 to 1 (the sketch's `sm`). */''')
sub(B, "    const F = cut.offStringer; if (y > F && W > F) lift += cut.depth * f * rise((y - F) / (W - F), r);",
       '''    const F = cut.offStringer;
    if (y > F && W > F) {
      const u = (y - F) / (W - F);
      let g = rise(u, r);
      if (cut.bellyShape !== BELLY_SHAPE.def && carriesBellyShape(cut.kind, cut.name)) g = bellyShaped(g, u, cut.bellyShape);
      lift += cut.depth * f * g;
    }''')

F = "lib/geometry/brd-bottom.ts"
sub(F, "  BOTTOM_CUT_NAMES,\n", "  BELLY_SHAPE,\n  carriesBellyShape,\n  BOTTOM_CUT_NAMES,\n")
sub(F, "|${s.smoothness}|${s.closesToPoint}`;", "|${s.smoothness}|${s.closesToPoint}|${s.bellyShape ?? \"\"}`;")
# refine: the shape number searched on its own grid after the across marks (SPIKE_SEARCH=refine)
sub(F, "      if (!moved) break;\n    }\n    return { specs: { nose: s.nose.spec, center: s.center.spec, tail: s.tail.spec }, value: current };",
'''      if (SPIKE_SEARCH === "refine") {
        for (const key of keys) {
          if (!carriesBellyShape(cutKind(s[key].spec.name), s[key].spec.name)) continue;
          let bestValue = current;
          let bestSpec: BottomCutSpec | null = null;
          const steps0 = Math.round(s[key].spec.depth / DEPTH_STEP_MM);
          for (let k = BELLY_SHAPE.min; k <= BELLY_SHAPE.max + NOISE; k += BELLY_SHAPE.step) {
            for (const d of [steps0 - 2, steps0 - 1, steps0, steps0 + 1, steps0 + 2]) {
              if (d < 1 || d > DEPTH_STEPS) continue;
              for (const os of [null, 0]) {
                const spec: BottomCutSpec = { ...s[key].spec, bellyShape: k, depth: inchesToMm(d * BOTTOM_MARK_STEP_IN), ...(os === 0 ? { offStringer: mm(0) } : {}) };
                const v = trial(key, spec);
                if (v < bestValue - NOISE) { bestValue = v; bestSpec = spec; }
              }
            }
          }
          if (bestSpec && bestValue < current - BRD_BOTTOM_MOVE_GAIN_MM) { adopt(key, bestSpec, bestValue); moved = true; }
        }
      }
      if (!moved) break;
    }
    return { specs: { nose: s.nose.spec, center: s.center.spec, tail: s.tail.spec }, value: current };''')
# polish: the shape number as one more slider
sub(F, 'type PolishField = "start" | "deepest" | "end" | "depth" | "offRail" | "offStringer" | "troughAt";',
       'type PolishField = "start" | "deepest" | "end" | "depth" | "offRail" | "offStringer" | "troughAt" | "bellyShape";')
sub(F, "      for (const field of marks) fields.push({ key, field });\n    }\n    if (fields.length === 0)",
       "      for (const field of marks) fields.push({ key, field });\n      if (SPIKE_SEARCH !== \"off\" && carriesBellyShape(kind, specs[key].name)) fields.push({ key, field: \"bellyShape\" });\n    }\n    if (fields.length === 0)")
sub(F, "const x0 = fields.map(({ key, field }) => (isStation(field) ? resolveCut(key, specs[key], board)[field] : specs[key][field]) / IN);",
       "const x0 = fields.map(({ key, field }) => (field === \"bellyShape\" ? (specs[key].bellyShape ?? BELLY_SHAPE.def) * IN : isStation(field) ? resolveCut(key, specs[key], board)[field] : specs[key][field]) / IN);")
sub(F, "      isStation(field) ? BRD_BOTTOM_POLISH_STATION_IN : field === \"depth\" ? BRD_BOTTOM_POLISH_DEPTH_IN : BRD_BOTTOM_POLISH_MARK_IN,",
       "      field === \"bellyShape\" ? BELLY_SHAPE.step : isStation(field) ? BRD_BOTTOM_POLISH_STATION_IN : field === \"depth\" ? BRD_BOTTOM_POLISH_DEPTH_IN : BRD_BOTTOM_POLISH_MARK_IN,")
sub(F, "    const heldTo = (field: PolishField, inches: number): number => {\n      if (isStation(field))",
       "    const heldTo = (field: PolishField, inches: number, kind?: string): number => {\n      if (field === \"bellyShape\") return Math.min(BELLY_SHAPE.max, Math.max(BELLY_SHAPE.min, inches));\n      if (field === \"depth\" && kind === \"belly\" && SPIKE_BELLY_DEPTH_MAX_IN > 0) return Math.min(SPIKE_BELLY_DEPTH_MAX_IN * IN, Math.max(BOTTOM_MARK_STEP_IN * IN, inches * IN));\n      if (isStation(field))")
sub(F, "          const at = heldTo(field, x[i]);", "          const at = heldTo(field, x[i], cutKind(specs[key].name));")
sub(F, "spec = isStation(field) ? { ...base, ...storeCutStation(key, field, mm(at), board) } : { ...base, [field]: mm(at) };",
       "spec = isStation(field) ? { ...base, ...storeCutStation(key, field, mm(at), board) } : field === \"bellyShape\" ? (at === BELLY_SHAPE.def && base.bellyShape === undefined ? base : { ...base, bellyShape: at }) : { ...base, [field]: mm(at) };")
sub(F, "/** How far out the bottom is read: from the stringer to this share of the section's widest reach. */",
'''/** SPIKE 003: where the trial number is searched: "off", "polish" (names never change) or "refine" (the grid search too). */
const SPIKE_SEARCH = (typeof process !== "undefined" && process.env.SPIKE_SEARCH) || "off";
/** SPIKE 003 diagnostic only: a belly's Depth ceiling in the polish, inches (0 = today's 1/2"). */
const SPIKE_BELLY_DEPTH_MAX_IN = Number((typeof process !== "undefined" && process.env.SPIKE_BELLY_DEPTH_MAX_IN) || 0);
/** How far out the bottom is read: from the stringer to this share of the section's widest reach. */''')
print("patched")

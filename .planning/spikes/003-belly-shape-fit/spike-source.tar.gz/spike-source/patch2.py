# Second trial patch: a heavier, many-starts polish (a ceiling diagnostic: is it the search or the model?).
import sys
W = sys.argv[1]
p = f"{W}/lib/geometry/brd-bottom.ts"; s = open(p).read()
old = "  const polish = (specs: Specs): { specs: Specs; value: number } => {\n    const IN = inchesToMm(1);"
assert old in s
s = s.replace(old, '''  const polish = (specs: Specs): { specs: Specs; value: number } => {
    let best = polishOnce(specs);
    if (!SPIKE_STARTS) return best;
    // SPIKE 003: restart the polish from other shape numbers, with and without the panel, and at the deepest belly.
    for (const key of ["center", "nose", "tail"] as const) {
      if (!carriesBellyShape(cutKind(specs[key].name), specs[key].name) || specs[key].depth <= 0) continue;
      const n = 6;
      for (let i = 0; i <= n; i++) {
        const k = BELLY_SHAPE.min + ((BELLY_SHAPE.max - BELLY_SHAPE.min) * i) / n;
        for (const os of [specs[key].offStringer, mm(0)]) {
          for (const depth of [specs[key].depth, inchesToMm(BOTTOM_DEPTH_RANGE_IN.max)]) {
            const from: Specs = { ...best.specs, [key]: { ...best.specs[key], bellyShape: k, offStringer: os, depth } };
            const got = polishOnce(from);
            if (got.value < best.value - NOISE) best = got;
          }
        }
      }
    }
    return best;
  };
  const polishOnce = (specs: Specs): { specs: Specs; value: number } => {
    const IN = inchesToMm(1);''')
old = "/** SPIKE 003 diagnostic only: a belly's Depth ceiling"
s = s.replace(old, "/** SPIKE 003: the polish restarted from many shape numbers (a ceiling check, slow). */\nconst SPIKE_STARTS = Boolean(typeof process !== \"undefined\" && process.env.SPIKE_STARTS);\n" + old)
open(p, "w").write(s); print("ok")

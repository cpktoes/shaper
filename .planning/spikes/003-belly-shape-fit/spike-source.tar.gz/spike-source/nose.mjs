// A pointer, off line (not through the import): the nose sections that pin the widest miss. One single concave on its own,
// today's across-curve (Smoothness and Off Rail free) against a plain power curve u^p out to the cut's edge.
import { readFileSync } from "node:fs";
const rows = JSON.parse(readFileSync(process.argv[2], "utf8")); const IN = 25.4;
const sec = (u, r) => (1 - r) * (1 - u) + r * (1 + Math.cos(Math.PI * u)) / 2;
const fit = (s, g, ks) => { let b = { v: 1e9 };
  for (const k of ks) for (let C = s.reach * 0.4; C <= s.reach; C += s.reach * 0.02) for (let d = 0.5; d <= 12.7; d += 0.1) {
    let mx = 0, sum = 0; s.across.forEach((y, j) => { const o = y < C ? -d * g(y / C, k) : -d; const e = Math.abs(s.file[j] - o); sum += e; if (e > mx) mx = e; });
    if (mx + sum / 25 < b.v) b = { v: mx + sum / 25, mx, typ: sum / 25, k, C, d }; }
  return b; };
const pick = { "Scoop-Noserider": [73.7, 85.7, 97.7], "testLB": [90.0, 93.0, 96.0], "92Log": [94.5] };
for (const r of rows) for (const s of r.sections) { const st = s.station / IN; if (!pick[r.name]?.some((p) => Math.abs(p - st) < 0.3)) continue;
  const a = fit(s, (u, r) => 1 - sec(u, r), Array.from({ length: 21 }, (_, i) => i / 20));
  const b = fit(s, (u, p) => u ** p, Array.from({ length: 31 }, (_, i) => 1 + i * 0.1));
  console.log(`${r.name} st ${st.toFixed(1)}": in the import today ${s.gap.largest.toFixed(2)} | one concave alone, today's curve: widest ${a.mx.toFixed(2)} typical ${a.typ.toFixed(2)} (smoothness ${(a.k * 100).toFixed(0)}) | power curve: widest ${b.mx.toFixed(2)} typical ${b.typ.toFixed(2)} (power ${b.k.toFixed(1)})`); }

// Scratch (16-03, Task 3): writes surface.html — the mock-up's page (build-mock.js) with its own loft replaced
// by the REAL surface: renderMesh(buildBoardSurface(...)) and stringerLines, from surface-<board>.json.
// Lights, foam and camera framing are the mock's, as the founder approved them; no fins (16-06 adds them).
// The surface is in Shape3D's axes (x along from the tail, y across, z up); three.js here is y up with the
// nose along +z, so each point (x, y, z) is drawn at (y, z, x) — a cyclic swap, a rotation, so the winding
// (and FrontSide culling) is kept: a face wound the wrong way would show as a hole.
// URL: ?board=fish|shortboard&view=deck|deck34|bottom|side|tailbottom&w=1280&h=800
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2]; // the output directory, holding surface-*.json
const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>3D surface</title>
<style>html,body{margin:0;height:100%;background:#f3efe6}canvas{display:block}</style>
<script type="importmap">{"imports":{"three":"http://mock.local/three/three.module.js"}}</script>
</head><body>
<script type="module">
import * as THREE from "three";
const q = new URLSearchParams(location.search);
const DATA = await (await fetch("http://mock.local/surface-" + (q.get("board") || "fish") + ".json")).json();
const view = q.get("view") || "deck34";
const W = +(q.get("w") || 1280), H = +(q.get("h") || 800);
const bg = q.get("bg") || "#f3efe6";

// The surface's own vertices, normals and triangles, moved into three's axes.
const P = DATA.positions, N = DATA.normals;
const pos = new Float32Array(P.length), nor = new Float32Array(N.length);
for (let i = 0; i < P.length; i += 3) {
  pos[i] = P[i + 1]; pos[i + 1] = P[i + 2]; pos[i + 2] = P[i];
  nor[i] = N[i + 1]; nor[i + 1] = N[i + 2]; nor[i + 2] = N[i];
}
const geo = new THREE.BufferGeometry();
geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
geo.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
geo.setIndex(DATA.indices);
geo.computeBoundingBox();
const bb = geo.boundingBox, centre = new THREE.Vector3(); bb.getCenter(centre);

// ---- scene, foam, lights (the mock's)
const scene = new THREE.Scene(); scene.background = new THREE.Color(bg);
const foam = new THREE.MeshStandardMaterial({ color: 0xf7f4ec, roughness: 0.92, metalness: 0.0, side: THREE.FrontSide });
const board = new THREE.Mesh(geo, foam);
const group = new THREE.Group(); group.add(board);
// the stringer, from stringerLines: lifted a hair off the deck and the bottom so it shows
const lineOf = (pts, lift) => new THREE.BufferGeometry().setFromPoints(pts.map((p) => new THREE.Vector3(p[1], p[2] + lift, p[0])));
const lineMat = new THREE.LineBasicMaterial({ color: 0x5a4a3a });
group.add(new THREE.Line(lineOf(DATA.stringer.deck, 0.4), lineMat));
group.add(new THREE.Line(lineOf(DATA.stringer.bottom, -0.4), lineMat));
group.position.sub(centre);
scene.add(group);
const side1 = new THREE.DirectionalLight(0xfff3e0, 2.6); side1.position.set(1400, 90, 150); scene.add(side1);
const side2 = new THREE.DirectionalLight(0xfff3e0, 2.0); side2.position.set(-1400, 60, -250); scene.add(side2);
const over = new THREE.HemisphereLight(0xffffff, 0xe6e0d2, 0.9); scene.add(over);
const bounce = new THREE.DirectionalLight(0xfff8ee, 0.7); bounce.position.set(200, -1400, 300); scene.add(bounce);
scene.add(new THREE.AmbientLight(0xffffff, 0.3));

// ---- camera and views (the mock's)
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(2); renderer.setSize(W, H); document.body.appendChild(renderer.domElement);
const camera = new THREE.PerspectiveCamera(32, W / H, 10, 20000);
const L = DATA.length;
const views = {
  deck34: [1500, 1300, -1900], bottom34: [1500, -1300, -1900], side: [2600, 120, 0], deck: [0.001, 2600, 0.001],
  bottom: [0.001, -2600, 0.001], tailbottom: [900, -1100, -2300],
};
const targets = { tailbottom: [0, 0, -L * 0.28] };
const v = views[view] || views.deck34; camera.position.set(v[0], v[1], v[2]);
const tg = targets[view] || [0, 0, 0];
if (view === "deck" || view === "bottom") camera.up.set(0, 0, 1); // nose up the screen in the plan views
const fit = (L * 1.08) / (2 * Math.tan((camera.fov * Math.PI) / 360));
const dist = fit / Math.min(1, W / H) * (view === "side" || view === "deck" || view === "bottom" ? 1.0 : 0.78);
camera.position.setLength(dist * (view === "tailbottom" ? 0.55 : 1));
if (view === "tailclose" || view === "tailend") {
  // Close on the tail end itself, from behind and below (tailclose) or straight behind (tailend).
  const t = new THREE.Vector3(0, -centre.y * 0.2, -L * 0.47);
  const d = new THREE.Vector3(...(view === "tailclose" ? [500, -650, -1300] : [0, -120, -1500])).normalize();
  camera.position.copy(t.clone().add(d.multiplyScalar(view === "tailclose" ? 820 : 760)));
  camera.up.set(0, 1, 0);
  camera.lookAt(t);
} else camera.lookAt(tg[0], tg[1], tg[2]);
renderer.render(scene, camera);
window.__done = true;
</script></body></html>`;
fs.writeFileSync(path.join(dir, "surface.html"), html);
console.log("wrote surface.html");

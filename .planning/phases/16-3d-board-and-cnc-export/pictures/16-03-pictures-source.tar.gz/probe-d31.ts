// Scratch (16-03, D-31): what "the litres' area at a fading station IS the area of the ring the surface draws"
// does (a) to the fade's continuity at its two ends, and (b) to the mesh-vs-litres gap, against an alternative
// that keeps both ends level: ring area + the two end sections' own polyline shortfalls blended by the weight.
// No app file is edited; the litres under each rule are today's plus Simpson over the changed station areas.
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const RB = await import(`${ROOT}/lib/geometry/rail-bands`);
  const B = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const ringArea = (section: any, half?: [number, number][]) => {
    const h = half ?? S.placedHalfSection(section, section.halfWidth, 0);
    let a = 0;
    for (let i = 0; i < h.length; i++) {
      const p = h[i], q = h[(i + 1) % h.length];
      a += p[0] * q[1] - q[0] * p[1];
    }
    return Math.abs(a); // both rails: 2 × half the shoelace sum
  };
  const one = (w: number) => ({ ...V.HARD_EDGE_FADE, weight: () => w });
  let worstStep = 0;
  const rows: string[] = [];
  for (const board of B.phase16Boards().filter((b: any) => b.label.endsWith("|hard"))) {
    for (const [name, from, toCentre] of [["default", undefined, false], ["12→centre", 12, true], ["30→centre", 30, true]] as const) {
      const L = board.fields.outline.length;
      const rails0 = { ...board.fields.rails } as any;
      if (from !== undefined) rails0.tailHardEdgeBlendsFrom = U.inchesToMm(from);
      if (toCentre) rails0.tailHardEdgeEndsAt = L / 2;
      const fields = { ...board.fields, rails: rails0 };
      const geometry = O.buildOutline(fields.outline);
      const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
      const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, true);
      const input = D.designCrossSectionInput(geometry, profile, rails, L);
      // (a) the step at each end of the fade under the strict rule
      const bf = RB.hardEdgeBlendsFrom(rails, L), ea = RB.hardEdgeEndsAt(rails, L);
      for (const [a, b] of [[bf, bf + 1e-4], [ea - 1e-4, ea]]) {
        const [left, right] = V.boardSections(input, [a, b]);
        const areaOf = (s: any) => (s.hardWeight > 0 && s.hardWeight < 1 ? ringArea(s) : s.area);
        const step = Math.abs(areaOf(left) - areaOf(right)) / left.area;
        worstStep = Math.max(worstStep, step);
      }
      // (b) the gap under each rule
      const vol = V.computeCrossSectionVolume(input);
      const sections = V.boardSections(input);
      const cut = input.cutStation ?? 0;
      const m = cut > 0 && cut < L ? vol.stations.indexOf(cut) : 0;
      const h = (L - (m > 0 ? cut : 0)) / (V.SIMPSON_PANEL_COUNT - m);
      let dStrict = 0, dLevel = 0;
      sections.forEach((s: any, i: number) => {
        if (!(s.hardWeight > 0 && s.hardWeight < 1)) return;
        if (i <= m) throw new Error("fade reaches the cut");
        const k = i - m, n = V.SIMPSON_PANEL_COUNT - m;
        const wt = (k === 0 || k === n ? 1 : k % 2 ? 4 : 2) * (h / 3);
        const ring = ringArea(s);
        const [t] = V.boardSectionsWith(input, one(0), [s.station]);
        const [hd] = V.boardSectionsWith(input, one(1), [s.station]);
        const dt = t.area - ringArea(t), dh = hd.area - ringArea(hd);
        const level = ring + (1 - s.hardWeight) * dt + s.hardWeight * dh;
        dStrict += wt * (ring - s.area);
        dLevel += wt * (level - s.area);
      });
      const surface = S.buildBoardSurface({ sections: input, geometry, rockerAt: profile.rockerAt });
      const mesh = S.enclosedVolumeMm3(surface);
      const g = (v: number) => ((100 * (mesh - v)) / v).toFixed(3) + "%";
      rows.push(`${board.label} ${name}: today ${g(vol.volumeMm3)} | strict ${g(vol.volumeMm3 + dStrict)} (litres ${(dStrict / 1e6).toFixed(4)} L) | level ${g(vol.volumeMm3 + dLevel)} (litres ${(dLevel / 1e6).toFixed(4)} L)`);
    }
  }
  rows.forEach((r) => console.log(r));
  console.log(`worst relative step at a fade end under the strict rule: ${worstStep.toExponential(2)} (the test asks < 1e-6)`);
})();

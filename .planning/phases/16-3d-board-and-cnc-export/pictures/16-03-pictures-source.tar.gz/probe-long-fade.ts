// Scratch (16-03 D-30 follow-up): the mesh-vs-litres gap on the hard-edged boards at the fade's widest settings
// (blends from 12", ends at the centre) and at the defaults, to see how close the long fade comes to −0.15%.
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const B = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  for (const board of B.phase16Boards().filter((b: any) => b.label.endsWith("|hard"))) {
    const out: string[] = [board.label];
    for (const [name, from, endsHalf] of [["default", undefined, false], ["12in-to-centre", 12, true], ["30in-to-centre", 30, true]] as const) {
      const L = board.fields.outline.length;
      const rails = { ...board.fields.rails } as any;
      if (from !== undefined) rails.tailHardEdgeBlendsFrom = U.inchesToMm(from);
      if (endsHalf) rails.tailHardEdgeEndsAt = L / 2;
      const fields = { ...board.fields, rails };
      const geometry = O.buildOutline(fields.outline);
      const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
      const eff = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, true);
      const sections = D.designCrossSectionInput(geometry, profile, eff, L);
      const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
      const litres = V.computeCrossSectionVolume(sections).volumeLitres;
      const gap = (100 * (S.enclosedVolumeMm3(surface) / 1e6 - litres)) / litres;
      out.push(`${name} ${gap.toFixed(3)}%`);
    }
    console.log(out.join(" | "));
  }
})();

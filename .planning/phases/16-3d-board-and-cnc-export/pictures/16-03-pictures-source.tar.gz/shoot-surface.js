// Scratch (16-03, Task 3): shoots surface.html in headless Chromium (software WebGL), the mock's shoot-mock.js
// pattern. Every request to http://mock.local/ is answered from disk by Playwright itself — no server, no port.
// node shoot-surface.js <abs out dir> <abs three build dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const threeDir = process.argv[3];
const views = (process.argv[4] || "deck,deck34,bottom,side,tailbottom,tailclose,tailend").split(",");
const types = { ".html": "text/html", ".js": "text/javascript", ".json": "application/json" };
(async () => {
  const browser = await chromium.launch({ args: ["--use-angle=swiftshader-webgl", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  for (const board of ["fish", "shortboard"]) {
    for (const view of views) {
      const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
      await page.route("http://mock.local/**", async (route) => {
        const p = new URL(route.request().url()).pathname;
        const file = p.startsWith("/three/") ? path.join(threeDir, p.slice("/three/".length)) : path.join(dir, p.slice(1));
        if (!fs.existsSync(file)) return route.fulfill({ status: 404, body: "missing " + p });
        await route.fulfill({ status: 200, contentType: types[path.extname(file)] || "application/octet-stream", body: fs.readFileSync(file) });
      });
      page.on("console", (m) => { if (m.type() === "error") console.log("console error:", m.text()); });
      page.on("pageerror", (e) => console.log("page error:", e.message));
      await page.goto(`http://mock.local/surface.html?board=${board}&view=${view}&w=1280&h=800`);
      await page.waitForFunction(() => window.__done === true, null, { timeout: 120000 });
      const out = path.join(dir, `surface-${board}-${view}.png`);
      await page.screenshot({ path: out });
      console.log(board, view, "->", out);
      await page.close();
    }
  }
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

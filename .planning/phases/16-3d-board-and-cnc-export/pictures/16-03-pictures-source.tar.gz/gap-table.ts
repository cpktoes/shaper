// Scratch (16-03): the gap table for the SUMMARY — per board of the 40-board set: the mesh's litres, VOLUME's
// litres, the gap, vertices, triangles and the build time in Node (median of 5 builds, after one warm-up).
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <abs this> <abs worktree>
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const R = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const B = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const rows: string[] = [];
  let worst = 0;
  let worstLabel = "";
  let maxGap = -Infinity;
  for (const board of B.phase16Boards()) {
    const geometry = O.buildOutline(board.fields.outline);
    const profile = D.designSideProfile(board.fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(board.fields.rails, profile.effectiveFoil, board.fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, board.fields.outline.length);
    const input = { sections, geometry, rockerAt: profile.rockerAt };
    S.buildBoardSurface(input); // warm-up
    const times: number[] = [];
    let surface: any;
    for (let k = 0; k < 5; k++) {
      const t0 = performance.now();
      surface = S.buildBoardSurface(input);
      times.push(performance.now() - t0);
    }
    times.sort((a, b) => a - b);
    const t1 = performance.now();
    R.renderMesh(surface);
    const renderMs = performance.now() - t1;
    const litres = V.computeCrossSectionVolume(sections).volumeLitres;
    const mesh = S.enclosedVolumeMm3(surface) / 1e6;
    const gap = (100 * (mesh - litres)) / litres;
    if (gap < worst) {
      worst = gap;
      worstLabel = board.label;
    }
    maxGap = Math.max(maxGap, gap);
    const check = S.meshCheck(surface);
    rows.push(
      `| ${board.label.replaceAll("|", " · ")} | ${mesh.toFixed(4)} | ${litres.toFixed(4)} | ${gap.toFixed(3)}% | ${surface.positions.length / 3} | ${surface.triangleCount} | ${times[2].toFixed(0)} | ${renderMs.toFixed(0)} | ${check.openEdges + check.nonManifoldEdges + check.misWoundEdges + check.zeroAreaTriangles} |`,
    );
  }
  console.log("| Board | Mesh (L) | VOLUME (L) | Gap | Vertices | Triangles | Build ms | renderMesh ms | Mesh faults |");
  console.log("|---|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const r of rows) console.log(r);
  console.log(`\nworst gap ${worst.toFixed(3)}% (${worstLabel}); largest (closest to 0) ${maxGap.toFixed(3)}%`);
})();

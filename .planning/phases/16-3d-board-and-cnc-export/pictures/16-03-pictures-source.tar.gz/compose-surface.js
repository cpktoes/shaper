// Scratch (16-03, Task 3): composes the shots into one captioned picture for the founder (the mock's compose.js).
// node compose-surface.js <abs out dir> <abs output png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const out = process.argv[3];
const img = (b, v) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `surface-${b}-${v}.png`)).toString("base64");
const info = (b) => JSON.parse(fs.readFileSync(path.join(dir, `surface-${b}.json`), "utf8"));
const fish = info("fish");
const sb = info("shortboard");
const pct = (d) => ((100 * (d.meshLitres - d.litres)) / d.litres).toFixed(3);
const rows = [
  ["deck", "Deck, straight down", "The outline as TEMPLATE draws it, the stringer nose to tail.", "The outline as TEMPLATE draws it, the squash tail's flat end."],
  ["deck34", "Deck, three-quarter — the view the screen opens on", "The side tubes rake across the deck and the rails.", "The side tubes rake across the deck and the rails."],
  ["bottom", "Bottom, straight up", "The swallow's two points with the notch between them; the stringer starts at the crotch.", "Flat across every section, exactly as designed; the stringer runs over the tail end."],
  ["side", "Side", "The rocker and the foil as ROCKER draws them, now as a solid.", "The rocker and the foil as ROCKER draws them, now as a solid."],
  ["tailbottom", "The tail from below", "The hard edge full to the 12\" mark, easing into the tucked rail by 18\".", "The hard edge full to the 12\" mark, easing into the tucked rail by 18\"."],
  ["tailclose", "The tail end, close, from below", "Two pieces, each with a square inner wall from the notch edge to the rail, meeting at the crotch.", "The squash tail's end, closed flat; the bottom edge stays crisp along the rail."],
];
const fig = (b, v, cap) => `<figure><img src="${img(b, v)}"><figcaption>${cap}</figcaption></figure>`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1480px;line-height:1.45}
h2{font-size:17px;margin:18px 36px 8px}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:0 24px;padding:0 36px}.cols h3{margin:6px 0 4px;font-size:18px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 24px;padding:0 36px 14px}
figure{margin:0;background:#f3efe6;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden}
figure img{display:block;width:100%;height:auto}figcaption{padding:8px 12px 10px;font-size:14px;line-height:1.4;background:#fff;border-top:1px solid #e5e1d6}
.end{display:grid;grid-template-columns:1fr 1fr;gap:24px;padding:0 36px 36px;align-items:start}.end p{font-size:15px;line-height:1.5;color:#374151;margin:6px 0}
</style></head><body>
<h1>Phase 16, plan 03 — the real 3D surface, under the mock-up's lights</h1>
<p class="lead">This is no longer the mock-up's loft. Every triangle here is the surface the 3D screen and the CNC files will read: VOLUME's own cross-sections at every half inch (and at each of the litres' own stations), placed on the outline and the rocker and joined into one closed skin. Lights, foam and framing are the mock-up you approved; no fins yet (they come with the screen). The Fish's skin holds ${fish.meshLitres.toFixed(2)} L against VOLUME's ${fish.litres.toFixed(2)} L (${pct(fish)}%); the Shortboard's ${sb.meshLitres.toFixed(2)} L against ${sb.litres.toFixed(2)} L (${pct(sb)}%) — a hair under, never over.</p>
<div class="cols"><h3>Fish (as its card opens: swallow, Hard Edge on)</h3><h3>Shortboard (as its card opens: squash, Hard Edge on)</h3></div>
${rows.map(([v, title, cf, cs]) => `<h2>${title}</h2><div class="grid">${fig("fish", v, cf)}${fig("shortboard", v, cs)}</div>`).join("\n")}
<h2>The Fish's tail end, straight from behind</h2>
<div class="end">${fig("fish", "tailend", "The two pieces at full thickness, each inner wall square and upright, the two walls meeting along one edge at the crotch — never a V from the stringer out.")}<div><p>What to look at: the Fish's tail is two pieces with square walls; the hard edge has no step where it starts to fade; the rails read as one smooth surface, not facets; the bottom edge is crisp where it is meant to be; the side reads like ROCKER's.</p></div></div>
</body></html>`;
fs.writeFileSync(path.join(dir, "compose-surface.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(dir, "compose-surface.html"));
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

// Scratch (16-03, Task 3): dumps the REAL surface for the Fish and the Shortboard, as their cards open them,
// for the mock-up's lights: renderMesh(buildBoardSurface(...)) and stringerLines, as JSON.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <abs this> <abs worktree> <abs out dir>
import { writeFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const R = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  for (const id of ["fish", "shortboard"]) {
    const preset = P.BOARD_PRESETS.find((p: any) => p.id === id);
    const fields = PB.presetDesignFields(preset);
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, true);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
    const mesh = R.renderMesh(surface);
    const stringer = R.stringerLines(surface);
    const litres = V.computeCrossSectionVolume(sections).volumeLitres;
    const meshLitres = S.enclosedVolumeMm3(surface) / 1e6;
    const round = (a: ArrayLike<number>, d: number) => Array.from(a, (x) => +x.toFixed(d));
    const data = {
      id,
      name: preset.name ?? id,
      length: surface.length,
      tailHardEdge: rails.tailHardEdge,
      tail: fields.outline.tail,
      litres,
      meshLitres,
      check: S.meshCheck(surface),
      slices: S.boardSlices(surface).length,
      positions: round(mesh.positions, 3),
      normals: round(mesh.normals, 5),
      indices: Array.from(mesh.indices),
      stringer,
    };
    writeFileSync(join(OUT, `surface-${id}.json`), JSON.stringify(data));
    console.log(id, "vertices", mesh.positions.length / 3, "triangles", mesh.indices.length / 3, "litres", litres.toFixed(3), "mesh", meshLitres.toFixed(3), JSON.stringify(data.check), "tail", JSON.stringify(fields.outline.tail), "hard", rails.tailHardEdge);
  }
})();

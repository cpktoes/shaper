// Scratch: where a board's deck sits under deckAt between the 12" stations, and why.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <abs this> <abs worktree> <label>
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const F = await import(`${ROOT}/lib/geometry/foil`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const FR = await import(`${ROOT}/lib/geometry/finished-rail`);
  const B = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const board = B.phase16Boards().find((b: any) => b.label === process.argv[3]);
  const geometry = O.buildOutline(board.fields.outline);
  const profile = D.designSideProfile(board.fields, D.LIVE_DESIGN_RULES);
  const rails = D.deriveEffectiveRails(board.fields.rails, profile.effectiveFoil, true);
  const sections = D.designCrossSectionInput(geometry, profile, rails, board.fields.outline.length);
  const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
  const a = F.foilStationPoints(sections.foil, sections.length);
  const { deck } = S.boardProfileLines(surface);
  surface.rings.forEach((r: any, i: number) => {
    if (r.station < a[1].station || r.station > a[3].station) return;
    const d = profile.deckAt(r.station) - deck[i][2];
    if (Math.abs(d) > 1e-6) {
      const [sec] = V.boardSections(sections, [r.station]);
      const fr = FR.sectionFinishedRail(sec.result, sec.domed);
      console.log(
        (r.station / 25.4).toFixed(3), "in", "gap", d.toFixed(4), "hw", sec.halfWidth.toFixed(2),
        "x0", fr.samples[0].x.toFixed(2), "y0", fr.samples[0].y.toFixed(3), "T", sec.thickness.toFixed(3),
        "domed", sec.domed, "deckY", deck[i][1].toFixed(3),
      );
    }
  });
})();

// Scratch (16-03, D-31): appends the D-31 (level variant) column to the D-30 40-board table in 16-01-SUMMARY.md,
// every figure from the app's own functions (the live litres of a board that says nothing), and prints the four
// presets as their cards open them plus the stock board, for the 16-02 note.
// Run: npx --no-install tsx --tsconfig <WT>/tsconfig.json <this file> <WT> <abs 16-01-SUMMARY.md>
import { readFileSync, writeFileSync } from "node:fs";

const WT = process.argv[2];
const SUMMARY = process.argv[3];

async function main() {
  const { phase16Boards } = await import(`${WT}/lib/geometry/__fixtures__/phase16-boards.ts`);
  const { summarizeDesign } = await import(`${WT}/lib/geometry/design.ts`);
  const { BOARD_PRESETS } = await import(`${WT}/lib/geometry/presets.ts`);
  const { presetDesignFields } = await import(`${WT}/lib/blanks/preset-blanks.ts`);
  const { DEFAULT_BOARD_SPEC } = await import(`${WT}/lib/geometry/board.ts`);
  const { DEFAULT_RAIL_BAND_SPEC } = await import(`${WT}/lib/geometry/rail-bands.ts`);
  const { DEFAULT_VOLUME_SPEC } = await import(`${WT}/lib/geometry/volume.ts`);

  const live = new Map<string, number>();
  for (const board of phase16Boards()) live.set(board.label.replaceAll("|", " · "), summarizeDesign(board.fields).volumeLitres);

  const lines = readFileSync(SUMMARY, "utf8").split("\n");
  const start = lines.findIndex((l) => l.startsWith("## D-30 update"));
  let rows = 0;
  for (let i = start; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith("## ") && i > start) break;
    if (l.startsWith("| Board | Length | Default end | Today (L)")) {
      lines[i] = l.replace("| D-30 default — live (L) |", "| D-30 default, the two areas blended (L) |") + " D-31 (level variant) — live (L) |";
    } else if (l.startsWith("|---|---:|---:|---:|---:|---:|---:|") && !l.endsWith("---:|---:|---:|---:|---:|---:|---:|---:|")) {
      lines[i] = l + "---:|";
    } else if (l.startsWith("| ") && live.has(l.split("|")[1].trim())) {
      lines[i] = l + ` ${live.get(l.split("|")[1].trim())!.toFixed(4)} |`;
      rows++;
    }
  }
  if (rows !== 40) throw new Error(`expected 40 rows, found ${rows}`);
  writeFileSync(SUMMARY, lines.join("\n"));
  console.log("appended the D-31 column to", rows, "rows");

  for (const preset of BOARD_PRESETS) {
    const fields = { ...presetDesignFields(preset), railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
    console.log(`${preset.id}: ${summarizeDesign(fields).volumeLitres.toFixed(4)} L (hard edge ${fields.rails.tailHardEdge})`);
  }
  const stock = {
    outline: DEFAULT_BOARD_SPEC.outline,
    rocker: DEFAULT_BOARD_SPEC.rocker,
    rails: DEFAULT_RAIL_BAND_SPEC,
    foil: DEFAULT_BOARD_SPEC.foil,
    railsImportFoilThickness: true,
    volume: DEFAULT_VOLUME_SPEC,
  };
  console.log(`stock 6'0": ${summarizeDesign(stock).volumeLitres.toFixed(4)} L`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

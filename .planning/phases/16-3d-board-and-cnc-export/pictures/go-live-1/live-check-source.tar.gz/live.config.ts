import { defineConfig } from "@playwright/test";
export default defineConfig({ testDir: __dirname, timeout: 90_000, retries: 0, reporter: "line", use: { headless: true } });

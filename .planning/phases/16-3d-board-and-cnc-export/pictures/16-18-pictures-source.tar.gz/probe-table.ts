import { AT_REST, BAY, bayLens, boardPlace, rackSeat, rackTurn, raiseOfLift, railSightDeg, standAt, overPad, type RackAngles } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/shaping-bay";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";
import { buildBoardSurface, type Vec3 } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { BOARD_TO_ROOM, framePointsOf, quatMultiply, rotateVec } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/view-3d";
import { inchesToMm, mm, mmToInches } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/units";

const rows: [string, string, number?][] = [
  ["Shortboard", "shortboard|asis|hard"],
  ["Fish", "fish|asis|hard"],
  ["Mid-length", "midlength|asis|hard"],
  ["Longboard", "longboard|asis|soft"],
  ['120"', "longboard|asis|soft", inchesToMm(120)],
];
const sizes: [string, number, number][] = [["computer", 804, 615], ["820 x 800", 482, 700], ["Pixel 7", 402, 523], ["iPhone 14", 380, 407], ["320", 288, 330], ["sideways", 482, 312]];
for (const [name, label, len] of rows) {
  const board = phase16Boards().find((b) => b.label === label)!;
  const fields = len ? { ...board.fields, outline: { ...board.fields.outline, length: mm(len) } } : board.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length), geometry, rockerAt: profile.rockerAt });
  const { points } = framePointsOf(surface.positions);
  const seat = rackSeat(points);
  const range = (a: RackAngles) => {
    const place = boardPlace(points, a, seat);
    const q = quatMultiply(rackTurn(a), BOARD_TO_ROOM);
    let lo = Infinity;
    let hi = -Infinity;
    for (const p of points) {
      const y = rotateVec(q, p as Vec3)[1] + place[1];
      lo = Math.min(lo, y);
      hi = Math.max(hi, y);
    }
    return `${lo.toFixed(0)}/${hi.toFixed(0)}`;
  };
  const lift = [30, 45, 60].map((l) => `${l}: ${range({ ...AT_REST, lift: l })}, ${mmToInches(raiseOfLift(l, seat)).toFixed(1)}"`).join(" ");
  const tail = [30, 45, 60].map((l) => range({ ...AT_REST, lift: -l })).join(" ");
  console.log(`${name}: racks ${(2 * seat.at).toFixed(0)} apart; home ${(BAY.rackTopMm + seat.home).toFixed(0)}; ${lift}; tail ${tail}; roll45 +${(overPad(seat, 45) - seat.home).toFixed(0)} roll90 +${(overPad(seat, 90) - seat.home).toFixed(0)}; flipped ${(overPad(seat, 180) - seat.home).toFixed(0)}`);
  const lens = sizes.map(([n, w, h]) => {
    const l = bayLens(points, seat, w / h);
    return `${n} ${l.distanceMm.toFixed(0)}@${l.lensDeg.toFixed(1)}`;
  });
  console.log("   ", lens.join(" | "));
  const l0 = bayLens(points, seat, 804 / 615);
  console.log("    rail sight from the tail", railSightDeg(surface.width / 2, standAt("tail", 0), l0).toFixed(2), "from the nose", railSightDeg(surface.width / 2, standAt("nose", 0), l0).toFixed(2));
}

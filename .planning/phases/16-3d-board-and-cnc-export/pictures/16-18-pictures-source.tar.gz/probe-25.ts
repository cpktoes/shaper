// Scratch: real clearances at the full Look Down the Rail, on the presets and a 120" board.
import { BAY, bayLens, boardPlace, clampViewer, rackSeat, rackTurn, standAt, viewerPlace, SIGHT_LIMIT_DEG, type RackAngles } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/shaping-bay";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { phase16FinCases } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-fin-cases";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";
import { buildBoardSurface, type Vec3 } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { BOARD_TO_ROOM, framePointsOf, quatMultiply, rotateVec } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/view-3d";
import { placedFins } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/fin-outline";
import { inchesToMm, mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/units";

const L = SIGHT_LIMIT_DEG;
const SWINGS = [L, -L, 180 + L, 180 - L];
const pad = (p: Vec3, at: number) =>
  Math.min(BAY.padHalfSpanMm - Math.abs(p[2]), BAY.padHalfDepthMm - Math.abs(Math.abs(p[0]) - at), BAY.rackTopMm - p[1], p[1] - (BAY.rackTopMm - 50));
const post = (p: Vec3, at: number) => Math.min(30 - Math.abs(p[2]), 30 - Math.abs(Math.abs(p[0]) - at), BAY.rackTopMm - 50 - p[1], p[1]);
const room = (p: Vec3, a: RackAngles, place: Vec3): Vec3 => {
  const r = rotateVec(quatMultiply(rackTurn(a), BOARD_TO_ROOM), p);
  return [r[0] + place[0], r[1] + place[1], r[2] + place[2]];
};

const rows: [string, string, number?][] = [
  ["Shortboard", "shortboard|asis|hard"],
  ["Fish", "fish|asis|hard"],
  ["Mid-length", "midlength|asis|hard"],
  ["Longboard", "longboard|asis|soft"],
  ['120"', "longboard|asis|soft", inchesToMm(120)],
];
const ASPECTS = [804 / 615, 482 / 700, 402 / 523, 380 / 407, 288 / 330, 482 / 312];
const cases = phase16FinCases();

for (const [name, label, len] of rows.filter((r) => !process.env.ONLY || r[0].startsWith(process.env.ONLY))) {
  const board = phase16Boards().find((b) => b.label === label)!;
  const fields = len ? { ...board.fields, outline: { ...board.fields.outline, length: mm(len) } } : board.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length), geometry, rockerAt: profile.rockerAt });
  const { centre, points } = framePointsOf(surface.positions);
  const all: Vec3[] = [];
  for (let v = 0; v < surface.positions.length / 3; v++) all.push([surface.positions[3 * v] - centre[0], surface.positions[3 * v + 1] - centre[1], surface.positions[3 * v + 2] - centre[2]]);
  const seat = rackSeat(points);

  let deepest = -Infinity;
  let at = "";
  let lowest = Infinity;
  for (const swing of SWINGS) {
    for (let lift = -60; lift <= 60; lift += 15) {
      for (let roll = -180; roll < 180; roll += 30) {
        const a = { swing, lift, roll };
        const place = boardPlace(all, a, seat);
        for (const p of all) {
          const r = room(p, a, place);
          const d = Math.max(pad(r, seat.at), post(r, seat.at));
          if (d > deepest) {
            deepest = d;
            at = `swing ${swing} lift ${lift} roll ${roll}`;
          }
          if (r[1] < lowest) lowest = r[1];
        }
      }
    }
  }

  let fin = -Infinity;
  let finAt = "";
  {
    const id = label.split("|")[0];
    for (const c of cases.filter((f) => f.preset.id === id)) {
      // The 120" board takes the Longboard's fin setups, on its own length and rocker.
      for (const f of placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, fields.outline.length, len ? profile.rockerAt : c.rockerAt)) {
        const run: Vec3 = [f.trailing[0] - f.leading[0], f.trailing[1] - f.leading[1], 0];
        const l = Math.hypot(run[0], run[1]) || 1;
        for (const { u, v } of f.outline.points) {
          const p: Vec3 = [f.leading[0] + (run[0] / l) * u - centre[0], f.leading[1] + (run[1] / l) * u - centre[1], f.rootZ - v - centre[2]];
          for (const swing of SWINGS) {
            for (let lift = -60; lift <= 60; lift += 15) {
              for (const roll of [-90, -45, 0, 45, 90]) {
                const a = { swing, lift, roll };
                const r = room(p, a, boardPlace(points, a, seat));
                const d = Math.max(pad(r, seat.at), post(r, seat.at));
                if (d > fin) {
                  fin = d;
                  finAt = `${c.label} swing ${swing} lift ${lift} roll ${roll}`;
                }
              }
            }
          }
        }
      }
    }
  }

  let wall = Infinity;
  let floor = Infinity;
  for (const aspect of ASPECTS) {
    const lens = bayLens(points, seat, aspect);
    for (const end of ["nose", "tail"] as const) {
      for (const sightDeg of [-L, L]) {
        const { position } = viewerPlace(clampViewer({ ...standAt(end, 0), sightDeg }, seat, lens), lens, seat);
        wall = Math.min(wall, BAY.lengthMm / 2 - Math.abs(position[0]), BAY.widthMm / 2 - Math.abs(position[2]));
        floor = Math.min(floor, position[1]);
      }
    }
  }
  console.log(`${name}: deepest foam into a rack ${deepest.toFixed(2)} mm at ${at}; lowest foam ${lowest.toFixed(0)}; fin into a rack ${fin === -Infinity ? "n/a" : fin.toFixed(2)} mm ${finAt}; eye off nearest wall ${wall.toFixed(0)}; eye height ${floor.toFixed(0)}`);
}

// Scratch: how the first view fits from behind the tail, at a few elevations.
import { bayLens, rackSeat, wallReach, boardPlace, AT_REST, viewerPlace, REST_VIEWER, fillCrop, standAt, railSightDeg } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/shaping-bay";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";
import { buildBoardSurface } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { framePointsOf } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/view-3d";

const sizes: [string, number, number][] = [["computer", 804, 615], ["820x800", 480, 700], ["pixel", 402, 523], ["iphone", 380, 407], ["320", 288, 330], ["sideways", 482, 312]];
for (const label of ["shortboard|asis|hard", "fish|asis|hard", "midlength|asis|hard", "longboard|asis|soft"]) {
  const board = phase16Boards().find((b) => b.label === label)!;
  const geometry = buildOutline(board.fields.outline);
  const profile = designSideProfile(board.fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(board.fields.rails, profile.effectiveFoil, board.fields.railsImportFoilThickness);
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, board.fields.outline.length), geometry, rockerAt: profile.rockerAt });
  const { points } = framePointsOf(surface.positions);
  const seat = rackSeat(points);
  console.log(label, "home", seat.home.toFixed(1), "at", seat.at.toFixed(0), "place", boardPlace(points, AT_REST, seat).map((v) => v.toFixed(1)).join(" "), "wall", wallReach(0, 20).toFixed(0));
  for (const [n, w, h] of sizes) {
    const lens = bayLens(points, seat, w / h);
    const p = viewerPlace(REST_VIEWER, lens, seat);
    const nose = fillCrop(points, AT_REST, standAt("nose", 0), lens, seat, w / h);
    const tail = fillCrop(points, AT_REST, standAt("tail", 0), lens, seat, w / h);
    const rail = railSightDeg(surface.width ? (surface.width as number) / 2 : 250, standAt("tail", 0), lens);
    console.log(" ", n, "d", lens.distanceMm.toFixed(0), "lens", lens.lensDeg.toFixed(1), "eye", p.position.map((v) => v.toFixed(0)).join(","), "noseZoom", nose.zoom.toFixed(2), nose.cx.toFixed(3), nose.cy.toFixed(3), "tailZoom", tail.zoom.toFixed(2), "railDeg", rail.toFixed(2));
  }
}

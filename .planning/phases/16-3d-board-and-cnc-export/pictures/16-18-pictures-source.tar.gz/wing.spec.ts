// Wire View on a winged board, seen from the tail, where the founder took his picture.
import { test, type Page } from "@playwright/test";
import { phase16WingBoards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/models/banner-dismissal";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/models/toolbar-tip";
import { bareCanvas, ready, shoot } from "./lib";

const TAG = process.env.TAG ?? "before";
const CASES: [string, string][] = [
  ["default", process.env.DEFAULT_LABEL ?? ""],
  ["square", process.env.SQUARE_LABEL ?? ""],
];

async function open(page: Page, label: string) {
  const board = phase16WingBoards().find((b) => b.label === label);
  if (!board) throw new Error(`no ${label}`);
  const raw = openBoardCopyJson({ ...board.fields, boardName: "", finSystem: "fcs2" } as never, { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, value]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, value);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw] as const,
  );
}

for (const [name, label] of CASES) {
  test(`wing ${name}`, async ({ page }) => {
    test.setTimeout(300_000);
    await open(page, label);
    await page.goto("/design/3d");
    const host = await ready(page);
    await page.locator('[data-three-d-show="wire"]').click();
    await host.focus();
    // Zoomed on the tail, where the wing is: the zoom's own centre would leave it out of the picture.
    for (let i = 0; i < 4; i++) await page.keyboard.press("+");
    for (let i = 0; i < 9; i++) await page.keyboard.press("Shift+ArrowUp");
    await bareCanvas(page);
    await shoot(page, `w-${TAG}-${name}`);
  });
}

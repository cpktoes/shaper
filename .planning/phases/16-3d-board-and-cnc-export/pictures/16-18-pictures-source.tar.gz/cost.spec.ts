import { test } from "@playwright/test";
import { prepare, ready } from "./lib";

for (const preset of ["Shortboard", "Longboard"]) {
  test(`cost ${preset}`, async ({ page }, info) => {
    test.setTimeout(300_000);
    await prepare(page, preset);
    await page.goto("/design/3d");
    const host = await ready(page);
    await page.waitForTimeout(1000);
    const box = await host.boundingBox();
    const ms = await page.evaluate(() => (globalThis as unknown as { __bayBench(n: number): number[] }).__bayBench(60));
    const sorted = [...ms].sort((a, b) => a - b);
    console.log(info.project.name, preset, Math.round(box?.width ?? 0), Math.round(box?.height ?? 0), "median", sorted[Math.floor(sorted.length / 2)].toFixed(1), "p90", sorted[Math.floor(sorted.length * 0.9)].toFixed(1));
  });
}

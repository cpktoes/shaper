// Scratch: a digest of wireLines' whole output on every wingless board, and the jump a long line makes on winged ones.
import { createHash } from "node:crypto";
import { buildBoardSurface, wireLines } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { phase16LiveBoards, phase16WingBoards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";

type Fields = ReturnType<typeof phase16LiveBoards>[number]["fields"];
function surfaceOf(fields: Fields) {
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  return buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length), geometry, rockerAt: profile.rockerAt });
}

const hash = createHash("sha256");
let count = 0;
for (const board of phase16LiveBoards()) {
  const surface = surfaceOf(board.fields);
  const wire = wireLines(surface);
  for (const lines of [wire.deck, wire.bottom, wire.rings, [wire.outline]]) {
    for (const line of lines) hash.update(Buffer.from(Float64Array.from(line.flat()).buffer));
  }
  count++;
}
console.log("wingless boards", count, "digest", hash.digest("hex").slice(0, 24));
console.log("wing labels", phase16WingBoards().map((b) => b.label).join(" "));
let worst = 0;
for (const board of phase16WingBoards()) {
  const surface = surfaceOf(board.fields);
  const wire = wireLines(surface);
  const mid = wire.deck.length >> 1;
  for (const line of [wire.deck[mid], wire.deck[Math.floor(wire.deck.length * 0.3)]]) {
    for (let i = 1; i < line.length; i++) {
      const dx = line[i][0] - line[i - 1][0];
      if (dx < 1) worst = Math.max(worst, Math.abs(line[i][1] - line[i - 1][1]));
    }
  }
}
console.log("worst sideways jump across a hair, lines away from the rail, mm", worst.toFixed(3));

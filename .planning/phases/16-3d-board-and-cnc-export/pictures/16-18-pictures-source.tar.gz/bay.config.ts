// Scratch config for 16-18's pictures. Runs against the worktree's own server on 3218.
import { defineConfig, devices } from "@playwright/test";

const { defaultBrowserType: _a, viewport: _v, ...iphoneLandscape } = devices["iPhone 14 landscape"];
void _a;
void _v;

export default defineConfig({
  testDir: __dirname,
  testMatch: [process.env.SPEC ?? "shots.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 1_800_000,
  workers: 1,
  fullyParallel: false,
  reporter: "line",
  use: { baseURL: "http://localhost:3218" },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 } } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
    { name: "android", use: { ...devices["Pixel 7"] } },
    { name: "sideways", use: { ...iphoneLandscape, viewport: { width: 844, height: 390 } } },
    { name: "chrome-gpu", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, launchOptions: { args: ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu-rasterization"] } } },
    { name: "chrome-gpu-phone", use: { ...devices["Pixel 7"], launchOptions: { args: ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu-rasterization"] } } },
  ],
});

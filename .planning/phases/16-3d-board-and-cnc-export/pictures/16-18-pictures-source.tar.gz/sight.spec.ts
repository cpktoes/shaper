import { test } from "@playwright/test";
import { bareCanvas, prepare, ready, setSlider, shoot } from "./lib";

for (const preset of ["Shortboard", "Longboard"]) {
  test(`sight ${preset}`, async ({ page }, info) => {
    test.setTimeout(600_000);
    const p = `${preset}-${info.project.name}`;
    await prepare(page, preset);
    await page.goto("/design/3d");
    await ready(page);
    await bareCanvas(page);
    await shoot(page, `s-first-${p}`);
    await page.getByRole("button", { name: "Tail", exact: true }).click();
    await shoot(page, `s-tail-0-${p}`);
    for (const deg of [-6, 3, 6, 9]) {
      await setSlider(page, "Sight Along", deg);
      await shoot(page, `s-tail-${deg}-${p}`);
    }
    await page.getByRole("button", { name: "Nose", exact: true }).click();
    await shoot(page, `s-nose-0-${p}`);
    await setSlider(page, "Sight Along", 6);
    await shoot(page, `s-nose-6-${p}`);
  });
}

import { test } from "@playwright/test";
import { bareCanvas, prepare, ready, shoot } from "./lib";

for (const preset of ["Shortboard", "Fish"]) {
  test(`near ${preset}`, async ({ page }, info) => {
    test.setTimeout(300_000);
    await prepare(page, preset);
    await page.goto("/design/3d");
    await ready(page);
    await bareCanvas(page);
    await shoot(page, `n-first-${preset}-${info.project.name}`);
  });
}

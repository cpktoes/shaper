// The 16-18 pictures, all from the real scene.
import { expect, test, type Page } from "@playwright/test";
import { bareCanvas, OUT, prepare, ready, setSlider, shoot } from "./lib";

const THEME_KEY = "shaper-theme";

const press = (page: Page, name: string) => page.getByRole("group", { name: "Views", exact: true }).getByRole("button", { name, exact: true }).click();
const walk = (page: Page) => page.getByRole("group", { name: "What a drag does", exact: true }).getByRole("button", { name: "Walk Around", exact: true }).click();
const turnMode = (page: Page) => page.getByRole("group", { name: "What a drag does", exact: true }).getByRole("button", { name: "Turn the Board", exact: true }).click();
const corner = (page: Page, name: string) => page.locator(`[data-three-d-show="${name}"]`);

async function drag(page: Page, dx: number, dy: number) {
  const box = await page.locator("[data-board-3d]").boundingBox();
  if (!box) throw new Error("no canvas");
  const x = box.x + box.width / 2;
  const y = box.y + box.height / 2;
  await page.mouse.move(x, y);
  await page.mouse.down();
  await page.mouse.move(x + dx, y + dy, { steps: 10 });
  await page.waitForTimeout(150);
  await page.mouse.up();
}

test.describe("finals", () => {
  for (const preset of ["Shortboard", "Fish", "Longboard"]) {
    test(`first ${preset}`, async ({ page }, info) => {
      test.setTimeout(600_000);
      const p = `${preset}-${info.project.name}`;
      await prepare(page, preset);
      await page.goto("/design/3d");
      await ready(page);
      await bareCanvas(page);
      await shoot(page, `f-first-${p}`);

      // On the racks.
      await press(page, "Bottom");
      await shoot(page, `f-flipped-${p}`);
      await press(page, "Deck");
      await setSlider(page, "Raise the Nose", 16);
      await shoot(page, `f-noseup-${p}`);
      await walk(page);
      await press(page, "Side");
      await shoot(page, `f-noseup-side-${p}`);
      await setSlider(page, "Raise the Tail", 16);
      await shoot(page, `f-tailup-side-${p}`);
      await turnMode(page);
      await page.getByRole("button", { name: "Reset View", exact: true }).click();
      await setSlider(page, "Rotate on Side", -45);
      await shoot(page, `f-roll-left-${p}`);
      await setSlider(page, "Rotate on Side", 45);
      await shoot(page, `f-roll-right-${p}`);
      await press(page, "Nose");
      await shoot(page, `f-roll-right-nose-${p}`);
      await page.getByRole("button", { name: "Reset View", exact: true }).click();
      // Each view, Turn the Board.
      for (const name of ["Bottom", "Deck", "Nose", "Tail"]) {
        await press(page, name);
        await shoot(page, `f-turn-${name}-${p}`);
      }
      await page.getByRole("button", { name: "Reset View", exact: true }).click();
      await walk(page);
      for (const name of ["Bottom", "Deck", "Side", "Nose", "Tail"]) {
        await press(page, name);
        await shoot(page, `f-walk-${name}-${p}`);
      }
      await page.getByRole("button", { name: "Reset View", exact: true }).click();
      await page.waitForTimeout(600);

      // The same drag each way, on a computer.
      if (info.project.name === "desktop") {
        await drag(page, 160, 40);
        await shoot(page, `f-walk-drag-${p}`);
        await page.getByRole("button", { name: "Reset View", exact: true }).click();
        await page.waitForTimeout(600);
        await turnMode(page);
        await drag(page, 160, 40);
        await shoot(page, `f-turn-drag-${p}`);
        await page.getByRole("button", { name: "Reset View", exact: true }).click();
        await page.waitForTimeout(600);
      }

      // Look Down the Rail, on the one view and from the tail on foot.
      await setSlider(page, "Look Down the Rail", -6);
      await shoot(page, `f-look-turn-left-${p}`);
      await setSlider(page, "Look Down the Rail", 6);
      await shoot(page, `f-look-turn-right-${p}`);
      await walk(page);
      await press(page, "Tail");
      await shoot(page, `f-sight-0-${p}`);
      await setSlider(page, "Look Down the Rail", -6);
      await shoot(page, `f-sight-left-${p}`);
      await setSlider(page, "Look Down the Rail", 6);
      await shoot(page, `f-sight-right-${p}`);
    });
  }

  test("looks and themes", async ({ page }, info) => {
    test.setTimeout(600_000);
    const p = info.project.name;
    await prepare(page, "Fish");
    await page.goto("/design/3d");
    await ready(page);
    await bareCanvas(page);
    await page.addStyleTag({ content: "[data-viewer-toolbar] { visibility: visible !important; }" });
    await page.addStyleTag({ content: "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }" });
    await walk(page);
    await page.locator("[data-board-3d]").focus();
    for (let i = 0; i < 4; i++) await page.keyboard.press("ArrowRight");
    await page.keyboard.press("ArrowDown");
    await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
    await shoot(page, `l-lit-${p}`);
    await corner(page, "stripes").evaluate((b) => (b as HTMLButtonElement).click());
    await shoot(page, `l-stripes-${p}`);
    await corner(page, "wire").evaluate((b) => (b as HTMLButtonElement).click());
    await shoot(page, `l-wire-${p}`);
    await corner(page, "room").evaluate((b) => (b as HTMLButtonElement).click());
    await shoot(page, `l-wire-noroom-${p}`);
    await corner(page, "wire").evaluate((b) => (b as HTMLButtonElement).click());
    await shoot(page, `l-noroom-${p}`);
    await corner(page, "room").evaluate((b) => (b as HTMLButtonElement).click());
    await page.waitForTimeout(600);
    for (const theme of ["daylight", "chalk", "slate", "phosphor"]) {
      await page.evaluate(([k, t]) => window.localStorage.setItem(k, t), [THEME_KEY, theme]);
      await page.reload();
      await ready(page);
      await bareCanvas(page);
      await shoot(page, `l-theme-${theme}-${p}`);
      await corner(page, "room").evaluate((b) => (b as HTMLButtonElement).click());
      await shoot(page, `l-theme-${theme}-noroom-${p}`);
    }
  });

  test("panel", async ({ page }, info) => {
    test.setTimeout(300_000);
    const p = info.project.name;
    await prepare(page, "Shortboard");
    await page.goto("/design/3d");
    await ready(page);
    await page.waitForTimeout(800);
    await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
    await page.screenshot({ path: `${OUT}/p-top-${p}.png` });
    await setSlider(page, "Rotate on Side", 30);
    const racks = page.locator("[data-three-d-racks]");
    await racks.scrollIntoViewIfNeeded();
    await page.waitForTimeout(600);
    await page.screenshot({ path: `${OUT}/p-racks-${p}.png` });
    await expect(racks).toBeVisible();
    await setSlider(page, "Look Down the Rail", 25);
    await page.getByRole("button", { name: /Rail Blend Controls/ }).click();
    await page.getByRole("button", { name: /Export for CNC/ }).scrollIntoViewIfNeeded();
    await page.waitForTimeout(400);
    await page.screenshot({ path: `${OUT}/p-view-${p}.png` });
  });
});

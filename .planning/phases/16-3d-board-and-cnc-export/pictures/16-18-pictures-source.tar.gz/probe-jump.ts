import { buildBoardSurface, wireLines } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { phase16WingBoards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { outlineWithoutWings } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/wings";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";

for (const board of phase16WingBoards()) {
  const fields = board.fields;
  const geometry = buildOutline(fields.outline);
  const plain = buildOutline(outlineWithoutWings(fields.outline));
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length), geometry, rockerAt: profile.rockerAt });
  const wire = wireLines(surface);
  const n = wire.deck.length;
  let worstStep = 0;
  let at = "";
  let worstOff = 0;
  let offAt = "";
  for (const k of [Math.floor(n / 2), Math.floor(n * 0.3), Math.floor(n * 0.15)]) {
    const share = (2 * k + 1) / n - 1;
    const line = wire.deck[k];
    for (let i = 1; i < line.length; i++) {
      const dx = line[i][0] - line[i - 1][0];
      const dy = Math.abs(line[i][1] - line[i - 1][1]);
      if (dx < 1 && dy > worstStep) {
        worstStep = dy;
        const r = surface.rings[i];
        at = `k${k} s${line[i][0].toFixed(1)} dx${dx.toFixed(3)} take ${surface.rings[i - 1].wingTake.toFixed(2)}>${r.wingTake.toFixed(2)}`;
      }
      const s = line[i][0];
      const want = Math.abs(share) * sampleOutline(plain, s as never);
      const off = Math.abs(Math.abs(line[i][1]) - want);
      if (off > worstOff) {
        worstOff = off;
        const r = surface.rings[i];
        const apex = Math.abs(surface.positions[3 * r.right[r.right.length >> 1] + 1]);
        offAt = `k${k} s${s.toFixed(1)} want ${want.toFixed(2)} got ${Math.abs(line[i][1]).toFixed(2)} take ${r.wingTake.toFixed(2)} real ${sampleOutline(geometry, s as never).toFixed(2)} plain ${sampleOutline(plain, s as never).toFixed(2)} apexish ${apex.toFixed(2)}`;
      }
    }
  }
  console.log(board.label.padEnd(26), "step", worstStep.toFixed(3), at, "| off", worstOff.toFixed(3), offAt);
}

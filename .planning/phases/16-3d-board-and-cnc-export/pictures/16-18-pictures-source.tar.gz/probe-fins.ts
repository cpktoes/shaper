import { AT_REST, BAY, boardPlace, rackSeat, rackTurn } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/shaping-bay";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-boards";
import { phase16FinCases } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/__fixtures__/phase16-fin-cases";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/outline";
import { designCrossSectionInput, designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/design";
import { buildBoardSurface, type Vec3 } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/board-surface";
import { BOARD_TO_ROOM, framePointsOf, quatMultiply, rotateVec } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/view-3d";
import { placedFins } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/lib/geometry/fin-outline";

const depthInPad = (p: Vec3, at: number) =>
  Math.min(BAY.padHalfSpanMm - Math.abs(p[2]), BAY.padHalfDepthMm - Math.abs(Math.abs(p[0]) - at), BAY.rackTopMm - p[1], p[1] - (BAY.rackTopMm - 50));

for (const c of phase16FinCases()) {
  const label = phase16Boards().find((b) => b.label.startsWith(`${c.preset.id}|asis`))!;
  const geometry = buildOutline(label.fields.outline);
  const profile = designSideProfile(label.fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(label.fields.rails, profile.effectiveFoil, label.fields.railsImportFoilThickness);
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, label.fields.outline.length), geometry, rockerAt: profile.rockerAt });
  const { centre, points } = framePointsOf(surface.positions);
  const seat = rackSeat(points);
  const fins = placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, label.fields.outline.length, c.rockerAt);
  for (const fin of fins) {
    const run: Vec3 = [fin.trailing[0] - fin.leading[0], fin.trailing[1] - fin.leading[1], 0];
    const l = Math.hypot(run[0], run[1]) || 1;
    let worst = -Infinity;
    let where = "";
    for (const { u, v } of fin.outline.points) {
      const p: Vec3 = [fin.leading[0] + (run[0] / l) * u - centre[0], fin.leading[1] + (run[1] / l) * u - centre[1], fin.rootZ - v - centre[2]];
      for (const roll of [0, 45, -45]) {
        const a = { ...AT_REST, roll };
        const place = boardPlace(points, a, seat);
        const r = rotateVec(quatMultiply(rackTurn(a), BOARD_TO_ROOM), p);
        const room: Vec3 = [r[0] + place[0], r[1] + place[1], r[2] + place[2]];
        const d = depthInPad(room, seat.at);
        if (d > worst) {
          worst = d;
          where = `roll ${roll} room ${room.map((n) => n.toFixed(0))} seat.at ${seat.at.toFixed(0)}`;
        }
      }
    }
    if (worst > -60) console.log(c.label, "lead", fin.leading[0].toFixed(0), "trail", fin.trailing[0].toFixed(0), "worst", worst.toFixed(1), where);
  }
}

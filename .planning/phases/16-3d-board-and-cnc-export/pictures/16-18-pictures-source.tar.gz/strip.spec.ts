import { test } from "@playwright/test";
import { bareCanvas, OUT, prepare, ready, shoot } from "./lib";

test("strip", async ({ page }, info) => {
  test.setTimeout(300_000);
  const p = info.project.name;
  await prepare(page, "Shortboard");
  await page.goto("/design/3d");
  await ready(page);
  await bareCanvas(page);
  await shoot(page, `st-first-${p}`);
  await page.getByRole("group", { name: "What a drag does", exact: true }).getByRole("button", { name: "Walk Around", exact: true }).click();
  await page.getByRole("group", { name: "Views", exact: true }).getByRole("button", { name: "Side", exact: true }).click();
  await shoot(page, `st-side-${p}`);
  void OUT;
});

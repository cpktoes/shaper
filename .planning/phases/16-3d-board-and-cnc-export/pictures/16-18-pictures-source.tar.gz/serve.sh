#!/bin/bash
# The worktree's webpack dev server on 3218, for pictures and the suite (reused by Playwright). Deliberate non-secrets.
export NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_ZXhhbXBsZS5jbGVyay5hY2NvdW50cy5kZXYk
export CLERK_SECRET_KEY=sk_live_fake-not-a-secret-for-playwright-only
export DATABASE_URL=postgresql://user:pass@localhost:5432/shaper
export SHAPER_BLANKS_SOURCE=seed-csv
export SHAPER_CONTACT_STAND_IN=1
export SHAPER_FORCED_ERROR=1
export SHAPER_RACK_STAND_IN=1
export IS_WEBPACK_TEST=1
exec npm run dev -- --port 3218

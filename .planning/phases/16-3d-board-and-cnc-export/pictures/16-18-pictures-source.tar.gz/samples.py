from PIL import Image
import sys

d = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/w18/out/"
name = sys.argv[1] if len(sys.argv) > 1 else "n-first-Shortboard-desktop"
im = Image.open(d + name + ".png").convert("RGB")
w, h = im.size
print(im.size)


def box(label, x0, y0, x1, y1):
    c = im.crop((int(x0), int(y0), int(x1), int(y1))).resize((1, 1), Image.BOX).getpixel((0, 0))
    print(label, "#%02x%02x%02x" % c, c)


# Find the board by its brightness along the row through its widest part.
row = int(h * 0.62)
xs = [x for x in range(w) if min(im.getpixel((x, row))) > 120 and w * 0.3 < x < w * 0.7]
left, right = min(xs), max(xs)
print("board at row", row, left, right)
mid = (left + right) // 2
box("deck beside the stringer", mid + 8, row - 6, mid + 28, row + 6)
box("deck left of the stringer", mid - 28, row - 6, mid - 8, row + 6)
box("rail, right", right - 7, row - 6, right - 2, row + 6)
box("rail, left", left + 2, row - 6, left + 7, row + 6)
box("wall", w * 0.45, h * 0.1, w * 0.55, h * 0.2)
box("floor", w * 0.75, h * 0.8, w * 0.85, h * 0.9)

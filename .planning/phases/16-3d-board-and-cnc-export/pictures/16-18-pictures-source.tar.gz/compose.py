"""Composes the five 16-18 pictures from the real scene's shots. Each stays under about 2500 px tall."""
from PIL import Image, ImageDraw, ImageFont
import sys

SP = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/w18/out/"
PIC = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/.planning/phases/16-3d-board-and-cnc-export/pictures/"
INK = (24, 30, 40)
MUTE = (92, 100, 112)
PAPER = (246, 245, 242)
FONT = "/System/Library/Fonts/Helvetica.ttc"
title_font = ImageFont.truetype(FONT, 26)
head_font = ImageFont.truetype(FONT, 19)
label_font = ImageFont.truetype(FONT, 15)


def sheet(path, title, note, rows, width=1500, gap=12):
    """rows: list of (heading, [(file, label), ...]); every row's pictures share a height and fill the width."""
    laid = []
    y = 26 + 34 + (26 if note else 0) + 16
    for heading, cells in rows:
        ims = [Image.open(f if f.startswith("/") else SP + f + ".png").convert("RGB") for f, _ in cells]
        total = sum(i.width / i.height for i in ims)
        h = int((width - 40 - gap * (len(ims) - 1)) / total)
        laid.append((heading, cells, ims, h, y))
        y += 30 + h + 24 + 14
    canvas = Image.new("RGB", (width, y + 8), PAPER)
    d = ImageDraw.Draw(canvas)
    d.text((20, 18), title, fill=INK, font=title_font)
    if note:
        d.text((20, 52), note, fill=MUTE, font=label_font)
    for heading, cells, ims, h, y in laid:
        d.text((20, y), heading, fill=INK, font=head_font)
        x = 20
        for im, (_, label) in zip(ims, cells):
            w = int(im.width * h / im.height)
            canvas.paste(im.resize((w, h), Image.LANCZOS), (x, y + 28))
            d.text((x + 2, y + 28 + h + 4), label, fill=MUTE, font=label_font)
            x += w + gap
    canvas.save(path, optimize=True)
    print(path.split("/")[-1], canvas.size)


d = "desktop"
i = "iphone"
sheet(
    PIC + "16-18-bay-beside-photo.png",
    "The bay beside your photo",
    "Each strip has one shelf, the long one, on top of it. This is what a standing eye sees: the strip below the shelf's edge, its light running down the wall.",
    [
        ("Your photo, and the Shortboard at the first view on a computer", [(PIC + "founder-bay-lighting.png", "Your photo"), (f"f-first-Shortboard-{d}", "Shortboard, computer")]),
        ("The Fish and the Longboard on a computer", [(f"f-first-Fish-{d}", "Fish, computer"), (f"f-first-Longboard-{d}", "Longboard, computer")]),
        ("An iPhone", [(f"f-first-Shortboard-{i}", "Shortboard, iPhone"), (f"f-first-Fish-{i}", "Fish, iPhone"), (f"f-first-Longboard-{i}", "Longboard, iPhone")]),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-on-the-racks.png",
    "On the racks",
    "Shadows are grey, bright light very white. The far end stays on its rack when one is raised, and the racks never move.",
    [
        (
            "Shortboard, computer: the one view",
            [
                (f"f-flipped-Shortboard-{d}", "Bottom"),
                (f"f-noseup-Shortboard-{d}", 'Raise the Nose 16"'),
                (f"f-roll-right-nose-Shortboard-{d}", "Nose: end for end, rotated 45°"),
            ],
        ),
        (
            "Walk Around, standing at the rail, a strip on the wall behind",
            [
                (f"f-noseup-side-Shortboard-{d}", 'Raise the Nose 16": the tail stays on its rack'),
                (f"f-tailup-side-Shortboard-{d}", 'Raise the Tail 16": the nose stays on its rack'),
            ],
        ),
        (
            "Rotate on Side, 45° each way",
            [(f"f-roll-left-Shortboard-{d}", "45° left"), (f"f-roll-right-Shortboard-{d}", "45° right")],
        ),
        (
            "Longboard, computer",
            [
                (f"f-flipped-Longboard-{d}", "Bottom"),
                (f"f-noseup-side-Longboard-{d}", 'Raise the Nose 16"'),
                (f"f-roll-right-nose-Longboard-{d}", "Nose, rotated 45°"),
            ],
        ),
        (
            "iPhone",
            [
                (f"f-flipped-Shortboard-{i}", "Bottom"),
                (f"f-noseup-Shortboard-{i}", 'Raise the Nose 16"'),
                (f"f-roll-right-Shortboard-{i}", "45° right"),
                (f"f-roll-right-nose-Shortboard-{i}", "Nose"),
                (f"f-noseup-Longboard-{i}", "Longboard, nose up"),
            ],
        ),
    ],
    width=1300,
)

sheet(
    PIC + "16-18-two-ways.png",
    "The two modes",
    "Turn the Board: one view, only the board moves, and Side is dimmed. Walk Around: you move inside the room. Nothing zooms by itself.",
    [
        ("The same drag each way (Shortboard, computer)", [(f"f-turn-drag-Shortboard-{d}", "Turn the Board: the one view, the board rotated"), (f"f-walk-drag-Shortboard-{d}", "Walk Around: you moved, the board still")]),
        ("The buttons, Turn the Board", [(f"f-turn-{n}-Shortboard-{d}", n) for n in ["Deck", "Bottom", "Nose", "Tail"]]),
        ("The buttons, Walk Around: overhead the nose is toward the back wall; at Side a strip is on the wall behind", [(f"f-walk-{n}-Shortboard-{d}", n) for n in ["Deck", "Bottom", "Side", "Nose", "Tail"]]),
        (
            "Look Down the Rail on Turn the Board: the board turns 6° and the room stays",
            [(f"f-look-turn-left-Shortboard-{d}", "6° left"), (f"f-turn-Tail-Shortboard-{d}", "On the stringer"), (f"f-look-turn-right-Shortboard-{d}", "6° right")],
        ),
        (
            "Look Down the Rail on Walk Around, from the tail: your eye moves 6° and the board stays",
            [(f"f-sight-left-Shortboard-{d}", "6° left"), (f"f-sight-0-Shortboard-{d}", "On the stringer"), (f"f-sight-right-Shortboard-{d}", "6° right")],
        ),
        (
            "Side, Longboard: left as it is, by your ruling",
            [(f"f-walk-Side-Longboard-{d}", "Computer"), (f"f-walk-Side-Longboard-{i}", "iPhone")],
        ),
    ],
    width=1180,
)

sheet(
    PIC + "16-18-looks-and-themes.png",
    "Contour Stripes, the wire view, the Room switch and the four themes",
    "Fish, walked 60° round to show its length. The room is its own colours in every theme; with the Room switch off the board sits on the theme's plain ground.",
    [
        ("The looks in the room", [(f"l-lit-{d}", "Lit"), (f"l-stripes-{d}", "Contour Stripes"), (f"l-wire-{d}", "Wire View")]),
        ("Room off", [(f"l-noroom-{d}", "Lit, plain ground"), (f"l-wire-noroom-{d}", "Wire View, plain ground")]),
        ("The room in the four themes", [(f"l-theme-{t}-{d}", t.title()) for t in ["daylight", "chalk", "slate", "phosphor"]]),
        ("Room off in the four themes", [(f"l-theme-{t}-noroom-{d}", t.title()) for t in ["daylight", "chalk", "slate", "phosphor"]]),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-panel.png",
    "The panel",
    "VIEW first, then the four sliders, then Rail Blend Controls folded, then Export.",
    [
        ("A computer", [(f"p-top-{d}", "The page"), (f"p-view-{d}", "Rail Blend Controls opened, Look Down the Rail at its full 25°")]),
        ("An iPhone, and a phone on its side", [(f"p-top-{i}", "First view"), (f"p-racks-{i}", "The sliders"), (f"p-view-{i}", "Export"), ("p-top-sideways", "Sideways"), ("p-racks-sideways", "Sideways, the sliders")]),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-wire-at-a-wing.png",
    "The wire view at a wing, before and after",
    "Shortboard from behind the tail at 3x. The long lines now ignore the wing and run straight across it. Only a real contour bends one.",
    [
        ("A default wing (3/16\" deep, a 1/4\" run)", [("w-before-default", "Before"), ("w-after-default", "After")]),
        ("A square wing (3/8\" deep, no run)", [("w-before-square", "Before"), ("w-after-square", "After")]),
    ],
    width=1300,
)

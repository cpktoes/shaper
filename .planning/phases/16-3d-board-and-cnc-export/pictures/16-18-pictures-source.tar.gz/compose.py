"""Composes the five 16-18 pictures from the real scene's shots. Each stays under about 2500 px tall."""
from PIL import Image, ImageDraw, ImageFont
import sys

SP = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/w18/out/"
PIC = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/.planning/phases/16-3d-board-and-cnc-export/pictures/"
INK = (24, 30, 40)
MUTE = (92, 100, 112)
PAPER = (246, 245, 242)
FONT = "/System/Library/Fonts/Helvetica.ttc"
title_font = ImageFont.truetype(FONT, 26)
head_font = ImageFont.truetype(FONT, 19)
label_font = ImageFont.truetype(FONT, 15)


def sheet(path, title, note, rows, width=1500, gap=12):
    """rows: list of (heading, [(file, label), ...]); every row's pictures share a height and fill the width."""
    laid = []
    y = 26 + 34 + (26 if note else 0) + 16
    for heading, cells in rows:
        ims = [Image.open(f if f.startswith("/") else SP + f + ".png").convert("RGB") for f, _ in cells]
        total = sum(i.width / i.height for i in ims)
        h = int((width - 40 - gap * (len(ims) - 1)) / total)
        laid.append((heading, cells, ims, h, y))
        y += 30 + h + 24 + 14
    canvas = Image.new("RGB", (width, y + 8), PAPER)
    d = ImageDraw.Draw(canvas)
    d.text((20, 18), title, fill=INK, font=title_font)
    if note:
        d.text((20, 52), note, fill=MUTE, font=label_font)
    for heading, cells, ims, h, y in laid:
        d.text((20, y), heading, fill=INK, font=head_font)
        x = 20
        for im, (_, label) in zip(ims, cells):
            w = int(im.width * h / im.height)
            canvas.paste(im.resize((w, h), Image.LANCZOS), (x, y + 28))
            d.text((x + 2, y + 28 + h + 4), label, fill=MUTE, font=label_font)
            x += w + gap
    canvas.save(path, optimize=True)
    print(path.split("/")[-1], canvas.size)


d = "desktop"
i = "iphone"
sheet(
    PIC + "16-18-bay-beside-photo.png",
    "The bay beside your photo",
    "Strips under the shelves, the long bright band on the sill below them, the blue walls, the dusty floor. You stand directly behind the tail.",
    [
        ("Your photo, and the Shortboard at the first view on a computer", [(PIC + "founder-bay-lighting.png", "Your photo"), (f"f-first-Shortboard-{d}", "Shortboard, computer")]),
        ("The Fish and the Longboard on a computer", [(f"f-first-Fish-{d}", "Fish, computer"), (f"f-first-Longboard-{d}", "Longboard, computer")]),
        ("An iPhone", [(f"f-first-Shortboard-{i}", "Shortboard, iPhone"), (f"f-first-Fish-{i}", "Fish, iPhone"), (f"f-first-Longboard-{i}", "Longboard, iPhone")]),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-on-the-racks.png",
    "On the racks",
    "Shadows are grey, bright light very white. The far end stays on its rack when one is raised. Nothing here moves the racks but Swing.",
    [
        (
            "Shortboard, computer",
            [
                (f"f-flipped-Shortboard-{d}", "Flipped"),
                (f"f-noseup-Shortboard-{d}", 'Raise the Nose 16"'),
                (f"f-swing-Shortboard-{d}", "Swing, 60°: board and racks together"),
            ],
        ),
        (
            "Standing at the rail",
            [
                (f"f-noseup-side-Shortboard-{d}", 'Raise the Nose 16": the tail stays on its rack'),
                (f"f-tailup-side-Shortboard-{d}", 'Raise the Tail 16": the nose stays on its rack'),
            ],
        ),
        (
            "Rotate on Side, 45° each way, and the shadows down a rail",
            [
                (f"f-roll-left-Shortboard-{d}", "45° left"),
                (f"f-roll-right-Shortboard-{d}", "45° right"),
                (f"f-roll-right-tail-Shortboard-{d}", "45° right, standing at the tail"),
            ],
        ),
        (
            "Longboard, computer",
            [
                (f"f-flipped-Longboard-{d}", "Flipped"),
                (f"f-noseup-side-Longboard-{d}", 'Raise the Nose 16"'),
                (f"f-roll-right-tail-Longboard-{d}", "45° right, standing at the tail"),
            ],
        ),
        (
            "iPhone",
            [
                (f"f-flipped-Shortboard-{i}", "Flipped"),
                (f"f-noseup-Shortboard-{i}", 'Raise the Nose 16"'),
                (f"f-roll-right-Shortboard-{i}", "45° right"),
                (f"f-roll-right-tail-Shortboard-{i}", "At the tail"),
                (f"f-noseup-Longboard-{i}", "Longboard, nose up"),
            ],
        ),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-two-ways.png",
    "Two ways a drag can go, the five buttons, and Sight Along",
    "Nose, Tail and Side stand you there, in both modes. Deck and Bottom set the board on its racks; in Walk Around they also take you overhead.",
    [
        ("The same drag each way (Shortboard, computer)", [(f"f-turn-drag-Shortboard-{d}", "Turn the Board: the board turned, the room and strips still"), (f"f-walk-drag-Shortboard-{d}", "Walk Around: you moved round it, the board and strips still")]),
        (
            "The five buttons, Turn the Board",
            [(f"f-turn-{n}-Shortboard-{d}", n) for n in ["Deck", "Bottom", "Side", "Nose", "Tail"]],
        ),
        (
            "The five buttons, Walk Around",
            [(f"f-walk-{n}-Shortboard-{d}", n) for n in ["Deck", "Bottom", "Side", "Nose", "Tail"]],
        ),
        (
            "Sight Along from the tail: 6° left, on the stringer, 6° right (Shortboard, computer)",
            [(f"f-sight-left-Shortboard-{d}", "6° left"), (f"f-sight-0-Shortboard-{d}", "On the stringer"), (f"f-sight-right-Shortboard-{d}", "6° right")],
        ),
        (
            "The same on the Longboard",
            [(f"f-sight-left-Longboard-{d}", "6° left"), (f"f-sight-0-Longboard-{d}", "On the stringer"), (f"f-sight-right-Longboard-{d}", "6° right")],
        ),
        (
            "Side at the wall: you stop at the wall, so a long board runs off a narrow window",
            [(f"f-turn-Side-Longboard-{d}", "Longboard, computer"), (f"f-turn-Side-Longboard-{i}", "Longboard, iPhone")],
        ),
    ],
    width=1280,
)

sheet(
    PIC + "16-18-looks-and-themes.png",
    "Contour Stripes, the wire view, the Room switch and the four themes",
    "Fish, swung 50° to show its length. The room is its own colours in every theme; with the Room switch off the board sits on the theme's plain ground.",
    [
        ("The looks in the room", [(f"l-lit-{d}", "Lit"), (f"l-stripes-{d}", "Contour Stripes"), (f"l-wire-{d}", "Wire View")]),
        ("Room off", [(f"l-noroom-{d}", "Lit, plain ground"), (f"l-wire-noroom-{d}", "Wire View, plain ground")]),
        ("The room in the four themes", [(f"l-theme-{t}-{d}", t.title()) for t in ["daylight", "chalk", "slate", "phosphor"]]),
        ("Room off in the four themes", [(f"l-theme-{t}-noroom-{d}", t.title()) for t in ["daylight", "chalk", "slate", "phosphor"]]),
    ],
    width=1400,
)

sheet(
    PIC + "16-18-panel.png",
    "The panel",
    "ON THE RACKS first, then TAIL RAIL, VIEW with the switch and Sight Along, EXPORT.",
    [
        ("A computer", [(f"p-top-{d}", "The page"), (f"p-view-{d}", "Scrolled to VIEW")]),
        ("An iPhone, and a phone on its side", [(f"p-top-{i}", "First view"), (f"p-racks-{i}", "ON THE RACKS"), (f"p-view-{i}", "VIEW"), ("p-top-sideways", "Sideways"), ("p-racks-sideways", "Sideways, ON THE RACKS")]),
    ],
    width=1400,
)

import glob
from PIL import Image, ImageChops

base = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bbbd56a81aac7a9/test-results/desktop-baseline-desktop-baseline-screenshots-3D-design-3d--desktop/"
print(sorted(p.split("/")[-1] for p in glob.glob(base + "*")))
old = Image.open(glob.glob(base + "*expected*.png")[0]).convert("RGB")
new = Image.open(glob.glob(base + "*actual*.png")[0]).convert("RGB")
print(old.size, new.size)
diff = ImageChops.difference(old, new).convert("L").point(lambda v: 255 if v > 0 else 0)
w, h = diff.size
px = diff.load()
regions = {
    "panel (x<340)": (0, 0, 340, h),
    "canvas": (340, 150, w, h),
    "above the canvas, right of the panel": (340, 0, w, 150),
}
total = sum(1 for y in range(h) for x in range(w) if px[x, y])
print("differ", total, "of", w * h, "bbox", diff.getbbox())
for name, (x0, y0, x1, y1) in regions.items():
    c = sum(1 for y in range(y0, y1) for x in range(x0, x1) if px[x, y])
    box = diff.crop((x0, y0, x1, y1)).getbbox()
    print(name, c, box)
new.save("/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/w18/out/base-new.png")

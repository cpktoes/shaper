// Dumps the Fish preset's shape for the 3D mock-up: at every half inch along the board, the foam half-width,
// the rocker, the thickness, and the finished rail's cross-section (the same maths VOLUME counts, simplified
// to the centre rail's family at every station — a mock-up, not the phase's own builder).
import { writeFileSync } from "node:fs";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { buildOutline, foamHalfWidth, sampleOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } from "/Users/kontoes/Code/shaper/lib/geometry/design";
import {
  DEFAULT_RAIL_BAND_SPEC,
  RAIL_NUDGE_KEYS,
  buildRailProfile,
  computeRailSection,
} from "/Users/kontoes/Code/shaper/lib/geometry/rail-bands";
import { sectionFinishedRail } from "/Users/kontoes/Code/shaper/lib/geometry/finished-rail";
import { mm } from "/Users/kontoes/Code/shaper/lib/geometry/units";

const preset = BOARD_PRESETS.find((p) => p.id === "fish") ?? BOARD_PRESETS[1];
const fields = presetDesignFields(preset) as any;
const rails = (fields.rails ?? DEFAULT_RAIL_BAND_SPEC) as any;
const outlineGeometry = buildOutline(fields.outline);
const profile = designSideProfile({ outline: fields.outline, rocker: fields.rocker, foil: fields.foil, blank: fields.blank }, LIVE_DESIGN_RULES);
const effective = deriveEffectiveRails(rails, profile.effectiveFoil, true) as any;
const length = fields.outline.length as number;
const zeroNudges = Object.fromEntries(RAIL_NUDGE_KEYS.map((k: string) => [k, mm(0)]));

function sectionFor(station: number, key: "tail" | "center" | "nose", hardEdge: boolean) {
  const spec = effective[key];
  const thickness = profile.thicknessAt(mm(station));
  const deckPercent = spec.deckPercent ?? 100;
  const domed = deckPercent < 100;
  const thicknessEff = domed ? mm((thickness * deckPercent) / 100) : thickness;
  const result = computeRailSection({
    thickness: thicknessEff,
    boardThickness: thickness,
    ratioTopPercent: spec.ratioTopPercent,
    family: spec.family,
    scale: 1,
    nudges: { ...zeroNudges, ...(spec.nudges ?? {}) },
    singleTuck: spec.singleTuck ?? false,
    sharpBottomTuck: spec.sharpBottomTuck ?? false,
    symmetrical: spec.symmetrical ?? false,
    hardEdge,
  } as any);
  return {
    faceted: buildRailProfile(result).map((p) => [p.x, p.y]),
    finished: sectionFinishedRail(result, domed).samples.map((p) => [p.x, p.y]),
    domed,
  };
}

// A swallow's notch: the foam at a station inside it runs from the notch edge to the rail (the air is in the
// middle), exactly as outline.ts's foamHalfWidth subtracts it. The mock carries both edges.
const first = outlineGeometry.points[0];
const close = outlineGeometry.centreCloseStation;
const isSwallow = close > first.station;
function notchEdge(station: number): number {
  if (!isSwallow || station >= close) return 0;
  return first.halfWidth * ((close - station) / (close - first.station));
}
// The hard edge fades into the tucked rail between the 12" station and about 18" from the tail (the founder,
// 2026-11-03: "fade into the center tuck just in front of the fins (~16-20\" from tail)") — a mock of the rule
// put to him; the app's maths today switches it at one point.
const HARD_FULL = 304.8, HARD_GONE = 457.2;
const hardEdgeOn = !!effective.tailHardEdge;
function hardWeight(station: number): number {
  if (!hardEdgeOn) return 0;
  if (station <= HARD_FULL) return 1;
  if (station >= HARD_GONE) return 0;
  const t = (station - HARD_FULL) / (HARD_GONE - HARD_FULL);
  return 1 - (t * t * (3 - 2 * t)); // smoothstep down
}
const step = 12.7;
const stations: any[] = [];
for (let s = 0; s <= length + 1e-6; s += step) {
  const station = Math.min(s, length);
  const half = foamHalfWidth(outlineGeometry, mm(station));
  const outer = isSwallow && station < close ? sampleOutline(outlineGeometry, mm(station)) : half;
  const key = station < length / 3 ? "tail" : station > (2 * length) / 3 ? "nose" : "center";
  const w = key === "tail" ? hardWeight(station) : 0;
  stations.push({
    station,
    halfWidth: outer,
    innerEdge: notchEdge(station),
    rocker: profile.rockerAt(mm(station)),
    thickness: profile.thicknessAt(mm(station)),
    hardWeight: w,
    section: half > 0 ? sectionFor(station, key, false) : null,
    sectionHard: half > 0 && w > 0 ? sectionFor(station, key, true) : null,
  });
}
const out = {
  preset: preset.id,
  name: preset.name,
  length,
  tail: { shape: fields.outline.tail?.shape ?? fields.outline.tailShape ?? null },
  stations,
};
writeFileSync(process.argv[2] ?? "/tmp/fish-3d.json", JSON.stringify(out));
const firstStation = stations.find((x) => x.section);
console.log(`${preset.name}: ${stations.length} stations, length ${length} mm; a section has ${firstStation?.section.faceted.length} faceted and ${firstStation?.section.finished.length} finished points; sample faceted:`, JSON.stringify(firstStation?.section.faceted.slice(0, 4)));

// Writes mock.html: the Fish lofted from fish-3d.json and drawn with three.js under shaping-room lights.
// Views and switches come from the URL: ?view=deck34|bottom34|side|deck|bottom|nose&zebra=1&fins=1&w=1280&h=800
const fs = require("node:fs");
const path = require("node:path");
const dir = __dirname;
const data = fs.readFileSync(path.join(dir, "fish-3d.json"), "utf8");
const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>3D mock</title>
<style>html,body{margin:0;height:100%;background:#f3efe6}canvas{display:block}</style>
<script type="importmap">{"imports":{"three":"https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.0/three.module.min.js"}}</script>
</head><body>
<script type="module">
import * as THREE from "three";
const DATA = ${data};
const q = new URLSearchParams(location.search);
const view = q.get("view") || "deck34";
const zebra = q.get("zebra") === "1";
const showFins = q.get("fins") !== "0";
const W = +(q.get("w") || 1280), H = +(q.get("h") || 800);
const bg = q.get("bg") || "#f3efe6";

// ---- the loft: one ring of 2N points per station, right half then left half, deck up (+y), nose along +z
// ---- the loft, as a regular grid: at every station each SIDE is an open strip of the same points —
// K along the deck from the inner edge (the stringer, or a swallow's notch wall) to the rail's apex, K along the
// bottom back from the apex to the inner edge, then the notch wall (a real face only inside the notch; it tapers
// to nothing at the crotch). The two sides are two lofts that meet along the stringer plane; nothing bridges the
// notch, so a swallow is two pieces, exactly as D-05 says.
const K = 24, WALL = 3, MH = 2 * K + WALL;
function resampleN(pts, n) {
  const seg = []; let L = 0;
  for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i-1][0], pts[i][1] - pts[i-1][1]); seg.push(d); L += d; }
  const out = []; let acc = 0, k = 1;
  for (let j = 0; j < n; j++) {
    const target = (L * j) / (n - 1);
    while (k < pts.length - 1 && acc + seg[k-1] < target) { acc += seg[k-1]; k++; }
    const t = seg[k-1] > 0 ? Math.min(1, Math.max(0, (target - acc) / seg[k-1])) : 0;
    out.push([pts[k-1][0] + (pts[k][0] - pts[k-1][0]) * t, pts[k-1][1] + (pts[k][1] - pts[k-1][1]) * t]);
  }
  return out;
}
function sideFor(st, sec) {
  const T = st.thickness, half = st.halfWidth, xin = st.innerEdge || 0;
  if (!sec || half - xin < 0.5) { const x = (half + xin) / 2; return Array.from({ length: MH }, () => [x, T / 2]); }
  const fin = sec.finished; // from the deck start, round the rail, to the bottom tuck; x <= 0 from the rail's apex
  let ai = 0; for (let i = 1; i < fin.length - 1; i++) if (fin[i][0] > fin[ai][0]) ai = i;
  const deck = [[xin, T]];
  for (let i = 0; i <= ai; i++) deck.push([Math.max(xin, half + fin[i][0]), fin[i][1]]);
  const bottom = [];
  for (let i = ai; i < fin.length - 1; i++) bottom.push([Math.max(xin, half + fin[i][0]), fin[i][1]]);
  bottom.push([xin, 0]);
  const wallH = xin > 0.5 ? T : 0;
  const wall = [[xin, 0], [xin, wallH * 0.5], [xin, wallH]];
  return resampleN(deck, K).concat(resampleN(bottom, K), wall);
}
function halfSection(st) {
  const soft = sideFor(st, st.section);
  if (!st.sectionHard || !st.hardWeight) return soft;
  const hard = sideFor(st, st.sectionHard), w = st.hardWeight;
  return soft.map((p, i) => [p[0] * (1 - w) + hard[i][0] * w, p[1] * (1 - w) + hard[i][1] * w]);
}
const rings = DATA.stations.map((st) => {
  const right = halfSection(st);
  const left = right.map(([x, y]) => [-x, y]);
  return { z: st.station, y0: st.rocker, right, left, inner: st.innerEdge || 0 };
});
const positions = [], indices = [];
for (const sideKey of ["right", "left"]) {
  const base = positions.length / 3;
  rings.forEach((r) => r[sideKey].forEach(([x, y]) => positions.push(x, y + r.y0, r.z)));
  for (let i = 0; i < rings.length - 1; i++) for (let j = 0; j < MH - 1; j++) {
    const a = base + i * MH + j, b = a + 1, c = base + (i + 1) * MH + j, d = c + 1;
    if (sideKey === "right") indices.push(a, c, b, b, c, d); else indices.push(a, b, c, b, d, c);
  }
}
const geo = new THREE.BufferGeometry();
geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
geo.setIndex(indices);
geo.computeVertexNormals();
geo.computeBoundingBox();

const bb = geo.boundingBox, centre = new THREE.Vector3(); bb.getCenter(centre);

// ---- scene, foam, lights
const scene = new THREE.Scene(); scene.background = new THREE.Color(bg);
const foam = new THREE.MeshStandardMaterial({ color: 0xf7f4ec, roughness: 0.92, metalness: 0.0, side: THREE.DoubleSide });
const zebraMat = new THREE.ShaderMaterial({
  uniforms: { bands: { value: 26.0 } },
  vertexShader: \`varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vV = -normalize(mv.xyz); gl_Position = projectionMatrix * mv;} \`,
  // the zebra check: stripes follow the reflection of a bank of tubes overhead, so they bend where the surface bends
  fragmentShader: \`varying vec3 vN; varying vec3 vV; uniform float bands; void main(){ vec3 n = normalize(vN); vec3 r = reflect(-normalize(vV), n); float s = fract(r.y * bands * 0.5 + 0.5); float w = fwidth(s) * 1.5; float k = smoothstep(0.5 - w, 0.5 + w, s) - smoothstep(1.0 - w, 1.0, s); vec3 c = mix(vec3(0.95,0.93,0.88), vec3(0.24,0.28,0.32), k); float lit = 0.75 + 0.25 * max(0.0, dot(n, normalize(vec3(0.3,0.8,0.5)))); gl_FragColor = vec4(c * lit,1.0);} \`,
  side: THREE.DoubleSide,
});
const board = new THREE.Mesh(geo, zebra ? zebraMat : foam);
board.castShadow = true; board.receiveShadow = true;
const group = new THREE.Group(); group.add(board);
// stringer: a thin dark line along the deck and the bottom centre
const deckPts = [], botPts = [];
rings.filter((r) => r.inner < 0.5).forEach((r) => { deckPts.push(new THREE.Vector3(0, r.right[0][1] + r.y0 + 0.4, r.z)); botPts.push(new THREE.Vector3(0, r.right[2 * K - 1][1] + r.y0 - 0.4, r.z)); });
const lineMat = new THREE.LineBasicMaterial({ color: 0x5a4a3a });
if (!zebra) { group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(deckPts), lineMat)); group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(botPts), lineMat)); }
// fins: two simple keels at a fish's placement (a mock: about 11" off the tail, 1 1/4" in from the rail, 1/4" toe)
if (showFins && !zebra) {
  const finShape = new THREE.Shape(); finShape.moveTo(0,0); finShape.lineTo(150,0); finShape.quadraticCurveTo(170,-60,120,-130); finShape.quadraticCurveTo(90,-150,55,-120); finShape.quadraticCurveTo(35,-60,0,0);
  const finGeo = new THREE.ExtrudeGeometry(finShape, { depth: 7, bevelEnabled: false });
  const finMat = new THREE.MeshStandardMaterial({ color: 0xe9e4d8, roughness: 0.7 });
  for (const sgn of [-1, 1]) {
    const zFin = 280; const st = rings.reduce((a, r) => Math.abs(r.z - zFin) < Math.abs(a.z - zFin) ? r : a, rings[0]);
    const half = Math.max(...st.right.map((p) => p[0]));
    const fin = new THREE.Mesh(finGeo, finMat);
    fin.rotation.y = -Math.PI / 2; // the fin's length runs along z
    fin.rotation.z = sgn * 0.0;
    fin.position.set(sgn * (half - 32), st.y0 + 1, zFin - 20);
    fin.rotation.y += sgn * 0.08; // a touch of toe-in
    group.add(fin);
  }
}
group.position.sub(centre);
scene.add(group);
// shaping-room lights: two low side lights along the rails, a soft overhead
// the bay's tubes run along both walls at rail height: nearly horizontal, warm, one a touch stronger than the other
const side1 = new THREE.DirectionalLight(0xfff3e0, 2.6); side1.position.set(1400, 90, 150); scene.add(side1);
const side2 = new THREE.DirectionalLight(0xfff3e0, 2.0); side2.position.set(-1400, 60, -250); scene.add(side2);
// a soft overhead and the floor's bounce, so neither face goes black when the board is turned over
const over = new THREE.HemisphereLight(0xffffff, 0xe6e0d2, 0.9); scene.add(over);
const bounce = new THREE.DirectionalLight(0xfff8ee, 0.7); bounce.position.set(200, -1400, 300); scene.add(bounce);
scene.add(new THREE.AmbientLight(0xffffff, 0.3));

// ---- camera and views
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(2); renderer.setSize(W, H); document.body.appendChild(renderer.domElement);
const camera = new THREE.PerspectiveCamera(32, W / H, 10, 20000);
const L = DATA.length;
const views = {
  deck34: [1500, 1300, -1900], bottom34: [1500, -1300, -1900], side: [2600, 120, 0], deck: [0.001, 2600, 0.001], bottom: [0.001, -2600, 0.001], nose: [0, 350, 2700], tail: [0, 350, -2700],
  tailbottom: [900, -1100, -2300],
};
const targets = { tailbottom: [0, 0, -L * 0.28] };
const v = views[view] || views.deck34; camera.position.set(v[0], v[1], v[2]);
const tg = targets[view] || [0, 0, 0];
if (view === "deck" || view === "bottom") camera.up.set(0, 0, 1); // nose up the screen in the plan views
// frame: fit the board's length to ~82% of the shorter side
const fit = (L * 1.08) / (2 * Math.tan((camera.fov * Math.PI) / 360));
const dist = fit / Math.min(1, W / H) * (view === "side" || view === "deck" || view === "bottom" ? 1.0 : 0.78);
camera.position.setLength(dist * (view === "tailbottom" ? 0.55 : 1));
camera.lookAt(tg[0], tg[1], tg[2]);
renderer.render(scene, camera);
window.__done = true;
</script></body></html>`;
fs.writeFileSync(path.join(dir, "mock.html"), html);
console.log("wrote mock.html", (html.length / 1024).toFixed(0), "KB");

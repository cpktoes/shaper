// Composes the five mock views into one captioned picture for the founder.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = __dirname;
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `mock-${n}.png`)).toString("base64");
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 22px;font-size:16px;color:#4b5563;max-width:1400px;line-height:1.45}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px 24px;padding:0 36px 36px}
figure{margin:0;background:#f3efe6;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden}
figure img{display:block;width:100%;height:auto}figcaption{padding:10px 14px 12px;font-size:14px;line-height:1.4;background:#fff;border-top:1px solid #e5e1d6}
figcaption b{display:block;font-size:15px;margin-bottom:2px}
.phone{display:flex;gap:24px;align-items:flex-start}.phone figure{width:300px;flex:none}.phone .note{font-size:14px;line-height:1.5;color:#374151;max-width:420px;padding-top:6px}
</style></head><body>
<h1>Phase 16 — the 3D screen, a mock-up of the board itself</h1>
<p class="lead">The Fish preset lofted from the app's own maths — its outline, rocker, thickness and the finished rail at every half inch — and drawn with the shaping-room lights you chose: two tubes at rail height along the walls, a soft overhead, the floor's bounce. Raw matte foam with the stringer line, simple twin keels at a fish's placement. The panel, the toolbar and the words are in the written contract; this picture is only the look of the board. Not the final build: the real screen reads every station exactly as the litres do.</p>
<div class="grid">
<figure><img src="${img("deck")}"><figcaption><b>Deck, straight down</b>The Fish's outline as TEMPLATE draws it: the swallow's two points and the notch between them, the stringer line nose to tail.</figcaption></figure>
<figure><img src="${img("deck34")}"><figcaption><b>Deck, three-quarter view — the view the screen opens on</b>The side tubes rake across the deck dome and the rails.</figcaption></figure>
<figure><img src="${img("bottom34")}"><figcaption><b>Bottom, three-quarter view</b>Turned over under the same lights: the bottom stays lit because the tubes sit at rail height, with the floor's bounce under it. The fins stand at the FINS placement.</figcaption></figure>
<figure><img src="${img("side")}"><figcaption><b>Side view</b>The rocker and the foil as the ROCKER screen draws them, now as a solid.</figcaption></figure>
<figure><img src="${img("zebra")}"><figcaption><b>Contour stripes switched on</b>The zebra check: bands of light from a bank of tubes overhead, bending where the surface bends. A flat spot or a bump breaks the flow of the bands. Off by default.</figcaption></figure>
<figure><img src="${img("tailbottom")}"><figcaption><b>The tail from below, closer</b>The swallow cut through from the notch edge to the rail, each wall a square face that tapers out at the crotch. The hard edge runs full to the 12" station and fades into the tucked rail by 18" — your "Hard edge ends at" at its default.</figcaption></figure>
</div>
<div class="phone" style="padding:0 36px 36px">
<figure><img src="${img("phone")}"><figcaption><b>On a phone</b>The same board in the stacked shell's drawing area, 390 dots wide.</figcaption></figure>
<div class="note">What to look at: does the foam read as foam, is the deck's dome visible under the side light, do the stripes read as a shaping check rather than decoration, and is the rest view the right one to open on. The lights' exact angles, the foam's tint per theme and the stripe density are mine to tune from pictures like this one.</div>
</div>
</body></html>`;
fs.writeFileSync(path.join(dir, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 2 });
  await page.goto("file://" + path.join(dir, "compose.html"));
  await page.evaluate(() => document.fonts.ready);
  const out = process.argv[2] || path.join(dir, "3d-mockup.png");
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

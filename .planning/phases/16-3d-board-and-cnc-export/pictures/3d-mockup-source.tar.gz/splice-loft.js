// Replaces build-mock.js's ring loft (from `const N = 48;` through `geo.computeBoundingBox();`) with loft-block.js,
// and points the stringer line and the fins at the new ring shape.
const fs = require("node:fs");
const path = require("node:path");
const p = path.join(__dirname, "build-mock.js");
let s = fs.readFileSync(p, "utf8");
const block = fs.readFileSync(path.join(__dirname, "loft-block.js"), "utf8");
const start = s.indexOf("const N = 48;");
const endMarker = "geo.computeBoundingBox();";
const end = s.indexOf(endMarker);
if (start < 0 || end < 0) throw new Error("loft anchors not found");
s = s.slice(0, start) + block.trimEnd() + "\n" + s.slice(end + endMarker.length);
// the stringer: only where the stringer is foam (not inside the notch); deck = the strip's first point, bottom = the end of the bottom run
s = s.replace(
  /rings\.forEach\(\(r\) => \{ deckPts\.push\([^\n]*\n/,
  "rings.filter((r) => r.inner < 0.5).forEach((r) => { deckPts.push(new THREE.Vector3(0, r.right[0][1] + r.y0 + 0.4, r.z)); botPts.push(new THREE.Vector3(0, r.right[2 * K - 1][1] + r.y0 - 0.4, r.z)); });\n",
);
s = s.replace("const half = Math.max(...st.pts.map(p => p.x ?? p[0]));", "const half = Math.max(...st.right.map((p) => p[0]));");
if (s.includes("st.pts") || s.includes("r.pts")) throw new Error("a .pts reference survived");
fs.writeFileSync(p, s);
console.log("spliced; build-mock.js is", (s.length / 1024).toFixed(1), "KB");

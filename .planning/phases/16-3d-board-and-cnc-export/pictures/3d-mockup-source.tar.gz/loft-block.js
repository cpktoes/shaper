// ---- the loft, as a regular grid: at every station each SIDE is an open strip of the same points —
// K along the deck from the inner edge (the stringer, or a swallow's notch wall) to the rail's apex, K along the
// bottom back from the apex to the inner edge, then the notch wall (a real face only inside the notch; it tapers
// to nothing at the crotch). The two sides are two lofts that meet along the stringer plane; nothing bridges the
// notch, so a swallow is two pieces, exactly as D-05 says.
const K = 24, WALL = 3, MH = 2 * K + WALL;
function resampleN(pts, n) {
  const seg = []; let L = 0;
  for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i-1][0], pts[i][1] - pts[i-1][1]); seg.push(d); L += d; }
  const out = []; let acc = 0, k = 1;
  for (let j = 0; j < n; j++) {
    const target = (L * j) / (n - 1);
    while (k < pts.length - 1 && acc + seg[k-1] < target) { acc += seg[k-1]; k++; }
    const t = seg[k-1] > 0 ? Math.min(1, Math.max(0, (target - acc) / seg[k-1])) : 0;
    out.push([pts[k-1][0] + (pts[k][0] - pts[k-1][0]) * t, pts[k-1][1] + (pts[k][1] - pts[k-1][1]) * t]);
  }
  return out;
}
function sideFor(st, sec) {
  const T = st.thickness, half = st.halfWidth, xin = st.innerEdge || 0;
  if (!sec || half - xin < 0.5) { const x = (half + xin) / 2; return Array.from({ length: MH }, () => [x, T / 2]); }
  const fin = sec.finished; // from the deck start, round the rail, to the bottom tuck; x <= 0 from the rail's apex
  let ai = 0; for (let i = 1; i < fin.length - 1; i++) if (fin[i][0] > fin[ai][0]) ai = i;
  const deck = [[xin, T]];
  for (let i = 0; i <= ai; i++) deck.push([Math.max(xin, half + fin[i][0]), fin[i][1]]);
  const bottom = [];
  for (let i = ai; i < fin.length - 1; i++) bottom.push([Math.max(xin, half + fin[i][0]), fin[i][1]]);
  bottom.push([xin, 0]);
  const wallH = xin > 0.5 ? T : 0;
  const wall = [[xin, 0], [xin, wallH * 0.5], [xin, wallH]];
  return resampleN(deck, K).concat(resampleN(bottom, K), wall);
}
function halfSection(st) {
  const soft = sideFor(st, st.section);
  if (!st.sectionHard || !st.hardWeight) return soft;
  const hard = sideFor(st, st.sectionHard), w = st.hardWeight;
  return soft.map((p, i) => [p[0] * (1 - w) + hard[i][0] * w, p[1] * (1 - w) + hard[i][1] * w]);
}
const rings = DATA.stations.map((st) => {
  const right = halfSection(st);
  const left = right.map(([x, y]) => [-x, y]);
  return { z: st.station, y0: st.rocker, right, left, inner: st.innerEdge || 0 };
});
const positions = [], indices = [];
for (const sideKey of ["right", "left"]) {
  const base = positions.length / 3;
  rings.forEach((r) => r[sideKey].forEach(([x, y]) => positions.push(x, y + r.y0, r.z)));
  for (let i = 0; i < rings.length - 1; i++) for (let j = 0; j < MH - 1; j++) {
    const a = base + i * MH + j, b = a + 1, c = base + (i + 1) * MH + j, d = c + 1;
    if (sideKey === "right") indices.push(a, c, b, b, c, d); else indices.push(a, b, c, b, d, c);
  }
}
const geo = new THREE.BufferGeometry();
geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
geo.setIndex(indices);
geo.computeVertexNormals();
geo.computeBoundingBox();

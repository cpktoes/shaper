// Screenshots mock.html in headless Chromium with software WebGL, one picture per view.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const dir = __dirname;
const shots = [
  ["deck34", {}, 1280, 800], ["bottom34", {}, 1280, 800], ["side", {}, 1280, 800],
  ["zebra", { zebra: "1" }, 1280, 800], ["phone", { view: "deck34", w: "390", h: "520" }, 390, 520],
  ["tail", {}, 1280, 800], ["tailbottom", {}, 1280, 800], ["deck", {}, 1280, 800],
];
(async () => {
  const browser = await chromium.launch({ args: ["--use-angle=swiftshader-webgl", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  for (const [name, params, w, h] of shots) {
    const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
    const q = new URLSearchParams({ view: name === "zebra" || name === "phone" ? (params.view || "deck34") : name, w: String(w), h: String(h), ...params });
    const url = "file://" + path.join(dir, "mock.html") + "?" + q.toString();
    page.on("console", (m) => { if (m.type() === "error") console.log("console error:", m.text()); });
    page.on("pageerror", (e) => console.log("page error:", e.message));
    await page.goto(url);
    await page.waitForFunction(() => window.__done === true, null, { timeout: 60000 });
    const gl = await page.evaluate(() => { const c = document.querySelector("canvas"); const g = c.getContext("webgl2") || c.getContext("webgl"); const d = g && g.getExtension("WEBGL_debug_renderer_info"); return d ? g.getParameter(d.UNMASKED_RENDERER_WEBGL) : (g ? "webgl ok" : "no webgl"); });
    await page.screenshot({ path: path.join(dir, `mock-${name}.png`) });
    console.log(name, "->", `mock-${name}.png`, "| renderer:", gl);
    await page.close();
  }
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

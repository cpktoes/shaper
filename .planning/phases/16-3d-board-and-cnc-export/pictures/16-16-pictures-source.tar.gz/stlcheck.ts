// Does a square step far from the tail (two rings a hair apart) stay one closed skin in the STL's float32 numbers?
import { buildBoardSurface, meshCheck } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/geometry/board-surface";
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/geometry/outline";
import { phase16WingBoards } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/geometry/__fixtures__/phase16-boards";
import { cncFiles } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/export/cnc-files";
import { readStl } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/export/stl";
import { inchesToMm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a49caccf569feea07/lib/geometry/units";

for (const inches of [11, 21, 22, 26, 30, 34]) {
  const base = phase16WingBoards().find((b) => b.label === "wing|midlength|square")!;
  const wings = base.fields.outline.wings!.map((w) => ({ ...w, station: inchesToMm(inches) }));
  const fields = { ...base.fields, outline: { ...base.fields.outline, wings } };
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const sections = designCrossSectionInput(geometry, profile, rails, fields.outline.length);
  const surface = buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
  const stlFile = cncFiles(surface, "x").files.find((f) => f.name.endsWith(".stl"))!;
  const stl = readStl(stlFile.data);
  const bits = new Float32Array(3);
  const u = new Uint32Array(bits.buffer);
  const index = new Map<string, number>();
  const positions: number[] = [];
  const indices: number[] = [];
  let degenerate = 0;
  for (const tri of stl.triangles) {
    const ids = tri.map((c: readonly number[]) => {
      bits[0] = c[0]; bits[1] = c[1]; bits[2] = c[2];
      const key = `${u[0]},${u[1]},${u[2]}`;
      let v = index.get(key);
      if (v === undefined) { v = positions.length / 3; index.set(key, v); positions.push(c[0], c[1], c[2]); }
      return v;
    });
    if (new Set(ids).size < 3) { degenerate++; continue; }
    indices.push(...ids);
  }
  console.log(inches, "double", JSON.stringify(meshCheck(surface)), "stl welded", JSON.stringify(meshCheck({ positions, indices })), "collapsed triangles", degenerate);
}

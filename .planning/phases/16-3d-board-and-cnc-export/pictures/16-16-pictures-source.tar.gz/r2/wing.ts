// Round 2, part A (D-37): the shared blend's candidates measured in the scratch copy.
//   npx --no-install tsx --tsconfig <cand>/tsconfig.json wing.ts <cand> <out>
import { writeFileSync, readFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.argv[2];
const OUT = process.argv[3];
const CANDS: [string, string][] = [["today", ""], ["short", "d4"], ["mid", "in3"], ["long", "in8"]];

(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const pin = JSON.parse(readFileSync(join(ROOT, "lib/geometry/__fixtures__/phase16-surface-litres-pin.json"), "utf8")).litres;
  const all = F.phase16WingBoards();
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return { geometry, profile, sections, surfaceInput: { sections, geometry, rockerAt: profile.rockerAt } };
  };
  const heightAt = (run: [number, number][], y: number) => {
    for (let i = 1; i < run.length; i++) {
      const [y0, h0] = run[i - 1];
      const [y1, h1] = run[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return run[run.length - 1][1];
  };
  const deckOf = (input: any, s: number) => {
    const [section] = V.boardSections(input, [s]);
    const half = S.placedHalfSection(section, section.halfWidth, 0) as [number, number][];
    return { section, half, deck: half.slice(0, 48) };
  };
  const I = U.inchesToMm;
  const out: any = {};
  const main = ["wing|shortboard|one", "wing|midlength|rounded", "wing|fish|square"];
  for (const [name, spec] of CANDS) {
    process.env.WING_SHARE = spec;
    if (!spec) delete process.env.WING_SHARE;
    const row: any = { boards: {}, sweep: {} };
    // the 28: litres, mesh, the 3D gap
    for (const board of all) {
      const { sections, surfaceInput } = inputOf(board.fields);
      const surface = S.buildBoardSurface(surfaceInput);
      const c = S.meshCheck(surface);
      const litres = D.summarizeDesign(board.fields).volumeLitres;
      const vol = V.computeCrossSectionVolume(sections).volumeLitres;
      row.sweep[board.label] = {
        litres,
        move: litres - Number(pin[board.label]),
        gap: (S.enclosedVolumeMm3(surface) / 1e6 / vol - 1) * 100,
        faults: c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles,
        slices: S.boardSlices(surface).length,
      };
    }
    for (const label of main) {
      const board = all.find((b: any) => b.label === label);
      const { geometry, sections, profile, surfaceInput } = inputOf(board.fields);
      const plainFields = { ...board.fields, outline: W.outlineWithoutWings(board.fields.outline) };
      const plain = inputOf(plainFields).sections;
      const wing = geometry.wings[0];
      const fp = W.wingFootprint(wing);
      const stepStart = fp.stepStart as number;
      const inner = fp.inner as number;
      // the rail's thickness along the board: the drawn deck 1/2" and 1" in from the drawn rail
      const series: number[][] = [];
      for (let s = inner - I(11); s <= stepStart + I(11); s += I(0.125)) {
        const d = deckOf(sections, s);
        const p = deckOf(plain, s);
        series.push([
          U.mmToInches(s),
          heightAt(d.deck, d.section.halfWidth - I(0.5)),
          heightAt(d.deck, d.section.halfWidth - I(1)),
          heightAt(d.deck, p.section.halfWidth - I(3)),
          heightAt(p.deck, p.section.halfWidth - I(0.5)),
          heightAt(p.deck, p.section.halfWidth - I(1)),
        ]);
      }
      // the deck's move against the wing-less board, just ahead of and just behind the wing
      const ahead = stepStart + 2;
      const behind = inner - 2;
      const move = (s: number) => {
        const d = deckOf(sections, s);
        const p = deckOf(plain, s);
        return [1, 2, 3].map((k) => {
          const y = d.section.halfWidth - I(k);
          return heightAt(d.deck, y) - heightAt(p.deck, y);
        });
      };
      // the jump across the wing at one distance from the stringer, and the largest anywhere inboard of the behind rail
      const a = deckOf(sections, ahead);
      const b = deckOf(sections, behind);
      // The ledge across the wing at one distance from the stringer, the board's own taper over those few
      // millimetres taken out (the board without the wing, at the same two stations).
      const pa = deckOf(plain, ahead);
      const pb = deckOf(plain, behind);
      const ledgeAt = (y: number) => heightAt(a.deck, y) - heightAt(b.deck, y) - (heightAt(pa.deck, y) - heightAt(pb.deck, y));
      const across = [0.5, 1, 2, 3].map((k) => ledgeAt(b.section.halfWidth - I(k)));
      // The lip: the height of the step's top edge, where the ahead rail's deck stands over the behind rail's outer
      // shoulder, in the last 1/4" inside the behind rail.
      const lip = ledgeAt(b.section.halfWidth - I(0.25));
      const lipAt = I(0.25);
      // what a CNC slice carries nearest the wing
      const surface = S.buildBoardSurface(surfaceInput);
      const slices = S.boardSlices(surface);
      const pick = (want: number) => slices.reduce((best: any, x: any) => (Math.abs(x.station - want) < Math.abs(best.station - want) ? x : best));
      const carried = [stepStart + I(2), (stepStart + inner) / 2, inner - I(2)].map((want) => {
        const slice = pick(want);
        const d = deckOf(sections, slice.station);
        const z0 = profile.rockerAt(slice.station);
        const widest = Math.max(...slice.loops.flat().map((p: number[]) => p[1]));
        return {
          stationIn: U.mmToInches(slice.station),
          width: widest,
          outline: O.sampleOutline(geometry, slice.station),
          deck1: heightAt(d.deck, d.section.halfWidth - I(1)),
          deck05: heightAt(d.deck, d.section.halfWidth - I(0.5)),
          top: Math.max(...slice.loops.flat().map((p: number[]) => p[2])) - z0,
        };
      });
      // the half sections for the slice plates
      const half = (input: any, s: number) => deckOf(input, s).half;
      const sliceAt = behind - 8; // the same station as the founder's first slice for his rounded board is drawn apart
      const dumpSurface = () => {
        const mesh = Rn.renderMesh(surface);
        const round = (arr: ArrayLike<number>, n: number) => Array.from(arr, (x) => +x.toFixed(n));
        writeFileSync(
          join(OUT, `surf-${name}-${label.replace(/\|/g, "_")}.json`),
          JSON.stringify({ label, length: board.fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface), wings: [{ inner, stepStart, half: O.sampleOutline(geometry, behind) }], tailZ: 0, tailT: 0, noseZ: 0, noseT: 0, tailHalf: 0 }),
        );
      };
      dumpSurface();
      row.boards[label] = {
        series,
        stepStart: U.mmToInches(stepStart),
        inner: U.mmToInches(inner),
        moveAhead: move(ahead),
        moveBehind: move(behind),
        across,
        lip,
        lipIn: U.mmToInches(lipAt),
        carried,
        slices: { ahead: half(sections, ahead), behind: half(sections, behind), plainBehind: half(plain, behind), plainAhead: half(plain, ahead), width: [a.section.halfWidth, b.section.halfWidth], s: [ahead, behind], sliceAt },
      };
    }
    out[name] = row;
    console.log(name, "done");
  }
  writeFileSync(join(OUT, "wing.json"), JSON.stringify(out));
  for (const label of main) {
    console.log("\n" + label);
    for (const [name] of CANDS) {
      const b = out[name].boards[label];
      const s = out[name].sweep[label];
      const f = (a: number[]) => a.map((x) => x.toFixed(2)).join(" / ");
      console.log(
        name.padEnd(6),
        "ahead", f(b.moveAhead), "| behind", f(b.moveBehind), "| ledge .5/1/2/3", f(b.across), "| lip", b.lip.toFixed(2),
        "| litres", s.litres.toFixed(4), (s.move >= 0 ? "+" : "") + s.move.toFixed(4), "| gap", s.gap.toFixed(3), "| faults", s.faults,
      );
      console.log("   slices", b.carried.map((c: any) => `${c.stationIn.toFixed(1)}" w ${c.width.toFixed(2)} (outline ${c.outline.toFixed(2)}) deck@1" ${c.deck1.toFixed(2)} top ${c.top.toFixed(2)}`).join(" | "));
    }
  }
  for (const [name] of CANDS) {
    const rows = Object.values(out[name].sweep) as any[];
    console.log(name, "faults", rows.reduce((n, r) => n + r.faults, 0), "move", Math.min(...rows.map((r) => r.move)).toFixed(4), Math.max(...rows.map((r) => r.move)).toFixed(4), "gap", Math.min(...rows.map((r) => r.gap)).toFixed(3), Math.max(...rows.map((r) => r.gap)).toFixed(3));
  }
})();

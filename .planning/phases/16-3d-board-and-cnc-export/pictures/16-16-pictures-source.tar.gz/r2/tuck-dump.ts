// The Shortboard and the Fish with a sharp centre, for the bottom shots. Args: <root> <tag> <out>
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const [ROOT, TAG, OUT] = process.argv.slice(2);
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  for (const label of ["tucked|shortboard|he-centre-sbt", "tucked|fish|he-centre-sbt"]) {
    const { fields } = F.phase16SurfaceBoards().find((b: any) => b.label === label);
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
    const mesh = Rn.renderMesh(surface);
    const round = (arr: ArrayLike<number>, n: number) => Array.from(arr, (x) => +x.toFixed(n));
    const half = (s: number) => O.sampleOutline(geometry, s);
    const stations = [37, 41, 45, 49, 53, 57, 61].map((i) => i * 25.4);
    writeFileSync(
      join(OUT, `tuck-${TAG}-${label.split("|")[1]}.json`),
      JSON.stringify({ label, length: fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface), halves: stations.map(half), rocker: stations.map((s) => profile.rockerAt(s)), stations }),
    );
  }
  console.log("ok", TAG);
})();

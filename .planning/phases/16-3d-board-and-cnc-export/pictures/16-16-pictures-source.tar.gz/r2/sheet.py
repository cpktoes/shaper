import sys
from PIL import Image
d='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/out/'
names=sys.argv[2:]
cols=4
w,h=640,400
rows=(len(names)+cols-1)//cols
im=Image.new('RGB',(cols*w+(cols-1)*6,rows*h+(rows-1)*6),'white')
for i,n in enumerate(names):
    a=Image.open(d+n+'.png').convert('RGB').resize((w,h))
    im.paste(a,((i%cols)*(w+6),(i//cols)*(h+6)))
im.save(sys.argv[1])

p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/cards.ts'
s=open(p).read()
a='''  for (const [n, f] of cards) {'''
b='''  const fine = (fields: any, tail: string, L: number) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const n = 600;
    const at = Array.from({ length: n + 1 }, (_, i) => (i * L) / n);
    process.env.TAIL_ROLL = tail;
    const rolled = V.boardSections(sections, at).map((x: any) => x.area);
    delete process.env.TAIL_ROLL;
    const plain = V.boardSections(sections, at).map((x: any) => x.area);
    let v = 0;
    for (let i = 0; i < n; i++) v += (((rolled[i] - plain[i]) + (rolled[i + 1] - plain[i + 1])) / 2) * (L / n);
    return v / 1e6;
  };
  for (const [n, f] of cards) {'''
assert a in s
s=s.replace(a,b)
a='''      const real = mesh(f) - m0;
'''
b='''      const real = fine(f, t, 39);
      process.env.TAIL_ROLL = t;
'''
assert a in s
s=s.replace(a,b)
s=s.replace('stations ${seen.toFixed(4)} mesh ${real.toFixed(4)}','stations ${seen.toFixed(4)} true ${real.toFixed(4)}')
open(p,'w').write(s)

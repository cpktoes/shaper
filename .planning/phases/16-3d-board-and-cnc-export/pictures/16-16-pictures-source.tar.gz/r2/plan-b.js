// Writes shots.json for part B.
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const norm = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
const shots = [];
const tails = [["fish_asis_hard", true], ["shortboard_asis_hard", false], ["shortboard_pin_hard", false], ["midlength_asis_hard", false], ["shortboard_diamond_hard", false]];
for (const [slug, point] of tails) {
  for (const cand of ["today", "gentle", "medium", "full"]) {
    const file = `tail-${cand}-${slug}.json`;
    const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
    const across = point ? -d.tailHalf : 0;
    const side = [28, d.tailZ + d.tailT / 2 + 3, across];
    shots.push({ name: `B-${slug}-${cand}-side`, file, mode: "lit", eye: [side[0], side[1], across - 420], look: side, fov: 14, keyAt: [0, 400, across - 700], key: 0.9, dim: 0.42, w: 800, h: 500 });
    const look = [34, d.tailZ + d.tailT / 2, across];
    const v = norm([-0.75, 0.55, -0.75]);
    shots.push({ name: `B-${slug}-${cand}-34`, file, mode: "lit", eye: look.map((x, i) => x + v[i] * 500), look, fov: 14, keyAt: [-300, 500, across - 500], key: 0.9, dim: 0.42, w: 800, h: 500 });
  }
}
fs.writeFileSync(path.join(dir, "shots-b.json"), JSON.stringify(shots));
console.log(shots.length);

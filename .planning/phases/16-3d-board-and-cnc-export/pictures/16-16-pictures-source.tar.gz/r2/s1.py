def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/finished-rail.ts'; s=open(p).read()
s=rep(s,'''/** The foam a sampled half-section and its mirror enclose together''','''/** The point `arc` millimetres along a polyline from its first point, and the index of the next point past it. */
function alongRun(points: readonly P2[], arc: number): { at: P2; next: number } {
  let left = arc;
  for (let i = 1; i < points.length; i++) {
    const [a, b] = [points[i - 1], points[i]];
    const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (d > 0 && left <= d) {
      const t = left / d;
      return { at: [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t], next: i };
    }
    left -= d;
  }
  return { at: points[points.length - 1], next: points.length - 1 };
}

/** How far the sharp corner may open along each side, as a share of what that side has. */
const OPEN_ROOM = 0.8;
/** The least a corner opens to at the full share, in inches, for a round rail that lands right beside it. */
const OPEN_FLOOR_IN = 1 / 8;

/**
 * A sharp half with its bottom corner opened toward a round rail (Phase 16, the founder 2026-11-05: "make sure a sharp
 * tuck can blend into a round tuck nicely. ... It's typical to have a sharp tuck at center that smooths/rounds toward
 * the nose."). `share` is how much of the station is the round rail's, 0 to 1. A point-for-point blend keeps a real
 * corner in every slice with its angle shrinking, the small kink he saw; here the corner gains a radius instead: a
 * parabola with the corner as its control, leaving each side `share` of the way along the reach, which is how far
 * across the round rail lands from the corner. Its end on the bottom becomes the half's bottom edge, as a round rail's
 * does, so the blend of this half with the round one has no corner in it at any weight. At `share` 0 it is the sharp
 * half; every point not near the corner stays where it is.
 */
export function openedFinishedRail(sharp: HalfSectionPoints, round: HalfSectionPoints, share: number): HalfSectionPoints {
  const edge = SECTION_POINTS.deck + SECTION_POINTS.rail - 2;
  const corner = sharp[edge];
  const reach = Math.max(Math.abs(corner[0] - round[edge][0]), inchesToMm(OPEN_FLOOR_IN)) * share;
  const up = sharp.slice(SECTION_POINTS.deck - 1, edge + 1).reverse() as P2[];
  const along = sharp.slice(edge) as P2[];
  const length = (run: P2[]) => run.reduce((sum, p, i) => (i ? sum + Math.hypot(p[0] - run[i - 1][0], p[1] - run[i - 1][1]) : 0), 0);
  const a = alongRun(up, Math.min(reach, OPEN_ROOM * length(up)));
  const b = alongRun(along, Math.min(reach, OPEN_ROOM * length(along)));
  if (a.at === corner || b.at === corner) return sharp;
  const curve = Array.from({ length: 17 }, (_, i): P2 => {
    const t = i / 16;
    const [u, v, w] = [(1 - t) * (1 - t), 2 * t * (1 - t), t * t];
    return [u * a.at[0] + v * corner[0] + w * b.at[0], u * a.at[1] + v * corner[1] + w * b.at[1]];
  });
  // Hold the curve's foot exactly on the bottom, so the run splits there.
  curve[16] = [b.at[0], 0];
  const lastBefore = edge - a.next + 1;
  const firstAfter = edge + b.next;
  return resampledHalf(dedupeRun([...(sharp.slice(0, lastBefore) as P2[]), ...curve, ...(sharp.slice(firstAfter) as P2[])]));
}

/** The foam a sampled half-section and its mirror enclose together''')
open(p,'w').write(s)

p='lib/geometry/volume.ts'; s=open(p).read()
s=rep(s,'''  finishedRailReach,
  fittedFinishedRail,
''','''  finishedRailReach,
  fittedFinishedRail,
  openedFinishedRail,
''')
s=rep(s,''' * around the end, the deck rolling over into the tail's edge (D-38).
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
  tail: "square" | "roll";
}
''',''' * around the end, the deck rolling over into the tail's edge (D-38). `tuck`: `"corner"` blends a sharp bottom edge
 * into a round one point for point, a corner in every slice, shrinking; `"open"` opens the corner into a radius
 * that grows along the blend (`openedFinishedRail`).
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
  tail: "square" | "roll";
  tuck: "corner" | "open";
}
''')
s=rep(s,'''export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip", tail: "square" };''','''export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip", tail: "square", tuck: "corner" };''')
s=rep(s,'''  fit: { wings: "share", tips: "fit", tail: "roll" },''','''  fit: { wings: "share", tips: "fit", tail: "roll", tuck: "open" },''')
s=rep(s,''' * (`tailRollDrop`, D-38).''',''' * (`tailRollDrop`, D-38), with a sharp bottom edge opening into a round one along a blend (`openedFinishedRail`).''')
s=rep(s,'''      const baseEnd = endHalf(baseResult, baseArea);
      const tipEnd = endHalf(tipResult, tipArea);
      const blended = blendFinishedRails(baseEnd.half, tipEnd.half, tipWeight);
''','''      const baseFinal = endHalf(baseResult, baseArea);
      const tipFinal = endHalf(tipResult, tipArea);
      // A sharp edge blending into a round one opens into a radius (the founder 2026-11-05): that end's half gains the
      // radius and its exact area the change, the level variant again. Two sharp ends, or two round, stay as they are.
      const opened = (end: typeof baseFinal, other: typeof baseFinal, share: number) => {
        const half = openedFinishedRail(end.half, other.half, share);
        return { half, exact: end.exact + (sampledSectionArea(half) - sampledSectionArea(end.half)) };
      };
      const opening = fit.tuck === "open" && isSharp(base) !== isSharp(tip);
      const baseEnd = opening && isSharp(base) ? opened(baseFinal, tipFinal, tipWeight) : baseFinal;
      const tipEnd = opening && isSharp(tip) ? opened(tipFinal, baseFinal, 1 - tipWeight) : tipFinal;
      const blended = blendFinishedRails(baseEnd.half, tipEnd.half, tipWeight);
''')
open(p,'w').write(s)

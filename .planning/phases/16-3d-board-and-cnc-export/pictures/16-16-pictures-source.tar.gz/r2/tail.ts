// Round 2, part B (D-38): the tail's rail carried round the tip, three amounts, in the scratch copy.
//   npx --no-install tsx --tsconfig <cand>/tsconfig.json tail.ts <cand> <out>
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const ROOT = process.argv[2];
const OUT = process.argv[3];
const CANDS: [string, string][] = [["today", ""], ["gentle", "0.25,0.75"], ["medium", "0.35,1"], ["full", "0.5,1.5"]];
const deg = (r: number) => (r * 180) / Math.PI;
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const all = F.phase16SurfaceBoards();
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return { geometry, profile, sections, surfaceInput: { sections, geometry, rockerAt: profile.rockerAt } };
  };
  const pictured = ["fish|asis|hard", "shortboard|asis|hard", "shortboard|pin|hard", "midlength|asis|hard", "shortboard|diamond|hard"];
  const out: any = {};
  for (const [name, spec] of CANDS) {
    if (spec) process.env.TAIL_ROLL = spec;
    else delete process.env.TAIL_ROLL;
    const rows: any = {};
    for (const board of all) {
      const { geometry, profile, sections, surfaceInput } = inputOf(board.fields);
      const surface = S.buildBoardSurface(surfaceInput);
      const p = surface.positions;
      const span = U.inchesToMm(2.5);
      const line = (k: number) =>
        surface.rings.filter((r: any) => r.station <= span).map((ring: any) => {
          const piece = ring.pieces[Math.min(k, ring.pieces.length - 1)];
          let top = -Infinity;
          let bot = Infinity;
          for (const v of S.pieceVertices(piece)) {
            top = Math.max(top, p[3 * v + 2]);
            bot = Math.min(bot, p[3 * v + 2]);
          }
          return { s: ring.station as number, top, bot };
        });
      const rows1 = line(0);
      let turn = 0;
      let botOff = 0;
      let rises = 0;
      for (let i = 1; i < rows1.length; i++) {
        botOff = Math.max(botOff, Math.abs(rows1[i].bot - profile.rockerAt(rows1[i].s)));
        if (i > 1) {
          const [a, b, c] = [rows1[i - 2], rows1[i - 1], rows1[i]];
          const t = Math.abs(deg(Math.atan2(c.top - b.top, c.s - b.s) - Math.atan2(b.top - a.top, b.s - a.s)));
          turn = Math.max(turn, t);
        }
        // the deck line above the side profile's deck, or dipping below the tip's own top: neither should happen
        if (rows1[i].top > profile.deckAt(rows1[i].s) + 1e-6) rises++;
      }
      const c = S.meshCheck(surface);
      const slices = S.boardSlices(surface);
      const litres = D.summarizeDesign(board.fields).volumeLitres;
      const vol = V.computeCrossSectionVolume(sections).volumeLitres;
      rows[board.label] = {
        kind: board.fields.outline.tail.kind,
        litres,
        gap: (S.enclosedVolumeMm3(surface) / 1e6 / vol - 1) * 100,
        faults: c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles,
        slices: slices.length,
        turn,
        botOff,
        rises,
        tipDeck: rows1[0].top - profile.rockerAt(0),
        tipT: profile.thicknessAt(0),
        drop: profile.deckAt(0) - rows1[0].top,
        firstSlice: { stationIn: U.mmToInches(slices[0].station), top: Math.max(...slices[0].loops.flat().map((q: number[]) => q[2])) - profile.rockerAt(slices[0].station) },
      };
      if (pictured.includes(board.label)) {
        const mesh = Rn.renderMesh(surface);
        const round = (arr: ArrayLike<number>, n: number) => Array.from(arr, (x) => +x.toFixed(n));
        writeFileSync(
          join(OUT, `tail-${name}-${board.label.replace(/\|/g, "_")}.json`),
          JSON.stringify({ label: board.label, length: board.fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface), tailZ: profile.rockerAt(0), tailT: profile.thicknessAt(0), tailHalf: O.sampleOutline(geometry, 0), kind: board.fields.outline.tail.kind }),
        );
      }
    }
    out[name] = rows;
    const r = Object.values(rows) as any[];
    console.log(name, "faults", r.reduce((n, x) => n + x.faults, 0), "gap", Math.min(...r.map((x) => x.gap)).toFixed(3), Math.max(...r.map((x) => x.gap)).toFixed(3), "turn", Math.max(...r.map((x) => x.turn)).toFixed(1), "bottom off", Math.max(...r.map((x) => x.botOff)).toFixed(4), "rises", r.reduce((n, x) => n + x.rises, 0));
  }
  const base = out.today;
  for (const [name] of CANDS.slice(1)) {
    const moves = Object.entries(out[name]).map(([k, v]: any) => [k, v.litres - base[k].litres] as [string, number]);
    moves.sort((a, b) => a[1] - b[1]);
    console.log(name, "litres", moves[0], moves[moves.length - 1]);
  }
  const labels = ["shortboard|asis|hard", "fish|asis|hard", "midlength|asis|hard", "longboard|asis|hard", "stock|hard", "shortboard|pin|hard", "shortboard|diamond|hard", "longboard|round|soft"];
  for (const l of labels) {
    console.log(l, out.today[l].kind, CANDS.map(([n]) => `${n} ${out[n][l].litres.toFixed(3)} drop ${out[n][l].drop.toFixed(1)}/${out[n][l].tipT.toFixed(1)} turn ${out[n][l].turn.toFixed(1)} gap ${out[n][l].gap.toFixed(3)} slice1 ${out[n][l].firstSlice.stationIn.toFixed(1)}" ${out[n][l].firstSlice.top.toFixed(2)}`).join(" | "));
  }
  writeFileSync(join(OUT, "tail.json"), JSON.stringify(out));
})();

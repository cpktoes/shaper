def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
d='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/pics/'
s=open(d+'dump.ts').read()
s=rep(s,'''      for (const r of rows) off = Math.max(off, Math.abs(r.top - profile.deckAt(r.s)), Math.abs(r.bot - profile.rockerAt(r.s)));
      return { flip, off };
''','''      for (const r of rows) off = Math.max(off, Math.abs(r.top - profile.deckAt(r.s)), Math.abs(r.bot - profile.rockerAt(r.s)));
      // The largest turn of the deck line between neighbouring panels, walking the line itself.
      let turn = 0;
      let bottomOff = 0;
      for (let i = 0; i < rows.length; i++) {
        bottomOff = Math.max(bottomOff, Math.abs(rows[i].bot - profile.rockerAt(rows[i].s)));
        if (i < 2) continue;
        const [a, b, c] = [rows[i - 2], rows[i - 1], rows[i]];
        turn = Math.max(turn, Math.abs(deg(Math.atan2(c.top - b.top, c.s - b.s) - Math.atan2(b.top - a.top, b.s - a.s))));
      }
      return { flip, off, turn, bottomOff };
''')
open(d+'dump.ts','w').write(s)

s=open(d+'tables.ts').read()
s=rep(s,'''  const R = await import(`${ROOT}/lib/geometry/rail-bands`);
  const SR = await import(`${ROOT}/lib/models/surface-report`);''','''  const R = await import(`${ROOT}/lib/geometry/rail-bands`);
  const SR = await import(`${ROOT}/lib/models/surface-report`);
  const VV = V;
  void VV;''')
a=s.index('  console.log("### The presets as their cards open them')
b=s.index('  console.log("\\n### The ledge')
s=s[:a]+'''  console.log("### The presets as their cards open them, and the stock 6'0\\"\\n");
  console.log("| Board | Site today (L) | With 16-15's fade alone (L) | Go-live 2 (L) | This plan's share (L) | Card today | Card at go-live 2 |\\n|---|---:|---:|---:|---:|---:|---:|");
  const open = [
    ...P.BOARD_PRESETS.map((preset: any) => [preset.name, { ...PB.presetDesignFields(preset), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC }]),
    ["Stock 6'0\\"", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: R.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  for (const [name, fields] of open) {
    const m = SR.surfaceLitresMove(fields);
    console.log(`| ${name} | ${m.before.toFixed(4)} | ${m.faded.toFixed(4)} | ${m.after.toFixed(4)} | ${signed(m.after - m.faded)} | ${m.before.toFixed(2)} | ${m.after.toFixed(2)} |`);
  }

'''+s[b:]
a=s.index('  console.log("\\n### The flip, per board')
b=s.index('  console.log("\\n### The 102 boards')
s=s[:a]+'''  console.log("\\n### The tips, per board and tip (the nose ends on the side profile; every tail rolls over)\\n");
  console.log("| Board | Tip | Corner today | Now | Deck off the side profile today (mm) | Now (mm) | Bottom off the rocker now (mm) |\\n|---|---|---:|---:|---:|---:|---:|");
  const worst = { nose: 0, turn: 0, bottom: 0 };
  for (const b of boards) {
    const [x, y] = [before[b.label], after[b.label]];
    const row = (tip: string, k: string, isNose: boolean) => {
      if (!x[k]) return;
      if (isNose) worst.nose = Math.max(worst.nose, y[k].flip);
      else worst.turn = Math.max(worst.turn, y[k].turn);
      worst.bottom = Math.max(worst.bottom, y[k].bottomOff);
      console.log(`| ${b.label} | ${tip} | ${x[k].flip.toFixed(1)}° | ${(isNose ? y[k].flip : y[k].turn).toFixed(2)}° | ${x[k].off.toFixed(2)} | ${y[k].off.toFixed(2)} | ${y[k].bottomOff.toFixed(4)} |`);
    };
    row("nose", "nose", true);
    row(x.tail2 ? "swallow point, right" : `tail (${x.tailKind})`, "tail", false);
    row("swallow point, left", "tail2", false);
  }
  console.log(`\\nNow: nose at most ${worst.nose.toFixed(3)}° off the side profile; tails' largest single panel turn ${worst.turn.toFixed(1)}°, spread round the roll; bottom at most ${worst.bottom.toFixed(4)} mm off the rocker.`);

'''+s[b:]
s=rep(s,'''  console.log(`\\n${same} of 102 bit-identical.`);''','''  console.log(`\\n${same} of 102 bit-identical to the pin under the live rule.`);''')
open(d+'tables.ts','w').write(s)

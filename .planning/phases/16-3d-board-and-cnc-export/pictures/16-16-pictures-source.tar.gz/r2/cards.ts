// Round 2: the foam the tail's roll really takes off each card's board, measured on the mesh, against what the litres'
// 51 stations see of it (station 0 only on a tail with width, nothing on a tail that comes to a point).
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const B = await import(`${ROOT}/lib/geometry/board`);
  const Ra = await import(`${ROOT}/lib/geometry/rail-bands`);
  const cards: [string, any][] = [
    ...P.BOARD_PRESETS.map((p: any) => [p.name, { ...PB.presetDesignFields(p), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC }] as [string, any]),
    ["Stock", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: Ra.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  const mesh = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return S.enclosedVolumeMm3(S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt })) / 1e6;
  };
  const fine = (fields: any, tail: string, L: number) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const n = 600;
    const at = Array.from({ length: n + 1 }, (_, i) => (i * L) / n);
    process.env.TAIL_ROLL = tail;
    const rolled = V.boardSections(sections, at).map((x: any) => x.area);
    delete process.env.TAIL_ROLL;
    const plain = V.boardSections(sections, at).map((x: any) => x.area);
    let v = 0;
    for (let i = 0; i < n; i++) v += (((rolled[i] - plain[i]) + (rolled[i + 1] - plain[i + 1])) / 2) * (L / n);
    return v / 1e6;
  };
  for (const [n, f] of cards) {
    delete process.env.TAIL_ROLL;
    const base = D.summarizeDesign(f).volumeLitres;
    const m0 = mesh(f);
    const row = ["0.25,0.75", "0.35,1", "0.5,1.5"].map((t) => {
      process.env.TAIL_ROLL = t;
      const seen = D.summarizeDesign(f).volumeLitres - base;
      const real = fine(f, t, 39);
      process.env.TAIL_ROLL = t;
      return `${t}: stations ${seen.toFixed(4)} true ${real.toFixed(4)} card if exact ${(base + real).toFixed(2)}`;
    });
    console.log(n, base.toFixed(4), row.join(" | "));
  }
})();

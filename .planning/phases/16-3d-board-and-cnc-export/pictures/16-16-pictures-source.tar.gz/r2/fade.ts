// Round 2, part C (D-39): what the fade really does, read off the app's own functions at the branch's HEAD rule.
//   npx --no-install tsx --tsconfig <cand>/tsconfig.json fade.ts <cand> <out>
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const Ra = await import(`${ROOT}/lib/geometry/rail-bands`);
  const Fo = await import(`${ROOT}/lib/geometry/foil`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const I = U.inchesToMm;
  const fieldsOf = (id: string) => ({ ...PB.presetDesignFields(P.BOARD_PRESETS.find((p: any) => p.id === id)), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC });
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return { geometry, profile, rails, input: D.designCrossSectionInput(geometry, profile, rails, fields.outline.length) };
  };
  const heightAt = (run: number[][], y: number) => {
    for (let i = 1; i < run.length; i++) {
      const [y0, h0] = run[i - 1];
      const [y1, h1] = run[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return run[run.length - 1][1];
  };
  const halfOf = (section: any) => S.placedHalfSection(section, section.halfWidth, 0) as number[][];
  const read = (section: any) => {
    const half = halfOf(section);
    const deck = half.slice(0, 48);
    const w = section.halfWidth;
    const T = section.thickness;
    const tuck = w - half[78][0]; // the bottom edge's distance in from the rail
    const apex = half[47];
    return { T, d05: T - heightAt(deck, w - I(0.5)), d1: T - heightAt(deck, w - I(1)), d2: T - heightAt(deck, w - I(2)), d3: T - heightAt(deck, w - I(3)), tuck, apex: apex[1], railT: section.result ? section.result.thickness : 0 };
  };
  const out: any = {};
  for (const [id, side] of [["shortboard", "tail"], ["fish", "nose"], ["midlength", "tail"], ["longboard", "tail"]] as const) {
    const fields = fieldsOf(id);
    const { rails, input } = inputOf(fields);
    const L = fields.outline.length;
    const anchors = Fo.foilStationPoints(input.foil, L);
    const [t12, centre, n12] = [anchors[1].station, anchors[2].station, anchors[3].station];
    const from = Ra.hardEdgeBlendsFrom(rails, L);
    const to = Ra.hardEdgeEndsAt(rails, L);
    const zone = side === "tail" ? [from, to] : [centre, n12];
    const slices = [0, 0.25, 0.5, 0.75, 1].map((f) => {
      const s = zone[0] + (zone[1] - zone[0]) * f;
      const { base, tip, tipWeight } = V.boardSectionEnds(input, s);
      const [live] = V.boardSections(input, [s]);
      return { stationIn: U.mmToInches(s), weight: tipWeight, live: halfOf(live), base: halfOf(base), tip: halfOf(tip), width: live.halfWidth, read: { live: read(live), base: read(base), tip: read(tip) } };
    });
    const along: any[] = [];
    for (let s = I(3); s <= L - I(3); s += I(0.5)) {
      const { base, tip, tipWeight } = V.boardSectionEnds(input, s);
      const [live] = V.boardSections(input, [s]);
      along.push({ in: U.mmToInches(s), w: tipWeight, live: read(live), base: read(base), tip: read(tip) });
    }
    out[id] = {
      side,
      lengthIn: U.mmToInches(L),
      marks: { t12: U.mmToInches(t12), from: U.mmToInches(from), to: U.mmToInches(to), centre: U.mmToInches(centre), n12: U.mmToInches(n12) },
      differs: { tail: V.railCharacterDifferences(rails, "tail"), nose: V.railCharacterDifferences(rails, "nose") },
      settings: {
        deck: [rails.tail.deckPercent, rails.center.deckPercent, rails.nose.deckPercent],
        ratio: [rails.tail.ratioTopPercent, rails.center.ratioTopPercent, rails.nose.ratioTopPercent],
        scale: [rails.tail.scaleFromCenter, 1, rails.nose.scaleFromCenter],
        family: [rails.tail.family, rails.center.family, rails.nose.family],
        hard: rails.tailHardEdge,
      },
      slices,
      along,
    };
    console.log(id, JSON.stringify(out[id].marks), JSON.stringify(out[id].differs), JSON.stringify(out[id].settings));
    for (const sl of slices) {
      const r = sl.read;
      console.log(`  ${sl.stationIn.toFixed(1)}" w=${sl.weight.toFixed(3)} 1"in drop live ${r.live.d1.toFixed(2)} base ${r.base.d1.toFixed(2)} tip ${r.tip.d1.toFixed(2)} | 2" ${r.live.d2.toFixed(2)} ${r.base.d2.toFixed(2)} ${r.tip.d2.toFixed(2)} | tuck ${r.live.tuck.toFixed(1)} ${r.base.tuck.toFixed(1)} ${r.tip.tuck.toFixed(1)} | apex ${r.live.apex.toFixed(1)} ${r.base.apex.toFixed(1)} ${r.tip.apex.toFixed(1)}`);
    }
  }
  writeFileSync(join(OUT, "fade.json"), JSON.stringify(out));
  // The candidates' litres, each preset as its card opens and the stock board.
  const B = await import(`${ROOT}/lib/geometry/board`);
  const boards: [string, any][] = [
    ...["shortboard", "fish", "midlength", "longboard"].map((id) => [id, fieldsOf(id)] as [string, any]),
    ["stock", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: Ra.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  const litres: any = {};
  for (const [id, fields] of boards) {
    const base = D.summarizeDesign(fields).volumeLitres;
    const L = fields.outline.length;
    const full = D.summarizeDesign({ ...fields, rails: { ...fields.rails, tailHardEdgeBlendsFrom: I(12), tailHardEdgeEndsAt: U.mm(L / 2) } }).volumeLitres;
    process.env.CONT_FOLLOWS = "1";
    const follows = D.summarizeDesign(fields).volumeLitres;
    delete process.env.CONT_FOLLOWS;
    litres[id] = { base, full, follows };
    console.log(id, base.toFixed(4), "whole stretch", (full - base).toFixed(4), "settings follow", (follows - base).toFixed(4));
  }
  writeFileSync(join(OUT, "fade-litres.json"), JSON.stringify(litres));
})();

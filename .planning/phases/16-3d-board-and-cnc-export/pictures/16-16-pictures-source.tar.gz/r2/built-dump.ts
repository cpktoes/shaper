// Round 3: the wing and the tail as committed, for his look, and the cards as the app reads them.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const [ROOT, OUT] = process.argv.slice(2);
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const B = await import(`${ROOT}/lib/geometry/board`);
  const Ra = await import(`${ROOT}/lib/geometry/rail-bands`);
  const SR = await import(`${ROOT}/lib/models/surface-report`);
  const fs = await import("node:fs");
  const pin = JSON.parse(fs.readFileSync(join(ROOT, "lib/geometry/__fixtures__/phase16-surface-litres-pin.json"), "utf8")).litres;
  const all = F.phase16SurfaceBoards();
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return { geometry, profile, sections, surfaceInput: { sections, geometry, rockerAt: profile.rockerAt } };
  };
  for (const label of ["wing|shortboard|one", "wing|midlength|rounded", "wing|fish|square", "fish|asis|hard", "shortboard|asis|hard", "shortboard|pin|hard", "midlength|asis|hard", "shortboard|diamond|hard"]) {
    const { fields } = all.find((b: any) => b.label === label);
    const { geometry, profile, surfaceInput } = inputOf(fields);
    const surface = S.buildBoardSurface(surfaceInput);
    const mesh = Rn.renderMesh(surface);
    const round = (a: ArrayLike<number>, n: number) => Array.from(a, (x) => +x.toFixed(n));
    const w = fields.outline.wings?.[0];
    const fp = w ? W.wingFootprint(w) : null;
    writeFileSync(join(OUT, `built-${label.replace(/\|/g, "_")}.json`), JSON.stringify({
      label, length: fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface),
      wings: fp ? [{ inner: fp.inner, stepStart: fp.stepStart, half: O.sampleOutline(geometry, fp.inner - 2) }] : [],
      tailZ: profile.rockerAt(0), tailT: profile.thicknessAt(0), tailHalf: O.sampleOutline(geometry, 0),
    }));
  }
  // the 102 again, as committed
  let faults = 0, gapLo = Infinity, gapHi = -Infinity, gapNoWing = -Infinity, lo = Infinity, hi = -Infinity, same = 0;
  for (const b of all) {
    const { sections, surfaceInput } = inputOf(b.fields);
    const surface = S.buildBoardSurface(surfaceInput);
    const c = S.meshCheck(surface);
    faults += c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles;
    const l = V.computeCrossSectionVolume(sections).volumeLitres;
    const g = (S.enclosedVolumeMm3(surface) / 1e6 / l - 1) * 100;
    gapLo = Math.min(gapLo, g); gapHi = Math.max(gapHi, g);
    if (!b.fields.outline.wings?.length) gapNoWing = Math.max(gapNoWing, g);
    const m = D.summarizeDesign(b.fields).volumeLitres;
    lo = Math.min(lo, m - Number(pin[b.label])); hi = Math.max(hi, m - Number(pin[b.label]));
    if (m.toPrecision(17) === pin[b.label]) same++;
  }
  console.log("102: faults", faults, "gap", gapLo.toFixed(3), gapHi.toFixed(3), "no-wing max", gapNoWing.toFixed(3), "move", lo.toFixed(4), hi.toFixed(4), "bit-identical", same);
  const cards: [string, any][] = [
    ...P.BOARD_PRESETS.map((p: any) => [p.name, { ...PB.presetDesignFields(p), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC }] as [string, any]),
    ["Stock 6'0\"", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: Ra.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  for (const [n, f] of cards) {
    const m = SR.surfaceLitresMove(f);
    console.log(n, "site today", m.before.toFixed(4), "fade alone", m.faded.toFixed(4), "go-live 2", m.after.toFixed(4), "card", m.before.toFixed(2), "→", m.after.toFixed(2));
  }
  const lines = SR.surfaceReportLines(all.map((b: any) => ({ id: b.label, fields: b.fields })));
  console.log(lines.slice(0, 4).join("\n"));
  console.log(lines[lines.length - 1]);
})();

p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/compose2.js'
s=open(p).read()
def rep(a,b):
    global s
    assert a in s, a[:70]
    s=s.replace(a,b)
rep('''.two{display:grid''','''.crop img{height:176px;object-fit:cover}
.two{display:grid''')
rep('''<div class="row r4">${cands.map((c, i) => fig(`B-${slug}-${c}-${view}`, labels[i])).join("")}</div>`''','''<div class="row r4 crop">${cands.map((c, i) => fig(`B-${slug}-${c}-${view}`, labels[i])).join("")}</div>`''')
rep('''return `<h2>${title}</h2><div style="padding:0 28px">${c}</div><div class="row r4">${frames}</div>`;''','''const note = slug.includes("fish") ? `<p style="margin-top:6px">The step's top edge is shorter and lower than as built, but still crisp: a square step is a wall. A corner radius on the wing softens it.</p>` : "";
    return `<h2>${title}</h2><div style="padding:0 28px">${c}</div><div class="row r4">${frames}</div>${note}`;''')
rep('''The shaded bands show both.</p>''','''The shaded bands show both.</p>
<p><b>If you want neither rail to sit still:</b> run the tail's fade from the 12" mark to the centre, as the nose does. A hard edge would start easing at 12" instead of 18". The cards: Longboard 72.40 → 72.35 L, the others the same.</p>''')
open(p,'w').write(s)

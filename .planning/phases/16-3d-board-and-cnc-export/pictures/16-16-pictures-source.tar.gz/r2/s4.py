def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/volume.ts'; s=open(p).read()
s=rep(s,''' * THE TAIL'S ROLL (Phase 16, D-38''',''' * A SHARP EDGE INTO A ROUND ONE (the founder, 2026-11-05: "make sure a sharp tuck can blend into a round tuck nicely").
 * Where a blend runs between a sharp bottom edge (a hard edge or a Sharp Bottom Tuck) and a round one, a point-for-point
 * blend keeps a real corner in every slice with its angle shrinking, a small kink along the board. So the sharp end's
 * corner opens first (`openedFinishedRail`): it gains a radius that grows with the round rail's share, and that half is
 * what blends. The litres count it the level way, the end's exact area plus the opened ring's less the sharp ring's. Two
 * sharp ends blend as they always did, so a sharp edge stays sharp all the way between them. The old rules keep the
 * corner (`OLD_SURFACE_FIT`).
 *
 * THE TAIL'S ROLL (Phase 16, D-38''')
open(p,'w').write(s)
p='e2e/desktop-baseline.spec.ts'; s=open(p).read()
s=rep(s,'''/**
 * RE-RECORDED 2026-11-05 (Phase 16, plan 16-16, branch board-3d) — 3D only, `three-d-desktop.png`, for the tail''','''/**
 * RE-RECORDED 2026-11-05 (Phase 16, plan 16-16, branch board-3d) — 3D only, `three-d-desktop.png`, for the sharp edge
 * opening into the round one (the founder: "make sure a sharp tuck can blend into a round tuck nicely"): the stock
 * board's hard edge now gains a radius through its fade in place of a shrinking corner. Compared with the tolerance
 * at 0: 120 pixels differ, all along the lower rail's edge between x 900 and 1017, y 517 to 523, where the fade lies, and
 * none by more than 50 of 255. The other five pictures passed and are byte-for-byte what they were — VOLUME still reads
 * 30.29 L. Rendered by the webpack dev server (`IS_WEBPACK_TEST=1`, port 3216) in the plan's worktree on this Mac; the
 * orchestrator confirms under the main checkout's Turbopack run after the merge. SHA-256 (first 8 characters), old to
 * new: 3D b5b8a3ef to d7842e75.
 *
 * RE-RECORDED 2026-11-05 (Phase 16, plan 16-16, branch board-3d) — 3D only, `three-d-desktop.png`, for the tail''')
open(p,'w').write(s)

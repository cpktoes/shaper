// Round 4: does any 1/16" floor in rail-bands bite along a board? Reads the app's own sections at every surface
// ring of the 102 boards, and works each mark's formula again to see which side of its floor it landed.
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const I = U.inchesToMm;
  const MIN = I(1 / 16);
  const near = (a: number, b: number) => Math.abs(a - b) < 1e-6;
  const hits: Record<string, { n: number; lowest: number; boards: Set<string>; at: number[] }> = {};
  const hit = (k: string, v: number, label: string, s: number) => {
    const h = (hits[k] ??= { n: 0, lowest: Infinity, boards: new Set(), at: [] });
    h.n++;
    h.lowest = Math.min(h.lowest, v);
    h.boards.add(label);
    h.at.push(U.mmToInches(s));
  };
  let seen = 0;
  for (const b of F.phase16SurfaceBoards()) {
    const geometry = O.buildOutline(b.fields.outline);
    const profile = D.designSideProfile(b.fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(b.fields.rails, profile.effectiveFoil, b.fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, b.fields.outline.length);
    const input = { sections, geometry, rockerAt: profile.rockerAt };
    for (const sec of V.boardSections(sections, S.surfaceStations(input))) {
      const r = sec.result;
      if (!r) continue;
      seen++;
      if (near(r.deckMark1, MIN)) hit("Deck Mark 1 held at 1/16", r.deckMark1, b.label, sec.station);
      if (near(r.deckMark2, MIN)) hit("Deck Mark 2 held at 1/16", r.deckMark2, b.label, sec.station);
      if (near(r.deckMark3, r.deckMark1 + MIN)) hit("Deck Mark 3 held 1/16 past Mark 1", r.deckMark3, b.label, sec.station);
      if (near(r.domedDeckBand, r.deckMark3 + MIN)) hit("Dome held 1/16 past Mark 3", r.domedDeckBand, b.label, sec.station);
      if (near(r.bottomTuck1, MIN)) hit("Bottom Tuck 1 held at 1/16", r.bottomTuck1, b.label, sec.station);
      if (near(r.bottomTuck2, MIN)) hit("Bottom Tuck 2 held at 1/16", r.bottomTuck2, b.label, sec.station);
      if (r.apexTrimmed) hit("Apex trimmed", r.apexLenRange, b.label, sec.station);
      if (near(r.apexLenRange, MIN)) hit("Apex held at 1/16", r.apexLenRange, b.label, sec.station);
      if (near(r.railTuck1, MIN)) hit("Rail Tuck 1 at 1/16", r.railTuck1, b.label, sec.station);
      if (near(r.bottomTuck3, r.bottomTuck1 + I(1 / 8)) || near(r.bottomTuck3, r.bottomTuck1 + I(1 / 16))) hit("Bottom Tuck 3 held past Tuck 1", r.bottomTuck3, b.label, sec.station);
    }
  }
  console.log("sections read", seen);
  if (Object.keys(hits).length === 0) console.log("no floor bites");
  for (const [k, h] of Object.entries(hits)) {
    console.log(k, "at", h.n, "stations, on", h.boards.size, "boards; lowest", h.lowest.toFixed(3), "mm; stations", Math.min(...h.at).toFixed(2) + '"', "to", Math.max(...h.at).toFixed(2) + '"', [...h.boards].slice(0, 3).join(", "));
  }
})();

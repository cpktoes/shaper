// The Mid-length plate, in the same style as compose3.js.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const png = (name) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${name}.png`)).toString("base64");
const STYLE = `<meta charset="utf-8"><style>
body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#0b0b0b;width:1400px}
h1{font-size:34px;margin:24px 28px 6px;line-height:1.15}p{margin:0 28px 10px;font-size:21px;color:#33322f;line-height:1.35}
h2{font-size:24px;margin:16px 28px 6px}.row{display:grid;gap:6px;padding:0 28px;grid-template-columns:1fr 1fr}
figure{margin:0;background:#1a1f28;border-radius:6px;overflow:hidden;position:relative}figure img{display:block;width:100%}
.t{position:absolute;left:6px;top:5px;background:rgba(255,255,255,.92);color:#111;font-size:16px;font-weight:600;padding:2px 7px;border-radius:4px}
</style>`;
const fig = (name, tag) => `<figure><img src="${png(name)}"><span class="t">${tag}</span></figure>`;
const pair = (n, title) => `<h2>${title}</h2><div class="row">${fig(`M-was-${n}`, "Before")}${fig(`M-now-${n}`, "Now")}</div>`;
const html = `<!doctype html><html><head>${STYLE}</head><body>
<h1>The Mid-length's rail, smooth</h1>
<p>The waves came from rounding the rail's thickness to the nearest 1/16" at every station. The board is now built from its actual thickness; only what you read stays rounded to the 1/16".</p>
${pair("whole-lit", "The whole board, low light")}${pair("whole-stripes", "The whole board, Contour Stripes")}${pair("wing-lit", "Near the wing, low light")}${pair("wing-stripes", "Near the wing, Contour Stripes")}
<div style="height:20px"></div></body></html>`;
(async () => {
  const browser = await chromium.launch();
  const file = path.join(dir, "16-16-r4-midlength.html");
  fs.writeFileSync(file, html);
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  await page.goto("file://" + file);
  const h = await page.evaluate(() => document.documentElement.scrollHeight);
  await page.screenshot({ path: path.join(dir, "16-16-r4-midlength.png"), fullPage: true });
  console.log("mid", h);
  await browser.close();
})();

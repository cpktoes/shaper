def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/volume.ts'; s=open(p).read()
s=rep(s,''' * into a round one point for point, a corner in every slice, shrinking; `"open"` opens the corner into a radius
 * that grows along the blend (`openedFinishedRail`).
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
  tail: "square" | "roll";
  tuck: "corner" | "open";
}
''',''' * into a round one point for point, a corner in every slice, shrinking; `"open"` opens the corner into a radius
 * that grows along the blend (`openedFinishedRail`). `rail`: on a domed deck, `"sixteenths"` builds each station's
 * rail from its thickness rounded to the nearest 1/16", which steps along the board; `"exact"` builds it from the
 * thickness itself, so the rail runs smooth. RAILS, DATA and the order form read `computeRailBands`, which keeps
 * the rounding, whichever rule the sections read.
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
  tail: "square" | "roll";
  tuck: "corner" | "open";
  rail: "sixteenths" | "exact";
}
''')
s=rep(s,'''export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip", tail: "square", tuck: "corner" };''','''export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip", tail: "square", tuck: "corner", rail: "sixteenths" };''')
s=rep(s,'''/** What every rule before plan 16-16 does: the whole section shifts in with a wing, a wide rail is cut off, and the
 * deck runs square to the tail's end. */''','''/** What every rule before plan 16-16 does: the whole section shifts in with a wing, a wide rail is cut off, the deck
 * runs square to the tail's end, a sharp edge blends as a corner and a domed rail steps by sixteenths. */''')
s=rep(s,'''  fit: { wings: "share", tips: "fit", tail: "roll", tuck: "open" },''','''  fit: { wings: "share", tips: "fit", tail: "roll", tuck: "open", rail: "exact" },''')
s=rep(s,''' * (`tailRollDrop`, D-38), with a sharp bottom edge opening into a round one along a blend (`openedFinishedRail`).''',''' * (`tailRollDrop`, D-38), with a sharp bottom edge opening into a round one along a blend (`openedFinishedRail`), and
 * a domed deck's rail built from its thickness itself, not rounded to a sixteenth.''')
s=rep(s,'''    const railThicknessClamped = roundToSixteenthInch(mm((thickness * deckPercent) / 100));
    const thicknessEff = domed ? railThicknessClamped : thickness;
''','''    const railThickness = mm((thickness * deckPercent) / 100);
    const thicknessEff = !domed ? thickness : fit.rail === "exact" ? railThickness : roundToSixteenthInch(railThickness);
''')
s=rep(s,''' * rail's fade`''',''' * rail's fade`''') if False else s
s=rep(s,''' * A SHARP EDGE INTO A ROUND ONE (the founder, 2026-11-05''',''' * A DOMED DECK'S RAIL (the founder, 2026-11-05, of the Mid-length: "all wavy and I do not like it"). RAILS reads the
 * rail-side thickness to the nearest 1/16", which is how a shaper marks it, but built station by station that rounding
 * stepped the rail about 25 times along a domed board. So the live rule builds the sections, and with them the
 * litres and the 3D board, from the thickness itself; the figures a shaper reads keep the rounding
 * (`computeRailBands`). The old rules keep the steps, by name for the pins (`OLD_SURFACE_FIT`).
 *
 * A SHARP EDGE INTO A ROUND ONE (the founder, 2026-11-05''')
s=rep(s,''' * The board
 * thickness at the station is T and the 1/16"-rounded tapered rail thickness t, so the Domed Deck Band
 * (2.4 x T) follows the board's own thickness along its length.''',''' * The board
 * thickness at the station is T and the tapered rail thickness t, so the Domed Deck Band (2.4 x T) follows the board's
 * own thickness along its length.''') if False else s
open(p,'w').write(s)

p='lib/models/surface-report.ts'; s=open(p).read()
s=rep(s,''' * It covers EVERY saved board, because the tail's roll reaches them all: a wing's two sides share its step, a rail
 * wider than its station near a tip is drawn into its room, and the deck rolls over into the tail's edge.''',''' * It covers EVERY saved board, because the tail's roll reaches them all: a wing's two sides share its step, a rail
 * wider than its station near a tip is drawn into its room, the deck rolls over into the tail's edge, a sharp edge
 * opens into a round one along a blend, and a domed deck's rail is built from its thickness itself.''')
open(p,'w').write(s)

p='lib/geometry/phase16-surface-litres-pin.test.ts'; s=open(p).read()
s=rep(s,'''tail: "square", tuck: "corner" } };''','''tail: "square", tuck: "corner", rail: "sixteenths" } };''')
open(p,'w').write(s)

p='lib/geometry/volume.test.ts'; s=open(p).read()
s=rep(s,'''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip", tail: "square", tuck: "corner" });''','''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip", tail: "square", tuck: "corner", rail: "sixteenths" });''')
s=rep(s,'''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit", tail: "roll", tuck: "open" });''','''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit", tail: "roll", tuck: "open", rail: "exact" });''')
open(p,'w').write(s)

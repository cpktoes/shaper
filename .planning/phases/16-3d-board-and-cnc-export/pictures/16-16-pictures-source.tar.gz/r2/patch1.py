# Round 2 candidates, in the scratch copy only. Environment switches stand in for rule objects:
#   WING_SHARE = "" (16-16 as built) | a reach spec: d<k> (k x the wing's depth), in<k> (k inches)
#   WING_ROLL  = the across-the-rail reach: dm2 (default), dm1, or a number of inches
#   TAIL_ROLL  = "" | "<fraction of tip thickness>,<run in inches>"
import os
R='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/cand/lib/geometry/'
def rep(s,a,b):
    assert a in s, a[:70]
    return s.replace(a,b)

# ---- wings.ts
p=R+'wings.ts'; s=open(p).read()
s=rep(s,'''function wingedFromPrepared(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {''','''/** SCRATCH (D-37): the along-the-board reach of the shared blend, either side of the step's middle. */
export function wingShareReach(depth: number, run: number): number {
  const spec = process.env.WING_SHARE ?? "";
  const k = Number(spec.replace(/^[a-z]+/, ""));
  const asked = spec.startsWith("d") ? k * depth : inchesToMm(k);
  return Math.max(asked, run / 2 + inchesToMm(1 / 8));
}

/** SCRATCH (D-37): where the deck's meeting curve stands against the stepped outline: + behind a wing, − ahead. */
export function wingDeltaAt(geometry: OutlineGeometry, station: Mm): Mm {
  if (!geometry.wings || geometry.wings.length === 0) return mm(0);
  const s = station as number;
  if (s <= geometry.tailPodStation) return mm(0);
  let delta = 0;
  for (const p of prepare(geometry.wings)) {
    const start = p.shape.points[0].station;
    const mid = (start + p.inner) / 2;
    const R = wingShareReach(p.depth, start - p.inner);
    const t = clamp((mid + R - s) / (2 * R), 0, 1);
    const phi = t * t * (3 - 2 * t);
    const fade = p.inner > geometry.tailPodStation ? clamp((s - geometry.tailPodStation) / (p.inner - geometry.tailPodStation), 0, 1) : 0;
    delta += p.depth * fade * (shareFromShape(p.shape, p.depth, s) - phi);
  }
  return mm(delta);
}

function wingedFromPrepared(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {''')
open(p,'w').write(s)

# ---- design.ts
p=R+'design.ts'; s=open(p).read()
s=rep(s,'''import { wingTakeAt } from "./wings";''','''import { wingDeltaAt, wingTakeAt } from "./wings";''')
s=rep(s,'''  return { ...foam, wingTakeAt: (station: Mm) => wingTakeAt(geometry, station) };''','''  return { ...foam, wingTakeAt: (station: Mm) => (process.env.WING_SHARE ? wingDeltaAt(geometry, station) : wingTakeAt(geometry, station)) };''')
open(p,'w').write(s)

# ---- volume.ts
p=R+'volume.ts'; s=open(p).read()
s=rep(s,'''    const room = take > 0 ? mm(foam + take) : foam;
''','''    const room = take !== 0 ? mm(foam + take) : foam;
''')
s=rep(s,'''export function wingStepHalf(half: HalfSectionPoints, room: number, take: number, deckMark3: Mm): HalfSectionPoints {
  const reach = Math.min(room, Math.max(deckMark3, 2 * take));
  if (1.5 * take >= reach) {''','''export function wingStepHalf(half: HalfSectionPoints, room: number, take: number, deckMark3: Mm): HalfSectionPoints {
  const reach = Math.min(room, Math.max(deckMark3, 2 * Math.abs(take)));
  if (1.5 * Math.abs(take) >= reach) {''')
s=rep(s,'''      const drawn = wingStepHalf(half, room, take, stepReach);
''','''      const drawn = wingStepHalf(half, room, take, rollReach(stepReach));
''')
s=rep(s,'''    const steppedIn = (built: BoardSection''','''    const rollReach = (dm3: Mm): Mm => {
      if (!process.env.WING_SHARE) return dm3;
      const roll = process.env.WING_ROLL ?? "dm2";
      if (roll === "dm2") return mm(dm3 / 3.6);
      if (roll === "dm1") return mm(dm3 / 1.8);
      return inchesToMm(Number(roll));
    };
    const steppedIn = (built: BoardSection''')
s=rep(s,'''      sections.push(take > 0 ? steppedIn(section, blended, stepReach) : section);
''','''      sections.push(tailRolled(take !== 0 ? steppedIn(section, blended, stepReach) : section, blended));
''')
s=rep(s,'''    if (take === 0 && !ended.fits) {
      sections.push(section);
      continue;
    }
    const { half, exact } = endHalf(result, ended);
    const counted = ended.fits ? { ...section, drawn: half, area: exact } : section;
    sections.push(take > 0 ? steppedIn(counted, half, result.deckMark3) : counted);
''','''    if (take === 0 && !ended.fits && !rolling) {
      sections.push(section);
      continue;
    }
    const { half, exact } = endHalf(result, ended);
    const counted = ended.fits ? { ...section, drawn: half, area: exact } : section;
    sections.push(tailRolled(take !== 0 ? steppedIn(counted, half, result.deckMark3) : counted, half));
''')
s=rep(s,'''    if (tipWeight > 0 && tipWeight < 1) {
      // The blend (D-31, level variant; D-32)''','''    // SCRATCH (D-38): the deck rolled over into the tail's edge, every height scaled, the bottom left alone.
    const rolling = tailFactor(station, thickness, input) < 1;
    const tailRolled = (built: BoardSection, half: HalfSectionPoints): BoardSection => {
      const k = tailFactor(station, thickness, input);
      if (k >= 1) return built;
      const from = built.drawn ?? built.blended ?? half;
      const drawn: HalfSectionPoints = from.map(([y, h]) => [y, h * k]);
      return { ...built, drawn, thickness: mm(thickness * k), area: built.area + (sampledSectionArea(drawn) - sampledSectionArea(from)) };
    };

    if (tipWeight > 0 && tipWeight < 1) {
      // The blend (D-31, level variant; D-32)''')
s=rep(s,'''    if (room === 0) {
      sections.push({
        station,
        halfWidth: foam,
        thickness,''','''    if (room === 0) {
      sections.push({
        station,
        halfWidth: foam,
        thickness: mm(thickness * tailFactor(station, thickness, input)),''')
s=rep(s,'''/**
 * The cross-sections the litres integrate, one per station''','''/** SCRATCH (D-38): the share of a station's thickness kept by the tail's roll: 1 clear of it. A quarter ellipse. */
function tailFactor(station: Mm, thickness: Mm, input: CrossSectionVolumeInput): number {
  const spec = process.env.TAIL_ROLL;
  if (!spec) return 1;
  const [amount, run] = spec.split(",").map(Number);
  const L = inchesToMm(run);
  if (station >= L) return 1;
  const atEnd = (input.thicknessAt?.(mm(0)) ?? thickness) * amount;
  const t = 1 - station / L;
  const drop = atEnd * (1 - Math.sqrt(Math.max(0, 1 - t * t)));
  return 1 - drop / thickness;
}

/**
 * The cross-sections the litres integrate, one per station''')
open(p,'w').write(s)

# ---- board-surface.ts
p=R+'board-surface.ts'; s=open(p).read()
s=rep(s,'''import { WING_HAIR_MM, wingStepShape } from "./wings";''','''import { WING_HAIR_MM, wingShareReach, wingStepShape } from "./wings";''')
s=rep(s,'''  const kept: number[] = [];
  const keep = (s: number) => {''','''  if (process.env.WING_SHARE) {
    // SCRATCH (D-37): rings through the shared blend, so a short reach isn't straddled.
    for (const wing of input.geometry.wings ?? []) {
      const { points } = wingStepShape(wing);
      const start = points[0].station;
      const end = points[points.length - 1].station;
      const mid = (start + end) / 2;
      const R = wingShareReach(wing.depth, start - end);
      for (let k = -12; k <= 12; k++) if (inside(mid + (k * R) / 12)) required.push(mid + (k * R) / 12);
    }
  }
  if (process.env.TAIL_ROLL) {
    // SCRATCH (D-38): rings round the tail's roll, even in the ellipse's own angle.
    const L = inchesToMm(Number(process.env.TAIL_ROLL.split(",")[1]));
    for (let k = 1; k <= 14; k++) required.push(L * (1 - Math.cos((k / 14) * (Math.PI / 2))));
  }
  const kept: number[] = [];
  const keep = (s: number) => {''')
open(p,'w').write(s)
print('ok')

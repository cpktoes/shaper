p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/overlay.ts'
s=open(p).read()
a='''  const [natural] = V.boardSectionsWith(sections, V.RAIL_CHARACTER_FADE, [station]);
  res.natural = S.placedHalfSection(natural, natural.halfWidth, 0);
'''
b='''  const [natural] = V.boardSectionsWith(sections, V.RAIL_CHARACTER_FADE, [station]);
  res.natural = S.placedHalfSection(natural, natural.halfWidth, 0);
  // The natural rail on the stepped outline with its deck side lifted onto the deck: distances across kept, so the
  // rail's own curve near its wall stays, only higher up.
  const deckRun = res.natural.slice(0, 48);
  const W0 = natural.halfWidth;
  const heightAt = (y: number) => {
    for (let i = 1; i < H.length; i++) {
      const [y0, h0] = H[i - 1];
      const [y1, h1] = H[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return 0;
  };
  const lift = (X: number) =>
    res.natural.map(([y, h]: number[], i: number) => {
      if (i >= 48) return [y, h];
      const x = W0 - y;
      const t = Math.min(1, x / X);
      const r = t * t * (3 - 2 * t);
      return [y, h + (heightAt(y) - h) * r];
    });
  res.curves.lift08 = lift(U.inchesToMm(0.8));
  res.curves.lift12 = lift(U.inchesToMm(1.2));
  res.curves.liftdm2 = lift(p.result.deckMark2);
  void deckRun;
'''
assert a in s
s=s.replace(a,b)
open(p,'w').write(s)
p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/overlay-plate.js'
s=open(p).read()
s=s.replace('r10: "#d97706" }','r10: "#d97706", lift08: "#db2777", lift12: "#ca8a04", liftdm2: "#16a34a" }')
open(p,'w').write(s)

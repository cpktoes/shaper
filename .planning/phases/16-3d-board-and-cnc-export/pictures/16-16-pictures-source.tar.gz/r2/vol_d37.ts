describe("D-37 a wing's two sides share the step, and the rail rolls straight up into the deck", () => {
  type Half = readonly (readonly [number, number])[];
  const BOTTOM_EDGE = SECTION_POINTS.deck + SECTION_POINTS.rail - 2;
  const deckRun = (half: Half) => half.slice(0, SECTION_POINTS.deck);
  const bottomRun = (half: Half) => half.slice(BOTTOM_EDGE);
  /** The drawn half of a section, as the 3D board lays it. */
  const halfOf = (section: BoardSection): Half => placedHalfSection(section, section.halfWidth, 0);
  /** Whether a run's distance across never turns back (`sign` 1 on the deck, walking out; −1 on the bottom). */
  const folds = (run: Half, sign: 1 | -1) => run.some((p, i) => i > 0 && sign * (p[0] - run[i - 1][0]) < -1e-9);
  /** A deck run's height at a distance across. */
  function heightAt(run: Half, y: number): number {
    for (let i = 1; i < run.length; i++) {
      const [y0, h0] = run[i - 1];
      const [y1, h1] = run[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return run[run.length - 1][1];
  }

  function inputOf(fields: DesignSummaryFields) {
    const geometry = buildOutline(fields.outline);
    const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
    const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return { geometry, input: designCrossSectionInput(geometry, profile, rails, fields.outline.length) };
  }
  /** The live rule with its wing behaviour set back: the whole section shifts in with the outline. */
  const SHIFT_WITH_LIVE_TIPS: RailCharacterRule = { ...SMOOTH_SURFACE_FADE, fit: { ...SMOOTH_SURFACE_FADE.fit!, wings: "shift" } };

  /** One winged board, with its stations every 2 mm through each wing's shared stretch, three ways. */
  const WINGED = phase16WingBoards().map((board) => {
    const { geometry, input } = inputOf(board.fields);
    const plain = inputOf({ ...board.fields, outline: outlineWithoutWings(board.fields.outline) }).input;
    const wings = geometry.wings!;
    const stations: Mm[] = [];
    for (const wing of wings) {
      const { middle, reach } = wingShareSpan(wing);
      for (let s = middle - reach; s <= middle + reach; s += 2) stations.push(mm(s));
    }
    const live = boardSections(input, stations);
    const shifted = boardSectionsWith(input, SHIFT_WITH_LIVE_TIPS, stations);
    const without = boardSections(plain, stations);
    return { ...board, geometry, input, plain, wings, stations, live, shifted, without };
  });
  const isDeep = (board: (typeof WINGED)[number]) => board.wings.some((wing) => wing.depth > inchesToMm(1 / 2));
  /** The jump in the deck across a wing at one distance from the stringer, the board's own taper taken out. */
  const ledgeAt = (rule: "live" | "shift", board: (typeof WINGED)[number], wing: Wing, y: (behindWidth: number) => number) => {
    const { stepStart, inner } = wingFootprint(wing);
    const stations = [mm(stepStart + 2), mm(inner - 2)];
    const sections = rule === "live" ? boardSections(board.input, stations) : boardSectionsWith(board.input, SHIFT_WITH_LIVE_TIPS, stations);
    const [plainAhead, plainBehind] = boardSections(board.plain, stations);
    const at = y(sections[1].halfWidth);
    return (
      heightAt(deckRun(halfOf(sections[0])), at) -
      heightAt(deckRun(halfOf(sections[1])), at) -
      (heightAt(deckRun(halfOf(plainAhead)), at) - heightAt(deckRun(halfOf(plainBehind)), at))
    );
  };

  it("the 28 boards each reach through their wing", () => {
    expect(WINGED).toHaveLength(28);
    for (const board of WINGED) expect(board.stations.length).toBeGreaterThan(100);
  });

  describe("wingStepHalf: the rail moved onto the outline, the deck left on its line", () => {
    const rail = computeRailBands(DEFAULT_RAIL_BAND_SPEC).center.result;
    const moves = [0.01, 0.5, inchesToMm(3 / 16), inchesToMm(3 / 8), inchesToMm(1 / 2), inchesToMm(1)];
    const rooms = (move: number) => [1.6, 2, 3, 5, 12].map((k) => k * move).concat([100, 200, 300]);

    for (const size of moves) {
      for (const move of [size, -size]) {
        it(`a move of ${move.toFixed(2)} mm, on rooms from 1.6 × the move to 300 mm`, () => {
          for (const room of rooms(size)) {
            const half = sampledFinishedRail(rail, true, room);
            const moved = wingStepHalf(half, room, move, rail.deckMark2);
            const reach = Math.min(room, Math.max(rail.deckMark2, 2 * size));
            expect(moved[0]).toEqual(half[0]);
            expect(moved[moved.length - 1]).toEqual(half[half.length - 1]);
            expect(Math.abs(Math.max(...moved.map((p) => p[0])) - (room - move))).toBeLessThan(1e-9);
            expect(folds(deckRun(moved), 1)).toBe(false);
            expect(folds(bottomRun(moved), -1)).toBe(false);
            moved.forEach((p, i) => {
              expect(p[1]).toBe(half[i][1]);
              if (1.5 * size < reach && room - half[i][0] >= reach) expect(p[0]).toBe(half[i][0]);
            });
          }
        });
      }
    }

    it("moves nothing with a move of 0", () => {
      const half = sampledFinishedRail(rail, true, 200);
      expect(wingStepHalf(half, 200, 0, rail.deckMark2)).toEqual(half);
    });
  });

  for (const board of WINGED) {
    it(`${board.label}: the deck runs smooth across the wing, where the whole section's shift left a ledge`, () => {
      for (const wing of board.wings) {
        for (const inches of [1, 2]) {
          const y = (width: number) => width - inchesToMm(inches);
          const shared = Math.abs(ledgeAt("live", board, wing, y));
          const shifted = Math.abs(ledgeAt("shift", board, wing, y));
          expect(shifted).toBeGreaterThan(0.1);
          expect(shared).toBeLessThan(shifted / 2);
        }
      }
    }, 60_000);

    it(`${board.label}: behind the wing the rail stands thicker, ahead of it thinner, and they share the step`, () => {
      let behind = 0;
      let ahead = 0;
      board.stations.forEach((station, i) => {
        const share = wingShareAt(board.geometry, station);
        // Clear of the blend's far ends, where the share is too small to read.
        if (Math.abs(share) < 0.25) return;
        const y = board.live[i].halfWidth - inchesToMm(1);
        const drawn = heightAt(deckRun(halfOf(board.live[i])), y);
        const own = heightAt(deckRun(halfOf(board.shifted[i])), y);
        if (share > 0) {
          expect(drawn).toBeGreaterThan(own);
          behind++;
        } else {
          expect(drawn).toBeLessThan(own);
          ahead++;
        }
      });
      expect(behind).toBeGreaterThan(10);
      expect(ahead).toBeGreaterThan(10);
    }, 60_000);

    it(`${board.label}: the rail stands on the stepped outline, the bottom stays flat, and nothing folds`, () => {
      board.stations.forEach((station, i) => {
        const section = board.live[i];
        const drawn = halfOf(section);
        expect(section.halfWidth).toBe(foamHalfWidthOf(board.geometry, station));
        expect(Math.abs(Math.max(...drawn.map((p) => p[0])) - section.halfWidth)).toBeLessThan(1e-9);
        expect(folds(deckRun(drawn), 1)).toBe(false);
        expect(folds(bottomRun(drawn), -1)).toBe(false);
        for (const [, h] of bottomRun(drawn)) expect(h).toBeLessThan(1e-9);
      });
    }, 60_000);

    it(`${board.label}: a station the shared stretch does not reach reads what it read with the wing rule off`, () => {
      const live = boardSections(board.input);
      const shifted = boardSectionsWith(board.input, SHIFT_WITH_LIVE_TIPS);
      let reached = 0;
      live.forEach((section, i) => {
        if (wingShareAt(board.geometry, section.station) !== 0) {
          reached++;
          return;
        }
        expect(Object.is(section.area, shifted[i].area)).toBe(true);
        expect(Object.is(section.blendArea, shifted[i].blendArea)).toBe(true);
        expect(section.drawn).toEqual(shifted[i].drawn);
      });
      expect(reached).toBeGreaterThan(0);
      expect(reached).toBeLessThan(live.length);
    }, 60_000);
  }

  describe("the tuck moves with the rail", () => {
    for (const board of WINGED.filter((b) => b.label.endsWith("|one") && b.input.rails.tailHardEdge)) {
      it(`${board.label}: on a hard edge the corner is the rail itself, on the stepped outline`, () => {
        let hard = 0;
        board.stations.forEach((_, i) => {
          const section = board.live[i];
          if (section.hardWeight !== 1) return;
          hard++;
          expect(Math.abs(halfOf(section)[BOTTOM_EDGE][0] - section.halfWidth)).toBeLessThan(1e-9);
        });
        expect(hard).toBeGreaterThan(10);
      });
    }

    for (const board of WINGED.filter((b) => b.label.endsWith("|one-soft") && !b.input.rails.center.symmetrical)) {
      it(`${board.label}: a tuck narrower than the roll stays its own width from the rail, within the move`, () => {
        board.stations.forEach((station, i) => {
          const section = board.live[i];
          const width = section.halfWidth - halfOf(section)[BOTTOM_EDGE][0];
          const own = board.shifted[i].halfWidth - halfOf(board.shifted[i])[BOTTOM_EDGE][0];
          expect(Math.abs(width - own)).toBeLessThanOrEqual(Math.abs(wingShareAt(board.geometry, station)) + 1e-6);
        });
      }, 60_000);
    }
  });
});


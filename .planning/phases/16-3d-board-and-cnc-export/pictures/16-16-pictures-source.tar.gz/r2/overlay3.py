p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/overlay.ts'
s=open(p).read()
a='''  writeFileSync(join(OUT, "overlay.json"), JSON.stringify(res));
'''
b='''  process.env.WING_SHARE = "in3";
  const [shared] = V.boardSections(inputOf(board.fields).sections, [station]);
  res.shared = S.placedHalfSection(shared, shared.halfWidth, 0);
  res.sharedDelta = W.wingDeltaAt(geometry, station);
  delete process.env.WING_SHARE;
  writeFileSync(join(OUT, "overlay.json"), JSON.stringify(res));
'''
assert a in s
s=s.replace(a,b)
open(p,'w').write(s)

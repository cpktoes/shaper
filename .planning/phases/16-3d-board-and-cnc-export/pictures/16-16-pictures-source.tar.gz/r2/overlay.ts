// Round 2: the roll across the rail, fitted against the founder's own red line. The slice he drew on, the rail moved
// in by the full take (no sharing yet), at several across-the-rail reaches.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const board = F.phase16WingBoards().find((b: any) => b.label === "wing|shortboard|rounded");
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return { geometry, sections: D.designCrossSectionInput(geometry, profile, rails, fields.outline.length) };
  };
  const { geometry, sections } = inputOf(board.fields);
  const plain = inputOf({ ...board.fields, outline: W.outlineWithoutWings(board.fields.outline) }).sections;
  const stations = V.crossSectionStations(sections.length, O.tailCutStation(geometry));
  const inner = W.wingFootprint(geometry.wings[0]).inner;
  const station = [...stations].reverse().find((s: number) => s < inner);
  const [p] = V.boardSections(plain, [station]);
  const H = S.placedHalfSection(p, p.halfWidth, 0);
  const take = W.wingTakeAt(geometry, station);
  const room = p.halfWidth;
  const dm3 = p.result.deckMark3;
  const res: any = { stationIn: U.mmToInches(station), W: room - take, take, dm1: p.result.deckMark1, dm2: p.result.deckMark2, dm3, dd: p.result.domedDeckBand, plain: H, curves: {} };
  for (const [name, reach] of Object.entries({ asbuilt: dm3, dm1: p.result.deckMark1, dm2: p.result.deckMark2, r075: U.inchesToMm(0.75), r10: U.inchesToMm(1) })) {
    res.curves[name] = V.wingStepHalf(H, room, take, reach);
  }
  const [natural] = V.boardSectionsWith(sections, V.RAIL_CHARACTER_FADE, [station]);
  res.natural = S.placedHalfSection(natural, natural.halfWidth, 0);
  // The natural rail on the stepped outline with its deck side lifted onto the deck: distances across kept, so the
  // rail's own curve near its wall stays, only higher up.
  const deckRun = res.natural.slice(0, 48);
  const W0 = natural.halfWidth;
  const heightAt = (y: number) => {
    for (let i = 1; i < H.length; i++) {
      const [y0, h0] = H[i - 1];
      const [y1, h1] = H[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return 0;
  };
  const lift = (X: number) =>
    res.natural.map(([y, h]: number[], i: number) => {
      if (i >= 48) return [y, h];
      const x = W0 - y;
      const t = Math.min(1, x / X);
      const r = t * t * (3 - 2 * t);
      return [y, h + (heightAt(y) - h) * r];
    });
  res.curves.lift08 = lift(U.inchesToMm(0.8));
  res.curves.lift12 = lift(U.inchesToMm(1.2));
  res.curves.liftdm2 = lift(p.result.deckMark2);
  void deckRun;
  process.env.WING_SHARE = "in3";
  const [shared] = V.boardSections(inputOf(board.fields).sections, [station]);
  res.shared = S.placedHalfSection(shared, shared.halfWidth, 0);
  res.sharedDelta = W.wingDeltaAt(geometry, station);
  delete process.env.WING_SHARE;
  writeFileSync(join(OUT, "overlay.json"), JSON.stringify(res));
  console.log({ stationIn: res.stationIn, W: res.W, take, dm1: res.dm1, dm2: res.dm2, dm3, dd: res.dd });
})();

// Round 4: the Mid-length, as it was (rounded rail) and is now, whole board and near a wing. Args: <root> <tag> <out>
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const [ROOT, TAG, OUT] = process.argv.slice(2);
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  for (const label of ["midlength|asis|hard", "wing|midlength|rounded"]) {
    const { fields } = F.phase16SurfaceBoards().find((b: any) => b.label === label);
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
    const mesh = Rn.renderMesh(surface);
    const round = (a: ArrayLike<number>, n: number) => Array.from(a, (x) => +x.toFixed(n));
    const w = fields.outline.wings?.[0];
    const fp = w ? W.wingFootprint(w) : null;
    writeFileSync(join(OUT, `mid-${TAG}-${label.split("|")[0]}.json`), JSON.stringify({
      label, length: fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface),
      wings: fp ? [{ inner: fp.inner, stepStart: fp.stepStart, half: O.sampleOutline(geometry, fp.inner - 2) }] : [],
      width: fields.outline.widePointWidth,
    }));
  }
  console.log("ok", TAG);
})();

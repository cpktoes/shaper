def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/finished-rail.ts'; s=open(p).read()
a=s.index('/** The point `arc` millimetres along a polyline')
b=s.index('/** The foam a sampled half-section and its mirror enclose together')
s=s[:a]+'''/** How far the sharp corner may open along each side, as a share of what that side has. */
const OPEN_ROOM = 0.8;
/** The least a corner opens to at the full share, in inches, for a round rail that lands right beside it. */
const OPEN_FLOOR_IN = 1 / 8;

/** Each point's distance along a run from the run's first point. */
function runLengths(run: readonly P2[]): number[] {
  const lengths = [0];
  for (let i = 1; i < run.length; i++) {
    lengths.push(lengths[i - 1] + Math.hypot(run[i][0] - run[i - 1][0], run[i][1] - run[i - 1][1]));
  }
  return lengths;
}

/** The point `arc` along a run whose `lengths` are known. */
function pointAlong(run: readonly P2[], lengths: readonly number[], arc: number): P2 {
  let i = 1;
  while (i < run.length - 1 && lengths[i] < arc) i++;
  const d = lengths[i] - lengths[i - 1];
  const t = d > 0 ? (arc - lengths[i - 1]) / d : 0;
  return [run[i - 1][0] + (run[i][0] - run[i - 1][0]) * t, run[i - 1][1] + (run[i][1] - run[i - 1][1]) * t];
}

/**
 * A sharp half with its bottom corner opened toward a round rail (Phase 16, the founder 2026-11-05: "make sure a sharp
 * tuck can blend into a round tuck nicely. ... It's typical to have a sharp tuck at center that smooths/rounds toward
 * the nose."). `share` is how much of the station is the round rail's, 0 to 1. A point-for-point blend keeps a real
 * corner in every slice with its angle shrinking, the small kink he saw; here the corner gains a radius instead: a
 * parabola with the corner as its control, leaving each side `share` of the way along the reach, which is how far
 * across the round rail lands from the corner. Point for point, as the blend needs: the bottom edge's point moves to
 * the curve's foot on the bottom, the rail's points near the corner slide onto the curve, the bottom's points
 * inside the foot spread out beyond it, and every other point stays exactly where it was. At `share` 0 it is the
 * sharp half.
 */
export function openedFinishedRail(sharp: HalfSectionPoints, round: HalfSectionPoints, share: number): HalfSectionPoints {
  const edge = SECTION_POINTS.deck + SECTION_POINTS.rail - 2;
  const corner = sharp[edge];
  const reach = Math.max(Math.abs(corner[0] - round[edge][0]), inchesToMm(OPEN_FLOOR_IN)) * share;
  const up = sharp.slice(SECTION_POINTS.deck - 1, edge + 1).reverse() as P2[];
  const along = sharp.slice(edge) as P2[];
  const [upLengths, alongLengths] = [runLengths(up), runLengths(along)];
  const a = Math.min(reach, OPEN_ROOM * upLengths[upLengths.length - 1]);
  const b = Math.min(reach, OPEN_ROOM * alongLengths[alongLengths.length - 1]);
  if (!(a > 0) || !(b > 0)) return sharp;
  const start = pointAlong(up, upLengths, a);
  const foot = pointAlong(along, alongLengths, b);
  const opened = sharp.map(([y, h]): P2 => [y, h]);
  for (let k = 0; k < up.length && upLengths[k] < a; k++) {
    const t = 1 - upLengths[k] / a;
    const [u, v, w] = [(1 - t) * (1 - t), 2 * t * (1 - t), t * t];
    opened[edge - k] = [u * start[0] + v * corner[0] + w * foot[0], u * start[1] + v * corner[1] + w * foot[1]];
  }
  opened[edge] = [foot[0], 0];
  let beyond = 1;
  while (beyond < along.length - 1 && alongLengths[beyond] <= b) beyond++;
  for (let k = 1; k < beyond; k++) {
    const t = k / beyond;
    opened[edge + k] = [foot[0] + (along[beyond][0] - foot[0]) * t, 0];
  }
  return opened;
}

'''+s[b:]
open(p,'w').write(s)

p='lib/geometry/volume.test.ts'; s=open(p).read()
s=rep(s,'''        const baseHalf = sampledFinishedRail(ends.base.result!, ends.base.domed, ends.base.halfWidth);
        const tipHalf = sampledFinishedRail(ends.tip.result!, ends.tip.domed, ends.tip.halfWidth);
        const w = section.tipWeight;
        expect(section.blended).toEqual(blendFinishedRails(baseHalf, tipHalf, w));
        const expected =''','''        const baseHalf = sampledFinishedRail(ends.base.result!, ends.base.domed, ends.base.halfWidth);
        const tipHalf = sampledFinishedRail(ends.tip.result!, ends.tip.domed, ends.tip.halfWidth);
        const w = section.tipWeight;
        expect(section.blended).toEqual(liveBlend(ends, baseHalf, tipHalf, w));
        const expected =''')
s=rep(s,'''        const baseHalf = sampledFinishedRail(ends.base.result!, ends.base.domed, ends.base.halfWidth);
        const tipHalf = sampledFinishedRail(ends.tip.result!, ends.tip.domed, ends.tip.halfWidth);
        expect(section.blended).toEqual(blendFinishedRails(baseHalf, tipHalf, section.tipWeight));
        const area = fadingSectionArea(ends.base.area, ends.tip.area, baseHalf, tipHalf, section.blended!, section.tipWeight);
        expect(Math.abs(section.area - area) / section.area).toBeLessThan(1e-9);
''','''        const baseHalf = sampledFinishedRail(ends.base.result!, ends.base.domed, ends.base.halfWidth);
        const tipHalf = sampledFinishedRail(ends.tip.result!, ends.tip.domed, ends.tip.halfWidth);
        const w = section.tipWeight;
        expect(section.blended).toEqual(liveBlend(ends, baseHalf, tipHalf, w));
        const area =
          sampledSectionArea(section.blended!) +
          (1 - w) * (ends.base.area - sampledSectionArea(baseHalf)) +
          w * (ends.tip.area - sampledSectionArea(tipHalf));
        expect(Math.abs(section.area - area) / section.area).toBeLessThan(1e-9);
''')
s=rep(s,'''const SQMM_PER_SQIN = MM_PER_INCH * MM_PER_INCH;
''','''const SQMM_PER_SQIN = MM_PER_INCH * MM_PER_INCH;

/** A station's blend as the live rule draws it from its two ends' halves: a sharp end opened toward a round one. */
function liveBlend(
  ends: { base: BoardSection; tip: BoardSection },
  baseHalf: [number, number][],
  tipHalf: [number, number][],
  w: number,
) {
  const [baseSharp, tipSharp] = [ends.base.sharpness === 1, ends.tip.sharpness === 1];
  if (baseSharp === tipSharp) return blendFinishedRails(baseHalf, tipHalf, w);
  return baseSharp
    ? blendFinishedRails(openedFinishedRail(baseHalf, tipHalf, w), tipHalf, w)
    : blendFinishedRails(baseHalf, openedFinishedRail(tipHalf, baseHalf, 1 - w), w);
}
''')
s=rep(s,'''  fittedFinishedRail,
  railBlendArea,
  railReach,''','''  fittedFinishedRail,
  openedFinishedRail,
  railBlendArea,
  railReach,''')
s=rep(s,'''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip", tail: "square" });''','''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip", tail: "square", tuck: "corner" });''')
s=rep(s,'''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit", tail: "roll" });''','''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit", tail: "roll", tuck: "open" });''')
s=rep(s,'''    // A board 40 mm wide all along: every station is narrow, and the nose and the tail differ from the centre.
    const room = mm(20);
    const rails: RailBandSpec = {
      ...DEFAULT_RAIL_BAND_SPEC,
      tailHardEdge: true,
      nose: { ...DEFAULT_RAIL_BAND_SPEC.nose, sharpBottomTuck: true },
    };''','''    // A board 40 mm wide all along: every station is narrow, and the nose and the tail differ from the centre.
    const room = mm(20);
    const family: RailFamily = DEFAULT_RAIL_BAND_SPEC.center.family === 3 ? 4 : 3;
    const rails: RailBandSpec = {
      ...DEFAULT_RAIL_BAND_SPEC,
      tailHardEdge: false,
      tail: { ...DEFAULT_RAIL_BAND_SPEC.tail, family },
      nose: { ...DEFAULT_RAIL_BAND_SPEC.nose, family },
    };''')
s=s.rstrip('\n')+'''

describe("a sharp bottom edge opens into a round one along the blend (the founder, 2026-11-05)", () => {
  const EDGE = SECTION_POINTS.deck + SECTION_POINTS.rail - 2;
  /** The largest turn between neighbouring points around the tuck, in degrees. */
  function tuckTurn(half: readonly (readonly [number, number])[]): number {
    let best = 0;
    for (let i = EDGE - 16; i <= EDGE + 8; i++) {
      const a = Math.atan2(half[i][1] - half[i - 1][1], half[i][0] - half[i - 1][0]);
      const b = Math.atan2(half[i + 1][1] - half[i][1], half[i + 1][0] - half[i][0]);
      const d = (Math.abs(b - a) * 180) / Math.PI;
      best = Math.max(best, d > 180 ? 360 - d : d);
    }
    return best;
  }
  function inputOf(label: string) {
    const { fields } = phase16SurfaceBoards().find((board) => board.label === label)!;
    const geometry = buildOutline(fields.outline);
    const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
    const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return designCrossSectionInput(geometry, profile, rails, fields.outline.length);
  }
  const zone = (input: ReturnType<typeof inputOf>, side: "tail" | "nose") => {
    const points = foilStationPoints(input.foil, input.length);
    return side === "nose"
      ? [points[2].station, points[3].station]
      : [hardEdgeBlendsFrom(input.rails, input.length), hardEdgeEndsAt(input.rails, input.length)];
  };
  const halfOf = (section: BoardSection) => placedHalfSection(section, section.halfWidth, 0);

  const cases: [string, "tail" | "nose"][] = [
    ["tucked|shortboard|he-centre-sbt", "nose"],
    ["tucked|fish|he-centre-sbt", "nose"],
    ["tucked|shortboard|tail-sbt", "tail"],
    ["tucked|fish|tail-sbt", "tail"],
    ["shortboard|asis|hard", "tail"],
    ["fish|asis|hard", "tail"],
  ];
  for (const [label, side] of cases) {
    it(`${label}: by the blend's middle the corner is gone, where a point-for-point blend still carries one`, () => {
      const input = inputOf(label);
      const [from, to] = zone(input, side);
      const s = mm((from + to) / 2);
      const [live] = boardSections(input, [s]);
      const [corner] = boardSectionsWith(input, { at: RAIL_CHARACTER_FADE.at }, [s]);
      const ends = boardSectionEnds(input, s);
      const round = ends.base.sharpness === 1 ? ends.tip : ends.base;
      const own = tuckTurn(halfOf(round));
      expect(tuckTurn(halfOf(live))).toBeLessThan(own + 3);
      expect(tuckTurn(halfOf(corner))).toBeGreaterThan(own + 8);
    });

    it(`${label}: the turn only eases along the blend, from the sharp end to the round`, () => {
      const input = inputOf(label);
      const [from, to] = zone(input, side);
      const fractions = Array.from({ length: 11 }, (_, i) => i / 10).slice(1, -1);
      const stations = fractions.map((f) => mm(from + (to - from) * f));
      const turns = boardSections(input, stations).map((section) => tuckTurn(halfOf(section)));
      const ordered = side === "tail" ? turns : turns;
      for (let i = 1; i < ordered.length; i++) expect(ordered[i]).toBeLessThan(ordered[i - 1] + 1);
    });
  }

  it("two sharp ends stay sharp: a hard tail into a sharp centre is the point blend, as it was", () => {
    const input = inputOf("tucked|shortboard|he-centre-sbt");
    const [from, to] = zone(input, "tail");
    const s = mm((from + to) / 2);
    const [live] = boardSections(input, [s]);
    const [corner] = boardSectionsWith(input, { at: RAIL_CHARACTER_FADE.at }, [s]);
    expect(live.blended).toEqual(corner.blended);
    expect(live.sharpness).toBe(1);
  });

  describe("openedFinishedRail", () => {
    const rails = computeRailBands({ ...DEFAULT_RAIL_BAND_SPEC, center: { ...DEFAULT_RAIL_BAND_SPEC.center, sharpBottomTuck: true } });
    const roundRails = computeRailBands(DEFAULT_RAIL_BAND_SPEC);
    const sharp = sampledFinishedRail(rails.center.result, rails.center.domed, 200);
    const round = sampledFinishedRail(roundRails.center.result, roundRails.center.domed, 200);

    it("at share 0 it is the sharp half", () => {
      expect(openedFinishedRail(sharp, round, 0)).toEqual(sharp);
    });

    for (const share of [0.02, 0.1, 0.25, 0.5, 0.75, 1]) {
      it(`at share ${share} the edge point is on the bottom, the deck hasn't moved, and nothing folds`, () => {
        const opened = openedFinishedRail(sharp, round, share);
        expect(opened).toHaveLength(sharp.length);
        expect(opened[EDGE][1]).toBe(0);
        expect(opened[EDGE][0]).toBeLessThan(sharp[EDGE][0]);
        expect(opened.slice(0, SECTION_POINTS.deck)).toEqual(sharp.slice(0, SECTION_POINTS.deck));
        for (let i = EDGE + 1; i < opened.length; i++) {
          expect(opened[i][1]).toBe(0);
          expect(opened[i][0]).toBeLessThanOrEqual(opened[i - 1][0] + 1e-9);
        }
        for (let i = SECTION_POINTS.deck; i <= EDGE; i++) expect(opened[i][1]).toBeLessThanOrEqual(opened[i - 1][1] + 1e-9);
        expect(opened[opened.length - 1]).toEqual(sharp[sharp.length - 1]);
      });
    }

    it("a wider share is a wider radius, and takes a little more foam off", () => {
      const areas = [0.1, 0.25, 0.5, 1].map((share) => sampledSectionArea(openedFinishedRail(sharp, round, share)));
      for (let i = 1; i < areas.length; i++) expect(areas[i]).toBeLessThan(areas[i - 1]);
      expect(areas[0]).toBeLessThan(sampledSectionArea(sharp));
    });
  });
});
'''
open(p,'w').write(s)

p='lib/geometry/board-surface.test.ts'; s=open(p).read()
s=rep(s,'''        const tucked = placedHalfSection(baseEnd, baseEnd.halfWidth, 0);
        const hard = placedHalfSection(tipEnd, tipEnd.halfWidth, 0);
        const w = section.tipWeight;
''','''        // A sharp end opens toward a round one (the founder, 2026-11-05), so the ring is the blend of those halves.
        const [baseHalf, tipHalf] = [placedHalfSection(baseEnd, baseEnd.halfWidth, 0), placedHalfSection(tipEnd, tipEnd.halfWidth, 0)];
        const w = section.tipWeight;
        const [baseSharp, tipSharp] = [baseEnd.sharpness === 1, tipEnd.sharpness === 1];
        const tucked = baseSharp && !tipSharp ? openedFinishedRail(baseHalf, tipHalf, w) : baseHalf;
        const hard = tipSharp && !baseSharp ? openedFinishedRail(tipHalf, baseHalf, 1 - w) : tipHalf;
''')
s=rep(s,'''import { railReach, sampledFinishedRail } from "./finished-rail";''','''import { openedFinishedRail, railReach, sampledFinishedRail } from "./finished-rail";''')
open(p,'w').write(s)

p='lib/geometry/phase16-surface-litres-pin.test.ts'; s=open(p).read()
s=rep(s,'''    it(`${board.label}: the wing rule and the tail's roll move the live litres from there by a hair, and never by nothing`, () => {
      const tips = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: TIPS_ONLY }).volumeLitres;
      const live = summarizeDesign(board.fields).volumeLitres;
      expect(live).not.toBe(tips);
      expect(Math.abs(live - tips)).toBeLessThan(0.1);
      if (!hasWing(board)) expect(live).toBeLessThan(tips);
    });''','''    it(`${board.label}: the wing, the tail's roll and the opening tuck move the live litres from there by a hair, and never by nothing`, () => {
      const tips = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: TIPS_ONLY }).volumeLitres;
      const live = summarizeDesign(board.fields).volumeLitres;
      expect(live).not.toBe(tips);
      expect(Math.abs(live - tips)).toBeLessThan(0.1);
    });''')
open(p,'w').write(s)

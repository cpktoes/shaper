// Round 2's three plates for the founder, in the scratchpad only.
//   node compose2.js <abs out dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const read = (n) => JSON.parse(fs.readFileSync(path.join(dir, n), "utf8"));
const png = (name, file) => "data:image/png;base64," + fs.readFileSync(file || path.join(dir, `${name}.png`)).toString("base64");
const INK = "#0b0b0b", MUTED = "#52514e", GRID = "#e4e3df", TODAY = "#6b6a66";
const C = { short: "#2a78d6", mid: "#eb6834", long: "#1baf7a" };
const STYLE = `<meta charset="utf-8"><style>
body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:${INK};width:1400px}
h1{font-size:34px;margin:24px 28px 6px;line-height:1.15}p{margin:0 28px 10px;font-size:21px;color:#33322f;line-height:1.35}
h2{font-size:26px;margin:20px 28px 4px}h3{font-size:19px;margin:8px 28px 4px;color:${MUTED};font-weight:600}
.row{display:grid;gap:6px;padding:0 28px}.r4{grid-template-columns:repeat(4,1fr)}.r5{grid-template-columns:repeat(5,1fr)}
figure{margin:0;background:#1a1f28;border-radius:6px;overflow:hidden;position:relative}figure img{display:block;width:100%}
.t{position:absolute;left:6px;top:5px;background:rgba(255,255,255,.92);color:#111;font-size:16px;font-weight:600;padding:2px 7px;border-radius:4px}
.w{background:#fff;border:1px solid ${GRID}}.w .t{background:#fff}
.crop img{height:176px;object-fit:cover}
.two{display:grid;grid-template-columns:590px 1fr;gap:18px;padding:0 28px;align-items:center}.two p{margin:0 0 10px}
</style>`;
const fig = (name, tag) => `<figure><img src="${png(name)}"><span class="t">${tag}</span></figure>`;

function chart({ w, h, x0, x1, series, marks = [], yLabel, shade = [], zero = false }) {
  const m = { l: 62, r: 16, t: 34, b: 40 };
  const all = series.flatMap((s) => s.pts.map((p) => p[1]));
  let lo = Math.min(...all), hi = Math.max(...all);
  const pad = (hi - lo) * 0.1 || 1;
  lo -= pad; hi += pad;
  const X = (v) => m.l + ((v - x0) / (x1 - x0)) * (w - m.l - m.r);
  const Y = (v) => h - m.b - ((v - lo) / (hi - lo)) * (h - m.t - m.b);
  const nice = (hi - lo) / 5;
  const stepY = [0.1, 0.2, 0.25, 0.5, 1, 2, 5, 10, 20, 50].find((s) => s >= nice) || 100;
  let grid = "";
  for (let v = Math.ceil(lo / stepY) * stepY; v <= hi; v += stepY) grid += `<line x1="${m.l}" x2="${w - m.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="${Math.abs(v) < 1e-9 && zero ? "#a3a29c" : GRID}"/><text x="${m.l - 8}" y="${Y(v) + 6}" text-anchor="end" font-size="17" fill="${MUTED}">${+v.toFixed(2)}</text>`;
  const stepX = (x1 - x0) > 40 ? 12 : 3;
  for (let v = Math.ceil(x0 / stepX) * stepX; v <= x1; v += stepX) grid += `<text x="${X(v)}" y="${h - 14}" text-anchor="middle" font-size="17" fill="${MUTED}">${v}"</text>`;
  const zones = shade.map(([a, b]) => `<rect x="${X(a)}" y="${m.t}" width="${X(b) - X(a)}" height="${h - m.t - m.b}" fill="#eeeade"/>`).join("");
  const mk = marks.map(([v, t, anchor]) => `<line x1="${X(v)}" x2="${X(v)}" y1="${m.t}" y2="${h - m.b}" stroke="${INK}" stroke-width="1" stroke-dasharray="3 4"/><text x="${X(v) + (anchor === "end" ? -5 : 5)}" y="${m.t - 10}" text-anchor="${anchor || "start"}" font-size="16" fill="${INK}">${t}</text>`).join("");
  const lines = series.map((s) => `<polyline points="${s.pts.map((p) => `${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join(" ")}" fill="none" stroke="${s.c}" stroke-width="2.5" stroke-linejoin="round" ${s.dash ? `stroke-dasharray="${s.dash}"` : ""}/>`).join("");
  const labels = series.filter((s) => s.at).map((s) => {
    const p = s.pts.reduce((b, q) => (Math.abs(q[0] - s.at) < Math.abs(b[0] - s.at) ? q : b));
    return `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="4" fill="${s.c}"/><text x="${X(p[0]) + 7}" y="${Y(p[1]) + (s.dy ?? -8)}" font-size="17" font-weight="600" fill="${INK}" paint-order="stroke" stroke="#fcfcfb" stroke-width="4">${s.name}</text>`;
  }).join("");
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${zones}${grid}${mk}${lines}${labels}<text x="4" y="${m.t - 10}" font-size="16" fill="${MUTED}">${yLabel}</text></svg>`;
}

function partA() {
  const a = read("wing.json");
  const o = read("overlay.json");
  const founder = "/Users/kontoes/Code/shaper/.planning/phases/16-3d-board-and-cnc-export/pictures/founder-wing-slice-red-line.png";
  const k = (14.4 * 1878) / 1960;
  const X = (y) => 279 + (y - o.W) * k;
  const Y = (h) => 943 - h * k;
  const line = (pts) => pts.filter((p) => X(p[0]) > 20).map((p, i) => `${i ? "L" : "M"}${X(p[0]).toFixed(1)} ${Y(p[1]).toFixed(1)}`).join(" ");
  const redPanel = `<div style="position:relative;width:590px;height:440px;overflow:hidden;background:#fff;border:1px solid ${GRID}">
<img src="${png("", founder)}" style="position:absolute;left:0;top:-515px;width:1878px;">
<svg width="590" height="440" viewBox="0 515 590 440" style="position:absolute;left:0;top:0"><path d="${line(o.curves.r10)}" fill="none" stroke="${C.short}" stroke-width="3.5"/><path d="${line(o.shared)}" fill="none" stroke="#1baf7a" stroke-width="3.5"/></svg>
<div style="position:absolute;right:14px;bottom:12px;background:#fff;font-size:18px;line-height:1.35;padding:6px 8px;width:235px"><b style="color:${C.short}">Blue</b>: the new roll with no sharing, the full step.<br><b style="color:#0f8f62">Green</b>: the same roll sharing the step over 3" each way.</div></div>`;
  const boards = [
    ["wing|shortboard|one", "wing_shortboard_one", "stripes", 'Shortboard, default wing (3/16" deep)'],
    ["wing|midlength|rounded", "wing_midlength_rounded", "stripes", 'Mid-length, rounded wing (1/2" deep)'],
    ["wing|fish|square", "wing_fish_square", "sight", 'Fish, square step (3/8" deep)'],
  ];
  const names = { today: "As built", short: "Short: 4 × the wing's depth", mid: 'Middle: 3" each way', long: 'Long: 8" each way' };
  const blocks = boards.map(([label, slug, view, title]) => {
    const base = a.today.boards[label];
    const series = ["today", "short", "mid", "long"].map((n, i) => ({
      name: n === "today" ? "As built" : n === "short" ? "Short" : n === "mid" ? "Middle" : "Long",
      c: n === "today" ? TODAY : C[n],
      dash: n === "today" ? "7 5" : null,
      pts: a[n].boards[label].series.map((r) => [r[0], r[2] - r[5]]),
      at: n === "today" ? base.inner - 6 : [base.stepStart + 2.2, base.stepStart + 4.6, base.stepStart + 7][i - 1],
      dy: n === "today" ? -8 : 22,
    }));
    const c = chart({ w: 1344, h: 250, x0: base.inner - 10.5, x1: base.stepStart + 10.5, series, marks: [[(base.inner + base.stepStart) / 2, "the wing", "start"]], yLabel: "mm thicker (+) or thinner (−) than with no wing", zero: true });
    const frames = ["today", "short", "mid", "long"].map((n) => fig(`A-${slug}-${n}-${view}`, n === "today" ? "As built" : names[n].split(":")[0])).join("");
    const note = slug.includes("fish") ? `<p style="margin-top:6px">The step's top edge is shorter and lower than as built, but still crisp: a square step is a wall. A corner radius on the wing softens it.</p>` : "";
    return `<h2>${title}</h2><div style="padding:0 28px">${c}</div><div class="row r4">${frames}</div>${note}`;
  }).join("");
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>The wing: the rail rolls into the deck, and both sides share the step</h1>
<div class="two">${redPanel}<div><p><b>Across the rail:</b> the new roll joins your deck where your red line does, and stays within about 2 mm of your line on the way down to the wall.</p><p><b>Along the board:</b> behind the wing the rail gets thicker, ahead of it thinner, and they meet at the wing with half the step each.</p><p><b>You pick how far the sharing reaches.</b> Each chart shows the rail's thickness an inch in from the rail. The pictures are the same three reaches on the 3D board.</p></div></div>
${blocks}<div style="height:20px"></div></body></html>`;
}

function partB() {
  const rows = [
    ["fish_asis_hard", "Swallow (Fish): one point, the other is its mirror"],
    ["shortboard_asis_hard", "Squash (Shortboard)"],
    ["shortboard_pin_hard", "Pin (Shortboard re-cut)"],
    ["midlength_asis_hard", "Round (Mid-length)"],
    ["shortboard_diamond_hard", "Diamond (Shortboard re-cut)"],
  ];
  const labels = ["Today", "Gentle", "Medium", "Full"];
  const cands = ["today", "gentle", "medium", "full"];
  const block = (view) => rows.map(([slug, title]) => `<h3>${title}</h3><div class="row r4 crop">${cands.map((c, i) => fig(`B-${slug}-${c}-${view}`, labels[i])).join("")}</div>`).join("");
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>The tail: the rail carried around the end</h1>
<p>The deck rolls over into the tail's edge, the bottom stays on your rocker, and the nose stays as it is.<br><b>Gentle:</b> 1/4 of the tip's thickness over the last 3/4". <b>Medium:</b> 1/3 over 1". <b>Full:</b> 1/2 over 1 1/2".</p>
<h2>From the side</h2>${block("side")}
<h2>From three-quarters</h2>${block("34")}<div style="height:20px"></div></body></html>`;
}

function partC() {
  const f = read("fade.json");
  const slicePanel = (s, tipName, id, i) => {
    const px = 3.3;
    const w = s.width;
    const rangeX = 72;
    const T = Math.max(...s.base.map((p) => p[1]), ...s.tip.map((p) => p[1]));
    const W = 262, H = (T + 6) * px + 14;
    const X = (y) => 6 + (y - (w - rangeX)) * px;
    const Y = (h) => H - 8 - h * px;
    const line = (pts) => pts.filter((p) => p[0] >= w - rangeX).map((p, n) => `${n ? "L" : "M"}${X(p[0]).toFixed(1)} ${Y(p[1]).toFixed(1)}`).join(" ");
    const tag = i === 0 && id === "shortboard" ? "all tail" : i === 4 && id === "shortboard" ? "all centre" : i === 0 ? "all centre" : i === 4 ? "all nose" : `${Math.round(s.weight * 100)}% ${tipName}`;
    return `<figure class="w"><svg width="100%" viewBox="0 0 ${W} ${H + 22}"><path d="${line(s.base)}" fill="none" stroke="${C.short}" stroke-width="2" stroke-dasharray="7 5"/><path d="${line(s.tip)}" fill="none" stroke="${C.mid}" stroke-width="2" stroke-dasharray="2 4"/><path d="${line(s.live)}" fill="none" stroke="${INK}" stroke-width="2.6"/><text x="8" y="${H + 16}" font-size="17" fill="${INK}" font-weight="600">${s.stationIn.toFixed(1)}": ${tag}</text></svg></figure>`;
  };
  const graph = (id) => {
    const b = f[id];
    const pick = (fn) => b.along.map((r) => [r.in, fn(r)]);
    const series = [
      { name: "Height of the rail's fullest point", c: C.short, pts: pick((r) => r.live.apex), at: b.marks.centre + 6, dy: -10 },
      { name: "Deck's fall 1\" in", c: C.mid, pts: pick((r) => r.live.d1), at: b.marks.centre + 8, dy: -10 },
      { name: "Deck's fall 2\" in", c: "#6250d6", pts: pick((r) => r.live.d2), at: b.marks.centre + 8, dy: 22 },
      { name: "Tuck's width", c: "#1baf7a", pts: pick((r) => r.live.tuck), at: b.marks.n12 - 6, dy: 24 },
    ];
    const m = b.marks;
    const marks = [[m.t12, '12"', "end"], [m.from, "Blends From", "start"], [m.to, "Ends At", "end"], [m.centre, "Centre", "start"], [m.n12, '12" nose', "end"]];
    const shade = b.side === "tail" ? [[m.from, m.to], [m.centre, m.n12]] : [[m.from, m.to], [m.centre, m.n12]];
    return chart({ w: 1344, h: 330, x0: 3, x1: b.lengthIn - 3, series, marks, shade, yLabel: "mm" });
  };
  const sb = f.shortboard;
  const fish = f.fish;
  const key = (a, b) => `<p style="font-size:19px"><b>Solid black:</b> the rail as it is. <span style="color:${C.short}"><b>Blue dashes:</b></span> ${a} alone at that spot. <span style="color:#c44f1e"><b>Orange dots:</b></span> ${b} alone at that spot.</p>`;
  const mid = sb.slices[2].read;
  const midF = fish.slices[2].read;
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>What the rail fades really do today</h1>
<p>Both rails move. At the middle of each fade the rail sits halfway between the two, and it does so in every number measured. Neither rail holds still inside a fade.</p>
<h2>Shortboard: tail into centre (hard edge fading out)</h2>${key("the centre's rail", "the tail's rail")}
<div class="row r5">${sb.slices.map((s, i) => slicePanel(s, "tail", "shortboard", i)).join("")}</div>
<p style="margin-top:8px">At the middle (${sb.slices[2].stationIn.toFixed(1)}") the tuck is ${mid.live.tuck.toFixed(1)} mm wide, halfway between ${mid.tip.tuck.toFixed(1)} and ${mid.base.tuck.toFixed(1)}. The deck side is the same on both rails, so only the lower rail moves.</p>
<div style="padding:0 28px">${graph("shortboard")}</div>
<h2>Fish: centre into nose</h2>${key("the centre's rail", "the nose's rail")}
<div class="row r5">${fish.slices.map((s, i) => slicePanel(s, "nose", "fish", i)).join("")}</div>
<p style="margin-top:8px">At the middle (${fish.slices[2].stationIn.toFixed(1)}") the deck falls ${midF.live.d1.toFixed(2)} mm an inch in, halfway between ${midF.base.d1.toFixed(2)} and ${midF.tip.d1.toFixed(2)}.</p>
<div style="padding:0 28px">${graph("fish")}</div>
<h2>The one real difference</h2>
<p>On the tail, each rail sits still outside the fade: the tail's rail from the 12" mark to Blends From, the centre's from Ends At to the centre. The nose has no still stretch: it fades all the way from the centre to its 12" mark. The shaded bands show both.</p>
<p><b>If you want neither rail to sit still:</b> run the tail's fade from the 12" mark to the centre, as the nose does. A hard edge would start easing at 12" instead of 18". The cards: Longboard 72.40 → 72.35 L, the others the same.</p>
<div style="height:16px"></div></body></html>`;
}

(async () => {
  const browser = await chromium.launch();
  for (const [name, html] of [["16-16-r2-A-wing", partA()], ["16-16-r2-B-tail", partB()], ["16-16-r2-C-fades", partC()]]) {
    const file = path.join(dir, `${name}.html`);
    fs.writeFileSync(file, html);
    const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
    await page.goto("file://" + file);
    await page.evaluate(() => document.fonts.ready);
    const h = await page.evaluate(() => document.documentElement.scrollHeight);
    await page.screenshot({ path: path.join(dir, `${name}.png`), fullPage: true });
    console.log(name, h);
    await page.close();
  }
  await browser.close();
})();

def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/finished-rail.ts'; s=open(p).read()
s=rep(s,''' * across the round rail lands from the corner. Point for point, as the blend needs: the bottom edge's point moves to
 * the curve's foot on the bottom, the rail's points near the corner slide onto the curve, the bottom's points
 * inside the foot spread out beyond it, and every other point stays exactly where it was. At `share` 0 it is the
 * sharp half.
 */''',''' * across the round rail lands from the corner. Point for point, as the blend needs: the bottom edge's point moves to
 * the curve's foot on the bottom, the rail's points within twice the reach of the corner spread evenly along the way
 * there, so the curve has points to be drawn with, the bottom's points inside the foot spread out beyond it, and
 * every other point stays exactly where it was. At `share` 0 it is the sharp half.
 */''')
s=rep(s,'''  const opened = sharp.map(([y, h]): P2 => [y, h]);
  for (let k = 0; k < up.length && upLengths[k] < a; k++) {
    const t = 1 - upLengths[k] / a;
    const [u, v, w] = [(1 - t) * (1 - t), 2 * t * (1 - t), t * t];
    opened[edge - k] = [u * start[0] + v * corner[0] + w * foot[0], u * start[1] + v * corner[1] + w * foot[1]];
  }
  opened[edge] = [foot[0], 0];
''','''  const opened = sharp.map(([y, h]): P2 => [y, h]);
  const curve = Array.from({ length: 33 }, (_, i): P2 => {
    const t = i / 32;
    const [u, v, w] = [(1 - t) * (1 - t), 2 * t * (1 - t), t * t];
    return [u * start[0] + v * corner[0] + w * foot[0], u * start[1] + v * corner[1] + w * foot[1]];
  });
  // The last point left where it was, and the way from it to the foot: down the rail to the curve, then the curve.
  let anchor = 1;
  while (anchor < up.length - 1 && upLengths[anchor] < 2 * a) anchor++;
  const onRail = up.slice(1, anchor + 1).filter((_, i) => upLengths[i + 1] > a).reverse();
  const way = [...onRail, ...curve];
  const wayLengths = runLengths(way);
  for (let k = 1; k <= anchor; k++) {
    opened[edge - anchor + k] = pointAlong(way, wayLengths, (k / anchor) * wayLengths[wayLengths.length - 1]);
  }
  opened[edge] = [foot[0], 0];
''')
open(p,'w').write(s)
p='lib/geometry/volume.test.ts'; s=open(p).read()
s=rep(s,'''    expect(mid.blended).toEqual(blendFinishedRails(tuckedHalf, hardHalf, mid.hardWeight));
    const w = mid.hardWeight;
''','''    const w = mid.hardWeight;
    // A hard edge fading into a round rail opens into a radius (the founder, 2026-11-05).
    expect(mid.blended).toEqual(blendFinishedRails(tuckedHalf, openedFinishedRail(hardHalf, tuckedHalf, 1 - w), w));
''')
open(p,'w').write(s)

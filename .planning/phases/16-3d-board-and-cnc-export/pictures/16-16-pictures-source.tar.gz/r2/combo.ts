// Round 2: what the recommended rules do together: the 102 boards against the pin, the presets' cards, the stock board.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const B = await import(`${ROOT}/lib/geometry/board`);
  const Ra = await import(`${ROOT}/lib/geometry/rail-bands`);
  const pin = JSON.parse(readFileSync(join(ROOT, "lib/geometry/__fixtures__/phase16-surface-litres-pin.json"), "utf8")).litres;
  const boards = F.phase16SurfaceBoards();
  const cards: [string, any][] = [
    ...P.BOARD_PRESETS.map((p: any) => [p.name, { ...PB.presetDesignFields(p), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC }] as [string, any]),
    ["Stock 6'0\"", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: Ra.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  const run = (name: string, share: string, tail: string) => {
    if (share) process.env.WING_SHARE = share; else delete process.env.WING_SHARE;
    if (tail) process.env.TAIL_ROLL = tail; else delete process.env.TAIL_ROLL;
    let faults = 0, same = 0, sameHead = 0;
    let lo = Infinity, hi = -Infinity, gapLo = Infinity, gapHi = -Infinity;
    const moves: Record<string, number> = {};
    for (const b of boards) {
      const geometry = O.buildOutline(b.fields.outline);
      const profile = D.designSideProfile(b.fields, D.LIVE_DESIGN_RULES);
      const rails = D.deriveEffectiveRails(b.fields.rails, profile.effectiveFoil, b.fields.railsImportFoilThickness);
      const sections = D.designCrossSectionInput(geometry, profile, rails, b.fields.outline.length);
      const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
      const c = S.meshCheck(surface);
      faults += c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles;
      const l = D.summarizeDesign(b.fields).volumeLitres;
      const v = V.computeCrossSectionVolume(sections).volumeLitres;
      const g = (S.enclosedVolumeMm3(surface) / 1e6 / v - 1) * 100;
      gapLo = Math.min(gapLo, g); gapHi = Math.max(gapHi, g);
      const m = l - Number(pin[b.label]);
      moves[b.label] = m;
      lo = Math.min(lo, m); hi = Math.max(hi, m);
      if (l.toPrecision(17) === pin[b.label]) same++;
    }
    void sameHead;
    const card = cards.map(([n, f]) => [n, D.summarizeDesign(f).volumeLitres]);
    console.log(name, "faults", faults, "bit-identical", same, "move", lo.toFixed(4), hi.toFixed(4), "gap", gapLo.toFixed(3), gapHi.toFixed(3));
    console.log("   ", card.map(([n, l]: any) => `${n} ${l.toFixed(4)}`).join(" · "));
    return { faults, same, lo, hi, gapLo, gapHi, card, moves };
  };
  const out: any = {};
  out.head = run("as built", "", "");
  out.wing = run("wing middle", "in3", "");
  out.gentle = run("tail gentle", "", "0.25,0.75");
  out.medium = run("tail medium", "", "0.35,1");
  out.full = run("tail full", "", "0.5,1.5");
  out.both = run("wing middle + tail medium", "in3", "0.35,1");
  out.bothG = run("wing middle + tail gentle", "in3", "0.25,0.75");
  writeFileSync(join(OUT, "combo.json"), JSON.stringify(out));
})();

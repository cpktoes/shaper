def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/volume.ts'; s=open(p).read()
s=rep(s,''' * outline; `result` and
 * `blended` are the section built on the meeting line.
 */''',''' * outline; `result` and
 * `blended` are the section built on the meeting line.
 *
 * `rollScale` is the share of its height a station in the tail's last inch keeps (D-38, `tailRollScale`), absent
 * clear of it: `drawn` is then already scaled by it. `area` stays the un-rolled section's, because the roll's foam
 * is counted once, exactly, off the whole board (`tailRollFoam`).
 */''') if False else s
s=rep(s,''' * The stepped outline stays `halfWidth`, so the drawn half's outermost point is TEMPLATE's outline; `result` and
 * `blended` are the section built on the meeting line.
 */''',''' * The stepped outline stays `halfWidth`, so the drawn half's outermost point is TEMPLATE's outline; `result` and
 * `blended` are the section built on the meeting line.
 *
 * `rollScale` is the share of its height a station in the tail's last inch keeps (D-38, `tailRollScale`), absent
 * clear of it; `drawn` is then already scaled by it. `area` stays the un-rolled section's, because the roll's foam is
 * counted once, exactly, off the whole board (`tailRollFoam`).
 */''')
s=rep(s,'''  drawn?: HalfSectionPoints;
  tipWeight: number;''','''  drawn?: HalfSectionPoints;
  rollScale?: number;
  tipWeight: number;''')
s=rep(s,''' * stringer sinks under the side profile's deck near a tip; `"fit"` draws it into its room and the litres count
 * what is drawn (D-34).
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
}

/** What every rule before plan 16-16 does: the whole section shifts in with a wing, a wide rail is cut off. */
export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip" };
''',''' * stringer sinks under the side profile's deck near a tip; `"fit"` draws it into its room and the litres count
 * what is drawn (D-34). `tail`: `"square"` ends the deck at the tail's full thickness; `"roll"` carries the rail
 * around the end, the deck rolling over into the tail's edge (D-38).
 */
export interface SurfaceFit {
  wings: "shift" | "share";
  tips: "clip" | "fit";
  tail: "square" | "roll";
}

/** What every rule before plan 16-16 does: the whole section shifts in with a wing, a wide rail is cut off, and the
 * deck runs square to the tail's end. */
export const OLD_SURFACE_FIT: SurfaceFit = { wings: "shift", tips: "clip", tail: "square" };

/** How much of the tip's thickness the tail's roll takes off at the very end (D-38, the founder's pick). */
export const TAIL_ROLL_SHARE = 1 / 3;
/** How far in from the tail end the roll runs, in inches (D-38, the founder's pick). */
export const TAIL_ROLL_RUN_IN = 1;
/** The panels the litres integrate the roll's foam over (`tailRollFoam`). */
const TAIL_ROLL_PANELS = 8;

/**
 * How far the deck has rolled down at a station in the tail's last inch (Phase 16, D-38, the founder: "The rail at the
 * tail of the board can be carried around the tip, so there's usually a pretty mild rounding of the deck line for all
 * tail types."), in millimetres: a quarter ellipse, `TAIL_ROLL_SHARE` of the tip's thickness tall and
 * `TAIL_ROLL_RUN_IN` long, level with the deck where it starts and upright where it meets the tail's edge. 0 at
 * and ahead of the end of the run.
 */
export function tailRollDrop(station: Mm, tipThickness: Mm): number {
  const run = inchesToMm(TAIL_ROLL_RUN_IN);
  if (station >= run) return 0;
  const t = 1 - station / run;
  return tipThickness * TAIL_ROLL_SHARE * (1 - Math.sqrt(Math.max(0, 1 - t * t)));
}

/** The share of its height a station keeps under the tail's roll: 1 clear of it. Every height scales alike, so the
 * bottom stays on the rocker and the rail keeps its shape. */
export function tailRollScale(station: Mm, thickness: Mm, tipThickness: Mm): number {
  return Math.max(0, 1 - tailRollDrop(station, tipThickness) / thickness);
}

/** `panels + 1` stations through the tail's roll, even in the ellipse's own angle, so they crowd where it turns
 * fastest: the tail end first, the end of the run last. The 3D board's rings and the litres' count both take them. */
export function tailRollStations(panels: number): Mm[] {
  const run = inchesToMm(TAIL_ROLL_RUN_IN);
  return Array.from({ length: panels + 1 }, (_, k) => mm(run * (1 - Math.cos((k / panels) * (Math.PI / 2)))));
}
''')
s=rep(s,''' * two sides share and only their rails moved onto the outline (`wingShareAt`, `wingStepHalf`), and a rail wider than
 * its station drawn into its room and counted (`fittedFinishedRail`).''',''' * two sides share and only their rails moved onto the outline (`wingShareAt`, `wingStepHalf`), a rail wider than its
 * station drawn into its room and counted (`fittedFinishedRail`), and the tail's rail carried around its end
 * (`tailRollDrop`, D-38).''')
s=rep(s,'''  fit: { wings: "share", tips: "fit" },''','''  fit: { wings: "share", tips: "fit", tail: "roll" },''')
s=rep(s,'''  const fit = "at" in rule ? (rule.fit ?? OLD_SURFACE_FIT) : OLD_SURFACE_FIT;
''','''  const fit = "at" in rule ? (rule.fit ?? OLD_SURFACE_FIT) : OLD_SURFACE_FIT;
  const tipThickness = thicknessAt(mm(0));
''')
s=rep(s,'''    const room = move !== 0 ? mm(foam + move) : foam;

    if (room === 0) {
      sections.push({
        station,
        halfWidth: foam,
        thickness,
        result: null,
''','''    const room = move !== 0 ? mm(foam + move) : foam;
    // In the tail's last inch the deck rolls over into the tail's edge (D-38); 1 everywhere else.
    const keep = fit.tail === "roll" ? tailRollScale(station, thickness, tipThickness) : 1;
    const rollField = keep < 1 ? { rollScale: keep } : {};

    if (room === 0) {
      sections.push({
        station,
        halfWidth: foam,
        thickness,
        ...rollField,
        result: null,
''')
s=rep(s,'''    if (tipWeight > 0 && tipWeight < 1) {
      // The blend (D-31, level variant; D-32)''','''    // The tail's roll on a built section (D-38): whatever it draws, every height scaled, the bottom left alone.
    const rolled = (built: BoardSection, half: HalfSectionPoints): BoardSection => {
      if (keep === 1) return built;
      const drawn = (built.drawn ?? half).map(([y, h]): [number, number] => [y, h * keep]);
      return { ...built, ...rollField, drawn };
    };

    if (tipWeight > 0 && tipWeight < 1) {
      // The blend (D-31, level variant; D-32)''')
s=rep(s,'''      sections.push(move !== 0 ? movedOn(section, blended, rollReach) : section);
''','''      sections.push(rolled(move !== 0 ? movedOn(section, blended, rollReach) : section, blended));
''')
s=rep(s,'''    if (move === 0 && !ended.fits) {''','''    if (move === 0 && !ended.fits && keep === 1) {''')
s=rep(s,'''    sections.push(move !== 0 ? movedOn(counted, half, result.deckMark2) : counted);''','''    sections.push(rolled(move !== 0 ? movedOn(counted, half, result.deckMark2) : counted, half));''')
s=rep(s,''' * TAIL CUT (quick 261103-gcm, the founder, 2026-11-03: the litres count the tail the board is drawn
 * with).''',''' * THE TAIL'S ROLL (Phase 16, D-38, the founder's pick: "Medium: 1/3 over 1\""). The rail is carried around the tail's
 * end: over the last inch every height of the section scales down along a quarter ellipse, a third of the tip's
 * thickness at the end (`tailRollDrop`), so the deck rolls over into the tail's edge and the bottom stays on the
 * rocker. The 51 stations are too far apart to see that: station 0 would stand for a whole first panel on a tail with
 * width, and a tail that comes to a point has no station in the roll at all. So each section's `area` is left un-rolled
 * and the roll's own foam comes off the whole board, integrated finely through the ellipse (`tailRollFoam`), so
 * the litres count what the 3D board draws (D-31). The old rules keep the square end (`OLD_SURFACE_FIT`).
 *
 * TAIL CUT (quick 261103-gcm, the founder, 2026-11-03: the litres count the tail the board is drawn
 * with).''')
s=rep(s,'''  /** The foam the finished rail's blends take off each station, both rails, in square millimetres
   * (quick 261102-gec plan 03, PV5): `stationAreas[i] + stationBlendAreas[i]` is that station's cut area.
   * Exposed for auditing, as `stationAreas` is. */
  stationBlendAreas: number[];
}
''','''  /** The foam the finished rail's blends take off each station, both rails, in square millimetres
   * (quick 261102-gec plan 03, PV5): `stationAreas[i] + stationBlendAreas[i]` is that station's cut area.
   * Exposed for auditing, as `stationAreas` is. */
  stationBlendAreas: number[];
  /** The foam the tail's roll takes off the whole board, in cubic millimetres (D-38, `tailRollFoam`): already out of
   * `volumeMm3`, and not in `stationAreas`. 0 under a rule with a square tail. */
  tailRollMm3: number;
}
''')
s=rep(s,'''/** `computeCrossSectionVolume` with the section rule named: Simpson over `boardSectionsWith(input, rule)`. */''','''/**
 * The foam the tail's roll takes off the whole board, in cubic millimetres (D-38): each station's area times the
 * share of height it loses, Simpson-integrated through the run in the ellipse's own angle (`θ`, with
 * `station = run (1 − cos θ)`), which keeps the integrand smooth where the ellipse stands upright at the tail end.
 */
export function tailRollFoam(input: CrossSectionVolumeInput, rule: SectionRule): number {
  const stations = tailRollStations(TAIL_ROLL_PANELS);
  const run = inchesToMm(TAIL_ROLL_RUN_IN);
  const h = Math.PI / 2 / TAIL_ROLL_PANELS;
  const sections = boardSectionsWith(input, rule, stations);
  const lost = sections.map((section, k) => section.area * (1 - (section.rollScale ?? 1)) * run * Math.sin(k * h));
  return simpsonIntegrate(lost, h);
}

/** `computeCrossSectionVolume` with the section rule named: Simpson over `boardSectionsWith(input, rule)`. */''')
s=rep(s,'''    volumeMm3 = simpsonIntegrate(stationAreas, length / SIMPSON_PANEL_COUNT);
  }

  return {
    volumeLitres: cubicMmToLitres(volumeMm3),
    volumeMm3,
    panelCount: SIMPSON_PANEL_COUNT,
    stations,
    stationAreas,
    stationBlendAreas,
  };''','''    volumeMm3 = simpsonIntegrate(stationAreas, length / SIMPSON_PANEL_COUNT);
  }
  const tailRollMm3 = "at" in rule && rule.fit?.tail === "roll" ? tailRollFoam(input, rule) : 0;
  if (tailRollMm3 !== 0) volumeMm3 -= tailRollMm3;

  return {
    volumeLitres: cubicMmToLitres(volumeMm3),
    volumeMm3,
    panelCount: SIMPSON_PANEL_COUNT,
    stations,
    stationAreas,
    stationBlendAreas,
    tailRollMm3,
  };''')
open(p,'w').write(s)

p='lib/geometry/board-surface.ts'; s=open(p).read()
s=rep(s,'''  boardSections,
  crossSectionStations,
  railCharacterDifferences,
} from "./volume";''','''  boardSections,
  crossSectionStations,
  railCharacterDifferences,
  tailRollStations,
} from "./volume";''')
s=rep(s,''' * at the outline's own point, so a tip is the side profile's own tip from the side and the outline's point from
 * above, with no cap and no slice (the founder: "Let's not do that little flip."); a tail end with width (a square
 * or squash tail) is closed with a flat cap.''',''' * at the outline's own point, so a tip ends on the side profile from the side and on the outline's point from
 * above, with no cap and no slice (the founder: "Let's not do that little flip."); a tail end with width (a square
 * or squash tail) is closed with a flat cap. On every tail the rail is carried around the end (D-38): over the last
 * inch the section's heights roll down (`tailRollDrop`), so the deck rolls over into the tail's edge, and rings crowd
 * through the roll to draw it.''')
s=rep(s,''' * — filled in so no two neighbours are more than''',''' * and through the tail's roll (D-38) — filled in so no two neighbours are more than''')
s=rep(s,'''  const kept: number[] = [];
  const keep = (s: number) => {''','''  required.push(...tailRollStations(TAIL_ROLL_RINGS).slice(1));
  const kept: number[] = [];
  const keep = (s: number) => {''')
s=rep(s,'''/** Stations closer than this are one station. */''','''/** Rings through the tail's roll (D-38), enough that its curve reads as one curve. */
const TAIL_ROLL_RINGS = 14;

/** Stations closer than this are one station. */''')
s=rep(s,'''  if (!section.result || section.halfWidth <= 0) return tipEdge(outer, section.thickness);
''','''  if (!section.result || section.halfWidth <= 0) return tipEdge(outer, section.thickness * (section.rollScale ?? 1));
''')
open(p,'w').write(s)

# ---- the report
p='lib/models/surface-report.ts'; s=open(p).read()
a=s.index('/**\n * The report')
s=open(p).read()
a=s.index('import {')
head='''/**
 * `scripts/check-saved-boards.ts --surface-report` (Phase 16, D-33 to D-38; the 14 D-18 report rule): the founder's
 * read-only check, before go-live 2, of what every real saved board will read when plan 16-16's surface goes live.
 * It covers EVERY saved board, because the tail's roll reaches them all: a wing's two sides share its step, a rail
 * wider than its station near a tip is drawn into its room, and the deck rolls over into the tail's edge. "Before" is
 * what the live site reads today (`HARD_EDGE_FADE`, go-live 1's rule), "after" what it will read (the live rule), so
 * each line is the move he will see. The bracket gives this plan's share of that move, against `RAIL_CHARACTER_FADE`:
 * the rest is the whole rail's fade, which `--rail-character-report` lists with its reasons, for the boards it reaches.
 *
 * It prints board ids, wing counts, tail kinds and litres only — never a board's name, an account, a snapshot or a
 * connection string — and a board that did not open is counted, never printed. Pure: no React, browser API or
 * database import; the script does the one read-only select and hands the opened boards in.
 */

'''
s=head+s[a:]
s=rep(s,'''import { RAIL_CHARACTER_FADE } from "@/lib/geometry/volume";

/** One board's litres under the rule before plan 16-16 (`before`) and the live rule (`after`). */
export interface SurfaceLitresMove {
  before: Litres;
  after: Litres;
}
''','''import { HARD_EDGE_FADE, RAIL_CHARACTER_FADE } from "@/lib/geometry/volume";

/** One board's litres as the site reads them today (`before`), with the whole rail's fade but none of this plan
 * (`faded`), and under the live rule (`after`). */
export interface SurfaceLitresMove {
  before: Litres;
  faded: Litres;
  after: Litres;
}
''')
s=rep(s,'''/**
 * A board's litres before the wing and tip rule (by name) and now (the live rule). Null when the two read the same:
 * a board with no wing and room for its rail all the way to each tip.
 */
export function surfaceLitresMove(fields: DesignSummaryFields): SurfaceLitresMove | null {
  const before = summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: RAIL_CHARACTER_FADE }).volumeLitres;
  const after = summarizeDesign(fields).volumeLitres;
  return before === after ? null : { before, after };
}
''','''/** A board's litres as the site reads them today, before this plan, and at go-live 2. Null when today's and go-live
 * 2's figures are the very same number. */
export function surfaceLitresMove(fields: DesignSummaryFields): SurfaceLitresMove | null {
  const before = summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_FADE }).volumeLitres;
  const faded = summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: RAIL_CHARACTER_FADE }).volumeLitres;
  const after = summarizeDesign(fields).volumeLitres;
  return before === after ? null : { before, faded, after };
}
''')
s=rep(s,''' *   <id>: <no wings | 1 wing | 2 wings> · <tail kind> tail — <before> → <after> L (<move>)
 *   largest move: <id>, <move> L                                              (or: largest move: none)
 * One line per board that moves, largest move first; litres to two places as every screen shows them, the move to
 * four, so a move too small to show on a card still shows here.''',''' *   <id>: <no wings | 1 wing | 2 wings> · <tail kind> tail — <before> → <after> L (<move>, this plan <share>)
 *   largest move: <id>, <move> L                                              (or: largest move: none)
 * One line per board that moves, largest move first; litres to two places as every screen shows them, the moves to
 * four, so a move too small to show on a card still shows here.''')
s=rep(s,'''  const moves: { id: string; text: string; before: number; after: number }[] = [];''','''  const moves: { id: string; text: string; before: number; faded: number; after: number }[] = [];''')
s=rep(s,'''      moves.push({ id: row.id, text, before: move.before, after: move.after });''','''      moves.push({ id: row.id, text, before: move.before, faded: move.faded, after: move.after });''')
s=rep(s,'''      (m) => `${m.id}: ${m.text} — ${m.before.toFixed(2)} → ${m.after.toFixed(2)} L (${signedLitres(m.after - m.before)})`,''','''      (m) =>
        `${m.id}: ${m.text} — ${m.before.toFixed(2)} → ${m.after.toFixed(2)} L ` +
        `(${signedLitres(m.after - m.before)}, this plan ${signedLitres(m.after - m.faded)})`,''')
open(p,'w').write(s)

p='scripts/check-saved-boards.ts'; s=open(p).read()
a=s.index(''' * `--surface-report` (Phase 16 D-33 and D-34''')
b=s.index(''' * Commands (D-20:''')
s=s[:a]+''' * `--surface-report` (Phase 16 D-33 to D-38, the 14 D-18 report rule; read-only, board ids, wing counts, tail kinds
 * and litres only): the founder's check before go-live 2 of what every saved board will read. It covers every
 * board, because the tail's roll reaches them all, where --rail-character-report lists only the boards the whole
 * rail's fade reaches. For each board it prints the wing count and tail kind, the litres the site reads today
 * (`HARD_EDGE_FADE`) and will read (the live rule), the whole move, and this plan's share of it (against
 * `RAIL_CHARACTER_FADE`), worked out in lib/models/surface-report.ts (`surfaceReportLines`):
 *   surface report: N saved boards; k open[, d did not open]; m whose litres move
 *   <id>: <no wings | 1 wing | 2 wings> · <tail kind> tail — <before> → <after> L (<move>, this plan <share>)
 *                                                                              one per such board, the largest move first
 *   largest move: <id>, <move> L                                              (or: largest move: none)
 * A board that does not open is counted, never printed with data. It only reads; it never prints a board name,
 * a snapshot, a user id or the connection string, and it never changes the exit code.
 *
'''+s[b:]
s=rep(s,'''  // --surface-report (Phase 16 D-33, D-34): ids, wing counts, tail kinds and litres only; never changes the exit code.''','''  // --surface-report (Phase 16 D-33 to D-38): ids, wing counts, tail kinds and litres only; never changes the exit code.''')
open(p,'w').write(s)

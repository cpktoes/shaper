// Writes shots.json for the as-built plate and the lip plate.
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const norm = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
const shots = [];
for (const slug of ["wing_shortboard_one", "wing_midlength_rounded", "wing_fish_square"]) {
  const file = `built-${slug}.json`;
  const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
  const s = (d.wings[0].inner + d.wings[0].stepStart) / 2;
  const half = d.wings[0].half;
  let top = -Infinity;
  for (let i = 0; i < d.positions.length; i += 3) if (Math.abs(d.positions[i] - s) < 8) top = Math.max(top, d.positions[i + 2]);
  const look = [s, top - 6, -half * 0.78];
  const eye = look.map((v, i) => v + norm([-0.3, 1, -0.4])[i] * 520);
  shots.push({ name: `B3-${slug}-stripes`, file, mode: "stripes", eye, look, up: [1, 0, 0], fov: 24, w: 800, h: 500 });
  shots.push({ name: `B3-${slug}-lit`, file, mode: "lit", eye, look, up: [1, 0, 0], fov: 24, keyAt: [900, 170, -half * 0.6], key: 2.6, dim: 0.45, w: 800, h: 500 });
  shots.push({ name: `B3-${slug}-sight`, file, mode: "lit", eye: [s - 340, top + 60, -half - 90], look: [s + 60, top - 8, -half * 0.97], fov: 16, keyAt: [s, 300, -half - 300], key: 1.0, dim: 0.42, w: 800, h: 500 });
}
for (const [slug, point] of [["fish_asis_hard", true], ["shortboard_asis_hard", false], ["shortboard_pin_hard", false], ["midlength_asis_hard", false], ["shortboard_diamond_hard", false]]) {
  const file = `built-${slug}.json`;
  const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
  const across = point ? -d.tailHalf : 0;
  const side = [28, d.tailZ + d.tailT / 2 + 3, across];
  shots.push({ name: `B3-${slug}-side`, file, mode: "lit", eye: [side[0], side[1], across - 420], look: side, fov: 14, keyAt: [0, 400, across - 700], key: 0.9, dim: 0.42, w: 800, h: 500 });
  const look = [34, d.tailZ + d.tailT / 2, across];
  const v = norm([-0.75, 0.55, -0.75]);
  shots.push({ name: `B3-${slug}-34`, file, mode: "lit", eye: look.map((x, i) => x + v[i] * 500), look, fov: 14, keyAt: [-300, 500, across - 500], key: 0.9, dim: 0.42, w: 800, h: 500 });
}
for (const id of ["fish38", "fish12"]) {
  for (const cand of ["built", "radius", "half", "full1", "full2"]) {
    const file = `lip-${id}-${cand}.json`;
    const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
    const s = d.s;
    const half = d.half;
    let top = -Infinity;
    for (let i = 0; i < d.positions.length; i += 3) if (Math.abs(d.positions[i] - s) < 8) top = Math.max(top, d.positions[i + 2]);
    shots.push({ name: `L-${id}-${cand}`, file, mode: "lit", eye: [s - 260, top + 110, -half - 150], look: [s + 18, top - 12, -half * 0.96], fov: 13, keyAt: [s - 200, 260, -half - 240], key: 0.9, dim: 0.42, w: 800, h: 500 });
    const lookTop = [s + 16, top - 8, -half * 0.93];
    const eyeTop = lookTop.map((x, i) => x + norm([-0.15, 1, -0.38])[i] * 330);
    shots.push({ name: `L-${id}-${cand}-top`, file, mode: "lit", eye: eyeTop, look: lookTop, up: [1, 0, 0], fov: 16, keyAt: [700, 150, -half * 0.8], key: 2.6, dim: 0.42, w: 800, h: 500 });
  }
}
fs.writeFileSync(path.join(dir, "shots.json"), JSON.stringify(shots));
console.log(shots.length);

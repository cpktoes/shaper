p='e2e/three-d-hard-edge.spec.ts'
s=open(p).read()
a='''    // VOLUME's litres moved.
    expect(await litres(page, litresBefore)).not.toBe(litresBefore);

    // Moved on RAILS'''
b='''    // Moved on RAILS'''
assert a in s
s=s.replace(a,b)
a='''    await expect(endsAtSlider(page)).toHaveAttribute("aria-valuetext", THREE_D_COPY.tailRailFromTheTail(low));
  });

  test("2. with the tail's Hard Edge off'''
b='''    await expect(endsAtSlider(page)).toHaveAttribute("aria-valuetext", THREE_D_COPY.tailRailFromTheTail(low));

    // VOLUME's litres moved: a shorter hard edge is less foam, enough for its two decimals. (Since the tail's roll,
    // D-38, the longer fade above lands on the same 30.29 L as the board opens on.)
    expect(await litres(page, litresBefore)).not.toBe(litresBefore);
  });

  test("2. with the tail's Hard Edge off'''
assert a in s
s=s.replace(a,b)
open(p,'w').write(s)

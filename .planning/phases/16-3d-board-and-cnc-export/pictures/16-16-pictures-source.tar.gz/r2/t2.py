def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)

# ---- volume.test
p='lib/geometry/volume.test.ts'; s=open(p).read()
s=rep(s,'''        if (fitted === sampled || section.halfWidth >= railReach(section.result, section.domed)) {
          expect(Object.is(section.area, before.area)).toBe(true);
          expect(section.drawn).toBeUndefined();
        } else {
          const lift = sampledSectionArea(fitted) - sampledSectionArea(sampled);
          expect(lift).toBeGreaterThan(0);
          expect(section.area).toBe(before.area + lift);
          expect(section.blendArea).toBe(before.blendArea);
          expect(section.drawn).toEqual(fitted);
        }
''','''        // The tail's roll draws a station's heights lower and leaves its area for the whole-board count (D-38).
        const scaled = (half: typeof fitted) => half.map(([y, h]) => [y, h * (section.rollScale ?? 1)]);
        if (fitted === sampled || section.halfWidth >= railReach(section.result, section.domed)) {
          expect(Object.is(section.area, before.area)).toBe(true);
          if (section.rollScale === undefined) expect(section.drawn).toBeUndefined();
          else expect(section.drawn).toEqual(scaled(sampled));
        } else {
          const lift = sampledSectionArea(fitted) - sampledSectionArea(sampled);
          expect(lift).toBeGreaterThan(0);
          expect(section.area).toBe(before.area + lift);
          expect(section.blendArea).toBe(before.blendArea);
          expect(section.drawn).toEqual(scaled(fitted));
        }
''')
s=rep(s,'''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip" });''','''    expect(OLD_SURFACE_FIT).toEqual({ wings: "shift", tips: "clip", tail: "square" });''')
s=rep(s,'''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit" });''','''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit", tail: "roll" });''')
s=rep(s,'''  OLD_SURFACE_FIT,
  RAIL_CHARACTER_FADE,''','''  computeCrossSectionVolumeWith,
  OLD_SURFACE_FIT,
  RAIL_CHARACTER_FADE,''')
s=rep(s,'''  SMOOTH_SURFACE_FADE,
  tailHardEdgeWeight,''','''  SMOOTH_SURFACE_FADE,
  TAIL_ROLL_RUN_IN,
  TAIL_ROLL_SHARE,
  tailHardEdgeWeight,
  tailRollDrop,
  tailRollFoam,
  tailRollScale,
  tailRollStations,''')
s=s.rstrip('\n')+'''

describe("D-38 the tail's rail is carried around the end", () => {
  const RUN = inchesToMm(TAIL_ROLL_RUN_IN);
  const TIP = mm(20);
  const boards = phase16SurfaceBoards().filter((board) => /\\|(asis|pin|round|diamond|swallow)\\|hard$|^wing\\|.*\\|one$/.test(board.label));
  function inputOf(fields: DesignSummaryFields) {
    const geometry = buildOutline(fields.outline);
    const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
    const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return designCrossSectionInput(geometry, profile, rails, fields.outline.length);
  }

  it("tailRollDrop is a quarter ellipse: the share of the tip at the end, nothing from the end of the run on", () => {
    expect(tailRollDrop(mm(0), TIP)).toBeCloseTo(TIP * TAIL_ROLL_SHARE, 12);
    expect(tailRollDrop(RUN, TIP)).toBe(0);
    expect(tailRollDrop(mm(RUN + 5), TIP)).toBe(0);
    // On the ellipse x² + y² = 1, walking in from the end.
    for (const f of [0.1, 0.3, 0.5, 0.7, 0.9]) {
      const y = 1 - tailRollDrop(mm(RUN * f), TIP) / (TIP * TAIL_ROLL_SHARE);
      expect(y * y + (1 - f) * (1 - f)).toBeCloseTo(1, 10);
    }
  });

  it("tailRollScale keeps every height's share, 1 clear of the roll", () => {
    expect(tailRollScale(mm(0), TIP, TIP)).toBeCloseTo(1 - TAIL_ROLL_SHARE, 12);
    expect(tailRollScale(RUN, mm(40), TIP)).toBe(1);
  });

  it("tailRollStations start at the tail end, stop at the end of the run, and crowd toward the end", () => {
    const stations = tailRollStations(8);
    expect(stations[0]).toBe(0);
    expect(stations[8]).toBeCloseTo(RUN, 9);
    for (let i = 1; i < 8; i++) expect(stations[i] - stations[i - 1]).toBeLessThan(stations[i + 1] - stations[i]);
  });

  for (const { label, fields } of boards) {
    const input = inputOf(fields);
    it(`${label}: the litres take off the roll's own foam, to within a part in a hundred of a fine count`, () => {
      const result = computeCrossSectionVolume(input);
      const n = 2000;
      const at = Array.from({ length: n + 1 }, (_, i) => mm((i * RUN) / n));
      const lost = boardSections(input, at).map((section) => section.area * (1 - (section.rollScale ?? 1)));
      const fine = simpsonIntegrate(lost, RUN / n);
      expect(result.tailRollMm3).toBe(tailRollFoam(input, SMOOTH_SURFACE_FADE));
      expect(result.tailRollMm3).toBeGreaterThan(0);
      expect(Math.abs(result.tailRollMm3 - fine) / fine).toBeLessThan(0.01);
    });

    it(`${label}: a rolled station keeps its un-rolled area and draws its heights scaled, the bottom left alone`, () => {
      const sections = boardSections(input, [mm(RUN / 3), mm(RUN / 2), mm(RUN + 1)]);
      for (const section of sections.slice(0, 2)) {
        expect(section.rollScale).toBeLessThan(1);
        if (!section.result) continue;
        const half = section.drawn!;
        expect(Math.max(...half.map((p) => p[1]))).toBeCloseTo(section.thickness * section.rollScale!, 6);
        expect(half[half.length - 1][1]).toBe(0);
      }
      expect(sections[2].rollScale).toBeUndefined();
    });
  }

  it("the old rules keep the square end and count no roll", () => {
    const input = inputOf(boards[0].fields);
    for (const rule of [HARD_EDGE_SWITCH, HARD_EDGE_FADE, RAIL_CHARACTER_FADE]) {
      expect(computeCrossSectionVolumeWith(input, rule).tailRollMm3).toBe(0);
      expect(boardSectionsWith(input, rule, [mm(0)])[0].rollScale).toBeUndefined();
    }
  });
});
'''
open(p,'w').write(s)

# ---- pin test
p='lib/geometry/phase16-surface-litres-pin.test.ts'; s=open(p).read()
s=rep(s,''' * Phase 16, D-34 and D-37 (plan 16-16): a wing's two sides share its step, and the surface runs into each tip
 * with no flip.''',''' * Phase 16, D-34, D-37 and D-38 (plan 16-16): a wing's two sides share its step, the surface runs into each tip
 * with no flip, and the tail's rail is carried around its end.''')
a=s.index('/** The live rule with its wing behaviour set back')
b=s.index('describe("the 102 boards\' litres')
s=s[:a]+'''/** The live rule with only its tips' fit (D-34) left on: the wing rule and the tail's roll set back, so each can be
 * told from the pin. */
const TIPS_ONLY: RailCharacterRule = { ...SMOOTH_SURFACE_FADE, fit: { ...SMOOTH_SURFACE_FADE.fit!, wings: "shift", tail: "square" } };

'''+s[b:]
a=s.index('  for (const board of BOARDS.filter((b) => !hasWing(b))) {')
b=s.index('  it("some boards have room for their rails')
s=s[:a]+'''  for (const board of BOARDS) {
    const narrow = hasNarrowStation(board);
    it(`${board.label}: with only the tips' fit on, it ${narrow ? "reads above the pin, for a narrow tip" : "has room for its rail and reads the pin to the last digit"}`, () => {
      const litres = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: TIPS_ONLY }).volumeLitres;
      if (narrow) expect(litres).toBeGreaterThan(Number(PIN.litres[board.label]));
      else expect(litres.toPrecision(17)).toBe(PIN.litres[board.label]);
    });
  }

  for (const board of BOARDS) {
    it(`${board.label}: the wing rule and the tail's roll move the live litres from there by a hair, and never by nothing`, () => {
      const tips = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: TIPS_ONLY }).volumeLitres;
      const live = summarizeDesign(board.fields).volumeLitres;
      expect(live).not.toBe(tips);
      expect(Math.abs(live - tips)).toBeLessThan(0.1);
      if (!hasWing(board)) expect(live).toBeLessThan(tips);
    });
  }

'''+s[b:]
a=s.index('  for (const board of BOARDS.filter(hasWing)) {')
b=s.rindex('});')
s=s[:a].rstrip()+'\n'+s[b:]
s=rep(s,'''  it("some boards have room for their rails and some don't, or the two cases above prove nothing", () => {
    const narrow = BOARDS.filter((b) => !hasWing(b)).map(hasNarrowStation);''','''  it("some boards have room for their rails and some don't, or the cases above prove nothing", () => {
    const narrow = BOARDS.map(hasNarrowStation);''')
open(p,'w').write(s)

# ---- board-surface tests
p='lib/geometry/board-surface.test.ts'; s=open(p).read()
s=rep(s,'''  railCharacterDifferences,
} from "./volume";''','''  railCharacterDifferences,
  TAIL_ROLL_RUN_IN,
  tailRollDrop,
} from "./volume";''')
s=rep(s,'''describe("every tip ends on the side profile's own tip, with no flip (D-34)", () => {
  const TIP_REACH = inchesToMm(2);
  /** The rings within 2" of each tip, ordered toward the tip, each read along one of a swallow's two points. */
  function tips({ surface, geometry }: (typeof BUILT_SURFACE)[number]) {
    const near = surface.rings.filter((ring) => ring.station >= surface.length - TIP_REACH).reverse();
    const tail = surface.rings.filter((ring) => ring.station <= TIP_REACH);
    const lines = [near.map((ring) => tipLine(surface, ring, 0)).reverse(), tail.map((ring) => tipLine(surface, ring, 0))];
    if (isSwallow(geometry)) lines.push(tail.map((ring) => tipLine(surface, ring, 1)));
    return lines;
  }
''','''describe("the nose ends on the side profile's own tip, the tail's rail is carried around its end, and neither flips (D-34, D-38)", () => {
  const TIP_REACH = inchesToMm(2);
  const ROLL_RUN = inchesToMm(TAIL_ROLL_RUN_IN);
  /** The rings within 2" of the tail end, walking in from it, read along a piece (a swallow's second point is 1). */
  const tailLine = ({ surface }: (typeof BUILT_SURFACE)[number], piece: number) =>
    surface.rings.filter((ring) => ring.station <= TIP_REACH).map((ring) => tipLine(surface, ring, piece));
''')
a=s.index('''    it(`${label}: over the last 2" into each tip the deck and the bottom lie on the side profile and turn with it`, () => {''')
b=s.index('''    it(`${label}: the check sees what it fixes''')
s=s[:a]+'''    it(`${label}: over the last 2" into the nose the deck and the bottom lie on the side profile and turn with it`, () => {
      const line = surface.rings.filter((ring) => ring.station >= surface.length - TIP_REACH).map((ring) => tipLine(surface, ring, 0));
      for (const q of line) {
        expect(Math.abs(q.deck - profile.deckAt(mm(q.station)))).toBeLessThan(0.01);
        expect(Math.abs(q.bottom - profile.rockerAt(mm(q.station)))).toBeLessThan(0.01);
      }
      for (let i = 1; i < line.length; i++) {
        const [a, b] = [line[i - 1], line[i]];
        const run = b.station - a.station;
        expect(degrees(b.deck - a.deck, profile.deckAt(mm(b.station)) - profile.deckAt(mm(a.station)), run)).toBeLessThan(0.1);
        expect(degrees(b.bottom - a.bottom, profile.rockerAt(mm(b.station)) - profile.rockerAt(mm(a.station)), run)).toBeLessThan(0.1);
      }
    });

    it(`${label}: the tail's deck rolls over along its ellipse with no corner, and the bottom stays on the rocker`, () => {
      const tipThickness = profile.thicknessAt(mm(0));
      const lines = [tailLine(board, 0), ...(isSwallow(geometry) ? [tailLine(board, 1)] : [])];
      for (const line of lines) {
        for (const q of line) {
          const deck = profile.deckAt(mm(q.station)) - tailRollDrop(mm(q.station), tipThickness);
          expect(Math.abs(q.deck - deck)).toBeLessThan(1e-3);
          expect(Math.abs(q.bottom - profile.rockerAt(mm(q.station)))).toBeLessThan(1e-3);
        }
        // Clear of the roll the deck turns with the side profile.
        const clear = line.filter((q) => q.station >= ROLL_RUN);
        for (let i = 1; i < clear.length; i++) {
          const [a, b] = [clear[i - 1], clear[i]];
          const run = b.station - a.station;
          expect(degrees(b.deck - a.deck, profile.deckAt(mm(b.station)) - profile.deckAt(mm(a.station)), run)).toBeLessThan(0.1);
        }
        // Through the roll the deck turns one way only, a little at a time: a curve, not a corner.
        const rolled = line.filter((q) => q.station <= ROLL_RUN);
        expect(rolled.length).toBeGreaterThan(10);
        const slopes = rolled.slice(1).map((q, i) => Math.atan2(q.deck - rolled[i].deck, q.station - rolled[i].station));
        for (let i = 1; i < slopes.length; i++) {
          expect(slopes[i]).toBeLessThanOrEqual(slopes[i - 1] + 1e-6);
          expect(((slopes[i - 1] - slopes[i]) * 180) / Math.PI).toBeLessThan(30);
        }
      }
    });

'''+s[b:]
s=rep(s,'''    const { label, input, geometry, profile, surface } = board;

    it(`${label}: over''','''    const { label, input, geometry, profile, surface } = board;

    it(`${label}: over''')
s=rep(s,'''        expect(kinds).not.toContain(SURFACE_FACE.capTail);
        const tailEdge = ringPoints(surface.positions, surface.rings[0]);
        expect(Math.abs(Math.min(...tailEdge.map((q) => q[2])) - profile.rockerAt(mm(0)))).toBeLessThan(1e-9);
        expect(Math.abs(Math.max(...tailEdge.map((q) => q[2])) - profile.deckAt(mm(0)))).toBeLessThan(1e-9);
''','''        expect(kinds).not.toContain(SURFACE_FACE.capTail);
        const tailEdge = ringPoints(surface.positions, surface.rings[0]);
        const rolledTop = profile.deckAt(mm(0)) - tailRollDrop(mm(0), profile.thicknessAt(mm(0)));
        expect(Math.abs(Math.min(...tailEdge.map((q) => q[2])) - profile.rockerAt(mm(0)))).toBeLessThan(1e-9);
        expect(Math.abs(Math.max(...tailEdge.map((q) => q[2])) - rolledTop)).toBeLessThan(1e-9);
''')
s=rep(s,'''        expect(loop[0][2]).toBeLessThan(profile.deckAt(mm(0)));
''','''        expect(loop[0][2]).toBeLessThan(profile.deckAt(mm(0)) - tailRollDrop(mm(0), profile.thicknessAt(mm(0))));
''')
open(p,'w').write(s)

# ---- surface report test
p='lib/models/surface-report.test.ts'; s=open(p).read()
s=rep(s,''' * The founder's read-only report of how a wing that moves only the rail and tips with no flip move every saved
 * board's litres (Phase 16, D-33, D-34, 14 D-18). Every expected figure is worked out here from the app's own
 * functions — plan 16-15's rule by name, the live rule by `summarizeDesign` — never typed.
 */''',''' * The founder's read-only report of what every saved board will read at go-live 2 (Phase 16, D-33 to D-38, 14 D-18).
 * Every expected figure is worked out here from the app's own functions — go-live 1's rule and plan 16-15's by name,
 * the live rule by `summarizeDesign` — never typed.
 */''')
s=rep(s,'''import { RAIL_CHARACTER_FADE } from "@/lib/geometry/volume";''','''import { HARD_EDGE_FADE, RAIL_CHARACTER_FADE } from "@/lib/geometry/volume";''')
s=rep(s,'''const beforeLitres = (fields: (typeof BOARDS)[number]["fields"]) =>
  summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: RAIL_CHARACTER_FADE }).volumeLitres;
''','''const beforeLitres = (fields: (typeof BOARDS)[number]["fields"]) =>
  summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_FADE }).volumeLitres;
const fadedLitres = (fields: (typeof BOARDS)[number]["fields"]) =>
  summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: RAIL_CHARACTER_FADE }).volumeLitres;
''')
a=s.index('describe("surfaceLitresMove", () => {')
b=s.index('describe("surfaceReportLines", () => {')
s=s[:a]+'''describe("surfaceLitresMove", () => {
  for (const board of BOARDS) {
    it(`${board.label}: reads what the site reads today, the fade alone, and go-live 2`, () => {
      const [before, faded, after] = [beforeLitres(board.fields), fadedLitres(board.fields), afterLitres(board.fields)];
      expect(surfaceLitresMove(board.fields)).toEqual({ before, faded, after });
    });
  }

  it("every one of the 102 moves, because the tail's roll reaches every board", () => {
    expect(BOARDS.filter((board) => surfaceLitresMove(board.fields))).toHaveLength(102);
  });
});

'''+s[b:]
s=rep(s,'''      const change = move.after - move.before;
      expect(line).toBe(
        `${board.label}: ${wings} · ${board.fields.outline.tail.kind} tail — ` +
          `${move.before.toFixed(2)} → ${move.after.toFixed(2)} L (${change > 0 ? "+" : ""}${change.toFixed(4)})`,
      );
''','''      const change = move.after - move.before;
      const share = move.after - move.faded;
      expect(line).toBe(
        `${board.label}: ${wings} · ${board.fields.outline.tail.kind} tail — ` +
          `${move.before.toFixed(2)} → ${move.after.toFixed(2)} L (${change > 0 ? "+" : ""}${change.toFixed(4)}, ` +
          `this plan ${share > 0 ? "+" : ""}${share.toFixed(4)})`,
      );
''')
s=rep(s,'''  it("says none when nothing moves, and an empty list is still a report", () => {
    expect(surfaceReportLines([])).toEqual(["surface report: 0 saved boards; 0 open; 0 whose litres move", "largest move: none"]);
    const still = BOARDS.find((board) => !surfaceLitresMove(board.fields))!;
    expect(surfaceReportLines([{ id: "b1", fields: still.fields }])).toEqual([
      "surface report: 1 saved boards; 1 open; 0 whose litres move",
      "largest move: none",
    ]);
  });
''','''  it("an empty list is still a report, and says none", () => {
    expect(surfaceReportLines([])).toEqual(["surface report: 0 saved boards; 0 open; 0 whose litres move", "largest move: none"]);
  });
''')
open(p,'w').write(s)

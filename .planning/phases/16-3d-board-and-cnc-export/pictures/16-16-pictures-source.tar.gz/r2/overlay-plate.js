// Draws the candidate rolls over the founder's own picture, in his picture's pixels.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const founder = "/Users/kontoes/Code/shaper/.planning/phases/16-3d-board-and-cnc-export/pictures/founder-wing-slice-red-line.png";
const o = JSON.parse(fs.readFileSync(path.join(dir, "overlay.json"), "utf8"));
const img = "data:image/png;base64," + fs.readFileSync(founder).toString("base64");
const k = (14.4 * 1878) / 1960;
const wall = +(process.argv[3] || 279);
const base = +(process.argv[4] || 943);
const X = (y) => wall + (y - o.W) * k;
const Y = (h) => base - h * k;
const line = (pts) => pts.filter((p) => X(p[0]) > 20).map((p, i) => `${i ? "L" : "M"}${X(p[0]).toFixed(1)} ${Y(p[1]).toFixed(1)}`).join(" ");
const colours = { asbuilt: "#111827", dm1: "#7c3aed", dm2: "#059669", r075: "#2563eb", r10: "#d97706", lift08: "#db2777", lift12: "#ca8a04", liftdm2: "#16a34a" };
const paths = Object.entries(o.curves).map(([n, c]) => `<path d="${line(c)}" fill="none" stroke="${colours[n]}" stroke-width="2"/>`).join("");
const html = `<html><body style="margin:0"><div style="position:relative;width:620px;height:460px;overflow:hidden">
<img src="${img}" style="position:absolute;left:0;top:-510px;width:1878px">
<svg width="620" height="460" viewBox="0 510 620 460" style="position:absolute;left:0;top:0">${paths}
<path d="${line(o.plain)}" fill="none" stroke="#0ea5e9" stroke-width="1"/></svg></div>
<div style="font:14px sans-serif">${Object.entries(colours).map(([n, c]) => `<span style="color:${c}">${n}</span>`).join(" · ")}</div></body></html>`;
fs.writeFileSync(path.join(dir, "overlay.html"), html);
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 640, height: 500 }, deviceScaleFactor: 2 });
  await p.goto("file://" + path.join(dir, "overlay.html"));
  await p.screenshot({ path: path.join(dir, "overlay.png") });
  await b.close();
})();

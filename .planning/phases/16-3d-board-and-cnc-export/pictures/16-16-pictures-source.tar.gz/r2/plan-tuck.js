const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const shots = [];
for (const board of ["shortboard", "fish"]) {
  for (const tag of ["was", "now"]) {
    const file = `tuck-${tag}-${board}.json`;
    const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
    const mid = 3;
    const s = d.stations[mid];
    const h = d.halves[mid];
    const z = d.rocker[mid];
    // Straight up at the bottom near the rail, along the whole blend: in a low light, and with Contour Stripes.
    const look = [s + 30, z, -h * 0.86];
    const eye = [s + 30, z - 1300, -h * 0.86 - 260];
    shots.push({ name: `T-${board}-${tag}`, file, mode: "lit", eye, look, up: [0, 0, 1], fov: 17, keyAt: [s - 1000, -120, -h - 100], key: 2.6, dim: 0.3, w: 1000, h: 300 });
    shots.push({ name: `T-${board}-${tag}-stripes`, file, mode: "stripes", eye, look, up: [0, 0, 1], fov: 17, w: 1000, h: 300 });
  }
}
fs.writeFileSync(path.join(dir, "shots.json"), JSON.stringify(shots));

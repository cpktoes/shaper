// Writes shots.json for part A.
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const norm = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
const shots = [];
for (const slug of ["wing_shortboard_one", "wing_midlength_rounded", "wing_fish_square"]) {
  for (const cand of ["today", "short", "mid", "long"]) {
    const file = `surf-${cand}-${slug}.json`;
    const d = JSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
    const s = (d.wings[0].inner + d.wings[0].stepStart) / 2;
    const half = d.wings[0].half;
    let top = -Infinity;
    for (let i = 0; i < d.positions.length; i += 3) if (Math.abs(d.positions[i] - s) < 8) top = Math.max(top, d.positions[i + 2]);
    const look = [s, top - 6, -half * 0.78];
    const dir1 = norm([-0.3, 1, -0.4]);
    const eye = look.map((v, i) => v + dir1[i] * 520);
    shots.push({ name: `A-${slug}-${cand}-stripes`, file, mode: "stripes", eye, look, up: [1, 0, 0], fov: 24, w: 800, h: 500 });
    shots.push({ name: `A-${slug}-${cand}-lit`, file, mode: "lit", eye, look, up: [1, 0, 0], fov: 24, keyAt: [900, 170, -half * 0.6], key: 2.6, dim: 0.45, w: 800, h: 500 });
    // low along the rail from behind the wing, the way a shaper sights a rail
    const sight = [s + 60, top - 8, -half * 0.97];
    shots.push({ name: `A-${slug}-${cand}-sight`, file, mode: "lit", eye: [s - 340, top + 60, -half - 90], look: sight, fov: 16, keyAt: [s, 300, -half - 300], key: 1.0, dim: 0.42, w: 800, h: 500 });
  }
}
fs.writeFileSync(path.join(dir, "shots.json"), JSON.stringify(shots));
console.log(shots.length);

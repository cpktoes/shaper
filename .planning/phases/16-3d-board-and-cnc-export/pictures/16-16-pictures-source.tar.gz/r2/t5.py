def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='e2e/rails-advanced.spec.ts'
s=open(p).read()
s=rep(s,'''    // Ends At all the way to the centre.
    await goToScreen(page, "RAILS");
    tail = await showRail(page, testInfo, "tail");
    await openAdvanced(tail);
    await endsAtSlider(page).press("End");
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${STOCK_CENTRE}`);
    await expect(endsAtSlider(page)).toHaveAttribute("aria-valuetext", `${STOCK_CENTRE} from the tail`);
''','''    // Ends At down to its lowest, 2" past Blends From: a shorter hard edge is less foam, enough for VOLUME's two
    // decimals. (Since the tail's roll, D-38, a longer fade lands on the same 30.29 L as the board opens on.)
    await goToScreen(page, "RAILS");
    tail = await showRail(page, testInfo, "tail");
    await openAdvanced(tail);
    await endsAtSlider(page).press("Home");
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${inches(20)}`);
    await expect(endsAtSlider(page)).toHaveAttribute("aria-valuetext", `${inches(20)} from the tail`);
''')
s=rep(s,'''    await expect.poll(() => keptTailRail(page, "tailHardEdgeEndsAt")).toBe(mm(STOCK_LENGTH / 2));
    await expect.poll(() => keptTailRail(page, "tailHardEdgeBlendsFrom")).toBe(inchesToMm(12));
    await page.reload();
    await goToScreen(page, "RAILS");
    tail = await showRail(page, testInfo, "tail");
    await openAdvanced(tail);
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${STOCK_CENTRE}`, { timeout: 30_000 });''','''    await expect.poll(() => keptTailRail(page, "tailHardEdgeEndsAt")).toBe(inchesToMm(20));
    await expect.poll(() => keptTailRail(page, "tailHardEdgeBlendsFrom")).toBe(inchesToMm(12));
    await page.reload();
    await goToScreen(page, "RAILS");
    tail = await showRail(page, testInfo, "tail");
    await openAdvanced(tail);
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${inches(20)}`, { timeout: 30_000 });''')
s=rep(s,'''    // One setting only: moving both at once can leave the litres where they were (an earlier start takes off
    // about what a later end keeps), and this case is about what the page says when the litres DO move.
    await endsAtSlider(page).press("End");
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${STOCK_CENTRE}`);
    const railsAfter''','''    // One setting only: moving both at once can leave the litres where they were (an earlier start takes off
    // about what a later end keeps), and this case is about what the page says when the litres DO move.
    await endsAtSlider(page).press("Home");
    await expect(endsAtLabel(tail)).toHaveText(`Tail Rail Ends At — ${inches(20)}`);
    const railsAfter''')
open(p,'w').write(s)

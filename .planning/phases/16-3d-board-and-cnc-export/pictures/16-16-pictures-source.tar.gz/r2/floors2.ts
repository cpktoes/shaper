// Round 4: what the two floors that bite actually do: drawn rails with and without them (FLOOR=off in the scratch copy).
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  let worst = 0, worstAt = "", moved = 0, seen = 0;
  const bendWorst: Record<string, number> = { on: 0, off: 0 };
  let bendAt = "";
  for (const b of F.phase16SurfaceBoards()) {
    const geometry = O.buildOutline(b.fields.outline);
    const profile = D.designSideProfile(b.fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(b.fields.rails, profile.effectiveFoil, b.fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, b.fields.outline.length);
    const input = { sections, geometry, rockerAt: profile.rockerAt };
    const st = S.surfaceStations(input);
    const fine: number[] = [];
    for (let s = 12; s < b.fields.outline.length - 12; s += 3) fine.push(s);
    const read = (mode: string) => {
      if (mode === "off") process.env.FLOOR = "off"; else delete process.env.FLOOR;
      const rings = V.boardSections(sections, st).map((x: any) => (x.result ? S.placedHalfSection(x, x.halfWidth, 0) : null));
      const line = V.boardSections(sections, fine.map(U.mm)).map((x: any) => {
        const h = S.placedHalfSection(x, x.halfWidth, 0) as number[][];
        return x.halfWidth - h[78][0];
      });
      return { rings, line };
    };
    const on = read("on");
    const off = read("off");
    on.rings.forEach((half: any, i: number) => {
      if (!half) return;
      seen++;
      let d = 0;
      for (let j = 0; j < half.length; j++) d = Math.max(d, Math.hypot(half[j][0] - off.rings[i][j][0], half[j][1] - off.rings[i][j][1]));
      if (d > 1e-6) moved++;
      if (d > worst) { worst = d; worstAt = `${b.label} at ${U.mmToInches(st[i]).toFixed(2)}"`; }
    });
    for (const [k, r] of [["on", on], ["off", off]] as const) {
      const f = r.line;
      for (let i = 1; i < f.length - 1; i++) {
        const dd = Math.abs(f[i + 1] - 2 * f[i] + f[i - 1]);
        if (dd > bendWorst[k]) { bendWorst[k] = dd; if (k === "on") bendAt = `${b.label} at ${U.mmToInches(fine[i]).toFixed(2)}"`; }
      }
    }
  }
  delete process.env.FLOOR;
  console.log("rings read", seen, "moved by lifting the two floors", moved, "largest move", worst.toFixed(3), "mm", worstAt);
  console.log("tuck line, largest bend every 3 mm: with floors", bendWorst.on.toFixed(3), bendAt, "| without", bendWorst.off.toFixed(3));
})();

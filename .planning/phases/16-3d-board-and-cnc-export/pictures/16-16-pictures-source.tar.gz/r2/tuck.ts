// Round 3: does a sharp tuck blend into a round one with a corner that lasts to the end of the blend? Read off the
// committed code (the worktree), never the scratch rule.
import { writeFileSync } from "node:fs";
const ROOT = process.argv[2];
const OUT = process.argv[3];
const deg = (r: number) => (r * 180) / Math.PI;
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const Ra = await import(`${ROOT}/lib/geometry/rail-bands`);
  const Fo = await import(`${ROOT}/lib/geometry/foil`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const all = F.phase16SurfaceBoards();
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return { rails, input: D.designCrossSectionInput(geometry, profile, rails, fields.outline.length) };
  };
  const E = 78;
  const turns = (half: number[][], from: number, to: number) => {
    let best = 0, at = -1;
    for (let i = from; i <= to; i++) {
      const a = Math.atan2(half[i][1] - half[i - 1][1], half[i][0] - half[i - 1][0]);
      const b = Math.atan2(half[i + 1][1] - half[i][1], half[i + 1][0] - half[i][0]);
      let d = Math.abs(deg(b - a));
      if (d > 180) d = 360 - d;
      if (d > best) { best = d; at = i; }
    }
    return { best, at };
  };
  const cases: [string, "nose" | "tail"][] = [
    ["tucked|shortboard|he-centre-sbt", "nose"],
    ["tucked|fish|he-centre-sbt", "nose"],
    ["tucked|shortboard|tail-sbt", "tail"],
    ["tucked|fish|tail-sbt", "tail"],
    ["shortboard|asis|hard", "tail"],
    ["fish|asis|hard", "tail"],
  ];
  const out: any = {};
  for (const [label, side] of cases) {
    const { rails, input } = inputOf(all.find((b: any) => b.label === label).fields);
    const L = input.length;
    const a = Fo.foilStationPoints(input.foil, L);
    const [from, to] = side === "nose" ? [a[2].station, a[3].station] : [Ra.hardEdgeBlendsFrom(rails, L), Ra.hardEdgeEndsAt(rails, L)];
    const fs = [0, 0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.85, 0.92, 0.96, 0.98, 0.99, 0.995, 1];
    const rows = fs.map((f) => {
      const s = from + (to - from) * f;
      const [sec] = V.boardSections(input, [s]);
      const half = S.placedHalfSection(sec, sec.halfWidth, 0) as number[][];
      const ends = V.boardSectionEnds(input, s);
      const [hb, ht] = [S.placedHalfSection(ends.base, ends.base.halfWidth, 0), S.placedHalfSection(ends.tip, ends.tip.halfWidth, 0)] as number[][][];
      return {
        f, in: U.mmToInches(s), w: ends.tipWeight, sharp: sec.sharpness,
        turn: turns(half, 60, 95), edge: turns(half, E, E).best,
        baseEdge: turns(hb, E, E).best, tipEdge: turns(ht, E, E).best,
        baseT: turns(hb, 60, 95).best, tipT: turns(ht, 60, 95).best,
        half: half.slice(55, 102), width: sec.halfWidth,
      };
    });
    out[label] = { side, rows };
    console.log(label, side, `zone ${U.mmToInches(from).toFixed(1)}–${U.mmToInches(to).toFixed(1)}`);
    for (const r of rows) console.log(`  ${(r.f * 100).toFixed(1).padStart(5)}% ${r.in.toFixed(2)}" w ${r.w.toFixed(3)} sharp ${r.sharp.toFixed(3)} | largest turn ${r.turn.best.toFixed(1)}° at pt ${r.turn.at} | at the edge point ${r.edge.toFixed(1)}° | base ${r.baseT.toFixed(1)}° tip ${r.tipT.toFixed(1)}°`);
  }
  writeFileSync(OUT, JSON.stringify(out));
})();

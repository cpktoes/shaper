def rep(s,a,b):
    assert a in s, a[:70]
    return s.replace(a,b)
p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/fade.ts'
s=open(p).read()
s=rep(s,'''    const bottom = half.slice(78); // the bottom edge to the stringer
    let tuck = 0;
    for (const [y, h] of bottom) if (h > 1e-6) tuck = Math.max(tuck, w - y);
    const apex = half[47];
''','''    const tuck = w - half[78][0]; // the bottom edge's distance in from the rail
    const apex = half[47];
''')
s=rep(s,'''  writeFileSync(join(OUT, "fade.json"), JSON.stringify(out));
''','''  writeFileSync(join(OUT, "fade.json"), JSON.stringify(out));
  // The candidates' litres, each preset as its card opens and the stock board.
  const B = await import(`${ROOT}/lib/geometry/board`);
  const boards: [string, any][] = [
    ...["shortboard", "fish", "midlength", "longboard"].map((id) => [id, fieldsOf(id)] as [string, any]),
    ["stock", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: Ra.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  const litres: any = {};
  for (const [id, fields] of boards) {
    const base = D.summarizeDesign(fields).volumeLitres;
    const L = fields.outline.length;
    const full = D.summarizeDesign({ ...fields, rails: { ...fields.rails, tailHardEdgeBlendsFrom: I(12), tailHardEdgeEndsAt: U.mm(L / 2) } }).volumeLitres;
    process.env.CONT_FOLLOWS = "1";
    const follows = D.summarizeDesign(fields).volumeLitres;
    delete process.env.CONT_FOLLOWS;
    litres[id] = { base, full, follows };
    console.log(id, base.toFixed(4), "whole stretch", (full - base).toFixed(4), "settings follow", (follows - base).toFixed(4));
  }
  writeFileSync(join(OUT, "fade-litres.json"), JSON.stringify(litres));
''')
open(p,'w').write(s)

p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/cand/lib/geometry/volume.ts'
s=open(p).read()
s=rep(s,'''  if (station <= tailStation) return tailVal;
  if (station <= centerStation) {
    const t = (station - tailStation) / (centerStation - tailStation);
    return tailVal + (centerVal - tailVal) * t;
  }
  if (station <= noseStation) {
    const t = (station - centerStation) / (noseStation - centerStation);
    return centerVal + (noseVal - centerVal) * t;
  }
''','''  if (station <= tailStation) return tailVal;
  if (station <= centerStation) {
    let t = (station - tailStation) / (centerStation - tailStation);
    if (process.env.CONT_FOLLOWS) t = 1 - tailHardEdgeWeight(mm(station), scratchZone.from, scratchZone.to);
    return tailVal + (centerVal - tailVal) * t;
  }
  if (station <= noseStation) {
    let t = (station - centerStation) / (noseStation - centerStation);
    if (process.env.CONT_FOLLOWS) t = t * t * (3 - 2 * t);
    return centerVal + (noseVal - centerVal) * t;
  }
''')
s=rep(s,'''function blendContinuous(''','''const scratchZone = { from: mm(0), to: mm(1) };
function blendContinuous(''')
s=rep(s,'''  const anchors: RailAnchorStations = { tail: tailStation, center: centerStation, nose: noseStation };
''','''  const anchors: RailAnchorStations = { tail: tailStation, center: centerStation, nose: noseStation };
  scratchZone.from = hardEdgeBlendsFrom(rails, length);
  scratchZone.to = hardEdgeEndsAt(rails, length);
''')
open(p,'w').write(s)

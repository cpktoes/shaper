def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)

# ---- wings.ts
p='lib/geometry/wings.ts'; s=open(p).read()
s=rep(s,'''/** A wing's position slider's''','''/** A wing's position slider's''') if False else s
s=rep(s,'''/** The wing "+ Add a wing" adds''','''/** The wing "+ Add a wing" adds''') if False else s
s=rep(s,'''/** Σ depth · share · fade at station `s` — what construction A takes off the curve there. */
function takeAt(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {
  if (s <= g.tailPodStation) return 0;
  let take = 0;
  for (const p of prepared) {
    const share = shareFromShape(p.shape, p.depth, s);
    const fade =
      p.inner > g.tailPodStation ? clamp((s - g.tailPodStation) / (p.inner - g.tailPodStation), 0, 1) : 0;
    take += p.depth * share * fade;
  }
  return take;
}
''','''/** A wing's fade toward the tail at station `s`: 1 from its inner corner nose-ward, 0 at the tail pod. */
function fadeAt(g: OutlineGeometry, p: PreparedWing, s: number): number {
  return p.inner > g.tailPodStation ? clamp((s - g.tailPodStation) / (p.inner - g.tailPodStation), 0, 1) : 0;
}

/** Σ depth · share · fade at station `s` — what construction A takes off the curve there. */
function takeAt(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {
  if (s <= g.tailPodStation) return 0;
  let take = 0;
  for (const p of prepared) {
    const share = shareFromShape(p.shape, p.depth, s);
    take += p.depth * share * fadeAt(g, p, s);
  }
  return take;
}
''')
s=rep(s,'''function wingedFromPrepared(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {''','''/**
 * Where a wing's shared blend stands along the board (Phase 16, D-37): the middle of its step, and how far the blend
 * reaches each way from there — `WING_SHARE_REACH_IN`, never less than the step's own run.
 */
export function wingShareSpan(w: Pick<Wing, "station" | "run" | "depth" | "radius">): { middle: Mm; reach: Mm } {
  const pts = wingStepShape(w).points;
  const [start, inner] = [pts[0].station, pts[pts.length - 1].station];
  return { middle: mm((start + inner) / 2), reach: mm(Math.max(inchesToMm(WING_SHARE_REACH_IN), start - inner)) };
}

/**
 * How far the stepped outline stands inside (+) or outside (−) the wing's meeting line at a station (Phase 16, D-37,
 * the founder: "they should share the blend"). The meeting line is the outline with its step eased along the board:
 * from where the shared blend starts ahead of the wing, it gives up the wing's depth (times the wing's fade to the
 * tail pod) by a smoothstep, half of it at the step's middle, all of it `WING_SHARE_REACH_IN` behind. A section is
 * built on that line, so the deck is smooth across the wing, and its rail then moves onto the real outline: inward
 * behind the wing, where the rail stands thicker than its own, and outward ahead of it, where it stands thinner.
 * Exactly 0 clear of the blend both ways, at or behind the tail pod and on an outline with no wings.
 */
export function wingShareAt(geometry: OutlineGeometry, station: Mm): Mm {
  if (!geometry.wings || geometry.wings.length === 0 || station <= geometry.tailPodStation) return mm(0);
  let share = 0;
  for (const p of prepare(geometry.wings)) {
    const start = p.shape.points[0].station;
    const middle = (start + p.inner) / 2;
    const reach = Math.max(inchesToMm(WING_SHARE_REACH_IN), start - p.inner);
    const t = clamp((middle + reach - station) / (2 * reach), 0, 1);
    const given = t * t * (3 - 2 * t);
    share += p.depth * fadeAt(geometry, p, station) * (shareFromShape(p.shape, p.depth, station) - given);
  }
  return mm(share);
}

function wingedFromPrepared(g: OutlineGeometry, prepared: readonly PreparedWing[], s: number): number {''')
s=rep(s,'''/** The wing's position slider's''','''/** The wing's position slider's''') if False else s
s=rep(s,'''/** A new wing's depth, in inches''','''/** How far each way along the board the two sides of a wing share its step, in inches (D-37, the founder's pick). */
export const WING_SHARE_REACH_IN = 3;
/** A new wing's depth, in inches''')
s=rep(s,''' * station behind a wing at the width this gives back, so the deck stays where it was (Phase 16, D-33).
 */''',''' * station behind a wing on the deck's meeting line from this (`wingShareAt`, Phase 16, D-37).
 */''')
open(p,'w').write(s)

# ---- outline.ts
p='lib/geometry/outline.ts'; s=open(p).read()
s=rep(s,'''   * cut, so a board without wings is today's object exactly. The litres and the 3D board read it to build each
   * station behind a wing at the width without the wing (`wingTakeAt`, Phase 16, D-33); nothing that draws or
   * measures the outline does.''','''   * cut, so a board without wings is today's object exactly. The litres and the 3D board read it to build the
   * stations either side of a wing on the deck's meeting line (`wingShareAt`, Phase 16, D-37); nothing that draws
   * or measures the outline does.''')
open(p,'w').write(s)

# ---- design.ts
p='lib/geometry/design.ts'; s=open(p).read()
s=rep(s,'''import { wingTakeAt } from "./wings";''','''import { wingShareAt } from "./wings";''')
s=rep(s,''' * (`tailCutStation`). A winged outline also carries how much its wings take at each station (`wingTakeAt`,
 * Phase 16, D-33): the litres and the 3D board build a station behind a wing at the width without the wing, and
 * step only the rail in. A board without wings carries no such thing. Spread into
 * `computeCrossSectionVolume`'s input.''',''' * (`tailCutStation`). A winged outline also carries how far it stands off the deck's meeting line at each station
 * (`wingShareAt`, Phase 16, D-37): the litres and the 3D board build the stations either side of a wing on that
 * line and move the rail onto the outline. A board without wings carries no such thing. Spread into
 * `computeCrossSectionVolume`'s input.''')
s=rep(s,'''"halfWidthAt" | "cutStation" | "wingTakeAt"> {''','''"halfWidthAt" | "cutStation" | "wingShareAt"> {''')
s=rep(s,'''  return { ...foam, wingTakeAt: (station: Mm) => wingTakeAt(geometry, station) };''','''  return { ...foam, wingShareAt: (station: Mm) => wingShareAt(geometry, station) };''')
open(p,'w').write(s)

# ---- volume.ts
p='lib/geometry/volume.ts'; s=open(p).read()
s=rep(s,'''   * How much the wings take off the curve at a station (Phase 16, D-33, `wingTakeAt` in wings.ts): `crossSectionFoam`
   * sets it only on a winged outline. The live rule builds each station behind a wing at `halfWidthAt` plus this,
   * then steps only the rail in (`wingStepHalf`); the old rules never read it.
   */
  wingTakeAt?: (station: Mm) => Mm;''','''   * How far the stepped outline stands inside (+) or outside (−) the wing's meeting line at a station (Phase 16,
   * D-37, `wingShareAt` in wings.ts): `crossSectionFoam` sets it only on a winged outline. The live rule builds
   * each station near a wing at `halfWidthAt` plus this, then moves the rail onto the outline (`wingStepHalf`); the
   * old rules never read it.
   */
  wingShareAt?: (station: Mm) => Mm;''')
s=rep(s,''' * halfWidth)`: a rail fitted into a station narrower than its own bands (D-34, `fittedFinishedRail`), or behind a
 * wing (D-33), the section as the board without the wing would have it with only its rail stepped in
 * (`wingStepHalf`). The stepped outline stays `halfWidth`, so the drawn half's outermost point is TEMPLATE's
 * outline; `result` and `blended` are the section built at the wider room the wing cuts into.
 */''',''' * halfWidth)`: a rail fitted into a station narrower than its own bands (D-34, `fittedFinishedRail`), or near a
 * wing (D-37), the section built on the deck's meeting line with its rail moved onto the outline (`wingStepHalf`).
 * The stepped outline stays `halfWidth`, so the drawn half's outermost point is TEMPLATE's outline; `result` and
 * `blended` are the section built on the meeting line.
 */''')
s=rep(s,''' * How a rail-character rule fits the section to the outline (Phase 16, plan 16-16). `wings`: `"shift"` moves the
 * whole section in with the outline behind a wing; `"hold-deck"` builds it at the width without the wing and
 * steps only the rail in (D-33). `tips`:''',''' * How a rail-character rule fits the section to the outline (Phase 16, plan 16-16). `wings`: `"shift"` moves the
 * whole section in with the outline behind a wing; `"share"` builds the stations either side of a wing on a deck
 * line the two sides share and moves only the rail onto the outline (D-37). `tips`:''')
s=rep(s,'''  wings: "shift" | "hold-deck";''','''  wings: "shift" | "share";''')
s=rep(s,''' * The live rule (Phase 16, D-33 and D-34, the founder 2026-11-04: "Wings should be steps in the outline. The Deck
 * should remain smooth across the wings location." and "Let's not do that little flip."): `RAIL_CHARACTER_FADE`'s
 * own rail character, with each station behind a wing built as the board without the wing would have it and only
 * its rail stepped in (`wingStepHalf`), and a rail wider than its station drawn into its room and counted
 * (`fittedFinishedRail`).''',''' * The live rule (Phase 16, D-33, D-34 and D-37, the founder: "Wings should be steps in the outline. The Deck should
 * remain smooth across the wings location.", "Let's not do that little flip." and "they should share the blend"):
 * `RAIL_CHARACTER_FADE`'s own rail character, with the stations either side of a wing built on the deck line the
 * two sides share and only their rails moved onto the outline (`wingShareAt`, `wingStepHalf`), and a rail wider than
 * its station drawn into its room and counted (`fittedFinishedRail`).''')
s=rep(s,'''  fit: { wings: "hold-deck", tips: "fit" },''','''  fit: { wings: "share", tips: "fit" },''')
a=s.index('''/**
 * A half-section drawn at `room` (the width without the wing)''')
b=s.index('''/**
 * An old hard-edge rule read in the rail-character terms''')
s=s[:a]+'''/**
 * A half-section drawn at `room` (the width on the wing's meeting line) with its rail moved onto the outline by `move`:
 * inward behind a wing (`move` above 0), outward ahead of it (below 0), straight up into the deck (D-37, the founder's
 * red line: "Blend the rail up to the deck with the same radius."). A point `u = room − y` in from the meeting line's
 * rail moves by `move × (1 − s(u / U))`, where `s(t) = t²(3 − 2t)` held to [0, 1] and
 * `U = min(room, max(deckMark2, 2 × |move|))`. Right at the rail the ease is level, so the rail's own tight curve moves
 * whole; the move is gone by Deck Mark 2 (never in under twice the move, or the rail would fold), and inside that
 * the deck is the meeting line's. Only distances across change, so the flat bottom stays flat and the tuck moves with
 * the rail. The stringer point never moves. Where `1.5 × |move| ≥ U` — a station barely wider than the move, where
 * the ease itself would fold — the whole half is scaled evenly into `room − move` instead.
 */
export function wingStepHalf(half: HalfSectionPoints, room: number, move: number, deckMark2: Mm): HalfSectionPoints {
  const reach = Math.min(room, Math.max(deckMark2, 2 * Math.abs(move)));
  if (1.5 * Math.abs(move) >= reach) {
    const k = (room - move) / room;
    return half.map(([y, h]) => [y * k, h]);
  }
  return half.map(([y, h]) => {
    const t = (room - y) / reach;
    const eased = t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t);
    return [y - move * (1 - eased), h];
  });
}

'''+s[b:]
s=rep(s,'''    // Behind a wing (D-33) the section is built at the width the wing cuts into; 0 everywhere else, and then
    // every line below runs exactly as it always has.
    const take = fit.wings === "hold-deck" && input.wingTakeAt && foam > 0 ? input.wingTakeAt(station) : 0;
    const room = take > 0 ? mm(foam + take) : foam;
''','''    // Near a wing (D-37) the section is built on the deck's meeting line; 0 everywhere else, and then every line
    // below runs exactly as it always has. A station too narrow to stand on the line stays on its outline.
    const offLine = fit.wings === "share" && input.wingShareAt && foam > 0 ? input.wingShareAt(station) : 0;
    const move = foam + offLine > 0 ? offLine : 0;
    const room = move !== 0 ? mm(foam + move) : foam;
''')
s=rep(s,'''    // The rail stepped in behind a wing (D-33): the half moved by `wingStepHalf`, the foam that adds to the built
    // area, and the stepped foam as the section's width (so the outline stays TEMPLATE's). `stepReach` is Deck Mark
    // 3, carried through a blend by the blend's own weight so the ease never jumps along the board.
    const steppedIn = (built: BoardSection, half: HalfSectionPoints, stepReach: Mm): BoardSection => {
      const drawn = wingStepHalf(half, room, take, stepReach);
''','''    // The rail moved onto the outline near a wing (D-37): the half moved by `wingStepHalf`, the foam that adds to or
    // takes off the built area, and the stepped foam as the section's width (so the outline stays TEMPLATE's).
    // `rollReach` is Deck Mark 2, carried through a blend by the blend's own weight so the roll never jumps.
    const movedOn = (built: BoardSection, half: HalfSectionPoints, rollReach: Mm): BoardSection => {
      const drawn = wingStepHalf(half, room, move, rollReach);
''')
s=rep(s,'''      const stepReach = mm((1 - tipWeight) * baseResult.deckMark3 + tipWeight * tipResult.deckMark3);
      sections.push(take > 0 ? steppedIn(section, blended, stepReach) : section);
''','''      const rollReach = mm((1 - tipWeight) * baseResult.deckMark2 + tipWeight * tipResult.deckMark2);
      sections.push(move !== 0 ? movedOn(section, blended, rollReach) : section);
''')
s=rep(s,'''    if (take === 0 && !ended.fits) {''','''    if (move === 0 && !ended.fits) {''')
s=rep(s,'''    sections.push(take > 0 ? steppedIn(counted, half, result.deckMark3) : counted);''','''    sections.push(move !== 0 ? movedOn(counted, half, result.deckMark2) : counted);''')
a=s.index(''' * WINGS (Phase 16, D-33, the founder 2026-11-04''')
b=s.index(''' * TIPS (Phase 16, D-34''')
s=s[:a]+''' * WINGS (Phase 16, D-33 and D-37, the founder: "Wings should be steps in the outline. The Deck should remain smooth
 * across the wings location." and "they should share the blend"). A wing is a step in the outline only. The deck
 * doesn't step: its rail stands on a meeting line (`wingShareAt`) that eases from the outline ahead of the wing to the
 * outline behind it, 3" each way, half and half at the wing. Each station in that stretch is built on the line, and its
 * rail then moves onto the real outline and rolls straight up into the deck (`wingStepHalf`): behind the wing the rail
 * stands thicker than its own, ahead of it thinner, and they meet at the wing. The flat bottom stays flat and the tuck
 * moves with the rail. The litres count that drawn half, as D-31 does a blend: the station's exact area plus the
 * drawn half's area less the half's it was moved from. The old rules shift the whole section in with the outline and
 * are kept by name for the pins (`OLD_SURFACE_FIT`).
 *
'''+s[b:]
open(p,'w').write(s)

# ---- board-surface.ts
p='lib/geometry/board-surface.ts'; s=open(p).read()
s=rep(s,'''import { WING_HAIR_MM, wingStepShape } from "./wings";''','''import { WING_HAIR_MM, wingShareSpan, wingStepShape } from "./wings";''')
s=rep(s,''' *    its bottom edge is drawn (`BoardSection.sharpness`). Nothing is blended here. Behind a wing (D-33) the
 *    section carries its ring too (`BoardSection.drawn`): the board without the wing with only its rail
 *    stepped in, so the deck and the flat bottom run smooth across the wing; and rings stand at each wing's own
 *    step (`surfaceStations`), so the outline steps where TEMPLATE does.''',''' *    its bottom edge is drawn (`BoardSection.sharpness`). Nothing is blended here. Near a wing (D-37) the
 *    section carries its ring too (`BoardSection.drawn`): built on the deck line the two sides share with only
 *    its rail moved onto the outline, so the deck and the flat bottom run smooth across the wing; and rings stand at
 *    each wing's own step and through the shared stretch (`surfaceStations`), so the outline steps where TEMPLATE
 *    does.''')
s=rep(s,''' * ends (D-30), and at each wing's own step (D-33: every point of the step, or a hair either side of a square
 * step's one station, which has two widths) — filled in so no two neighbours are more than''',''' * ends (D-30), at each wing's own step (D-33: every point of the step, or a hair either side of a square step's one
 * station, which has two widths) and every twelfth of the way through the stretch the wing's two sides share (D-37)
 * — filled in so no two neighbours are more than''')
s=rep(s,'''      for (const s of square ? [point.station - WING_HAIR_MM, point.station + WING_HAIR_MM] : [point.station]) {
        if (inside(s)) required.push(s);
      }
    });
  }
''','''      for (const s of square ? [point.station - WING_HAIR_MM, point.station + WING_HAIR_MM] : [point.station]) {
        if (inside(s)) required.push(s);
      }
    });
    const { middle, reach } = wingShareSpan(wing);
    for (let k = -WING_SHARE_RINGS; k <= WING_SHARE_RINGS; k++) {
      const s = middle + (k * reach) / WING_SHARE_RINGS;
      if (inside(s)) required.push(s);
    }
  }
''')
s=rep(s,'''/** Stations closer than this are one station. */''','''/** Rings each way through the stretch a wing's two sides share (D-37), so its short ease isn't straddled. */
const WING_SHARE_RINGS = 12;

/** Stations closer than this are one station. */''')
s=rep(s,''' * — behind a wing (`BoardSection.drawn`, D-33), inside a tip's blend''',''' * — near a wing (`BoardSection.drawn`, D-37), inside a tip's blend''')
open(p,'w').write(s)

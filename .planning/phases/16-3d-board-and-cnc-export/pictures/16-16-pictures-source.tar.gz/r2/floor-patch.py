p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/smooth/lib/geometry/rail-bands.ts'
s=open(p).read()
a='const bottomTuck2 = Math.max(MIN, Math.min(bottomTuck1 / 2, bottomTuck1 - MIN)); // C20: =C19/2'
b='const bottomTuck2 = process.env.FLOOR === "off" ? bottomTuck1 / 2 : Math.max(MIN, Math.min(bottomTuck1 / 2, bottomTuck1 - MIN)); // C20: =C19/2'
assert a in s
s=s.replace(a,b)
a='bottomTuck1 + MIN_BOTTOM_TUCK_SEPARATION_IN,'
b='process.env.FLOOR === "off" ? 0 : bottomTuck1 + MIN_BOTTOM_TUCK_SEPARATION_IN,'
assert a in s
s=s.replace(a,b)
open(p,'w').write(s)

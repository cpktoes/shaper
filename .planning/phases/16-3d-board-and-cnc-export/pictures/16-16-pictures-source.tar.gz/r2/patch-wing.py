def rep(s,a,b):
    assert a in s, a[:70]
    return s.replace(a,b)
p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/wing.ts'
s=open(p).read()
s=rep(s,'["short", "d6"]','["short", "d4"]')
s=rep(s,'''      const across = [1, 2, 3].map((k) => {
        const y = b.section.halfWidth - I(k);
        return heightAt(a.deck, y) - heightAt(b.deck, y);
      });
      let lip = 0;
      let lipAt = 0;
      for (let y = 0; y <= b.section.halfWidth; y += 0.25) {
        const j = heightAt(a.deck, y) - heightAt(b.deck, y);
        if (Math.abs(j) > Math.abs(lip)) {
          lip = j;
          lipAt = b.section.halfWidth - y;
        }
      }
''','''      // The ledge across the wing at one distance from the stringer, the board's own taper over those few
      // millimetres taken out (the board without the wing, at the same two stations).
      const pa = deckOf(plain, ahead);
      const pb = deckOf(plain, behind);
      const ledgeAt = (y: number) => heightAt(a.deck, y) - heightAt(b.deck, y) - (heightAt(pa.deck, y) - heightAt(pb.deck, y));
      const across = [0.5, 1, 2, 3].map((k) => ledgeAt(b.section.halfWidth - I(k)));
      // The lip: the height of the step's top edge, where the ahead rail's deck stands over the behind rail's outer
      // shoulder, in the last 1/4" inside the behind rail.
      const lip = ledgeAt(b.section.halfWidth - I(0.25));
      const lipAt = I(0.25);
''')
s=rep(s,'''      const f = (a: number[]) => a.map((x) => x.toFixed(2)).join(" / ");
      console.log(
        name.padEnd(6),
        "ahead", f(b.moveAhead), "| behind", f(b.moveBehind), "| across", f(b.across), "| lip", b.lip.toFixed(2), `@${b.lipIn.toFixed(2)}in`,
        "| litres", s.litres.toFixed(4), (s.move >= 0 ? "+" : "") + s.move.toFixed(4), "| gap", s.gap.toFixed(3), "| faults", s.faults,
      );
''','''      const f = (a: number[]) => a.map((x) => x.toFixed(2)).join(" / ");
      console.log(
        name.padEnd(6),
        "ahead", f(b.moveAhead), "| behind", f(b.moveBehind), "| ledge .5/1/2/3", f(b.across), "| lip", b.lip.toFixed(2),
        "| litres", s.litres.toFixed(4), (s.move >= 0 ? "+" : "") + s.move.toFixed(4), "| gap", s.gap.toFixed(3), "| faults", s.faults,
      );
      console.log("   slices", b.carried.map((c: any) => `${c.stationIn.toFixed(1)}" w ${c.width.toFixed(2)} (outline ${c.outline.toFixed(2)}) deck@1" ${c.deck1.toFixed(2)} top ${c.top.toFixed(2)}`).join(" | "));
''')
open(p,'w').write(s)

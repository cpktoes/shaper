R='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/lip/lib/geometry/'
def rep(s,a,b):
    assert a in s, a[:70]
    return s.replace(a,b)
# ---- design.ts: hand the square steps' stations to the section loop
p=R+'design.ts'; s=open(p).read()
s=rep(s,'''  return { ...foam, wingShareAt: (station: Mm) => wingShareAt(geometry, station) };''','''  const squareSteps = geometry.wings
    .map((wing) => wingStepShape(wing).points)
    .filter((pts) => Math.abs(pts[0].station - pts[pts.length - 1].station) < 1e-6)
    .map((pts) => pts[0].station);
  return { ...foam, wingShareAt: (station: Mm) => wingShareAt(geometry, station), squareSteps };''')
s=rep(s,'''import { wingShareAt } from "./wings";''','''import { wingShareAt, wingStepShape } from "./wings";''')
s=rep(s,'''"halfWidthAt" | "cutStation" | "wingShareAt"> {''','''"halfWidthAt" | "cutStation" | "wingShareAt" | "squareSteps"> {''')
open(p,'w').write(s)
# ---- volume.ts: the lip's roll, on the sections ahead of a square step
p=R+'volume.ts'; s=open(p).read()
s=rep(s,'''  wingShareAt?: (station: Mm) => Mm;
}
''','''  wingShareAt?: (station: Mm) => Mm;
  /** SCRATCH: square steps' stations, for the lip's roll. */
  squareSteps?: number[];
}
''')
s=rep(s,'''export function boardSectionsWith(
  input: CrossSectionVolumeInput,
  rule: SectionRule,
  stations?: readonly Mm[],
): BoardSection[] {
''','''const LIP_HAIR = inchesToMm(1e-6);
function deckHeightAt(half: HalfSectionPoints, y: number): number {
  for (let i = 1; i < 48; i++) {
    const [y0, h0] = half[i - 1];
    const [y1, h1] = half[i];
    if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
  }
  return half[47][1];
}
/** SCRATCH (D-37, the lip): ahead of a square step the deck rolls down onto the rail behind the step: a share `p` of
 * the height it stands above that rail, along a quarter ellipse over `run`. */
export function boardSectionsWith(input: CrossSectionVolumeInput, rule: SectionRule, stations?: readonly Mm[]): BoardSection[] {
  const sections = boardSectionsNoLip(input, rule, stations);
  const spec = process.env.LIP;
  if (!spec || !input.squareSteps?.length || !("at" in rule) || rule.fit?.wings !== "share") return sections;
  const [p, runIn] = spec.split(",").map(Number);
  const run = inchesToMm(runIn);
  return sections.map((section) => {
    for (const step of input.squareSteps!) {
      const s = section.station - step;
      if (s <= 0 || s >= run || !section.result) continue;
      const [behind] = boardSectionsNoLip(input, rule, [mm(step - LIP_HAIR)]);
      const back = (behind.drawn ?? behind.blended)!;
      const edge = back[47];
      const t = 1 - s / run;
      const e = 1 - Math.sqrt(Math.max(0, 1 - t * t));
      const from = section.drawn ?? section.blended ?? sampledFinishedRail(section.result, section.domed, section.halfWidth);
      const drawn: HalfSectionPoints = from.map(([y, h], i) => {
        if (i >= 48) return [y, h];
        const floor = y <= edge[0] ? deckHeightAt(back, y) : edge[1];
        return [y, h - p * e * Math.max(0, h - floor)];
      });
      return { ...section, drawn, area: section.area + (sampledSectionArea(drawn) - sampledSectionArea(from)) };
    }
    return section;
  });
}

function boardSectionsNoLip(
  input: CrossSectionVolumeInput,
  rule: SectionRule,
  stations?: readonly Mm[],
): BoardSection[] {
''')
open(p,'w').write(s)
# ---- board-surface.ts: rings through the roll
p=R+'board-surface.ts'; s=open(p).read()
s=rep(s,'''  required.push(...tailRollStations(TAIL_ROLL_RINGS).slice(1));
''','''  required.push(...tailRollStations(TAIL_ROLL_RINGS).slice(1));
  if (process.env.LIP) {
    const run = inchesToMm(Number(process.env.LIP.split(",")[1]));
    for (const step of input.sections.squareSteps ?? []) {
      for (let k = 1; k <= 14; k++) required.push(step + WING_HAIR_MM + run * (1 - Math.cos((k / 14) * (Math.PI / 2))));
    }
  }
''')
open(p,'w').write(s)
print('ok')

// Round 4: the step scan along the rail. Args: <root>. RAIL_T=exact bypasses the 1/16" rounding in the scratch copy.
const ROOT = process.argv[2];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const I = U.inchesToMm;
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    return D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
  };
  const heightAt = (run: number[][], y: number) => {
    for (let i = 1; i < run.length; i++) {
      const [y0, h0] = run[i - 1];
      const [y1, h1] = run[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return run[run.length - 1][1];
  };
  const labels = (process.argv[3] ?? "midlength|asis|hard,wing|midlength|rounded,shortboard|asis|hard,fish|asis|hard,longboard|asis|soft").split(",");
  const boards = F.phase16SurfaceBoards();
  const step = I(0.125);
  for (const label of labels) {
    const { fields } = boards.find((b: any) => b.label === label);
    const input = inputOf(fields);
    const L = input.length;
    const at: number[] = [];
    for (let s = I(4); s <= L - I(4); s += step) at.push(s);
    const secs = V.boardSections(input, at.map(U.mm));
    const series: Record<string, number[]> = { d1: [], d2: [], d3: [], apex: [] };
    for (const sec of secs) {
      const half = S.placedHalfSection(sec, sec.halfWidth, 0) as number[][];
      const deck = half.slice(0, 48);
      series.d1.push(sec.thickness - heightAt(deck, sec.halfWidth - I(1)));
      series.d2.push(sec.thickness - heightAt(deck, sec.halfWidth - I(2)));
      series.d3.push(sec.thickness - heightAt(deck, sec.halfWidth - I(3)));
      series.apex.push(half[47][1]);
    }
    const row = Object.entries(series).map(([k, f]) => {
      const dd = f.slice(1, -1).map((v, i) => Math.abs(f[i + 2] - 2 * v + f[i]));
      const firsts = f.slice(1).map((v, i) => Math.abs(v - f[i]));
      const big = dd.filter((x) => x > 0.05).length;
      const max = Math.max(...dd);
      const worst = U.mmToInches(at[dd.indexOf(max) + 1]);
      return `${k}: worst bend ${max.toFixed(3)} at ${worst.toFixed(1)}", biggest step ${Math.max(...firsts).toFixed(3)}, bends over 0.05: ${big}`;
    });
    console.log(label.padEnd(26), row.join(" | "));
  }
})();

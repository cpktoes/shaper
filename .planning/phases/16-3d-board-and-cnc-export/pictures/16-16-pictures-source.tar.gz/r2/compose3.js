// Round 3's three plates, in the scratchpad only.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const read = (n) => JSON.parse(fs.readFileSync(path.join(dir, n), "utf8"));
const png = (name) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${name}.png`)).toString("base64");
const INK = "#0b0b0b", MUTED = "#52514e";
const STYLE = `<meta charset="utf-8"><style>
body{margin:0;background:#fcfcfb;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:${INK};width:1400px}
h1{font-size:34px;margin:24px 28px 6px;line-height:1.15}p{margin:0 28px 10px;font-size:21px;color:#33322f;line-height:1.35}
h2{font-size:26px;margin:18px 28px 6px}h3{font-size:19px;margin:8px 28px 4px;color:${MUTED};font-weight:600}
.row{display:grid;gap:6px;padding:0 28px}.r2{grid-template-columns:1fr 1fr}.r3{grid-template-columns:repeat(3,1fr)}.r5{grid-template-columns:repeat(5,1fr)}.r7{grid-template-columns:repeat(7,1fr)}
figure{margin:0;background:#1a1f28;border-radius:6px;overflow:hidden;position:relative}figure img{display:block;width:100%}
.t{position:absolute;left:6px;top:5px;background:rgba(255,255,255,.92);color:#111;font-size:15px;font-weight:600;padding:2px 7px;border-radius:4px}
.w{background:#fff;border:1px solid #e4e3df}
table{border-collapse:collapse;margin:8px 28px;font-size:18px}th,td{padding:4px 12px;border-bottom:1px solid #e4e3df;text-align:right}th:first-child,td:first-child{text-align:left}
</style>`;
const fig = (name, tag) => `<figure><img src="${png(name)}"><span class="t">${tag}</span></figure>`;

function built() {
  const wings = [
    ["wing_shortboard_one", 'Shortboard, default wing (3/16" deep)'],
    ["wing_midlength_rounded", 'Mid-length, rounded wing (1/2" deep)'],
    ["wing_fish_square", 'Fish, square step (3/8" deep)'],
  ];
  const tails = [
    ["fish_asis_hard", "Swallow"],
    ["shortboard_asis_hard", "Squash"],
    ["shortboard_pin_hard", "Pin"],
    ["midlength_asis_hard", "Round"],
    ["shortboard_diamond_hard", "Diamond"],
  ];
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>The wing and the tail, as now built</h1>
<p>The wing shares its step 3" each way. The tail rolls over by a third of its thickness across the last inch. The nose stays as it was.</p>
${wings.map(([s, t]) => `<h2>${t}</h2><div class="row r3">${fig(`B3-${s}-stripes`, "Contour Stripes")}${fig(`B3-${s}-lit`, "Low light")}${fig(`B3-${s}-sight`, "Along the rail")}</div>`).join("")}
<h2>The five tails, from the side</h2><div class="row r5">${tails.map(([s, t]) => fig(`B3-${s}-side`, t)).join("")}</div>
<h2>From three-quarters</h2><div class="row r5">${tails.map(([s, t]) => fig(`B3-${s}-34`, t)).join("")}</div>
<div style="height:20px"></div></body></html>`;
}

function lip() {
  const m = read("lip.json");
  const cands = [["built", "As built"], ["radius", '1/4" corner radius'], ["half", 'Half, over 1/2"'], ["full1", 'All, over 1"'], ["full2", 'All, over 2"']];
  const block = (id, title) => `<h2>${title}</h2>
<div class="row r5">${cands.map(([c, t]) => fig(`L-${id}-${c}`, t)).join("")}</div>
<div class="row r5" style="margin-top:6px">${cands.map(([c, t]) => fig(`L-${id}-${c}-top`, t)).join("")}</div>
<table><tr><th></th>${cands.map(([, t]) => `<th>${t}</th>`).join("")}</tr>
<tr><td>Lip height 1/4" in, mm</td>${cands.map(([c]) => `<td>${Math.max(0, m[id][c].lip).toFixed(1)}</td>`).join("")}</tr>
<tr><td>Litres move</td>${cands.map(([c]) => `<td>${c === "built" ? "–" : m[id][c].move.toFixed(3)}</td>`).join("")}</tr></table>`;
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>Rolling a square wing's lip</h1>
<p>The step stays a wall in the outline. These roll its top edge into the deck. Top row of each: along the rail. Second row: from above in a low light.</p>
${block("fish38", 'Fish, square step 3/8" deep')}${block("fish12", 'Fish, square step 1/2" deep')}
<p style="margin-top:10px">The corner radius does not lower the lip at all; it softens the shading. All-the-way rolls take the lip off but leave a small scoop ahead of the step. Half is the cleanest roll.</p>
<div style="height:16px"></div></body></html>`;
}

function tuck() {
  const was = read("tuck-asbuilt.json")["tucked|shortboard|he-centre-sbt"].rows;
  const now = read("tuck-open.json")["tucked|shortboard|he-centre-sbt"].rows;
  const pick = [1, 2, 3, 4, 5, 6, 8];
  const panel = (row) => {
    const S = 7.4;
    const x0 = row.width - 21;
    const W = 170, H = 150;
    const X = (y) => 6 + (y - x0) * S;
    const Y = (h) => H - 10 - h * S;
    const pts = row.half.filter((p) => p[0] >= x0 && p[1] <= 19).map((p) => `${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join(" ");
    return `<figure class="w"><svg width="100%" viewBox="0 0 ${W} ${H + 22}"><polyline points="${pts}" fill="none" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/><text x="6" y="${H + 16}" font-size="15" font-weight="600">${row.in.toFixed(1)}": ${row.turn.best.toFixed(0)}°</text></svg></figure>`;
  };
  return `<!doctype html><html><head>${STYLE}</head><body>
<h1>A sharp tuck blending into a round one</h1>
<p>Shortboard with a sharp tuck at the centre, round at the nose, from the centre (37") to the nose 12" mark (62"). Each slice is the tuck, close, and the number is the sharpest turn in it. The round rail's own is about 5°.</p>
<h2>As it was: a corner in every slice, shrinking</h2><div class="row r7">${pick.map((i) => panel(was[i])).join("")}</div>
<h2>As it is now: the corner opens into a radius</h2><div class="row r7">${pick.map((i) => panel(now[i])).join("")}</div>
<h2>The bottom along that stretch, in a low light</h2>
<div class="row r2">${fig("T-shortboard-was", "As it was")}${fig("T-shortboard-now", "As it is now")}</div>
<h2>With Contour Stripes</h2>
<div class="row r2">${fig("T-shortboard-was-stripes", "As it was")}${fig("T-shortboard-now-stripes", "As it is now")}</div>
<h2>The Fish, the same way</h2>
<div class="row r2">${fig("T-fish-was", "As it was")}${fig("T-fish-now", "As it is now")}</div>
<div style="height:20px"></div></body></html>`;
}

(async () => {
  const browser = await chromium.launch();
  for (const [name, html] of [["16-16-r3-built", built()], ["16-16-r3-lip", lip()], ["16-16-r3-tuck", tuck()]]) {
    const file = path.join(dir, `${name}.html`);
    fs.writeFileSync(file, html);
    const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
    await page.goto("file://" + file);
    const h = await page.evaluate(() => document.documentElement.scrollHeight);
    await page.screenshot({ path: path.join(dir, `${name}.png`), fullPage: true });
    console.log(name, h);
    await page.close();
  }
  await browser.close();
})();

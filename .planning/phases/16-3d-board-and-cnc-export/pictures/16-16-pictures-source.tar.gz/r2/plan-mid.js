const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const norm = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
const shots = [];
for (const tag of ["was", "now"]) {
  const whole = `mid-${tag}-midlength.json`;
  const d = JSON.parse(fs.readFileSync(path.join(dir, whole), "utf8"));
  const L = d.length;
  let top = -Infinity;
  for (let i = 2; i < d.positions.length; i += 3) top = Math.max(top, d.positions[i]);
  const mid = [L / 2, 60, 0];
  const eye = [L / 2, L * 1.55, -260];
  shots.push({ name: `M-${tag}-whole-lit`, file: whole, mode: "lit", eye, look: mid, up: [0, 0, -1], fov: 13, keyAt: [L + 900, 170, 0], key: 2.6, dim: 0.42, w: 1000, h: 340 });
  shots.push({ name: `M-${tag}-whole-stripes`, file: whole, mode: "stripes", eye, look: mid, up: [0, 0, -1], fov: 13, w: 1000, h: 340 });
  const wing = `mid-${tag}-wing_midlength.json`;
  const w = JSON.parse(fs.readFileSync(path.join(dir, `mid-${tag}-wing.json`), "utf8"));
  void wing;
  const s = (w.wings[0].inner + w.wings[0].stepStart) / 2;
  const half = w.wings[0].half;
  let t = -Infinity;
  for (let i = 0; i < w.positions.length; i += 3) if (Math.abs(w.positions[i] - s) < 8) t = Math.max(t, w.positions[i + 2]);
  const look = [s, t - 6, -half * 0.72];
  const e = look.map((v, i) => v + norm([-0.3, 1, -0.4])[i] * 620);
  shots.push({ name: `M-${tag}-wing-lit`, file: `mid-${tag}-wing.json`, mode: "lit", eye: e, look, up: [1, 0, 0], fov: 24, keyAt: [900, 170, -half * 0.6], key: 2.6, dim: 0.45, w: 800, h: 500 });
  shots.push({ name: `M-${tag}-wing-stripes`, file: `mid-${tag}-wing.json`, mode: "stripes", eye: e, look, up: [1, 0, 0], fov: 24, w: 800, h: 500 });
}
fs.writeFileSync(path.join(dir, "shots.json"), JSON.stringify(shots));
console.log(shots.length);

def rep(s,a,b):
    assert a in s, a[:80]
    return s.replace(a,b)
p='lib/geometry/volume.test.ts'; s=open(p).read()
a=s.index('describe("D-33 a wing steps the outline only"')
b=s.index('describe("D-34 the rail fits into a narrow tip"')
s=s[:a]+open('/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/r2/vol_d37.ts').read()+s[b:]
s=rep(s,'''import { outlineWithoutWings, wingFootprint, wingTakeAt } from "./wings";''','''import { outlineWithoutWings, wingFootprint, wingShareAt, wingShareSpan, type Wing } from "./wings";''')
s=rep(s,'''if (!section.result || section.blended || wingTakeAt(geometry, section.station) > 0) return;''','''if (!section.result || section.blended || wingShareAt(geometry, section.station) !== 0) return;''')
s=rep(s,'''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "hold-deck", tips: "fit" });''','''    expect(SMOOTH_SURFACE_FADE.fit).toEqual({ wings: "share", tips: "fit" });''')
open(p,'w').write(s)

p='lib/geometry/phase16-surface-litres-pin.test.ts'; s=open(p).read()
s=rep(s,''' * Phase 16, D-33 and D-34 (plan 16-16): a wing is a step in the outline only, and the surface runs into each tip
 * with no flip.''',''' * Phase 16, D-34 and D-37 (plan 16-16): a wing's two sides share its step, and the surface runs into each tip
 * with no flip.''')
s=rep(s,'''import { boardSectionEnds, boardSections, RAIL_CHARACTER_FADE } from "./volume";''','''import { boardSectionEnds, boardSections, RAIL_CHARACTER_FADE, type RailCharacterRule, SMOOTH_SURFACE_FADE } from "./volume";''')
s=rep(s,'''describe("the 102 boards' litres, pinned before a wing stopped moving the deck (D-33, D-34)", () => {''','''/** The live rule with its wing behaviour set back, so a winged board's tips can be read alone. */
const WING_RULE_OFF: RailCharacterRule = { ...SMOOTH_SURFACE_FADE, fit: { ...SMOOTH_SURFACE_FADE.fit!, wings: "shift" } };

describe("the 102 boards' litres, pinned before the wing and tip rules (D-34, D-37)", () => {''')
s=rep(s,'''  for (const board of BOARDS.filter(hasWing)) {
    it(`${board.label}: the deck stays where it was, so the live litres are above the pinned litres`, () => {
      expect(summarizeDesign(board.fields).volumeLitres).toBeGreaterThan(Number(PIN.litres[board.label]));
    });
  }
''','''  for (const board of BOARDS.filter(hasWing)) {
    it(`${board.label}: with the wing rule off it reads the pin, or above it for a narrow tip; the shared wing moves it a hair`, () => {
      const off = summarizeDesignWith(board.fields, { ...LIVE_DESIGN_RULES, hardEdge: WING_RULE_OFF }).volumeLitres;
      if (hasNarrowStation(board)) expect(off).toBeGreaterThan(Number(PIN.litres[board.label]));
      else expect(off.toPrecision(17)).toBe(PIN.litres[board.label]);
      const live = summarizeDesign(board.fields).volumeLitres;
      expect(live).not.toBe(off);
      expect(Math.abs(live - off)).toBeLessThan(0.1);
    });
  }
''')
open(p,'w').write(s)

p='lib/geometry/board-surface.test.ts'; s=open(p).read()
s=rep(s,'''import { outlineWithoutWings, WING_HAIR_MM, wingFootprint, wingStepShape } from "./wings";''','''import { outlineWithoutWings, WING_HAIR_MM, wingFootprint, wingShareSpan, wingStepShape } from "./wings";''')
s=rep(s,'''      const stepPoints = geometry.wings!.flatMap((wing) => {
        const { points } = wingStepShape(wing);
        return points.flatMap((point) => {
          const square = points.some((other) => other.station === point.station && other.inward !== point.inward);
          return square ? [point.station - WING_HAIR_MM, point.station + WING_HAIR_MM] : [point.station];
        });
      });''','''      const stepPoints = geometry.wings!.flatMap((wing) => {
        const { points } = wingStepShape(wing);
        const { middle, reach } = wingShareSpan(wing);
        const shared = Array.from({ length: 25 }, (_, k) => middle + ((k - 12) * reach) / 12);
        return points
          .flatMap((point) => {
            const square = points.some((other) => other.station === point.station && other.inward !== point.inward);
            return square ? [point.station - WING_HAIR_MM, point.station + WING_HAIR_MM] : [point.station];
          })
          .concat(shared);
      });''')
s=rep(s,'''    it(`${label}: rings stand at each step point, a hair either side of a square step's station, and nowhere else new`, () => {''','''    it(`${label}: rings stand at each step point, a hair either side of a square step's station, through the shared stretch, and nowhere else new`, () => {''')
s=rep(s,'''    it(`${label}: every ring behind a wing is its section's drawn half`, () => {''','''    it(`${label}: every ring near a wing is its section's drawn half`, () => {''')
s=rep(s,'''describe("the 28 winged boards: the surface steps where TEMPLATE does and the deck runs through (D-33)", () => {''','''describe("the 28 winged boards: the surface steps where TEMPLATE does and the deck runs through (D-37)", () => {''')
s=rep(s,'/** The 28 winged boards (D-33). */','/** The 28 winged boards (D-37). */')
s=rep(s,'/** All 102 (D-33, D-34): the 74, then the winged boards. */','/** All 102 (D-34, D-37): the 74, then the winged boards. */')
open(p,'w').write(s)

p='lib/geometry/wings.test.ts'; s=open(p).read()
s=rep(s,'''  wingStepShare,
  wingTakeAt,''','''  WING_SHARE_REACH_IN,
  wingShareAt,
  wingShareSpan,
  wingStepShare,
  wingTakeAt,''')
s=rep(s,'''    it(`${id}: a board without wings takes nothing and carries no wings`, () => {''','''    it(`${id}: the outline stands on the meeting line clear of the shared stretch, both ways, and at the tail pod`, () => {
      for (const wing of winged.wings!) {
        const { middle, reach } = wingShareSpan(wing);
        expect(reach).toBe(inchesToMm(WING_SHARE_REACH_IN));
        if (wings.length === 1) {
          expect(wingShareAt(winged, mm(middle + reach + 1))).toBe(0);
          expect(wingShareAt(winged, mm(middle - reach - 1))).toBe(0);
        }
      }
      expect(wingShareAt(winged, winged.tailPodStation)).toBe(0);
      expect(wingShareAt(curve, mm(winged.length / 2))).toBe(0);
    });

    it(`${id}: ahead of a wing the outline stands outside the line, behind it inside`, () => {
      const [first, second] = winged.wings!;
      const { stepStart } = wingFootprint(first);
      const { inner } = wingFootprint(second);
      const { middle: secondMiddle } = wingShareSpan(second);
      // Ahead of both wings and behind both, the sign is the wing's own.
      expect(wingShareAt(winged, mm(stepStart + inchesToMm(1)))).toBeLessThan(0);
      if (wingFootprint(second).inner > winged.tailPodStation + inchesToMm(1)) {
        expect(wingShareAt(winged, mm(inner - inchesToMm(0.5)))).toBeGreaterThan(0);
      }
      expect(secondMiddle).toBeLessThan(wingShareSpan(first).middle);
    });

    it(`${id}: a board without wings takes nothing and carries no wings`, () => {''')
s=s.rstrip('\n')+'''

describe("the two sides of a wing meet at half the step (Phase 16, D-37)", () => {
  const { outline } = BOARDS[0];
  const square: Wing = { ...nextWing([], NO_FIN_EDGES, buildOutline(outline), "imperial"), depth: inchesToMm(3 / 8), run: mm(0), radius: mm(0) };
  const winged = buildOutline({ ...outline, wings: [square] });
  const faded = (s: number) => (s - winged.tailPodStation) / (square.station - winged.tailPodStation);

  it("a square step's share runs from half the depth outside the line to half the depth inside it", () => {
    expect(Math.abs(wingShareAt(winged, mm(square.station + WING_HAIR_MM)) + square.depth / 2)).toBeLessThan(1e-6);
    expect(Math.abs(wingShareAt(winged, mm(square.station - WING_HAIR_MM)) - (square.depth / 2) * faded(square.station))).toBeLessThan(1e-3);
  });

  it("the share eases: it shrinks away from the wing each way", () => {
    const at = (inches: number) => Math.abs(wingShareAt(winged, mm(square.station + inchesToMm(inches))));
    for (const inches of [0.5, 1, 1.5, 2, 2.5]) {
      expect(at(inches + 0.5)).toBeLessThan(at(inches));
      expect(at(-inches - 0.5)).toBeLessThan(at(-inches));
    }
  });
});
'''
open(p,'w').write(s)

p='lib/export/cnc-files.test.ts'; s=open(p).read()
s=rep(s,'''describe("the CNC files carry the step TEMPLATE draws (R8, D-33)", () => {''','''describe("the CNC files carry the step TEMPLATE draws (R8, D-37)", () => {''')
open(p,'w').write(s)

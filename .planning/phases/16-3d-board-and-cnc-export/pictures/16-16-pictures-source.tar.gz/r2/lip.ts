// Round 3, the square lip's candidates, in a scratch copy of HEAD.
//   npx --no-install tsx --tsconfig <lip>/tsconfig.json lip.ts <lip root> <out>
import { writeFileSync } from "node:fs";
import { join } from "node:path";
const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const Rn = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const CF = await import(`${ROOT}/lib/export/cnc-files`);
  const ST = await import(`${ROOT}/lib/export/stl`);
  const I = U.inchesToMm;
  const fish = F.phase16WingBoards().find((b: any) => b.label === "wing|fish|square").fields;
  const wing0 = fish.outline.wings[0];
  const withWing = (w: any) => ({ ...fish, outline: { ...fish.outline, wings: [w] } });
  const boards: [string, any, number][] = [["fish38", fish, 3 / 8], ["fish12", withWing({ ...wing0, depth: I(0.5) }), 1 / 2]];
  const cands: [string, string, boolean][] = [
    ["built", "", false],
    ["radius", "", true],
    ["half", "0.5,0.5", false],
    ["full1", "1,1", false],
    ["full2", "1,2", false],
  ];
  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return { geometry, profile, sections, surfaceInput: { sections, geometry, rockerAt: profile.rockerAt } };
  };
  const heightAt = (run: number[][], y: number) => {
    for (let i = 1; i < run.length; i++) {
      const [y0, h0] = run[i - 1];
      const [y1, h1] = run[i];
      if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
    }
    return run[run.length - 1][1];
  };
  const halfAt = (input: any, s: number) => {
    const [section] = V.boardSections(input, [s]);
    return { section, half: S.placedHalfSection(section, section.halfWidth, 0) as number[][] };
  };
  const stlCollapsed = (surface: any) => {
    const stl = ST.readStl(CF.cncFiles(surface, "x").files.find((f: any) => f.name.endsWith(".stl")).data);
    const bits = new Float32Array(3);
    const u = new Uint32Array(bits.buffer);
    const index = new Map<string, number>();
    const positions: number[] = [];
    const indices: number[] = [];
    let collapsed = 0;
    for (const tri of stl.triangles) {
      const ids = tri.map((c: readonly number[]) => {
        bits[0] = c[0]; bits[1] = c[1]; bits[2] = c[2];
        const key = `${u[0]},${u[1]},${u[2]}`;
        let v = index.get(key);
        if (v === undefined) { v = positions.length / 3; index.set(key, v); positions.push(c[0], c[1], c[2]); }
        return v;
      });
      if (new Set(ids).size < 3) { collapsed++; continue; }
      indices.push(...ids);
    }
    const w = S.meshCheck({ positions, indices });
    return { collapsed, open: w.openEdges + w.nonManifoldEdges };
  };
  const out: any = {};
  for (const [id, base, depthIn] of boards) {
    out[id] = {};
    delete process.env.LIP;
    const litres0 = D.summarizeDesign(base).volumeLitres;
    const plainFields = { ...base, outline: W.outlineWithoutWings(base.outline) };
    const plain = inputOf(plainFields).sections;
    for (const [name, lip, radius] of cands) {
      if (lip) process.env.LIP = lip; else delete process.env.LIP;
      const fields = radius ? withRadius(base) : base;
      const { geometry, profile, sections, surfaceInput } = inputOf(fields);
      const surface = S.buildBoardSurface(surfaceInput);
      const c = S.meshCheck(surface);
      const fp = W.wingFootprint(geometry.wings[0]);
      const H = W.WING_HAIR_MM * 2;
      const [ahead, behind] = [fp.stepStart + H, fp.inner - H];
      const a = halfAt(sections, ahead);
      const b = halfAt(sections, behind);
      const pa = halfAt(plain, ahead);
      const pb = halfAt(plain, behind);
      const ledge = (y: number) =>
        heightAt(a.half.slice(0, 48), y) - heightAt(b.half.slice(0, 48), y) - (heightAt(pa.half.slice(0, 48), y) - heightAt(pb.half.slice(0, 48), y));
      const at = [0.25, 1, 2, 3].map((k) => ledge(b.section.halfWidth - I(k)));
      // the true foam the lip's roll takes, station by fine station
      let foam = 0;
      if (lip) {
        const run = I(Number(lip.split(",")[1]));
        const n = 200;
        const st = Array.from({ length: n + 1 }, (_, i) => U.mm(geometry.wings[0].station + 1e-3 + ((run - 2e-3) * i) / n));
        const rolled = V.boardSections(sections, st).map((x: any) => x.area);
        delete process.env.LIP;
        const flat = V.boardSections(sections, st).map((x: any) => x.area);
        process.env.LIP = lip;
        for (let i = 0; i < n; i++) foam += (((rolled[i] - flat[i]) + (rolled[i + 1] - flat[i + 1])) / 2) * (run / n);
      }
      process.env.LIPOFF = "";
      const litres = (() => { const keep = process.env.LIP; delete process.env.LIP; const l = D.summarizeDesign(fields).volumeLitres; if (keep) process.env.LIP = keep; return l; })() + foam / 1e6;
      const slices = S.boardSlices(surface);
      const near = (want: number) => slices.reduce((best: any, x: any) => (Math.abs(x.station - want) < Math.abs(best.station - want) ? x : best));
      const sliceAhead = near(fp.stepStart + I(0.4));
      const stl = stlCollapsed(surface);
      const row = {
        lip: at[0], l1: at[1], l2: at[2], l3: at[3],
        litres, move: litres - litres0,
        faults: c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles,
        rings: surface.rings.length,
        slices: slices.length,
        stl,
        gap: (S.enclosedVolumeMm3(surface) / 1e6 / litres - 1) * 100,
        sliceIn: U.mmToInches(sliceAhead.station),
        sliceTop: Math.max(...sliceAhead.loops.flat().map((q: number[]) => q[2])) - profile.rockerAt(sliceAhead.station),
        sliceWidth: Math.max(...sliceAhead.loops.flat().map((q: number[]) => q[1])),
        aheadH: a.half, behindH: b.half,
      };
      out[id][name] = row;
      console.log(id, name.padEnd(7), "lip", row.lip.toFixed(2), "ledge", [row.l1, row.l2, row.l3].map((x) => x.toFixed(2)).join("/"), "litres", row.litres.toFixed(4), (row.move >= 0 ? "+" : "") + row.move.toFixed(4), "faults", row.faults, "slices", row.slices, "gap", row.gap.toFixed(3), "stl collapsed", stl.collapsed, "open", stl.open, `slice ${row.sliceIn.toFixed(2)}" w ${row.sliceWidth.toFixed(2)}`);
      const mesh = Rn.renderMesh(surface);
      const round = (arr: ArrayLike<number>, n: number) => Array.from(arr, (x) => +x.toFixed(n));
      writeFileSync(join(OUT, `lip-${id}-${name}.json`), JSON.stringify({ label: id, length: fields.outline.length, positions: round(mesh.positions, 4), normals: round(mesh.normals, 5), indices: Array.from(mesh.indices), stringer: Rn.stringerLines(surface), s: geometry.wings[0].station, half: b.section.halfWidth, top: profile.deckAt(behind) }));
    }
  }
  writeFileSync(join(OUT, "lip.json"), JSON.stringify(out));
  function withRadius(fields: any) {
    return { ...fields, outline: { ...fields.outline, wings: fields.outline.wings.map((w: any) => ({ ...w, radius: I(1 / 4) })) } };
  }
})();

import sys
from PIL import Image, ImageChops
a=Image.open(sys.argv[1]).convert("RGB"); b=Image.open(sys.argv[2]).convert("RGB")
d=ImageChops.difference(a,b)
px=d.load(); w,h=d.size
import collections
c=collections.Counter(max(px[x,y]) for y in range(h) for x in range(w))
print(sorted(c.items())[:40])
big=[(x,y) for y in range(h) for x in range(w) if max(px[x,y])>=20]
print(len(big), big[:60])
out=d.point(lambda v: min(255,v*20))
out.crop((450,330,1230,560)).resize((1560,460)).save(sys.argv[3])

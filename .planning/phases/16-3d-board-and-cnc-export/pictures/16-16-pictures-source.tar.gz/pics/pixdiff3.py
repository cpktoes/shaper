import sys
from PIL import Image, ImageChops
a=Image.open(sys.argv[1]).convert("RGB"); b=Image.open(sys.argv[2]).convert("RGB")
d=ImageChops.difference(a,b)
px=d.load(); w,h=d.size
for t in (6,20,51):
    pts=[(x,y) for y in range(h) for x in range(w) if max(px[x,y])>=t]
    nose=[p for p in pts if p[0]<560]; tail=[p for p in pts if p[0]>1150]
    print(t,len(pts),"nose",len(nose),"tail",len(tail),"other",len(pts)-len(nose)-len(tail), [p for p in pts if 560<=p[0]<=1150][:14])

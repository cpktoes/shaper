p='/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1616/pics/compose.js'
s=open(p).read()
a='''      const IW = (room - x0 + 4) * k + 60;
      const IH = (a.thickness + 8) * k + 60;
      const X2 = (y) => 30 + (y - x0) * k;
      const Y2 = (h) => IH - 30 - h * k;
'''
b='''      const top = Math.max(...[...a.plain, ...a.this, ...b.this].filter((p) => p[0] >= x0).map((p) => p[1]));
      const IW = (room - x0 + 4) * k + 60;
      const IH = top * k + 60;
      const X2 = (y) => 30 + (y - x0) * k;
      const Y2 = (h) => IH - 30 - h * k;
'''
assert a in s
s=s.replace(a,b)
a='''const p2 = (pts) => pts.filter((p) => p[0] >= x0 - 6).map('''
b='''const p2 = (pts) => pts.filter((p) => p[0] >= x0).map('''
assert a in s
s=s.replace(a,b)
a='''<h3>Deck in a low light along the board: the ledge you saw, and the deck without it.</h3>'''
b='''<h3>Deck in a low light along the board: the ledge you saw, and the deck without it. ${slug.includes("midlength") ? "The faint bands crossing the Mid-length's domed deck in both pictures are not the wing: they are the 1/16\\" rounding of its rail thickness, the known to-do from plan 15, and this plan leaves them alone." : ""}</h3>'''
assert a in s
s=s.replace(a,b)
open(p,'w').write(s)

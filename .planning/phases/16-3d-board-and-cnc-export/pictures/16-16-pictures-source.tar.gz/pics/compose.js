// Composes plan 16-16's three pictures for the founder from the shots and the slices.
//   node compose.js <abs out dir> <abs pictures dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const pictures = process.argv[3];
const img = (name) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${name}.png`)).toString("base64");
const measure = (tag) => JSON.parse(fs.readFileSync(path.join(dir, `measure-${tag}.json`), "utf8"));
const [mb, ma] = [measure("before"), measure("after")];
const STYLE = `<style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1960px}
h1{font-size:30px;margin:30px 36px 8px}p.lead{margin:0 36px 22px;font-size:18px;color:#4b5563;max-width:1840px;line-height:1.45}
h2{font-size:23px;margin:26px 36px 6px}h3{font-size:17px;margin:14px 36px 6px;font-weight:600;color:#374151}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:0 36px}
.row4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:0 36px}
figure{margin:0;background:#1a1f28;border:1px solid #d8d2c4;border-radius:8px;overflow:hidden;position:relative}
figure img{display:block;width:100%;height:auto}
.tag{position:absolute;left:10px;top:8px;background:rgba(255,255,255,.9);color:#111827;font-size:15px;font-weight:600;padding:3px 9px;border-radius:5px}
</style>`;
const fig = (name, tag) => `<figure><img src="${img(name)}"><span class="tag">${tag}</span></figure>`;
const L = (x) => x.toFixed(2);

async function render(browser, html, name) {
  const file = path.join(dir, `${name}.html`);
  fs.writeFileSync(file, html);
  const page = await browser.newPage({ viewport: { width: 1960, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + file);
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: path.join(pictures, `${name}.png`), fullPage: true });
  await page.close();
  console.log("wrote", name);
}

function wingPicture() {
  const boards = [
    ["wing_shortboard_one", "wing|shortboard|one", 'Shortboard with the wing TEMPLATE adds first: 3/16" deep, a 1/4" run, 11" from the tail'],
    ["wing_midlength_rounded", "wing|midlength|rounded", 'Mid-length with a rounded wing: 1/2" deep, a 1/2" run, a 1/4" radius — a domed deck'],
    ["wing_fish_square", "wing|fish|square", 'Fish with a square step: 3/8" deep, no run'],
  ];
  const body = boards
    .map(([slug, label, title]) => `<h2>${title}</h2>
<p class="lead" style="margin-bottom:6px">Litres ${L(mb[label].litres)} before, ${L(ma[label].litres)} after. Just behind the wing the deck stood ${ma[label] && mb[label].ledge[0][1].toFixed(2)} mm off the board without the wing one inch in from the rail, ${mb[label].ledge[0][2].toFixed(2)} mm two inches in and ${mb[label].ledge[0][3].toFixed(2)} mm three inches in; now ${ma[label].ledge[0][1].toFixed(2)}, ${ma[label].ledge[0][2].toFixed(2)} and ${ma[label].ledge[0][3].toFixed(2)} mm.</p>
<h3>Deck with Contour Stripes: before, the stripes jog across most of the board at the wing; after, they run straight through and only the rail's own band steps in.</h3>
<div class="row">${fig(`${slug}-before-deck`, "Before")}${fig(`${slug}-after-deck`, "After")}</div>
<h3>Deck in a low light along the board: the ledge you saw, and the deck without it. ${slug.includes("midlength") ? "The faint bands crossing the Mid-length's domed deck in both pictures are not the wing: they are the 1/16\" rounding of its rail thickness, the known to-do from plan 15, and this plan leaves them alone." : ""}</h3>
<div class="row">${fig(`${slug}-before-decklit`, "Before")}${fig(`${slug}-after-decklit`, "After")}</div>
<h3>Bottom: the flat bottom runs straight through, the tuck (the bright band along the rail) steps in with the rail.</h3>
<div class="row">${fig(`${slug}-before-bottom`, "Before")}${fig(`${slug}-after-bottom`, "After")}</div>
<h3>After: the whole board from the side, and the outline from above, with the step exactly where TEMPLATE draws it.</h3>
<div class="row">${fig(`${slug}-after-side`, "Side, after")}${fig(`${slug}-after-outline`, "From above, after")}</div>`)
    .join("\n");
  return `<!doctype html><html><head><meta charset="utf-8">${STYLE}</head><body>
<h1>Phase 16, plan 16 — the deck stays smooth across a wing</h1>
<p class="lead">A wing is a step in the outline only. Behind a wing only the rail and its bands step in, easing to nothing at Deck Mark 3, so the deck inside Deck Mark 3 and the flat bottom are the board without the wing. Every picture is the real 3D board: "before" is the code before this plan, "after" the code now, the same camera and light in both.</p>
${body}<div style="height:30px"></div></body></html>`;
}

function slicePicture() {
  const [before, after] = ["before", "after"].map((t) => JSON.parse(fs.readFileSync(path.join(dir, `slice-${t}.json`), "utf8")));
  const names = { "wing|shortboard|rounded": 'Shortboard, a rounded wing 1/2" deep', "wing|longboard|deep": 'Longboard, a wing 1" deep' };
  const panel = (label) => {
    const a = after[label];
    const b = before[label];
    const room = a.halfWidth + a.take;
    const S = 3.6;
    const pad = 46;
    const W = (room + 8) * S + pad * 2;
    const H = (a.thickness + 12) * S + pad * 2;
    const X = (y) => pad + y * S;
    const Y = (h) => H - pad - h * S;
    const path_ = (pts) => pts.map((p, i) => `${i ? "L" : "M"}${X(p[0]).toFixed(1)} ${Y(p[1]).toFixed(1)}`).join(" ");
    const dm = room - a.deckMark3;
    const inset = () => {
      // The rail, four times closer.
      const k = 4 * S;
      const x0 = room - Math.max(a.deckMark3 * 0.42, 24);
      const top = Math.max(...[...a.plain, ...a.this, ...b.this].filter((p) => p[0] >= x0).map((p) => p[1]));
      const IW = (room - x0 + 4) * k + 60;
      const IH = top * k + 60;
      const X2 = (y) => 30 + (y - x0) * k;
      const Y2 = (h) => IH - 30 - h * k;
      const p2 = (pts) => pts.filter((p) => p[0] >= x0).map((p, i) => `${i ? "L" : "M"}${X2(p[0]).toFixed(1)} ${Y2(p[1]).toFixed(1)}`).join(" ");
      return `<svg width="${IW}" height="${IH}" viewBox="0 0 ${IW} ${IH}">
<path d="${p2(a.plain)}" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-dasharray="2 5"/>
<path d="${p2(b.this)}" fill="none" stroke="#dc2626" stroke-width="2.5" stroke-dasharray="10 6"/>
<path d="${p2(a.this)}" fill="none" stroke="#111827" stroke-width="3"/>
</svg>`;
    };
    return `<h2>${names[label]} — the slice at ${a.stationIn.toFixed(1)}" from the tail, the first slice behind the wing, to scale</h2>
<p class="lead" style="margin-bottom:4px">The wing takes ${a.take.toFixed(1)} mm here. Deck Mark 3 is ${a.deckMark3.toFixed(1)} mm in from the rail.</p>
<div style="padding:0 36px;overflow:hidden"><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<line x1="${X(dm)}" x2="${X(dm)}" y1="${Y(a.thickness + 8)}" y2="${Y(-6)}" stroke="#6b7280" stroke-width="1.5" stroke-dasharray="4 4"/>
<text x="${X(dm) - 8}" y="${Y(a.thickness + 3)}" text-anchor="end" font-size="16" fill="#374151">Deck Mark 3, in from the rail</text>
<line x1="${X(0)}" x2="${X(0)}" y1="${Y(a.thickness + 8)}" y2="${Y(-6)}" stroke="#9ca3af" stroke-width="1"/>
<text x="${X(0) + 6}" y="${Y(a.thickness + 3)}" font-size="16" fill="#374151">stringer</text>
<path d="${path_(a.plain)}" fill="none" stroke="#2563eb" stroke-width="2.2" stroke-dasharray="2 5"/>
<path d="${path_(b.this)}" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="10 6"/>
<path d="${path_(a.this)}" fill="none" stroke="#111827" stroke-width="2.2"/>
</svg></div>
<h3>The rail, four times closer</h3><div style="padding:0 36px">${inset()}</div>`;
  };
  return `<!doctype html><html><head><meta charset="utf-8">${STYLE}</head><body>
<h1>Phase 16, plan 16 — the CNC slice behind a wing</h1>
<p class="lead">Half a slice, stringer on the left, as the CNC file carries it. <b style="color:#111827">Solid black: after.</b> <b style="color:#dc2626">Dashed red: before</b>, the whole section moved in by the wing. <b style="color:#2563eb">Dotted blue: the same board with no wing.</b> From the stringer out to Deck Mark 3 the solid line sits on the dotted one; only the rail stands in by the wing's depth.</p>
${Object.keys(names).map(panel).join("\n")}<div style="height:30px"></div></body></html>`;
}

function tipsPicture() {
  const flip = (m, k) => (m ? m[k].flip : 0);
  const rows = [
    ["fish_nose", "fish|asis|hard", "nose", "Fish, the nose"],
    ["fish_swallow", "fish|asis|hard", "tail", "Fish, a swallow's point (the other is its mirror)"],
    ["shortboard_nose", "shortboard|asis|hard", "nose", "Shortboard, the nose"],
    ["shortboard_squash", "shortboard|asis|hard", "tail", "Shortboard, the squash tail"],
    ["shortboard_pin", "shortboard|pin|hard", "tail", "Shortboard re-cut as a pin"],
    ["midlength_round", "midlength|asis|hard", "tail", "Mid-length, its round tail as it opens"],
  ];
  const body = rows
    .map(([key, label, end, title]) => `<h2>${title} — the flip ${flip(mb[label], end).toFixed(1)}° before, ${flip(ma[label], end).toFixed(2)}° after</h2>
<div class="row4">${fig(`${key}-before-side`, "Side, before")}${fig(`${key}-after-side`, "Side, after")}${fig(`${key}-before-34`, "Three-quarters, before")}${fig(`${key}-after-34`, "Three-quarters, after")}</div>`)
    .join("\n");
  return `<!doctype html><html><head><meta charset="utf-8">${STYLE}</head><body>
<h1>Phase 16, plan 16 — no little flip at the tips</h1>
<p class="lead">Before, the last half inch dived into a point halfway up the tip. After, the deck and the bottom run along your rocker into the tip's own edge: from the side the tip is the side profile's own tip, from above it is still the outline's point. The flip is the largest angle over the last 2" between the surface's deck or bottom line and the side profile's own line.</p>
${body}<div style="height:30px"></div></body></html>`;
}

(async () => {
  const browser = await chromium.launch();
  await render(browser, wingPicture(), "16-16-wing-before-after");
  await render(browser, slicePicture(), "16-16-wing-slice");
  await render(browser, tipsPicture(), "16-16-tips-before-after");
  await browser.close();
})();

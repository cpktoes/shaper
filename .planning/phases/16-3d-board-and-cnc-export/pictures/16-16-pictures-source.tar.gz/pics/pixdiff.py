import sys
from PIL import Image, ImageChops
a=Image.open(sys.argv[1]).convert("RGBA"); b=Image.open(sys.argv[2]).convert("RGBA")
print(a.size,b.size)
d=ImageChops.difference(a,b).convert("RGB")
px=d.load(); w,h=d.size
pts=[(x,y) for y in range(h) for x in range(w) if px[x,y]!=(0,0,0)]
print(len(pts))
if pts:
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    print("bbox",min(xs),min(ys),max(xs),max(ys))
    # cluster by x
    import collections
    c=collections.Counter((x//50*50,y//50*50) for x,y in pts)
    print(sorted(c.items()))

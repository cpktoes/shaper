// Plan 16-16's pictures and tables. Reads the REAL surface from a root (this worktree, or the third pin's commit
// extracted by `git archive`), so "before" is the code as 16-15 left it and "after" the code as it stands.
//   npx --no-install tsx --tsconfig <root>/tsconfig.json dump.ts <abs root> <tag> <abs out dir>
// Writes surf-<tag>-<slug>.json (mesh, normals, stringer), slice-<tag>.json (the CNC slices behind a wing) and
// measure-<tag>.json (per-board ledge, tips, litres).
import { writeFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.argv[2];
const TAG = process.argv[3];
const OUT = process.argv[4];
const deg = (r: number) => (r * 180) / Math.PI;

(async () => {
  const S = await import(`${ROOT}/lib/geometry/board-surface`);
  const R = await import(`${ROOT}/lib/geometry/board-surface-render`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const O = await import(`${ROOT}/lib/geometry/outline`);
  const W = await import(`${ROOT}/lib/geometry/wings`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const U = await import(`${ROOT}/lib/geometry/units`);
  const all = F.phase16SurfaceBoards();
  const fieldsOf = (label: string) => all.find((b: any) => b.label === label).fields;

  const inputOf = (fields: any) => {
    const geometry = O.buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    return { geometry, profile, rails, sections, surfaceInput: { sections, geometry, rockerAt: profile.rockerAt } };
  };

  // ---- the meshes the pictures draw
  const pictured = [
    "wing|shortboard|one",
    "wing|midlength|rounded",
    "wing|fish|square",
    "fish|asis|hard",
    "shortboard|asis|hard",
    "shortboard|pin|hard",
    "midlength|asis|hard",
  ];
  for (const label of pictured) {
    const fields = fieldsOf(label);
    const { geometry, surfaceInput, sections } = inputOf(fields);
    const surface = S.buildBoardSurface(surfaceInput);
    const mesh = R.renderMesh(surface);
    const stringer = R.stringerLines(surface);
    const round = (a: ArrayLike<number>, d: number) => Array.from(a, (x) => +x.toFixed(d));
    const wings = (fields.outline.wings ?? []).map((w: any) => ({ ...W.wingFootprint(w), shape: undefined }));
    const halfAt = (s: number) => O.sampleOutline(geometry, s);
    const profile = inputOf(fields).profile;
    const L = fields.outline.length;
    const data = {
      label,
      tail: fields.outline.tail.kind,
      length: L,
      litres: V.computeCrossSectionVolume(sections).volumeLitres,
      positions: round(mesh.positions, 4),
      normals: round(mesh.normals, 5),
      indices: Array.from(mesh.indices),
      stringer,
      wings: wings.map((w: any) => ({ inner: w.inner, stepStart: w.stepStart, half: halfAt(w.inner - 2) })),
      noseZ: profile.rockerAt(L),
      noseT: profile.thicknessAt(L),
      tailZ: profile.rockerAt(0),
      tailT: profile.thicknessAt(0),
      tailHalf: O.sampleOutline(geometry, 0),
    };
    writeFileSync(join(OUT, `surf-${TAG}-${label.replace(/\|/g, "_")}.json`), JSON.stringify(data));
  }

  // ---- the CNC slice behind a wing
  const sliceOf = (fields: any, station: number | null) => {
    const { surfaceInput } = inputOf(fields);
    const surface = S.buildBoardSurface(surfaceInput);
    return { surface, slices: S.boardSlices(surface) };
  };
  const sliceOut: Record<string, unknown> = {};
  for (const label of ["wing|shortboard|rounded", "wing|longboard|deep"]) {
    const fields = fieldsOf(label);
    const { geometry, profile, sections } = inputOf(fields);
    const inner = W.wingFootprint(geometry.wings?.[0] ?? fields.outline.wings[0]).inner;
    const { slices } = sliceOf(fields, null);
    const slice = [...slices].reverse().find((s: any) => s.station < inner);
    const z0 = profile.rockerAt(slice.station);
    const plainFields = { ...fields, outline: W.outlineWithoutWings(fields.outline) };
    const plain = sliceOf(plainFields, null).slices.find((s: any) => s.station === slice.station);
    const plainInput = inputOf(plainFields).sections;
    const [section] = V.boardSections(plainInput, [slice.station]);
    const loop = (s: any) => s.loops[0].filter((p: number[]) => p[1] >= 0).map((p: number[]) => [p[1], p[2] - z0]);
    sliceOut[label] = {
      station: slice.station,
      stationIn: U.mmToInches(slice.station),
      halfWidth: O.sampleOutline(geometry, slice.station),
      take: O.sampleOutline(O.buildOutline(plainFields.outline), slice.station) - O.sampleOutline(geometry, slice.station),
      deckMark3: section.result.deckMark3,
      thickness: section.thickness,
      this: loop(slice),
      plain: loop(plain),
    };
  }
  writeFileSync(join(OUT, `slice-${TAG}.json`), JSON.stringify(sliceOut));

  // ---- per-board measures
  const SPAN = U.inchesToMm(2);
  const measure: Record<string, unknown> = {};
  for (const board of all) {
    const { geometry, profile, sections, surfaceInput } = inputOf(board.fields);
    const surface = S.buildBoardSurface(surfaceInput);
    const p = surface.positions;
    const lineOf = (k: number) =>
      surface.rings.map((ring: any) => {
        const piece = ring.pieces[Math.min(k, ring.pieces.length - 1)];
        let top = -Infinity;
        let bot = Infinity;
        for (const v of S.pieceVertices(piece)) {
          top = Math.max(top, p[3 * v + 2]);
          bot = Math.min(bot, p[3 * v + 2]);
        }
        return { s: ring.station as number, top, bot };
      });
    const L = sections.length;
    const tip = (rows: { s: number; top: number; bot: number }[]) => {
      let flip = 0;
      let off = 0;
      for (let i = 1; i < rows.length; i++) {
        const [a, b] = [rows[i - 1], rows[i]];
        const ds = Math.abs(b.s - a.s);
        const sign = b.s >= a.s ? 1 : -1;
        flip = Math.max(
          flip,
          Math.abs(deg(Math.atan2(sign * (b.top - a.top), ds) - Math.atan2(sign * (profile.deckAt(b.s) - profile.deckAt(a.s)), ds))),
          Math.abs(deg(Math.atan2(sign * (b.bot - a.bot), ds) - Math.atan2(sign * (profile.rockerAt(b.s) - profile.rockerAt(a.s)), ds))),
        );
      }
      for (const r of rows) off = Math.max(off, Math.abs(r.top - profile.deckAt(r.s)), Math.abs(r.bot - profile.rockerAt(r.s)));
      // The largest turn of the deck line between neighbouring panels, walking the line itself.
      let turn = 0;
      let bottomOff = 0;
      for (let i = 0; i < rows.length; i++) {
        bottomOff = Math.max(bottomOff, Math.abs(rows[i].bot - profile.rockerAt(rows[i].s)));
        if (i < 2) continue;
        const [a, b, c] = [rows[i - 2], rows[i - 1], rows[i]];
        turn = Math.max(turn, Math.abs(deg(Math.atan2(c.top - b.top, c.s - b.s) - Math.atan2(b.top - a.top, b.s - a.s))));
      }
      return { flip, off, turn, bottomOff };
    };
    const nose = tip(lineOf(0).filter((r: any) => r.s >= L - SPAN - 1e-6));
    const tail = tip(lineOf(0).filter((r: any) => r.s <= SPAN + 1e-6));
    const hasCut = geometry.centreCloseStation > geometry.points[0].station;
    const tail2 = hasCut ? tip(lineOf(1).filter((r: any) => r.s <= SPAN + 1e-6)) : null;
    const check = S.meshCheck(surface);
    const litres = D.summarizeDesign(board.fields).volumeLitres;
    const vol = V.computeCrossSectionVolume(sections).volumeLitres;
    const gap = (S.enclosedVolumeMm3(surface) / 1e6 / vol - 1) * 100;

    // The ledge: just behind each wing, the deck against the wing-less board's deck at the same distance across.
    let ledge: unknown = null;
    if (board.fields.outline.wings?.length) {
      const plainFields = { ...board.fields, outline: W.outlineWithoutWings(board.fields.outline) };
      const plain = inputOf(plainFields).sections;
      const halves = (input: any, s: number) => {
        const [section] = V.boardSections(input, [s]);
        return { section, half: S.placedHalfSection(section, section.halfWidth, 0) as [number, number][] };
      };
      const heightAt = (run: [number, number][], y: number) => {
        for (let i = 1; i < run.length; i++) {
          const [y0, h0] = run[i - 1];
          const [y1, h1] = run[i];
          if (y <= y1) return y1 > y0 ? h0 + ((h1 - h0) * (y - y0)) / (y1 - y0) : h1;
        }
        return run[run.length - 1][1];
      };
      const rows: number[][] = [];
      for (const wing of W.placedWings(board.fields.outline.wings, geometry)) {
        const s = W.wingFootprint(wing).inner - 2;
        const a = halves(sections, s);
        const b = halves(plain, s);
        const deckA = a.half.slice(0, 48);
        const deckB = b.half.slice(0, 48);
        const inFrom = (d: number) => Math.abs(heightAt(deckA, a.section.halfWidth - d) - heightAt(deckB, a.section.halfWidth - d));
        rows.push([
          Math.abs(heightAt(deckA, b.section.halfWidth / 2) - heightAt(deckB, b.section.halfWidth / 2)),
          inFrom(U.inchesToMm(1)),
          inFrom(U.inchesToMm(2)),
          inFrom(U.inchesToMm(3)),
        ]);
      }
      ledge = rows;
    }
    measure[board.label] = { nose, tail, tail2, check, litres, gap, ledge, tailKind: board.fields.outline.tail.kind, rings: surface.rings.length };
  }
  writeFileSync(join(OUT, `measure-${TAG}.json`), JSON.stringify(measure));
  console.log("done", TAG, Object.keys(measure).length);
})();

// Plan 16-16's 3D shots, headless (16-03's harness: no server, no port — Playwright answers every request from
// disk). The REAL surface from dump.ts, in the room's axes the app uses (x along the board, y up, z across, a
// rotation of the surface's own, so the winding is kept), with the app's own Contour Stripes shader for the striped views.
//   node shoot.js <abs out dir> <abs three build dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const threeDir = process.argv[3];
const only = process.argv[4];

const page = `<!doctype html><html><head><meta charset="utf-8">
<style>html,body{margin:0;height:100%;background:#1a1f28}canvas{display:block}</style>
<script type="importmap">{"imports":{"three":"http://mock.local/three/three.module.js"}}</script></head><body>
<script type="module">
import * as THREE from "three";
const shot = JSON.parse(decodeURIComponent(location.hash.slice(1)));
const DATA = await (await fetch("http://mock.local/" + shot.file)).json();
const P = DATA.positions, N = DATA.normals;
const pos = new Float32Array(P.length), nor = new Float32Array(N.length);
for (let i = 0; i < P.length; i += 3) {
  pos[i] = P[i]; pos[i + 1] = P[i + 2]; pos[i + 2] = -P[i + 1];
  nor[i] = N[i]; nor[i + 1] = N[i + 2]; nor[i + 2] = -N[i + 1];
}
const geo = new THREE.BufferGeometry();
geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
geo.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
geo.setIndex(DATA.indices);
const scene = new THREE.Scene();
const bg = shot.bg || "#1a1f28";
scene.background = new THREE.Color(bg);
const foam = new THREE.MeshStandardMaterial({ color: 0xf0ece2, roughness: 0.92, metalness: 0, side: THREE.FrontSide });
const stripes = new THREE.ShaderMaterial({
  uniforms: { foam: { value: new THREE.Color(0xf0ece2) }, onFoam: { value: new THREE.Color(0x39424f) }, pairSpan: { value: (2 * 12 * Math.PI) / 180 } },
  vertexShader: \`varying vec3 vRoomNormal; varying vec3 vRoomPosition;
void main(){ vec4 room = modelMatrix * vec4(position, 1.0); vRoomPosition = room.xyz; vRoomNormal = normalize(mat3(modelMatrix) * normal); gl_Position = projectionMatrix * viewMatrix * room; }\`,
  fragmentShader: \`uniform vec3 foam; uniform vec3 onFoam; uniform float pairSpan; varying vec3 vRoomNormal; varying vec3 vRoomPosition;
void main(){ vec3 n = normalize(vRoomNormal); vec3 sight = normalize(vRoomPosition - cameraPosition); vec3 r = reflect(sight, n);
float across = max(r.y*r.y + r.z*r.z, 1e-6); float t = atan(r.z, r.y) / pairSpan; vec3 rx = dFdx(r); vec3 ry = dFdy(r);
float w = (abs(r.y*rx.z - r.z*rx.y) + abs(r.y*ry.z - r.z*ry.y)) / across / pairSpan; float s = abs(fract(t) - 0.5);
float light = clamp((s - 0.25) / max(w, 1e-4) + 0.5, 0.0, 1.0); light = mix(light, 0.5, clamp(2.0*w - 1.0, 0.0, 1.0));
gl_FragColor = vec4(mix(onFoam, foam, light), 1.0);
#include <colorspace_fragment>
}\`,
});
scene.add(new THREE.Mesh(geo, shot.mode === "stripes" ? stripes : foam));
const lineMat = new THREE.LineBasicMaterial({ color: 0x1b1f26 });
const line = (pts, lift) => new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts.map((p) => new THREE.Vector3(p[0], p[2] + lift, -p[1]))), lineMat);
if (shot.mode !== "stripes") { scene.add(line(DATA.stringer.deck, 0.15)); scene.add(line(DATA.stringer.bottom, -0.15)); }
const dl = (c, i, x, y, z) => { const l = new THREE.DirectionalLight(c, i); l.position.set(x, y, z); scene.add(l); };
const dim = shot.dim ?? 1;
dl(0xfff3e0, 2.6 * dim, 150, 90, -1400); dl(0xfff3e0, 2.0 * dim, -250, 60, 1400); dl(0xfff8ee, 0.7, 300, -1400, -200);
dl(0xffffff, shot.key ?? 1.2, shot.keyAt ? shot.keyAt[0] : -500, shot.keyAt ? shot.keyAt[1] : 500, shot.keyAt ? shot.keyAt[2] : -300);
scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8a90, 0.9));
scene.add(new THREE.AmbientLight(0xffffff, 0.25));
const W = shot.w || 960, H = shot.h || 600;
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(2); renderer.setSize(W, H); document.body.appendChild(renderer.domElement);
const camera = new THREE.PerspectiveCamera(shot.fov || 22, W / H, 5, 20000);
camera.up.set(...(shot.up || [0, 1, 0]));
camera.position.set(...shot.eye);
camera.lookAt(...shot.look);
renderer.render(scene, camera);
window.__done = true;
</script></body></html>`;
fs.writeFileSync(path.join(dir, "shoot.html"), page);

const types = { ".html": "text/html", ".js": "text/javascript", ".json": "application/json" };
const shots = JSON.parse(fs.readFileSync(path.join(dir, "shots.json"), "utf8")).filter((s) => !only || s.name.includes(only));
(async () => {
  const browser = await chromium.launch({ args: ["--use-angle=swiftshader-webgl", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  for (const shot of shots) {
    const w = shot.w || 960, h = shot.h || 600;
    const tab = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 2 });
    await tab.route("http://mock.local/**", async (route) => {
      const p = new URL(route.request().url()).pathname;
      const file = p.startsWith("/three/") ? path.join(threeDir, p.slice("/three/".length)) : path.join(dir, p.slice(1));
      if (!fs.existsSync(file)) return route.fulfill({ status: 404, body: "missing " + p });
      await route.fulfill({ status: 200, contentType: types[path.extname(file)] || "application/octet-stream", body: fs.readFileSync(file) });
    });
    tab.on("console", (m) => { if (m.type() === "error") console.log("console error:", m.text()); });
    tab.on("pageerror", (e) => console.log("page error:", e.message));
    await tab.goto(`http://mock.local/shoot.html#${encodeURIComponent(JSON.stringify(shot))}`);
    await tab.waitForFunction(() => window.__done === true, null, { timeout: 180000 });
    await tab.screenshot({ path: path.join(dir, `${shot.name}.png`) });
    console.log(shot.name);
    await tab.close();
  }
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

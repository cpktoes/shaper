// Writes shots.json: every 3D shot of plan 16-16's pictures, positioned from the dumped boards.
//   node plan-shots.js <abs out dir>
const fs = require("node:fs");
const path = require("node:path");
const dir = process.argv[2];
const load = (tag, slug) => JSON.parse(fs.readFileSync(path.join(dir, `surf-${tag}-${slug}.json`), "utf8"));
const shots = [];
const norm = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };

function deckAt(data, s) {
  let top = -Infinity;
  for (let i = 0; i < data.positions.length; i += 3) if (Math.abs(data.positions[i] - s) < 8) top = Math.max(top, data.positions[i + 2]);
  return top;
}
function bottomAt(data, s) {
  let low = Infinity;
  for (let i = 0; i < data.positions.length; i += 3) if (Math.abs(data.positions[i] - s) < 8) low = Math.min(low, data.positions[i + 2]);
  return low;
}

// ---- wings: the right rail's wing, close from above and from below, before and after
for (const slug of ["wing_shortboard_one", "wing_midlength_rounded", "wing_fish_square"]) {
  const a = load("after", slug);
  const w = a.wings[0];
  const s = w.inner;
  const half = w.half;
  const top = deckAt(a, s);
  const low = bottomAt(a, s);
  const look = [s, top, -half * 0.62];
  const lookBottom = [s, low, -half * 0.62];
  const far = 640;
  const deckDir = norm([-0.35, 1, -0.42]);
  const botDir = norm([-0.35, -1, -0.42]);
  const eye = (l, d) => l.map((v, i) => v + d[i] * far);
  for (const tag of ["before", "after"]) {
    const file = `surf-${tag}-${slug}.json`;
    shots.push({ name: `${slug}-${tag}-deck`, file, mode: "stripes", eye: eye(look, deckDir), look, up: [1, 0, 0], fov: 24 });
    shots.push({ name: `${slug}-${tag}-decklit`, file, mode: "lit", eye: eye(look, deckDir), look, up: [1, 0, 0], fov: 24, keyAt: [900, 170, -half * 0.6], key: 2.6, dim: 0.45 });
    shots.push({ name: `${slug}-${tag}-bottom`, file, mode: "lit", eye: eye(lookBottom, botDir), look: lookBottom, up: [1, 0, 0], fov: 24, keyAt: [200, -300, -900], key: 1.2, dim: 0.5 });
  }
  const L = a.length;
  shots.push({ name: `${slug}-after-side`, file: `surf-after-${slug}.json`, mode: "lit", eye: [L * 0.5, top + 40, -2300], look: [L * 0.5, top * 0.8, 0], fov: 40 });
  shots.push({ name: `${slug}-after-outline`, file: `surf-after-${slug}.json`, mode: "lit", eye: [s, top + 700, -half * 0.8], look: [s, top, -half * 0.8], up: [1, 0, 0], fov: 22 });
}

// ---- tips: from the side and from three-quarters, before and after
const tips = [
  { key: "fish_nose", slug: "fish_asis_hard", end: "nose" },
  { key: "fish_swallow", slug: "fish_asis_hard", end: "tail", point: true },
  { key: "shortboard_nose", slug: "shortboard_asis_hard", end: "nose" },
  { key: "shortboard_squash", slug: "shortboard_asis_hard", end: "tail" },
  { key: "shortboard_pin", slug: "shortboard_pin_hard", end: "tail" },
  { key: "midlength_round", slug: "midlength_asis_hard", end: "tail" },
];
for (const tip of tips) {
  const a = load("after", tip.slug);
  const nose = tip.end === "nose";
  const x = nose ? a.length : 0;
  const z = nose ? a.noseZ : a.tailZ;
  const t = nose ? a.noseT : a.tailT;
  const inward = nose ? -1 : 1;
  const across = tip.point ? -a.tailHalf : 0;
  // A little way in from the tip, level with the middle of the tip's edge.
  const lookSide = [x + inward * 34, z + t / 2 + (nose ? -6 : 3), across];
  const look34 = [x + inward * 40, z + t / 2, across];
  for (const tag of ["before", "after"]) {
    const file = `surf-${tag}-${tip.slug}.json`;
    shots.push({ name: `${tip.key}-${tag}-side`, file, mode: "lit", eye: [lookSide[0], lookSide[1], across - 520], look: lookSide, fov: 14, keyAt: [x, 400, across - 700], key: 0.9, dim: 0.42 });
    const d = norm([-inward * 0.75, 0.55, -0.75]);
    shots.push({ name: `${tip.key}-${tag}-34`, file, mode: "lit", eye: look34.map((v, i) => v + d[i] * 540), look: look34, fov: 14, keyAt: [x - inward * 300, 500, across - 500], key: 0.9, dim: 0.42 });
  }
}
fs.writeFileSync(path.join(dir, "shots.json"), JSON.stringify(shots, null, 1));
console.log(shots.length, "shots");

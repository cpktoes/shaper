// Plan 16-16's tables for the SUMMARY: every figure from the app's own functions, the third pin and dump.ts's two
// measures. Run from the worktree root:
//   npx --no-install tsx --tsconfig ./tsconfig.json tables.ts <abs root> <abs out dir> > tables.md
import { readFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.argv[2];
const OUT = process.argv[3];
(async () => {
  const F = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards`);
  const D = await import(`${ROOT}/lib/geometry/design`);
  const V = await import(`${ROOT}/lib/geometry/volume`);
  const P = await import(`${ROOT}/lib/geometry/presets`);
  const PB = await import(`${ROOT}/lib/blanks/preset-blanks`);
  const B = await import(`${ROOT}/lib/geometry/board`);
  const R = await import(`${ROOT}/lib/geometry/rail-bands`);
  const SR = await import(`${ROOT}/lib/models/surface-report`);
  const pin = JSON.parse(readFileSync(join(ROOT, "lib/geometry/__fixtures__/phase16-surface-litres-pin.json"), "utf8")).litres;
  const before = JSON.parse(readFileSync(join(OUT, "measure-before.json"), "utf8"));
  const after = JSON.parse(readFileSync(join(OUT, "measure-after.json"), "utf8"));
  const boards = F.phase16SurfaceBoards();
  const signed = (x: number) => (x === 0 ? "±0.0000" : `${x > 0 ? "+" : "−"}${Math.abs(x).toFixed(4)}`);

  console.log("### The presets as their cards open them, and the stock 6'0\"\n");
  console.log("| Board | Before (L) | After (L) | Move (L) | Card before | Card after |\n|---|---:|---:|---:|---:|---:|");
  const open = [
    ...P.BOARD_PRESETS.map((preset: any) => [preset.name, { ...PB.presetDesignFields(preset), railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC }]),
    ["Stock 6'0\"", { outline: B.DEFAULT_BOARD_SPEC.outline, rocker: B.DEFAULT_BOARD_SPEC.rocker, foil: B.DEFAULT_BOARD_SPEC.foil, rails: R.DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: V.DEFAULT_VOLUME_SPEC, blank: null }],
  ];
  for (const [name, fields] of open) {
    const b = D.summarizeDesignWith(fields, { ...D.LIVE_DESIGN_RULES, hardEdge: V.RAIL_CHARACTER_FADE }).volumeLitres;
    const a = D.summarizeDesign(fields).volumeLitres;
    console.log(`| ${name} | ${b.toFixed(4)} | ${a.toFixed(4)} | ${signed(a - b)} | ${b.toFixed(2)} | ${a.toFixed(2)} |`);
  }

  console.log("\n### The ledge, per winged board and wing (mm off the board without the wing, just behind the wing)\n");
  console.log("| Board | Wing | 1\" in, today | 1\" in, after | 2\" in, today | 2\" in, after | 3\" in, today | 3\" in, after | half-width, today | half-width, after |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const b of boards.filter((x: any) => x.fields.outline.wings?.length)) {
    before[b.label].ledge.forEach((row: number[], i: number) => {
      const a = after[b.label].ledge[i];
      console.log(`| ${b.label} | ${i + 1} | ${row[1].toFixed(2)} | ${a[1].toFixed(2)} | ${row[2].toFixed(2)} | ${a[2].toFixed(2)} | ${row[3].toFixed(2)} | ${a[3].toFixed(2)} | ${row[0].toFixed(2)} | ${a[0].toFixed(2)} |`);
    });
  }

  console.log("\n### The flip, per board and tip (largest angle off the side profile over the last 2\", and furthest off it)\n");
  console.log("| Board | Tip | Flip today | Flip after | Off today (mm) | Off after (mm) |\n|---|---|---:|---:|---:|---:|");
  const worst = { flip: 0, off: 0 };
  for (const b of boards) {
    const [x, y] = [before[b.label], after[b.label]];
    const row = (tip: string, k: string) => {
      if (!x[k]) return;
      worst.flip = Math.max(worst.flip, y[k].flip);
      worst.off = Math.max(worst.off, y[k].off);
      console.log(`| ${b.label} | ${tip} | ${x[k].flip.toFixed(1)}° | ${y[k].flip.toFixed(3)}° | ${x[k].off.toFixed(2)} | ${y[k].off.toFixed(4)} |`);
    };
    row("nose", "nose");
    row(x.tail2 ? "swallow point, right" : `tail (${x.tailKind})`, "tail");
    row("swallow point, left", "tail2");
  }
  console.log(`\nWorst after: ${worst.flip.toFixed(3)}°, ${worst.off.toFixed(4)} mm.`);

  console.log("\n### The 102 boards' litres\n");
  console.log("| Board | Pinned (L) | Now (L) | Move (L) | 3D vs VOLUME, today | 3D vs VOLUME, now | Mesh faults |\n|---|---:|---:|---:|---:|---:|---:|");
  let same = 0;
  for (const b of boards) {
    const now = D.summarizeDesign(b.fields).volumeLitres;
    const old = Number(pin[b.label]);
    if (now.toPrecision(17) === pin[b.label]) same++;
    const c = after[b.label].check;
    const faults = c.openEdges + c.nonManifoldEdges + c.misWoundEdges + c.zeroAreaTriangles;
    console.log(`| ${b.label} | ${old.toFixed(4)} | ${now.toFixed(4)} | ${signed(now - old)} | ${before[b.label].gap.toFixed(3)}% | ${after[b.label].gap.toFixed(3)}% | ${faults} |`);
  }
  console.log(`\n${same} of 102 bit-identical.`);

  console.log("\n### The surface report on the 102 test boards\n\n```");
  for (const line of SR.surfaceReportLines(boards.map((b: any) => ({ id: b.label, fields: b.fields })))) console.log(line);
  console.log("```");
})();

// Plan 16-06's pictures for the founder: the real 3D screen shot from the worktree's dev server (port 3206).
// Run: npx playwright test -c <abs>/pictures.config.ts   (SHOTS=name,name to shoot a few)
import { expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/geometry/presets";
import { inchesToMm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/theme";

const OUT = __dirname + "/out";
const only = (process.env.SHOTS ?? "").split(",").filter(Boolean);
const wanted = (name: string) => only.length === 0 || only.includes(name);

function fieldsOf(presetName: string, lengthMm?: number): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === presetName)!;
  const base = presetDesignFields(preset);
  return {
    ...base,
    outline: lengthMm ? { ...base.outline, length: lengthMm as never } : base.outline,
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page, opts: { preset: string; theme: string; lengthMm?: number }) {
  const raw = openBoardCopyJson(fieldsOf(opts.preset, opts.lengthMm), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey, theme]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, theme);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY, opts.theme] as const,
  );
}

async function shoot(page: Page, name: string, state: string) {
  await page.goto("/design/3d");
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", state, { timeout: 120_000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/${name}.png` });
}

const desktop = { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 };

for (const [name, preset, theme] of [
  ["daylight-fish", "Fish", "daylight"],
  ["daylight-shortboard", "Shortboard", "daylight"],
  ["daylight-midlength", "Mid-length", "daylight"],
  ["daylight-longboard", "Longboard", "daylight"],
  ["chalk-fish", "Fish", "chalk"],
  ["slate-fish", "Fish", "slate"],
  ["phosphor-fish", "Fish", "phosphor"],
] as const) {
  test(name, async ({ browser }) => {
    test.skip(!wanted(name));
    const context = await browser.newContext(desktop);
    const page = await context.newPage();
    await prepare(page, { preset, theme });
    await shoot(page, name, "ready");
    await context.close();
  });
}

test("phone-fish", async ({ playwright }) => {
  test.skip(!wanted("phone-fish"));
  const browser = await playwright.webkit.launch();
  const context = await browser.newContext({ ...playwright.devices["iPhone 14"], baseURL: "http://localhost:3206" });
  const page = await context.newPage();
  await prepare(page, { preset: "Fish", theme: "daylight" });
  await shoot(page, "phone-fish", "ready");
  await browser.close();
});

test("message-no-webgl", async ({ browser }) => {
  test.skip(!wanted("message-no-webgl"));
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page, { preset: "Fish", theme: "daylight" });
  await page.addInitScript(() => {
    HTMLCanvasElement.prototype.getContext = function () {
      return null;
    } as typeof HTMLCanvasElement.prototype.getContext;
  });
  await shoot(page, "message-no-webgl", "no-webgl");
  await context.close();
});

test("message-cant-build", async ({ browser }) => {
  test.skip(!wanted("message-cant-build"));
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page, { preset: "Fish", theme: "daylight", lengthMm: inchesToMm(40) });
  await shoot(page, "message-cant-build", "cant-build");
  await context.close();
});

test("message-didnt-load", async ({ browser }) => {
  test.skip(!wanted("message-didnt-load"));
  const context = await browser.newContext(desktop);
  const learn = await context.newPage();
  await prepare(learn, { preset: "Fish", theme: "daylight" });
  const urls: string[] = [];
  learn.on("response", async (response) => {
    if (response.request().resourceType() !== "script") return;
    const body = await response.text().catch(() => "");
    if (body.includes("THREE.WebGLRenderer")) urls.push(response.url());
  });
  await shoot(learn, "learn", "ready");
  expect(urls.length).toBeGreaterThan(0);
  await learn.close();
  const page = await context.newPage();
  await prepare(page, { preset: "Fish", theme: "daylight" });
  for (const url of urls) await page.route(url, (route) => route.abort());
  await shoot(page, "message-didnt-load", "didnt-load");
  await context.close();
});

test("debug-slate", async ({ browser }) => {
  test.skip(!wanted("debug-slate"));
  const context = await browser.newContext(desktop);
  const page = await context.newPage();
  await prepare(page, { preset: "Fish", theme: "slate" });
  await page.goto("/design/3d");
  await expect(page.locator("[data-board-3d]")).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  const out = await page.evaluate(() => {
    const style = getComputedStyle(document.documentElement);
    const probe = document.createElement("canvas").getContext("2d");
    const raw = ["--surf-canvas", "--surf-foam", "--surf-on-foam"].map((n) => [n, style.getPropertyValue(n)]);
    probe!.fillStyle = style.getPropertyValue("--surf-canvas").trim();
    probe!.fillRect(0, 0, 1, 1);
    return {
      cls: document.documentElement.className,
      raw,
      px: Array.from(probe!.getImageData(0, 0, 1, 1).data),
      host: getComputedStyle(document.querySelector("[data-board-3d]")!).backgroundColor,
    };
  });
  console.log("DEBUG " + JSON.stringify(out));
  await context.close();
});

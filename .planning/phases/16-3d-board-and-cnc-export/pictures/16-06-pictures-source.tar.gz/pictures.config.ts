// Scratch config for plan 16-06's pictures: the repo's own config, this folder's spec, the worktree's dev server on 3206.
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/playwright.config";
import { defineConfig } from "@playwright/test";

const worktree = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a";
const port = 3206;

export default defineConfig({
  ...base,
  testDir: __dirname,
  testIgnore: [],
  testMatch: ["shots.spec.ts", "candidates.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 300_000,
  webServer: {
    ...(base.webServer as object),
    command: `npm run dev -- --port ${port}`,
    url: `http://localhost:${port}/design/outline`,
    cwd: worktree,
    env: { ...((base.webServer as { env: Record<string, string> }).env), IS_WEBPACK_TEST: "1" },
  },
  use: { ...base.use, baseURL: `http://localhost:${port}` },
  projects: [{ name: "shots" }],
});

// Composes plan 16-06's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, title, text) => `<figure><img src="${img(n)}"><figcaption><b>${title}</b>${text}</figcaption></figure>`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 22px;font-size:16px;color:#4b5563;max-width:1450px;line-height:1.45}
h2{font-size:19px;margin:8px 36px 12px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px 24px;padding:0 36px 28px}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:10px 14px 12px;font-size:14px;line-height:1.4;border-top:1px solid #e5e1d6}
figcaption b{display:block;font-size:15px;margin-bottom:2px}
.phone{display:flex;gap:24px;align-items:flex-start;padding:0 36px 28px}.phone figure{width:330px;flex:none}
.msgs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px;padding:0 36px 36px}
.note{font-size:14px;line-height:1.5;color:#374151;max-width:560px;padding-top:6px}
</style></head><body>
<h1>Phase 16, plan 06: the real 3D screen, second look</h1>
<p class="lead">This is the app itself at /design/3d, not a mock-up. It's not in the menus yet; that comes next. Each board is a preset as its card opens it, built from the very cross-sections VOLUME adds up for the litres. It's raw white foam under the shaping room's fixed lights. After your first look: in the light themes it's lit by the two low rail tubes alone (no overhead, the least fill) on a darker ground (#aeaca5), and the dark themes are unchanged. A dark stringer runs down the middle. The board opens flat, deck up, nose to the left, seen from 50° above, and fills 85% of the window. There are no fins or blank yet; turning, zoom, views and export come in the next plans.</p>
<h2>The four presets, Daylight, 1280 × 800 (lighting C, ground #aeaca5)</h2>
<div class="grid">
${fig("daylight-fish", "Fish", "The swallow's two points, the stringer stopping at the crotch.")}
${fig("daylight-shortboard", "Shortboard", "Squash tail; the near rail catches the low tube along the bottom edge.")}
${fig("daylight-midlength", "Mid-length", "")}
${fig("daylight-longboard", "Longboard", "")}
</div>
<h2>The Fish in the other three themes</h2>
<div class="grid">
${fig("chalk-fish", "Chalk", "The same darker 3D ground as Daylight (#aeaca5), the same lights.")}
${fig("slate-fish", "Slate", "Unchanged from the first look: near-white foam on near-black, near-black stringer.")}
${fig("phosphor-fish", "Phosphor", "Unchanged from the first look: white foam on dark green, near-black stringer.")}
</div>
<div class="phone">
${fig("phone-fish", "iPhone 14, upright", "The board fills the drawing area above the panel.")}
<div class="note"><b>What to look at.</b><br>1. Does the foam read as foam, with the deck's dome showing under the side light as in the mock-up? The stringer runs down the middle; the Fish's tail is two pieces.<br>2. In Daylight and Chalk, are the shadows strong enough, and does the foam stand off the darker ground?<br>3. On the phone, the board fills the drawing area above the panel.<br>4. The three messages below read in plain English.</div>
</div>
<h2>When there's no board to draw</h2>
<div class="msgs">
${fig("message-no-webgl", "A browser with no 3D drawing", "")}
${fig("message-cant-build", "A board the 3D surface can't be built for", "Forced here with a 40\" board, which a saved board may hold but the app's 60\"–120\" range refuses.")}
${fig("message-didnt-load", "The 3D code didn't arrive", "Forced by blocking it, as if offline. The messages keep the lighter canvas grey, so their small second line stays readable.")}
</div>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.evaluate(() => document.fonts.ready);
  const out = process.argv[2];
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

// Scratch: runs e2e/prod/three-d.spec.ts against the worktree's DEV server on 3206, only to check the spec's own logic.
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/playwright.config";
import { defineConfig } from "@playwright/test";

const worktree = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a";
export default defineConfig({
  ...base,
  testDir: worktree + "/e2e/prod",
  testIgnore: [],
  testMatch: ["three-d.spec.ts"],
  outputDir: __dirname + "/test-results-prod",
  webServer: {
    ...(base.webServer as object),
    command: "npm run dev -- --port 3206",
    url: "http://localhost:3206/design/outline",
    cwd: worktree,
    env: { ...((base.webServer as { env: Record<string, string> }).env), IS_WEBPACK_TEST: "1" },
  },
  use: { ...base.use, baseURL: "http://localhost:3206" },
});

// Plan 16-06, the founder's second look: lighting candidates × ground tones, shot from the worktree's dev server.
// The lighting is picked by name through the dev-only `window.__shaper3dLighting`; the ground by an inline
// `--surf-3d-ground` on <html>, which outranks a theme block. Run: npx playwright test -c <abs>/pictures.config.ts candidates
import { expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/banner-dismissal";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/lib/theme";

const OUT = __dirname + "/cand";
const only = (process.env.SHOTS ?? "").split(",").filter(Boolean);

async function prepare(page: Page, preset: string, theme: string, lighting: string, ground: string | null) {
  const p = BOARD_PRESETS.find((b) => b.name === preset)!;
  const raw = openBoardCopyJson(
    { ...presetDesignFields(p), volume: DEFAULT_VOLUME_SPEC, finsImportTemplate: true, railsImportFoilThickness: true, boardName: "", finSystem: "fcs2" },
    { modelId: null, ownerId: null, locked: false, dirty: true },
  );
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey, themeId, light, groundHex]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, themeId);
      (window as unknown as { __shaper3dLighting: string }).__shaper3dLighting = light;
      // An inline value on <html> outranks every theme block, and React leaves an attribute it never set alone.
      // An init script runs before <html> exists, so the value goes on as soon as it appears.
      if (groundHex) {
        const apply = () => {
          if (!document.documentElement) return false;
          document.documentElement.style.setProperty("--surf-3d-ground", groundHex);
          return true;
        };
        if (!apply()) {
          new MutationObserver((_, observer) => {
            if (apply()) observer.disconnect();
          }).observe(document, { childList: true });
        }
      }
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY, theme, lighting, ground ?? ""] as const,
  );
}

const GROUNDS = { today: "#dfdcd3", t1: "#aeaca5", t2: "#9d9b95" } as const;
const shots: [string, string, string, string, keyof typeof GROUNDS | null][] = [];
for (const preset of ["Fish", "Shortboard"]) shots.push([`firstLook-today-${preset}`, preset, "daylight", "firstLook", "today"]);
for (const light of ["A", "B", "C"])
  for (const g of ["t1", "t2"] as const)
    for (const preset of ["Fish", "Shortboard"]) shots.push([`${light}-${g}-${preset}`, preset, "daylight", light, g]);
for (const light of ["firstLook", "A", "B", "C"]) shots.push([`${light}-slate-Fish`, "Fish", "slate", light, null]);

for (const [name, preset, theme, light, ground] of shots) {
  test(name, async ({ browser }) => {
    test.skip(only.length > 0 && !only.some((o) => name.includes(o)));
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
    const page = await context.newPage();
    await prepare(page, preset, theme, light, ground ? GROUNDS[ground] : null);
    await page.goto("/design/3d");
    const host = page.locator("[data-board-3d]");
    await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
    await page.waitForTimeout(600);
    await host.screenshot({ path: `${OUT}/${name}.png` });
    await context.close();
  });
}

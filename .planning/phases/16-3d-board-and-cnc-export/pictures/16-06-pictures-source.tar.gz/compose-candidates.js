// Composes the lighting × ground candidates into one captioned comparison. Usage: node compose-candidates.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/.claude/worktrees/agent-a2481cd7269a4c29a/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "cand");
const img = (n) => {
  const p = path.join(dir, `${n}.png`);
  return fs.existsSync(p) ? `<div class="cell" style="background-image:url(data:image/png;base64,${fs.readFileSync(p).toString("base64")})"></div>` : `<div class="cell empty"></div>`;
};
const ROWS = [
  ["firstLook", "Today (the first look)", "rail tubes 1.0 / 0.7, overhead 0.2, fill 0.2 (key 2.9). Shown on today's ground, #dfdcd3. Far-rail edge 29 levels under the ground.", ""],
  ["A", "A — overhead off", "rail tubes 1.0 / 0.7, overhead 0, fill 0.2. The deck lands at the ground's tone: the far-rail edge is only 5 levels off ground 1.", ""],
  ["B", "B — overhead off, fill lowered", "rail tubes 1.0 / 0.7, overhead 0, fill 0.08. Far edge 29 under ground 1, 12 under ground 2.", ""],
  ["C", "C — strongest shadowing (recommended, on ground 1)", "near tube 1.0, far tube 0.45, overhead 0, fill 0.04. This room has no floor bounce to lower, so the far tube was the other light on the shadow side. Far edge 64 under ground 1, near rail 56 over it; the dome runs 107 to 122.", ""],
];
const rows = ROWS.map(([id, title, levels, note]) => {
  const daylight =
    id === "firstLook"
      ? img(`${id}-today-Fish`) + img(`${id}-today-Shortboard`) + `<div class="cell blank"></div><div class="cell blank"></div>`
      : img(`${id}-t1-Fish`) + img(`${id}-t1-Shortboard`) + img(`${id}-t2-Fish`) + img(`${id}-t2-Shortboard`);
  return `<div class="label"><b>${title}</b>${levels}</div>${daylight}${img(`${id}-slate-Fish`)}`;
}).join("");
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:2000px}
h1{font-size:26px;margin:26px 30px 6px}p.lead{margin:0 30px 18px;font-size:16px;color:#4b5563;max-width:1900px;line-height:1.45}
.grid{display:grid;grid-template-columns:230px repeat(5,minmax(0,1fr));gap:10px;padding:0 30px 30px;align-items:start}
.head{font-size:14px;font-weight:700;padding:4px 2px}.head span{display:block;font-weight:400;color:#4b5563}
.label{font-size:13px;line-height:1.4;color:#374151;padding-top:6px}.label b{display:block;font-size:15px;color:#1f2a37;margin-bottom:4px}
.cell{aspect-ratio:724/230;background-size:112% auto;background-position:50% 47%;border:1px solid #d8d2c4;border-radius:6px}
.cell.blank{background:none;border:none}.cell.empty{background:#fafafa;display:flex;align-items:center;justify-content:center;font-size:13px;color:#6b7280;padding:8px;text-align:center}
</style></head><body>
<h1>The 3D board, second look: lighting and ground candidates</h1>
<p class="lead">You asked for stronger shadowing, perhaps side lights only, and a darker ground behind the board in the light themes, with the dark themes left as they are. Each row is one lighting setting and each column a board on a ground. The lights are shared by every theme, so the last column shows the Fish in Slate under the same row's lights. Fish and Shortboard as their cards open them, in Daylight (Chalk is the same ground and draws the same), shot from the app at 1280 × 800 and cropped to the board.</p>
<div class="grid">
<div></div>
<div class="head">Fish<span>ground 1: #aeaca5 (22% darker)</span></div>
<div class="head">Shortboard<span>ground 1: #aeaca5</span></div>
<div class="head">Fish<span>ground 2: #9d9b95 (a further 10% darker)</span></div>
<div class="head">Shortboard<span>ground 2: #9d9b95</span></div>
<div class="head">Fish in Slate<span>ground #1a1d25 (unchanged)</span></div>
${rows}
</div>
<p class="lead"><b>Recommended: C on ground 1 (#aeaca5) in Daylight and Chalk, with Slate and Phosphor keeping today's lights.</b> C shows the deck's dome most strongly while the stringer stays clear (77 on a deck of 112), and on ground 1 both edges read: the far rail well under the ground, the near rail well over it. Ground 2 brightens the near-rail edge further but brings the far edge closer to the ground. The lights are shared by every theme, so the last column shows what each row would do to Slate: under B and C the dark-theme deck goes from about 180 to 130 and 100. You liked the dark themes as they are, so the recommendation keeps them on today's lights, which the theme's own light-or-dark setting picks. Their column then stays exactly as the top row shows it.</p>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose-candidates.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 2000, height: 400 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose-candidates.html"));
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: process.argv[2], fullPage: true });
  console.log("wrote", process.argv[2]);
  await browser.close();
})();

// Plan 16-17's tables for the SUMMARY: every preset's fins (before from the pin, after from the app), the keel at 4.5"
// and 6.5", what the twin defaults move, and the wire view's counts. Run from the worktree:
//   npx --no-install tsx --tsconfig ./tsconfig.json <abs>/table.ts <worktree> <abs out dir>
import { readFileSync, writeFileSync } from "node:fs";

const root = process.argv[2];
const out = process.argv[3];
(async () => {
  const { phase16FinCases, finMeasures } = await import(`${root}/lib/geometry/__fixtures__/phase16-fin-cases`);
  const O = await import(`${root}/lib/geometry/fin-outline`);
  const F = await import(`${root}/lib/geometry/fins`);
  const S = await import(`${root}/lib/geometry/board-surface`);
  const D = await import(`${root}/lib/geometry/design`);
  const { buildOutline } = await import(`${root}/lib/geometry/outline`);
  const { recordedPresetDesignFields } = await import(`${root}/lib/geometry/__fixtures__/phase14-preset-blanks`);
  const { BOARD_PRESETS } = await import(`${root}/lib/geometry/presets`);
  const { mmToInches, inchesToMm, mm } = await import(`${root}/lib/geometry/units`);
  const pin = JSON.parse(readFileSync(`${root}/lib/geometry/__fixtures__/phase16-fin-pin.json`, "utf8")).fins;
  const inch = (x: number) => mmToInches(x);
  const n2 = (x: number) => inch(x).toFixed(2);
  const depthOf = (x: number) => String(+inch(x).toFixed(3));
  const area = (x: number) => (x / inchesToMm(1) / inchesToMm(1)).toFixed(1);
  const lines: string[] = [];
  const facts: Record<string, unknown> = {};

  lines.push("### Every preset's fins, today and after", "");
  lines.push("A pair is listed once. \"Behind\" is measured from the trailing dot on the board. Today's figures are the pin's; after is the app's, at FINS' new defaults.", "");
  lines.push("| Board and setup | Fin | Shape | FINS' base | Root | Depth today → after | Area today → after (in²) | Sweep today → after | Tip behind today → after | Rearmost behind after |");
  lines.push("|---|---|---|---|---|---|---|---|---|---|");
  for (const c of phase16FinCases()) {
    const fins = O.placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, c.preset.outline.length, c.rockerAt);
    const [, caseName] = c.label.split("|");
    const seen = new Set<string>();
    fins.forEach((fin: any, i: number) => {
      const key = `${c.marks[i].role}|${fin.role}`;
      if (seen.has(key)) return;
      seen.add(key);
      const p = pin[`${c.label}|${i}`];
      const m = finMeasures(fin.outline);
      const offset = fin.outline.footprint; // from the root's front to the trailing dot
      lines.push(
        `| ${c.preset.name} ${caseName} | ${c.marks[i].role} | ${fin.outline.template} | ${n2(c.marks[i].baseLength)}" | ${n2(fin.outline.base)}" | ${depthOf(p.depth)}" → ${depthOf(fin.outline.depth)}" | ${area(p.area)} → ${area(m.area)} | ${p.sweepDeg.toFixed(1)}° → ${m.sweepDeg.toFixed(1)}° | ${n2(p.top.u - p.base)}" → ${n2(m.top.u - offset)}" | ${n2(m.rearmost.u - offset)}" |`,
      );
      facts[`${c.label}|${c.marks[i].role}`] = { depthBefore: depthOf(p.depth), depthAfter: depthOf(fin.outline.depth), base: depthOf(fin.outline.base) };
    });
  }

  lines.push("", "### The keel at 4.5\" and 6.5\" (FINS' base, the whole footprint)", "");
  lines.push("| FINS' base | Root | Area | Sweep | Highest point behind the trailing dot | Rearmost behind it | Cut-away length | Gap at 1/4\" · 1/2\" · 1\" · 1 1/2\" · 2\" behind the root's end | Nearest the body comes to the bottom, away from the root, Shortboard · Fish · Mid-length · Longboard |");
  lines.push("|---|---|---|---|---|---|---|---|---|");
  for (const baseIn of [4.5, 6.5]) {
    const clear: string[] = [];
    let row = "";
    for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
      const c = phase16FinCases().find((x: any) => x.label === `${id}|twin/keel`);
      const marks = c.marks.map((m: any) => ({ ...m, baseLength: inchesToMm(baseIn), leadingOffTail: mm(m.offTail + inchesToMm(baseIn)) }));
      const fins = O.placedFins(marks, "twin", "keel", c.preset.outline.length, c.rockerAt);
      let least = Infinity;
      for (const fin of fins) {
        const { outline } = fin;
        const slope = Math.tan(fin.tiltRad);
        const run = Math.hypot(fin.trailing[0] - fin.leading[0], fin.trailing[1] - fin.leading[1]);
        const along = (fin.trailing[0] - fin.leading[0]) / run;
        const uLen = Math.hypot(along, (fin.trailing[1] - fin.leading[1]) / run, slope * along);
        const u = { x: along / uLen, z: (slope * along) / uLen };
        const vL = Math.hypot(slope, 1);
        const v = { x: slope / vL, z: -1 / vL };
        const o = { x: (fin.leading[0] + fin.trailing[0]) / 2 - (u.x * outline.base) / 2, z: fin.rootZ - (u.z * outline.base) / 2 };
        // Past the first quarter inch behind the root's end, where the cut-away has left the root's line.
        for (const q of outline.points.filter((p: any) => p.u > outline.base + inchesToMm(0.25))) {
          const x = o.x + q.u * u.x + q.v * v.x;
          const z = o.z + q.u * u.z + q.v * v.z;
          least = Math.min(least, c.rockerAt(mm(x)) - z);
        }
      }
      clear.push(`${n2(least)}"`);
      if (id === "fish") {
        const fin = fins[0];
        const { outline } = fin;
        const m = finMeasures(outline);
        const cut = outline.points.slice(3 * (O.FIN_CUBIC_SAMPLES - 1));
        const gap = (d: number) => {
          const at = outline.base + inchesToMm(d);
          if (at > outline.footprint) return "past the heel";
          for (let i = 0; i + 1 < cut.length; i++) {
            const [a, b] = [cut[i], cut[i + 1]];
            if ((a.u - at) * (b.u - at) <= 0) return `${n2(a.v + ((b.v - a.v) * (at - a.u)) / (b.u - a.u))}"`;
          }
          return "?";
        };
        row = `| ${baseIn}" | ${n2(outline.base)}" | ${area(m.area)} in² | ${m.sweepDeg.toFixed(1)}° | ${n2(m.top.u - outline.footprint)}" | ${n2(m.rearmost.u - outline.footprint)}" | ${n2(outline.footprint - outline.base)}" | ${[0.25, 0.5, 1, 1.5, 2].map(gap).join(" · ")} |`;
        facts[`keel${baseIn}`] = { root: n2(outline.base), gap2: gap(2) };
      }
    }
    lines.push(`${row} ${clear.join(" · ")} |`);
  }

  lines.push("", "### What the twin defaults move (every preset, FINS' Reset)", "");
  lines.push("| Board | Twin template | Base today → after | Leading dot off the tail today → after | Trailing dot off the tail | Off-rail and toe |");
  lines.push("|---|---|---|---|---|---|");
  for (const c of phase16FinCases().filter((x: any) => x.label.includes("|twin/"))) {
    const fin = O.placedFins(c.marks, "twin", c.spec.twinTemplate, c.preset.outline.length, c.rockerAt);
    const i = c.marks.findIndex((m: any) => m.role !== "center");
    const m = c.marks[i];
    const p = pin[`${c.label}|${i}`];
    lines.push(
      `| ${c.preset.name} | ${c.spec.twinTemplate} | ${n2(p.base)}" → ${n2(m.baseLength)}" | ${n2(p.leading[0])}" → ${n2(m.leadingOffTail)}" | ${n2(m.offTail)}" (unchanged${m.offTail === p.trailing[0] ? "" : " — CHECK"}) | ${m.lateral === p.trailing[1] && m.leadingLateral === p.leading[1] ? "unchanged" : "CHECK"} |`,
    );
    void fin;
  }

  lines.push("", "### The wire view's counts, per preset", "");
  lines.push("| Board | Length × width | Rings | Long lines on the deck | On the bottom | Ring loops drawn (a swallow's two pieces count twice) | Outline loop points | Line segments |");
  lines.push("|---|---|---|---|---|---|---|---|");
  for (const p of BOARD_PRESETS) {
    const fields = recordedPresetDesignFields(p);
    const geometry = buildOutline(fields.outline);
    const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
    const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
    const sections = D.designCrossSectionInput(geometry, profile, rails, fields.outline.length);
    const surface = S.buildBoardSurface({ sections, geometry, rockerAt: profile.rockerAt });
    const wire = S.wireLines(surface);
    lines.push(
      `| ${p.name} | ${inch(surface.length).toFixed(1)}" × ${inch(surface.width).toFixed(2)}" | ${wire.ringStations.length} | ${wire.deck.length} | ${wire.bottom.length} | ${wire.rings.length} | ${wire.outline.length} | ${S.wireSegments(wire).length / 6} |`,
    );
  }
  writeFileSync(`${out}/table.md`, `${lines.join("\n")}\n`);
  writeFileSync(`${out}/facts.json`, JSON.stringify(facts, null, 1));
  void F;
  console.log(lines.length, "lines");
})();

// Plan 16-17's pictures for the founder: the real 3D screen, before (the plan's Task 1 commit) and after. Run with
// PIC_MODE=before or after; compose.js lays them out.
import { mkdirSync, writeFileSync } from "node:fs";
import { devices, expect, test, type Browser, type Locator, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/blanks/preset-blanks";
import { resetAdvanced, type FinSetup, type TwinTemplate } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/geometry/presets";
import { inchesToMm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/lib/theme";
import { countDifferent, decodePng } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/e2e/helpers/canvas-pixels";

const AFTER = process.env.PIC_MODE !== "before";
const MODE = AFTER ? "after" : "before";
const OUT = `${__dirname}/out/${MODE}`;
mkdirSync(OUT, { recursive: true });

interface Case {
  name: string;
  preset: string;
  setup?: FinSetup;
  twin?: TwinTemplate;
  keelBaseIn?: number;
  handSet?: boolean;
  theme?: string;
}

const CASES: Case[] = [
  { name: "longboard", preset: "Longboard" },
  { name: "midlength-2plus1", preset: "Mid-length", setup: "2plus1" },
  { name: "fish", preset: "Fish" },
  { name: "fish-keel", preset: "Fish", setup: "twin", twin: "keel" },
  { name: "fish-trailer", preset: "Fish", setup: "twin", twin: "trailer" },
  { name: "shortboard", preset: "Shortboard" },
  { name: "midlength", preset: "Mid-length" },
  { name: "shortboard-quad", preset: "Shortboard", setup: "quad" },
];

function fields(c: Case): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === c.preset);
  if (!preset) throw new Error(`no ${c.preset}`);
  const base = presetDesignFields(preset);
  const twin = c.twin ?? base.fins.twinTemplate;
  let fins = base.fins;
  if (c.setup) {
    const advanced = resetAdvanced(c.setup, twin);
    fins = {
      ...base.fins,
      finSetup: c.setup,
      twinTemplate: twin,
      // The code before this plan reset every forward base to 4.5".
      advanced: AFTER ? advanced : { ...advanced, baseLenForward: inchesToMm(4.5) },
    };
  }
  if (c.keelBaseIn !== undefined) {
    fins = { ...fins, advanced: { ...fins.advanced, baseLenForward: inchesToMm(c.keelBaseIn), baseLenForwardOverridden: true } };
  }
  return {
    ...base,
    ...(c.handSet ? { blank: null } : {}),
    fins,
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page, c: Case) {
  const raw = openBoardCopyJson(fields(c), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey, theme]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, theme);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY, c.theme ?? "daylight"] as const,
  );
}

async function ready(page: Page) {
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForFunction(() => {
    const el = document.querySelector("[data-viewer-zoom] button, [data-viewer-toolbar] button");
    return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
  });
  await page.waitForTimeout(1200);
  return host;
}

const HIDE_CHROME = "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }";

async function shot(host: Locator) {
  await host.page().waitForTimeout(1200);
  return host.screenshot({ scale: "css", style: HIDE_CHROME });
}

async function pressFins(page: Page) {
  if (AFTER) await page.locator("[data-viewer-toolbar]").getByRole("button", { name: THREE_D_COPY.fins, exact: true }).click();
  else await page.getByRole("checkbox", { name: THREE_D_COPY.fins, exact: true }).click();
  await page.mouse.move(2, 2);
}

/** Where the fins are on the canvas: the box of pixels that change when Fins goes off. */
async function finsBoxOn(page: Page, host: Locator) {
  const on = decodePng(await shot(host));
  await pressFins(page);
  const off = decodePng(await shot(host));
  await pressFins(page);
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (let y = 0; y < on.height; y++) {
    for (let x = 0; x < on.width; x++) {
      const i = 4 * (y * on.width + x);
      if ([0, 1, 2].every((k) => Math.abs(on.rgba[i + k] - off.rgba[i + k]) <= 2)) continue;
      left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
    }
  }
  expect(countDifferent(on.rgba, off.rgba, 2)).toBeGreaterThan(0);
  return { left, right, top, bottom };
}

async function view(page: Page, name: "bottom" | "side" | "nose" | "tail" | "deck") {
  await page.getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true }).getByRole("button", {
    name: THREE_D_COPY.views[name],
    exact: true,
  }).click();
  await page.waitForTimeout(1500);
}

/** The fins and a margin round them, widened to 4:3, inside the canvas (CSS dots). */
function frameAround(b: { left: number; right: number; top: number; bottom: number }, w: number, h: number, share = 0.3) {
  const size = Math.max(b.right - b.left, b.bottom - b.top);
  const m = Math.max(40, size * share);
  let left = b.left - m, right = b.right + m, top = b.top - m * 1.6, bottom = b.bottom + m;
  const cw = right - left, ch = bottom - top;
  if (cw / ch < 4 / 3) { const d = (ch * 4) / 3 - cw; left -= d / 2; right += d / 2; }
  else { const d = (cw * 3) / 4 - ch; top -= d / 2; bottom += d / 2; }
  const shiftX = Math.max(0, -left) - Math.max(0, right - w);
  const shiftY = Math.max(0, -top) - Math.max(0, bottom - h);
  left += shiftX; right += shiftX; top += shiftY; bottom += shiftY;
  left = Math.max(0, left); top = Math.max(0, top); right = Math.min(w, right); bottom = Math.min(h, bottom);
  return { x: left, y: top, width: right - left, height: bottom - top };
}

async function quarter(page: Page, host: Locator) {
  // From the Side view, turned three key steps (45°) so the bottom and the fins are seen from below and aside.
  await view(page, "side");
  await host.focus();
  for (let i = 0; i < 3; i++) await page.keyboard.press("ArrowUp");
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  await page.waitForTimeout(1500);
}

async function finShots(page: Page, host: Locator, name: string, views: readonly ("bottom" | "side" | "quarter")[], share = 0.3) {
  for (const v of views) {
    if (v === "quarter") await quarter(page, host);
    else await view(page, v);
    const b = await finsBoxOn(page, host);
    const hb = (await host.boundingBox())!;
    const f = frameAround(b, hb.width, hb.height, share);
    await page.waitForTimeout(1200);
    writeFileSync(
      `${OUT}/${name}-${v}.png`,
      await page.screenshot({ clip: { x: hb.x + f.x, y: hb.y + f.y, width: f.width, height: f.height }, style: HIDE_CHROME }),
    );
  }
}

for (const c of CASES) {
  test(`fins-${c.name}`, async ({ page }) => {
    await prepare(page, c);
    await page.goto("/design/3d");
    const host = await ready(page);
    await finShots(page, host, c.name, ["bottom", "side", "quarter"]);
  });
}

// The keel from below and aside, close: before at 4.5" (today's outline), after at 6.5" (Reset) and at 4.5" (set on FINS).
const KEELS: Case[] = AFTER
  ? [
      { name: "keel-65", preset: "Fish", setup: "twin", twin: "keel" },
      { name: "keel-45", preset: "Fish", setup: "twin", twin: "keel", keelBaseIn: 4.5 },
    ]
  : [{ name: "keel-45", preset: "Fish", setup: "twin", twin: "keel" }];

for (const c of KEELS) {
  test(`keel-${c.name}`, async ({ page }) => {
    await prepare(page, c);
    await page.goto("/design/3d");
    const host = await ready(page);
    await finShots(page, host, c.name, ["quarter", "side"], 0.06);
  });
}

test("quad-close", async ({ page }) => {
  const c = CASES.find((x) => x.name === "midlength")!;
  await prepare(page, c);
  await page.goto("/design/3d");
  const host = await ready(page);
  await finShots(page, host, "quad-close", ["side"], 0.06);
});

const shell = { width: 1280, height: 800 };

async function corner(page: Page, name: string) {
  return page.locator("[data-viewer-toolbar]").getByRole("button", { name, exact: true });
}

/** The canvas's top right, where the corner row and the zoom row sit. */
async function cornerShot(page: Page, file: string, width = 260, height = 120) {
  const hb = (await page.locator("[data-board-3d]").boundingBox())!;
  await page.waitForTimeout(800);
  writeFileSync(file, await page.screenshot({ clip: { x: hb.x + hb.width - width, y: hb.y, width, height } }));
}

test("panel", async ({ page }) => {
  await page.setViewportSize(shell);
  await page.addInitScript(
    ([bannerKey, tipKey, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, THEME_STORAGE_KEY] as const,
  );
  await page.goto("/design/3d");
  await ready(page);
  await page.screenshot({ path: `${OUT}/panel-page.png` });
});

test("corners", async ({ page }) => {
  test.skip(!AFTER);
  await page.setViewportSize(shell);
  // The Fish, which sits in a blank: the stock board opened fresh has none to press Blank for.
  await prepare(page, { name: "corners", preset: "Fish" });
  await page.goto("/design/3d");
  await ready(page);
  for (const [name, label] of [
    ["fins-off", THREE_D_COPY.fins],
    ["blank-on", THREE_D_COPY.blank],
    ["stripes-on", THREE_D_COPY.contourStripes],
    ["wire-on", THREE_D_COPY.wireView],
  ] as const) {
    const button = await corner(page, label);
    await button.click();
    await page.mouse.move(2, 2);
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${OUT}/corner-${name}.png` });
    await button.click();
    await page.mouse.move(2, 2);
  }
});

test("hand-set", async ({ page }) => {
  test.skip(!AFTER);
  await page.setViewportSize(shell);
  await prepare(page, { name: "hs", preset: "Fish", handSet: true });
  await page.goto("/design/3d");
  await ready(page);
  await (await corner(page, THREE_D_COPY.blank)).hover();
  await cornerShot(page, `${OUT}/corner-handset.png`);
});

async function phone(browser: Browser, name: string, width: number, height: number, zoom = false) {
  const context = await browser.newContext({
    ...devices["iPhone 14"],
    defaultBrowserType: undefined,
    viewport: { width, height },
    baseURL: test.info().project.use.baseURL,
  } as never);
  const page = await context.newPage();
  await prepare(page, { name, preset: "Fish" });
  await page.goto("/design/3d");
  const host = await ready(page);
  if (zoom) {
    await host.focus();
    await page.keyboard.press("+");
    await page.keyboard.press("+");
    await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
    await page.waitForTimeout(1200);
  }
  await page.screenshot({ path: `${OUT}/phone-${name}.png` });
  await context.close();
}

test("phones", async ({ browser }) => {
  test.skip(!AFTER);
  await phone(browser, "iphone14", 390, 664);
  await phone(browser, "phone320", 320, 568);
  await phone(browser, "sideways", 844, 390);
  await phone(browser, "zoomed", 390, 664, true);
});

test("phone-wire", async ({ browser }) => {
  test.skip(!AFTER);
  const context = await browser.newContext({
    ...devices["iPhone 14"],
    defaultBrowserType: undefined,
    viewport: { width: 390, height: 664 },
    baseURL: test.info().project.use.baseURL,
  } as never);
  const page = await context.newPage();
  await prepare(page, { name: "wire", preset: "Fish" });
  await page.goto("/design/3d");
  await ready(page);
  await (await corner(page, THREE_D_COPY.wireView)).click();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/phone-wire.png` });
  await context.close();
});

// The corner table: the row, the zoom row and the board's nearest dot, on six screens, four presets, six views.
const SCREENS: { name: string; width: number; height: number; touch: boolean }[] = [
  { name: "1280 × 800", width: 1280, height: 800, touch: false },
  { name: "820 × 800", width: 820, height: 800, touch: false },
  { name: "Pixel 7, 412 × 839", width: 412, height: 839, touch: true },
  { name: "iPhone 14, 390 × 664", width: 390, height: 664, touch: true },
  { name: "320 × 568", width: 320, height: 568, touch: true },
  { name: "sideways iPhone, 844 × 390", width: 844, height: 390, touch: true },
];

for (const screen of SCREENS) {
  test(`measure ${screen.name}`, async ({ browser }) => {
    test.skip(!AFTER);
    const rows: string[] = [];
    let nearest = Infinity;
    let under = 0;
    let line = "";
    for (const preset of ["Shortboard", "Fish", "Mid-length", "Longboard"]) {
      const context = await browser.newContext({
        ...(screen.touch ? devices["iPhone 14"] : devices["Desktop Chrome"]),
        defaultBrowserType: undefined,
        viewport: { width: screen.width, height: screen.height },
        deviceScaleFactor: 1,
        baseURL: test.info().project.use.baseURL,
      } as never);
      const page = await context.newPage();
      await prepare(page, { name: "m", preset });
      await page.goto("/design/3d");
      const host = await ready(page);
      for (const v of [null, "deck", "bottom", "side", "nose", "tail"] as const) {
        if (v) await view(page, v);
        const canvas = (await host.boundingBox())!;
        const row = (await page.locator("[data-viewer-toolbar]").boundingBox())!;
        const zoom = await page.locator("[data-viewer-zoom]").boundingBox();
        const pic = decodePng(await shot(host));
        const g = 4 * ((pic.height - 12) * pic.width + 12);
        const ground = [pic.rgba[g], pic.rgba[g + 1], pic.rgba[g + 2]];
        const inRow = (x: number, y: number, b: { x: number; y: number; width: number; height: number }) =>
          x >= b.x - canvas.x && x < b.x - canvas.x + b.width && y >= b.y - canvas.y && y < b.y - canvas.y + b.height;
        for (let y = 0; y < pic.height; y++) {
          for (let x = 0; x < pic.width; x++) {
            if ((x < 8 || x >= pic.width - 8) && (y < 8 || y >= pic.height - 8)) continue;
            const i = 4 * (y * pic.width + x);
            if (![0, 1, 2].some((k) => Math.abs(pic.rgba[i + k] - ground[k]) > 12)) continue;
            nearest = Math.min(nearest, y);
            if (inRow(x, y, row) || (zoom && inRow(x, y, zoom))) under += 1;
          }
        }
        line = `| ${screen.name} | ${Math.round(canvas.width)} × ${Math.round(canvas.height)} | ${Math.round(row.width)} × ${Math.round(row.height)}, ${await page.locator("[data-viewer-toolbar] button:visible").count()} icons | ${zoom ? `${Math.round(zoom.width)} × ${Math.round(zoom.height)} at ${Math.round(zoom.y - canvas.y)}` : "hidden at 1x"} |`;
      }
      await context.close();
    }
    rows.push(`${line} ${nearest} | ${under} |`);
    writeFileSync(`${OUT}/measure-${screen.width}.txt`, rows.join("\n") + "\n");
  });
}

// ---- The wire view (D-42): end-on and three-quarter, as his Shape3D picture.

async function wireOn(page: Page) {
  await (await corner(page, THREE_D_COPY.wireView)).click();
  await page.mouse.move(2, 2);
  await page.waitForTimeout(800);
}

/** End-on: the Nose view tipped down a little, so the deck and the nose read as in his top picture. */
async function endOn(page: Page, host: Locator) {
  await view(page, "nose");
  // A short drag, finer than a key's 15°: the board nearly edge-on, a little of the deck showing.
  const box = (await host.boundingBox())!;
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.down();
  for (let i = 1; i <= 6; i++) await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2 + 3 * i);
  await page.waitForTimeout(300);
  await page.mouse.up();
  // Wide view and back: a new canvas size frames the whole board again at this turn, tail included.
  await page.getByRole("button", { name: "Hide the sidebar for a wider view", exact: true }).click();
  await page.waitForTimeout(600);
  await page.getByRole("button", { name: "Show the sidebar", exact: true }).click();
  await page.mouse.move(2, 2);
  await page.waitForTimeout(1200);
}

/** Three-quarter: the Deck view turned and tipped, as his lower picture. */
async function threeQuarter(page: Page, host: Locator) {
  await view(page, "deck");
  await host.focus();
  await page.keyboard.press("ArrowLeft");
  await page.keyboard.press("ArrowDown");
  await page.keyboard.press("ArrowDown");
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  await page.waitForTimeout(1200);
}

for (const [name, preset, theme] of [
  ["fish", "Fish", "daylight"],
  ["longboard", "Longboard", "daylight"],
  ["shortboard", "Shortboard", "daylight"],
  ["fish-slate", "Fish", "slate"],
  ["fish-phosphor", "Fish", "phosphor"],
] as const) {
  test(`wire-${name}`, async ({ page }) => {
    test.skip(!AFTER);
    await prepare(page, { name, preset, theme });
    await page.goto("/design/3d");
    const host = await ready(page);
    await wireOn(page);
    await endOn(page, host);
    writeFileSync(`${OUT}/wire-${name}-end.png`, await shot(host));
    await threeQuarter(page, host);
    writeFileSync(`${OUT}/wire-${name}-quarter.png`, await shot(host));
    await view(page, "bottom");
    writeFileSync(`${OUT}/wire-${name}-bottom.png`, await shot(host));
  });
}

// The same board on a white page, for his call only: the token changed in this picture, nothing built.
test("wire-white", async ({ page }) => {
  test.skip(!AFTER);
  await prepare(page, { name: "white", preset: "Fish" });
  await page.goto("/design/3d");
  const host = await ready(page);
  await page.evaluate(() => {
    document.documentElement.style.setProperty("--surf-3d-ground", "#ffffff");
    document.documentElement.classList.add("picture-white");
  });
  await wireOn(page);
  await endOn(page, host);
  writeFileSync(`${OUT}/wire-white-end.png`, await shot(host));
  await threeQuarter(page, host);
  writeFileSync(`${OUT}/wire-white-quarter.png`, await shot(host));
  await view(page, "bottom");
  writeFileSync(`${OUT}/wire-white-bottom.png`, await shot(host));
});

// The stock board with its fins off, before and after: its own pixels must not move at all.
test("board-alone", async ({ page }) => {
  await page.setViewportSize(shell);
  await page.addInitScript(
    ([bannerKey, tipKey, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, THEME_STORAGE_KEY] as const,
  );
  await page.goto("/design/3d");
  const host = await ready(page);
  await pressFins(page);
  writeFileSync(`${OUT}/board-alone.png`, await shot(host));
});

// What is the dark dot on the deck in the stock board's first view? Zoomed hard at it, fins on.
test("speck", async ({ page }) => {
  await page.setViewportSize(shell);
  await page.addInitScript(
    ([bannerKey, tipKey, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, THEME_STORAGE_KEY] as const,
  );
  await page.goto("/design/3d");
  const host = await ready(page);
  const box = (await host.boundingBox())!;
  await page.mouse.move(1064, 416);
  for (let i = 0; i < 18; i++) {
    await page.mouse.wheel(0, -100);
    await page.waitForTimeout(250);
  }
  await page.mouse.move(2, 2);
  await page.waitForTimeout(1500);
  console.log("box", JSON.stringify(box), await host.getAttribute("data-crop"));
  writeFileSync(`${OUT}/speck-on.png`, await shot(host));
  await pressFins(page);
  writeFileSync(`${OUT}/speck-off.png`, await shot(host));
});

test("gpu-dot", async ({ page }) => {
  await page.setViewportSize(shell);
  await page.addInitScript(
    ([bannerKey, tipKey, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, THEME_STORAGE_KEY] as const,
  );
  await page.goto("/design/3d");
  await ready(page);
  const renderer = await page.evaluate(() => {
    const gl = document.createElement("canvas").getContext("webgl2");
    const info = gl?.getExtension("WEBGL_debug_renderer_info");
    return info ? gl?.getParameter(info.UNMASKED_RENDERER_WEBGL) : "unknown";
  });
  console.log("RENDERER", renderer);
  const png = decodePng(await page.screenshot({ clip: { x: 1054, y: 406, width: 22, height: 22 } }));
  const rows: string[] = [];
  for (let y = 0; y < png.height; y += 1) {
    rows.push(Array.from({ length: png.width }, (_, x) => String(png.rgba[4 * (y * png.width + x)]).padStart(3)).join(" "));
  }
  console.log(rows.join("\n"));
  await page.screenshot({ path: `${OUT}/gpu-dot.png` });
});

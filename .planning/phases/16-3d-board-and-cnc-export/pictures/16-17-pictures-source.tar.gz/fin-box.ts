// The fin's changed pixels between two 3D desktop pictures.
//   npx --no-install tsx --tsconfig ./tsconfig.json <abs>/fin-box.ts <worktree> <old png>
import { readFileSync } from "node:fs";

const [root, old] = process.argv.slice(2);
(async () => {
  const { decodePng } = await import(`${root}/e2e/helpers/canvas-pixels`);
  const a = decodePng(readFileSync(old));
  const b = decodePng(readFileSync(`${root}/e2e/desktop-baseline.spec.ts-snapshots/three-d-desktop-desktop-darwin.png`));
  let [l, r, t, u, n] = [Infinity, -Infinity, Infinity, -Infinity, 0];
  for (let y = 420; y < 600; y++) {
    for (let x = 400; x < a.width; x++) {
      const i = 4 * (y * a.width + x);
      if ([0, 1, 2, 3].every((k) => a.rgba[i + k] === b.rgba[i + k])) continue;
      l = Math.min(l, x); r = Math.max(r, x); t = Math.min(t, y); u = Math.max(u, y); n++;
    }
  }
  console.log({ l, r, t, u, n });
})();

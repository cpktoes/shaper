// Where the 3D desktop picture changed. Run from the worktree:
//   npx --no-install tsx --tsconfig ./tsconfig.json <abs>/diff.ts <worktree>
import { readFileSync } from "node:fs";

const root = process.argv[2];
(async () => {
  const { decodePng } = await import(`${root}/e2e/helpers/canvas-pixels`);
  const dir = `${root}/test-results/desktop-baseline-desktop-baseline-screenshots-3D-design-3d--desktop`;
  const a = decodePng(readFileSync(`${dir}/three-d-desktop-expected.png`));
  const b = decodePng(readFileSync(`${dir}/three-d-desktop-actual.png`));
  console.log("size", a.width, a.height, b.width, b.height);
  const box = () => ({ left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity, n: 0 });
  const add = (r: ReturnType<typeof box>, x: number, y: number) => {
    r.left = Math.min(r.left, x); r.right = Math.max(r.right, x); r.top = Math.min(r.top, y); r.bottom = Math.max(r.bottom, y); r.n++;
  };
  const panel = box();
  const canvas = box();
  for (let y = 0; y < a.height; y++) {
    for (let x = 0; x < a.width; x++) {
      const i = 4 * (y * a.width + x);
      if ([0, 1, 2, 3].every((k) => a.rgba[i + k] === b.rgba[i + k])) continue;
      add(x < 400 ? panel : canvas, x, y);
    }
  }
  console.log("panel", panel, "\nright of the panel", canvas);
  const outside = box();
  const low = box();
  const high: number[][] = [];
  for (let y = 0; y < a.height; y++) {
    for (let x = 400; x < a.width; x++) {
      const i = 4 * (y * a.width + x);
      if ([0, 1, 2, 3].every((k) => a.rgba[i + k] === b.rgba[i + k])) continue;
      if (y >= 147 && y < 181 && x >= 1048 && x < 1208) continue; // the corner row, left of Wide view
      add(outside, x, y);
      if (y < 300) high.push([x, y, a.rgba[i], a.rgba[i + 1], a.rgba[i + 2], b.rgba[i], b.rgba[i + 1], b.rgba[i + 2]]);
      else add(low, x, y);
    }
  }
  console.log("outside the corner row", outside, "\nthe fin's part", low, "\nhigh up", high.length, JSON.stringify(high.slice(0, 12)));
  const x17 = process.argv[3];
  const before = decodePng(readFileSync(`${x17}/out/before/board-alone.png`));
  const after = decodePng(readFileSync(`${x17}/out/after/board-alone.png`));
  let moved = 0;
  for (let i = 0; i < before.rgba.length; i++) if (before.rgba[i] !== after.rgba[i]) moved++;
  console.log("stock board with its fins off, before against after: channels differing", moved, "of", before.rgba.length);
})();

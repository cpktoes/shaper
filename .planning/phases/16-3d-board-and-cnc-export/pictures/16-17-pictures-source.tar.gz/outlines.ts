// Plan 16-17's outlines picture: every role's fin flat on a 1" grid, today dashed and after solid, at FINS' figures with
// the new defaults; the keel twice with FINS' two dots. Run from the worktree:
//   npx --no-install tsx --tsconfig ./tsconfig.json <abs>/outlines.ts <worktree> <abs before code> <abs out.png>
import { chromium } from "playwright";

const [root, before, png] = process.argv.slice(2);
(async () => {
  const { phase16FinCases } = await import(`${root}/lib/geometry/__fixtures__/phase16-fin-cases`);
  const New = await import(`${root}/lib/geometry/fin-outline`);
  const Old = await import(`${before}/lib/geometry/fin-outline`);
  const { mmToInches, inchesToMm, mm } = await import(`${root}/lib/geometry/units`);
  const inch = (x: number) => mmToInches(x);
  const PX = 26;
  const W = 14 * PX;
  const panels: string[] = [];
  const panel = (title: string, sub: string, fresh: any, today: any, dots?: number[]) => {
    const H = Math.ceil(inch(fresh.outline.depth) + 1.2) * PX;
    const ox = 0.8 * PX;
    const oy = H - 0.5 * PX;
    const path = (pts: { u: number; v: number }[]) =>
      "M" + pts.map((q) => `${(ox + inch(q.u) * PX).toFixed(1)},${(oy - inch(q.v) * PX).toFixed(1)}`).join(" L") + " Z";
    const grid =
      Array.from({ length: 15 }, (_, k) => `<line x1="${ox + k * PX}" y1="0" x2="${ox + k * PX}" y2="${H}" stroke="#e8e4da"/>`).join("") +
      Array.from({ length: 12 }, (_, k) => `<line x1="0" y1="${oy - k * PX}" x2="${W}" y2="${oy - k * PX}" stroke="#e8e4da"/>`).join("");
    const marks = (dots ?? [])
      .map((u) => `<circle cx="${ox + inch(u) * PX}" cy="${oy}" r="5" fill="#c2410c" stroke="#fff" stroke-width="1.5"/>`)
      .join("");
    panels.push(
      `<div class="p"><b>${title}</b><div class="s">${sub}</div><svg width="${W}" height="${H}">${grid}` +
        `<line x1="0" y1="${oy}" x2="${W}" y2="${oy}" stroke="#667"/>` +
        (today ? `<path d="${path(today.outline.points)}" fill="none" stroke="#c0392b" stroke-width="1.5" stroke-dasharray="5 4"/>` : "") +
        `<path d="${path(fresh.outline.points)}" fill="rgba(31,42,59,0.16)" stroke="#1f2a3b" stroke-width="2"/>${marks}</svg></div>`,
    );
  };
  const flat = () => mm(0);
  const WANT: [string, string][] = [
    ["longboard|opened", "Longboard 9'0\" single"],
    ["midlength|2plus1", "Mid-length 7'2\" 2+1"],
    ["fish|opened", "Fish 5'8\" upright twin"],
    ["fish|twin/trailer", "Fish Upright + Trailer"],
    ["shortboard|opened", "Shortboard 6'2\" thruster"],
    ["midlength|opened", "Mid-length 7'2\" quad"],
    ["shortboard|quad", "Shortboard switched to a quad"],
  ];
  const NAMES: Record<string, string> = {
    single: "single",
    twoPlusOneCentre: "centre",
    sideBite: "side bite",
    twinUpright: "upright twin",
    trailer: "centre trailer",
    thruster: "side fin",
    quadRear: "rear",
  };
  const cases = phase16FinCases();
  for (const [label, name] of WANT) {
    const c = cases.find((x: any) => x.label === label);
    const after = New.placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, c.preset.outline.length, flat);
    const today = Old.placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, c.preset.outline.length, flat);
    const seen = new Set<string>();
    after.forEach((fin: any, i: number) => {
      const key = `${fin.role}|${c.marks[i].role}`;
      if (seen.has(key)) return;
      seen.add(key);
      const finName = fin.role === "thruster" ? (c.marks[i].role === "center" ? "centre fin" : c.spec.finSetup === "quad" ? "front" : "side fin") : NAMES[fin.role];
      panel(
        `${name}: ${finName}`,
        `Base ${inch(fin.outline.base).toFixed(2)}", depth ${inch(fin.outline.depth).toFixed(3).replace(/0+$/, "").replace(/\.$/, "")}" (was ${inch(today[i].outline.depth).toFixed(2)}")`,
        fin,
        today[i],
      );
    });
  }
  // The keel at each footprint, with FINS' two dots at its leading root and under its heel.
  const keel = cases.find((x: any) => x.label === "fish|twin/keel");
  for (const baseIn of [4.5, 6.5]) {
    const marks = keel.marks.map((m: any) => ({ ...m, baseLength: inchesToMm(baseIn), leadingOffTail: mm(m.offTail + inchesToMm(baseIn)) }));
    const fin = New.placedFins(marks, "twin", "keel", keel.preset.outline.length, flat)[0];
    const today = Old.placedFins(marks, "twin", "keel", keel.preset.outline.length, flat)[0];
    panel(
      `Fish keel: FINS' base ${baseIn}"`,
      `Whole fin ${baseIn}" dot to dot, root ${inch(fin.outline.base).toFixed(2)}", depth 5", heel over its gap`,
      fin,
      today,
      [0, fin.outline.footprint],
    );
  }
  const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:24px 28px 4px}p{margin:0 28px 14px;font-size:15px;color:#4b5563;line-height:1.45;max-width:1500px}
.g{display:flex;flex-wrap:wrap;gap:10px;padding:0 28px 28px;align-items:flex-end}
.p{border:1px solid #d8d2c4;border-radius:8px;padding:8px 10px;font-size:14px;width:${W}px}.s{color:#4b5563;font-size:13px;margin:2px 0 6px}svg{display:block}
</style></head><body><h1>The fins, flat, on a 1" grid</h1>
<p>Solid: the new shape at FINS' figures with the new defaults. Dashed red: today's one plain outline at the same figures. The root sits on the line, the leading edge left, the tail to the right. Orange dots on the two keels are FINS' two placement dots: leading root and under the heel.</p>
<div class="g">${panels.join("\n")}</div></body></html>`;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1.5 });
  await page.setContent(html);
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: png, fullPage: true });
  await browser.close();
  console.log("wrote", png);
})();

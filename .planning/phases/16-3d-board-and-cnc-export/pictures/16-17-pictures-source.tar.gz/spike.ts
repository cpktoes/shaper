// How far each fin's solid reaches outside its own outline: the same extrusion the scene makes.
//   npx --no-install tsx --tsconfig ./tsconfig.json <abs>/spike.ts <worktree>
import { ExtrudeGeometry, Shape } from "three";

const root = process.argv[2];
(async () => {
  const { phase16FinCases } = await import(`${root}/lib/geometry/__fixtures__/phase16-fin-cases`);
  const O = await import(`${root}/lib/geometry/fin-outline`);
  const SHARE = Number(process.env.SHARE ?? 0.25);
  const seen = new Set<string>();
  for (const c of phase16FinCases()) {
    for (const fin of O.placedFins(c.marks, c.spec.finSetup, c.spec.twinTemplate, c.preset.outline.length, c.rockerAt)) {
      const { outline, thickness } = fin;
      const key = `${fin.role}|${outline.base}|${outline.depth}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const round = thickness * SHARE;
      const into = O.FIN_ROOT_SINK + round;
      const shape = new Shape();
      shape.moveTo(0, -into);
      for (const p of outline.points) shape.lineTo(p.u, p.v);
      shape.lineTo(outline.base, -into);
      shape.closePath();
      const core = Math.max(thickness - 2 * round, thickness * 0.05);
      const geometry = new ExtrudeGeometry(shape, {
        depth: core,
        bevelEnabled: true,
        bevelThickness: round,
        bevelSize: round,
        bevelOffset: -round,
        bevelSegments: 3,
        curveSegments: 1,
      });
      const p = geometry.getAttribute("position");
      let [uMin, uMax, vMin, vMax] = [Infinity, -Infinity, Infinity, -Infinity];
      let worst = 0;
      let bad = 0;
      let [zMin, zMax] = [Infinity, -Infinity];
      for (let i = 0; i < p.count; i++) {
        if (![p.getX(i), p.getY(i), p.getZ(i)].every(Number.isFinite)) bad++;
        zMin = Math.min(zMin, p.getZ(i)); zMax = Math.max(zMax, p.getZ(i));
      }
      if (bad) console.log("NOT FINITE", bad);
      for (let i = 0; i < p.count; i++) {
        uMin = Math.min(uMin, p.getX(i)); uMax = Math.max(uMax, p.getX(i));
        vMin = Math.min(vMin, p.getY(i)); vMax = Math.max(vMax, p.getY(i));
      }
      const rear = Math.max(...outline.points.map((q: { u: number }) => q.u));
      worst = Math.max(-vMin - into, vMax - outline.depth, uMax - rear, -uMin);
      console.log(fin.role.padEnd(18), `base ${outline.base.toFixed(1)} depth ${outline.depth.toFixed(1)}`, `v ${vMin.toFixed(2)}..${vMax.toFixed(2)} (into ${into.toFixed(2)})`, `u ${uMin.toFixed(2)}..${uMax.toFixed(2)} (rear ${rear.toFixed(2)})`, `past the outline by ${worst.toFixed(2)} mm`, `z ${zMin.toFixed(2)}..${zMax.toFixed(2)}`, `count ${p.count}`);
    }
  }
})();

// Scratch config for plan 16-17's pictures: this folder's spec against the worktree's code ("after", port 3217) or the
// archive of the plan's Task 1 commit ("before", port 3219). Run from the worktree:
//   PIC_MODE=after npx playwright test -c <abs>/pictures.config.ts
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd/playwright.config";
import { defineConfig, devices } from "@playwright/test";

const after = process.env.PIC_MODE !== "before";
const port = after ? 3217 : 3219;
const code = after ? "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae829388c3b4cd4fd" : `${__dirname}/before-code`;

export default defineConfig({
  ...base,
  testDir: __dirname,
  testIgnore: [],
  testMatch: ["shots.spec.ts"],
  outputDir: `${__dirname}/test-results`,
  timeout: 600_000,
  workers: 1,
  reporter: "line",
  webServer: {
    ...(base.webServer as object),
    command: `npm run dev -- --port ${port}`,
    url: `http://localhost:${port}/design/outline`,
    cwd: code,
    env: { ...(base.webServer as { env: Record<string, string> }).env, IS_WEBPACK_TEST: "1" },
  },
  use: {
    ...base.use,
    baseURL: `http://localhost:${port}`,
    ...(process.env.REAL_GPU ? { launchOptions: { args: ["--use-angle=metal", "--ignore-gpu-blocklist", "--enable-gpu-rasterization"] } } : {}),
  },
  projects: [{ name: "shots", use: { ...devices["Desktop Chrome"], viewport: { width: 1600, height: 1000 }, deviceScaleFactor: process.env.REAL_GPU ? 1 : 2 } }],
});

// Composes plan 16-17's shots into captioned pictures for the founder. Usage: node compose.js <abs pictures dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const pictures = process.argv[2];
const facts = JSON.parse(fs.readFileSync(path.join(__dirname, "out/facts.json"), "utf8"));
const img = (mode, n) => "data:image/png;base64," + fs.readFileSync(path.join(__dirname, "out", mode, `${n}.png`)).toString("base64");
const fig = (src, cap, cls = "") => `<figure class="${cls}"><img src="${src}"><figcaption>${cap}</figcaption></figure>`;
const CSS = `body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1800px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1640px;line-height:1.45}
section{padding:0 36px 22px}h3{font-size:18px;margin:6px 0 2px}section p{margin:0 0 10px;font-size:14px;color:#374151;line-height:1.4;max-width:1640px}
.row{display:grid;gap:12px;align-items:start}.r6{grid-template-columns:repeat(6,1fr)}.r3{grid-template-columns:repeat(3,1fr)}.r2{grid-template-columns:repeat(2,1fr)}.r4{grid-template-columns:repeat(4,1fr)}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:6px 10px 8px;font-size:13px;color:#4b5563;border-top:1px solid #e5e1d6}
.phones{display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap}.phones figure img{width:auto;height:420px}.side figure img{height:230px}`;
const page = (title, lead, body) => `<!doctype html><html><head><meta charset="utf-8"><style>${CSS}</style></head><body><h1>${title}</h1><p class="lead">${lead}</p>${body}</body></html>`;

const ROWS = [
  ["longboard", "Longboard 9'0\" — single", "The classic raked single, 9\" deep on a 6.3\" base, centred in FINS' box."],
  ["midlength-2plus1", "Mid-length — switched to 2+1 (Reset)", "The centre takes the single's shape an inch shorter, 6.17\" deep. The side bites are the small fin, 3.5\" deep."],
  ["fish", "Fish 5'8\" — upright twin, as it opens", "The upright twin, 5.0\" deep on the Fish's own 5.5\" base."],
  ["fish-keel", "Fish — switched to a keel twin (Reset, so 6.5\")", "Before: the 4.5\" default and the plain outline. After: FINS' new 6.5\" is the whole fin, leading edge to heel, on a 4.28\" root."],
  ["fish-trailer", "Fish — switched to Upright + Trailer (Reset, so 5.5\")", "The mains are upright twins. The centre trailer is the small fin, 3.375\" deep."],
  ["shortboard", "Shortboard 6'2\" — thruster", "Three side fins, 4.5\" deep on 4.5\" bases, in exactly the same places."],
  ["midlength", "Mid-length 7'2\" — quad with its centre fin, as it opens", "Fronts and centre are side fins, 4.5\" deep. Rears are the small fin, 3.375\" deep on FINS' 4.0\" base."],
  ["shortboard-quad", "Shortboard — switched to a quad (Reset)", "The same, on FINS' Reset rears, a 4.5\" base."],
];
const V = [["quarter", "from below and aside"], ["side", "Side view"], ["bottom", "Bottom view"]];
const finsBody = ROWS.map(([n, title, text]) => `<section><h3>${title}</h3><p>${text}</p><div class="row r6">
${V.map(([v, c]) => fig(img("before", `${n}-${v}`), `Before, ${c}`)).join("")}
${V.map(([v, c]) => fig(img("after", `${n}-${v}`), `After, ${c}`)).join("")}</div></section>`).join("\n");

const quad = facts["midlength|opened|rear"];
const front = facts["midlength|opened|front"];
const quadBody = `<section><h3>The Mid-length quad: rears 25% shallower than the fronts</h3>
<p>After, by the app's own figures: fronts ${front.depthAfter}" deep, rears ${quad.depthAfter}" deep on a ${quad.base}" base. Before: the rears were ${quad.depthBefore}" deep. Side view, close in.</p>
<div class="row r2">${fig(img("before", "quad-close-side"), "Before")}${fig(img("after", "quad-close-side"), "After")}</div></section>
<section><h3>The keel from below and aside</h3>
<p>FINS' base is the whole fin, so a 6.5" base is a 6.5" fin and a 4.5" base a 4.5" fin. The root is the front of that (${facts["keel6.5"].root}" and ${facts["keel4.5"].root}"), and the heel hangs over its gap, ${facts["keel6.5"].gap2} two inches behind the root on the 6.5" keel.</p>
<div class="row r3">${fig(img("before", "keel-45-quarter"), "Before: 4.5\", the plain outline")}${fig(img("after", "keel-65-quarter"), "After: 6.5\" (FINS' Reset)")}${fig(img("after", "keel-45-quarter"), "After: 4.5\" (set on FINS)")}
${fig(img("before", "keel-45-side"), "Before, Side view")}${fig(img("after", "keel-65-side"), "After 6.5\", Side view")}${fig(img("after", "keel-45-side"), "After 4.5\", Side view")}</div></section>`;

const toolbarBody = `<section><h3>On a computer, 1280 × 800</h3><p>Wide view stays in the corner; then Fins (pressed when the screen opens), Blank, Contour Stripes and the # for Wire View. The zoom row sits under them. The panel loses SHOW and reads TAIL RAIL, VIEW, EXPORT.</p>
<div class="row r2">${fig(img("before", "panel-page"), "Before, with SHOW in the panel")}${fig(img("after", "panel-page"), "After: the icons in the corner, the panel without SHOW")}</div></section>
<section><h3>Each switch pressed in turn</h3><div class="row r2">${fig(img("after", "corner-fins-off"), "Fins off")}${fig(img("after", "corner-blank-on"), "Blank on (the picked blank's ghost round the board)")}${fig(img("after", "corner-stripes-on"), "Contour Stripes on")}${fig(img("after", "corner-wire-on"), "Wire View on")}</div></section>
<section><h3>A hand-set board</h3><p>Blank is dimmed. Its tooltip, a browser's own and so not in this picture, reads: No blank on this board — pick one on ROCKER to see it here.</p><div style="width:520px">${fig(img("after", "corner-handset"), "The hand-set Fish, pointer on Blank")}</div></section>
<section><h3>On a phone</h3><p>Upright, Fins takes the corner and the four pack tight. Sideways, Wide view keeps the corner. The zoom row only appears once zoomed in, under the icons.</p>
<div class="phones">${fig(img("after", "phone-iphone14"), "iPhone 14, 390 × 664")}${fig(img("after", "phone-phone320"), "A 320 × 568 phone")}${fig(img("after", "phone-zoomed"), "iPhone 14 zoomed in, the zoom row under the icons")}</div>
<div class="phones side" style="margin-top:12px">${fig(img("after", "phone-sideways"), "A sideways iPhone, 844 × 390")}</div></section>`;

const W = (name, title) => `<section><h3>${title}</h3><div class="row r3">${fig(img("after", `wire-${name}-end`), "End-on, from the nose")}${fig(img("after", `wire-${name}-quarter`), "Three-quarter")}${fig(img("after", `wire-${name}-bottom`), "Bottom view")}</div></section>`;
const wireBody = `<section><h3>Your Shape3D picture</h3><div style="width:520px">${fig("data:image/png;base64," + fs.readFileSync(path.join(pictures, "founder-wire-view-shape3d.png")).toString("base64"), "The view you liked")}</div></section>
${W("fish", "Fish, Daylight")}${W("longboard", "Longboard, Daylight")}${W("white", "Fish on a white page, as your picture has it: shown for your call, not built")}${W("fish-slate", "Fish, Slate (dark theme): dark lines on a light board, the theme's own ground")}${W("fish-phosphor", "Fish, Phosphor")}
<section><h3>The corner</h3><div class="row r2">${fig(img("after", "corner-wire-on"), "On a computer, the # pressed")}${fig(img("after", "phone-wire"), "On an iPhone")}</div></section>`;

(async () => {
  const browser = await chromium.launch();
  const p = await browser.newPage({ viewport: { width: 1800, height: 1200 }, deviceScaleFactor: 1 });
  for (const [file, title, lead, body] of [
    ["16-17-fins-before-after.png", "Every setup's fins, before and after", "The real app at /design/3d, Daylight, close in on the fins. Each fin stands where FINS puts it; only its shape changed, and the twin defaults moved a twin's leading dot.", finsBody],
    ["16-17-quad-and-keel.png", "The quad's rears and the keel", "The real app, close in.", quadBody],
    ["16-17-toolbar.png", "The switches as icons in the corner", "The real app at /design/3d, Daylight.", toolbarBody],
    ["16-17-wire-view.png", "Wire View: the # switch", "The real app. A ring every 1 1/2\" along the board, one long line per whole inch of width on the deck and again on the bottom, one outline loop at the rail's apex, near side only.", wireBody],
  ]) {
    const html = path.join(__dirname, "compose.html");
    fs.writeFileSync(html, page(title, lead, body));
    await p.goto("file://" + html);
    await p.evaluate(() => document.fonts.ready);
    await p.screenshot({ path: path.join(pictures, file), fullPage: true });
    console.log("wrote", file);
  }
  await browser.close();
})();

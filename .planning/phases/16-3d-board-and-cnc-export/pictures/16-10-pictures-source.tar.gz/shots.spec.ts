// Plan 16-10's pictures for the founder: every fin system on the real 3D screen (port 3210), in the Bottom view and
// the Side view, each zoomed in on its fins. Run: npx playwright test -c <abs>/pictures.config.ts
import { writeFileSync } from "node:fs";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/blanks/preset-blanks";
import { resetAdvanced, type FinSetup, type TwinTemplate } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/models/toolbar-tip";
import { THEME_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/lib/theme";
import { countDifferent, decodePng } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae6bd8e6d9ec8fe5c/e2e/helpers/canvas-pixels";

const OUT = __dirname + "/out";

interface Case {
  name: string;
  preset: string;
  setup?: FinSetup;
  twin?: TwinTemplate;
}

const CASES: Case[] = [
  { name: "longboard", preset: "Longboard" },
  { name: "fish", preset: "Fish" },
  { name: "fish-keel", preset: "Fish", setup: "twin", twin: "keel" },
  { name: "fish-trailer", preset: "Fish", setup: "twin", twin: "trailer" },
  { name: "shortboard", preset: "Shortboard" },
  { name: "midlength", preset: "Mid-length" },
  { name: "midlength-2plus1", preset: "Mid-length", setup: "2plus1" },
];

function fields(c: Case): DesignSnapshotFields {
  const preset = BOARD_PRESETS.find((p) => p.name === c.preset);
  if (!preset) throw new Error(`no ${c.preset}`);
  const base = presetDesignFields(preset);
  const fins = c.setup
    ? { ...base.fins, finSetup: c.setup, twinTemplate: c.twin ?? base.fins.twinTemplate, advanced: resetAdvanced(c.setup) }
    : base.fins;
  return {
    ...base,
    fins,
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2",
  };
}

async function prepare(page: Page, c: Case) {
  const raw = openBoardCopyJson(fields(c), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem(themeKey, "daylight");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, THEME_STORAGE_KEY] as const,
  );
}

async function ready(page: Page) {
  const host = page.locator("[data-board-3d]");
  await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 120_000 });
  await page.waitForFunction(() => {
    const el = document.querySelector("[data-viewer-zoom] button, [data-viewer-toolbar] button");
    return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
  });
  await page.waitForTimeout(1200);
  return host;
}

const HIDE_CHROME = "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }";

async function shot(host: Locator) {
  await host.page().waitForTimeout(1200);
  return host.screenshot({ scale: "css", style: HIDE_CHROME });
}

/** Where the fins are on the canvas: the box of pixels that change when Fins is unticked. */
async function finsBoxOn(page: Page, host: Locator) {
  const on = decodePng(await shot(host));
  await page.getByRole("checkbox", { name: THREE_D_COPY.fins, exact: true }).click();
  const off = decodePng(await shot(host));
  await page.getByRole("checkbox", { name: THREE_D_COPY.fins, exact: true }).click();
  let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
  for (let y = 0; y < on.height; y++) {
    for (let x = 0; x < on.width; x++) {
      const i = 4 * (y * on.width + x);
      if ([0, 1, 2].every((k) => Math.abs(on.rgba[i + k] - off.rgba[i + k]) <= 2)) continue;
      left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
    }
  }
  expect(countDifferent(on.rgba, off.rgba, 2)).toBeGreaterThan(0);
  return { left, right, top, bottom };
}

async function view(page: Page, name: "bottom" | "side") {
  await page.getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true }).getByRole("button", {
    name: THREE_D_COPY.views[name],
    exact: true,
  }).click();
  await page.waitForTimeout(1500);
}

/** Zooms toward (x, y) on the canvas by `notches` half steps. */
async function zoomAt(page: Page, host: Locator, x: number, y: number, notches: number) {
  const box = (await host.boundingBox())!;
  await page.mouse.move(box.x + x, box.y + y);
  for (let i = 0; i < notches; i++) {
    await page.waitForTimeout(250);
    await page.mouse.wheel(0, -100);
  }
  await page.waitForTimeout(1500);
}

const boxes: Record<string, unknown> = {};

/** The fins and a margin round them, widened to 4:3, inside the canvas (CSS dots). */
function frameAround(b: { left: number; right: number; top: number; bottom: number }, w: number, h: number) {
  const size = Math.max(b.right - b.left, b.bottom - b.top);
  const m = Math.max(40, size * 0.3);
  let left = b.left - m, right = b.right + m, top = b.top - m * 1.6, bottom = b.bottom + m;
  const cw = right - left, ch = bottom - top;
  if (cw / ch < 4 / 3) { const d = (ch * 4) / 3 - cw; left -= d / 2; right += d / 2; }
  else { const d = (cw * 3) / 4 - ch; top -= d / 2; bottom += d / 2; }
  const shiftX = Math.max(0, -left) - Math.max(0, right - w);
  const shiftY = Math.max(0, -top) - Math.max(0, bottom - h);
  left += shiftX; right += shiftX; top += shiftY; bottom += shiftY;
  left = Math.max(0, left); top = Math.max(0, top); right = Math.min(w, right); bottom = Math.min(h, bottom);
  return { x: left, y: top, width: right - left, height: bottom - top };
}

for (const c of CASES) {
  test(c.name, async ({ page }) => {
    await prepare(page, c);
    await page.goto("/design/3d");
    const host = await ready(page);
    for (const v of ["bottom", "side", "quarter"] as const) {
      if (v === "quarter") {
        // From the Side view, turned three key steps (45°) so the bottom and the fins are seen from below and aside.
        await view(page, "side");
        await host.focus();
        for (let i = 0; i < 3; i++) await page.keyboard.press(process.env.QUARTER_KEY ?? "ArrowUp");
        // Leave the canvas, so its focus ring is not in the pictures (it would read as a change with the fins).
        await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
        await page.waitForTimeout(1500);
      } else await view(page, v);
      writeFileSync(`${OUT}/${c.name}-${v}-1x.png`, await shot(host));
      const b = await finsBoxOn(page, host);
      boxes[`${c.name}-${v}`] = b;
      const hb = (await host.boundingBox())!;
      const f = frameAround(b, hb.width, hb.height);
      await page.waitForTimeout(1200);
      writeFileSync(
        `${OUT}/${c.name}-${v}.png`,
        await page.screenshot({ clip: { x: hb.x + f.x, y: hb.y + f.y, width: f.width, height: f.height }, style: HIDE_CHROME }),
      );
    }
    writeFileSync(`${OUT}/boxes-${c.name}.json`, JSON.stringify(boxes, null, 1));
  });
}

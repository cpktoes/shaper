// Composes plan 16-10's shots into one captioned picture for the founder. Usage: node compose.js <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const ROWS = [
  ["longboard", "Longboard 9'0\" — single", "One fin, 9\" deep (the board's 9 feet, read as inches) on a 6.3\" base (0.70 of its depth), centred in FINS' 10.5\" box: trailing edge 7.6\" off the tail, leading edge 13.9\". 3/8\" thick."],
  ["fish", "Fish 5'8\" — upright twin (as opened)", "Two fins, 5.0\" deep, base 5.5\" (FINS' own), the tip 0.75\" behind the trailing edge. Trailing edges 7.5\" off the tail."],
  ["fish-keel", "Fish — switched to a keel twin (FINS' Reset)", "5.0\" deep, the tip straight above the trailing edge, base FINS' default 4.5\" — so it reads upright, not long and low (your K5 ruling). Raise the base on FINS and the 3D follows."],
  ["fish-trailer", "Fish — switched to Upright + Trailer", "Mains: the upright twin's outline, 5.0\" deep, base 4.5\", 10\" off the tail. Centre trailer: the thruster's outline (4.5\" deep, base 4.5\"), 4\" off the tail — question 3."],
  ["shortboard", "Shortboard 6'2\" — thruster", "Three alike: 4.5\" deep, base 4.5\", tip 0.75\" behind. Sides 11\" off the tail with FINS' 1/4\" toe-in; centre 3.375\" off the tail."],
  ["midlength", "Mid-length 7'2\" — quad with its centre fin", "Fronts 4.5\" deep on 4.5\" bases; rears a touch shallower, 4.25\" deep, on FINS' 4.0\" bases. The centre fin takes the thruster's outline — question 3."],
  ["midlength-2plus1", "Mid-length — switched to 2+1", "Centre: the single's rule, 7.17\" deep on a 5.0\" base, centred in the 10.5\" box. Side bites: the thruster's outline, 4.5\" deep, base 4.5\", 15.3\" off the tail."],
];
const fig = (n, cap) => `<figure><img src="${img(n)}"><figcaption>${cap}</figcaption></figure>`;
const rows = ROWS.map(
  ([n, title, text]) => `<section><h3>${title}</h3><p>${text}</p><div class="row">
${fig(`${n}-quarter`, "From below and aside")}${fig(`${n}-side`, "Side view, close in")}${fig(`${n}-bottom`, "Bottom view, close in")}
</div></section>`,
).join("\n");
const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1500px;line-height:1.45}
section{padding:0 36px 22px}h3{font-size:18px;margin:6px 0 2px}section p{margin:0 0 10px;font-size:14px;color:#374151;line-height:1.4;max-width:1500px}
.row{display:grid;grid-template-columns:1.25fr 1fr 1fr;gap:14px;align-items:start}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:6px 12px 8px;font-size:13px;color:#4b5563;border-top:1px solid #e5e1d6}
.note{font-size:15px;line-height:1.55;color:#374151;max-width:1500px;padding:4px 36px 36px}
</style></head><body>
<h1>Phase 16, plan 10: fins on the 3D board</h1>
<p class="lead">The real app at /design/3d, Daylight. Every fin stands on its FINS line — trailing-edge mark to leading-edge mark, toe-in included — upright and square to the bottom, no cant. One plain generic outline per role, with FINS' own base; a smaller fin is a shorter base, never a shrunk fin. The SHOW section's Fins box (ticked by default) hides them without moving the view.</p>
${rows}
<div class="note"><b>Your three questions.</b> 1. Do these read as plain, generic fins — the single centred in its box, keels long and low, the thruster's three alike, the quad's rears a touch smaller? 2. A default keel (FINS' 4.5" base) looks more like an upright fin than a real keel; that is "true to FINS" (your K5 ruling) — raise the keel's base on FINS and the 3D follows. 3. The trailer twin's centre and the quad's centre fin weren't named in your rulings; they use the thruster's outline here. Fine, or say what they should be.</div>
</body></html>`;
fs.writeFileSync(path.join(__dirname, "compose.html"), html);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, "compose.html"));
  await page.evaluate(() => document.fonts.ready);
  const out = process.argv[2];
  await page.screenshot({ path: out, fullPage: true });
  console.log("wrote", out);
  await browser.close();
})();

// Plan 16-10's fins table: every preset's fins as the 3D board draws them (role, base, depth, where), from the app's
// own functions. Run from the worktree: npx --no-install tsx --tsconfig ./tsconfig.json <abs>/table.ts <worktree>
const root = process.argv[2];
(async () => {
  const { BOARD_PRESETS } = await import(`${root}/lib/geometry/presets`);
  const { buildOutline } = await import(`${root}/lib/geometry/outline`);
  const { deriveEffectiveFins } = await import(`${root}/lib/geometry/design`);
  const F = await import(`${root}/lib/geometry/fins`);
  const O = await import(`${root}/lib/geometry/fin-outline`);
  const { mmToInches, formatFeetInches } = await import(`${root}/lib/geometry/units`);
  const r = (x: number) => (+mmToInches(x).toFixed(3)).toString();
  const cases: [string, string, any?, any?][] = [
    ["Longboard", "longboard"],
    ["Fish", "fish"],
    ["Fish → keel twin", "fish", "twin", "keel"],
    ["Fish → Upright + Trailer", "fish", "twin", "trailer"],
    ["Shortboard", "shortboard"],
    ["Mid-length", "midlength"],
    ["Mid-length → 2+1", "midlength", "2plus1"],
    ["Mid-length → single", "midlength", "single"],
  ];
  for (const [label, id, setup, twin] of cases) {
    const p = BOARD_PRESETS.find((x: any) => x.id === id);
    const geo = buildOutline(p.outline);
    const fins = setup ? { ...p.fins, finSetup: setup, twinTemplate: twin ?? p.fins.twinTemplate, advanced: F.resetAdvanced(setup) } : p.fins;
    const spec = deriveEffectiveFins(fins, true, p.outline, geo);
    const marks = F.computeFinPlacement(spec, F.importedFinTailFromOutline(geo)).marks;
    const placed = O.placedFins(marks, spec.finSetup, spec.twinTemplate, p.outline.length, () => 0);
    const rows = placed
      .map((f: any, i: number) => ({ f, m: marks[i] }))
      .filter(({ m }: any) => m.side >= 0)
      .map(({ f, m }: any) => `${m.role}${m.side ? " (each side)" : ""}: ${f.role}, base ${r(f.outline.base)}", depth ${r(f.outline.depth)}", tip ${r(f.outline.tipBehind)}" behind, ${r(f.thickness)}" thick, trailing edge ${r(f.trailing[0])}" off the tail${m.side ? `, ${r(Math.abs(m.lateral))}" off the stringer` : ""}${f.role === "single" ? ` (box ${r(m.offTail)}"–${r(m.leadingOffTail)}")` : ""}`);
    console.log(`${label} ${formatFeetInches(p.outline.length)} [${spec.finSetup}${spec.finSetup === "twin" ? "/" + spec.twinTemplate : ""}]\n  ${rows.join("\n  ")}`);
  }
})();

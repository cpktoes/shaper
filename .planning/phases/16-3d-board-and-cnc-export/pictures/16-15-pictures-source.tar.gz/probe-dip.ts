// Scratch (16-15): on the stock board with the centre's Sharp Bottom Tuck, the nose blend's areas station by station.
import { DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { DEFAULT_FOIL_SPEC } from "@/lib/geometry/foil";
import { buildOutline, sampleOutline } from "@/lib/geometry/outline";
import { DEFAULT_RAIL_BAND_SPEC, type RailBandSpec } from "@/lib/geometry/rail-bands";
import { type Mm, mm, inchesToMm } from "@/lib/geometry/units";
import { boardSectionEnds, boardSections } from "@/lib/geometry/volume";

const g = buildOutline(DEFAULT_BOARD_SPEC.outline);
const length = DEFAULT_BOARD_SPEC.outline.length;
const input = (rails: RailBandSpec) => ({ halfWidthAt: (s: Mm) => sampleOutline(g, s), foil: DEFAULT_FOIL_SPEC, rails, length });
const base: RailBandSpec = { ...DEFAULT_RAIL_BAND_SPEC, tailHardEdgeBlendsFrom: inchesToMm(14), tailHardEdgeEndsAt: inchesToMm(18) };
const on: RailBandSpec = { ...base, center: { ...base.center, sharpBottomTuck: true }, tail: { ...base.tail, sharpBottomTuck: true } };
for (let i = 36; i <= 62; i += 1) {
  const s = mm(inchesToMm(i));
  const [offS] = boardSections(input(base), [s]);
  const [onS] = boardSections(input(on), [s]);
  const e = boardSectionEnds(input(on), s);
  console.log(
    `${i}" w ${onS.tipWeight.toFixed(3)}  off ${offS.area.toFixed(2)}  on ${onS.area.toFixed(2)}  base(SBT) ${e.base.area.toFixed(2)}  tip ${e.tip.area.toFixed(2)}  on-off ${(onS.area - offS.area).toFixed(3)}`,
  );
}

// Scratch (16-15): do the litres the two browser cases read move at two decimals?
import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { summarizeDesign } from "@/lib/geometry/design";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { DEFAULT_RAIL_BAND_SPEC, type RailBandSpec } from "@/lib/geometry/rail-bands";
import { inchesToMm, mm } from "@/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "@/lib/geometry/volume";

const stock = (rails: RailBandSpec) => ({
  outline: DEFAULT_BOARD_SPEC.outline, rocker: DEFAULT_BOARD_SPEC.rocker, foil: DEFAULT_BOARD_SPEC.foil,
  rails, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC, blank: null,
});
const L = DEFAULT_BOARD_SPEC.outline.length;
const r: RailBandSpec = { ...DEFAULT_RAIL_BAND_SPEC, tailHardEdge: false, tail: { ...DEFAULT_RAIL_BAND_SPEC.tail, singleTuck: true }, tailHardEdgeBlendsFrom: inchesToMm(12) };
console.log("stock SBT 12-30", summarizeDesign(stock(r)).volumeLitres.toPrecision(17));
console.log("stock SBT 12-36", summarizeDesign(stock({ ...r, tailHardEdgeEndsAt: mm(L / 2) })).volumeLitres.toPrecision(17));
const sb = BOARD_PRESETS.find((p) => p.name === "Shortboard")!;
const f = presetDesignFields(sb);
const fr: RailBandSpec = { ...f.rails, tailHardEdge: false, tail: { ...f.rails.tail, singleTuck: true } };
const base = { ...f, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
console.log("shortboard SBT default", summarizeDesign({ ...base, rails: fr }).volumeLitres.toPrecision(17));
console.log("shortboard SBT end centre", summarizeDesign({ ...base, rails: { ...fr, tailHardEdgeEndsAt: mm(f.outline.length / 2) } }).volumeLitres.toPrecision(17));

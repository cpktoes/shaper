// Scratch (16-15): the 74-board table for the SUMMARY — today's live litres (go-live 1's rule, from the pin) against
// the new rule, and the four presets as their cards open them. Every figure comes from the app or the pin.
import { readFileSync } from "node:fs";
import path from "node:path";
import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { phase16LiveBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { LIVE_DESIGN_RULES, summarizeDesign, summarizeDesignWith } from "@/lib/geometry/design";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC, HARD_EDGE_FADE, railCharacterDifferences } from "@/lib/geometry/volume";

const pin = JSON.parse(
  readFileSync(path.resolve(process.cwd(), "lib/geometry/__fixtures__/phase16-live-litres-pin.json"), "utf8"),
) as { litres: Record<string, string> };
const WORDS: Record<string, string> = {
  hardEdge: "Hard Edge",
  family: "Family",
  symmetrical: "Symmetrical",
  singleTuck: "Single Tuck",
  sharpBottomTuck: "Sharp Bottom Tuck",
};
const words = (keys: string[]) => (keys.length ? keys.map((k) => WORDS[k]).join(", ") : "same");
console.log("| Board | Tail differs in | Nose differs in | Today (L) | New rule (L) | Move (L) |");
console.log("|---|---|---|---:|---:|---:|");
let same = 0;
let largest = { label: "", move: 0 };
for (const b of phase16LiveBoards()) {
  const today = Number(pin.litres[b.label]);
  const after = summarizeDesign(b.fields).volumeLitres;
  const move = after - today;
  if (Object.is(after.toPrecision(17), pin.litres[b.label]) || after.toPrecision(17) === pin.litres[b.label]) same++;
  if (Math.abs(move) > Math.abs(largest.move)) largest = { label: b.label, move };
  const sign = move > 0 ? "+" : move < 0 ? "−" : "±";
  console.log(
    `| ${b.label} | ${words(railCharacterDifferences(b.fields.rails, "tail"))} | ${words(railCharacterDifferences(b.fields.rails, "nose"))} | ${today.toFixed(4)} | ${after.toFixed(4)} | ${sign}${Math.abs(move).toFixed(4)} |`,
  );
}
console.log(`\n${same} of 74 bit-identical; largest move ${largest.label} ${largest.move.toFixed(4)} L`);
console.log("\nThe presets as their cards open them:");
for (const preset of BOARD_PRESETS) {
  const fields = { ...presetDesignFields(preset), railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
  const before = summarizeDesignWith(fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_FADE }).volumeLitres;
  const after = summarizeDesign(fields).volumeLitres;
  console.log(`${preset.id}: ${before.toFixed(2)} → ${after.toFixed(2)} L (${(after - before >= 0 ? "+" : "")}${(after - before).toFixed(4)})  tail ${words(railCharacterDifferences(fields.rails, "tail"))}; nose ${words(railCharacterDifferences(fields.rails, "nose"))}`);
}

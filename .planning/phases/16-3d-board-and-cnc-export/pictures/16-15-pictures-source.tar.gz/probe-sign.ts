// Scratch (16-15): along the mid-length swallow's tail, the tip-minus-base area at each station — does its sign change?
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES, type DesignSummaryFields } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { inchesToMm, mm } from "@/lib/geometry/units";
import { boardSectionEnds, railCharacterDifferences } from "@/lib/geometry/volume";

function inputOf(fields: DesignSummaryFields) {
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  return designCrossSectionInput(buildOutline(fields.outline), profile, rails, fields.outline.length);
}
const label = process.argv[2] ?? "midlength|swallow|hard";
const board = phase16Boards().find((b) => b.label === label)!;
const input = inputOf(board.fields);
console.log(label, railCharacterDifferences(input.rails, "tail"), railCharacterDifferences(input.rails, "nose"));
for (let s = 12; s <= 30; s += 1) {
  const e = boardSectionEnds(input, mm(inchesToMm(s)));
  console.log(`${s}"  tip-base ${(e.tip.area - e.base.area).toFixed(2)} mm²  tipWeight ${e.tipWeight.toFixed(3)}`);
}

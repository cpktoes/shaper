// Scratch (16-15): how long one board's litres take, go-live 1's rule vs the live rule.
import { phase16LiveBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { LIVE_DESIGN_RULES, summarizeDesign, summarizeDesignWith } from "@/lib/geometry/design";
import { HARD_EDGE_FADE } from "@/lib/geometry/volume";

const boards = phase16LiveBoards();
const time = (f: () => void, n: number) => {
  const t0 = performance.now();
  for (let i = 0; i < n; i++) f();
  return (performance.now() - t0) / n;
};
for (const label of ["shortboard|asis|hard", "longboard|asis|hard", "stock|hard", "tucked|fish|tail-sbt"]) {
  const b = boards.find((x) => x.label === label)!;
  for (let i = 0; i < 3; i++) summarizeDesign(b.fields);
  const before = time(() => summarizeDesignWith(b.fields, { ...LIVE_DESIGN_RULES, hardEdge: HARD_EDGE_FADE }), 20);
  const after = time(() => summarizeDesign(b.fields), 20);
  console.log(`${label.padEnd(24)} go-live 1 ${before.toFixed(2)} ms   live ${after.toFixed(2)} ms`);
}

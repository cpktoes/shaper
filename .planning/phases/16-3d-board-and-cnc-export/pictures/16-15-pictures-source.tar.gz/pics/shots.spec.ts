// Plan 16-15's pictures for the founder: RAILS' tail and nose Advanced menus with the two Tail Rail rows, the 3D
// panel's Tail Rail group, and the 3D board's Bottom view before (3216, the second pin's commit) and after (3215,
// this worktree). SHOTS=name1,name2 picks a few. Every board is the app's own (presets, stock defaults).
import { mkdirSync, writeFileSync } from "node:fs";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/components/3d/three-d-copy";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/blanks/preset-blanks";
import { DEFAULT_BOARD_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/geometry/board";
import { DEFAULT_FIN_PLACEMENT_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/geometry/presets";
import { DEFAULT_RAIL_BAND_SPEC, type RailBandSpec } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/geometry/rail-bands";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/models/banner-dismissal";
import type { DesignSnapshotFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/models/design-snapshot";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/lib/models/toolbar-tip";

const OUT = __dirname + "/out";
mkdirSync(OUT, { recursive: true });
const AFTER = "http://localhost:3215";
const BEFORE = "http://localhost:3216";

type Board = "stock-soft-sbt" | "stock-soft" | "stock" | "shortboard-centre-sbt" | "fish";

function fields(board: Board): DesignSnapshotFields {
  const common = { volume: DEFAULT_VOLUME_SPEC, finsImportTemplate: true, railsImportFoilThickness: true, boardName: "", finSystem: "fcs2" as const };
  if (board.startsWith("stock")) {
    let rails: RailBandSpec = DEFAULT_RAIL_BAND_SPEC;
    if (board === "stock-soft") rails = { ...rails, tailHardEdge: false };
    if (board === "stock-soft-sbt") rails = { ...rails, tailHardEdge: false, tail: { ...rails.tail, sharpBottomTuck: true } };
    return {
      outline: DEFAULT_BOARD_SPEC.outline,
      rocker: DEFAULT_BOARD_SPEC.rocker,
      foil: DEFAULT_BOARD_SPEC.foil,
      rails,
      fins: DEFAULT_FIN_PLACEMENT_SPEC,
      blank: null,
      ...common,
    };
  }
  const preset = BOARD_PRESETS.find((p) => p.name === (board === "fish" ? "Fish" : "Shortboard"))!;
  const base = presetDesignFields(preset);
  const rails =
    board === "shortboard-centre-sbt"
      ? { ...base.rails, center: { ...base.rails.center, sharpBottomTuck: true }, nose: { ...base.rails.nose, sharpBottomTuck: false } }
      : base.rails;
  return { ...base, rails, ...common };
}

async function prepare(page: Page, board: Board, units: "imperial" | "metric" = "imperial") {
  const raw = openBoardCopyJson(fields(board), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, value, unitsValue]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      if (window.sessionStorage.getItem("pics-seeded") === null) {
        window.localStorage.setItem(boardKey, value);
        window.localStorage.setItem("shaper-units", unitsValue);
        window.sessionStorage.setItem("pics-seeded", "1");
      }
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, units] as const,
  );
}

async function hydrated(page: Page, selector: string) {
  await expect(page.locator(selector).first()).toBeVisible({ timeout: 120_000 });
  await page.waitForFunction(
    (sel) => {
      const el = document.querySelector(sel);
      return !!el && Object.keys(el).some((k) => k.startsWith("__react"));
    },
    selector,
    { timeout: 120_000 },
  );
}

async function railsGroup(page: Page, key: "tail" | "nose", phone = false): Promise<{ group: Locator; body: Locator }> {
  await page.goto(`${AFTER}/design/rails`);
  await hydrated(page, `[data-rail-group]`);
  if (phone) {
    const tab = page.getByRole("tablist").filter({ hasText: "NOSE" }).getByRole("tab", { name: key.toUpperCase() });
    await expect(async () => {
      await tab.click();
      await expect(tab).toHaveAttribute("aria-selected", "true", { timeout: 1_000 });
    }).toPass({ timeout: 60_000 });
  }
  const group = page.locator(`[data-rail-group="${key}"]`);
  const heading = group.getByRole("button", { name: /^Advanced [▾▸]$/ });
  const body = heading.locator("xpath=following-sibling::div[1]");
  await expect(async () => {
    if ((await body.count()) === 0) await heading.click();
    await expect(body.getByRole("button", { name: /Reset Advanced Settings/ })).toBeVisible({ timeout: 1_000 });
  }).toPass({ timeout: 60_000 });
  await page.waitForTimeout(600);
  return { group, body };
}

/** The dev server's own badge, never part of the app. */
const NO_DEV = "nextjs-portal { display: none !important; }";

const wanted = process.env.SHOTS?.split(",");
const want = (name: string) => !wanted || wanted.includes(name);

// RAILS, desktop.
for (const [name, board, units, untick] of [
  ["rails-tail-hard", "stock", "imperial", false],
  ["rails-tail-soft-sbt", "stock-soft-sbt", "imperial", false],
  ["rails-tail-metric", "stock-soft-sbt", "metric", false],
] as const) {
  test(name, async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop" || !want(name) || !!untick);
    // 1280 wide (the layout reads width alone); tall enough that the whole tail group fits above the dev-only row.
    await page.setViewportSize({ width: 1280, height: 1700 });
    await prepare(page, board, units);
    const { group } = await railsGroup(page, "tail");
    writeFileSync(`${OUT}/${name}.png`, await group.screenshot({ style: NO_DEV }));
  });
}

test("rails-nose", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop" || !want("rails-nose"));
  await page.setViewportSize({ width: 1280, height: 1700 });
  await prepare(page, "stock");
  const { group } = await railsGroup(page, "nose");
  writeFileSync(`${OUT}/rails-nose.png`, await group.screenshot({ style: NO_DEV }));
});

test("phone-tail", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone" || !want("phone-tail"));
  await prepare(page, "stock-soft-sbt");
  const { body } = await railsGroup(page, "tail", true);
  await body.getByRole("button", { name: /Reset Advanced Settings/ }).scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);
  writeFileSync(`${OUT}/phone-tail.png`, await page.screenshot({ style: NO_DEV }));
});

test("threed-panel-soft", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop" || !want("threed-panel-soft"));
  await prepare(page, "stock-soft-sbt");
  await page.goto(`${AFTER}/design/3d`);
  await hydrated(page, "[data-three-d-tail-rail]");
  await page.waitForTimeout(800);
  writeFileSync(`${OUT}/threed-panel-soft.png`, await page.locator("[data-three-d-controls]").screenshot({ style: NO_DEV }));
});

// The 3D board's Bottom view with Contour Stripes, before and after.
const HIDE_CHROME = "[data-viewer-zoom], [data-viewer-toolbar] { visibility: hidden !important; }";
for (const board of ["stock-soft-sbt", "shortboard-centre-sbt", "fish"] as const) {
  for (const [when, url] of [
    ["before", BEFORE],
    ["after", AFTER],
  ] as const) {
    for (const stripes of [true, false]) {
      const name = `bottom-${board}-${when}${stripes ? "" : "-plain"}`;
      test(name, async ({ page }, testInfo) => {
        test.skip(testInfo.project.name !== "desktop3x" || !want(name) || process.env.ONLY_AFTER === "1");
        await prepare(page, board);
        await page.goto(`${url}/design/3d`);
        const host = page.locator("[data-board-3d]");
        await expect(host).toHaveAttribute("data-board-state", "ready", { timeout: 180_000 });
        await page.waitForFunction(() => {
          const el = document.querySelector("[data-viewer-zoom] button, [data-viewer-toolbar] button");
          return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
        });
        await page.waitForTimeout(1200);
        if (stripes) await page.getByRole("checkbox", { name: THREE_D_COPY.contourStripes, exact: true }).click();
        await page
          .getByRole("group", { name: THREE_D_COPY.viewsGroup, exact: true })
          .getByRole("button", { name: THREE_D_COPY.views.bottom, exact: true })
          .click();
        await page.waitForTimeout(2500);
        writeFileSync(`${OUT}/${name}.png`, await host.screenshot({ scale: "device", style: HIDE_CHROME }));
      });
    }
  }
}

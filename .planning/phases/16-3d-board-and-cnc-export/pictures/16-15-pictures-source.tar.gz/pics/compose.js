// Composes plan 16-15's shots into the founder's two pictures. Usage: node compose.js rails <abs out.png> | node compose.js 3d <abs out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "out");
const img = (n) => "data:image/png;base64," + fs.readFileSync(path.join(dir, `${n}.png`)).toString("base64");
const fig = (n, cap) => `<figure><img src="${img(n)}"><figcaption>${cap}</figcaption></figure>`;

const STYLE = `<style>
body{margin:0;background:#fff;font-family:Inter,-apple-system,Helvetica,Arial,sans-serif;color:#1f2a37;width:1600px}
h1{font-size:26px;margin:28px 36px 6px}p.lead{margin:0 36px 18px;font-size:16px;color:#4b5563;max-width:1500px;line-height:1.45}
section{padding:0 36px 24px}h3{font-size:19px;margin:6px 0 2px}section p{margin:0 0 10px;font-size:14px;color:#374151;line-height:1.45;max-width:1500px}
.row{display:grid;gap:14px;align-items:start}.c2{grid-template-columns:1fr 1fr}.c3{grid-template-columns:1fr 1fr 1fr}.c4{grid-template-columns:1fr 1fr 1fr 1fr}
.rails{grid-template-columns:repeat(4, 1fr)}.second{grid-template-columns:300px 360px 1fr}
figure{margin:0;border:1px solid #d8d2c4;border-radius:10px;overflow:hidden;background:#fff}
figure img{display:block;width:100%;height:auto}figcaption{padding:6px 12px 8px;font-size:13px;color:#4b5563;border-top:1px solid #e5e1d6}
.note{font-size:15px;line-height:1.55;color:#374151;max-width:1500px;padding:4px 36px 36px}
</style>`;

const pages = {
  rails: `<!doctype html><html><head><meta charset="utf-8">${STYLE}</head><body>
<h1>Phase 16, plan 15: the Tail Rail rows on RAILS and the 3D page</h1>
<p class="lead">The real app, shot from this plan's own server. The tail's two rows are now named for what they set — the tail rail's
whole blend into the centre's — and always show on the tail, Hard Edge ticked or not. The nose has no row, as you ruled:
"Only the tail rail gets the users blend. The nose is a default that always gets applied."</p>
<section><h3>RAILS on a computer, 1280 wide (the window made tall so each whole group shows in one picture): the tail's Advanced menu, and the nose's</h3>
<p>Left to right: the stock 6'0" with Hard Edge on (the two rows directly above Reset, where they were); the same board with Hard Edge off and
the tail's Sharp Bottom Tuck ticked (the tuck rows are back and the two rows follow them, still above Reset); the same in Metric; and the nose's
Advanced menu, which has nothing new.</p>
<div class="row rails">
${fig("rails-tail-hard", "Tail, Hard Edge on")}
${fig("rails-tail-soft-sbt", "Tail, Hard Edge off, Sharp Bottom Tuck ticked")}
${fig("rails-tail-metric", "The same in Metric")}
${fig("rails-nose", "Nose: no blend rows")}
</div></section>
<section><h3>On an iPhone 14, and the 3D page's panel</h3>
<p>The phone's TAIL tab with Hard Edge off, scrolled to the end of its Advanced menu; and the 3D page's panel with Hard Edge off — the group is
now TAIL RAIL, its two rows live (no dimming and no reason line any more), over the very same two values as RAILS.</p>
<div class="row second">
${fig("phone-tail", "iPhone 14, the tail's Advanced menu")}
${fig("threed-panel-soft", "3D panel, Hard Edge off")}
<div></div>
</div></section>
</body></html>`,
  "3d": `<!doctype html><html><head><meta charset="utf-8">${STYLE}</head><body>
<h1>Phase 16, plan 15: the 3D board's bottom, before and after the whole rail fades</h1>
<p class="lead">The 3D page's Bottom view, nose on the left and tail on the right, with Contour Stripes on. "Before" is the app as go-live 1
shipped it; "after" is this plan. Under each pair, the stretch of rail it is about, close up: with Contour Stripes, then the plain shading.</p>
${["stock-soft-sbt", "shortboard-centre-sbt", "fish"].map((b, i) => {
  const t = {
    "stock-soft-sbt": ["1. The stock 6'0\", Hard Edge off, the tail's Sharp Bottom Tuck ticked", "Before: the tail's sharp edge (the stripes bunched tight along the rail) stops dead about halfway from the 12\" mark to the centre. After: it holds to Tail Rail Blends From (18\") and fades out by Tail Rail Ends At (30\"). The close-ups are the tail half of the upper rail."],
    "shortboard-centre-sbt": ["2. The Shortboard with the centre's Sharp Bottom Tuck ticked and the nose's not", "Before: the centre's sharp edge stops dead halfway from the centre to the nose 12\" mark. After: it eases into the nose's round edge on its own, between the centre and the nose 12\" mark — no control, nothing saved. The close-ups are the nose half of the upper rail."],
    fish: ["3. The Fish as it opens (its nose rail is a different Family from its centre's)", "Before: a small jog in the stripes halfway between the centre and the nose 12\" mark, where the Family switched. After: the two Families blend and the stripes run on smoothly. The close-ups are the nose half of the upper rail."],
  }[b];
  return `<section><h3>${t[0]}</h3><p>${t[1]}</p>
<div class="row c2">${fig(`bottom-${b}-before-band`, "Before")}${fig(`bottom-${b}-after-band`, "After")}</div>
<div class="row c2" style="margin-top:10px">${fig(`bottom-${b}-before-crop`, "Before, close up")}${fig(`bottom-${b}-after-crop`, "After, close up")}
${fig(`bottom-${b}-before-plain-crop`, "Before, close up, plain shading")}${fig(`bottom-${b}-after-plain-crop`, "After, close up, plain shading")}</div></section>`;
}).join("")}
</body></html>`,
};

const which = process.argv[2];
fs.writeFileSync(path.join(__dirname, `compose-${which}.html`), pages[which]);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto("file://" + path.join(__dirname, `compose-${which}.html`));
  await page.screenshot({ path: process.argv[3], fullPage: true });
  await browser.close();
})();

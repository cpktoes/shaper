# Crops plan 16-15's 3x bottom views to the stretch of rail each row is about (css pixels × 3).
# Usage: python3 -I crop.py   (reads and writes ./out next to this file)
import os
from PIL import Image

here = os.path.dirname(os.path.abspath(__file__))
out = os.path.join(here, "out")
# (left, top, right, bottom) in css pixels of the 804 × 615 viewer: the upper rail edge, tail on the right.
REGIONS = {
    "stock-soft-sbt": (380, 196, 760, 256),
    "shortboard-centre-sbt": (60, 196, 440, 256),
    "fish": (60, 196, 440, 256),
}
for board, (l, t, r, b) in REGIONS.items():
    for when in ("before", "after"):
        for plain in ("", "-plain"):
            name = f"bottom-{board}-{when}{plain}"
            im = Image.open(os.path.join(out, f"{name}.png"))
            im.crop((l * 3, t * 3, r * 3, b * 3)).save(os.path.join(out, f"{name}-crop.png"))
            # The whole board, the empty ground above and below it cut away.
            im.crop((30 * 3, 190 * 3, 774 * 3, 420 * 3)).save(os.path.join(out, f"{name}-band.png"))
            print(name, im.size)

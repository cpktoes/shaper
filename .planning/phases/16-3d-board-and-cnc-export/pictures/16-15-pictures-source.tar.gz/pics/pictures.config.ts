// Scratch config for plan 16-15's pictures: this worktree's dev server on 3215 (after) and the second pin's commit,
// extracted by `git archive` into ../before, on 3216 (before) — both webpack. Run:
//   npx playwright test -c <abs>/pictures.config.ts
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d/playwright.config";
import { defineConfig, devices } from "@playwright/test";

const worktree = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a72417bb1ef634e0d";
const before = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/aca08098-d213-4b0a-9c2f-b7dd43fd982d/scratchpad/e1615/before";
const env = { ...(base.webServer as { env: Record<string, string> }).env, IS_WEBPACK_TEST: "1" };
const server = (cwd: string, port: number) => ({
  command: `npm run dev -- --port ${port}`,
  url: `http://localhost:${port}/design/outline`,
  reuseExistingServer: false,
  timeout: 240_000,
  cwd,
  env,
});

export default defineConfig({
  ...base,
  testDir: __dirname,
  testIgnore: [],
  testMatch: ["shots.spec.ts"],
  outputDir: __dirname + "/test-results",
  timeout: 600_000,
  workers: 1,
  webServer: process.env.ONLY_AFTER ? [server(worktree, 3215)] : [server(worktree, 3215), server(before, 3216)],
  use: { ...base.use, baseURL: "http://localhost:3215" },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 } },
    // The 3D bottom views at three device pixels to the dot, so the rail can be cropped and read up close.
    { name: "desktop3x", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 3 } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
});

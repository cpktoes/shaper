// Scratch (16-15): which tail-rail change, Hard Edge off, moves the stock board's two-decimal litres?
import { DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { summarizeDesign } from "@/lib/geometry/design";
import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { DEFAULT_RAIL_BAND_SPEC, type RailBandSpec, type RailSectionSpec } from "@/lib/geometry/rail-bands";
import { inchesToMm, mm } from "@/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "@/lib/geometry/volume";

const stockFields = { outline: DEFAULT_BOARD_SPEC.outline, rocker: DEFAULT_BOARD_SPEC.rocker, foil: DEFAULT_BOARD_SPEC.foil, rails: DEFAULT_RAIL_BAND_SPEC, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC, blank: null };
const sb = presetDesignFields(BOARD_PRESETS.find((p) => p.name === "Shortboard")!);
const boards = { stock: stockFields, shortboard: { ...sb, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC } };
const changes: Record<string, Partial<RailSectionSpec>> = {
  sbt: { sharpBottomTuck: true },
  single: { singleTuck: true },
  both: { singleTuck: true, sharpBottomTuck: true },
};
for (const [bn, f] of Object.entries(boards)) {
  const L = f.outline.length;
  for (const [cn, ch] of Object.entries(changes)) {
    const rails = (from: number | null, to: number | null): RailBandSpec => ({
      ...f.rails,
      tailHardEdge: false,
      tail: { ...f.rails.tail, ...ch },
      ...(from === null ? {} : { tailHardEdgeBlendsFrom: inchesToMm(from) }),
      ...(to === null ? {} : { tailHardEdgeEndsAt: to === 0 ? mm(L / 2) : inchesToMm(to) }),
    });
    const lit = (from: number | null, to: number | null) => summarizeDesign({ ...f, rails: rails(from, to) }).volumeLitres.toFixed(3);
    console.log(`${bn} ${cn}: default ${lit(null, null)}  end→centre ${lit(null, 0)}  from12/end20 ${lit(12, 20)}  from12/end→centre ${lit(12, 0)}  from30/end→centre ${lit(30, 0)}  from18/end20 ${lit(18, 20)}  from18/end→centre ${lit(18, 0)}`);
  }
}

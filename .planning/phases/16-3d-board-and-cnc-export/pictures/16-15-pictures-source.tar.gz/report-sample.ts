// Scratch (16-15): the rail-character report's lines on the 74 test boards, ids being the boards' labels.
import { phase16LiveBoards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { railCharacterReportLines } from "@/lib/models/rail-character-report";

for (const line of railCharacterReportLines(phase16LiveBoards().map((b) => ({ id: b.label, fields: b.fields })))) console.log(line);

Scratch scripts behind Phase 14's measurements. Not app code and not kept up to date: they import the
app's own modules by absolute path (/Users/kontoes/Code/shaper/...) and were run from the repo root with
  npx tsx --tsconfig ./tsconfig.json <file>        (TypeScript)
  python3 <file>                                   (Python, from inside rk/)
2026-10-02-curve-research/
  rk/        the station tests in Python: models.py (the curve families), smooth.py (bend change at a
             station), inner_curves.py (the three curves inside the square-root rule, and the data for
             pictures/curve-inside-the-rule.png), and the rest of the 2026-10-02 research
  board/     the board probes in TypeScript: lib.ts (prepareRoot = the square-root rule as measured),
             taper.ts, tips.ts, presets.ts, impact.ts
  widget/, widget2/   the two chart fragments shown to the founder on 2026-10-02
2026-10-02-taper-shapes/
  shapes.ts          six taper shapes, each with its own automatic start, scored on the 1,635-board
                     stress set; writes shape-cases.json and preset-rows.json
  render.cjs         draws pictures/tip-taper-three-shapes.png
  render2.cjs        draws pictures/curve-inside-the-rule.png from inner-curves.json
  tape-sheet.cjs     draws arctic-blank-tape-check-sheet.pdf
Kept as an archive so the type checker, the linter and Tailwind's source scan never read them.

Scratch scripts behind Phase 14's measurements. Not app code and not kept up to date: they import the
app's own modules by absolute path (/Users/kontoes/Code/shaper/...) and were run from the repo root with
  npx tsx --tsconfig ./tsconfig.json <file>
2026-10-02-curve-research/  the station tests in Python (rk/), the board probes in TypeScript (board/),
                            and the two chart fragments shown to the founder (widget/, widget2/).
2026-10-02-taper-shapes/    shapes.ts scores six taper shapes on the 1,635-board stress set and writes
                            shape-cases.json; render.cjs draws pictures/tip-taper-three-shapes.png.
Kept as an archive so the type checker, the linter and Tailwind's source scan never read them.

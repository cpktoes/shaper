// Scratch analysis for the Phase 14 discussion: candidate SHAPES for the tip taper, each with its own
// automatic start, scored on the same 1,635-board stress set the 2026-10-02 research used.
// Nothing here is app code; it runs the app's own geometry by absolute import.
import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { writeFileSync } from "node:fs";

const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
type On = ReturnType<typeof boardOnBlank>;
type Curve = (d: number) => number;
export interface Taper { T: Curve; ok: boolean; slopeBreak: number; bendJump: number; tipSlope: number }
export type Shape = (P: Curve, tip: number, W: number) => Taper;

const H = 0.5; // mm, for slopes
const slopeAt = (P: Curve, x: number) => (P(x + H) - P(x - H)) / (2 * H);
/** The planer cut's bend just INSIDE the start (the side the taper has to join). */
const bendInside = (P: Curve, W: number) => { const h = 3; return (P(W + 2 * h) - 2 * P(W + h) + P(W)) / (h * h); };

/** A. Steady taper — one parabola (the research's own formula, unchanged). */
export const parabola: Shape = (P, tip, W) => {
  const PW = P(W), mW = slopeAt(P, W), sec = (PW - tip) / W;
  const m = Math.max(0, Math.min(mW, 2 * sec));
  const a = 2 * sec - m, b = (m - sec) / W;
  return { ok: PW >= tip - 1e-9, slopeBreak: Math.abs(mW - m), bendJump: Math.abs(2 * b - bendInside(P, W)), tipSlope: a,
    T: (d) => (d >= W ? P(d) : tip + a * d + b * d * d) };
};
/** B. Smooth join — one cubic that also matches the planer cut's BEND at the start. */
export const cubic: Shape = (P, tip, W) => {
  const PW = P(W), m = slopeAt(P, W), c = bendInside(P, W);
  const k = (PW - m * W + (c / 2) * W * W - tip) / (W * W * W);
  const T = (d: number) => { const e = d - W; return d >= W ? P(d) : PW + m * e + (c / 2) * e * e + k * e * e * e; };
  return { ok: PW >= tip - 1e-9, slopeBreak: 0, bendJump: 0, tipSlope: m - c * W + 3 * k * W * W, T };
};
/** C. Today's S-blend, moved to the start: the planer cut less (planer cut at the tip − tip setting) × smoothstep. */
export const sblend: Shape = (P, tip, W) => {
  const P0 = P(0), w = (t: number) => { const u = Math.min(1, Math.max(0, t)); return u * u * (3 - 2 * u); };
  const T = (d: number) => (d >= W ? P(d) : P(d) - (P0 - tip) * w(1 - d / W));
  return { ok: P(W) >= tip - 1e-9, slopeBreak: 0, bendJump: Math.abs((6 * (P0 - tip)) / (W * W)), tipSlope: slopeAt(P, H), T };
};
/** D. Power ramp: tip + (rise to the start) × (d/W)^n, n chosen so the slope matches at the start. */
export const power: Shape = (P, tip, W) => {
  const PW = P(W), mW = slopeAt(P, W), sec = (PW - tip) / W;
  const n = sec > 1e-12 ? Math.max(0.05, mW / sec) : 1;
  const T = (d: number) => (d >= W ? P(d) : tip + (PW - tip) * Math.pow(Math.max(d, 0) / W, n));
  const bend = n * (n - 1) * (PW - tip) / (W * W);
  return { ok: PW >= tip - 1e-9 && mW >= 0, slopeBreak: 0, bendJump: Math.abs(bend - bendInside(P, W)), tipSlope: n > 1 ? 0 : n === 1 ? sec : Infinity, T };
};
/** E. Square-law thinning: the planer cut less (planer cut at the tip − tip setting) × (1 − d/W)².
 * Follows the blank's own curve; identical to the parabola when the planer cut is straight. */
export const square: Shape = (P, tip, W) => {
  const P0 = P(0);
  const T = (d: number) => (d >= W ? P(d) : P(d) - (P0 - tip) * (1 - d / W) ** 2);
  return { ok: P(W) >= tip - 1e-9, slopeBreak: 0, bendJump: Math.abs((2 * (P0 - tip)) / (W * W)), tipSlope: slopeAt(P, H) + (2 * (P0 - tip)) / W, T };
};
/** F. Cube-law thinning: the same with (1 − d/W)³ — no change of bend at the start. */
export const cube: Shape = (P, tip, W) => {
  const P0 = P(0);
  const T = (d: number) => (d >= W ? P(d) : P(d) - (P0 - tip) * (1 - d / W) ** 3);
  return { ok: P(W) >= tip - 1e-9, slopeBreak: 0, bendJump: 0, tipSlope: slopeAt(P, H) + (3 * (P0 - tip)) / W, T };
};
export const SHAPES: Record<string, Shape> = { parabola, square, cube, cubic, sblend, power };

const TOL = inch(0.005);
/** Does this taper run down to its tip with no hump, no thin spot and no slope break? */
function steady(t: Taper, tip: number, W: number): boolean {
  if (!t.ok || t.slopeBreak > 1e-6) return false;
  let prev = t.T(0);
  if (Math.abs(prev - tip) > 1e-6) return false;
  for (let d = inch(0.125); d <= W + 1e-9; d += inch(0.125)) {
    const v = t.T(d);
    if (v < prev - 1e-7 || v < tip - 1e-7) return false;
    prev = v;
  }
  return true;
}
/** The first start (>= from, in 1/2" steps) from which the shape runs down steadily; the half-length if none. */
export function autoStart(shape: Shape, P: Curve, tip: number, half: number, from: number): number {
  for (let W = from; W < half; W += inch(0.5)) if (steady(shape(P, tip, W), tip, W)) return W;
  return half;
}

// ---- the stress set, exactly as the research built it ----
const boards: { vendor: string; name: string; c: number; place: string; on: On }[] = [];
for (const record of catalog) {
  const base = prepareBlank(record), prep = prepareNew(record, { thickness: true });
  const L = mm(base.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(base, board, settings).passes) continue;
    const { min, max } = placementRange(base.lengthMm, L);
    for (const [place, p] of [["tail", min], ["centre", mm(0)], ["nose", max]] as const) boards.push({ vendor: record.vendor, name: record.name, c, place, on: boardOnBlank(prep, board, p) });
  }
}
export function ends(on: On) {
  const L = on.board.length, drop = on.blankThicknessAt(L / 2) - on.board.centerThickness;
  return [
    { end: "tail" as const, tip: on.board.tailTip, P: (d: number) => on.blankThicknessAt(d) - drop, half: L / 2, gap: on.centerGap },
    { end: "nose" as const, tip: on.board.noseTip, P: (d: number) => on.blankThicknessAt(L - d) - drop, half: L / 2, gap: on.centerGap },
  ];
}
const pct = (xs: number[], q: number) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(s.length * q))]; };

console.log(`${boards.length} boards, ${boards.length * 2} tips. Each shape with its OWN automatic start (12" unless it cannot run down steadily from there).`);
const summary: Record<string, unknown> = {};
for (const [name, shape] of Object.entries(SHAPES)) {
  let thinB = 0, humpB = 0, pokeB = 0, floorB = 0, differ = 0, flatTips = 0, addTips = 0, steepTips = 0;
  const starts: number[] = [], bend: number[] = [], rise12: number[] = [], tipSl: number[] = [], twoIn: number[] = [];
  const bins = [0, 0, 0, 0, 0];
  for (const b of boards) {
    let thin = 0, hump = 0, pk = 0, fl = 0; const ws: number[] = [];
    for (const e of ends(b.on)) {
      const W = autoStart(shape, e.P, e.tip, e.half, inch(12)); ws.push(W);
      const t = shape(e.P, e.tip, W);
      starts.push(W / IN); bend.push(t.bendJump * IN); // 1/in... (mm/mm^2 * 25.4 = per inch)
      bins[W <= inch(12.01) ? 0 : W <= inch(18) ? 1 : W <= inch(24) ? 2 : W <= inch(36) ? 3 : 4]++;
      if (W > inch(12.01)) rise12.push((t.T(inch(12)) - e.P(inch(12))) / IN);
      const sl = (t.T(inch(0.25)) - t.T(0)) / inch(0.25); tipSl.push(sl);
      if (sl < 0.004) flatTips++; if (sl > 0.25) steepTips++;
      twoIn.push((t.T(inch(2)) - e.tip) / IN);
      if (e.P(0) < e.tip - TOL) addTips++;
      let run = -Infinity;
      for (let d = 0; d <= e.half; d += inch(0.125)) {
        const v = t.T(d);
        thin = Math.max(thin, e.tip - v); run = Math.max(run, v); hump = Math.max(hump, run - v);
        pk = Math.max(pk, -(e.gap + e.P(d) - v)); fl = Math.max(fl, inch(0.25) - v);
      }
    }
    if (thin > TOL) thinB++; if (hump > TOL) humpB++; if (pk > TOL) pokeB++; if (fl > TOL) floorB++;
    if (Math.abs(ws[0] - ws[1]) > inch(0.01)) differ++;
  }
  const line = {
    thinSpotBoards: thinB, humpBoards: humpB, pokeBoards: pokeB, underFloorBoards: floorB,
    startAt12: bins[0], start12to18: bins[1], start18to24: bins[2], start24to36: bins[3], startOver36: bins[4],
    startMax: +Math.max(...starts).toFixed(1), boardsWhoseTwoTipsStartDifferently: differ,
    bendJumpMedian: +pct(bend, 0.5).toExponential(2), bendJump90: +pct(bend, 0.9).toExponential(2),
    rise12Count: rise12.length, rise12Median: rise12.length ? +pct(rise12, 0.5).toFixed(3) : 0, rise12Max: rise12.length ? +Math.max(...rise12).toFixed(3) : 0,
    tipSlopeMedian: +pct(tipSl, 0.5).toFixed(3), flatTips, steepTips,
    twoInAboveTipMedian: +pct(twoIn, 0.5).toFixed(3), twoInAboveTip90: +pct(twoIn, 0.9).toFixed(3),
  };
  summary[name] = line;
  console.log(`\n== ${name} ==`); console.log(JSON.stringify(line, null, 1));
}

{
  // how far apart are the research's parabola and the square-law thinning, at the same start?
  const diffs: number[] = [];
  for (const b of boards) for (const e of ends(b.on)) {
    const W = autoStart(square, e.P, e.tip, e.half, inch(12)); const a = parabola(e.P, e.tip, W), q = square(e.P, e.tip, W);
    let m = 0; for (let d = 0; d <= W; d += inch(0.25)) m = Math.max(m, Math.abs(a.T(d) - q.T(d)));
    diffs.push(m / IN);
  }
  console.log(`\nparabola vs square-law thinning at the same start: median gap ${pct(diffs, 0.5).toFixed(4)} in, 90% ${pct(diffs, 0.9).toFixed(4)} in, max ${Math.max(...diffs).toFixed(4)} in`);
}
// ---- the picture data: three boards, every shape with its own automatic start ----
function pictureCase(title: string, on: On, end: "tail" | "nose", today: On) {
  const e = ends(on).find((x) => x.end === end)!;
  const L = on.board.length, span = Math.min(e.half, inch(48));
  const grid: number[] = []; for (let d = 0; d <= span + 1e-6; d += inch(0.25)) grid.push(d);
  const out: any = { title, tip: e.tip / IN, d: grid.map((d) => +(d / IN).toFixed(2)), P: grid.map((d) => +(e.P(d) / IN).toFixed(4)),
    today: grid.map((d) => +(on.derivedThicknessAt(end === "tail" ? d : L - d) / IN).toFixed(4)),
    todayOldCurves: grid.map((d) => +(today.derivedThicknessAt(end === "tail" ? d : L - d) / IN).toFixed(4)), shapes: {} };
  for (const [name, shape] of Object.entries(SHAPES)) {
    const W = autoStart(shape, e.P, e.tip, e.half, inch(12)); const t = shape(e.P, e.tip, W);
    out.shapes[name] = { start: +(W / IN).toFixed(1), T: grid.map((d) => +(t.T(d) / IN).toFixed(4)),
      at2: +(t.T(inch(2)) / IN).toFixed(3), at6: +(t.T(inch(6)) / IN).toFixed(3), at12: +(t.T(inch(12)) / IN).toFixed(3) };
  }
  return out;
}
const stress = (name: string, vendor: string, c: number, place: "tail" | "centre" | "nose") => {
  const record = catalog.find((r) => r.vendor === vendor && r.name === name)!;
  const base = prepareBlank(record), prep = prepareNew(record, { thickness: true });
  const L = mm(base.lengthMm - inch(2));
  const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
  const { min, max } = placementRange(base.lengthMm, L);
  const p = place === "tail" ? min : place === "nose" ? max : mm(0);
  return { on: boardOnBlank(prep, board, p), old: boardOnBlank(base, board, p) };
};
const presetCase = (re: RegExp) => {
  const preset = BOARD_PRESETS.find((p) => re.test(p.name))!; const f = presetDesignFields(preset), b = f.blank!;
  const input: BoardOnBlankInput = { length: f.outline.length, centerThickness: f.foil.center, noseTip: f.foil.noseTip, tailTip: f.foil.tailTip, nose12Offset: b.nose12Offset, tail12Offset: b.tail12Offset, deckSkin: b.deckSkin, tipStyle: b.tipStyle, fineTuneSurface: b.fineTuneSurface };
  return { name: preset.name, blank: b.copy.name, on: boardOnBlank(prepareNew(b.copy, { thickness: true }), input, b.placement), old: boardOnBlank(prepareBlank(b.copy), input, b.placement) };
};
const cases: any[] = [];
const e1 = stress("10'9\" LB", "Arctic Foam", 2.5, "centre");
cases.push(pictureCase("Arctic 10'9\" LB, 2 1/2\" centre: tail (humps today)", e1.on, "tail", e1.old));
const sb = presetCase(/short/i); cases.push(pictureCase(`${sb.name} preset on US Blanks ${sb.blank}: nose`, sb.on, "nose", sb.old));
const sbt = presetCase(/short/i); cases.push(pictureCase(`${sbt.name} preset on US Blanks ${sbt.blank}: tail`, sbt.on, "tail", sbt.old));
const lb = presetCase(/long/i); cases.push(pictureCase(`${lb.name} preset on US Blanks ${lb.blank}: tail`, lb.on, "tail", lb.old));
const lbn = presetCase(/long/i); cases.push(pictureCase(`${lbn.name} preset on US Blanks ${lbn.blank}: nose`, lbn.on, "nose", lbn.old));
// a mid case: the automatic (parabola) start lands 14-18" — pick the median such tip
const mids: { b: (typeof boards)[number]; end: "tail" | "nose"; W: number }[] = [];
for (const b of boards) for (const e of ends(b.on)) { const W = autoStart(parabola, e.P, e.tip, e.half, inch(12)); if (W >= inch(14) && W <= inch(18)) mids.push({ b, end: e.end, W }); }
mids.sort((x, y) => x.W - y.W);
const mid = mids[mids.length >> 1];
if (mid) { const s = stress(mid.b.name, mid.b.vendor, mid.b.c, mid.b.place as any); cases.push(pictureCase(`${mid.b.vendor} ${mid.b.name}, ${mid.b.c}" centre, ${mid.b.place}: ${mid.end}`, s.on, mid.end, s.old)); }
writeFileSync(new URL("./shape-cases.json", import.meta.url), JSON.stringify({ summary, cases }));
console.log("\n-- picture cases --");
for (const c of cases) console.log(`${c.title} | tip ${c.tip} | planer cut at tip ${c.P[0]} at 12" ${c.P[48]} | ` + Object.entries(c.shapes).map(([n, s]: any) => `${n}: start ${s.start}" 2"=${s.at2} 6"=${s.at6} 12"=${s.at12}`).join(" | "));

// ---- the four presets: litres and the last foot, today's tip rule vs each shape (new curves in every column) ----
import { buildBoardProfile } from "/Users/kontoes/Code/shaper/lib/geometry/board-profile";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { deriveEffectiveRails } from "/Users/kontoes/Code/shaper/lib/geometry/design";
import { computeCrossSectionVolume } from "/Users/kontoes/Code/shaper/lib/geometry/volume";
console.log("\n-- presets: litres and thickness 2\" / 6\" in from each tip (new curves in every column) --");
const presetRows: any[] = [];
for (const preset of BOARD_PRESETS) {
  const f = presetDesignFields(preset), b = f.blank!, L = f.outline.length, outline = buildOutline(f.outline);
  const prepared = prepareNew(b.copy, { thickness: true });
  const profile = buildBoardProfile({ length: L, rocker: f.rocker, foil: f.foil, blank: { prepared, placement: b.placement, nose12Offset: b.nose12Offset, tail12Offset: b.tail12Offset, deckSkin: b.deckSkin, tipStyle: b.tipStyle, fineTuneSurface: b.fineTuneSurface } } as any);
  const input: BoardOnBlankInput = { length: L, centerThickness: f.foil.center, noseTip: f.foil.noseTip, tailTip: f.foil.tailTip, nose12Offset: b.nose12Offset, tail12Offset: b.tail12Offset, deckSkin: b.deckSkin, tipStyle: b.tipStyle, fineTuneSurface: b.fineTuneSurface };
  const on = boardOnBlank(prepared, input, b.placement);
  const rails = deriveEffectiveRails(f.rails, profile.effectiveFoil, true);
  const litresWith = (thicknessAt: (s: number) => number) => computeCrossSectionVolume({ halfWidthAt: (s: any) => sampleOutline(outline, s), foil: profile.effectiveFoil, thicknessAt: thicknessAt as any, rails, length: L } as any).volumeLitres;
  const [tail, nose] = ends(on);
  const row: any = { preset: preset.name, blank: b.copy.name, today: { litres: +litresWith(profile.thicknessAt as any).toFixed(3), tail2: +(on.derivedThicknessAt(inch(2)) / IN).toFixed(3), tail6: +(on.derivedThicknessAt(inch(6)) / IN).toFixed(3), nose6: +(on.derivedThicknessAt(L - inch(6)) / IN).toFixed(3), nose2: +(on.derivedThicknessAt(L - inch(2)) / IN).toFixed(3) } };
  for (const name of ["square", "cube", "parabola"]) {
    const shape = SHAPES[name];
    const Wt = autoStart(shape, tail.P, tail.tip, tail.half, inch(12)), Wn = autoStart(shape, nose.P, nose.tip, nose.half, inch(12));
    const tt = shape(tail.P, tail.tip, Wt), tn = shape(nose.P, nose.tip, Wn);
    const derived = (s: number) => (s <= L / 2 ? tt.T(s) : tn.T(L - s));
    const thicknessAt = (s: number) => (profile.thicknessAt as any)(s) + (derived(s) - on.derivedThicknessAt(s));
    row[name] = { litres: +litresWith(thicknessAt).toFixed(3), startTail: +(Wt / IN).toFixed(1), startNose: +(Wn / IN).toFixed(1), tail2: +(tt.T(inch(2)) / IN).toFixed(3), tail6: +(tt.T(inch(6)) / IN).toFixed(3), nose6: +(tn.T(inch(6)) / IN).toFixed(3), nose2: +(tn.T(inch(2)) / IN).toFixed(3) };
  }
  presetRows.push(row);
  console.log(JSON.stringify(row));
}
writeFileSync(new URL("./preset-rows.json", import.meta.url), JSON.stringify(presetRows));

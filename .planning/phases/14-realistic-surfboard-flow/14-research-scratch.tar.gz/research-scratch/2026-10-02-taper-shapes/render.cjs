// Renders the side-by-side taper pictures for the Phase 14 discussion from shape-cases.json.
const fs = require("fs");
const path = require("path");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");

const here = __dirname;
const { cases } = JSON.parse(fs.readFileSync(path.join(here, "shape-cases.json"), "utf8"));

const ROWS = [
  { i: 0, xmax: 48, label: "A longboard tail that humps today", sub: "Arctic 10'9\" LB cut to a 2 1/2\" centre, 5/8\" tail tip" },
  { i: 5, xmax: 30, label: "A tail that needs a little more run", sub: "Arctic 9'4\" G cut to a 2 1/2\" centre, slid to the tail, 5/8\" tail tip" },
  { i: 1, xmax: 24, label: "An ordinary nose (nothing wrong today)", sub: "Shortboard preset on US Blanks 6'3\"RP, 7/16\" nose tip" },
];
const COLS = [
  { key: "parabola", name: "1. Steady taper", note: "One even curve from the start to the tip" },
  { key: "cubic", name: "2. Soft start", note: "Leaves the planer cut more gradually; needs a longer run" },
  { key: "sblend", name: "3. Today's S-shape", note: "Today's blend, started further in where it has to be" },
];

function frac(v) {
  const n = Math.round(v * 16); const whole = Math.floor(n / 16); let num = n % 16; let den = 16;
  while (num && num % 2 === 0) { num /= 2; den /= 2; }
  if (!num) return `${whole}"`;
  return `${whole ? whole + " " : ""}${num}/${den}"`;
}
const at = (c, arr, inches) => arr[Math.round(inches / 0.25)];
const same = (c, s) => s.T.every((v, k) => Math.abs(v - c.today[k]) < 0.002);

const PW = 440, PH = 300, ML = 46, MR = 14, MT = 14, MB = 36;
function panel(c, col, row) {
  const s = c.shapes[col.key];
  const n = Math.round(row.xmax / 0.25) + 1;
  const ymaxRaw = Math.max(...c.P.slice(0, n), ...s.T.slice(0, n), c.tip);
  const ymax = Math.ceil(ymaxRaw * 2) / 2;
  const X = (d) => ML + (d / row.xmax) * (PW - ML - MR);
  const Y = (v) => MT + (1 - Math.max(0, v) / ymax) * (PH - MT - MB);
  const line = (arr) => arr.slice(0, n).map((v, k) => `${k ? "L" : "M"}${X(c.d[k]).toFixed(1)},${Y(v).toFixed(1)}`).join("");
  let g = "";
  for (let y = 0; y <= ymax + 1e-9; y += 0.5) g += `<line x1="${ML}" x2="${PW - MR}" y1="${Y(y)}" y2="${Y(y)}" class="grid"/><text x="${ML - 6}" y="${Y(y) + 4}" class="tick" text-anchor="end">${y % 1 ? y.toFixed(1) : y}</text>`;
  for (let x = 0; x <= row.xmax; x += 6) g += `<text x="${X(x)}" y="${PH - MB + 16}" class="tick" text-anchor="middle">${x}</text>`;
  const startX = X(Math.min(s.start, row.xmax));
  const shown = s.start <= row.xmax;
  return `<svg viewBox="0 0 ${PW} ${PH}" width="${PW}" height="${PH}">
    ${g}
    <text x="${(ML + PW - MR) / 2}" y="${PH - 4}" class="axis" text-anchor="middle">inches in from the tip</text>
    ${shown ? `<line x1="${startX}" x2="${startX}" y1="${MT}" y2="${PH - MB}" class="start"/>` : ""}
    <path d="${line(c.P)}" class="planer"/>
    <path d="${line(c.today)}" class="today"/>
    <path d="${line(s.T)}" class="board"/>
    <circle cx="${X(0)}" cy="${Y(c.tip)}" r="4.5" class="tip"/>
  </svg>
  <p class="cap"><b>Thinning starts ${frac(s.start).replace('"', "")} in from the tip.</b> Thickness 2 in from the tip ${frac(at(c, s.T, 2))}, 6 in ${frac(at(c, s.T, 6))}, 12 in ${frac(at(c, s.T, 12))}.${same(c, s) ? " The same as today." : ""}</p>`;
}

let body = `<h1>Tip taper: three shapes, side by side</h1>
<p class="lede">Each column is one way to run the board's thickness down to its tip setting. Each one starts 12 in from the tip unless it cannot run down steadily from there; then it starts as far in as it needs.</p>
<div class="legend">
  <span><i class="k board"></i>The board with this shape</span>
  <span><i class="k today"></i>Today's blend, always from 12 in</span>
  <span><i class="k planer"></i>What the level planer cut leaves</span>
  <span><i class="dot"></i>Tip setting</span>
  <span><i class="k start"></i>Where the thinning starts</span>
</div>
<div class="grid3 head">${COLS.map((c) => `<div><h2>${c.name}</h2><p>${c.note}</p></div>`).join("")}</div>`;
for (const row of ROWS) {
  const c = cases[row.i];
  body += `<h3>${row.label} <span>${row.sub}. Today: 2 in ${frac(at(c, c.today, 2))}, 6 in ${frac(at(c, c.today, 6))}, 12 in ${frac(at(c, c.today, 12))}.</span></h3>
  <div class="grid3">${COLS.map((col) => `<div class="cell">${panel(c, col, row)}</div>`).join("")}</div>`;
}
body += `<p class="foot">Thickness in inches, up the side. Readings are to the nearest 1/16". Every line here is drawn on the new blank curves, so the only difference between them is the taper. Measured with the app's own board maths; nothing is built yet.</p>`;

const css = `
  *{box-sizing:border-box} body{margin:0;padding:28px 30px 26px;background:#fff;color:#1f2a3b;font:15px/1.45 -apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif;width:1420px}
  h1{font-size:25px;margin:0 0 6px} .lede{margin:0 0 12px;color:#4a5568;max-width:1100px}
  .legend{display:flex;gap:22px;flex-wrap:wrap;margin:0 0 14px;font-size:14px;color:#2d3748}
  .legend span{display:inline-flex;align-items:center;gap:7px}
  .k{display:inline-block;width:26px;height:0;border-top:3px solid #2a6fdb} .k.today{border-top:3px dashed #e8590c} .k.planer{border-top:3px solid #8a9099} .k.start{border-top:0;border-left:2px solid #9aa3ad;height:16px;width:0}
  .dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#111}
  .grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
  .head h2{font-size:18px;margin:0} .head p{margin:2px 0 4px;color:#4a5568;font-size:14px}
  h3{font-size:16px;margin:14px 0 6px} h3 span{font-weight:400;color:#4a5568;font-size:14px;margin-left:6px}
  .cell{border:1px solid #dfe3e8;border-radius:8px;padding:6px 6px 2px}
  svg{display:block;width:100%;height:auto}
  .grid{stroke:#e6e9ee;stroke-width:1} .tick{font-size:11.5px;fill:#6b7480} .axis{font-size:11.5px;fill:#6b7480}
  .planer{fill:none;stroke:#8a9099;stroke-width:2} .today{fill:none;stroke:#e8590c;stroke-width:2.2;stroke-dasharray:6 4} .board{fill:none;stroke:#2a6fdb;stroke-width:2.8}
  .tip{fill:#111} .start{stroke:#9aa3ad;stroke-width:1.5}
  .cap{margin:2px 6px 8px;font-size:13.5px;color:#2d3748} .cap b{font-weight:600}
  .foot{margin:12px 0 0;color:#6b7480;font-size:13px}
`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>${css}</style></head><body>${body}</body></html>`;
fs.writeFileSync(path.join(here, "taper-shapes.html"), html);

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1420, height: 900 }, deviceScaleFactor: 2 });
  await page.setContent(html);
  await page.screenshot({ path: path.join(here, "tip-taper-three-shapes.png"), fullPage: true });
  await browser.close();
  console.log("wrote tip-taper-three-shapes.png");
})();

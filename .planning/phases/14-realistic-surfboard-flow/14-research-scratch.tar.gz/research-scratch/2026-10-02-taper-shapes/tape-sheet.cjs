// Renders the one-page tape-measure sheet (Phase 14, D-08) as a Letter PDF plus a PNG to look at.
const path = require("path");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const out = process.argv[2];

const marks = []; for (let i = 0; i <= 132; i += 6) marks.push(i);
const left = marks.slice(0, 12), right = marks.slice(12);
const label = (i) => (i === 0 ? '0" (tail tip)' : `${i}"`);
const block = (rows, withNose) => `<table>
  <thead><tr><th>From the tail tip</th><th>Gap to the bottom</th><th>Thickness<br><span>optional</span></th></tr></thead>
  <tbody>${rows.map((i) => `<tr><td>${label(i)}</td><td></td><td></td></tr>`).join("")}
  ${withNose ? `<tr class="nose"><td>Nose tip, at <i></i></td><td></td><td></td></tr>` : ""}</tbody></table>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  @page { size: Letter; margin: 0.55in 0.6in; }
  *{box-sizing:border-box} body{margin:0;color:#111;font:11.5pt/1.38 -apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif}
  h1{font-size:19pt;margin:0} .sub{color:#555;font-size:10pt;margin:2px 0 12px}
  .fields{display:grid;grid-template-columns:1.1fr 1.6fr 1fr 0.9fr;gap:14px;margin:0 0 12px}
  .fields div{border-bottom:1px solid #111;padding:14px 0 3px;font-size:9pt;color:#555}
  h2{font-size:12pt;margin:10px 0 4px}
  ol{margin:0 0 6px 18px;padding:0} li{margin:0 0 3px}
  .ticks{display:flex;gap:26px;margin:4px 0 2px;font-size:10.5pt;flex-wrap:wrap}
  .ticks b{font-weight:600;margin-right:4px} .box{display:inline-block;width:11px;height:11px;border:1.2px solid #111;margin:0 5px -1px 10px}
  .cols{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-top:8px;align-items:start}
  table{width:100%;border-collapse:collapse;font-size:10.5pt}
  th{font-size:9pt;text-align:left;border-bottom:1.4px solid #111;padding:3px 6px;vertical-align:bottom} th span{font-weight:400;color:#555}
  td{border-bottom:1px solid #999;height:23px;padding:2px 6px} td:first-child{width:36%;font-weight:600} td:nth-child(2){width:34%;border-left:1px solid #ccc;border-right:1px solid #ccc}
  tr.nose td:first-child{font-weight:600;white-space:nowrap} tr.nose i{display:inline-block;width:34px;border-bottom:1px solid #111;margin:0 0 -2px 4px}
  .note{margin:10px 0 0;font-size:10pt;color:#333} .foot{margin-top:8px;font-size:9pt;color:#666}
</style></head><body>
  <h1>Blank bottom check: tape-measure sheet</h1>
  <div class="sub">Shaper Assistant · one blank per sheet · gaps to the nearest 1/16"</div>
  <div class="fields"><div>Maker</div><div>Blank name, as printed on it</div><div>Length, tip to tip</div><div>Date</div></div>

  <h2>How to measure</h2>
  <ol>
    <li><b>Pick one straight reference and keep it for the whole blank.</b> Bottom up on stands with a tight string or a straightedge along the stringer, or bottom down on a flat floor or bench, wedged so it cannot rock.</li>
    <li><b>Hook the tape on the tail tip</b> and mark the stringer every 6" all the way to the nose.</li>
    <li><b>At each mark, measure the gap</b> between the reference and the foam of the bottom, square to the reference. Write it beside that mark.</li>
    <li><b>The nose tip gets its own row:</b> its distance from the tail tip and its gap.</li>
    <li><b>Optional:</b> the blank's thickness at each mark, with calipers.</li>
  </ol>
  <div class="ticks"><span><b>Reference used:</b><i class="box"></i>string or straightedge, bottom up<i class="box"></i>flat floor or bench, bottom down</span></div>
  <div class="ticks"><span><b>Tape laid:</b><i class="box"></i>along the foam<i class="box"></i>held straight</span></div>

  <div class="cols">${block(left, false)}${block(right, true)}</div>

  <p class="note">It does not matter if the blank sits a little tilted, or which of the two references you use: the check allows for that. What matters is one reference for the whole blank and a gap at every mark. Stop at the last mark your blank reaches.</p>
  <p class="foot">Phase 14, decision D-08. Send a photo of the filled-in sheet, or the numbers, to the Shaper session; they are checked against the app's curve for that blank between its printed stations.</p>
</body></html>`;

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 816, height: 1056 } });
  await page.setContent(html);
  await page.pdf({ path: path.join(out, "arctic-blank-tape-check-sheet.pdf"), format: "Letter", printBackground: true, preferCSSPageSize: true });
  await page.emulateMedia({ media: "print" });
  await page.screenshot({ path: path.join(__dirname, "tape-sheet-preview.png"), fullPage: true });
  await browser.close();
  console.log("wrote the sheet");
})();

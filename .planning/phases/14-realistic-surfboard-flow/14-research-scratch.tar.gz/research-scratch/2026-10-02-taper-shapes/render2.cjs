// Renders "the curve inside the square-root rule" picture from inner-curves.json.
const fs = require("fs");
const path = require("path");
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const here = __dirname;
const cases = JSON.parse(fs.readFileSync(path.join(here, "inner-curves.json"), "utf8"));

const KEYS = [
  { k: "today", cls: "today", name: "Today's curve (no square-root rule)" },
  { k: "pchip", cls: "c1", name: "1. Today's curve inside the rule" },
  { k: "steffen", cls: "c2", name: "2. Steffen's curve inside the rule" },
  { k: "hyman", cls: "c3", name: "3. Smoothest cubic inside the rule" },
];
const PW = 450, PH = 300, ML = 46, MR = 12, MT = 12, MB = 34;
const ft = (inches) => `${Math.floor(inches / 12)}'`;

function chart(c, kind) {
  const x0 = c.x[0], x1 = c.x[c.x.length - 1];
  const xs = kind === "rocker" ? c.x : c.bx;
  const series = kind === "rocker" ? c.y : c.bend;
  let lo = Infinity, hi = -Infinity;
  for (const { k } of KEYS) for (const v of series[k]) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
  if (kind === "rocker") { lo = 0; hi = Math.ceil(hi); } else { const m = Math.max(Math.abs(lo), Math.abs(hi)); lo = Math.min(0, -m * 0.25); hi = m * 1.05; lo = Math.min(lo, Math.min(...KEYS.flatMap(({ k }) => series[k]))); }
  const X = (x) => ML + ((x - x0) / (x1 - x0)) * (PW - ML - MR);
  const Y = (v) => MT + (1 - (v - lo) / (hi - lo)) * (PH - MT - MB);
  const d = (arr) => arr.map((v, i) => `${i ? "L" : "M"}${X(xs[i]).toFixed(1)},${Y(v).toFixed(1)}`).join("");
  let g = "";
  if (kind === "rocker") for (let y = 0; y <= hi + 1e-9; y += hi > 6 ? 2 : 1) g += `<line x1="${ML}" x2="${PW - MR}" y1="${Y(y)}" y2="${Y(y)}" class="grid"/><text x="${ML - 6}" y="${Y(y) + 4}" class="tick" text-anchor="end">${y}"</text>`;
  else g += `<line x1="${ML}" x2="${PW - MR}" y1="${Y(0)}" y2="${Y(0)}" class="grid"/><text x="${ML - 6}" y="${Y(0) + 4}" class="tick" text-anchor="end">flat</text><text x="${ML - 6}" y="${MT + 10}" class="tick" text-anchor="end">hard</text>`;
  for (let x = Math.ceil(x0 / 12) * 12; x <= x1; x += 12) g += `<text x="${X(x)}" y="${PH - MB + 15}" class="tick" text-anchor="middle">${ft(x)}</text>`;
  const stationMarks = c.xs.map((x, i) => kind === "rocker"
    ? `<circle cx="${X(x)}" cy="${Y(c.ys[i] - Math.min(...c.ys) + (kind === "rocker" ? Math.min(...c.ys) : 0))}" r="3.6" class="st"/>`
    : `<line x1="${X(x)}" x2="${X(x)}" y1="${MT}" y2="${PH - MB}" class="stline"/>`).join("");
  return `<svg viewBox="0 0 ${PW} ${PH}" width="${PW}" height="${PH}">${g}
    ${kind === "bend" ? stationMarks : ""}
    ${KEYS.map(({ k, cls }) => `<path d="${d(series[k])}" class="ln ${cls}"/>`).join("")}
    ${kind === "rocker" ? stationMarks : ""}
    <text x="${(ML + PW - MR) / 2}" y="${PH - 3}" class="tick" text-anchor="middle">${kind === "rocker" ? "feet from the tail" : "feet from the tail (grey lines: the printed stations)"}</text>
  </svg>`;
}
const frac = (v) => { const n = Math.round(v * 32); if (!n) return 'under 1/32"'; let num = n, den = 32; while (num % 2 === 0) { num /= 2; den /= 2; } return num >= den ? `${Math.floor(num / den)}${num % den ? " " + (num % den) + "/" + den : ""}"` : `${num}/${den}"`; };

let body = `<h1>The curve inside the square-root rule: three choices</h1>
<p class="lede">The rule takes the square root of each station's lift, runs a curve through those, and squares the result. This picture is about which curve runs in the middle. All three pass exactly through every printed station and score the same against real blanks' hidden stations (0.035 to 0.036 in average miss).</p>
<div class="legend">${KEYS.map(({ cls, name }) => `<span><i class="k ${cls}"></i>${name}</span>`).join("")}<span><i class="dot"></i>Printed station</span></div>
<div class="grid3 head">${cases.map((c) => `<div><h2>${c.title}</h2><p>${c.stations} printed stations. Furthest apart anywhere: 2 from 1 by ${frac(c.gap.steffen)}, 3 from 1 by ${frac(c.gap.hyman)}.</p></div>`).join("")}</div>
<h3>The blank's bottom rocker <span>height above the lowest station</span></h3>
<div class="grid3">${cases.map((c) => `<div class="cell">${chart(c, "rocker")}</div>`).join("")}</div>
<h3>How hard the bottom bends along the blank <span>a step in a line here is a change of bend at a station: the "sharp" look</span></h3>
<div class="grid3">${cases.map((c) => `<div class="cell">${chart(c, "bend")}</div>`).join("")}</div>
<p class="foot">The Arctic and Marko blanks shown are the ones where choices 1 and 2 differ most; the US Blanks one is where they differ most among blanks with many stations. Nothing is built yet.</p>`;
const css = `
  *{box-sizing:border-box} body{margin:0;padding:28px 30px 24px;background:#fff;color:#1f2a3b;font:15px/1.45 -apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif;width:1470px}
  h1{font-size:25px;margin:0 0 6px} .lede{margin:0 0 12px;color:#4a5568;max-width:1180px}
  .legend{display:flex;gap:22px;flex-wrap:wrap;margin:0 0 12px;font-size:14px;color:#2d3748} .legend span{display:inline-flex;align-items:center;gap:7px}
  .k{display:inline-block;width:28px;height:0;border-top:3px solid #2a6fdb} .k.today{border-top:3px dashed #8a9099} .k.c2{border-top-color:#1a9c5b} .k.c3{border-top-color:#c2410c}
  .dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:#111}
  .grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px} .head h2{font-size:17px;margin:0} .head p{margin:2px 0 2px;color:#4a5568;font-size:13.5px}
  h3{font-size:16px;margin:14px 0 6px} h3 span{font-weight:400;color:#4a5568;font-size:14px;margin-left:6px}
  .cell{border:1px solid #dfe3e8;border-radius:8px;padding:6px 6px 2px} svg{display:block;width:100%;height:auto}
  .grid{stroke:#e6e9ee;stroke-width:1} .tick{font-size:11.5px;fill:#6b7480}
  .ln{fill:none;stroke-width:2.2} .ln.today{stroke:#8a9099;stroke-dasharray:6 4} .ln.c1{stroke:#2a6fdb} .ln.c2{stroke:#1a9c5b} .ln.c3{stroke:#c2410c}
  .st{fill:#111} .stline{stroke:#d4d9df;stroke-width:1}
  .foot{margin:12px 0 0;color:#6b7480;font-size:13px}`;
const html = `<!doctype html><html><head><meta charset="utf-8"><style>${css}</style></head><body>${body}</body></html>`;
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1470, height: 900 }, deviceScaleFactor: 2 });
  await page.setContent(html);
  await page.screenshot({ path: path.join(here, "curve-inside-the-rule.png"), fullPage: true });
  await browser.close();
  console.log("wrote curve-inside-the-rule.png");
})();

const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
const dir = __dirname;
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  for (const mode of ['light', 'dark']) {
    const page = await browser.newPage({ viewport: { width: 712, height: 520 }, deviceScaleFactor: 2 });
    page.on('console', (m) => { if (m.type() === 'error') errors.push(mode + ': ' + m.text()); });
    page.on('pageerror', (e) => errors.push(mode + ': ' + e.message));
    await page.goto('file://' + dir + '/preview-' + mode + '.html');
    await page.waitForFunction(() => window.Chart && document.querySelector('#rk-read').textContent.length > 0, null, { timeout: 15000 });
    await page.waitForTimeout(300);
    await page.screenshot({ path: dir + '/shot-' + mode + '-0.png', fullPage: true });
    if (mode === 'light') {
      for (const i of [1, 2, 3, 4, 5]) {
        await page.selectOption('#rk-blank', String(i));
        await page.waitForTimeout(150);
        await page.screenshot({ path: dir + '/shot-light-' + i + '.png', fullPage: true });
        console.log(i, await page.textContent('#rk-read'));
      }
      await page.selectOption('#rk-blank', '0');
      const box = await page.locator('#rk-chart').boundingBox();
      await page.mouse.move(box.x + box.width * 0.705, box.y + box.height * 0.5);
      await page.waitForTimeout(200);
      await page.screenshot({ path: dir + '/shot-light-hover.png', fullPage: true });
    }
    console.log(mode, await page.textContent('#rk-read'));
    await page.close();
  }
  console.log('errors:', JSON.stringify(errors));
  await browser.close();
})();

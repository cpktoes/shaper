function slopes(xs, ys) {
  const n = xs.length, h = [], d = [];
  for (let k = 0; k < n - 1; k++) { h.push(xs[k + 1] - xs[k]); d.push((ys[k + 1] - ys[k]) / h[k]); }
  if (n === 2) return [d[0], d[0]];
  const m = new Array(n).fill(0);
  for (let k = 1; k < n - 1; k++) {
    const a = d[k - 1], b = d[k];
    if (a === 0 || b === 0 || (a > 0) !== (b > 0)) continue;
    const w1 = 2 * h[k] + h[k - 1], w2 = h[k] + 2 * h[k - 1];
    m[k] = (w1 + w2) / (w1 / a + w2 / b);
  }
  const end = (h0, h1, d0, d1) => {
    const s = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1);
    if (Math.sign(s) !== Math.sign(d0)) return 0;
    if (Math.sign(d0) !== Math.sign(d1) && Math.abs(s) > Math.abs(3 * d0)) return 3 * d0;
    return s;
  };
  m[0] = end(h[0], h[1], d[0], d[1]);
  m[n - 1] = end(h[n - 2], h[n - 3], d[n - 2], d[n - 3]);
  return m;
}
function pchip(xs, ys) {
  const m = slopes(xs, ys), n = xs.length;
  return (x) => {
    if (x <= xs[0]) return ys[0];
    if (x >= xs[n - 1]) return ys[n - 1];
    let k = 0;
    while (xs[k + 1] <= x) k++;
    const w = xs[k + 1] - xs[k], t = (x - xs[k]) / w, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * ys[k] + (t3 - 2 * t2 + t) * w * m[k] + (-2 * t3 + 3 * t2) * ys[k + 1] + (t3 - t2) * w * m[k + 1];
  };
}
function rootPchip(xs, ys) {
  const lo = Math.min(...ys), first = ys.indexOf(lo);
  const g = pchip(xs, ys.map((y, i) => (i < first ? -1 : 1) * Math.sqrt(Math.max(y - lo, 0))));
  return (x) => lo + g(x) ** 2;
}
if (typeof module !== 'undefined') module.exports = { pchip, rootPchip };

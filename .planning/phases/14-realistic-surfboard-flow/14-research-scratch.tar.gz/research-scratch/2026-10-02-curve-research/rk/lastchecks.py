import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats, shape
us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
def fit_sqrt_pchip(xs, ys):
    lo = min(ys); first = ys.index(lo)
    s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
    g = fit_pchip(list(xs), s)
    return lambda x: lo + g(x) ** 2
two = {'today': fit_pchip, 'sqrt': fit_sqrt_pchip}
print('(a) 9-station pattern with T48/N48 and no 36 — by hidden station, mean miss and bias (today | sqrt)')
_, out = run(dense, 'T0 T12 T24 T48 C N48 N24 N12 N0', two)
for lab in ['T6', 'T18', 'T36', 'N36', 'N18', 'N6']:
    row = f'   {lab:>4s}'
    for k in two:
        e = [r[4]-r[3] for r in out[k] if r[1] == lab]
        row += f'   {k}: mean|e| {sum(abs(v) for v in e)/len(e):.3f} bias {sum(e)/len(e):+.3f}'
    print(row + f'   (n={len(e)})')

print('\n(b) does the curve go below the lowest printed station? (thinned dense US curves, 5 stations | the 33 real Arctic blanks)')
chk = collections.OrderedDict([('pchip (today)', fit_pchip), ('square-root pchip', fit_sqrt_pchip), ('Hyman monotone C2', fit_hyman), ('Steffen', fit_steffen),
    ('Akima', fit_akima), ('cubic spline, not-a-knot', fit_notaknot), ('cubic spline, natural', fit_natural), ('Catmull-Rom (3pt)', fit_fd), ('clamped natural + level centre', fit_flat_nat)])
a = shape(dense, 'T0 T12 C N12 N0', chk)
for k, fit in chk.items():
    dips = 0; deep = 0.0
    for b in ar:
        f = fit(b['xs'], b['ys']); n = int(b['length'] / 0.1)
        m = min(f(b['xs'][0] + i * (b['xs'][-1] - b['xs'][0]) / n) for i in range(n + 1))
        d = min(b['ys']) - m
        if d > 1e-4: dips += 1
        deep = max(deep, d)
    print(f'   {k:32s} thinned US: {a[k]["dips"]:2d} of {a[k]["n"]} (deepest {a[k]["worst_dip"]:.3f} in)   Arctic: {dips:2d} of {len(ar)} (deepest {deep:.3f} in)   kink at stations (median curvature jump) {a[k]["jump_med"]:.4f}')

print('\n(d) the one curve where today is closer than the square-root curve, 5-station pattern')
_, out = run(dense, 'T0 T12 C N12 N0', two)
per = collections.defaultdict(lambda: collections.defaultdict(list))
for k in two:
    for r in out[k]: per[r[0]][k].append(abs(r[4]-r[3]))
for name, d in per.items():
    t, s = sum(d['today'])/len(d['today']), sum(d['sqrt'])/len(d['sqrt'])
    if s >= t: print(f'   {name}: today {t:.3f}  sqrt {s:.3f}')
tot = collections.Counter()
for name, d in per.items():
    t, s = sum(d['today'])/len(d['today']), sum(d['sqrt'])/len(d['sqrt'])
    tot['halved or better'] += s <= t/2
print('   curves where the average miss is at least halved:', tot['halved or better'], 'of', len(per))
print('   blanks behind the 68 curves:', sum(len(b['sisters']) for b in dense))

"""Candidate curve models for a blank's rocker. Pure Python (no numpy on this Mac).

Every model is `fit(xs, ys) -> f(x)` and passes exactly through every knot it is given.
Inches throughout (this is an analysis script, not app code).
"""
import math
from bisect import bisect_right


# ---------------------------------------------------------------- helpers
def secants(xs, ys):
    h = [xs[i + 1] - xs[i] for i in range(len(xs) - 1)]
    d = [(ys[i + 1] - ys[i]) / h[i] for i in range(len(xs) - 1)]
    return h, d


def sign(v):
    return (v > 0) - (v < 0)


def hermite(xs, ys, ms):
    """Piecewise cubic Hermite through (xs, ys) with knot slopes ms. Clamps past the ends."""
    xs = list(xs)
    ys = list(ys)
    ms = list(ms)
    n = len(xs)

    def f(x):
        if n == 0:
            return 0.0
        if n == 1 or x <= xs[0]:
            return ys[0]
        if x >= xs[-1]:
            return ys[-1]
        k = bisect_right(xs, x) - 1
        w = xs[k + 1] - xs[k]
        t = (x - xs[k]) / w
        t2 = t * t
        t3 = t2 * t
        return (
            (2 * t3 - 3 * t2 + 1) * ys[k]
            + (t3 - 2 * t2 + t) * w * ms[k]
            + (-2 * t3 + 3 * t2) * ys[k + 1]
            + (t3 - t2) * w * ms[k + 1]
        )

    f.xs, f.ys, f.ms = xs, ys, ms
    return f


def solve(a, b):
    """Dense Gaussian elimination with partial pivoting (systems here are at most ~20 wide)."""
    n = len(b)
    m = [row[:] + [b[i]] for i, row in enumerate(a)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(m[r][c]))
        if abs(m[p][c]) < 1e-14:
            raise ZeroDivisionError("singular system")
        m[c], m[p] = m[p], m[c]
        for r in range(c + 1, n):
            k = m[r][c] / m[c][c]
            if k:
                for j in range(c, n + 1):
                    m[r][j] -= k * m[c][j]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        x[r] = (m[r][n] - sum(m[r][j] * x[j] for j in range(r + 1, n))) / m[r][r]
    return x


# ---------------------------------------------------------------- slope rules
def slopes_pchip(xs, ys):
    """The app's own rule (lib/geometry/pchip.ts), ported line for line."""
    n = len(xs)
    if n == 0:
        return []
    if n == 1:
        return [0.0]
    h, d = secants(xs, ys)
    if n == 2:
        return [d[0], d[0]]
    m = [0.0] * n
    for k in range(1, n - 1):
        a, b = d[k - 1], d[k]
        if a == 0 or b == 0 or (a > 0) != (b > 0):
            continue
        w1 = 2 * h[k] + h[k - 1]
        w2 = h[k] + 2 * h[k - 1]
        m[k] = (w1 + w2) / (w1 / a + w2 / b)

    def end(h0, h1, d0, d1):
        s = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1)
        if sign(s) != sign(d0):
            return 0.0
        if sign(d0) != sign(d1) and abs(s) > abs(3 * d0):
            return 3 * d0
        return s

    m[0] = end(h[0], h[1], d[0], d[1])
    m[-1] = end(h[-1], h[-2], d[-1], d[-2])
    return m


def slopes_fd(xs, ys):
    """Three-point (parabola) tangents — the non-uniform Catmull-Rom / 'Bessel' rule."""
    n = len(xs)
    h, d = secants(xs, ys)
    if n == 2:
        return [d[0], d[0]]
    m = [0.0] * n
    for k in range(1, n - 1):
        m[k] = (d[k - 1] * h[k] + d[k] * h[k - 1]) / (h[k - 1] + h[k])
    m[0] = ((2 * h[0] + h[1]) * d[0] - h[0] * d[1]) / (h[0] + h[1])
    m[-1] = ((2 * h[-1] + h[-2]) * d[-1] - h[-1] * d[-2]) / (h[-1] + h[-2])
    return m


def slopes_steffen(xs, ys):
    n = len(xs)
    h, d = secants(xs, ys)
    if n == 2:
        return [d[0], d[0]]
    m = [0.0] * n
    for k in range(1, n - 1):
        p = (d[k - 1] * h[k] + d[k] * h[k - 1]) / (h[k - 1] + h[k])
        m[k] = (sign(d[k - 1]) + sign(d[k])) * min(abs(d[k - 1]), abs(d[k]), 0.5 * abs(p))

    def end(h0, h1, d0, d1):
        p = d0 * (1 + h0 / (h0 + h1)) - d1 * h0 / (h0 + h1)
        if p * d0 <= 0:
            return 0.0
        if abs(p) > 2 * abs(d0):
            return 2 * d0
        return p

    m[0] = end(h[0], h[1], d[0], d[1])
    m[-1] = end(h[-1], h[-2], d[-1], d[-2])
    return m


def _akima(xs, ys, modified):
    n = len(xs)
    h, d = secants(xs, ys)
    if n == 2:
        return [d[0], d[0]]
    # two extrapolated secants at each end (Akima 1970)
    e = [0.0, 0.0] + d + [0.0, 0.0]
    e[1] = 2 * e[2] - e[3]
    e[0] = 2 * e[1] - e[2]
    e[-2] = 2 * e[-3] - e[-4]
    e[-1] = 2 * e[-2] - e[-3]
    m = [0.0] * n
    for i in range(n):
        dm2, dm1, dp0, dp1 = e[i], e[i + 1], e[i + 2], e[i + 3]
        if modified:
            w1 = abs(dp1 - dp0) + abs(dp1 + dp0) / 2
            w2 = abs(dm1 - dm2) + abs(dm1 + dm2) / 2
        else:
            w1 = abs(dp1 - dp0)
            w2 = abs(dm1 - dm2)
        if w1 + w2 == 0:
            m[i] = 0.0 if modified else (dm1 + dp0) / 2
        else:
            m[i] = (w1 * dm1 + w2 * dp0) / (w1 + w2)
    return m


def slopes_akima(xs, ys):
    return _akima(xs, ys, False)


def slopes_makima(xs, ys):
    return _akima(xs, ys, True)


def slopes_c2(xs, ys, left="notaknot", right="notaknot"):
    """Knot slopes of the C2 cubic spline. End conditions: 'natural', 'notaknot', 'parabolic'
    (first span is a parabola) or ('clamped', slope)."""
    n = len(xs)
    h, d = secants(xs, ys)
    if n == 2:
        l = left[1] if isinstance(left, tuple) else None
        r = right[1] if isinstance(right, tuple) else None
        if l is not None and r is not None:
            return [l, r]
        if l is not None:  # one cubic piece, clamped one end: make it a parabola
            return [l, 2 * d[0] - l]
        if r is not None:
            return [2 * d[0] - r, r]
        return [d[0], d[0]]
    a = [[0.0] * n for _ in range(n)]
    b = [0.0] * n
    for i in range(1, n - 1):
        a[i][i - 1] = 1 / h[i - 1]
        a[i][i] = 2 * (1 / h[i - 1] + 1 / h[i])
        a[i][i + 1] = 1 / h[i]
        b[i] = 3 * (d[i - 1] / h[i - 1] + d[i] / h[i])

    def end(row, cond, i0, i1, h0, h1, d0, d1):
        # i0 = the end knot, i1 = its neighbour; h0/d0 the end span, h1/d1 the next one in
        if isinstance(cond, tuple):
            a[row][i0] = 1.0
            b[row] = cond[1]
        elif cond == "natural":
            a[row][i0] = 2.0
            a[row][i1] = 1.0
            b[row] = 3 * d0
        elif cond == "parabolic":
            a[row][i0] = 1.0
            a[row][i1] = 1.0
            b[row] = 2 * d0
        elif cond == "notaknot":
            if h1 is None:  # only two knots on this side of things: fall back to parabolic
                a[row][i0] = 1.0
                a[row][i1] = 1.0
                b[row] = 2 * d0
            else:
                a[row][i0] = h1
                a[row][i1] = h0 + h1
                b[row] = ((3 * h0 + 2 * h1) * h1 * d0 + h0 * h0 * d1) / (h0 + h1)
        else:
            raise ValueError(cond)

    if n == 3 and left == "notaknot" and right == "notaknot":
        # the parabola through the three points (SciPy special-cases this the same way)
        m1 = (d[0] * h[1] + d[1] * h[0]) / (h[0] + h[1])
        return [2 * d[0] - m1, m1, 2 * d[1] - m1]
    if n == 3 and left == "notaknot" and isinstance(right, tuple):
        # one cubic through three points with the right-hand slope fixed
        pass
    end(0, left, 0, 1, h[0], h[1] if n > 2 else None, d[0], d[1] if n > 2 else None)
    end(n - 1, right, n - 1, n - 2, h[-1], h[-2] if n > 2 else None, d[-1], d[-2] if n > 2 else None)
    return solve(a, b)


def hyman0(xs, ys, m):
    """Hyman's monotonicity filter (as in R's splinefun 'hyman'), with a zero slope at any knot
    that is a local high or low so the curve never passes the lowest station."""
    n = len(xs)
    h, d = secants(xs, ys)
    out = list(m)
    for i in range(n):
        s0 = d[i - 1] if i > 0 else d[0]
        s1 = d[i] if i < n - 1 else d[-1]
        if s0 * s1 <= 0:
            out[i] = 0.0
            continue
        t = 3 * min(abs(s0), abs(s1))
        if s1 > 0:
            out[i] = min(max(0.0, out[i]), t)
        else:
            out[i] = max(min(0.0, out[i]), -t)
    return out


# ---------------------------------------------------------------- models in plain (x, y)
def fit_linear(xs, ys):
    h, d = secants(xs, ys)
    n = len(xs)

    def f(x):
        if x <= xs[0]:
            return ys[0]
        if x >= xs[-1]:
            return ys[-1]
        k = bisect_right(xs, x) - 1
        return ys[k] + d[k] * (x - xs[k])

    return f


def fit_pchip(xs, ys):
    return hermite(xs, ys, slopes_pchip(xs, ys))


def fit_fd(xs, ys):
    return hermite(xs, ys, slopes_fd(xs, ys))


def fit_steffen(xs, ys):
    return hermite(xs, ys, slopes_steffen(xs, ys))


def fit_akima(xs, ys):
    return hermite(xs, ys, slopes_akima(xs, ys))


def fit_makima(xs, ys):
    return hermite(xs, ys, slopes_makima(xs, ys))


def fit_natural(xs, ys):
    return hermite(xs, ys, slopes_c2(xs, ys, "natural", "natural"))


def fit_notaknot(xs, ys):
    return hermite(xs, ys, slopes_c2(xs, ys, "notaknot", "notaknot"))


def fit_parabolic_ends(xs, ys):
    return hermite(xs, ys, slopes_c2(xs, ys, "parabolic", "parabolic"))


def fit_hyman(xs, ys):
    return hermite(xs, ys, hyman0(xs, ys, slopes_c2(xs, ys, "notaknot", "notaknot")))


def fit_hyman_fd(xs, ys):
    return hermite(xs, ys, hyman0(xs, ys, slopes_fd(xs, ys)))


def low_span(ys, tol=1e-9):
    lo = min(ys)
    idx = [i for i, y in enumerate(ys) if y - lo <= tol]
    return idx[0], idx[-1]


def make_flat(tip_cond="notaknot"):
    """C2 spline on each side of the low station, dead level (zero slope) at the low station.
    Between two equally-low stations the curve is the app's pchip (flat when they are all equal)."""

    def fit(xs, ys):
        i0, i1 = low_span(ys)
        n = len(xs)
        m = [0.0] * n
        if i0 >= 1:
            ms = slopes_c2(xs[: i0 + 1], ys[: i0 + 1], tip_cond, ("clamped", 0.0))
            m[: i0 + 1] = ms
        if i1 <= n - 2:
            ms = slopes_c2(xs[i1:], ys[i1:], ("clamped", 0.0), tip_cond)
            m[i1:] = ms
        if i1 > i0:
            mid = slopes_pchip(xs[i0 : i1 + 1], ys[i0 : i1 + 1]) if i1 - i0 >= 2 else [0.0, 0.0]
            for j in range(i0 + 1, i1):
                m[j] = mid[j - i0]
            m[i0] = 0.0
            m[i1] = 0.0
        return hermite(xs, ys, m)

    return fit


fit_flat_nak = make_flat("notaknot")
fit_flat_nat = make_flat("natural")
fit_flat_par = make_flat("parabolic")


# ---------------------------------------------------------------- models on a root of the lift
def make_root(p, base):
    """Interpolate the signed p-th root of the lift above the lowest station, then raise back.

    A rocker line rises from its low point roughly like distance^p, so its p-th root is close to a
    straight line on each side — far easier for any spline to follow. Tail side takes a minus sign
    so the root runs monotonically from tail to nose; the result is |s|^p, which can never dip
    below the low station."""

    def fit(xs, ys):
        lo = min(ys)
        i0, i1 = low_span(ys)
        s = []
        for i, y in enumerate(ys):
            r = max(y - lo, 0.0) ** (1.0 / p)
            s.append(-r if i < i0 else (r if i > i1 else 0.0))
        g = base(list(xs), s)

        def f(x):
            return lo + abs(g(x)) ** p

        f.g = g
        return f

    return fit


# ---------------------------------------------------------------- registry
MODELS = {
    "linear": fit_linear,
    "pchip (today)": fit_pchip,
    "steffen": fit_steffen,
    "akima": fit_akima,
    "makima": fit_makima,
    "catmull-rom (3pt)": fit_fd,
    "natural C2": fit_natural,
    "not-a-knot C2": fit_notaknot,
    "parabolic-end C2": fit_parabolic_ends,
    "hyman(not-a-knot)": fit_hyman,
    "hyman(3pt)": fit_hyman_fd,
    "flat-centre C2 (nak tips)": fit_flat_nak,
    "flat-centre C2 (natural tips)": fit_flat_nat,
    "flat-centre C2 (parabolic tips)": fit_flat_par,
}
for _p in (1.5, 2.0, 2.5, 3.0):
    MODELS[f"root{_p:g} + pchip"] = make_root(_p, fit_pchip)
    MODELS[f"root{_p:g} + not-a-knot"] = make_root(_p, fit_notaknot)
    MODELS[f"root{_p:g} + natural"] = make_root(_p, fit_natural)
    MODELS[f"root{_p:g} + 3pt"] = make_root(_p, fit_fd)

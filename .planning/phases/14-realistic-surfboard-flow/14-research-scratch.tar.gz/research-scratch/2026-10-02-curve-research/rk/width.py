import math, collections
from tdata import load_full, as_blank, unique, series
from models import *
from experiment import run
from thick import drop
us = load_full('US Blanks'); mk = load_full('Marko Foam')
Wd = unique([as_blank(b, 'width') for b in us if 'T6' in series(b, 'width')[0]])
cands = collections.OrderedDict([('pchip (today)', fit_pchip), ('square-root of the narrowing + pchip', drop(2.0)), ('root 1.6', drop(1.6)), ('root 2.5', drop(2.5)), ('root 3', drop(3.0)),
    ('Hyman monotone C2', fit_hyman), ('cubic spline (not-a-knot)', fit_notaknot), ('Steffen', fit_steffen)])
for title, lay in (('5 stations', 'T0 T12 C N12 N0'), ('7 stations', 'T0 T12 T24 C N24 N12 N0')):
    used, out = run(Wd, lay, cands)
    print(f'WIDTH (full width, inches) — {title}: {used} dense US curves, {len(out["pchip (today)"])} hidden stations')
    for k in cands:
        e = sorted(abs(x[4]-x[3]) for x in out[k]); bias = sum(x[4]-x[3] for x in out[k]) / len(out[k])
        body = [abs(x[4]-x[3]) for x in out[k] if x[1] not in ('T6', 'N6')]; tipz = [abs(x[4]-x[3]) for x in out[k] if x[1] in ('T6', 'N6')]
        print(f'   {k:38s} mean {sum(e)/len(e):.3f}  median {e[len(e)//2]:.3f}  worst {e[-1]:.3f}  bias {bias:+.3f}   | last foot {sum(tipz)/len(tipz):.3f}  body {sum(body)/len(body):.3f}')
MW = unique([as_blank(b, 'width') for b in mk if len(series(b, 'width')[0]) >= 7 and all(k in series(b, 'width')[0] for k in ['T0','T12','C','N12','N0'])])
used, out = run(MW, 'T0 T12 C N12 N0', {k: cands[k] for k in ('pchip (today)', 'square-root of the narrowing + pchip')})
print(f'Marko width thinned to five: {used} curves: ' + ' | '.join(f"{k}: mean {sum(abs(x[4]-x[3]) for x in v)/len(v):.3f}" for k, v in out.items()))
# does the widest station sit at C? and is T0 width zero for pointed noses?
cnt = collections.Counter(b['labels'][b['ys'].index(max(b['ys']))] for b in Wd); print('widest station:', cnt.most_common(6))

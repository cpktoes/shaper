"""Thickness (and deck) tables from the three catalogues, inches."""
import collections, csv
from data import REPO, FILES

def load_full(vendor):
    rows = list(csv.DictReader(open(f"{REPO}/db/seed/blanks/{FILES[vendor]}", newline="")))
    blanks = collections.OrderedDict()
    for r in rows:
        b = blanks.setdefault(r["blank_name"], dict(vendor=r["vendor"], name=r["blank_name"], length=float(r["length_in"]), rows=[]))
        f = lambda k: float(r[k]) if r[k].strip() != "" else None
        b["rows"].append(dict(label=r["station"], x=float(r["station_in_from_tail"]), rocker=f("rocker_in"), thick=f("thickness_in"), width=f("width_in"), flag=r["flag"]))
    out = []
    for b in blanks.values():
        b["rows"].sort(key=lambda s: s["x"])
        out.append(b)
    return out

def series(b, key):
    """(labels, xs, ys) for one attribute's own non-empty stations."""
    rs = [r for r in b["rows"] if r[key] is not None]
    return [r["label"] for r in rs], [r["x"] for r in rs], [r[key] for r in rs]

def as_blank(b, key):
    lab, xs, ys = series(b, key)
    return dict(vendor=b["vendor"], name=b["name"], length=b["length"], labels=lab, xs=xs, ys=ys, st=list(zip(lab, xs, ys)))

def unique(blanks):
    seen = collections.OrderedDict()
    for b in blanks:
        seen.setdefault(tuple((round(x, 2), round(y, 3)) for x, y in zip(b["xs"], b["ys"])), []).append(b)
    return [dict(v[0], sisters=[x["name"] for x in v]) for v in seen.values()]

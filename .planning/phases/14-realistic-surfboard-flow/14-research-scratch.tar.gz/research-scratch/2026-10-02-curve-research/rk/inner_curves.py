"""Phase 14 discussion: the three curves that can run INSIDE the square-root rule, compared on every blank's rocker."""
import json, math, sys
from data import load
from models import *

def root_with(base):
    def fit(xs, ys):
        lo = min(ys); first = ys.index(lo)
        s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
        g = base(list(xs), s)
        return lambda x: lo + g(x) ** 2
    return fit

CANDS = {"today": fit_pchip, "pchip": root_with(fit_pchip), "steffen": root_with(fit_steffen), "hyman": root_with(fit_hyman)}
blanks = load("US Blanks") + load("Arctic Foam") + load("Marko Foam")
gaps = {"steffen": [], "hyman": []}
worst = {"steffen": (0, ""), "hyman": (0, "")}
for b in blanks:
    xs, ys = b["xs"], b["ys"]
    f = {k: fit(xs, ys) for k, fit in CANDS.items()}
    n = int(round((xs[-1] - xs[0]) / 0.25))
    for k in ("steffen", "hyman"):
        m = max(abs(f[k](xs[0] + i * 0.25) - f["pchip"](xs[0] + i * 0.25)) for i in range(n + 1))
        gaps[k].append(m)
        if m > worst[k][0]: worst[k] = (m, f'{b["vendor"]} {b["name"]}')
q = lambda v, p: sorted(v)[min(len(v) - 1, int(p * len(v)))]
for k in gaps:
    print(f'{k:8s} vs pchip inside the rule, largest gap anywhere along each of {len(blanks)} blanks: median {q(gaps[k],0.5):.4f} in, 90% {q(gaps[k],0.9):.4f} in, max {max(gaps[k]):.4f} in ({worst[k][1]}); over 1/32 in on {sum(1 for g in gaps[k] if g > 1/32)} blanks, over 1/16 in on {sum(1 for g in gaps[k] if g > 1/16)}')

def bend(f, x, e=0.25):
    return (f(x + e) - 2 * f(x) + f(x - e)) / (e * e)
out = []
for vendor, name in (("Arctic Foam", "9'4\" G"), ("Marko Foam", None), ("US Blanks", None)):
    pool = [b for b in blanks if b["vendor"] == vendor]
    if name: b = next(x for x in pool if x["name"] == name)
    else:
        # the blank where Steffen and pchip differ most (so the picture shows the largest difference there is)
        b = max(pool, key=lambda bb: max(abs(root_with(fit_steffen)(bb["xs"], bb["ys"])(bb["xs"][0] + i * 0.25) - root_with(fit_pchip)(bb["xs"], bb["ys"])(bb["xs"][0] + i * 0.25)) for i in range(int(round((bb["xs"][-1] - bb["xs"][0]) / 0.25)) + 1)))
    xs, ys = b["xs"], b["ys"]
    f = {k: fit(xs, ys) for k, fit in CANDS.items()}
    grid = [xs[0] + i * 0.5 for i in range(int(round((xs[-1] - xs[0]) / 0.5)) + 1)]
    inner = [x for x in grid if xs[0] + 1 <= x <= xs[-1] - 1]
    out.append({"title": f'{b["vendor"]} {b["name"]}', "stations": len(xs), "xs": xs, "ys": ys, "x": grid,
                "y": {k: [round(f[k](x), 4) for x in grid] for k in f},
                "bx": inner, "bend": {k: [round(bend(f[k], x), 5) for x in inner] for k in f},
                "gap": {k: round(max(abs(f[k](x) - f["pchip"](x)) for x in grid), 4) for k in ("steffen", "hyman", "today")}})
    print(f'picture blank: {b["vendor"]} {b["name"]} ({len(xs)} stations) — largest gap from pchip-inside: Steffen {out[-1]["gap"]["steffen"]} in, Hyman {out[-1]["gap"]["hyman"]} in; today vs new {out[-1]["gap"]["today"]} in')
json.dump(out, open(sys.argv[1], "w"))

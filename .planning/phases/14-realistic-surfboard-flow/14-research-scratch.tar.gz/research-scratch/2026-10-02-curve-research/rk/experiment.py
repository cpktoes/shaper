"""Thinning test: hide stations of the densely measured US Blanks, redraw from the few that a
sparse blank would have, and score each model at the hidden stations."""
import math, collections, json, sys
from data import load, unique_rockers
from models import MODELS

LAYOUTS = collections.OrderedDict([
    ("5pt  T0 T12 C N12 N0            (all 33 Arctic, 2 Marko, the hand-set rocker)", "T0 T12 C N12 N0"),
    ("7pt  T0 T12 T24 C N24 N12 N0    (12 Marko)", "T0 T12 T24 C N24 N12 N0"),
    ("9pt  +T36/N36                   (4 Marko)", "T0 T12 T24 T36 C N36 N24 N12 N0"),
    ("9pt  +T48/N48, no 36            (4 Marko)", "T0 T12 T24 T48 C N48 N24 N12 N0"),
    ("5pt  T0 T24 C N24 N0            (2 Marko)", "T0 T24 C N24 N0"),
    ("7pt  T0 T12 T36 C N36 N12 N0    (1 Marko)", "T0 T12 T36 C N36 N12 N0"),
    ("11pt 12in grid                  (10 US Blanks EPS/SUP)", "T0 T12 T24 T36 T48 C N48 N36 N24 N12 N0"),
])

def stats(errs):
    n = len(errs)
    if not n: return None
    a = sorted(abs(e) for e in errs)
    return dict(n=n, rms=math.sqrt(sum(e*e for e in errs)/n), mae=sum(a)/n, p95=a[min(n-1, int(math.ceil(0.95*n))-1)], mx=a[-1], bias=sum(errs)/n)

def run(blanks, layout, models=MODELS):
    want = layout.split()
    out = {name: [] for name in models}   # (blank, label, x, truth, pred)
    used = 0
    for b in blanks:
        if not all(l in b['labels'] for l in want): continue
        hid = [(l, x, y) for l, x, y in b['st'] if l not in want]
        if not hid: continue
        used += 1
        kx = [x for l, x, y in b['st'] if l in want]
        ky = [y for l, x, y in b['st'] if l in want]
        for name, fit in models.items():
            f = fit(kx, ky)
            for l, x, y in hid:
                out[name].append((b['name'], l, x, y, f(x)))
    return used, out

def shape(blanks, layout, models=MODELS, step=0.25):
    """How believable is the redrawn curve as a shape? dips below the low station, bumps (concave
    stretches) and the size of the curvature jump at each station."""
    want = layout.split()
    res = {}
    for name, fit in models.items():
        dips = bumps = 0; worst_dip = 0.0; worst_bump = 0.0; jumps = []; nb = 0
        for b in blanks:
            if not all(l in b['labels'] for l in want): continue
            nb += 1
            kx = [x for l, x, y in b['st'] if l in want]; ky = [y for l, x, y in b['st'] if l in want]
            f = fit(kx, ky)
            n = int(round((kx[-1]-kx[0])/step))
            g = [f(kx[0] + i*(kx[-1]-kx[0])/n) for i in range(n+1)]
            dx = (kx[-1]-kx[0])/n
            dip = min(ky) - min(g)
            if dip > 1e-4: dips += 1
            worst_dip = max(worst_dip, dip)
            # bump: deepest the curve rises above its own chord over any 6-inch window
            w = int(round(6/dx)); wb = 0.0
            for i in range(0, n+1-w):
                mid = g[i + w//2]; chord = (g[i] + g[i+w])/2
                wb = max(wb, mid - chord)
            if wb > 0.005: bumps += 1
            worst_bump = max(worst_bump, wb)
            e = 1e-3
            for k in range(1, len(kx)-1):
                l = (f(kx[k]) - 2*f(kx[k]-e) + f(kx[k]-2*e))/e**2
                r = (f(kx[k]+2*e) - 2*f(kx[k]+e) + f(kx[k]))/e**2
                jumps.append(abs(r-l))
        jumps.sort()
        res[name] = dict(n=nb, dips=dips, worst_dip=worst_dip, bumps=bumps, worst_bump=worst_bump,
                         jump_med=jumps[len(jumps)//2] if jumps else 0, jump_max=jumps[-1] if jumps else 0)
    return res

if __name__ == '__main__':
    us = load('US Blanks')
    dense = unique_rockers([b for b in us if 'T6' in b['labels']])
    only = sys.argv[1:] 
    results = {}
    for title, layout in LAYOUTS.items():
        used, out = run(dense, layout)
        print(f'\n=== {title}   [{used} distinct dense US curves, {len(next(iter(out.values())))} hidden stations]')
        rows = []
        for name, recs in out.items():
            s = stats([r[4]-r[3] for r in recs])
            rows.append((s['rms'], name, s))
        rows.sort()
        print(f'{"model":34s} {"RMS":>7s} {"mean|e|":>8s} {"95%":>7s} {"worst":>7s} {"bias":>8s}   (inches)')
        for rms, name, s in rows:
            print(f'{name:34s} {s["rms"]:7.3f} {s["mae"]:8.3f} {s["p95"]:7.3f} {s["mx"]:7.3f} {s["bias"]:+8.3f}')
        results[layout] = {name: s for _, name, s in rows}
    json.dump(results, open('results_thinning.json', 'w'), indent=1)

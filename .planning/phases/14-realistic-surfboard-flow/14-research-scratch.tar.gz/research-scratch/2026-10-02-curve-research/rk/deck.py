import math, collections
from tdata import load_full
from models import *
from thick import root_first, drop
KEEP = ['T0', 'T12', 'C', 'N12', 'N0']
us = load_full('US Blanks'); mk = load_full('Marko Foam')
def cases(blanks, need='T6'):
    out = []
    for b in blanks:
        rows = [r for r in b['rows'] if r['rocker'] is not None and r['thick'] is not None]
        labs = [r['label'] for r in rows]
        if (need and need not in labs) or not all(k in labs for k in KEEP) or len(rows) < 7: continue
        out.append((b, rows))
    return out
sq = root_first(2.0); dr = drop(2.0)
APPROACHES = collections.OrderedDict([
    ("today: pchip bottom + pchip thickness", lambda x, R, T: (fit_pchip(x, R), fit_pchip(x, T), None)),
    ("sqrt bottom + pchip thickness", lambda x, R, T: (sq(x, R), fit_pchip(x, T), None)),
    ("sqrt bottom + sqrt-thinning thickness", lambda x, R, T: (sq(x, R), dr(x, T), None)),
    ("sqrt bottom + deck line drawn directly (pchip)", lambda x, R, T: (sq(x, R), None, fit_pchip(x, [a + b for a, b in zip(R, T)]))),
    ("sqrt bottom + deck line drawn directly (sqrt)", lambda x, R, T: (sq(x, R), None, sq(x, [a + b for a, b in zip(R, T)]))),
    ("sqrt bottom + deck line drawn directly (Hyman C2)", lambda x, R, T: (sq(x, R), None, fit_hyman(x, [a + b for a, b in zip(R, T)]))),
])
def score(tag, cs):
    print(f'\n{tag}: {len(cs)} blanks; hidden stations scored on bottom, thickness and deck height (mean miss, worst) + how often the deck line dips')
    for name, mk_ in APPROACHES.items():
        eb, et, ed = [], [], []; humps = 0; thin_neg = 0
        for b, rows in cs:
            k = [r for r in rows if r['label'] in KEEP]; h = [r for r in rows if r['label'] not in KEEP]
            x = [r['x'] for r in k]; R = [r['rocker'] for r in k]; T = [r['thick'] for r in k]
            fb, ft, fd = mk_(x, R, T)
            bottom = fb
            thick = ft if ft is not None else (lambda q: fd(q) - fb(q))
            deck = fd if fd is not None else (lambda q: fb(q) + ft(q))
            for r in h:
                eb.append(abs(bottom(r['x']) - r['rocker'])); et.append(abs(thick(r['x']) - r['thick'])); ed.append(abs(deck(r['x']) - (r['rocker'] + r['thick'])))
            # thickness sanity along the blank: never above the thickest station, never rising toward a tip
            n = int(b['length'] * 2); g = [thick(x[0] + i * (x[-1] - x[0]) / n) for i in range(n + 1)]
            if max(g) > max(T) + 0.01: humps += 1
        f = lambda v: f'{sum(v)/len(v):.3f} / {max(v):.3f}'
        print(f'  {name:52s} bottom {f(eb)}   thickness {f(et)}   deck {f(ed)}   thicker-than-thickest-station on {humps}')
score('US Blanks with 6in tip stations, thinned to five', cases(us))
score('Marko 7+ stations, thinned to five', cases(mk, need=None))

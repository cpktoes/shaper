import math, collections, random
from data import load, unique_rockers
from models import *
from experiment import run, stats

us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
A5 = "T0 T12 C N12 N0"; M7 = "T0 T12 T24 C N24 N12 N0"

# --- the general rule, written the way the app would need it: every station keeps its number
def fit_sqrt_pchip(xs, ys):
    lo = min(ys); first = ys.index(lo)
    s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
    g = fit_pchip(list(xs), s)
    f = lambda x: lo + g(x) ** 2
    f.g = g
    return f

print('(a) every real blank: does the general rule pass through every printed station, and stay at or above the lowest one?')
for tag, blanks in (('US Blanks', us), ('Arctic', ar), ('Marko', mk)):
    worst = 0; dips = 0; ties = 0; nonmono = []
    for b in blanks:
        f = fit_sqrt_pchip(b['xs'], b['ys'])
        worst = max(worst, max(abs(f(x) - y) for x, y in zip(b['xs'], b['ys'])))
        lo = min(b['ys']); n = int(b['length'] / 0.1)
        if min(f(b['xs'][0] + i * (b['xs'][-1] - b['xs'][0]) / n) for i in range(n + 1)) < lo - 1e-9: dips += 1
        lows = [i for i, y in enumerate(b['ys']) if y == lo]
        if len(lows) > 1: ties += 1
        i0 = lows[0]
        tail = b['ys'][:i0 + 1]; nose = b['ys'][lows[-1]:]
        if any(tail[i] < tail[i + 1] for i in range(len(tail) - 1)) or any(nose[i] > nose[i + 1] for i in range(len(nose) - 1)) or any(b['ys'][i] > lo for i in range(lows[0], lows[-1])):
            nonmono.append(b['name'])
    print(f'   {tag:10s} {len(blanks):3d} blanks: biggest miss at a printed station {worst:.2e} in; dips below lowest station: {dips}; blanks with a level stretch (tied lowest stations): {ties}; not steadily rising from the low point: {nonmono}')

# --- parametric Catmull-Rom (the graphics kind), uniform / centripetal / chordal
def make_cr(alpha):
    def fit(xs, ys):
        P = [(x, y) for x, y in zip(xs, ys)]
        P = [(2 * P[0][0] - P[1][0], 2 * P[0][1] - P[1][1])] + P + [(2 * P[-1][0] - P[-2][0], 2 * P[-1][1] - P[-2][1])]
        def seg(k, u):  # between P[k+1] and P[k+2] in padded indexing, u in [0,1]
            p0, p1, p2, p3 = P[k], P[k + 1], P[k + 2], P[k + 3]
            d = lambda a, b: max(math.hypot(b[0] - a[0], b[1] - a[1]) ** alpha, 1e-9)
            t0 = 0.0; t1 = t0 + d(p0, p1); t2 = t1 + d(p1, p2); t3 = t2 + d(p2, p3)
            t = t1 + u * (t2 - t1)
            out = []
            for c in (0, 1):
                A1 = (t1 - t) / (t1 - t0) * p0[c] + (t - t0) / (t1 - t0) * p1[c]
                A2 = (t2 - t) / (t2 - t1) * p1[c] + (t - t1) / (t2 - t1) * p2[c]
                A3 = (t3 - t) / (t3 - t2) * p2[c] + (t - t2) / (t3 - t2) * p3[c]
                B1 = (t2 - t) / (t2 - t0) * A1 + (t - t0) / (t2 - t0) * A2
                B2 = (t3 - t) / (t3 - t1) * A2 + (t - t1) / (t3 - t1) * A3
                out.append((t2 - t) / (t2 - t1) * B1 + (t - t1) / (t2 - t1) * B2)
            return out
        def f(x):
            if x <= xs[0]: return ys[0]
            if x >= xs[-1]: return ys[-1]
            k = bisect_right(xs, x) - 1
            a, b = 0.0, 1.0
            for _ in range(60):
                m = (a + b) / 2
                if seg(k, m)[0] < x: a = m
                else: b = m
            return seg(k, (a + b) / 2)[1]
        return f
    return fit

extra = collections.OrderedDict([
    ('pchip (today)', fit_pchip),
    ('sqrt + pchip (general rule)', fit_sqrt_pchip),
    ('sqrt + steffen', make_root(2, fit_steffen)),
    ('sqrt + akima', make_root(2, fit_akima)),
    ('sqrt + makima', make_root(2, fit_makima)),
    ('sqrt + hyman(not-a-knot)', make_root(2, fit_hyman)),
    ('sqrt + not-a-knot', make_root(2, fit_notaknot)),
    ('sqrt + 3pt', make_root(2, fit_fd)),
    ('Catmull-Rom uniform (parametric)', make_cr(0.0)),
    ('Catmull-Rom centripetal (parametric)', make_cr(0.5)),
    ('Catmull-Rom chordal (parametric)', make_cr(1.0)),
])
for lay, tag in ((A5, '5 stations'), (M7, '7 stations')):
    _, out = run(dense, lay, extra)
    print(f'\n(b) {tag}:')
    for k in extra:
        s = stats([r[4] - r[3] for r in out[k]])
        print(f'   {k:38s} RMS {s["rms"]:.3f}  mean|e| {s["mae"]:.3f}  95% {s["p95"]:.3f}  worst {s["mx"]:.3f}  bias {s["bias"]:+.3f}')
    if lay == A5:
        # paired bootstrap over curves: mean |error| per curve
        per = {k: collections.defaultdict(list) for k in extra}
        for k in extra:
            for r in out[k]: per[k][r[0]].append(abs(r[4] - r[3]))
        names = list(per['pchip (today)'].keys())
        m = {k: [sum(per[k][n]) / len(per[k][n]) for n in names] for k in extra}
        random.seed(11)
        def boot(a, b, B=4000):
            diffs = []
            for _ in range(B):
                idx = [random.randrange(len(names)) for _ in names]
                diffs.append(sum(a[i] - b[i] for i in idx) / len(idx))
            diffs.sort(); return diffs[int(0.025 * B)], diffs[int(0.975 * B)]
        base = m['sqrt + pchip (general rule)']
        print('   paired bootstrap over the 68 curves — mean miss per curve, other model minus sqrt+pchip (95% range, inches):')
        for k in ('pchip (today)', 'sqrt + not-a-knot', 'sqrt + 3pt', 'sqrt + steffen', 'Catmull-Rom centripetal (parametric)'):
            lo, hi = boot(m[k], base)
            print(f'      {k:38s} {sum(m[k])/len(names) - sum(base)/len(names):+.3f}   [{lo:+.3f} .. {hi:+.3f}]')
        better = sum(1 for a, b in zip(m['pchip (today)'], base) if b < a)
        print(f'   sqrt+pchip is closer than today on {better} of {len(names)} curves')

print('\n(c) stations no smooth curve explains (by-product): printed value vs the value every neighbour implies (leave-one-out, sqrt+pchip), > 0.15 in')
rows = []
for tag, blanks in (('US Blanks', us), ('Marko', mk)):
    for b in blanks:
        xs, ys, lab = b['xs'], b['ys'], b['labels']
        for i in range(1, len(xs) - 1):
            if ys[i] == min(ys): continue
            f = fit_sqrt_pchip(xs[:i] + xs[i + 1:], ys[:i] + ys[i + 1:])
            d = ys[i] - f(xs[i])
            if abs(d) > 0.15: rows.append((abs(d), tag, b['name'], lab[i], ys[i], f(xs[i])))
rows.sort(reverse=True)
for r in rows[:20]: print(f'   {r[1]:9s} {r[2]:20s} {r[3]:4s} printed {r[4]:.3f}  neighbours imply {r[5]:.3f}  ({r[4]-r[5]:+.3f})')

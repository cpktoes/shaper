import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats

us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
A5 = "T0 T12 C N12 N0"
pc = fit_pchip; r2 = make_root(2, fit_pchip)

print('(H) 5-station test split by how many stations the US blank really has (most control points = 15)')
for n in (15, 13, 11):
    grp = [b for b in dense if len(b['xs']) == n]
    _, out = run(grp, A5, {'pchip (today)': pc, 'root2 + pchip': r2})
    Ls = [b['length'] for b in grp]
    line = f'  {n} stations: {len(grp):2d} distinct curves, {min(Ls)/12:.1f}-{max(Ls)/12:.1f} ft'
    for k in out:
        s = stats([r[4]-r[3] for r in out[k]])
        line += f'  | {k}: mean {s["mae"]:.3f} RMS {s["rms"]:.3f} worst {s["mx"]:.3f}'
    print(line)

print('\n(G) CEILING — could a model *trained* on the US tables beat the square-root curve? (leave-one-curve-out linear regression per hidden station)')
from models import solve
def ridge(X, y, lam=1e-6):
    p = len(X[0]); A = [[sum(r[i]*r[j] for r in X) + (lam if i == j else 0) for j in range(p)] for i in range(p)]
    b = [sum(r[i]*t for r, t in zip(X, y)) for i in range(p)]
    return solve(A, b)
want = A5.split()
errs_reg = []; errs_r2 = []; errs_reg2 = []
rows = collections.defaultdict(list)
for bi, b in enumerate(dense):
    kx = [x for l, x, y in b['st'] if l in want]; ky = [y for l, x, y in b['st'] if l in want]
    f = r2(kx, ky)
    for l, x, y in b['st']:
        if l in want: continue
        rows[l].append((bi, [1.0, ky[0], ky[1], ky[3], ky[4], b['length']/100.0], f(x), y))
for lab, rs in rows.items():
    for hold in range(len(rs)):
        bi = rs[hold][0]
        # leave out every curve within 0.05 in of this one at all five stations AND same length (near-sisters)
        tr = [r for r in rs if r[0] != bi]
        w = ridge([r[1] for r in tr], [r[3] for r in tr])
        errs_reg.append(sum(a*c for a, c in zip(w, rs[hold][1])) - rs[hold][3])
        # regression on top of the square-root curve's own answer
        w2 = ridge([r[1] + [r[2]] for r in tr], [r[3] for r in tr])
        errs_reg2.append(sum(a*c for a, c in zip(w2, rs[hold][1] + [rs[hold][2]])) - rs[hold][3])
        errs_r2.append(rs[hold][2] - rs[hold][3])
for k, e in (('root2 + pchip (no training)', errs_r2), ('trained: stations+length', errs_reg), ('trained: + root2 answer', errs_reg2)):
    s = stats(e); print(f'   {k:30s} RMS {s["rms"]:.3f}  mean|e| {s["mae"]:.3f}  95% {s["p95"]:.3f}  worst {s["mx"]:.3f}')

print('\n(I) HOW FAR WOULD THE REAL SPARSE BLANKS MOVE?  new (root2+pchip) minus today (pchip), along each blank')
def moves(blanks, tag):
    allmax = []
    print(f'  {tag}')
    for b in blanks:
        kx, ky = b['xs'], b['ys']; f0 = pc(kx, ky); f1 = r2(kx, ky)
        n = int(round(b['length']/0.25)); best = (0, 0)
        for i in range(n+1):
            x = kx[0] + i*(kx[-1]-kx[0])/n; d = f1(x) - f0(x)
            if abs(d) > abs(best[0]): best = (d, x)
        allmax.append((abs(best[0]), b['name'], best[0], best[1], b['length'], len(kx)))
    allmax.sort(reverse=True)
    v = sorted(a[0] for a in allmax)
    print(f'     largest move per blank: median {v[len(v)//2]:.3f} in, biggest {v[-1]:.3f} in; blanks moving more than 1/8 in: {sum(x > 0.125 for x in v)} of {len(v)}, more than 1/4 in: {sum(x > 0.25 for x in v)}')
    for a in allmax[:6]:
        print(f'       {a[1]:22s} ({a[5]} stations) moves {a[2]:+.3f} in at {a[4]-a[3]:.0f} in from the nose / {a[3]:.0f} in from the tail')
    return allmax
ma = moves(ar, 'Arctic Foam (33 blanks, 5 stations each)')
mm_ = moves(mk, 'Marko Foam (28 blanks, 5-10 stations)')
mu = moves(us, 'US Blanks (101 blanks, 9-15 stations)')

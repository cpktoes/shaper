import math, json, subprocess, random
from models import *

# 1. not-a-knot reproduces any cubic exactly; natural has zero end curvature
xs = [0, 6, 12, 18, 24, 36, 48, 55.8, 63.6]
cub = lambda x: 0.5 - 0.03*x + 0.002*x*x - 0.00001*x**3
f = fit_notaknot(xs, [cub(x) for x in xs])
err = max(abs(f(x) - cub(x)) for x in [i*0.37 for i in range(0, 171)])
print('not-a-knot on a cubic, max err', err)
assert err < 1e-10
# 3 knots + clamped: one cubic
xs3 = [0, 12, 40.5]
c3 = lambda x: 0.0006*(40.5-x)**2 + 0.00002*(40.5-x)**3   # zero value and slope at 40.5
m = slopes_c2(xs3, [c3(x) for x in xs3], 'notaknot', ('clamped', 0.0))
f = hermite(xs3, [c3(x) for x in xs3], m)
err = max(abs(f(x) - c3(x)) for x in [i*0.25 for i in range(0, 163)])
print('flat-centre single cubic, max err', err); assert err < 1e-10
# natural: second derivative zero at ends
f = fit_natural(xs, [cub(x) for x in xs]); e=1e-3
d2 = (f(xs[0]+2*e) - 2*f(xs[0]+e) + f(xs[0]))/e**2
print('natural end curvature ~', d2)
# C2 continuity check for not-a-knot on rough data
random.seed(1)
ys = [random.random() for _ in xs]
for name in ['natural C2','not-a-knot C2','parabolic-end C2']:
    f = MODELS[name](xs, ys); worst = 0
    for k in range(1, len(xs)-1):
        e = 1e-3
        l = (f(xs[k]) - 2*f(xs[k]-e) + f(xs[k]-2*e))/e**2
        r = (f(xs[k]+2*e) - 2*f(xs[k]+e) + f(xs[k]))/e**2
        worst = max(worst, abs(l-r))
    print(name, 'max curvature jump at knots', round(worst, 5))
# every model passes through its knots
ys = [3.189,2.374,1.752,1.252,0.811,0.311,0.0,0.0,0.28]
for name, fit in MODELS.items():
    f = fit(xs, ys)
    assert max(abs(f(x)-y) for x, y in zip(xs, ys)) < 1e-9, name
print('all', len(MODELS), 'models interpolate their knots')

# 2. pchip port == the app's own lib/geometry/pchip.ts
cases = []
random.seed(7)
for _ in range(40):
    n = random.randint(2, 15)
    x = sorted(random.sample(range(0, 150), n))
    y = [round(random.uniform(0, 8), 3) if random.random() > 0.15 else 0.0 for _ in x]
    q = [random.uniform(x[0]-2, x[-1]+2) for _ in range(25)]
    cases.append(dict(x=x, y=y, q=q))
json.dump(cases, open('pchip_cases.json', 'w'))
ts = r'''
import { preparePchip } from "/Users/kontoes/Code/shaper/lib/geometry/pchip";
import { readFileSync } from "node:fs";
const cases = JSON.parse(readFileSync(process.argv[2], "utf8"));
const out = cases.map((c: any) => { const p = preparePchip(c.x.map((x: number, i: number) => ({ x, y: c.y[i] }))); return c.q.map((q: number) => p.sample(q)); });
console.log(JSON.stringify(out));
'''
open('pchip_ref.ts', 'w').write(ts)

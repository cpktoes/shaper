"""Reads the three committed blank catalogues (read-only) into plain rocker tables, in inches."""
import collections
import csv

REPO = "/Users/kontoes/Code/shaper"
FILES = {
    "US Blanks": "us_blanks_stations.csv",
    "Arctic Foam": "arctic_foam_stations.csv",
    "Marko Foam": "marko_foam_stations.csv",
}


def load(vendor):
    rows = list(csv.DictReader(open(f"{REPO}/db/seed/blanks/{FILES[vendor]}", newline="")))
    blanks = collections.OrderedDict()
    for r in rows:
        b = blanks.setdefault(
            r["blank_name"],
            dict(vendor=r["vendor"], name=r["blank_name"], length=float(r["length_in"]), slug=r["catalog_slug"], st=[]),
        )
        if r["rocker_in"].strip() != "":
            b["st"].append((r["station"], float(r["station_in_from_tail"]), float(r["rocker_in"])))
    out = []
    for b in blanks.values():
        b["st"].sort(key=lambda s: s[1])
        b["labels"] = [s[0] for s in b["st"]]
        b["xs"] = [s[1] for s in b["st"]]
        b["ys"] = [s[2] for s in b["st"]]
        out.append(b)
    return out


def curve_key(b):
    """Two blanks with the same stations and the same rocker numbers are one rocker (sister blanks)."""
    return tuple((round(x, 2), round(y, 3)) for x, y in zip(b["xs"], b["ys"]))


def unique_rockers(blanks):
    seen = collections.OrderedDict()
    for b in blanks:
        seen.setdefault(curve_key(b), []).append(b)
    return [dict(v[0], sisters=[x["name"] for x in v]) for v in seen.values()]

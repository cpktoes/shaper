import math, json, collections
from data import load, unique_rockers
from models import *
from experiment import run
us = load('US Blanks')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
A5 = "T0 T12 C N12 N0"
def fit_sqrt_pchip(xs, ys):
    lo = min(ys); first = ys.index(lo)
    s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
    g = fit_pchip(list(xs), s)
    return lambda x: lo + g(x) ** 2
_, out = run(dense, A5, {'p': fit_pchip, 's': fit_sqrt_pchip})
per = collections.defaultdict(lambda: {'p': [], 's': []})
for k in ('p', 's'):
    for r in out[k]: per[r[0]][k].append(abs(r[4] - r[3]))
rows = []
for b in dense:
    d = per[b['name']]
    rows.append((sum(d['p'])/len(d['p']), max(d['p']), sum(d['s'])/len(d['s']), max(d['s']), b['name'], len(b['xs']), b['length']))
for n in (15, 11):
    grp = sorted(r for r in rows if r[5] == n)
    print(f'--- {n}-station curves sorted by today\'s mean miss (mean/worst today | mean/worst sqrt)')
    for r in grp: print(f'   {r[4]:12s} L={r[6]:7.2f}  today {r[0]:.3f}/{r[1]:.3f}   sqrt {r[2]:.3f}/{r[3]:.3f}')

import math, collections
from tdata import load_full, as_blank, unique, series
from models import *
from experiment import run, stats

def root_first(p, base=fit_pchip):
    def fit(xs, ys):
        lo = min(ys); first = ys.index(lo)
        s = [(-1 if i < first else 1) * (max(y - lo, 0.0) ** (1.0 / p)) for i, y in enumerate(ys)]
        g = base(list(xs), s)
        return lambda x: lo + abs(g(x)) ** p
    return fit
def drop(p, base=fit_pchip):
    """Mirror of the rocker rule: fit the root of the THINNING below the thickest station."""
    inner = root_first(p, base)
    def fit(xs, ys):
        f = inner(xs, [-y for y in ys])
        return lambda x: -f(x)
    return fit

us = load_full('US Blanks'); ar = load_full('Arctic Foam'); mk = load_full('Marko Foam')
T = unique([as_blank(b, 'thick') for b in us if 'T6' in series(b, 'thick')[0]])
cands = collections.OrderedDict([
    ('pchip (today)', fit_pchip),
    ('square-root of the thinning + pchip', drop(2.0)),
    ('root 1.6 of the thinning', drop(1.6)), ('root 1.8 of the thinning', drop(1.8)), ('root 2.2 of the thinning', drop(2.2)), ('root 2.5 of the thinning', drop(2.5)),
    ('sqrt thinning + Steffen', drop(2.0, fit_steffen)), ('sqrt thinning + Hyman C2', drop(2.0, fit_hyman)),
    ('Hyman monotone C2', fit_hyman), ('Steffen', fit_steffen), ('cubic spline (not-a-knot)', fit_notaknot), ('Catmull-Rom (3pt)', fit_fd), ('natural spline', fit_natural),
])
REG = collections.OrderedDict([('tail last ft', ['T6']), ('tail body', ['T18', 'T24', 'T36', 'T48']), ('nose body', ['N48', 'N36', 'N24', 'N18']), ('nose last ft', ['N6'])])
for title, lay in (('5 stations (Arctic: T0 T12 C N12 N0)', 'T0 T12 C N12 N0'), ('7 stations (Marko: +T24/N24)', 'T0 T12 T24 C N24 N12 N0')):
    used, out = run(T, lay, cands)
    n = len(out['pchip (today)'])
    print(f'\nTHICKNESS — {title}: {used} dense US curves, {n} hidden stations.  mean miss by region | all: mean  median  worst  bias')
    rows = []
    for k in cands:
        line = f'  {k:38s}'
        for r, labs in REG.items():
            e = [abs(x[4]-x[3]) for x in out[k] if x[1] in labs]
            line += f'{sum(e)/len(e):7.3f}' if e else '      -'
        e = sorted(abs(x[4]-x[3]) for x in out[k]); bias = sum(x[4]-x[3] for x in out[k]) / len(out[k])
        line += f'  | {sum(e)/len(e):.3f}  {e[len(e)//2]:.3f}  {e[-1]:.3f}  {bias:+.3f}'
        rows.append((sum(e)/len(e), line))
    print('  ' + ' ' * 38 + ''.join(f'{r[:7]:>7s}' for r in ('tailft', 'tailbd', 'nosebd', 'noseft')))
    for _, line in sorted(rows): print(line)
    if lay.startswith('T0 T12 C'):
        per = {k: collections.defaultdict(list) for k in cands}
        for k in cands:
            for r in out[k]: per[k][r[0]].append(abs(r[4]-r[3]))
        a, b = per['pchip (today)'], per['square-root of the thinning + pchip']
        better = sum(1 for nme in a if sum(b[nme])/len(b[nme]) < sum(a[nme])/len(a[nme]))
        print(f'  square-root thinning closer than today on {better} of {len(a)} curves')
        w = sorted(out['square-root of the thinning + pchip'], key=lambda r: -abs(r[4]-r[3]))[:6]
        for r in w: print(f'     worst: {r[0]:14s} {r[1]:4s} catalogue {r[3]:.3f} model {r[4]:.3f} ({r[4]-r[3]:+.3f})')

# Marko out-of-maker
MT = unique([as_blank(b, 'thick') for b in mk if len(series(b, 'thick')[0]) >= 7])
used, out = run(MT, 'T0 T12 C N12 N0', {k: cands[k] for k in ('pchip (today)', 'square-root of the thinning + pchip', 'Hyman monotone C2')})
print(f'\nMarko thickness thinned to five: {used} curves')
for k in out:
    e = sorted(abs(x[4]-x[3]) for x in out[k]); print(f'  {k:38s} mean {sum(e)/len(e):.3f} median {e[len(e)//2]:.3f} worst {e[-1]:.3f}  (n={len(e)})')
# leave-one-out on dense
errs = {k: [] for k in ('pchip (today)', 'square-root of the thinning + pchip')}
for b in T:
    xs, ys, lab = b['xs'], b['ys'], b['labels']
    for i in range(1, len(xs)-1):
        if lab[i] == 'C': continue
        for k in errs: errs[k].append(abs(cands[k](xs[:i]+xs[i+1:], ys[:i]+ys[i+1:])(xs[i]) - ys[i]))
print('\nleave-one-station-out on the dense thickness tables: ' + ' | '.join(f'{k}: mean {sum(v)/len(v):.3f} worst {max(v):.3f}' for k, v in errs.items()))

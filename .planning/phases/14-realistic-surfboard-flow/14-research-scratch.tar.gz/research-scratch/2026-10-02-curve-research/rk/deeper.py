import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats, LAYOUTS

us = load('US Blanks')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
A5 = "T0 T12 C N12 N0"; M7 = "T0 T12 T24 C N24 N12 N0"; B5 = "T0 T24 C N24 N0"

def make_root2side(pt, pn, base):
    def fit(xs, ys):
        lo = min(ys); i0, i1 = low_span(ys); s = []
        for i, y in enumerate(ys):
            if i < i0: s.append(-(max(y-lo,0.0) ** (1/pt)))
            elif i > i1: s.append(max(y-lo,0.0) ** (1/pn))
            else: s.append(0.0)
        g = base(list(xs), s)
        def f(x):
            v = g(x)
            return lo + (abs(v) ** (pt if v < 0 else pn))
        return f
    return fit

print('(A) exponent grid, RMS inches at hidden stations — same exponent both sides, base = pchip / not-a-knot / 3pt')
print('   p     ' + ''.join(f'{t:>26s}' for t in ('5pt Arctic layout', '7pt Marko layout', '5pt T0 T24 C N24 N0')))
for p in (1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.6):
    line = f'  {p:3.1f}   '
    for lay in (A5, M7, B5):
        ms = {'pc': make_root(p, fit_pchip), 'nk': make_root(p, fit_notaknot), 'fd': make_root(p, fit_fd)}
        _, out = run(dense, lay, ms)
        line += '     ' + ' / '.join(f"{stats([r[4]-r[3] for r in out[k]])['rms']:.3f}" for k in ('pc','nk','fd'))
    print(line)

print('\n(A2) separate tail / nose exponents, base = pchip: RMS 5pt | 7pt | T24-5pt')
for pt in (1.8, 2.0, 2.2):
    for pn in (2.0, 2.2, 2.4, 2.6, 2.8):
        row = []
        for lay in (A5, M7, B5):
            _, out = run(dense, lay, {'m': make_root2side(pt, pn, fit_pchip)})
            row.append(stats([r[4]-r[3] for r in out['m']])['rms'])
        print(f'   tail {pt:3.1f}  nose {pn:3.1f}   {row[0]:.3f} | {row[1]:.3f} | {row[2]:.3f}')

print('\n(B) 5pt layout — error by hidden station (model minus catalogue, inches): bias / RMS')
pick = collections.OrderedDict([('pchip (today)', MODELS['pchip (today)']), ('root2 + pchip', MODELS['root2 + pchip']),
        ('root2 + not-a-knot', MODELS['root2 + not-a-knot']), ('flat-centre C2', MODELS['flat-centre C2 (nak tips)']), ('not-a-knot C2', MODELS['not-a-knot C2'])])
_, out = run(dense, A5, pick)
order = ['T6','T18','T24','T36','T48','N48','N36','N24','N18','N6']
print('  station   n ' + ''.join(f'{k:>22s}' for k in pick))
for lab in order:
    line = ''; n = 0
    for k in pick:
        e = [r[4]-r[3] for r in out[k] if r[1] == lab]; n = len(e); s = stats(e)
        line += f'      {s["bias"]:+.3f} / {s["rms"]:.3f} '
    print(f'  {lab:>6s} {n:4d} ' + line)

print('\n(C) 5pt layout — the worst single stations for root2 + pchip')
recs = sorted(out['root2 + pchip'], key=lambda r: -abs(r[4]-r[3]))[:14]
for r in recs: print(f'   {r[0]:14s} {r[1]:4s} catalogue {r[3]:.3f}  model {r[4]:.3f}  diff {r[4]-r[3]:+.3f}')
print('   ... and for pchip (today)')
recs = sorted(out['pchip (today)'], key=lambda r: -abs(r[4]-r[3]))[:8]
for r in recs: print(f'   {r[0]:14s} {r[1]:4s} catalogue {r[3]:.3f}  model {r[4]:.3f}  diff {r[4]-r[3]:+.3f}')

print('\n(C2) per blank: worst hidden-station miss, 5pt layout — how many of the 68 curves stay within 1/16, 1/8, 1/4 in')
for k in pick:
    worst = collections.defaultdict(float)
    for r in out[k]: worst[r[0]] = max(worst[r[0]], abs(r[4]-r[3]))
    v = list(worst.values())
    print(f'   {k:22s} within 1/16: {sum(x<=0.0625+1e-9 for x in v):2d}   within 1/8: {sum(x<=0.125+1e-9 for x in v):2d}   within 1/4: {sum(x<=0.25+1e-9 for x in v):2d}   of {len(v)}')

import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats, shape

us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
pick = collections.OrderedDict([
    ('pchip (today)', fit_pchip), ('root2 + pchip', make_root(2, fit_pchip)), ('root2 + not-a-knot', make_root(2, fit_notaknot)),
    ('root2 + 3pt', make_root(2, fit_fd)), ('hyman(not-a-knot)', fit_hyman), ('flat-centre C2', fit_flat_nak), ('not-a-knot C2', fit_notaknot), ('akima', fit_akima)])

print('(E) OUT-OF-MAKER CHECK — Marko blanks that print 7+ stations, redrawn from fewer, scored at the hidden ones')
mku = unique_rockers(mk)
for title, lay in [('Marko thinned to the 5 Arctic stations (T0 T12 C N12 N0)', 'T0 T12 C N12 N0'),
                   ('Marko 9-10pt thinned to 7 (T0 T12 T24 C N24 N12 N0)', 'T0 T12 T24 C N24 N12 N0')]:
    used, out = run(mku, lay, pick)
    n = len(next(iter(out.values())))
    print(f'  {title}: {used} distinct Marko curves, {n} hidden stations')
    for k in pick:
        s = stats([r[4]-r[3] for r in out[k]])
        print(f'     {k:22s} RMS {s["rms"]:.3f}  mean|e| {s["mae"]:.3f}  95% {s["p95"]:.3f}  worst {s["mx"]:.3f}  bias {s["bias"]:+.3f}')
    if lay.startswith('T0 T12 C'):
        print('     by station (bias / RMS):   ' + '   '.join(pick.keys()).replace('  ', ' ')[:0])
        labs = collections.OrderedDict()
        for r in out['pchip (today)']: labs.setdefault(r[1], 0)
        for lab in ['T24','T36','T48','N48','N36','N24']:
            row = f'       {lab:>4s}'
            for k in ('pchip (today)', 'root2 + pchip', 'root2 + not-a-knot'):
                e = [r[4]-r[3] for r in out[k] if r[1] == lab]
                if e:
                    s = stats(e); row += f'   {k}: n={len(e)} {s["bias"]:+.3f}/{s["rms"]:.3f}'
            print(row)
        worst = sorted(out['root2 + pchip'], key=lambda r: -abs(r[4]-r[3]))[:6]
        for r in worst: print(f'       worst root2+pchip: {r[0]:22s} {r[1]:4s} catalogue {r[3]:.2f} model {r[4]:.2f} diff {r[4]-r[3]:+.3f}')

print('\n(F) LEAVE-ONE-STATION-OUT on the full dense US tables (does the same model also suit the dense blanks?)')
errs = {k: [] for k in pick}
for b in dense:
    xs, ys, lab = b['xs'], b['ys'], b['labels']
    for i in range(1, len(xs)-1):
        if lab[i] == 'C': continue
        kx = xs[:i] + xs[i+1:]; ky = ys[:i] + ys[i+1:]
        for k, fit in pick.items():
            errs[k].append(fit(kx, ky)(xs[i]) - ys[i])
for k in pick:
    s = stats(errs[k]); print(f'     {k:22s} RMS {s["rms"]:.3f}  mean|e| {s["mae"]:.3f}  95% {s["p95"]:.3f}  worst {s["mx"]:.3f}  bias {s["bias"]:+.3f}   (n={s["n"]})')

print('\n(D) SHAPE CHECK — is the redrawn line a fair curve?  dips = goes below the lowest station; bumps = a stretch that bulges up between its neighbours (> 0.005 in over 6 in);')
print('    curvature jump = how hard the bend changes at a station (0 = seamless).')
def show(title, blanks, lay=None):
    print('  ' + title)
    for k, fit in pick.items():
        if lay is None:
            # full own stations
            res = None
            dips = bumps = 0; wd = wb = 0.0; jumps = []
            for b in blanks:
                kx, ky = b['xs'], b['ys']; f = fit(kx, ky)
                n = int(round((kx[-1]-kx[0])/0.25)); dx = (kx[-1]-kx[0])/n
                g = [f(kx[0]+i*dx) for i in range(n+1)]
                dip = min(ky) - min(g)
                if dip > 1e-4: dips += 1
                wd = max(wd, dip)
                w = int(round(6/dx)); bb = 0.0
                for i in range(0, n+1-w): bb = max(bb, g[i+w//2] - (g[i]+g[i+w])/2)
                if bb > 0.005: bumps += 1
                wb = max(wb, bb)
                e = 1e-3
                for j in range(1, len(kx)-1):
                    l = (f(kx[j]) - 2*f(kx[j]-e) + f(kx[j]-2*e))/e**2; r = (f(kx[j]+2*e) - 2*f(kx[j]+e) + f(kx[j]))/e**2
                    jumps.append(abs(r-l))
            jumps.sort()
            print(f'     {k:22s} dips {dips:2d} (deepest {wd:.3f})   bumps {bumps:2d} (largest {wb:.3f})   curvature jump median {jumps[len(jumps)//2]:.4f} max {jumps[-1]:.4f}   of {len(blanks)}')
        else:
            r = shape(blanks, lay, {k: fit})[k]
            print(f'     {k:22s} dips {r["dips"]:2d} (deepest {r["worst_dip"]:.3f})   bumps {r["bumps"]:2d} (largest {r["worst_bump"]:.3f})   curvature jump median {r["jump_med"]:.4f} max {r["jump_max"]:.4f}   of {r["n"]}')
show('dense US curves thinned to 5 stations', dense, 'T0 T12 C N12 N0')
show('the 33 real Arctic blanks, as printed', ar)
show('the 28 real Marko blanks, as printed', mk)
show('all 101 real US Blanks, as printed', us)

"""Independent check: each catalogue prints a blank's litres. Width x thickness integrated along the blank
should be a steady multiple of that figure. If sparse blanks read low next to dense ones, the curve between
their stations is under-filled."""
import math, collections, csv
from tdata import load_full, series
from data import REPO, FILES
from models import fit_pchip
from thick import drop, root_first
sq_fall = drop(2.0)
def vol_rows(vendor):
    rows = list(csv.DictReader(open(f"{REPO}/db/seed/blanks/{FILES[vendor]}", newline="")))
    return {r['blank_name']: (float(r['volume_l']) if r['volume_l'].strip() else None) for r in rows}
def integral(b, fT, fW):
    _, xt, yt = series(b, 'thick'); _, xw, yw = series(b, 'width')
    if len(xt) < 3 or len(xw) < 3: return None
    T = fT(xt, yt); W = fW(xw, yw); L = b['length']; n = 600; tot = 0.0
    for i in range(n + 1):
        x = L * i / n; w = 1 if i in (0, n) else (4 if i % 2 else 2)
        tot += w * max(T(x), 0) * max(W(x), 0)
    return tot * (L / n) / 3 / 61.0237   # cubic inches -> litres
print('catalogue litres divided by the width x thickness integral (a full rectangle would read 1.00; rounded rails read lower)')
res = {}
for vendor in ('US Blanks', 'Arctic Foam'):
    vols = vol_rows(vendor)
    for b in load_full(vendor):
        v = vols.get(b['name'])
        if not v: continue
        nT = len(series(b, 'thick')[0])
        a = integral(b, fit_pchip, fit_pchip); c = integral(b, sq_fall, fit_pchip); d = integral(b, sq_fall, sq_fall)
        if a is None: continue
        res.setdefault(vendor, []).append((b['name'], nT, b['length'], v / a, v / c, v / d))
def summ(tag, rows):
    for j, lab in ((3, 'today (pchip thickness, pchip width)'), (4, 'square-root thickness, pchip width'), (5, 'square-root thickness AND width')):
        v = sorted(r[j] for r in rows); m = sum(v) / len(v); sd = math.sqrt(sum((x - m) ** 2 for x in v) / len(v))
        print(f'   {tag:34s} {lab:40s} median {v[len(v)//2]:.3f}  mean {m:.3f}  spread {sd:.3f}  (n={len(v)})')
us = res['US Blanks']; ar = res['Arctic Foam']
summ('US Blanks, 13-15 stations', [r for r in us if r[1] >= 13])
summ('US Blanks, 11 stations', [r for r in us if r[1] == 11])
summ('Arctic, 5 stations (all)', ar)
summ('Arctic, 8 ft and longer', [r for r in ar if r[2] >= 96])
summ('Arctic, under 8 ft', [r for r in ar if r[2] < 96])
# apples to apples: thin the dense US blanks to five stations and see what the integral loses under each rule
KEEP = ['T0', 'T12', 'C', 'N12', 'N0']
loss = collections.defaultdict(list)
for b in load_full('US Blanks'):
    lt, xt, yt = series(b, 'thick'); lw, xw, yw = series(b, 'width')
    if 'T6' not in lt or not all(k in lt for k in KEEP) or not all(k in lw for k in KEEP): continue
    full = integral(b, fit_pchip, fit_pchip)
    kt = [(x, y) for l, x, y in zip(lt, xt, yt) if l in KEEP]; kw = [(x, y) for l, x, y in zip(lw, xw, yw) if l in KEEP]
    def thin(fT, fW):
        T = fT([p[0] for p in kt], [p[1] for p in kt]); W = fW([p[0] for p in kw], [p[1] for p in kw]); L = b['length']; n = 600; tot = 0
        for i in range(n + 1):
            x = L * i / n; w = 1 if i in (0, n) else (4 if i % 2 else 2); tot += w * max(T(x), 0) * max(W(x), 0)
        return tot * (L / n) / 3 / 61.0237
    loss['today (pchip, pchip)'].append(100 * (thin(fit_pchip, fit_pchip) / full - 1))
    loss['square-root thickness, pchip width'].append(100 * (thin(sq_fall, fit_pchip) / full - 1))
    loss['square-root thickness and width'].append(100 * (thin(sq_fall, sq_fall) / full - 1))
print('\ndense US Blanks cut down to five stations: how far the width x thickness integral drifts from its full-station value')
for k, v in loss.items():
    s = sorted(v); print(f'   {k:38s} median {s[len(s)//2]:+.2f}%   range {s[0]:+.2f}% .. {s[-1]:+.2f}%   (n={len(s)})')

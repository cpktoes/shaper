
import { preparePchip } from "/Users/kontoes/Code/shaper/lib/geometry/pchip";
import { readFileSync } from "node:fs";
const cases = JSON.parse(readFileSync(process.argv[2], "utf8"));
const out = cases.map((c: any) => { const p = preparePchip(c.x.map((x: number, i: number) => ({ x, y: c.y[i] }))); return c.q.map((q: number) => p.sample(q)); });
console.log(JSON.stringify(out));

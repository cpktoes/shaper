import math, json, collections
from data import load, unique_rockers
from models import *
us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
KEEP = ['T0', 'T12', 'C', 'N12', 'N0']
def fit_sqrt_pchip(xs, ys):
    lo = min(ys); first = ys.index(lo)
    s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
    g = fit_pchip(list(xs), s)
    return lambda x: lo + g(x) ** 2
print('Marko blanks with all five Arctic stations and at least 7 printed: mean/worst miss thinned to 5 (today | sqrt)')
for b in mk:
    if all(k in b['labels'] for k in KEEP) and len(b['xs']) >= 7:
        kx = [x for l, x, y in b['st'] if l in KEEP]; ky = [y for l, x, y in b['st'] if l in KEEP]
        hid = [(l, x, y) for l, x, y in b['st'] if l not in KEEP]
        fp, fs = fit_pchip(kx, ky), fit_sqrt_pchip(kx, ky)
        ep = [abs(fp(x) - y) for l, x, y in hid]; es = [abs(fs(x) - y) for l, x, y in hid]
        print(f"   {b['name']:22s} {len(b['xs'])} st  today {sum(ep)/len(ep):.3f}/{max(ep):.3f}   sqrt {sum(es)/len(es):.3f}/{max(es):.3f}")
def pick(blanks, name):
    return next(b for b in blanks if b['name'] == name)
sel = [
    ('US Blanks 9\'9"B — typical longboard, 15 stations printed', pick(us, '9\'9"B')),
    ('US Blanks 6\'3"EA — typical shortboard, 11 stations printed', pick(us, '6\'3"EA')),
    ('US Blanks 11\'8"BG — today\'s worst case, 15 stations printed', pick(us, '11\'8"BG')),
    ('Marko 9\'1" Machine All — 10 stations printed', pick(mk, '9\'1" Machine All')),
    ('Arctic 9\'4" G — only 5 stations printed', pick(ar, '9\'4" G')),
    ('Arctic 6\'4" SBF — only 5 stations printed', pick(ar, '6\'4" SBF')),
]
out = []
for title, b in sel:
    out.append(dict(t=title, L=round(b['xs'][-1], 3), st=[[l, round(x, 3), y] for l, x, y in b['st']]))
    kx = [x for l, x, y in b['st'] if l in KEEP]; ky = [y for l, x, y in b['st'] if l in KEEP]
    fp, fs = fit_pchip(kx, ky), fit_sqrt_pchip(kx, ky)
    probe = [kx[0] + i * (kx[-1] - kx[0]) / 7 for i in range(8)]
    out[-1]['check'] = [[round(x, 4), fp(x), fs(x)] for x in probe]
json.dump(out, open('chart_blanks.json', 'w'))
print(json.dumps([{k: v for k, v in o.items() if k != 'check'} for o in out])[:1500])

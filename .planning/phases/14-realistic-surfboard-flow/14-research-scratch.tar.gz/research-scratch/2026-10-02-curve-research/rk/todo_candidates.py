import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats

us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
A5 = "T0 T12 C N12 N0"; M7 = "T0 T12 T24 C N24 N12 N0"

def fit_sqrt_pchip(xs, ys):
    lo = min(ys); first = ys.index(lo)
    s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
    g = fit_pchip(list(xs), s)
    return lambda x: lo + g(x) ** 2

def make_cardinal(c):   # Catmull-Rom / cardinal family: three-point tangents scaled by (1 - tension)
    return lambda xs, ys: hermite(xs, ys, [(1 - c) * m for m in slopes_fd(xs, ys)])

def make_mono_tension(c):  # monotone cubic with tension: pchip tangents scaled by (1 - tension)
    return lambda xs, ys: hermite(xs, ys, [(1 - c) * m for m in slopes_pchip(xs, ys)])

def make_tip_ramp(qn, qt, body=fit_pchip, n_in=12.0):
    """The Oct-1 note's leading guess: keep the body spline, replace the last foot at each end with a
    power ramp that leaves the 12in station at the body's own slope and reaches the tip:
    y = y12 + m12*d + (rise - m12*L)*(d/L)^q."""
    def fit(xs, ys):
        f = body(xs, ys); ms = f.ms; n = len(xs)
        def g(x):
            if x < xs[1] and abs((xs[1] - xs[0]) - n_in) < 1e-6:
                L = xs[1] - xs[0]; d = xs[1] - x; m = -ms[1]
                return ys[1] + m * d + (ys[0] - ys[1] - m * L) * (d / L) ** qt
            if x > xs[-2] and abs((xs[-1] - xs[-2]) - n_in) < 1e-6:
                L = xs[-1] - xs[-2]; d = x - xs[-2]; m = ms[-2]
                return ys[-2] + m * d + (ys[-1] - ys[-2] - m * L) * (d / L) ** qn
            return f(x)
        return g
    return fit

def fit_clamped_natural_tiprule(xs, ys):
    """'Clamped natural spline with the tip rules on top': C2 spline, level at the low station,
    natural (straight-running) at the tips."""
    return fit_flat_nat(xs, ys)

# fit the tip-ramp exponents on the dense data (best case for that idea: tuned on the very stations it is scored on)
best = None
for qn in (1.2, 1.4, 1.6, 1.8, 2.0, 2.2, 2.5, 3.0):
    for qt in (1.2, 1.4, 1.6, 1.8, 2.0, 2.2, 2.5, 3.0):
        _, out = run(dense, A5, {'m': make_tip_ramp(qn, qt)})
        e = [r[4] - r[3] for r in out['m'] if r[1] in ('T6', 'N6')]
        s = stats(e)['rms']
        if best is None or s < best[0]: best = (s, qn, qt)
print(f'tip-ramp exponents fitted on the US dense data: nose {best[1]}, tail {best[2]} (RMS at T6/N6 {best[0]:.3f})')

cands = collections.OrderedDict([
    ('pchip (today)', fit_pchip),
    ('SQUARE-ROOT pchip', fit_sqrt_pchip),
    ('pchip + fitted power tip ramp (Oct-1 leading guess)', make_tip_ramp(best[1], best[2])),
    ('monotone cubic, tension 0.25', make_mono_tension(0.25)),
    ('monotone cubic, tension 0.5', make_mono_tension(0.5)),
    ('monotone cubic, tension -0.25 (looser)', make_mono_tension(-0.25)),
    ('Steffen monotone', fit_steffen),
    ('Catmull-Rom (tension 0)', make_cardinal(0.0)),
    ('cardinal, tension 0.25', make_cardinal(0.25)),
    ('cardinal, tension 0.5', make_cardinal(0.5)),
    ('cubic B-spline through the stations (not-a-knot)', fit_notaknot),
    ('cubic B-spline through the stations (natural ends)', fit_natural),
    ('clamped natural spline + level-centre rule', fit_clamped_natural_tiprule),
    ('monotone C2 (Hyman-filtered)', fit_hyman),
    ('Akima', fit_akima),
])
REGIONS = collections.OrderedDict([('tail last ft', ['T6']), ('tail body', ['T18', 'T24', 'T36', 'T48']), ('nose body', ['N48', 'N36', 'N24', 'N18']), ('nose last ft', ['N6'])])
_, out = run(dense, A5, cands)
print('\n5-station (Arctic) pattern on the 68 dense US curves — mean miss in inches, by region, then overall mean / median / worst; and the bias in the nose body')
print(f'{"candidate":52s}' + ''.join(f'{r:>14s}' for r in REGIONS) + f'{"ALL mean":>10s}{"median":>8s}{"worst":>8s}{"nose-body bias":>16s}')
rows = []
for k in cands:
    line = f'{k:52s}'
    for r, labs in REGIONS.items():
        e = [abs(x[4] - x[3]) for x in out[k] if x[1] in labs]
        line += f'{sum(e)/len(e):14.3f}'
    e = sorted(abs(x[4] - x[3]) for x in out[k]); nb = [x[4] - x[3] for x in out[k] if x[1] in REGIONS['nose body']]
    line += f'{sum(e)/len(e):10.3f}{e[len(e)//2]:8.3f}{e[-1]:8.3f}{sum(nb)/len(nb):+16.3f}'
    rows.append((sum(e)/len(e), line))
for _, line in sorted(rows): print(line)

print('\nrobustness to a few wrong catalogue cells: drop every curve that owns one of the 12 worst-explained stations, and re-score')
worst = sorted(out['SQUARE-ROOT pchip'], key=lambda r: -abs(r[4] - r[3]))[:12]
bad = {r[0] for r in worst}
print('   dropped:', sorted(bad))
for k in ('pchip (today)', 'SQUARE-ROOT pchip', 'cubic B-spline through the stations (not-a-knot)', 'Catmull-Rom (tension 0)'):
    e = sorted(abs(x[4] - x[3]) for x in out[k] if x[0] not in bad)
    print(f'   {k:52s} mean {sum(e)/len(e):.3f}  median {e[len(e)//2]:.3f}  worst {e[-1]:.3f}   ({len(e)} stations)')

print('\ntypo scan (by-product): dense US stations that sit > 0.12 in from what the neighbours imply under ALL of three different curve types (leave-one-out)')
three = [fit_sqrt_pchip, fit_pchip, fit_notaknot]
hits = []
for b in [x for x in us if 'T6' in x['labels']]:
    xs, ys, lab = b['xs'], b['ys'], b['labels']
    for i in range(1, len(xs) - 1):
        if lab[i] == 'C': continue
        d = [ys[i] - f(xs[:i] + xs[i+1:], ys[:i] + ys[i+1:])(xs[i]) for f in three]
        if all(abs(v) > 0.12 for v in d) and (all(v > 0 for v in d) or all(v < 0 for v in d)):
            hits.append((min(abs(v) for v in d), b['name'], lab[i], ys[i], d))
hits.sort(reverse=True)
for h in hits: print(f'   {h[1]:14s} {h[2]:4s} printed {h[3]:.3f} in — neighbours imply {h[3]-h[4][0]:.3f} (sits {h[4][0]:+.3f} / {h[4][1]:+.3f} / {h[4][2]:+.3f} off)')

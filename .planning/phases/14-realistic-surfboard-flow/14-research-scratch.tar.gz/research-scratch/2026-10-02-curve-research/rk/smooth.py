import math, collections
from data import load, unique_rockers
from models import *
from experiment import run, stats
us = load('US Blanks'); ar = load('Arctic Foam'); mk = load('Marko Foam')
dense = unique_rockers([b for b in us if 'T6' in b['labels']])
def root_with(base):
    def fit(xs, ys):
        lo = min(ys); first = ys.index(lo)
        s = [(-1 if i < first else 1) * math.sqrt(max(y - lo, 0.0)) for i, y in enumerate(ys)]
        g = base(list(xs), s)
        f = lambda x: lo + g(x) ** 2
        f.g = g
        return f
    return fit
cands = collections.OrderedDict([
    ('pchip (today)', fit_pchip),
    ('sqrt + pchip', root_with(fit_pchip)),
    ('sqrt + Hyman-filtered C2', root_with(fit_hyman)),
    ('sqrt + Hyman-filtered 3pt', root_with(fit_hyman_fd)),
    ('sqrt + Steffen', root_with(fit_steffen)),
    ('sqrt + plain C2 (no filter)', root_with(fit_notaknot)),
])
def d2(f, x, side, e=1e-3):
    return (f(x) - 2*f(x - e) + f(x - 2*e))/e**2 if side < 0 else (f(x + 2*e) - 2*f(x + e) + f(x))/e**2
def audit(tag, blanks):
    print(f'  {tag}')
    for k, fit in cands.items():
        jumps = []; ratios = []; bumps = 0; wb = 0.0; nonmono = 0
        for b in blanks:
            xs, ys = b['xs'], b['ys']; f = fit(xs, ys)
            for j in range(1, len(xs) - 1):
                if ys[j] == min(ys): continue
                l, r = d2(f, xs[j], -1), d2(f, xs[j], +1)
                jumps.append(abs(r - l))
                if min(abs(l), abs(r)) > 1e-5: ratios.append(max(abs(l), abs(r)) / min(abs(l), abs(r)))
            n = int(round(b['length'] / 0.25)); dx = (xs[-1] - xs[0]) / n
            g = [f(xs[0] + i * dx) for i in range(n + 1)]
            w = int(round(6 / dx)); bb = max(g[i + w//2] - (g[i] + g[i + w]) / 2 for i in range(0, n + 1 - w))
            if bb > 0.005: bumps += 1
            wb = max(wb, bb)
            lo = min(ys); i0 = ys.index(lo)
            xm = xs[i0]; im = int(round((xm - xs[0]) / dx))
            if any(g[i] < g[i + 1] - 1e-9 for i in range(0, im)) or any(g[i] > g[i + 1] + 1e-9 for i in range(im + 1, n)): nonmono += 1
        jumps.sort(); ratios.sort()
        q = lambda v, p: v[min(len(v) - 1, int(p * len(v)))]
        print(f'     {k:28s} bend-change at a station: median {q(jumps,0.5):.4f}  90% {q(jumps,0.9):.4f}  max {jumps[-1]:.4f} | bend ratio across a station: median x{q(ratios,0.5):.2f}  90% x{q(ratios,0.9):.2f} | bumps {bumps} (max {wb:.3f}) | not steadily rising: {nonmono}   of {len(blanks)}')
audit('33 real Arctic blanks', ar)
audit('28 real Marko blanks', mk)
audit('101 real US Blanks', us)
for lay, tag in (('T0 T12 C N12 N0', '5-station test'), ('T0 T12 T24 C N24 N12 N0', '7-station test')):
    _, out = run(dense, lay, cands)
    print(f'  accuracy, {tag}: ' + ' | '.join(f"{k}: {sum(abs(r[4]-r[3]) for r in out[k])/len(out[k]):.3f}" for k in cands))
mku = unique_rockers(mk)
_, out = run([b for b in mku if b['name'] not in ('8\'0" Gun', '10\'6" Gun')], 'T0 T12 C N12 N0', cands)
print('  accuracy, Marko thinned to 5 (18 curves): ' + ' | '.join(f"{k}: {sum(abs(r[4]-r[3]) for r in out[k])/len(out[k]):.3f}" for k in cands))
errs = {k: [] for k in cands}
for b in dense:
    xs, ys, lab = b['xs'], b['ys'], b['labels']
    for i in range(1, len(xs)-1):
        if lab[i] == 'C': continue
        for k, fit in cands.items(): errs[k].append(abs(fit(xs[:i] + xs[i+1:], ys[:i] + ys[i+1:])(xs[i]) - ys[i]))
print('  accuracy, leave-one-out on the dense tables: ' + ' | '.join(f"{k}: {sum(v)/len(v):.3f} (worst {max(v):.3f})" for k, v in errs.items()))

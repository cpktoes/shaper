import math, collections
from data import load, unique_rockers
us = load('US Blanks')
print('US Blanks:', len(us), 'blanks;', len(unique_rockers(us)), 'distinct rocker curves')
dense = [b for b in us if 'T6' in b['labels']]
du = unique_rockers(dense)
print('with 6" tip spacing:', len(dense), 'blanks ->', len(du), 'distinct rocker curves')
by = collections.Counter(len(b['xs']) for b in du)
print('  distinct curves by knot count:', sorted(by.items()))
by2 = collections.Counter(len(b['xs']) for b in dense)
print('  blanks by knot count:', sorted(by2.items()))

# where is the low point?
cnt = collections.Counter()
for b in du:
    lo = min(b['ys'])
    lows = tuple(l for l, y in zip(b['labels'], b['ys']) if y - lo < 1e-9)
    cnt[(lows, round(lo, 3))] += 1
print('lowest stations (label set, value):')
for k, v in cnt.most_common(): print('   ', v, k)

# is the measured curve convex? second divided differences over consecutive triples
neg = []
allsd = 0
for b in du:
    xs, ys = b['xs'], b['ys']
    for i in range(1, len(xs)-1):
        h0, h1 = xs[i]-xs[i-1], xs[i+1]-xs[i]
        sd = 2*((ys[i+1]-ys[i])/h1 - (ys[i]-ys[i-1])/h0)/(h0+h1)
        allsd += 1
        if sd < -1e-9:
            # how big a nudge (in inches at the middle station) would straighten it
            mid = ys[i-1] + (ys[i+1]-ys[i-1])*h0/(h0+h1)
            neg.append((ys[i]-mid, b['name'], b['labels'][i]))
print('station triples:', allsd, ' concave (middle station sits ABOVE the chord):', len(neg))
neg.sort(reverse=True)
for d, n, l in neg[:25]: print(f'    {n:14s} {l:4s} sits {d:.3f} in above the straight line between its neighbours')
c = collections.Counter(l for _,_,l in neg); print('   by station:', c.most_common())

# local exponent: lift ~ distance^p from the centre. p between successive stations per side
def side_exps(b):
    xs, ys, lab = b['xs'], b['ys'], b['labels']
    ic = lab.index('C'); xc = xs[ic]; lo = ys[ic]
    res = {}
    for i in range(len(xs)-1):
        j = i+1
        if i >= ic:
            d0, d1, y0, y1 = xs[i]-xc, xs[j]-xc, ys[i]-lo, ys[j]-lo
            key = (lab[i], lab[j])
        else:
            d0, d1, y0, y1 = xc-xs[j], xc-xs[i], ys[j]-lo, ys[i]-lo
            key = (lab[j], lab[i])
        if d0 > 0 and y0 > 0.2 and y1 > y0:
            res[key] = math.log(y1/y0)/math.log(d1/d0)
    return res
agg = collections.defaultdict(list)
for b in du:
    for k, p in side_exps(b).items(): agg[k].append(p)
print('local exponent p (lift ~ distance-from-centre ^ p), median [10th..90th pct], n:')
for k in [('T36','T24'),('T24','T18'),('T18','T12'),('T12','T6'),('T6','T0'),('N36','N24'),('N24','N18'),('N18','N12'),('N12','N6'),('N6','N0')]:
    v = sorted(agg.get(k, []))
    if v:
        q = lambda f: v[min(len(v)-1, int(f*len(v)))]
        print(f'   {k[0]:>4}->{k[1]:<4} {q(0.5):5.2f}  [{q(0.1):4.2f}..{q(0.9):4.2f}]  n={len(v)}')

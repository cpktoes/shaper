const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
const dir = __dirname;
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  for (const mode of ['light', 'dark']) {
    const page = await browser.newPage({ viewport: { width: 712, height: 600 }, deviceScaleFactor: 2 });
    page.on('console', (m) => { if (m.type() === 'error') errors.push(mode + ': ' + m.text()); });
    page.on('pageerror', (e) => errors.push(mode + ': ' + e.message));
    await page.goto('file://' + dir + '/preview-' + mode + '.html');
    await page.waitForFunction(() => window.Chart && document.querySelector('#tp-read').textContent.length > 0, null, { timeout: 15000 });
    await page.waitForTimeout(300);
    await page.screenshot({ path: dir + '/tip-' + mode + '-0.png', fullPage: true });
    console.log(mode, 0, await page.textContent('#tp-read'));
    if (mode === 'light') {
      await page.click('#tp-auto'); await page.waitForTimeout(100);
      await page.screenshot({ path: dir + '/tip-light-0-auto.png', fullPage: true });
      console.log('auto', await page.textContent('#tp-start-out'), '|', await page.textContent('#tp-read'));
      await page.click('#tp-r0'); await page.waitForTimeout(100);
      await page.screenshot({ path: dir + '/tip-light-0-auto-sblend.png', fullPage: true });
      console.log('auto + S-blend', await page.textContent('#tp-read'));
      await page.click('#tp-r1');
      for (const i of [1, 2, 3, 4]) {
        await page.selectOption('#tp-board', String(i)); await page.waitForTimeout(100);
        console.log(i, 'at 12:', await page.textContent('#tp-read'));
        await page.click('#tp-auto'); await page.waitForTimeout(100);
        console.log(i, 'auto', await page.textContent('#tp-start-out'), '|', await page.textContent('#tp-read'));
        await page.screenshot({ path: dir + '/tip-light-' + i + '-auto.png', fullPage: true });
      }
      await page.selectOption('#tp-board', '3');
      await page.evaluate(() => { const s = document.querySelector('#tp-start'); s.value = s.max; s.dispatchEvent(new Event('input', { bubbles: true })); });
      await page.waitForTimeout(100);
      await page.screenshot({ path: dir + '/tip-light-3-centre.png', fullPage: true });
      console.log('3 centre', await page.textContent('#tp-start-out'), '|', await page.textContent('#tp-read'));
    }
    await page.close();
  }
  console.log('errors:', JSON.stringify(errors));
  await browser.close();
})();

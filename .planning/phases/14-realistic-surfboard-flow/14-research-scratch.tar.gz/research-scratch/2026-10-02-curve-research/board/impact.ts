import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm, type PreparedBlank } from "./lib";
import { boardOnBlank, fitAt, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";

const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
const W = inch(12);
type Row = { vendor: string; name: string; nst: number; centre: number; place: string; d: Record<string, number>; fit: [boolean, boolean, boolean]; thin: [boolean, boolean, boolean] };
const rows: Row[] = [];
let boards = 0;
const vendorsCount: Record<string, number> = {};
for (const record of catalog) {
  const today = prepareBlank(record);
  const newR = prepareNew(record, { thickness: false });
  const newRT = prepareNew(record, { thickness: true });
  const L = mm(today.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(today, board, settings).passes) continue;
    const { min, max } = placementRange(today.lengthMm, L);
    for (const [place, p] of [["tail", min], ["centre", mm(0)], ["nose", max]] as const) {
      boards++;
      vendorsCount[record.vendor] = (vendorsCount[record.vendor] ?? 0) + 1;
      const a = boardOnBlank(today, board, p), b = boardOnBlank(newR, board, p), c2 = boardOnBlank(newRT, board, p);
      const st = { tailTip: 0, tail12: W, center: L / 2, nose12: L - W, noseTip: L };
      const d: Record<string, number> = {};
      for (const [k, s] of Object.entries(st)) {
        d["rk_" + k] = (c2.rockerAt(s) - a.rockerAt(s)) / IN;
        d["th_" + k] = (c2.thicknessAt(s) - a.thicknessAt(s)) / IN;
        d["rkOnly_" + k] = (b.rockerAt(s) - a.rockerAt(s)) / IN;
      }
      let mr = 0, mt = 0, md = 0;
      const n = Math.round(L / inch(0.5));
      for (let i = 0; i <= n; i++) {
        const s = (L * i) / n;
        mr = Math.max(mr, Math.abs(c2.rockerAt(s) - a.rockerAt(s)));
        mt = Math.max(mt, Math.abs(c2.thicknessAt(s) - a.thicknessAt(s)));
        md = Math.max(md, Math.abs(c2.rockerAt(s) + c2.thicknessAt(s) - a.rockerAt(s) - a.thicknessAt(s)));
      }
      d.maxRocker = mr / IN; d.maxThick = mt / IN; d.maxDeck = md / IN;
      // thin spot: somewhere in a tip window the board is thinner than its own tip setting
      const thin = (o: typeof a) => {
        let worst = 0;
        for (let i = 0; i <= 96; i++) {
          const s = (W * i) / 96;
          worst = Math.max(worst, board.tailTip - o.thicknessAt(s), board.noseTip - o.thicknessAt(L - s));
        }
        return worst > inch(0.005);
      };
      const fit = (o: typeof a) => fitAt(o, () => mm(0), mm(L / 2), settings).fits;
      rows.push({ vendor: record.vendor, name: record.name, nst: record.stations.filter((s) => s.rockerMm !== null).length, centre: c, place, d, fit: [fit(a), fit(b), fit(c2)], thin: [thin(a), thin(b), thin(c2)] });
    }
  }
}
const q = (v: number[], p: number) => { const s = [...v].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const fmt = (v: number) => v.toFixed(3);
console.log(`stress set: ${boards} boards on ${catalog.length} pickable blanks`, JSON.stringify(vendorsCount));
for (const vendor of ["Arctic Foam", "Marko Foam", "US Blanks"]) {
  const r = rows.filter((x) => x.vendor === vendor);
  console.log(`\n== ${vendor}: ${r.length} boards — what moves when BOTH curves change (square-root bottom + square-root thinning), today's 12in tip rule kept; inches`);
  for (const k of ["rk_tailTip", "rk_tail12", "rk_center", "rk_nose12", "rk_noseTip", "th_tail12", "th_nose12", "maxRocker", "maxThick", "maxDeck"]) {
    const v = r.map((x) => Math.abs(x.d[k]));
    const signed = r.map((x) => x.d[k]);
    console.log(`   ${k.padEnd(11)} median |move| ${fmt(q(v, 0.5))}  90% ${fmt(q(v, 0.9))}  max ${fmt(Math.max(...v))}   mean signed ${fmt(signed.reduce((a, b) => a + b, 0) / signed.length)}   moved > 1/16: ${v.filter((x) => x > 0.0625).length}`);
  }
  const flips = (i: number) => r.filter((x) => x.fit[0] !== x.fit[i]).length;
  console.log(`   fit (no width check): fits today ${r.filter((x) => x.fit[0]).length}; new rocker only ${r.filter((x) => x.fit[1]).length} (${flips(1)} flips); both ${r.filter((x) => x.fit[2]).length} (${flips(2)} flips: ${r.filter((x) => x.fit[0] && !x.fit[2]).length} lost, ${r.filter((x) => !x.fit[0] && x.fit[2]).length} gained)`);
  console.log(`   thin spot below the tip setting inside a tip window: today ${r.filter((x) => x.thin[0]).length}; both new ${r.filter((x) => x.thin[2]).length}`);
}

import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
const big: Record<string, number> = {}; const inherit: Record<string, number> = {};
for (const record of catalog) {
  const today = prepareBlank(record), neu = prepareNew(record, { thickness: true });
  const L = mm(today.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(today, board, settings).passes) continue;
    const { min, max } = placementRange(today.lengthMm, L);
    for (const p of [min, mm(0), max]) {
      const a = boardOnBlank(today, board, p), b = boardOnBlank(neu, board, p);
      const d = Math.abs(b.rockerAt(inch(12)) - a.rockerAt(inch(12))) / IN;
      if (record.vendor === "Marko Foam" && d > 0.0625) big[record.name] = Math.max(big[record.name] ?? 0, d);
      // the planer cut itself thicker nearer a tip than further in (the blank's thickest station is not its centre)
      const drop = b.blankThicknessAt(L / 2) - board.centerThickness; let run = -Infinity, hump = 0;
      for (const dir of [1, -1]) { run = -Infinity; for (let x = inch(36); x <= L / 2; x += inch(0.125)) { const s = dir === 1 ? x : L - x; const v = b.blankThicknessAt(s) - drop; run = Math.max(run, v); hump = Math.max(hump, run - v); } }
      if (hump > inch(0.005)) inherit[`${record.vendor} ${record.name}`] = Math.max(inherit[`${record.vendor} ${record.name}`] ?? 0, hump / IN);
    }
  }
}
console.log("Marko blanks whose board tail-12 rocker moves > 1/16:", JSON.stringify(big));
console.log("blanks whose own foil is thicker away from the centre (inside 36in of a tip excluded):", JSON.stringify(inherit));

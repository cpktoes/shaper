import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { writeFileSync } from "node:fs";
const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
const stress = (name: string, vendor: string, c: number, place: "tail" | "centre" | "nose") => {
  const record = catalog.find((r) => r.vendor === vendor && r.name === name)!;
  const base = prepareBlank(record), prep = prepareNew(record, { thickness: true });
  const L = mm(base.lengthMm - inch(2));
  const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
  const { min, max } = placementRange(base.lengthMm, L);
  const p = place === "tail" ? min : place === "nose" ? max : mm(0);
  return { on: boardOnBlank(prep, board, p), old: boardOnBlank(base, board, p), passes: floorCheck(base, board, settings).passes };
};
const out: any[] = [];
function add(title: string, on: ReturnType<typeof boardOnBlank>, end: "tail" | "nose") {
  const L = on.board.length, drop = on.blankThicknessAt(L / 2) - on.board.centerThickness;
  const P: number[] = [];
  for (let d = 0; d <= L / 2 + 1e-6; d += inch(0.5)) P.push(+(((on.blankThicknessAt(end === "tail" ? d : L - d) - drop) / IN).toFixed(4)));
  out.push({ t: title, tip: +((end === "tail" ? on.board.tailTip : on.board.noseTip) / IN).toFixed(4), P });
}
const e1 = stress("10'9\" LB", "Arctic Foam", 2.5, "centre");
console.log("E1 today (old curves, app rule): 12in", (e1.old.thicknessAt(inch(12)) / IN).toFixed(3), "10in", (e1.old.thicknessAt(inch(10)) / IN).toFixed(3), "2in", (e1.old.thicknessAt(inch(2)) / IN).toFixed(3), "tip", (e1.old.thicknessAt(0) / IN).toFixed(3));
add("Arctic 10'9\" LB cut to a 2 1/2\" centre — tail (humps today)", e1.on, "tail");
const e2 = stress("10'6\" G", "Arctic Foam", 2.25, "tail");
console.log("E2 passes floor:", e2.passes, " today 12in", (e2.old.thicknessAt(inch(12)) / IN).toFixed(3), "11in", (e2.old.thicknessAt(inch(11)) / IN).toFixed(3), "1in", (e2.old.thicknessAt(inch(1)) / IN).toFixed(3));
add("Arctic 10'6\" G cut to a 2 1/4\" centre, slid to the tail — tail (worst case today)", e2.on, "tail");
// the worst US Blanks hump in the stress set
let best: any = null;
for (const record of catalog.filter((r) => r.vendor === "US Blanks")) {
  for (const c of [2.25, 2.5, 2.75, 3]) for (const place of ["tail", "centre", "nose"] as const) {
    const s = stress(record.name, "US Blanks", c, place); if (!s.passes) continue;
    for (const end of ["tail", "nose"] as const) {
      const L = s.on.board.length, tip = end === "tail" ? s.on.board.tailTip : s.on.board.noseTip; let thin = 0;
      for (let d = 0; d <= inch(12); d += inch(0.25)) thin = Math.max(thin, tip - s.on.derivedThicknessAt(end === "tail" ? d : L - d));
      if (!best || thin > best.thin) best = { thin, name: record.name, c, place, end, on: s.on };
    }
  }
}
console.log("worst US Blanks thin spot:", best.name, best.c, best.place, best.end, (best.thin / IN).toFixed(3));
add(`US Blanks ${best.name} cut to a ${best.c}" centre — ${best.end}`, best.on, best.end);
for (const preset of BOARD_PRESETS.filter((p) => /short|long/i.test(p.name))) {
  const f = presetDesignFields(preset), b = f.blank;
  const on = boardOnBlank(prepareNew(b.copy, { thickness: true }), { length: f.outline.length, centerThickness: f.foil.center, noseTip: f.foil.noseTip, tailTip: f.foil.tailTip, nose12Offset: b.nose12Offset, tail12Offset: b.tail12Offset, deckSkin: b.deckSkin, tipStyle: b.tipStyle, fineTuneSurface: b.fineTuneSurface }, b.placement);
  add(`${preset.name} preset on US Blanks ${b.copy.name} — nose (tapers steadily today)`, on, "nose");
}
writeFileSync(new URL("./examples.json", import.meta.url), JSON.stringify(out));
console.log(out.map((o) => `${o.t} | tip ${o.tip} | P0 ${o.P[0]} P12 ${o.P[24]} P24 ${o.P[48]} half ${(o.P.length - 1) / 2}in`).join("\n"));

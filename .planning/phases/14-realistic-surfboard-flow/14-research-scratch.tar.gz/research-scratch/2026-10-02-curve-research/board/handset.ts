import { prepareRoot, preparePchip, inch, IN, mm } from "./lib";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { DEFAULT_BOARD_SPEC } from "/Users/kontoes/Code/shaper/lib/geometry/board";
import { deriveEffectiveRails } from "/Users/kontoes/Code/shaper/lib/geometry/design";
import { computeCrossSectionVolume } from "/Users/kontoes/Code/shaper/lib/geometry/volume";
import { DEFAULT_RAIL_BAND_SPEC } from "/Users/kontoes/Code/shaper/lib/geometry/rail-bands";
import { DEFAULT_FOIL_SPEC, foilStationPoints } from "/Users/kontoes/Code/shaper/lib/geometry/foil";
const spec = DEFAULT_BOARD_SPEC.outline, L = spec.length, outline = buildOutline(spec);
const pts = foilStationPoints(DEFAULT_FOIL_SPEC, L).map((p) => ({ x: p.station, y: p.thickness }));
const rails = deriveEffectiveRails(DEFAULT_RAIL_BAND_SPEC, DEFAULT_FOIL_SPEC, true);
for (const [name, curve] of [["pchip (today)", preparePchip(pts)], ["square-root thinning", prepareRoot(pts, "fall")]] as const) {
  const v = computeCrossSectionVolume({ halfWidthAt: (s) => sampleOutline(outline, s), foil: DEFAULT_FOIL_SPEC, thicknessAt: (s) => mm(curve.sample(s)), rails, length: L });
  console.log(`default hand-set board (${(L / IN).toFixed(1)} in): ${name.padEnd(22)} ${v.volumeLitres.toFixed(2)} L`);
}

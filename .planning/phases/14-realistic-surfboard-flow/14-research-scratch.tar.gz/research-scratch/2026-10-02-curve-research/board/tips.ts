import { catalog, prepareBlank, prepareNew, prepareRoot, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, blankStationOf, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";

const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
const smooth = (w: number) => { const t = Math.min(1, Math.max(0, w)); return t * t * (3 - 2 * t); };
const square = (w: number) => { const t = Math.min(1, Math.max(0, w)); return t * t; };
type Kind = "smooth" | "square" | "reknot";

/** The board's thickness under one tip rule. W = how far in from each tip the thinning starts. */
export function thicknessUnder(on: ReturnType<typeof boardOnBlank>, kind: Kind, Win: number) {
  const b = on.board, L = b.length, W = Math.min(Win, L / 2);
  const drop = on.blankThicknessAt(L / 2) - b.centerThickness;
  const P = (s: number) => on.blankThicknessAt(s) - drop;
  if (kind !== "reknot") {
    const e = kind === "smooth" ? smooth : square;
    const tailUn = P(0), noseUn = P(L);
    return { P, T: (s: number) => {
      let v = P(s);
      if (s < W) v += (b.tailTip - tailUn) * e(1 - s / W);
      if (s > L - W) v += (b.noseTip - noseUn) * e(1 - (L - s) / W);
      return v;
    } };
  }
  // re-knot: the tip settings at the tips, the planer-cut thickness where the thinning starts and at every
  // blank thickness station between the two starts, one square-root curve through them all.
  const u0 = blankStationOf(mm(0), on.placement, L, on.prepared.lengthMm);
  const pts: { x: number; y: number }[] = [{ x: 0, y: b.tailTip }];
  if (W < L / 2 - 1) pts.push({ x: W, y: P(W) });
  for (const x of on.prepared.thickness.xs) {
    const s = x - u0;
    if (s > W + inch(1) && s < L - W - inch(1)) pts.push({ x: s, y: P(s) });
  }
  if (W < L / 2 - 1) pts.push({ x: L - W, y: P(L - W) }); else if (!pts.some((p) => Math.abs(p.x - L / 2) < 1)) pts.push({ x: L / 2, y: P(L / 2) });
  pts.push({ x: L, y: b.noseTip });
  pts.sort((p, q) => p.x - q.x);
  const curve = prepareRoot(pts, "fall");
  return { P, T: (s: number) => curve.sample(s) };
}

type B = { vendor: string; name: string; c: number; place: string; on: ReturnType<typeof boardOnBlank> };
const boards: B[] = [];
for (const record of catalog) {
  const base = prepareBlank(record);
  const prep = prepareNew(record, { thickness: true });
  const L = mm(base.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(base, board, settings).passes) continue;
    const { min, max } = placementRange(base.lengthMm, L);
    for (const [place, p] of [["tail", min], ["centre", mm(0)], ["nose", max]] as const) boards.push({ vendor: record.vendor, name: record.name, c, place, on: boardOnBlank(prep, board, p) });
  }
}
// self-check: my "smooth, 12in" is the app's own rule
let worst = 0;
for (const b of boards.slice(0, 200)) { const t = thicknessUnder(b.on, "smooth", inch(12)); for (let i = 0; i <= 50; i++) { const s = (b.on.board.length * i) / 50; worst = Math.max(worst, Math.abs(t.T(s) - b.on.derivedThicknessAt(s))); } }
console.log("self-check vs the app's own thickness (mm):", worst.toExponential(2), "| boards:", boards.length);

function audit(b: B, kind: Kind, W: number) {
  const { P, T } = thicknessUnder(b.on, kind, W);
  const L = b.on.board.length, gap = b.on.centerGap, step = inch(0.125);
  let thinBelowTip = 0, hump = 0, dev = 0, poke = 0, floor = 0;
  for (const [tip, dir] of [[b.on.board.tailTip, 1], [b.on.board.noseTip, -1]] as const) {
    let runMax = -Infinity;
    for (let d = 0; d <= L / 2; d += step) {
      const s = dir === 1 ? d : L - d, t = T(s);
      thinBelowTip = Math.max(thinBelowTip, tip - t);
      runMax = Math.max(runMax, t);
      hump = Math.max(hump, runMax - t);            // thicker nearer the tip than further in
      if (d >= Math.min(W, L / 2)) dev = Math.max(dev, Math.abs(t - P(s)));
      poke = Math.max(poke, -(gap + P(s) - t));     // Pin deck: the thinning comes off the bottom
      floor = Math.max(floor, inch(0.25) - t);
    }
  }
  return { thinBelowTip: thinBelowTip / IN, hump: hump / IN, dev: dev / IN, poke: poke / IN, floor: floor / IN };
}
const WS: [string, number][] = [['6"', 6], ['9"', 9], ['12"', 12], ['18"', 18], ['24"', 24], ['36"', 36], ["centre", 999]];
const tol = 0.005;
console.log(`\nTip rule options on ${boards.length} stress boards (new curves; default tips 1/2" nose, 5/8" tail; Pin deck).`);
console.log("columns: boards with a thin spot below the tip setting | boards that get thicker toward a tip (hump > 0.005\") and the largest | largest departure from the planer cut inside the start | pokes out of the bottom | under the 1/4\" floor");
for (const kind of ["smooth", "square", "reknot"] as Kind[]) {
  console.log(`  -- ${kind === "smooth" ? "today's S-shaped blend" : kind === "square" ? "square-law blend (deepest at the tip)" : "one square-root curve through the tip, the start point and the blank's stations between"}`);
  for (const [label, w] of WS) {
    const r = boards.map((b) => audit(b, kind, inch(w)));
    const n = (f: (x: typeof r[number]) => number) => r.filter((x) => f(x) > tol).length;
    const mx = (f: (x: typeof r[number]) => number) => Math.max(...r.map(f));
    console.log(`     start ${label.padEnd(7)} thin-spot ${String(n((x) => x.thinBelowTip)).padStart(4)}   hump ${String(n((x) => x.hump)).padStart(4)} (max ${mx((x) => x.hump).toFixed(3)})   departs ${mx((x) => x.dev).toFixed(3)}   pokes ${String(n((x) => x.poke)).padStart(4)}   under-floor ${String(n((x) => x.floor)).padStart(4)}`);
  }
}
// by maker for today's rule and the two 12in alternatives
for (const vendor of ["Arctic Foam", "Marko Foam", "US Blanks"]) {
  const bs = boards.filter((b) => b.vendor === vendor);
  const line = (["smooth", "square", "reknot"] as Kind[]).map((k) => `${k}: ${bs.filter((b) => audit(b, k, inch(12)).hump > tol).length}`).join("  ");
  console.log(`  humps at a 12" start, ${vendor} (${bs.length} boards): ${line}`);
}

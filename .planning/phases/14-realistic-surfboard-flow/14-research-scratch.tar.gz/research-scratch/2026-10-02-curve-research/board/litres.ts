import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
const out: Record<string, number[]> = {};
for (const record of catalog) {
  const today = prepareBlank(record), neu = prepareNew(record, { thickness: true });
  const L = mm(today.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(today, board, settings).passes) continue;
    const a = boardOnBlank(today, board, mm(0)), b = boardOnBlank(neu, board, mm(0));
    // thickness x blank-width integral as a stand-in for litres (same outline both times, so the ratio is what matters)
    let va = 0, vb = 0;
    for (let i = 0; i <= 400; i++) { const s = (L * i) / 400, w = Math.max(0, a.blankWidthAt(s)); va += a.thicknessAt(s) * w; vb += b.thicknessAt(s) * w; }
    (out[record.vendor] ??= []).push(100 * (vb / va - 1));
  }
}
for (const [v, arr] of Object.entries(out)) { const s = [...arr].sort((x, y) => x - y); console.log(`${v.padEnd(12)} boards ${String(s.length).padStart(4)}: volume change median ${s[s.length >> 1].toFixed(2)}%  range ${s[0].toFixed(2)}% .. ${s[s.length - 1].toFixed(2)}%`); }

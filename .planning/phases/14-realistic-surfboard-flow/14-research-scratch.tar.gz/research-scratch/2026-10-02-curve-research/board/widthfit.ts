import { catalog, prepareBlank, prepareNew, prepareRoot, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, fitAt, type BoardOnBlankInput, type PreparedBlank } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { DEFAULT_BOARD_SPEC } from "/Users/kontoes/Code/shaper/lib/geometry/board";
const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
function withWidth(p: PreparedBlank): PreparedBlank {
  const pts = p.record.stations.filter((s) => s.widthMm !== null).map((s) => ({ x: s.fromTailMm, y: s.widthMm as number }));
  return { ...p, width: prepareRoot(pts, "fall") };
}
const tally: Record<string, { n: number; a: number; b: number; c: number; wideA: number; wideC: number }> = {};
for (const record of catalog) {
  const today = prepareBlank(record), rt = prepareNew(record, { thickness: true }), all = withWidth(rt);
  const centre = record.stations.find((s) => s.label === "C");
  if (!centre || centre.widthMm === null) continue;
  for (const spare of [0.25, 0.5, 1.0]) {                       // board this much narrower than the blank's centre allows
    for (const shorter of [2, 6]) {
      const L = mm(today.lengthMm - inch(shorter));
      const spec = { ...DEFAULT_BOARD_SPEC.outline, length: L, widePointWidth: mm(centre.widthMm - inch(1) - inch(spare)), widePointOffset: mm(0) };
      const outline = buildOutline(spec);
      const board: BoardOnBlankInput = { length: L, centerThickness: inch(2.5), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
      if (!floorCheck(today, board, settings).passes) continue;
      const f = (p: PreparedBlank) => fitAt(boardOnBlank(p, board, mm(0)), (s) => sampleOutline(outline, s), mm(L / 2), settings);
      const a = f(today), b = f(rt), c = f(all);
      const t = (tally[record.vendor] ??= { n: 0, a: 0, b: 0, c: 0, wideA: 0, wideC: 0 });
      t.n++; if (a.fits) t.a++; if (b.fits) t.b++; if (c.fits) t.c++;
      if (!a.fits && a.worst.kind === "wide") t.wideA++; if (!c.fits && c.worst.kind === "wide") t.wideC++;
    }
  }
}
console.log("boards with the default outline, centred, 2\" and 6\" shorter than the blank, 1/4-1\" narrower than the blank's centre allows:");
for (const [v, t] of Object.entries(tally)) console.log(`  ${v.padEnd(12)} ${t.n} boards: fit today ${t.a} (too wide: ${t.wideA}) | new bottom+thickness ${t.b} | plus new width ${t.c} (too wide: ${t.wideC})`);

import { catalog, prepareBlank, prepareNew, floorCheck, inch, IN, mm } from "./lib";
import { boardOnBlank, placementRange, type BoardOnBlankInput } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";

const settings = { extraLength: inch(2), planerMaxDepth: inch(0.125), widthMargin: inch(1) };
type On = ReturnType<typeof boardOnBlank>;

/** Steady taper: the planer cut exactly inside the start point; from the start to the tip one parabola that
 * leaves the planer cut along its own slope and lands on the tip setting. d = distance in from the tip. */
export function steadyTaper(P: (d: number) => number, tip: number, W: number) {
  const PW = P(W), h = 0.5;
  const mW = (P(W + h) - P(W - h)) / (2 * h);
  const sec = (PW - tip) / W;
  const m = Math.max(0, Math.min(mW, 2 * sec));
  return {
    ok: PW >= tip - 1e-9, kink: mW - m,
    T: (d: number) => (d >= W ? P(d) : tip + (2 * sec - m) * d + ((m - sec) / W) * d * d),
  };
}
/** The first start point (>= from) where the board is thick enough to run down to its tip with no hump and no kink. */
export function autoStart(P: (d: number) => number, tip: number, half: number, from: number) {
  for (let W = from; W < half; W += inch(0.5)) {
    const t = steadyTaper(P, tip, W);
    if (t.ok && t.kink <= 1e-6) return W;
  }
  return half;
}

const boards: { vendor: string; name: string; c: number; place: string; on: On }[] = [];
for (const record of catalog) {
  const base = prepareBlank(record), prep = prepareNew(record, { thickness: true });
  const L = mm(base.lengthMm - inch(2));
  for (const c of [2.25, 2.5, 2.75, 3]) {
    const board: BoardOnBlankInput = { length: L, centerThickness: inch(c), noseTip: inch(0.5), tailTip: inch(0.625), nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: inch(0.125), tipStyle: "pinDeck", fineTuneSurface: "deck" };
    if (!floorCheck(base, board, settings).passes) continue;
    const { min, max } = placementRange(base.lengthMm, L);
    for (const [place, p] of [["tail", min], ["centre", mm(0)], ["nose", max]] as const) boards.push({ vendor: record.vendor, name: record.name, c, place, on: boardOnBlank(prep, board, p) });
  }
}
function ends(b: (typeof boards)[number]) {
  const L = b.on.board.length, drop = b.on.blankThicknessAt(L / 2) - b.on.board.centerThickness;
  return [
    { end: "tail", tip: b.on.board.tailTip, P: (d: number) => b.on.blankThicknessAt(d) - drop, half: L / 2, gap: b.on.centerGap },
    { end: "nose", tip: b.on.board.noseTip, P: (d: number) => b.on.blankThicknessAt(L - d) - drop, half: L / 2, gap: b.on.centerGap },
  ];
}
// why the hump: how often is the tip setting thicker than what the planer cut leaves?
let addTip = 0, add12 = 0, nEnds = 0;
for (const b of boards) for (const e of ends(b)) { nEnds++; if (e.P(0) < e.tip - inch(0.005)) addTip++; if (e.P(inch(12)) < e.tip - inch(0.005)) add12++; }
console.log(`${boards.length} boards, ${nEnds} tips: the planer cut leaves LESS than the tip setting at the tip on ${addTip} tips; and still less than the tip setting 12" in on ${add12} tips`);

const tol = inch(0.005);
function score(label: string, startOf: (e: ReturnType<typeof ends>[number]) => number) {
  let humpBoards = 0, thinBoards = 0, kinkBoards = 0, poke = 0, floor = 0, worstHump = 0; const starts: number[] = [];
  for (const b of boards) {
    let hump = 0, thin = 0, kink = 0, pk = 0, fl = 0;
    for (const e of ends(b)) {
      const W = Math.min(startOf(e), e.half); starts.push(W / IN);
      const t = steadyTaper(e.P, e.tip, W);
      kink = Math.max(kink, t.kink);
      let run = -Infinity;
      for (let d = 0; d <= e.half; d += inch(0.125)) {
        const v = t.T(d);
        thin = Math.max(thin, e.tip - v); run = Math.max(run, v); hump = Math.max(hump, run - v);
        pk = Math.max(pk, -(e.gap + e.P(d) - v)); fl = Math.max(fl, inch(0.25) - v);
      }
    }
    if (hump > tol) humpBoards++; if (thin > tol) thinBoards++; if (kink > 0.002) kinkBoards++; if (pk > tol) poke++; if (fl > tol) floor++;
    worstHump = Math.max(worstHump, hump / IN);
  }
  const s = [...starts].sort((a, b) => a - b);
  console.log(`  ${label.padEnd(34)} thin-spot ${String(thinBoards).padStart(4)}  hump ${String(humpBoards).padStart(4)} (max ${worstHump.toFixed(3)})  slope-break at the start ${String(kinkBoards).padStart(4)}  pokes ${String(poke).padStart(3)}  under-floor ${String(floor).padStart(3)}   start: median ${s[s.length >> 1].toFixed(1)}", 90% ${s[Math.floor(s.length * 0.9)].toFixed(1)}", max ${s[s.length - 1].toFixed(1)}"`);
}
console.log("Steady taper (planer cut inside the start; one parabola from the start to the tip):");
for (const w of [6, 9, 12, 18, 24, 36]) score(`fixed start ${w}"`, () => inch(w));
score("start at the centre", (e) => e.half);
score('automatic, never under 6"', (e) => autoStart(e.P, e.tip, e.half, inch(6)));
score('automatic, never under 12"', (e) => autoStart(e.P, e.tip, e.half, inch(12)));
// distribution of the automatic start
const auto = boards.flatMap((b) => ends(b).map((e) => ({ v: b.vendor, w: autoStart(e.P, e.tip, e.half, inch(12)) / IN, half: e.half / IN })));
const bins = [12.01, 18, 24, 36, 1e9];
const lab = ['12" (no change needed)', '12-18"', '18-24"', '24-36"', 'over 36" / centre'];
const cnt = bins.map(() => 0);
for (const a of auto) cnt[bins.findIndex((x) => a.w <= x)]++;
console.log("automatic start (never under 12\") lands at:", lab.map((l, i) => `${l}: ${cnt[i]}`).join("  |  "), `of ${auto.length} tips;  reaches the centre on ${auto.filter((a) => a.w >= a.half - 0.01).length}`);

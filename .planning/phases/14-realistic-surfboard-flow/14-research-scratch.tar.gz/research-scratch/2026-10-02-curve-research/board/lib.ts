// Scratch analysis only — runs the app's own geometry on alternative blank curves. Nothing here is app code.
import { readSeedCatalog } from "/Users/kontoes/Code/shaper/lib/blanks/seed-files";
import { isPickable } from "/Users/kontoes/Code/shaper/lib/blanks/catalog";
import type { BlankRecord, BlankStation } from "/Users/kontoes/Code/shaper/lib/geometry/blank";
import { levelCurve, prepareBlank, floorCheck, type PreparedBlank } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { preparePchip, type PreparedPchip } from "/Users/kontoes/Code/shaper/lib/geometry/pchip";
import { inchesToMm, mm, type Mm } from "/Users/kontoes/Code/shaper/lib/geometry/units";

export const IN = 25.4;
export const inch = (v: number) => inchesToMm(v);

/** The square-root rule: pchip through sign*sqrt(|y - anchor|), squared back. `rise` anchors on the
 * lowest station (rocker); `fall` anchors on the thickest station (thickness). */
export function prepareRoot(points: { x: number; y: number }[], kind: "rise" | "fall"): PreparedPchip {
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const anchor = kind === "rise" ? Math.min(...ys) : Math.max(...ys);
  const first = ys.indexOf(anchor);
  const g = preparePchip(points.map((p, i) => ({ x: p.x, y: (i < first ? -1 : 1) * Math.sqrt(Math.abs(p.y - anchor)) })));
  const sample = (x: number) => (kind === "rise" ? anchor + g.sample(x) ** 2 : anchor - g.sample(x) ** 2);
  return { xs, ys, slopes: [], sample };
}

function knots(stations: readonly BlankStation[], pick: (s: BlankStation) => Mm | null) {
  const out: { x: number; y: number }[] = [];
  for (const s of stations) { const v = pick(s); if (v !== null) out.push({ x: s.fromTailMm, y: v }); }
  return out;
}

/** A blank prepared with the square-root rule for rocker (and, optionally, thickness). */
export function prepareNew(record: BlankRecord, opts: { thickness: boolean }): PreparedBlank {
  const base = prepareBlank(record);
  const rocker = prepareRoot(knots(base.record.stations, (s) => s.rockerMm), "rise");
  return {
    ...base,
    rocker: levelCurve(rocker, 0, base.lengthMm),
    thickness: opts.thickness ? prepareRoot(knots(base.record.stations, (s) => s.thicknessMm), "fall") : base.thickness,
  };
}

export const catalog = readSeedCatalog().filter(isPickable);
export { prepareBlank, floorCheck, levelCurve, preparePchip, mm };
export type { PreparedBlank, BlankRecord, Mm };

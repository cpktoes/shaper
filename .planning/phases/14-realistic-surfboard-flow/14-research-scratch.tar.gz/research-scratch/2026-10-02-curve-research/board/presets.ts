import { prepareBlank, prepareNew, prepareRoot, levelCurve, preparePchip, inch, IN, mm } from "./lib";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { buildBoardProfile, buildFallbackProfile } from "/Users/kontoes/Code/shaper/lib/geometry/board-profile";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { deriveEffectiveRails } from "/Users/kontoes/Code/shaper/lib/geometry/design";
import { computeCrossSectionVolume, DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/lib/geometry/volume";
import { DEFAULT_FALLBACK_ROCKER, fallbackRockerPoints } from "/Users/kontoes/Code/shaper/lib/geometry/rocker";
import { DEFAULT_FOIL_SPEC, foilStationPoints } from "/Users/kontoes/Code/shaper/lib/geometry/foil";

const f3 = (v: number) => (v / IN).toFixed(3);
console.log("THE FOUR PRESETS — each on its own US Blanks blank, today's tip rule kept. Five station numbers (in) and litres, today -> new curves");
for (const preset of BOARD_PRESETS) {
  const fields = presetDesignFields(preset);
  const outline = buildOutline(fields.outline);
  const L = fields.outline.length;
  const run = (prepared: ReturnType<typeof prepareBlank>) => {
    const b = fields.blank;
    const profile = buildBoardProfile({ length: L, rocker: fields.rocker, foil: fields.foil, blank: { prepared, placement: b.placement, nose12Offset: b.nose12Offset, tail12Offset: b.tail12Offset, deckSkin: b.deckSkin, tipStyle: b.tipStyle, fineTuneSurface: b.fineTuneSurface } });
    const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, true);
    const vol = computeCrossSectionVolume({ halfWidthAt: (s) => sampleOutline(outline, s), foil: profile.effectiveFoil, thicknessAt: profile.thicknessAt, rails, length: L });
    return { profile, litres: vol.volumeLitres };
  };
  const a = run(prepareBlank(fields.blank.copy)), b = run(prepareNew(fields.blank.copy, { thickness: true }));
  let mr = 0, mt = 0;
  for (let i = 0; i <= 400; i++) { const s = mm((L * i) / 400); mr = Math.max(mr, Math.abs(a.profile.rockerAt(s) - b.profile.rockerAt(s))); mt = Math.max(mt, Math.abs(a.profile.thicknessAt(s) - b.profile.thicknessAt(s))); }
  const keys = ["tailTip", "tail12", "center", "nose12", "noseTip"] as const;
  console.log(`\n ${preset.name} on ${fields.blank.copy.vendor} ${fields.blank.copy.name} (${fields.blank.copy.stations.filter((s) => s.rockerMm !== null).length} stations), board ${(L / IN / 12).toFixed(2)} ft`);
  console.log("   rocker    " + keys.map((k) => `${k} ${f3(a.profile.stationRocker[k])}->${f3(b.profile.stationRocker[k])}`).join("   "));
  console.log("   thickness " + keys.map((k) => `${k} ${f3(a.profile.effectiveFoil[k])}->${f3(b.profile.effectiveFoil[k])}`).join("   "));
  console.log(`   between stations: bottom moves up to ${f3(mr)} in, thickness up to ${f3(mt)} in;   litres ${a.litres.toFixed(3)} -> ${b.litres.toFixed(3)}  (${(b.litres - a.litres >= 0 ? "+" : "") + (b.litres - a.litres).toFixed(3)} L)`);
}

// The hand-set board (no blank): five typed stations for rocker and for thickness
console.log("\nTHE HAND-SET BOARD (no blank): default numbers on a 6'0\" board — pchip today vs the square-root rules through the same five numbers");
const L = inch(72);
const rk = fallbackRockerPoints(DEFAULT_FALLBACK_ROCKER, L);
const fo = foilStationPoints(DEFAULT_FOIL_SPEC, L).map((p) => ({ x: p.station, y: p.thickness }));
const rA = preparePchip(rk), rB = prepareRoot(rk, "rise"), tA = preparePchip(fo), tB = prepareRoot(fo, "fall");
let wr = { d: 0, s: 0 }, wt = { d: 0, s: 0 };
for (let i = 0; i <= 720; i++) { const s = (L * i) / 720; const d1 = rB.sample(s) - rA.sample(s), d2 = tB.sample(s) - tA.sample(s); if (Math.abs(d1) > Math.abs(wr.d)) wr = { d: d1, s }; if (Math.abs(d2) > Math.abs(wt.d)) wt = { d: d2, s }; }
console.log(`   bottom moves up to ${f3(wr.d)} in at ${(wr.s / IN).toFixed(0)} in from the tail; thickness up to ${f3(wt.d)} in at ${(wt.s / IN).toFixed(0)} in from the tail`);
for (const s of [6, 18, 24, 30, 42, 48, 54, 66]) console.log(`     ${String(s).padStart(2)} in from tail: bottom ${f3(rA.sample(inch(s)))} -> ${f3(rB.sample(inch(s)))}   thickness ${f3(tA.sample(inch(s)))} -> ${f3(tB.sample(inch(s)))}`);

/*
 * REFERENCE COPY — never edited.
 *
 * This is the maths behind sketch 021 (.planning/sketches/021-bottom-guide/), the founder's approved bottom
 * contours on 2026-11-08 ("Love everything about it"), copied byte for byte from the sketch's archive
 * (.planning/sketches/021-bottom-guide/sketch-source.tar.gz → template.html, SHA-1
 * 53cbf011a3144c40185da1e10e651751133375bf) on 2026-11-08: its lines 326–553 (the units, the eighteen cut names
 * and their starting numbers, the channels, the state, the board's numbers along its length, the foam taken off,
 * the litres off and the layout marks) and 1013–1018 (`normalize`, how a dragged Start, Deepest or End keeps the
 * other two in order), in that order. It is the source of truth for the bottom contours (Phase 17, CLAUDE.md
 * Rule 1: the expected numbers come from the founder's chosen sketch's own code, never a transcription).
 *
 * It works in MILLIMETRES: stations from the tail, distances from the stringer, depths. Its `IN = 25.4` is the
 * sketch's own and stays here — the app takes inches through lib/geometry/units.ts and never imports this file.
 *
 * It is run only by scripts/extract-sketch021-bottom-golden.mjs, which writes
 * lib/geometry/__fixtures__/bottom-golden.json. The app never imports it.
 *
 * Do not edit anything between the marked lines below. The golden is only as good as this copy is faithful, and
 * the copy is only faithful while each block is template.html's lines unchanged.
 */

// ---- NOT from the sketch: the one global the copied lines read (the sketch's DATA, line 323). ----
let DATA = { U: [], boards: [] };

// ---- BEGIN template.html lines 326–553 (byte for byte) ----

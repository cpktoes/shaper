"""Assemble reference/sketches/021-bottom-maths.js from template.html's own lines, and prove the two blocks byte for
byte. Usage: python3 -I assemble.py <q dir> <template.html> <output>"""
import hashlib
import sys

q, template, out = sys.argv[1], sys.argv[2], sys.argv[3]
raw = open(template, "rb").read()
assert hashlib.sha1(raw).hexdigest() == "53cbf011a3144c40185da1e10e651751133375bf", "template SHA-1 differs"
lines = raw.split(b"\n")
block1 = b"\n".join(lines[325:553]) + b"\n"  # lines 326..553
block2 = b"\n".join(lines[1012:1018]) + b"\n"  # lines 1013..1018
read = lambda n: open(f"{q}/{n}", "rb").read()
data = read("head.js") + block1 + read("mid.js") + block2 + read("tail.js")
open(out, "wb").write(data)

# the proof: find each block between its markers in the written file and compare bytes
written = open(out, "rb").read()
b1 = written.split(b"// ---- BEGIN template.html lines 326\xe2\x80\x93553 (byte for byte) ----\n")[1].split(b"// ---- END template.html lines 326\xe2\x80\x93553 ----")[0]
b2 = written.split(b"// ---- BEGIN template.html lines 1013\xe2\x80\x931018 (byte for byte) ----\n")[1].split(b"// ---- END template.html lines 1013\xe2\x80\x931018 ----")[0]
print("block 326-553 identical:", b1 == block1, len(block1), "bytes;", "block 1013-1018 identical:", b2 == block2, len(block2), "bytes")

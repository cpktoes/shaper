/* Plan 17-01's picture: reads lib/geometry/__fixtures__/bottom-golden.json (the sketch's own maths run on the app's
   boards), runs the same reference copy on the sketch's own shipped board data (boards.json from the archive) for the
   figures the sketch itself showed, and writes a captioned HTML page. Nothing is typed: every figure is read.
   Usage (from the worktree root):
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> <sketch boards.json> <out.html> */
import { createRequire } from "node:module";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, sketchBoards, out] = process.argv.slice(2);
const units = await import(path.join(root, "lib/geometry/units.ts"));
const outlineMod = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { designFinPlacement } = await import(path.join(root, "lib/geometry/design.ts"));
const { frontFinStation } = await import(path.join(root, "lib/geometry/fins.ts"));
const { formatInchesFraction, inchesToMm, mm, mmToInches } = units;

type Golden = {
  provenance: Record<string, unknown>;
  boards: { id: string; facts: { L: number; fin: number; toeDeg: number; litres: number } }[];
  cases: Record<string, any>[];
};
const golden: Golden = JSON.parse(readFileSync(path.join(root, "lib/geometry/__fixtures__/bottom-golden.json"), "utf8"));

// the sketch's own figures: the same byte-for-byte maths on the board data the sketch shipped with
const require = createRequire(import.meta.url);
const sketch = require(path.join(root, "reference/sketches/021-bottom-maths.js"));
const shipped = JSON.parse(readFileSync(sketchBoards, "utf8"));
sketch.setData(shipped);
const sketchFig: Record<string, { litres: number; fin: number; toe: number }> = {};
for (const b of shipped.boards) {
  sketch.use(b.id, "imperial", "narrow");
  sketchFig[b.id] = { litres: sketch.litresOff(), fin: b.fin, toe: b.toeDeg };
}

const NAME: Record<string, string> = { shortboard: "Shortboard", fish: "Fish", midlength: "Mid-length", longboard: "Longboard", fishwing: "Fish, winged" };
const frac = (v: number) => formatInchesFraction(mm(v));
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");

const rows = golden.boards.map((b) => {
  const open = golden.cases.find((c) => c.kind === "opening" && c.board === b.id && c.channels === 0)!;
  const six = golden.cases.find((c) => c.kind === "opening" && c.board === b.id && c.channels === 6)!;
  const sk = sketchFig[b.id];
  const cuts = Object.values(open.cuts as Record<string, { name: string }>).map((c) => c.name).join(" · ");
  const moved = open.litresOff.toFixed(2) !== sk.litres.toFixed(2);
  return `<tr${moved ? ' class="moved"' : ""}>
    <td class="b">${NAME[b.id]}</td><td class="cuts">${esc(cuts)}</td>
    <td>${esc(frac(b.facts.fin))}<div class="sub">sketch ${esc(frac(sk.fin))}</div></td>
    <td>${b.facts.toeDeg > 0 ? b.facts.toeDeg.toFixed(1) + "°" : "none"}<div class="sub">${b.facts.toeDeg > 0 ? "sketch " + sk.toe.toFixed(1) + "°" : "single fin"}</div></td>
    <td class="n">${sk.litres.toFixed(2)} L<div class="sub">${sk.litres.toFixed(4)}</div></td>
    <td class="n big">${open.litresOff.toFixed(2)} L<div class="sub">${open.litresOff.toFixed(4)}</div></td>
    <td class="n">+${(six.litresOff - open.litresOff).toFixed(2)} L</td>
    <td class="n">${b.facts.litres.toFixed(2)} L</td></tr>`;
}).join("\n");

// the winged Fish: the real rail, the curve drawn before the wing and the Narrowest outline, every 2" (golden refAt +
// the app's own rail at the same stations)
const fishFields = phase16Boards().find((b: { label: string }) => b.label.startsWith("fish|asis|"))!.fields;
const wingStation = frontFinStation(designFinPlacement(fishFields)) + inchesToMm(4);
const wing = { station: mm(wingStation), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
const g = outlineMod.buildOutline({ ...fishFields.outline, wings: [wing] });
const ref = (rule: string) => golden.cases.filter((c) => c.kind === "refAt" && c.wingRule === rule);
const narrow = ref("narrow");
const natural = ref("natural");
const wingRows: string[] = [];
for (let k = 0; k < narrow.length; k++) {
  const s = narrow[k].s as number;
  const inches = mmToInches(mm(s));
  if (Math.abs(inches / 2 - Math.round(inches / 2)) > 0.01 || inches > 24.001) continue;
  const rail = outlineMod.sampleOutline(g, mm(s));
  const n = narrow[k].ref as number;
  const nat = natural[k].ref as number;
  const where = s < wingStation - inchesToMm(1) ? "behind the wing" : s <= wingStation ? "the wing's step" : "ahead of the wing";
  wingRows.push(`<tr><td>${esc(frac(s))}</td><td>${where}</td><td>${esc(frac(rail * 2))}</td><td>${esc(frac(nat * 2))}</td><td>${esc(frac(n * 2))}</td>
    <td class="n">${(mmToInches(mm(n - rail))).toFixed(3)}"</td><td class="n">${(mmToInches(mm(nat - rail))).toFixed(3)}"</td></tr>`);
}

// a small drawing: the tail 24" of the winged Fish, one side, rail / natural / narrowest
const W = 760, H = 230, maxS = inchesToMm(24);
let maxY = 0;
for (const c of natural) if ((c.s as number) <= maxS) maxY = Math.max(maxY, c.ref as number);
const X = (s: number) => 40 + (s / maxS) * (W - 60);
const Y = (y: number) => H - 30 - (y / (maxY * 1.05)) * (H - 50);
const line = (pts: [number, number][]) => pts.map(([s, y], i) => `${i ? "L" : "M"}${X(s).toFixed(1)},${Y(y).toFixed(1)}`).join(" ");
const railPts: [number, number][] = [];
for (let i = 0; i <= 480; i++) { const s = (i / 480) * maxS; railPts.push([s, outlineMod.sampleOutline(g, mm(s))]); }
const natPts = natural.filter((c) => (c.s as number) <= maxS).map((c) => [c.s, c.ref] as [number, number]);
const narPts = narrow.filter((c) => (c.s as number) <= maxS).map((c) => [c.s, c.ref] as [number, number]);
const ticks = Array.from({ length: 7 }, (_, i) => i * 4).map((t) => `<text x="${X(inchesToMm(t))}" y="${H - 12}" text-anchor="middle">${t}"</text><line x1="${X(inchesToMm(t))}" x2="${X(inchesToMm(t))}" y1="${H - 30}" y2="${H - 25}" stroke="#888"/>`).join("");
const svg = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <line x1="40" x2="${W - 20}" y1="${H - 30}" y2="${H - 30}" stroke="#888"/>${ticks}
  <text x="${W - 20}" y="${H - 36}" text-anchor="end" class="ax">inches from the tail</text>
  <path d="${line(natPts)}" fill="none" stroke="#9aa3ad" stroke-width="2" stroke-dasharray="6 4"/>
  <path d="${line(railPts)}" fill="none" stroke="#1d2a36" stroke-width="2.4"/>
  <path d="${line(narPts)}" fill="none" stroke="#d2691e" stroke-width="2"/>
  <line x1="${X(wingStation)}" x2="${X(wingStation)}" y1="20" y2="${H - 30}" stroke="#d2691e" stroke-dasharray="2 3"/>
  <text x="${X(wingStation) + 4}" y="30" class="ax">wing at ${esc(frac(wingStation))}</text>
</svg>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a36; margin: 0; padding: 28px 32px; width: 1100px; background: #fff; }
  h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 16px; margin: 26px 0 6px; }
  p { margin: 4px 0 10px; max-width: 1040px; } .lede { color: #4a5763; }
  table { border-collapse: collapse; width: 100%; } th, td { border-bottom: 1px solid #dde2e7; padding: 6px 8px; text-align: left; vertical-align: top; }
  th { font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; font-weight: 600; }
  td.n { text-align: right; font-variant-numeric: tabular-nums; } td.b { font-weight: 600; } td.cuts { font-size: 13px; }
  td.big { font-weight: 700; } .sub { font-size: 11px; color: #7a8590; font-weight: 400; }
  tr.moved td { background: #fff6ea; } .key span { display: inline-block; margin-right: 18px; } .sw { display: inline-block; width: 22px; height: 0; vertical-align: middle; margin-right: 6px; }
  .ax { font-size: 11px; fill: #5b6772; } svg text { font-size: 11px; fill: #5b6772; }
  .foot { font-size: 11px; color: #7a8590; margin-top: 18px; }
</style></head><body>
<h1>Sketch 021's bottom maths, run unchanged on the app's own boards</h1>
<p class="lede">Nothing on any screen has changed. This is the arithmetic every later step of the bottom is checked against:
the sketch's own code, copied byte for byte, fed the app's real boards at 4,801 stations instead of the sketch's 241.</p>
<h2>1 · Foam the opening cuts take off, and where the front fins sit</h2>
<table><thead><tr><th>Board</th><th>Opening cuts</th><th>Front fins</th><th>Toe-in</th><th class="n">Foam off — what the sketch showed</th><th class="n">Foam off — on the app's boards</th><th class="n">Six channels add</th><th class="n">Litres today</th></tr></thead>
<tbody>${rows}</tbody></table>
<p>The Mid-length (shaded) is the one that moves: the app puts its front fins at 12" — Import Template ticked, as a board opens — where the
sketch read them with Import Template off, at 10 7/8". Its cuts are set from the fins, so they reach further up the board.
The Shortboard's fins move the same way, but its opening cuts barely notice. The Fish's toe now reads 2.0°: the sketch rounded the angle
to 1.95° first and then to one place, which gave 1.9°; the app rounds once.</p>
<h2>2 · The winged Fish: what Off Rail is measured from (the Narrowest outline, the default)</h2>
<div class="key"><span><i class="sw" style="border-top:2.4px solid #1d2a36"></i>the real rail, wing and all</span><span><i class="sw" style="border-top:2px dashed #9aa3ad"></i>the curve you drew before the wing (Natural)</span><span><i class="sw" style="border-top:2px solid #d2691e"></i>the Narrowest outline</span></div>
${svg}
<table><thead><tr><th>From the tail</th><th></th><th>Real rail (full width)</th><th>Natural outline</th><th>Narrowest outline</th><th class="n">Narrowest − rail (one side)</th><th class="n">Natural − rail (one side)</th></tr></thead>
<tbody>${wingRows.join("\n")}</tbody></table>
<p>Behind the wing the Narrowest outline sits exactly on the real rail (0.000"); ahead of it, it sits the wing's 1/4" inside the curve
you drew, so a cut measured from it never runs out through the step. The Natural outline stands outside the real rail behind the wing.</p>
<p class="foot">From lib/geometry/__fixtures__/bottom-golden.json (${esc(String(golden.provenance.producer))}; sketch ${esc(String(golden.provenance.sketchSha1))}).
"What the sketch showed" is the same reference copy run on the board data the sketch shipped with. Widths are full board widths; differences are one side.</p>
</body></html>`;
writeFileSync(out, html);
console.log("wrote", out, "rows", golden.boards.length, "wing rows", wingRows.length);

// ---- END template.html lines 1013–1018 ----

// ---- NOT from the sketch: how the golden script reaches the copied functions. ----
module.exports = {
  setData(d) {
    DATA = d;
  },
  use(id, units, wingRule) {
    setBoard(id);
    state.units = units || "imperial";
    state.wingRule = wingRule || "narrow";
  },
  get state() {
    return state;
  },
  get B() {
    return B;
  },
  makeCut,
  makeChannels,
  NAMES,
  STARTS,
  foamOff,
  cutOff,
  litresOff,
  fadeAt,
  cutHalfWidth,
  doubleMarks,
  channelFit,
  channelEdges,
  channelMarks,
  chStart,
  marksOf,
  markColumns,
  normalize,
  refAt,
  curveAt,
  foamAt,
  thickAt,
  innerAt,
};

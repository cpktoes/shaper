/* Plan 17-02's picture: the app's own bottom maths (lib/geometry/bottom.ts) drawn as a line through four cross-sections,
   with the sketch's own executed figures (lib/geometry/__fixtures__/bottom-golden.json) as dots over it; and a table of
   every name's starting Start · Deepest · End on the five boards, read from the app. Nothing is typed: every figure is
   read or computed by the app's functions.
   Usage (from the worktree root):
     npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree> <out.html> */
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const [root, out] = process.argv.slice(2);
const units = await import(path.join(root, "lib/geometry/units.ts"));
const bottomMod = await import(path.join(root, "lib/geometry/bottom.ts"));
const design = await import(path.join(root, "lib/geometry/design.ts"));
const { buildOutline } = await import(path.join(root, "lib/geometry/outline.ts"));
const { phase16Boards } = await import(path.join(root, "lib/geometry/__fixtures__/phase16-boards.ts"));
const { BOARD_PRESETS } = await import(path.join(root, "lib/geometry/presets.ts"));
const { frontFinStation } = await import(path.join(root, "lib/geometry/fins.ts"));
const { formatInchesFraction, inchesToMm, mm } = units;
const { BOTTOM_CUT_NAMES, BOTTOM_SECTIONS, DEFAULT_BOTTOM, cutKind, foamOff, cutFoamOff, resolveBottom, resolveCut, startingCut } = bottomMod;

const golden = JSON.parse(readFileSync(path.join(root, "lib/geometry/__fixtures__/bottom-golden.json"), "utf8"));

/* the five boards, built as the golden's script builds them */
const all = phase16Boards();
const jobs: { id: string; fields: any }[] = BOARD_PRESETS.map((preset: any) => {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  return { id: preset.id, fields: all.find((b: any) => b.label === label).fields };
});
const fishF = jobs.find((j) => j.id === "fish")!.fields;
const wing = { station: mm(frontFinStation(design.designFinPlacement(fishF)) + inchesToMm(4)), depth: inchesToMm(1 / 4), run: inchesToMm(1), radius: mm(0), lock: null, finOffset: mm(0) };
jobs.push({ id: "fishwing", fields: { ...fishF, outline: { ...fishF.outline, wings: [wing] } } });
const boardOf = (fields: any) => design.designBottomBoard(fields.outline, buildOutline(fields.outline), design.designSideProfile(fields, design.LIVE_DESIGN_RULES), design.designFinPlacement(fields));
const BOARDS: Record<string, any> = Object.fromEntries(jobs.map((j) => [j.id, boardOf(j.fields)]));
const NAME: Record<string, string> = { shortboard: "Shortboard", fish: "Fish", midlength: "Mid-length", longboard: "Longboard", fishwing: "Fish, winged" };
const frac = (v: number) => formatInchesFraction(mm(v));
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");

const thisWave = (name: string) => BOTTOM_SECTIONS.some((s: string) => BOTTOM_CUT_NAMES[s].includes(name));
const cutCases = golden.cases.filter((c: any) => c.kind === "cut" && thisWave(c.name));
const onlyCut = (board: any, section: string, name: string) => {
  const b = structuredClone(DEFAULT_BOTTOM);
  b[section] = startingCut(section, name, board);
  return resolveBottom(b, board);
};

/* the agreement over every probe of every name of this wave, alone */
let worstCut = 0, worstFoam = 0, probes = 0;
for (const c of cutCases) {
  const board = BOARDS[c.board];
  const grid = golden.boards.find((b: any) => b.id === c.board).facts.grid;
  const r = onlyCut(board, c.section, c.name);
  grid.s.forEach((s: number, k: number) => grid.y[k].forEach((y: number, j: number) => {
    probes++;
    worstCut = Math.max(worstCut, Math.abs(cutFoamOff(r[c.section], board, "narrowest", mm(s), mm(y)) - c.cutOff[k][j]));
    worstFoam = Math.max(worstFoam, Math.abs(foamOff(r, board, mm(s), mm(y)) - c.foamOff[k][j]));
  }));
}

/* the four cross-sections */
const PANELS = [
  { board: "shortboard", section: "center", name: "Deep Single Concave" },
  { board: "fish", section: "tail", name: "Panel Vee" },
  { board: "longboard", section: "center", name: "Continuous Belly / Rolled Mid" },
  { board: "midlength", section: "center", name: "Shallow Single Concave" },
];
const EXAG = 4;
function panel(p: (typeof PANELS)[number]) {
  const board = BOARDS[p.board];
  const facts = golden.boards.find((b: any) => b.id === p.board).facts;
  const c = cutCases.find((x: any) => x.board === p.board && x.name === p.name);
  const r = onlyCut(board, p.section, p.name);
  const deepest = r[p.section].deepest;
  // the golden's stations are every 1/24 of the board: draw at the one nearest Deepest At
  let k = 0;
  facts.grid.s.forEach((s: number, i: number) => { if (Math.abs(s - deepest) < Math.abs(facts.grid.s[k] - deepest)) k = i; });
  const s = facts.grid.s[k];
  const ys: number[] = facts.grid.y[k];
  const W = ys[ys.length - 1];
  const PW = 520, PH = 168, padX = 24, base = 122;
  const sx = (PW - 2 * padX) / (2 * W);
  const X = (y: number) => PW / 2 + y * sx;
  const scaleY = sx * EXAG; // Height ×4 against the across scale
  const Y = (off: number) => base - off * scaleY; // foam off the bottom rises into the board
  const N = 240;
  const pts: string[] = [];
  for (let i = 0; i <= N; i++) {
    const y = -W + (2 * W * i) / N;
    pts.push(`${X(y).toFixed(2)},${Y(foamOff(r, board, mm(s), mm(Math.abs(y)))).toFixed(2)}`);
  }
  const shade = `M${X(-W)},${base} L${pts.join(" L")} L${X(W)},${base} Z`;
  const dots = ys.flatMap((y: number, j: number) => [y, -y].map((yy) => `<circle cx="${X(yy).toFixed(2)}" cy="${Y(c.foamOff[k][j]).toFixed(2)}" r="3.6" fill="none" stroke="#c0392b" stroke-width="1.6"/>`)).join("");
  const worst = Math.max(...ys.map((y: number, j: number) => Math.abs(foamOff(r, board, mm(s), mm(y)) - c.foamOff[k][j])));
  const deepAtStringer = foamOff(r, board, mm(s), mm(0));
  const atRail = foamOff(r, board, mm(s), mm(W));
  const sectionWord = p.section === "center" ? "Center" : p.section === "tail" ? "Tail" : "Nose";
  return `<div class="panel">
  <div class="ph"><b>${NAME[p.board]}</b> · ${esc(sectionWord)}: ${esc(p.name)}</div>
  <div class="sub">at ${esc(frac(s))} from the tail (the sketch's station nearest Deepest At, ${esc(frac(deepest))}) · the rail ${esc(frac(W))} out each side</div>
  <svg width="${PW}" height="${PH}" viewBox="0 0 ${PW} ${PH}">
    <rect x="${X(-W)}" y="${base - 90}" width="${2 * W * sx}" height="90" fill="#eef1f4"/>
    <text x="${PW / 2}" y="${base - 76}" text-anchor="middle">the planed board, deck up, looking from the tail</text>
    <path d="${shade}" fill="#f5d9b8" stroke="none"/>
    <line x1="${X(-W) - 8}" x2="${X(W) + 8}" y1="${base}" y2="${base}" stroke="#5b6772" stroke-width="1.2" stroke-dasharray="5 4"/>
    <polyline points="${pts.join(" ")}" fill="none" stroke="#1d2a36" stroke-width="2.2"/>
    ${dots}
    <line x1="${PW / 2}" x2="${PW / 2}" y1="${base - 66}" y2="${PH - 26}" stroke="#9aa3ad" stroke-width="1" stroke-dasharray="2 3"/>
    <text x="${PW / 2}" y="${PH - 12}" text-anchor="middle">stringer</text>
    <text x="${X(-W)}" y="${PH - 12}" text-anchor="start">rail</text><text x="${X(W)}" y="${PH - 12}" text-anchor="end">rail</text>
  </svg>
  <div class="sub">foam off: ${esc(frac(deepAtStringer))} at the stringer, ${esc(frac(atRail))} at the rail · the app against the sketch's 13 dots: largest gap ${worst.toExponential(1)} mm</div>
</div>`;
}

/* the starting numbers of every name on the five boards */
const ids = ["shortboard", "fish", "midlength", "longboard", "fishwing"];
let inOrder = 0, total = 0;
const tableRows = BOTTOM_SECTIONS.flatMap((section: string) => BOTTOM_CUT_NAMES[section].filter((n: string) => cutKind(n) !== "flat").map((name: string) => {
  const cells = ids.map((id) => {
    const board = BOARDS[id];
    const r = resolveCut(section, startingCut(section, name, board), board);
    total++;
    const ok = r.start >= r.deepest && r.deepest >= r.end;
    if (ok) inOrder++;
    const tip = (v: number) => (section === "nose" ? board.length - v : v);
    return `<td class="n${ok ? "" : " bad"}">${esc(frac(tip(r.start)))} · ${esc(frac(tip(r.deepest)))} · ${esc(frac(tip(r.end)))}</td>`;
  }).join("");
  const from = section === "nose" ? "from the nose" : "from the tail";
  return `<tr><td class="b">${esc(name)}<div class="sub">${section[0].toUpperCase() + section.slice(1)} · ${esc(cutKind(name))} · ${from}</div></td>${cells}</tr>`;
})).join("\n");

/* the three yes-or-no questions, worked on the Shortboard by the app */
const sbF = jobs.find((j) => j.id === "shortboard")!.fields;
const sb = BOARDS.shortboard;
const longer = boardOf({ ...sbF, outline: { ...sbF.outline, length: mm(sbF.outline.length + inchesToMm(6)) } });
const blended = startingCut("nose", "Blended Nose Concave", sb);
const b1 = resolveCut("nose", blended, sb), b2 = resolveCut("nose", blended, longer);
const panelVee = startingCut("tail", "Panel Vee", sb);
const fins2 = { ...sb, frontFins: mm(sb.frontFins + inchesToMm(2)) };
const v1 = resolveCut("tail", panelVee, sb), v2 = resolveCut("tail", panelVee, fins2);
const ext = startingCut("tail", "Extending Single Concave", sb);
const fins14 = { ...sb, frontFins: mm(sb.frontFins + inchesToMm(14)) };
const e1 = resolveCut("tail", ext, sb), e2 = resolveCut("tail", ext, fins14);
const q = `
<ol class="qs">
<li><b>D-39 — a nose cut is kept from the nose.</b> The Shortboard's Blended Nose Concave starts ${esc(frac(sb.length - b1.start))} from the nose and is deepest ${esc(frac(sb.length - b1.deepest))} from it. Make the board 6" longer on TEMPLATE and it still starts ${esc(frac(longer.length - b2.start))} from the nose — ${esc(frac(b1.start))} from the tail before, ${esc(frac(b2.start))} after.</li>
<li><b>D-03 — a tail cut's deepest point is kept from the front fins.</b> The Shortboard's Panel Vee is deepest at its front fins, ${esc(frac(v1.deepest))} from the tail. Move the fins up 2" on FINS and it is deepest at ${esc(frac(v2.deepest))}; its Start stays at ${esc(frac(v2.start))}. (The channels' Start and Deepest At will ride with the fins the same way, from 17-05.)</li>
<li><b>D-36 — fins that carry it past the cut's own Start.</b> The Extending Single Concave starts ${esc(frac(e1.start))} from the tail, 12" ahead of the fins. Move the fins up 14" and its Deepest At reads ${esc(frac(e2.deepest))}, so its Start reads ${esc(frac(e2.start))} as well, on the screen. The saved board still says ${esc(frac(ext.start))} until you next move a slider.</li>
</ol>`;

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a36; margin: 0; padding: 28px 32px; width: 1100px; background: #fff; }
  h1 { font-size: 22px; margin: 0 0 4px; } h2 { font-size: 16px; margin: 24px 0 6px; }
  p { margin: 4px 0 10px; max-width: 1060px; } .lede { color: #4a5763; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px 24px; }
  .panel { border: 1px solid #dde2e7; border-radius: 6px; padding: 10px 12px; } .ph { font-size: 14px; }
  table { border-collapse: collapse; width: 100%; } th, td { border-bottom: 1px solid #dde2e7; padding: 5px 7px; text-align: left; vertical-align: top; }
  th { font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: #5b6772; font-weight: 600; }
  td.n { font-variant-numeric: tabular-nums; font-size: 13px; white-space: nowrap; } td.b { font-weight: 600; font-size: 13px; } td.bad { background: #fde8e4; }
  .sub { font-size: 11px; color: #7a8590; font-weight: 400; }
  svg text { font-size: 11px; fill: #5b6772; }
  .key span { display: inline-block; margin-right: 18px; } .sw { display: inline-block; width: 22px; height: 0; vertical-align: middle; margin-right: 6px; }
  .dot { display: inline-block; width: 8px; height: 8px; border: 1.6px solid #c0392b; border-radius: 50%; vertical-align: middle; margin-right: 6px; }
  .qs li { margin-bottom: 6px; max-width: 1060px; } .foot { font-size: 11px; color: #7a8590; margin-top: 16px; }
</style></head><body>
<h1>The bottom's one number — a flat, a belly, a vee and a single concave, against the sketch</h1>
<p class="lede">The app's own bottom maths (the line) through the sketch you approved (the dots), at each cut's deepest station, the height drawn 4 times its true size against the width. Nothing on any screen changes yet: this is the arithmetic the BOTTOM page, the litres and the 3D board will read.</p>
<div class="key"><span><i class="sw" style="border-top:2.2px solid #1d2a36"></i>the app: foam off across the board</span><span><i class="dot"></i>the sketch's own figure</span><span><i class="sw" style="border-top:1.2px dashed #5b6772"></i>the straightedge on the planed bottom</span><span><i class="sw" style="border-top:8px solid #f5d9b8"></i>foam taken off</span></div>
<div class="grid">${PANELS.map(panel).join("\n")}</div>
<p style="margin-top:10px">Over every probe of all thirteen names on all five boards — ${probes.toLocaleString()} points, each cut alone — the app and the sketch differ by at most ${worstCut.toExponential(1)} mm for the cut itself and ${worstFoam.toExponential(1)} mm once the 1/4" floor is applied. (The Mid-length's Shallow Single is deepest at its front fins, which the app puts at 12", where the sketch's own board data had 10 7/8" — the dots here are the sketch run on the app's board.)</p>
<h2>Every starting cut: Start · Deepest At · End</h2>
<p>Nose cuts read from the nose, Center and Tail cuts from the tail — as each is kept. ${inOrder} of ${total} read Start ≥ Deepest At ≥ End along the board.</p>
<table><tr><th>Name</th>${ids.map((id) => `<th>${NAME[id]}<div class="sub">${esc(frac(BOARDS[id].length))} · fins ${esc(frac(BOARDS[id].frontFins))}</div></th>`).join("")}</tr>
${tableRows}
</table>
<h2>Three things to say yes or no to</h2>
${q}
<p class="foot">Drawn by gen-page.mts from lib/geometry/bottom.ts and lib/geometry/__fixtures__/bottom-golden.json (the sketch 021 maths, executed on the app's boards in 17-01); inches through lib/geometry/units.ts. Plan 17-02, 2026-11-08.</p>
</body></html>`;
writeFileSync(out, html);
console.log("wrote", out, { probes, worstCut, worstFoam, inOrder, total });

// Composes the four plan 17-17 pictures side by side with a caption over each.
const sharp = require("/Users/kontoes/Code/shaper/.claude/worktrees/agent-a4bcfdf53a2d8e2d8/node_modules/sharp");
const path = require("path");
(async () => {
  const [, , dir, out] = process.argv;
  const items = [
    ["w820.png", "VOLUME panel · 820-dot window"],
    ["w1280.png", "VOLUME panel · 1280-dot window"],
    ["phone.png", "VOLUME · 390-dot phone"],
    ["guide.png", "GUIDE card · 1280"],
  ];
  const pad = 24, cap = 44, gap = 24;
  const loaded = [];
  for (const [f, label] of items) {
    const buf = await sharp(path.join(dir, f)).png().toBuffer();
    const m = await sharp(buf).metadata();
    loaded.push({ buf, w: m.width, h: m.height, label });
  }
  const maxH = Math.max(...loaded.map((l) => l.h));
  const width = pad * 2 + loaded.reduce((s, l) => s + l.w, 0) + gap * (loaded.length - 1);
  const height = pad * 2 + cap + maxH;
  const layers = [];
  let x = pad;
  for (const l of loaded) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${l.w}" height="${cap}"><text x="0" y="28" font-family="Helvetica, Arial, sans-serif" font-size="15" font-weight="700" fill="#1f2d3a">${l.label.replace(/&/g, "&amp;")}</text></svg>`;
    layers.push({ input: Buffer.from(svg), left: x, top: pad });
    layers.push({ input: l.buf, left: x, top: pad + cap });
    x += l.w + gap;
  }
  await sharp({ create: { width, height, channels: 3, background: "#ffffff" } }).composite(layers).png().toFile(out);
  console.log(width, height);
})();

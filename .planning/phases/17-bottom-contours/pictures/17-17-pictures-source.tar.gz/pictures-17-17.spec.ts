import { expect, test } from "@playwright/test";
import { VOLUME_GUIDE_CARD_IDS } from "../lib/geometry/guide-volume";
import { VOLUME_GUIDE_WORDS } from "../components/guide/words/volume";
import { forgetOpenBoardOnEveryLoad } from "./helpers/open-board";
import { dismissStrips, guideCard, openGuide, openPreset } from "./helpers/guide";
import { importedReadout } from "./helpers/imported-readout";

// Scratch picture script for plan 17-17 (archived as pictures/17-17-pictures-source.tar.gz); never committed as a spec.
const OUT = process.env.PIC_OUT ?? "/tmp/pics";

test("pictures for the founder", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "desktop");
  test.setTimeout(400_000);
  await dismissStrips(page);
  await forgetOpenBoardOnEveryLoad(page);

  for (const [name, w, h] of [
    ["w820", 820, 800],
    ["w1280", 1280, 800],
  ] as const) {
    await page.setViewportSize({ width: w, height: h });
    await page.goto("/design/volume");
    const card = importedReadout(page.locator("aside"), "From TEMPLATE and ROCKER & FOIL");
    await expect(card).toBeVisible();
    await expect(card.locator("[data-readout-foot]")).toHaveText(
      "Counts the finished rail shape from RAILS and the bottom contours from BOTTOM.",
    );
    await page.locator("aside").screenshot({ path: `${OUT}/${name}.png` });
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/design/volume");
  const phoneCard = importedReadout(page, "From TEMPLATE and ROCKER & FOIL");
  await expect(phoneCard).toBeVisible();
  await phoneCard.scrollIntoViewIfNeeded();
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/phone.png` });

  await page.setViewportSize({ width: 1280, height: 800 });
  await openPreset(page, "shortboard", "VOLUME");
  await openGuide(page, VOLUME_GUIDE_WORDS.length);
  const guideCardLoc = guideCard(page, VOLUME_GUIDE_CARD_IDS.importDesignedBoard);
  await guideCardLoc.scrollIntoViewIfNeeded();
  await guideCardLoc.screenshot({ path: `${OUT}/guide.png` });
});

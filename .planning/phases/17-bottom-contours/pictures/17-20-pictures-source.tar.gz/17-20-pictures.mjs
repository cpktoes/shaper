/**
 * 17-19 / 17-20 picture script. Takes BOTTOM's section with "Show the finished rail from RAILS" ticked, Height x4,
 * the section 6" from the tail, on (a) the Longboard with six channels and (b) the Shortboard with its tail's
 * Hard Edge unticked on RAILS and six channels; then the 3D screen's Bottom view of the same two boards; then
 * composes one captioned PNG.
 *
 *   WT=<worktree root> PORT=3319 OUT=<out dir> LABEL=before node 17-19-pictures.mjs
 *
 * A dev server must already be answering on PORT (IS_WEBPACK_TEST=1 and the playwright.config non-secret env).
 * Re-run with LABEL=after for 17-20.
 */
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";

const WT = process.env.WT;
const PORT = process.env.PORT ?? "3319";
const OUT = process.env.OUT;
const LABEL = process.env.LABEL ?? "before";
const require = createRequire(path.join(WT, "package.json"));
const { chromium } = require("playwright");
const base = `http://localhost:${PORT}`;
fs.mkdirSync(OUT, { recursive: true });

async function openPreset(page, name) {
  await page.goto(`${base}/`, { timeout: 120000 });
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  for (let i = 0; i < 40 && !/\/design\/outline$/.test(page.url()); i++) {
    if ((await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2000 }).catch(() => {});
      await card.click({ timeout: 2000 }).catch(() => {});
    }
    await page.waitForTimeout(1500);
  }
  if (!/\/design\/outline$/.test(page.url())) throw new Error("never reached TEMPLATE");
}

async function go(page, href) {
  const label = { "/design/bottom": "BOTTOM", "/design/rails": "RAILS", "/design/3d": "3D" }[href];
  const link = page.locator("nav:not([aria-label])").getByRole("link", { name: label, exact: true }).first();
  await link.click({ timeout: 90000 });
  await page.waitForURL(`**${href}`, { timeout: 90000 });
}

async function pickChannels(page, option) {
  for (let i = 0; i < 20; i++) {
    try {
      await page.getByRole("combobox", { name: "Channels", exact: true }).click({ timeout: 2000 });
      await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2000 });
      const echo = await page.locator("[data-bottom-channels-echo]").textContent({ timeout: 2000 });
      if (echo && echo !== "None") return;
    } catch {}
    await page.waitForTimeout(800);
  }
  throw new Error("could not pick channels");
}

async function sectionAtMm(page, targetMm) {
  const slider = page.getByRole("slider", { name: "Section at", exact: true });
  const cutAt = async () => Number(await page.locator("[data-bottom-cut-at]").getAttribute("data-bottom-cut-at"));
  await slider.focus();
  let stuck = false;
  for (let i = 0; i < 1500; i++) {
    const now = await cutAt();
    if (Math.abs(now - targetMm) < 0.5) return now;
    const key = now > targetMm ? "ArrowRight" : "ArrowLeft"; // right is toward the tail
    const far = !stuck && Math.abs(now - targetMm) > 270; // a Shift step is 10" (254 mm)
    await slider.focus();
    await page.keyboard.press(far ? `Shift+${key}` : key);
    if (far && Math.abs((await cutAt()) - now) < 0.01) stuck = true; // a big step that goes nowhere: use small ones
  }
  return cutAt();
}

async function bottomShots(page, tag) {
  await go(page, "/design/bottom");
  await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 60000 });
  await pickChannels(page, "6 channels");
  await page.getByRole("button", { name: "Height ×4", exact: true }).click();
  const tick = page.getByRole("checkbox", { name: "Show the finished rail from RAILS" });
  if (!(await tick.isChecked())) await tick.click();
  const at = await sectionAtMm(page, 6 * 25.4);
  const sl = page.getByRole("slider", { name: "Section at", exact: true });
  console.log(tag, "slider", await sl.getAttribute("aria-valuemin"), await sl.getAttribute("aria-valuemax"), await sl.getAttribute("aria-valuenow"), await sl.getAttribute("aria-valuetext"));
  await page.waitForTimeout(800);
  await page.locator("[data-bottom-section]").screenshot({ path: path.join(OUT, `${tag}-section.png`) });
  await page.locator("[data-bottom-top-view]").screenshot({ path: path.join(OUT, `${tag}-top.png`) });
  const ghost = await page.locator("[data-bottom-ghost]").count();
  console.log(tag, "section at mm from tail", at, "ghost drawn", ghost);
}

async function threeD(page, tag) {
  await go(page, "/design/3d");
  const canvas = page.locator("[data-board-3d]");
  await canvas.waitFor({ state: "attached", timeout: 90000 });
  await page
    .waitForFunction(() => document.querySelector("[data-board-3d]")?.getAttribute("data-board-state") === "ready", null, { timeout: 90000 })
    .catch(() => {});
  const state = await canvas.getAttribute("data-board-state");
  console.log(tag, "3D state", state);
  const bottom = page.getByRole("group", { name: "Views" }).getByRole("button", { name: "Bottom", exact: true });
  await bottom.click();
  await page.waitForTimeout(2500);
  await page.locator("[data-three-d-drawing]").screenshot({ path: path.join(OUT, `${tag}-3d.png`) });
  return state;
}

/* ============ 17-20: the same boards, station, height and width, close-ups at 3x, then the before-and-after ============
 *
 *   capture: WT=<worktree> PORT=3320 OUT=<dir> LABEL=after  MODE=capture node 17-20-pictures.mjs
 *   compose: WT=<worktree> OUT=<dir> BEFORE_SHEET=<17-19-before.png> AFTER_SHEET=<17-19-after.png> MODE=compose \
 *            FINAL=<pictures/17-20-before-and-after.png> node 17-20-pictures.mjs
 *
 * The "after" sheet is 17-19's own script re-run with LABEL=after (same layout as 17-19-before.png). The close-ups
 * are this script's capture at deviceScaleFactor 3: the "after" from the fixed app, the "before" from the same worktree
 * with lib/geometry/volume.ts, design.ts and board-surface.ts put back to the base commit for the one run and then
 * restored (17-20-SUMMARY.md says so).
 */
const MODE = process.env.MODE ?? "capture";
const BOARDS = [
  { tag: "longboard", name: "Longboard", caption: 'Longboard (rolled rail), six channels, section 6" from the tail' },
  {
    tag: "shortboard-soft",
    name: "Shortboard",
    caption: 'Shortboard with a soft tail (Hard Edge unticked), six channels, section 6" from the tail',
    softTail: true,
  },
];

if (MODE === "capture") {
  const browser = await chromium.launch();
  for (const board of BOARDS) {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 3 });
    await context.addInitScript(() => {
      try {
        sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
        localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
        localStorage.removeItem("shaper-open-board");
      } catch {}
    });
    const page = await context.newPage();
    await openPreset(page, board.name);
    if (board.softTail) {
      await go(page, "/design/rails");
      const tail = page.locator('[data-rail-group="tail"]');
      const hard = tail.getByRole("checkbox", { name: "Hard Edge" });
      await hard.waitFor({ timeout: 60000 });
      if (await hard.isChecked()) await hard.click();
      if (await hard.isChecked()) throw new Error("Hard Edge still ticked");
    }
    await bottomShots(page, `${board.tag}-${LABEL}-x3`);
    await context.close();
  }
  await browser.close();
} else {
  const browser = await chromium.launch();
  const data = (f) => `data:image/png;base64,${fs.readFileSync(f).toString("base64")}`;
  const before = data(process.env.BEFORE_SHEET);
  const after = data(process.env.AFTER_SHEET);
  // the boxes of 17-19's sheet (its 1px borders found by scanning it): the section and the 3D view, per row
  const SHEET = { width: 1740, height: 1072 };
  const BOX = {
    longboard: { section: [17, 103, 560, 164], three: [1165, 103, 560, 433] },
    "shortboard-soft": { section: [17, 603, 560, 163], three: [1165, 603, 560, 432] },
  };
  // the right rail in the section, in the section's own CSS pixels (804 wide): close-up at 3x
  const CLOSE = { x: 490, y: 10, w: 160, h: 137 };
  const crop = (src, [x, y, w, h], scale = 1) =>
    `<div class="crop" style="width:${w * scale}px;height:${h * scale}px;background-image:url(${src});background-size:${SHEET.width * scale}px ${SHEET.height * scale}px;background-position:-${x * scale}px -${y * scale}px"></div>`;
  const close = (file) => {
    const s = 2.2;
    return `<div class="crop" style="width:${CLOSE.w * s}px;height:${CLOSE.h * s}px;background-image:url(${data(file)});background-size:${804 * s}px ${235 * s}px;background-position:-${CLOSE.x * s}px -${CLOSE.y * s}px"></div>`;
  };
  const rows = BOARDS.map((b) => {
    const box = BOX[b.tag];
    return `<section><h2>${b.caption}</h2>
  <div class="pair"><figure>${crop(before, box.section)}<figcaption><b>Before</b> (17-19): BOTTOM's section, finished rail from RAILS ticked, Height x4</figcaption></figure>
  <figure>${crop(after, box.section)}<figcaption><b>After</b> (17-20): the same section</figcaption></figure></div>
  <div class="pair"><figure>${close(path.join(OUT, `${b.tag}-before-x3-section.png`))}<figcaption><b>Before</b>, close-up of the right rail: the thin grey finished-rail line</figcaption></figure>
  <figure>${close(path.join(OUT, `${b.tag}-after-x3-section.png`))}<figcaption><b>After</b>, the same close-up</figcaption></figure></div>
  <div class="pair"><figure>${crop(before, box.three, 0.6)}<figcaption><b>Before</b>: 3D screen, Bottom view</figcaption></figure>
  <figure>${crop(after, box.three, 0.6)}<figcaption><b>After</b>: 3D screen, Bottom view</figcaption></figure></div>
  </section>`;
  }).join("\n");
  const html = `<html><body style="font-family:system-ui;margin:16px;background:#fff;color:#111;width:1180px">
<h1 style="font-size:24px">Phase 17, G-17-6 (17-20): channels cut straight up into the finished rail — before and after</h1>
<style>h2{font-size:17px;margin:18px 0 6px}.pair{display:flex;gap:16px;align-items:flex-start;margin-bottom:10px}figure{margin:0}.crop{border:1px solid #999;background-repeat:no-repeat}figcaption{font-size:13px;margin-top:4px;color:#333;max-width:560px}</style>
${rows}</body></html>`;
  const page = await browser.newPage({ viewport: { width: 1212, height: 900 } });
  await page.setContent(html);
  await page.waitForTimeout(500);
  await page.screenshot({ path: process.env.FINAL, fullPage: true });
  await browser.close();
  console.log("composed", process.env.FINAL);
}

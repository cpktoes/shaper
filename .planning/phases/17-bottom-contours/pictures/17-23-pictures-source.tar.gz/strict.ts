// 17-23: strict sheet compare. For every layout: the after layout, less `tablesTight`, equals the before layout with the
// old depths note replaced by the new one — except the Longboard's tight sheets, whose `tableNotes` must be every
// wanted note. Also checks `tablesTight` is false on every non-Longboard layout and whenever the tables stay on the page,
// and that the page's own spare never moves.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <before> <after>
import { readFileSync } from "node:fs";
import { BOTTOM_COPY } from "@/components/bottom/bottom-copy";

const OLD =
  "Deepest cut is the largest gap under a straightedge laid rail to rail at that station. Rail lift is that gap at the rail. Stringer left is the planed thickness less the cut at the stringer.";
type L = { layout: Record<string, unknown> & { tableNotes: string[]; tablesTight?: boolean; tablesOnOwnSheet: boolean; sheets: number }; spare: { page: number; tables: number | null } };
const b: Record<string, L> = JSON.parse(readFileSync(`${process.argv[2]}/sheets.json`, "utf8"));
const a: Record<string, L> = JSON.parse(readFileSync(`${process.argv[3]}/sheets.json`, "utf8"));
let ok = 0;
let bad = 0;
let tightOther = 0;
for (const key of Object.keys(b)) {
  const before = b[key];
  const after = a[key];
  const { tablesTight, ...rest } = after.layout;
  const mapped = { ...before.layout, tableNotes: before.layout.tableNotes.map((n) => (n === OLD ? BOTTOM_COPY.depthsNote : n)) };
  const isLong = key.startsWith("longboard|");
  if (!isLong && tablesTight) tightOther++;
  if (!after.layout.tablesOnOwnSheet && tablesTight) tightOther++;
  const same = (x: unknown, y: unknown) => JSON.stringify(x) === JSON.stringify(y);
  let good = after.spare.page === before.spare.page && after.layout.sheets === before.layout.sheets && after.layout.tablesOnOwnSheet === before.layout.tablesOnOwnSheet;
  if (tablesTight) {
    const { tableNotes: _x, ...r1 } = rest;
    const { tableNotes: _y, ...r2 } = mapped;
    good = good && same(r1, r2) && after.layout.tableNotes.length >= before.layout.tableNotes.length && after.layout.tableNotes[0] === BOTTOM_COPY.depthsNote;
  } else {
    good = good && same(rest, mapped);
  }
  if (good) ok++;
  else {
    bad++;
    if (bad < 10) console.log("BAD", key);
  }
}
console.log(`layouts ${Object.keys(b).length}: as expected ${ok}, not ${bad}; tight where it must not be ${tightOther}`);

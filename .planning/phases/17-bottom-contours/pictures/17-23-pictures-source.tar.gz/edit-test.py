p = '/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/components/summary/bottom-sheet-fit.test.ts'
s = open(p).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old, s.count(old))
    s = s.replace(old, new)


rep('''  BOTTOM_SECTION_BOX,
  BOTTOM_TABLES_BESIDE_MAX_COLUMNS,''', '''  BOTTOM_SECTION_BOX,
  BOTTOM_SHEET_SPARE,
  BOTTOM_TABLES_BESIDE_MAX_COLUMNS,''')
rep('''  const tightOf = (layout: BottomSheetLayout) => (layout as BottomSheetLayout & { tablesTight?: boolean }).tablesTight;
  /** The tables' sheet's spare room counted at today's rows, whatever the layout chose. */
  const regularSpare = (layout: BottomSheetLayout, board: BottomBoard) => bottomSheetSpare({ ...layout, tablesTight: false } as BottomSheetLayout, board).tables;
''', '''  /** The tables' sheet's spare room counted at today's rows, whatever the layout chose. */
  const regularSpare = (layout: BottomSheetLayout, board: BottomBoard) => bottomSheetSpare({ ...layout, tablesTight: false }, board).tables;
''')
s = s.replace("tightOf(layout)", "layout.tablesTight")
rep('''        expect(regularSpare(layout, board)!, `${what}: tight although the notes fit today's rows`).toBeLessThan(4);''',
    '''        expect(regularSpare(layout, board)!, `${what}: tight although the notes fit today's rows`).toBeLessThan(BOTTOM_SHEET_SPARE);''')
open(p, 'w').write(s)
print("ok", s.count("layout.tablesTight"))

// 17-23's compare: argv[2] = before folder, argv[3] = after folder. Prints, for gauges.json, whether every gauge but the
// rail lift is identical and whether each rail-lift gauge is drawn exactly where DATA's Rail lift (held at the
// slab's thickness) reads, carrying that value; and which stations' rail lift changed, per board. For sheets.json, the
// layouts that changed in anything but the notes' words, `tablesTight` and `tableNotes`/spare; the note counts before and
// after per Longboard and setup group. data.json and litres.json: identical or not.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <before> <after>
import { readFileSync } from "node:fs";
import { gaugeReads } from "@/lib/geometry/bottom-draw";
import { formatMark } from "@/lib/geometry/measure-display";
import { mm } from "@/lib/geometry/units";

const [before, after] = [process.argv[2], process.argv[3]];
const read = (dir: string, f: string) => readFileSync(`${dir}/${f}.json`, "utf8");
for (const f of ["data", "litres"]) console.log(`${f}.json`, read(before, f) === read(after, f) ? "identical" : "DIFFERS");

type G = { kind: string; value: number };
type Entry = { station: number; thickness: number; railLift: number; gauges: G[] };
const gb: Record<string, Entry[]> = JSON.parse(read(before, "gauges"));
const ga: Record<string, Entry[]> = JSON.parse(read(after, "gauges"));
let othersDiffer = 0;
let ruleBroken = 0;
let gone = 0;
let lower = 0;
let higher = 0;
let appeared = 0;
let stations = 0;
const changedAt: Record<string, string[]> = {};
for (const label of Object.keys(gb)) {
  gb[label].forEach((b, i) => {
    const a = ga[label][i];
    stations++;
    const others = (e: Entry) => JSON.stringify(e.gauges.filter((g) => g.kind !== "railLift"));
    if (others(a) !== others(b)) {
      othersDiffer++;
      console.log("OTHER GAUGE DIFFERS", label, b.station);
    }
    const want = Math.min(a.railLift, a.thickness);
    const lifts = a.gauges.filter((g) => g.kind === "railLift");
    const ok = gaugeReads(want, "imperial") ? lifts.length === 1 && lifts[0].value === want : lifts.length === 0;
    if (!ok) {
      ruleBroken++;
      console.log("RULE BROKEN", label, a.station, want, JSON.stringify(lifts));
    }
    const lb = b.gauges.find((g) => g.kind === "railLift");
    const la = lifts[0];
    if (JSON.stringify(lb) !== JSON.stringify(la)) {
      const show = (g?: G) => (g ? formatMark(mm(g.value), "imperial") : "none");
      if (!la) gone++;
      else if (!lb) appeared++;
      else if (la.value < lb.value) lower++;
      else if (la.value > lb.value) higher++;
      (changedAt[label] ??= []).push(`${i === 0 ? "tail" : `row ${i}`} (${b.station.toFixed(1)} mm): ${show(lb)} → ${show(la)}`);
    }
  });
}
console.log(`gauges: ${Object.keys(gb).length} boards, ${stations} stations; other gauges differing ${othersDiffer}; rule broken ${ruleBroken}`);
console.log(`rail lift: gone ${gone}, lower ${lower}, higher ${higher}, appeared ${appeared}; boards changed ${Object.keys(changedAt).length}`);
const notTail = Object.values(changedAt).flat().filter((t) => !t.startsWith("tail"));
console.log("changes off the tail row:", notTail.length);
if (process.env.LIST) for (const [k, v] of Object.entries(changedAt)) console.log(" ", k, "|", v.join("; "));

// sheets
const sb: Record<string, { layout: Record<string, unknown>; spare: { page: number; tables: number | null } }> = JSON.parse(read(before, "sheets"));
const sa: typeof sb = JSON.parse(read(after, "sheets"));
let sheetIdentical = 0;
let sheetOnlyWords = 0;
let sheetOther = 0;
const counts: Record<string, Record<string, number>> = {};
for (const key of Object.keys(sb)) {
  const b = sb[key];
  const a = sa[key];
  if (JSON.stringify(a) === JSON.stringify(b)) {
    sheetIdentical++;
  } else {
    const strip = (x: (typeof sb)[string]) => {
      const { tableNotes: _n, tablesTight: _t, ...rest } = x.layout as Record<string, unknown>;
      return JSON.stringify({ ...rest, page: x.spare.page });
    };
    if (strip(a) === strip(b) && (a.layout.tablesOnOwnSheet || !(a.layout as { tablesTight?: boolean }).tablesTight)) sheetOnlyWords++;
    else {
      sheetOther++;
      if (sheetOther < 10) console.log("SHEET DIFFERS BEYOND NOTES", key);
    }
  }
  if (key.startsWith("longboard|") && b.layout.tablesOnOwnSheet) {
    const parts = key.split("|");
    const group = `${parts[0]}|${parts[1]}|${parts[2]} · ${Number(parts[parts.length - 2]) > 0 ? "channels" : "no channels"} · ${parts[parts.length - 1]}`;
    const bn = (b.layout.tableNotes as string[]).length;
    const an = (a.layout.tableNotes as string[]).length;
    const tight = (a.layout as { tablesTight?: boolean }).tablesTight ? "tight" : "regular";
    const c = (counts[group] ??= {});
    c[`${bn}→${an} ${tight}`] = (c[`${bn}→${an} ${tight}`] ?? 0) + 1;
  }
}
console.log(`sheets: ${Object.keys(sb).length} layouts; identical ${sheetIdentical}; notes/tight/tables-spare only ${sheetOnlyWords}; other ${sheetOther}`);
if (process.env.LIST) for (const [k, v] of Object.entries(counts)) console.log(" ", k, JSON.stringify(v));

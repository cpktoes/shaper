// 17-23 regression capture. Writes four JSON files into argv[2] (a folder):
//  gauges.json — sectionGauges(bottomSection(resolved, board, row.station, 4, 804 × 165, { live: "tail" }), resolved,
//    board, "imperial") at every bottomDataRows station, on every board of phase17ChannelBoards() and on the four presets
//    (<id>|asis|hard and soft) with each of Panel Vee, Spiral Vee, Rolled Vee, Double Concave Exit, Extending Single
//    Concave and Continuous Belly / Rolled Mid at 0, 4, 6 and 8 channels. Each entry also carries the drawing's
//    thickness and DATA's row, so the compare can work out what the rail lift should read.
//  sheets.json — bottomSheetLayout (whole) and bottomSheetSpare for every board of phase16Boards() × the 96 cut setups
//    (each nose × tail name with a centre Early Double Concave at 0 and 8 channels, each centre name at 0, 4, 6, 8) ×
//    both systems.
//  data.json — bottomDataRows for every gauge board.
//  litres.json — summarizeDesign(fields).volumeLitres.toPrecision(17) for every gauge board.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <out dir> [gauges|sheets|all]
import { writeFileSync } from "node:fs";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { phase17ChannelBoards } from "@/lib/geometry/__fixtures__/phase17-channel-boards";
import {
  BOTTOM_CUT_NAMES,
  bottomDataRows,
  DEFAULT_BOTTOM,
  pickCut,
  resolveBottom,
  startingChannels,
  startingCut,
  type BoardBottom,
  type BottomBoard,
  type BottomCutName,
  type BottomSectionKey,
  type ChannelCount,
} from "@/lib/geometry/bottom";
import { bottomSection, sectionGauges } from "@/lib/geometry/bottom-draw";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, summarizeDesign, type DesignSummaryFields } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { UNITS_SYSTEMS } from "@/lib/geometry/units";
import { bottomSheetLayout, bottomSheetSpare } from "@/components/summary/bottom-sheet-fit";

const dir = process.argv[2];
const which = process.argv[3] ?? "all";
const all = phase16Boards();

function built(fields: DesignSummaryFields): { board: BottomBoard; frontPair: boolean } {
  const fins = designFinPlacement(fields);
  const board = designBottomBoard(fields.outline, buildOutline(fields.outline), designSideProfile(fields, LIVE_DESIGN_RULES), fins);
  return { board, frontPair: fins.marks.some((m) => m.role === "front") };
}

const BOX = { width: 804, height: 165 };
const GAUGE_CUTS: [BottomSectionKey, BottomCutName][] = [
  ["tail", "Panel Vee"],
  ["tail", "Spiral Vee"],
  ["tail", "Rolled Vee"],
  ["tail", "Double Concave Exit"],
  ["tail", "Extending Single Concave"],
  ["center", "Continuous Belly / Rolled Mid"],
];

if (which === "all" || which === "gauges") {
  const gauges: Record<string, unknown> = {};
  const data: Record<string, unknown> = {};
  const litres: Record<string, string> = {};
  const record = (label: string, fields: DesignSummaryFields) => {
    const { board } = built(fields);
    const resolved = resolveBottom(fields.bottom ?? DEFAULT_BOTTOM, board);
    const rows = bottomDataRows(resolved, board);
    data[label] = rows;
    litres[label] = summarizeDesign(fields).volumeLitres.toPrecision(17);
    gauges[label] = rows.map((row) => {
      const drawing = bottomSection(resolved, board, row.station, 4, BOX, { live: "tail" });
      return { station: row.station, thickness: drawing.thickness, railLift: row.railLift, gauges: sectionGauges(drawing, resolved, board, "imperial") };
    });
  };
  for (const { label, fields } of phase17ChannelBoards()) record(`p17|${label}`, fields);
  for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
    for (const edge of ["hard", "soft"]) {
      const base = all.find((b) => b.label === `${id}|asis|${edge}`)!.fields;
      const { board } = built(base);
      for (const [section, name] of GAUGE_CUTS) {
        for (const count of [0, 4, 6, 8] as const) {
          let bottom: BoardBottom = pickCut(structuredClone(DEFAULT_BOTTOM), section, name, board);
          if (count > 0) bottom = { ...bottom, channels: startingChannels(count, board, bottom.channels) };
          record(`${id}|${edge}|${name}|${count}`, { ...base, bottom });
        }
      }
    }
  }
  writeFileSync(`${dir}/gauges.json`, JSON.stringify(gauges));
  writeFileSync(`${dir}/data.json`, JSON.stringify(data));
  writeFileSync(`${dir}/litres.json`, JSON.stringify(litres));
  console.log("gauge boards", Object.keys(gauges).length);
}

if (which === "all" || which === "sheets") {
  type Names = Partial<Record<BottomSectionKey, BottomCutName>>;
  const setups: { key: string; names: Names; count: ChannelCount | 0 }[] = [];
  for (const nose of BOTTOM_CUT_NAMES.nose)
    for (const tail of BOTTOM_CUT_NAMES.tail)
      for (const count of [0, 8] as const) setups.push({ key: `${nose}|Early Double Concave|${tail}|${count}`, names: { nose, center: "Early Double Concave", tail }, count });
  for (const center of BOTTOM_CUT_NAMES.center)
    for (const count of [0, 4, 6, 8] as const) setups.push({ key: `c:${center}|${count}`, names: { center }, count });
  const sheets: Record<string, unknown> = {};
  for (const { label, fields } of all) {
    const { board, frontPair } = built(fields);
    for (const s of setups) {
      const bottom = structuredClone(DEFAULT_BOTTOM);
      for (const section of ["nose", "center", "tail"] as const) {
        const name = s.names[section];
        if (name) bottom[section] = startingCut(section, name, board);
      }
      if (s.count > 0) bottom.channels = startingChannels(s.count as ChannelCount, board, bottom.channels);
      const resolved = resolveBottom(bottom, board);
      for (const system of UNITS_SYSTEMS) {
        const layout = bottomSheetLayout(resolved, board, system, frontPair);
        sheets[`${label}|${s.key}|${system}`] = { layout, spare: bottomSheetSpare(layout, board) };
      }
    }
  }
  writeFileSync(`${dir}/sheets.json`, JSON.stringify(sheets));
  console.log("setups", setups.length, "layouts", Object.keys(sheets).length);
}

// 17-23: measure the tables sheet's row height as today and with each row's cell padding (`py-px`) taken off by a
// stylesheet injected for the measurement only — on the computer's print and on the phone sheet at every width the fit
// sweep counts. Prints one line per run. The worst Longboard: Teardrop Nose Concave, Early Double Concave, Spiral Vee,
// 8 channels. Run with measure.config.ts (desktop project only).
import { expect, test, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/lib/models/toolbar-tip";
import { boardWithBottom, openOnBoard } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/e2e/helpers/bottom-print";

const FIT_WIDTHS = [560, 618, 680, 733, 760, 800, 812, 900];
const TIGHT_CSS = "[data-bottom-tables-sheet] tbody td, [data-bottom-tables-sheet] tbody th { padding-top: 0 !important; padding-bottom: 0 !important; }";

function rowHeights() {
  const sheet = document.querySelector("[data-bottom-tables-sheet]")!;
  return [...sheet.querySelectorAll("table")].map((table) => {
    const trs = [...table.querySelectorAll("tbody tr")];
    const top = trs[0].getBoundingClientRect().top;
    const bottom = trs[trs.length - 1].getBoundingClientRect().bottom;
    const page = sheet.closest("[data-order-form-sheet]")!.getBoundingClientRect();
    return { rows: trs.length, perRow: (bottom - top) / trs.length, sheetWidth: page.width, sheetHeight: page.height };
  });
}

for (const system of ["imperial", "metric"] as const) {
  test(`row heights, regular and tight (${system})`, async ({ page }) => {
    test.setTimeout(300_000);
    await page.addInitScript((key) => window.sessionStorage.setItem(key, "true"), BANNER_DISMISSAL_KEY);
    await page.addInitScript((key) => window.localStorage.setItem(key, "true"), TOOLBAR_TIP_DISMISSAL_KEY);
    if (system === "metric") {
      await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
      await page.context().addCookies([{ name: "shaper-units", value: "metric", domain: "localhost", path: "/" }]);
    }
    const board = boardWithBottom("longboard", { nose: "Teardrop Nose Concave", center: "Early Double Concave", tail: "Spiral Vee", channels: 8 });
    await openOnBoard(page, board);
    await page.goto("/design/summary");
    await expect(page.locator("[data-bottom-tables-sheet]")).toHaveCount(1, { timeout: 60_000 });
    await page.waitForTimeout(2_000);
    const measure = async (label: string, p: Page) => {
      await p.emulateMedia({ media: "print" });
      const regular = await p.evaluate(rowHeights);
      const style = await p.addStyleTag({ content: TIGHT_CSS });
      const tight = await p.evaluate(rowHeights);
      await style.evaluate((el) => el.remove());
      await p.emulateMedia({ media: "screen" });
      console.log(
        `[17-23 ${system}] ${label}: sheet ${regular[0].sheetWidth.toFixed(1)}x${regular[0].sheetHeight.toFixed(1)} ` +
          regular.map((r, i) => `table ${i + 1} (${r.rows} rows): regular ${r.perRow.toFixed(3)} tight ${tight[i].perRow.toFixed(3)}`).join(" | "),
      );
    };
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.emulateMedia({ media: "print" });
    console.log("[17-23 debug]", await page.evaluate(() => {
      const td = document.querySelector("[data-bottom-tables-sheet] tbody td")!;
      const tr = td.parentElement!;
      const cs = getComputedStyle(td);
      const ts = getComputedStyle(tr);
      return JSON.stringify({ tdClass: td.className, pad: [cs.paddingTop, cs.paddingBottom], lh: cs.lineHeight, fs: cs.fontSize, h: td.getBoundingClientRect().height, trH: tr.getBoundingClientRect().height, trLh: ts.lineHeight, trFs: ts.fontSize, trB: ts.borderBottomWidth, html: tr.outerHTML.slice(0, 400) });
    }));
    await page.emulateMedia({ media: "screen" });
    await measure("computer print", page);
    await page.locator("[data-order-form-root]").evaluate((el) => el.setAttribute("data-print-touch", "true"));
    for (const width of FIT_WIDTHS) {
      await page.setViewportSize({ width, height: 1400 });
      await measure(`touch ${width}`, page);
    }
  });
}

// 17-23's pictures, 1280 wide, Imperial. PICS_PHASE=before|after names the files. Run with the scratch pics.config.ts
// (desktop project only).
//  - BOTTOM's VIEWER section at DATA's tail row: the Fish with a flat tail and its starting eight channels, and the Fish
//    with a Rolled Vee and eight.
//  - The printed BOTTOM CONTOURS page's sections of the Fish with a Rolled Vee and eight.
//  - BOTTOM's DATA of the Fish with a flat tail and eight (the note under the depths table's box recorded for a ring).
//  - The order form's BOTTOM CONTOURS tables sheet of the Longboard with Teardrop Nose Concave, Early Double Concave,
//    Spiral Vee, with 8 channels and with none.
import { writeFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/lib/models/toolbar-tip";
import { bottomDataRows } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/lib/geometry/bottom";
import { boardWithBottom, openOnBoard, type BoardWithBottom } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/e2e/helpers/bottom-print";
import { BOTTOM_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/components/bottom/bottom-copy";
import { bottomSheetLayout } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/components/summary/bottom-sheet-fit";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/p23/pics-out";
const PHASE = process.env.PICS_PHASE ?? "before";

async function dismiss(page: Page) {
  await page.addInitScript((key) => window.sessionStorage.setItem(key, "true"), BANNER_DISMISSAL_KEY);
  await page.addInitScript((key) => window.localStorage.setItem(key, "true"), TOOLBAR_TIP_DISMISSAL_KEY);
}

test.setTimeout(240_000);
test.use({ deviceScaleFactor: 2, viewport: { width: 1280, height: 800 } });

async function openBottomOn(page: Page, board: BoardWithBottom) {
  await dismiss(page);
  await openOnBoard(page, board);
  await page.goto("/design/bottom");
  await expect(page.locator("[data-bottom-cut-line]")).toBeAttached({ timeout: 60_000 });
  await expect(page.locator("[data-bottom-channels-echo]")).not.toHaveText("None", { timeout: 60_000 });
  await page.waitForTimeout(2_000);
}

async function viewerAtTail(page: Page, board: BoardWithBottom, name: string) {
  await openBottomOn(page, board);
  const rows = bottomDataRows(board.resolved, board.board);
  const tailRow = rows.reduce((a, b) => (b.station < a.station ? b : a));
  const slider = page.getByRole("slider", { name: BOTTOM_COPY.sectionAt, exact: true });
  await expect(slider).toBeVisible({ timeout: 30_000 });
  const cutAt = async () => Number(await page.locator("[data-bottom-cut-at]").getAttribute("data-bottom-cut-at"));
  await slider.focus();
  for (let i = 0; i < 400 && (await cutAt()) > tailRow.station + 0.5; i++) await page.keyboard.press("ArrowRight");
  console.log(name, "viewer at", await cutAt(), "tail row", tailRow.station, "rail lift", tailRow.railLift);
  await page.waitForTimeout(2_000);
  const texts = await page.locator("[data-bottom-section] [data-gauge]").evaluateAll((gs) => gs.map((g) => `${g.getAttribute("data-gauge")}: ${(g.textContent ?? "").trim()}`));
  console.log(name, "gauges", JSON.stringify(texts));
  writeFileSync(`${OUT}/${PHASE}-${name}-gauges.json`, JSON.stringify(texts));
  await page.locator("[data-bottom-section]").screenshot({ path: `${OUT}/${PHASE}-${name}.png` });
}

test("viewer: fish, flat tail, eight channels", async ({ page }) => {
  await viewerAtTail(page, boardWithBottom("fish", { channels: 8 }), "viewer-fish-flat-8");
});

test("viewer: fish, Rolled Vee, eight channels", async ({ page }) => {
  await viewerAtTail(page, boardWithBottom("fish", { tail: "Rolled Vee", channels: 8 }), "viewer-fish-rv-8");
});

test("paper: fish, Rolled Vee, eight channels — the BOTTOM CONTOURS page's sections", async ({ page }) => {
  await dismiss(page);
  const board = boardWithBottom("fish", { tail: "Rolled Vee", channels: 8 });
  await openOnBoard(page, board);
  await page.goto("/design/summary");
  await expect(page.locator("[data-bottom-sheet]")).toBeVisible({ timeout: 60_000 });
  await expect(page.locator("[data-bottom-sheet-section]")).toHaveCount(2, { timeout: 60_000 });
  await page.waitForTimeout(2_000);
  const texts = await page.locator("[data-bottom-sheet-gauge]").evaluateAll((gs) => gs.map((g) => `${g.getAttribute("data-bottom-sheet-gauge")}: ${(g.textContent ?? "").trim()}`));
  writeFileSync(`${OUT}/${PHASE}-paper-fish-rv-8-gauges.json`, JSON.stringify(texts));
  const part = page.locator('[data-bottom-sheet-part="sections"]');
  await part.scrollIntoViewIfNeeded();
  await part.screenshot({ path: `${OUT}/${PHASE}-paper-fish-rv-8.png` });
});

test("data: fish, flat tail, eight channels — the note under the depths table", async ({ page }) => {
  const board = boardWithBottom("fish", { channels: 8 });
  await openBottomOn(page, board);
  const dataTab = page.getByRole("tab", { name: "DATA", exact: true });
  await expect(async () => {
    if ((await page.locator("[data-bottom-data]").count()) === 0) await dataTab.click({ timeout: 2_000 });
    await expect(page.locator("[data-bottom-data]")).toBeVisible({ timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await page.waitForTimeout(3_000);
  const notes = page.locator("[data-bottom-notes]");
  await notes.scrollIntoViewIfNeeded();
  await page.waitForTimeout(500);
  const data = page.locator("[data-bottom-data]");
  await data.screenshot({ path: `${OUT}/${PHASE}-data-fish-8.png` });
  const box = await data.boundingBox();
  const noteBox = await page.locator("[data-bottom-notes] p").first().boundingBox();
  const cellBox = await page.locator("[data-bottom-depths] tbody tr").first().locator("td").nth(2).boundingBox();
  writeFileSync(
    `${OUT}/${PHASE}-data-boxes.json`,
    JSON.stringify({
      note: { x: (noteBox!.x - box!.x) * 2, y: (noteBox!.y - box!.y) * 2, w: noteBox!.width * 2, h: noteBox!.height * 2 },
      cell: { x: (cellBox!.x - box!.x) * 2, y: (cellBox!.y - box!.y) * 2, w: cellBox!.width * 2, h: cellBox!.height * 2 },
      visible: { w: box!.width * 2, h: box!.height * 2 },
    }),
  );
  console.log("note", await page.locator("[data-bottom-notes] p").first().textContent());
});

for (const channels of [8, 0] as const) {
  test(`tables sheet: longboard, three cuts, ${channels} channels`, async ({ page }) => {
    await dismiss(page);
    const board = boardWithBottom("longboard", { nose: "Teardrop Nose Concave", center: "Early Double Concave", tail: "Spiral Vee", ...(channels ? { channels } : {}) });
    const layout = bottomSheetLayout(board.resolved, board.board, "imperial", board.frontPair);
    console.log("layout notes", layout.tableNotes.length, "own sheet", layout.tablesOnOwnSheet);
    // A window tall enough for the whole sheet, so the top bar never lies over it in the picture.
    await page.setViewportSize({ width: 1280, height: 6000 });
    await openOnBoard(page, board);
    await page.goto("/design/summary");
    await expect(page.locator("[data-bottom-tables-sheet]")).toHaveCount(1, { timeout: 60_000 });
    await expect(page.locator("[data-bottom-tables-sheet] table[data-bottom-sheet-depths] tbody tr")).toHaveCount(layout.dataRows.length, { timeout: 60_000 });
    await page.waitForTimeout(2_000);
    const sheet = page.locator("[data-order-form-sheet]").filter({ has: page.locator("[data-bottom-tables-sheet]") });
    await sheet.scrollIntoViewIfNeeded();
    await page.waitForTimeout(500);
    const notes = await page.locator('[data-bottom-sheet-part="table-notes"] p').allTextContents();
    writeFileSync(`${OUT}/${PHASE}-tables-longboard-${channels}-notes.json`, JSON.stringify(notes));
    const rowsMark = await page.locator("[data-bottom-tables-sheet]").getAttribute("data-bottom-rows");
    writeFileSync(`${OUT}/${PHASE}-tables-longboard-${channels}-rows.json`, JSON.stringify(rowsMark));
    await sheet.screenshot({ path: `${OUT}/${PHASE}-tables-longboard-${channels}.png` });
  });
}

p = '/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/components/summary/bottom-contours-sheet.tsx'
s = open(p).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old, s.count(old))
    s = s.replace(old, new)


rep('''const STATION_CELL = "whitespace-nowrap py-px pr-1.5 text-left font-bold text-surf-ink";
const CELL = "whitespace-nowrap py-px pl-1.5 text-right";''', '''const STATION_CELL = "whitespace-nowrap py-px pr-1.5 text-left font-bold text-surf-ink";
const CELL = "whitespace-nowrap py-px pl-1.5 text-right";
/**
 * The same two cells with their one dot of padding above and below taken off: the rows of the tables' own sheet when
 * its notes need the room (`layout.tablesTight`; the founder, 2026-11-11: "Make it fit"). The type is the same size.
 */
const STATION_CELL_TIGHT = "whitespace-nowrap pr-1.5 text-left font-bold text-surf-ink";
const CELL_TIGHT = "whitespace-nowrap pl-1.5 text-right";''')
rep('''function DepthsTable({ layout, beside = false }: { layout: BottomSheetLayout; beside?: boolean }) {''',
    '''function DepthsTable({ layout, beside = false, tight = false }: { layout: BottomSheetLayout; beside?: boolean; tight?: boolean }) {''')
rep('''function MarksTable({ layout, beside = false }: { layout: BottomSheetLayout; beside?: boolean }) {''',
    '''function MarksTable({ layout, beside = false, tight = false }: { layout: BottomSheetLayout; beside?: boolean; tight?: boolean }) {''')
rep('''            const cell = cn(CELL, row.reference !== null ? "font-bold text-surf-ink" : "text-surf-ink-muted");''',
    '''            const cell = cn(tight ? CELL_TIGHT : CELL, row.reference !== null ? "font-bold text-surf-ink" : "text-surf-ink-muted");''', 2)
rep('''                <th scope="row" className={STATION_CELL}>''', '''                <th scope="row" className={tight ? STATION_CELL_TIGHT : STATION_CELL}>''', 2)
rep('''/** Part 3: the two tables — side by side when the marks table is narrow, otherwise one above the other. */
function Tables({ layout, beside }: { layout: BottomSheetLayout; beside: boolean }) {
  const columns = layout.marks.columns.length;
  if (columns === 0) {
    return (
      <div data-bottom-sheet-part="tables" className="flex flex-none flex-col gap-1">
        <DepthsTable layout={layout} />
      </div>
    );
  }
  if (!beside) {
    return (
      <div data-bottom-sheet-part="tables" className="flex flex-none flex-col gap-1">
        <DepthsTable layout={layout} />
        <MarksTable layout={layout} />
      </div>
    );
  }''', '''/**
 * Part 3: the two tables — side by side when the marks table is narrow, otherwise one above the other. `tight` draws
 * the full-width tables' rows without their padding (the tables' own sheet only; the page itself never tightens).
 */
function Tables({ layout, beside, tight = false }: { layout: BottomSheetLayout; beside: boolean; tight?: boolean }) {
  const columns = layout.marks.columns.length;
  if (columns === 0) {
    return (
      <div data-bottom-sheet-part="tables" className="flex flex-none flex-col gap-1">
        <DepthsTable layout={layout} tight={tight} />
      </div>
    );
  }
  if (!beside) {
    return (
      <div data-bottom-sheet-part="tables" className="flex flex-none flex-col gap-1">
        <DepthsTable layout={layout} tight={tight} />
        <MarksTable layout={layout} tight={tight} />
      </div>
    );
  }''')
rep('''/**
 * The tables' own sheet, for a board whose cuts fill the page: the same two tables at the page's full width, with
 * DATA's own notes on how to read them — as many as the fit rule found room for under the tables
 * (`layout.tableNotes`; the longest board with the most columns of marks leaves room for none, and keeps every row).
 */
export function BottomTablesSheet({ layout }: { layout: BottomSheetLayout }) {
  return (
    <div data-bottom-tables-sheet className="flex min-h-0 flex-1 flex-col gap-1">
      <Tables layout={layout} beside={false} />''', '''/**
 * The tables' own sheet, for a board whose cuts fill the page: the same two tables at the page's full width, with
 * DATA's own notes on how to read them — every one (`layout.tableNotes`; the founder, 2026-11-11: "Make it fit"). Where
 * they would not otherwise all fit, the rows sit two dots closer together (`layout.tablesTight`, marked
 * `data-bottom-rows="tight"`), every row kept and the type the same size.
 */
export function BottomTablesSheet({ layout }: { layout: BottomSheetLayout }) {
  return (
    <div data-bottom-tables-sheet data-bottom-rows={layout.tablesTight ? "tight" : undefined} className="flex min-h-0 flex-1 flex-col gap-1">
      <Tables layout={layout} beside={false} tight={layout.tablesTight} />''')
open(p, 'w').write(s)
print("ok")

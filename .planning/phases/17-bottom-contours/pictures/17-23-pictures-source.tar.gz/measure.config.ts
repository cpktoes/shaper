// Scratch config for 17-23's row-height measurement: the suite's own config, its dev server started from the worktree
// (PW_PORT=3323), its desktop project only, the spec from this scratch folder.
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615/playwright.config";

const SCRATCH = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/p23";
const server = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer!;

export default {
  ...base,
  testDir: `${SCRATCH}/measure`,
  testIgnore: [],
  outputDir: `${SCRATCH}/measure-results`,
  webServer: { ...server, cwd: "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a908d504f4b27f615" },
  projects: (base.projects ?? []).filter((p) => p.name === "desktop"),
};

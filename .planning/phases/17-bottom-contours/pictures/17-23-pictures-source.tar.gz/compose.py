# 17-23: put the before and after pictures side by side, a caption over each row, into one PNG.
# Usage: python3 compose.py gauge|note <pics-out dir> <output png>
import json
import sys
from PIL import Image, ImageDraw, ImageFont

mode, src, out = sys.argv[1], sys.argv[2], sys.argv[3]


def font(size):
    for path in ["/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()


title_font = font(34)
caption_font = font(26)
label_font = font(24)
pad = 24
gap = 30
title_h = 60
caption_h = 40
label_h = 34
RED = (214, 40, 40)


def open_rgb(name):
    return Image.open(f"{src}/{name}.png").convert("RGB")


def sheet_of(title, rows, extra_lines=()):
    """rows: (caption lines, before image, after image, before ring, after ring) — a ring is a box or None."""
    col_w = max(max(b.width, a.width) for _, b, a, _, _ in rows)
    width = pad * 2 + col_w * 2 + gap
    height = pad + title_h + len(extra_lines) * caption_h
    for lines, b, a, _, _ in rows:
        height += len(lines) * caption_h + label_h + max(b.height, a.height) + pad
    height += pad
    sheet = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text((pad, pad), title, fill="black", font=title_font)
    y = pad + title_h
    for line in extra_lines:
        draw.text((pad, y), line, fill="black", font=caption_font)
        y += caption_h
    for lines, before, after, ring_b, ring_a in rows:
        for line in lines:
            draw.text((pad, y), line, fill="black", font=caption_font)
            y += caption_h
        draw.text((pad, y), "Before", fill=(120, 120, 120), font=label_font)
        draw.text((pad + col_w + gap, y), "After", fill=(120, 120, 120), font=label_font)
        y += label_h
        for x, im, ring in [(pad, before, ring_b), (pad + col_w + gap, after, ring_a)]:
            sheet.paste(im, (x, y))
            draw.rectangle([x - 1, y - 1, x + im.width, y + im.height], outline=(200, 200, 200))
            if ring:
                draw.rectangle([x + ring["x"] - 8, y + ring["y"] - 6, x + ring["x"] + ring["w"] + 8, y + ring["y"] + ring["h"] + 6], outline=RED, width=5)
        y += max(before.height, after.height) + pad
    return sheet


if mode == "gauge":
    rows = [
        (["Fish, flat tail, its starting eight channels - BOTTOM's VIEWER, the section at DATA's tail row",
          "The 5/16\" \"rail lift\" was the channel running out through the rail. A flat tail lifts no rail, so it is gone."],
         open_rgb("before-viewer-fish-flat-8"), open_rgb("after-viewer-fish-flat-8"), None, None),
        (["Fish, Rolled Vee tail, eight channels - the same section at the tail row",
          "The rail lift now reads the vee's own lift (1/4\"), DATA's figure; it read 9/16\" with the channel counted."],
         open_rgb("before-viewer-fish-rv-8"), open_rgb("after-viewer-fish-rv-8"), None, None),
        (["The printed BOTTOM CONTOURS page, Fish, Rolled Vee, eight channels - its two sections",
          "The printed sections stand where each cut is deepest, at the fins, where the channels are still inside the rail,",
          "so the paper reads the same there (identical to the dot), and follows the same rule wherever a channel reaches the rail."],
         open_rgb("before-paper-fish-rv-8"), open_rgb("after-paper-fish-rv-8"), None, None),
    ]
    sheet = sheet_of("17-23 - BOTTOM's section reads the rail lift DATA reads, the vee or belly alone (\"Match DATA\")", rows,
                     ["1280 wide, Imperial. Every other reading on the section is where it was."])
else:
    boxes_b = json.load(open(f"{src}/before-data-boxes.json"))
    boxes_a = json.load(open(f"{src}/after-data-boxes.json"))
    notes = {k: json.load(open(f"{src}/{k}-notes.json")) for k in [
        "before-tables-longboard-8", "after-tables-longboard-8", "before-tables-longboard-0", "after-tables-longboard-0"]}

    def shrink(im, w):
        return im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)

    def rows_word(name):
        try:
            mark = json.load(open(f"{src}/{name}-rows.json"))
        except OSError:
            mark = None
        return "the rows two dots closer together, the type the same size" if mark == "tight" else "the rows as they were"

    t8b, t8a = open_rgb("before-tables-longboard-8"), open_rgb("after-tables-longboard-8")
    t0b, t0a = open_rgb("before-tables-longboard-0"), open_rgb("after-tables-longboard-0")
    rows = [
        (["Fish, flat tail, its starting eight channels - BOTTOM's DATA. The note under the depths table is ringed:",
          "its middle sentence is now the founder's own. (The tail row's Rail lift dash is what it explains.)"],
         open_rgb("before-data-fish-8"), open_rgb("after-data-fish-8"), boxes_b["note"], boxes_a["note"]),
        ([f"9'+ Longboard, Teardrop Nose Concave, Early Double Concave, Spiral Vee, 8 channels - the printed tables sheet",
          f"Before: {len(notes['before-tables-longboard-8'])} note under the tables. After: {len(notes['after-tables-longboard-8'])} notes in the new words, {rows_word('after-tables-longboard-8')}."],
         t8b, t8a, None, None),
        ([f"The same Longboard and cuts, no channels - the printed tables sheet",
          f"Before: {len(notes['before-tables-longboard-0'])} notes in the old words. After: {len(notes['after-tables-longboard-0'])} notes in the new words, {rows_word('after-tables-longboard-0')}."],
         t0b, t0a, None, None),
    ]
    sheet = sheet_of("17-23 - DATA's note in the founder's words (\"Use the sentence\"), and the Longboard's tables sheet (\"Make it fit\")", rows,
                     ["1280 wide, Imperial."])
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

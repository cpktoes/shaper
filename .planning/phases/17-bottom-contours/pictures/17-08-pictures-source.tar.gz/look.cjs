// A quick look at BOTTOM on the worktree's dev server (3308): the Shortboard, flat, then CENTER → Deep Single Concave,
// VIEWER and DATA, at 1280 × 800, deviceScaleFactor 2.
const { chromium } = require("@playwright/test");
const OUT = __dirname;
const BASE = "http://localhost:3308";

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  await context.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
  const page = await context.newPage();
  await page.goto(`${BASE}/`);
  const card = page.getByRole("button").filter({ hasText: "Start Shaping" }).filter({ hasText: "Shortboard" }).first();
  for (let i = 0; i < 30; i++) {
    await card.click().catch(() => {});
    try {
      await page.waitForURL("**/design/outline", { timeout: 2000 });
      break;
    } catch {}
  }
  await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
  await page.waitForURL("**/design/bottom");
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${OUT}/flat-viewer.png` });
  const trigger = page.getByRole("combobox", { name: "Center Cut" });
  for (let i = 0; i < 20; i++) {
    await trigger.click();
    const opt = page.getByRole("option", { name: "Deep Single Concave", exact: true });
    try {
      await opt.click({ timeout: 2000 });
      break;
    } catch {}
  }
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/deep-viewer.png` });
  await page.getByRole("tab", { name: "DATA", exact: true }).click();
  await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/deep-data.png` });
  await browser.close();
})();

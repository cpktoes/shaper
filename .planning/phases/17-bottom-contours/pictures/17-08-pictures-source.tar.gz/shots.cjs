// The founder's first look at BOTTOM (17-08, Task 3): real pictures of the running page on the worktree's dev server
// (port 3308), deviceScaleFactor 2. Writes PNGs beside this script; compose.py lays them out with captions.
const { chromium, devices } = require("@playwright/test");
const OUT = `${__dirname}/shots`;
const BASE = "http://localhost:3308";
require("fs").mkdirSync(OUT, { recursive: true });

async function dismiss(context) {
  await context.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
}

async function openShortboard(page) {
  await page.goto(`${BASE}/`);
  const card = page.getByRole("button").filter({ hasText: "Start Shaping" }).filter({ hasText: "Shortboard" }).first();
  for (let i = 0; i < 40; i++) {
    await card.click().catch(() => {});
    try {
      await page.waitForURL("**/design/outline", { timeout: 2000 });
      return;
    } catch {}
  }
  throw new Error("the Shortboard never opened");
}

async function pick(page, select, option) {
  const trigger = page.getByRole("combobox", { name: select });
  for (let i = 0; i < 20; i++) {
    await trigger.click();
    try {
      await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2000 });
      return;
    } catch {}
  }
  throw new Error(`could not pick ${option}`);
}

async function openMenu(page) {
  const button = page.getByRole("banner").getByRole("button", { name: "Menu" });
  for (let i = 0; i < 20; i++) {
    await button.click().catch(() => {});
    try {
      await page.locator('[role="menu"] [data-screen-tile]').first().waitFor({ timeout: 2000 });
      break;
    } catch {}
  }
  await page.waitForTimeout(600);
}

(async () => {
  const browser = await chromium.launch();

  // The computer, 1280 x 800.
  {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
    await dismiss(context);
    const page = await context.newPage();
    await openShortboard(page);
    await page.screenshot({ path: `${OUT}/nav-1280.png`, clip: { x: 0, y: 0, width: 1280, height: 82 } });
    await page.locator("nav:not([aria-label])").getByRole("link", { name: "ROCKER", exact: true }).click();
    await page.waitForURL("**/design/rocker");
    await page.waitForTimeout(1500);
    const next = page.getByRole("navigation", { name: "Back and Next", exact: true });
    await next.scrollIntoViewIfNeeded();
    const box = await next.boundingBox();
    await page.screenshot({ path: `${OUT}/rocker-next.png`, clip: { x: 0, y: Math.max(0, box.y - 20), width: 400, height: box.height + 40 } });
    await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
    await page.waitForURL("**/design/bottom");
    await page.waitForTimeout(2000);
    await page.screenshot({ path: `${OUT}/bottom-flat.png` });
    await pick(page, "Center Cut", "Deep Single Concave");
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${OUT}/bottom-deep-viewer.png` });
    await page.getByRole("tab", { name: "DATA", exact: true }).click();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: `${OUT}/bottom-deep-data.png` });
    await context.close();
  }

  // The nav row at 820.
  {
    const context = await browser.newContext({ viewport: { width: 820, height: 800 }, deviceScaleFactor: 2 });
    await dismiss(context);
    const page = await context.newPage();
    await page.goto(`${BASE}/design/bottom`);
    await page.waitForTimeout(2500);
    const nav = await page.locator("nav:not([aria-label])").boundingBox();
    await page.screenshot({ path: `${OUT}/nav-820.png`, clip: { x: 0, y: 0, width: 820, height: nav.height } });
    await context.close();
  }

  // The ☰ sheet on an iPhone 14, upright, with the Deep Single picked so BOTTOM's tile has a cut to show.
  {
    const context = await browser.newContext({ ...devices["iPhone 14"], deviceScaleFactor: 2 });
    await dismiss(context);
    const page = await context.newPage();
    await openShortboard(page);
    await openMenu(page);
    await page.screenshot({ path: `${OUT}/sheet-upright-flat.png` });
    await page.keyboard.press("Escape");
    await page.goto(`${BASE}/design/bottom`);
    await page.waitForTimeout(2000);
    await pick(page, "Center Cut", "Deep Single Concave");
    await page.waitForTimeout(1000);
    await openMenu(page);
    await page.screenshot({ path: `${OUT}/sheet-upright-cut.png` });
    await context.close();
  }

  // Held sideways, 844 x 390: one row of eight.
  {
    const context = await browser.newContext({ ...devices["iPhone 14 landscape"], viewport: { width: 844, height: 390 }, deviceScaleFactor: 2 });
    await dismiss(context);
    const page = await context.newPage();
    await openShortboard(page);
    await openMenu(page);
    await page.screenshot({ path: `${OUT}/sheet-sideways.png` });
    await context.close();
  }

  await browser.close();
  console.log("done");
})();

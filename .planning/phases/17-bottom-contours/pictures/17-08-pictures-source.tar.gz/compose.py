"""Lays the founder's first-look shots (shots.cjs) out on one captioned sheet: 17-08-bottom-screen-first-look.png."""
import sys
from PIL import Image, ImageDraw, ImageFont

HERE = sys.argv[1]
OUT = sys.argv[2]
S = f"{HERE}/shots"
W = 2700
PAD = 40
BG = (250, 249, 246)
INK = (24, 28, 34)
MUTED = (96, 100, 108)


def font(size, bold=False):
    for path in ["/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
                 "/Library/Fonts/Arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


TITLE = font(44, True)
HEAD = font(30, True)
BODY = font(24)


def load(name, scale):
    im = Image.open(f"{S}/{name}").convert("RGB")
    return im.resize((round(im.width * scale), round(im.height * scale)), Image.LANCZOS)


def framed(im):
    out = Image.new("RGB", (im.width + 2, im.height + 2), (180, 176, 168))
    out.paste(im, (1, 1))
    return out


blocks = []  # (heading, note, [images])
blocks.append(("1. The top row: BOTTOM is third, between ROCKER and RAILS",
               "At 1280 wide (above) and 820 wide (below), where the gaps between the links are narrower so all eight still fit.",
               [[load("nav-1280.png", 1.0)], [load("nav-820.png", 1.0)]]))
blocks.append(("2. ROCKER's Next now reads Bottom",
               "Back + Next walk TEMPLATE, ROCKER, BOTTOM, RAILS ... ; BOTTOM's own pair reads Rocker / Rails.",
               [[load("rocker-next.png", 1.0)]]))
blocks.append(("3. BOTTOM at 1280 x 800 — the Shortboard as it opens (left), then CENTER → Deep Single Concave (right)",
               "Panel in RAILS' dress: the board's size, then Nose, Center and Tail each with its Cut menu. From below: the shade darkens toward the "
               "deepest with a line every 1/16\"; the pencil line is the concave's edge; the fins are FINS' own lines. Across: the section at the cut's "
               "deepest, Height x4, with the gap under the straightedge at the stringer.",
               [[load("bottom-flat.png", 0.5), load("bottom-deep-viewer.png", 0.5)]]))
blocks.append(("4. DATA with the Deep Single — and the menu sheet on an iPhone 14 held upright",
               "DATA's first line reads VOLUME's own litres (28.87 L now, 29.61 L before); the depths under a straightedge every 6\", the wide "
               "point's and front fins' rows in full ink. The sheet: eight tiles, four over four — flat (middle) reads All flat; with the cut (right) 1 cut.",
               [[load("bottom-deep-data.png", 0.5), load("sheet-upright-flat.png", 0.5), load("sheet-upright-cut.png", 0.5)]]))
blocks.append(("5. Held sideways (844 x 390): one row of eight",
               "Each tile about 96 dots wide; the browser test's floor is 92.",
               [[load("sheet-sideways.png", 0.75)]]))


def wrap(draw, text, fnt, width):
    words, lines, line = text.split(), [], ""
    for w in words:
        trial = f"{line} {w}".strip()
        if draw.textlength(trial, font=fnt) > width:
            lines.append(line)
            line = w
        else:
            line = trial
    if line:
        lines.append(line)
    return lines


probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
height = PAD + 70
layout = []
for heading, note, rows in blocks:
    note_lines = wrap(probe, note, BODY, W - 2 * PAD)
    h = 44 + 32 * len(note_lines) + 12
    row_heights = [max(im.height + 2 for im in row) for row in rows]
    h += sum(row_heights) + 16 * len(rows) + 30
    layout.append((heading, note_lines, rows, row_heights))
    height += h

sheet = Image.new("RGB", (W, height), BG)
d = ImageDraw.Draw(sheet)
d.text((PAD, PAD), "Phase 17 · 17-08 — BOTTOM on the screen for the first time", font=TITLE, fill=INK)
y = PAD + 70
for heading, note_lines, rows, row_heights in layout:
    d.text((PAD, y), heading, font=HEAD, fill=INK)
    y += 44
    for line in note_lines:
        d.text((PAD, y), line, font=BODY, fill=MUTED)
        y += 32
    y += 12
    for row, rh in zip(rows, row_heights):
        x = PAD
        for im in row:
            sheet.paste(framed(im), (x, y))
            x += im.width + 2 + 24
        y += rh + 16
    y += 30
sheet.save(OUT, optimize=True)
print(OUT, sheet.size)

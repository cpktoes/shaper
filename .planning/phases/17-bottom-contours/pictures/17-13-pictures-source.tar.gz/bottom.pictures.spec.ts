import { join } from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5c3348348b0c6dd8/e2e/helpers/screens";
import { openAppSettings } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5c3348348b0c6dd8/e2e/helpers/settings";

// Scratch: the pictures for the founder's look at 17-13 — FINS' tail drawing with the bottom's contours under the
// fins, a fin move carrying the tail cut and the channels on BOTTOM, and BOTTOM in Metric beside Imperial.
// Every picture is the running page on the worktree's own dev server.
const SHOTS = join(__dirname, "shots");
const shot = (name: string) => join(SHOTS, `${name}.png`);
const squash = (text: string | null | undefined) => (text ?? "").replace(/\s+/g, " ").trim();
const FIN_STEPS = 16;

async function quiet(page: Page) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
}

async function openPreset(page: Page, name: string) {
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  await expect(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2_000 });
      await card.click({ timeout: 2_000 });
    }
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
  }).toPass({ timeout: 90_000 });
}

async function toBottom(page: Page) {
  await goToScreen(page, "BOTTOM");
  await expect(page).toHaveURL(/\/design\/bottom$/, { timeout: 60_000 });
  await expect(page.locator('[data-bottom-card="nose"]')).toBeAttached({ timeout: 60_000 });
}

async function toFins(page: Page) {
  await goToScreen(page, "FINS");
  await expect(page).toHaveURL(/\/design\/fins$/, { timeout: 60_000 });
  await expect(page.locator("[data-fin-plot] svg").first()).toBeVisible({ timeout: 60_000 });
}

async function pick(page: Page, section: "Nose" | "Center" | "Tail", name: string) {
  await expect(async () => {
    await page.getByRole("combobox", { name: `${section} Cut` }).click();
    await page.getByRole("option", { name, exact: true }).click({ timeout: 2_000 });
    await expect(page.locator(`[data-bottom-card="${section.toLowerCase()}"] [data-bottom-cut-echo]`)).toHaveText(name, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

async function pickFrom(page: Page, menu: string, option: string) {
  const box = page.getByRole("combobox", { name: menu, exact: true });
  await expect(async () => {
    await box.click();
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2_000 });
    await expect(box).toContainText(option, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

/** The pointer parked where it lights nothing up, and a beat for the drawings to settle. */
async function calm(page: Page, ms = 600) {
  const size = page.viewportSize()!;
  await page.mouse.move(size.width - 4, size.height - 4);
  await page.waitForTimeout(ms);
}

/** The browser's kept copy of the open board holds `needle` — the last change has landed everywhere. */
async function kept(page: Page, needle: RegExp) {
  await expect
    .poll(async () => page.evaluate((source) => new RegExp(source).test(window.localStorage.getItem("shaper-open-board") ?? ""), needle.source), {
      timeout: 30_000,
    })
    .toBe(true);
}

/** The box around the named slider rows, each row being the label line, the track and its hints. */
async function rowsClip(page: Page, names: string[]) {
  const box = await page.evaluate((wanted) => {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    const found: string[] = [];
    for (const node of Array.from(document.querySelectorAll('[data-bottom-card] input[type="range"]'))) {
      const input = node as HTMLInputElement;
      const name = input.getAttribute("aria-label") ?? "";
      if (!wanted.includes(name)) continue;
      let row: Element | null = null;
      for (let el: Element | null = input; el?.parentElement; el = el.parentElement) {
        const first = el.parentElement.firstElementChild;
        if (first && !first.contains(input) && (first.textContent ?? "").trim() !== "") {
          row = el.parentElement;
          break;
        }
      }
      if (!row) continue;
      const r = row.getBoundingClientRect();
      left = Math.min(left, r.left);
      top = Math.min(top, r.top);
      right = Math.max(right, r.right);
      bottom = Math.max(bottom, r.bottom);
      found.push(`${name}: ${(input.getAttribute("aria-valuetext") ?? "").replace(/\s+/g, " ").trim()}`);
    }
    return { left, top, right, bottom, found };
  }, names);
  console.log(`rows — ${box.found.join(" | ")}`);
  const pad = 10;
  return { x: box.left - pad, y: box.top - pad, width: box.right - box.left + 2 * pad, height: box.bottom - box.top + 2 * pad };
}

/** The section's own plate: its caption row, the drawing and the Section at row beneath, as far as they go. */
async function sectionClip(page: Page) {
  return page.evaluate(() => {
    const svg = document.querySelector("svg[data-bottom-section]")!;
    const head = svg.parentElement!.previousElementSibling ?? svg.parentElement!;
    const at = document.querySelector("[data-bottom-section-at]");
    const rects = [svg.getBoundingClientRect(), head.getBoundingClientRect(), ...(at ? [at.getBoundingClientRect()] : [])];
    const left = Math.min(...rects.map((r) => r.left));
    const top = Math.min(...rects.map((r) => r.top));
    const right = Math.max(...rects.map((r) => r.right));
    const bottom = Math.max(...rects.map((r) => r.bottom));
    return { x: left - 6, y: top - 6, width: right - left + 12, height: bottom - top + 12 };
  });
}

async function pickUnits(page: Page, system: "imperial" | "metric") {
  const dialog = await openAppSettings(page);
  const button = dialog.getByRole("group", { name: "Units" }).getByRole("button", { name: system === "metric" ? /^Metric/ : /^Imperial/ });
  await button.click();
  await expect(button).toHaveAttribute("aria-pressed", "true");
  await dialog.getByRole("button", { name: "Done" }).click();
  await expect(dialog).toBeHidden();
}

/** FINS' Aft/Forward position slider for the front pair, in the open Advanced fold, and the row it stands in. */
async function frontFinRow(page: Page): Promise<{ row: Locator; slider: Locator }> {
  const button = page.getByRole("button", { name: /^Advanced/ });
  await expect(button).toBeVisible();
  await expect.poll(() => button.evaluate((el) => Object.keys(el).some((key) => key.startsWith("__reactFiber")))).toBe(true);
  if ((await page.getByRole("button", { name: /Reset Advanced Settings/ }).count()) === 0) await button.click();
  await expect(page.getByRole("button", { name: /Reset Advanced Settings/ })).toBeVisible();
  const label = page.getByText(/^Aft\/Forward position — /).filter({ visible: true }).first();
  await expect(label).toBeVisible();
  const row = label.locator("xpath=..");
  return { row, slider: row.getByRole("slider") };
}

/** The box around FINS' icon row with a little of the drawing round it, for a close-up of the buttons. */
async function toolbarClip(page: Page, pad = { left: 70, top: 14, right: 14, bottom: 60 }) {
  const box = (await page.locator("[data-fin-plot] [data-viewer-toolbar]").first().boundingBox())!;
  const view = page.viewportSize()!;
  const x = Math.max(0, box.x - pad.left);
  const y = Math.max(0, box.y - pad.top);
  return { x, y, width: Math.min(view.width, box.x + box.width + pad.right) - x, height: box.y + box.height + pad.bottom - y };
}

/** What the Bottom Contours button is, in words and dots. */
async function toggleFacts(page: Page) {
  return page.locator("[data-fins-contour-toggle]").evaluate((el) => {
    const b = el as HTMLElement;
    const after = getComputedStyle(b, "::after");
    const grow = after.content === "none" || after.position !== "absolute" ? 0 : -parseFloat(after.left || "0");
    return {
      name: b.getAttribute("aria-label"),
      tip: b.getAttribute("title"),
      pressed: b.getAttribute("aria-pressed"),
      drawn: `${b.offsetWidth} x ${b.offsetHeight}`,
      touch: `${b.offsetWidth + 2 * grow} x ${b.offsetHeight + 2 * grow}`,
    };
  });
}

const TALL = { width: 1280, height: 2300 };
const WINDOW = { width: 1280, height: 800 };

test.describe("computer", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "desktop"));

  test("FINS over the bottom, and a fin move carrying the tail cut and the channels", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Shortboard");

    // 1. A flat board's FINS, as it has always been.
    await toFins(page);
    await calm(page, 1200);
    await page.screenshot({ path: shot("fins-flat-window") });
    await page.locator("[data-fin-plot]").first().screenshot({ path: shot("fins-flat-plot") });
    console.log(`flat: contour groups ${await page.locator("[data-fins-contour]").count()}`);

    // 2. A Spiral Vee and six channels.
    await toBottom(page);
    await pick(page, "Tail", "Spiral Vee");
    await pickFrom(page, "Channels", "6 channels");
    await kept(page, /"count":6/);
    await calm(page, 900);
    await page.screenshot({ path: shot("move-before-bottom-window") });
    await page.locator("[data-bottom-top-view-press]").screenshot({ path: shot("move-before-top") });
    await page.setViewportSize(TALL);
    await calm(page, 900);
    await page.screenshot({ path: shot("move-before-tail"), clip: await rowsClip(page, ["Tail Start", "Tail Deepest At", "Tail End"]) });
    await page.screenshot({
      path: shot("move-before-channels"),
      clip: await rowsClip(page, ["Channels Start", "Channels Stagger", "Channels Deepest At", "Channels End"]),
    });
    await page.setViewportSize(WINDOW);

    // FINS with a cut: the Bottom Contours button is there and off, and the drawing is a flat board's.
    await toFins(page);
    const toggle = page.locator("[data-fins-contour-toggle]");
    await expect(toggle).toHaveAttribute("aria-pressed", "false");
    await calm(page, 1200);
    await page.screenshot({ path: shot("fins-off-window") });
    await page.locator("[data-fin-plot]").first().screenshot({ path: shot("fins-off-plot") });
    await page.screenshot({ path: shot("fins-toggle-off"), clip: await toolbarClip(page) });
    console.log(`off: contour groups ${await page.locator("[data-fins-contour]").count()} · button ${JSON.stringify(await toggleFacts(page))}`);

    // Pressed: the bottom draws under the fins.
    await toggle.click();
    await expect(toggle).toHaveAttribute("aria-pressed", "true");
    await expect(page.locator("[data-fin-plot] [data-fins-contour]").first()).toBeVisible();
    await calm(page, 1200);
    await page.screenshot({ path: shot("fins-cut-window") });
    await page.locator("[data-fin-plot]").first().screenshot({ path: shot("fins-cut-plot") });
    await page.screenshot({ path: shot("fins-toggle-on"), clip: await toolbarClip(page) });
    console.log(`on: button ${JSON.stringify(await toggleFacts(page))}`);
    console.log(
      `cut: shade ${await page.locator("[data-fins-contour-shade] path").count()} · lines ${await page.locator("[data-fins-contour-line]").count()} · walls ${await page.locator('[data-fins-contour-pencil="wall"]').count()}`,
    );

    // 3. Import Designed Board unticked: nothing of the bottom is drawn.
    const box = page.getByRole("checkbox", { name: "Import Designed Board" });
    await box.click();
    await expect(box).toHaveAttribute("aria-checked", "false");
    await calm(page, 900);
    await page.screenshot({ path: shot("fins-unticked-window") });
    await page.locator("[data-fin-plot]").first().screenshot({ path: shot("fins-unticked-plot") });
    console.log(`unticked: contour groups ${await page.locator("[data-fins-contour]").count()} · contour buttons ${await toggle.count()}`);
    await box.click();
    await expect(box).toHaveAttribute("aria-checked", "true");

    // 4. The front fins moved toward the nose on FINS.
    const { row, slider } = await frontFinRow(page);
    await row.scrollIntoViewIfNeeded();
    await calm(page, 900);
    await page.screenshot({ path: shot("move-before-fins-window") });
    await row.screenshot({ path: shot("move-before-finrow") });
    console.log(`fins before: ${squash(await row.innerText())}`);
    await slider.focus();
    for (let i = 0; i < FIN_STEPS; i += 1) await page.keyboard.press("ArrowRight");
    await page.locator("body").click({ position: { x: 900, y: 790 } });
    await calm(page, 1200);
    await page.screenshot({ path: shot("move-after-fins-window") });
    await row.screenshot({ path: shot("move-after-finrow") });
    await page.locator("[data-fin-plot]").first().screenshot({ path: shot("move-after-plot") });
    console.log(`fins after: ${squash(await row.innerText())}`);

    // 5. BOTTOM afterwards: the tail cut's deepest station and the channels have gone with them.
    await toBottom(page);
    await calm(page, 1200);
    await page.screenshot({ path: shot("move-after-bottom-window") });
    await page.locator("[data-bottom-top-view-press]").screenshot({ path: shot("move-after-top") });
    await page.setViewportSize(TALL);
    await calm(page, 900);
    await page.screenshot({ path: shot("move-after-tail"), clip: await rowsClip(page, ["Tail Start", "Tail Deepest At", "Tail End"]) });
    await page.screenshot({
      path: shot("move-after-channels"),
      clip: await rowsClip(page, ["Channels Start", "Channels Stagger", "Channels Deepest At", "Channels End"]),
    });
  });

  test("BOTTOM in Metric beside Imperial", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Shortboard");
    await toBottom(page);
    await pick(page, "Center", "Deep Single Concave");
    await pick(page, "Tail", "Spiral Vee");
    await pickFrom(page, "Channels", "6 channels");
    await kept(page, /"count":6/);

    for (const key of ["imperial", "metric"] as const) {
      if (key === "metric") await pickUnits(page, "metric");
      await page.setViewportSize(WINDOW);
      await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
      await page.locator('[data-bottom-card="center"]').evaluate((el) => el.scrollIntoView({ block: "start" }));
      await calm(page, 1200);
      await page.screenshot({ path: shot(`${key}-window`) });
      await page.screenshot({ path: shot(`${key}-section`), clip: await sectionClip(page) });
      await page.locator("[data-bottom-top-view-press]").screenshot({ path: shot(`${key}-top`) });
      console.log(
        `${key}: caption "${squash(await page.locator("svg[data-bottom-section]").getAttribute("aria-label"))}" · ruler "${squash(
          await page.locator("[data-bottom-ruler]").first().textContent(),
        )}" · gauges "${squash((await page.locator("svg[data-bottom-section] [data-gauge] text").allTextContents()).join(" | "))}"`,
      );

      await page.setViewportSize(TALL);
      await calm(page, 900);
      const readout = page.locator('[role="group"]').filter({ has: page.locator("dt") }).first();
      await readout.screenshot({ path: shot(`${key}-inputs`) });
      await page.locator('[data-bottom-card="center"]').screenshot({ path: shot(`${key}-center`) });
      await page.locator('[data-bottom-card="tail"]').screenshot({ path: shot(`${key}-tail`) });
      console.log(`${key}: readout "${squash(await readout.innerText())}"`);
      console.log(`${key}: floors "${squash((await page.locator("[data-bottom-floor]").allInnerTexts()).join(" | "))}"`);

      await page.getByRole("tab", { name: "DATA", exact: true }).click();
      await expect(page.locator("[data-bottom-data]")).toBeVisible();
      await calm(page, 900);
      await page.locator("[data-bottom-data]").screenshot({ path: shot(`${key}-data`) });
      console.log(`${key}: litres "${squash(await page.locator("[data-bottom-litres]").innerText())}"`);
      await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
    }
  });
});

test.describe("upright phone", () => {
  test.beforeEach(({}, info) => test.skip(info.project.name !== "android"));

  test("FINS' Bottom Contours button on a phone held upright", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Shortboard");
    await toBottom(page);
    await pick(page, "Tail", "Spiral Vee");
    await pickFrom(page, "Channels", "6 channels");
    await kept(page, /"count":6/);

    await toFins(page);
    const toggle = page.locator("[data-fins-contour-toggle]");
    await expect(toggle).toHaveAttribute("aria-pressed", "false");
    await page.waitForTimeout(1200);
    await page.screenshot({ path: shot("fins-phone-off") });
    console.log(`phone off: view ${JSON.stringify(page.viewportSize())} · button ${JSON.stringify(await toggleFacts(page))}`);

    // For one close-up only, the invisible touch box round the button is drawn in as a dashed square.
    const mark = await page.addStyleTag({ content: "[data-fins-contour-toggle]::after { outline: 1px dashed #d1242f; }" });
    await page.waitForTimeout(300);
    await page.screenshot({ path: shot("fins-phone-touch"), clip: await toolbarClip(page, { left: 60, top: 14, right: 12, bottom: 44 }) });
    await mark.evaluate((el) => el.remove());

    await toggle.tap();
    await expect(toggle).toHaveAttribute("aria-pressed", "true");
    await expect(page.locator("[data-fin-plot] [data-fins-contour]").first()).toBeVisible();
    await page.waitForTimeout(1200);
    await page.screenshot({ path: shot("fins-phone-on") });
    console.log(`phone on: button ${JSON.stringify(await toggleFacts(page))}`);
  });

  test("BOTTOM in Metric beside Imperial, on a phone held upright", async ({ page }) => {
    await quiet(page);
    await openPreset(page, "Shortboard");
    await toBottom(page);
    await pick(page, "Center", "Deep Single Concave");
    await pick(page, "Tail", "Spiral Vee");
    await pickFrom(page, "Channels", "6 channels");
    await kept(page, /"count":6/);

    for (const key of ["imperial", "metric"] as const) {
      if (key === "metric") await pickUnits(page, "metric");
      await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
      await page.locator('[data-bottom-card="center"] [data-bottom-cut-echo]').scrollIntoViewIfNeeded();
      await page.waitForTimeout(900);
      await page.screenshot({ path: shot(`${key}-phone-viewer`) });
      await page.locator('[data-bottom-card="center"]').getByText(/^Depth — /).first().scrollIntoViewIfNeeded();
      await page.waitForTimeout(900);
      await page.screenshot({ path: shot(`${key}-phone-rows`) });
      await page.locator("[data-bottom-channels]").getByText(/^Depth — /).first().scrollIntoViewIfNeeded();
      await page.waitForTimeout(900);
      await page.screenshot({ path: shot(`${key}-phone-channels`) });
      await page.getByRole("tab", { name: "DATA", exact: true }).click();
      await expect(page.locator("[data-bottom-data]")).toBeVisible();
      await page.waitForTimeout(900);
      await page.screenshot({ path: shot(`${key}-phone-data`) });
      console.log(`${key} phone: view ${JSON.stringify(page.viewportSize())}`);
    }
  });
});

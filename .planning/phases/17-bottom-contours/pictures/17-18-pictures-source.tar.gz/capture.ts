// 17-18 regression capture: RAILS' three sections and the finished rail on the bottom, for every channel-free
// lifted board (four presets x hard/soft tails x the five vees and two bellies). Writes JSON to argv[2].
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <out.json>
import { writeFileSync } from "node:fs";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import {
  BOTTOM_SECTIONS,
  DEFAULT_BOTTOM,
  resolveBottom,
  startingCut,
  type BoardBottom,
  type BottomBoard,
  type BottomCutName,
  type BottomSectionKey,
} from "@/lib/geometry/bottom";
import {
  bottomRailLift,
  deriveEffectiveRails,
  designBottomBoard,
  designFinPlacement,
  designSideProfile,
  LIVE_DESIGN_RULES,
  railAnchorStations,
  railBandsOnTheBottom,
  railsOnTheBottom,
} from "@/lib/geometry/design";
import { finishedRail } from "@/lib/geometry/finished-rail";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom } from "@/lib/geometry/rail-bottom";

const CUTS: [BottomSectionKey, BottomCutName][] = [
  ["tail", "Panel Vee"],
  ["tail", "Spiral Vee"],
  ["tail", "Rolled Vee"],
  ["nose", "Reverse Vee Nose"],
  ["center", "Tri-Plane Hull Center"],
  ["nose", "Rolled Belly Entry"],
  ["center", "Continuous Belly / Rolled Mid"],
];
const out: Record<string, unknown> = {};
const all = phase16Boards();
for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  for (const tail of ["hard", "soft"]) {
    const fields = all.find((b) => b.label === `${id}|asis|${tail}`)!.fields;
    for (const [section, name] of CUTS) {
      const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
      const board: BottomBoard = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
      const bottom: BoardBottom = structuredClone(DEFAULT_BOTTOM);
      for (const s of BOTTOM_SECTIONS) if (s === section) bottom[s] = startingCut(s, name, board);
      const resolved = resolveBottom(bottom, board);
      const effectiveRails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
      const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
      const rails = railsOnTheBottom(effectiveRails, bottomRailLift(resolved, board), anchors);
      const bands = railBandsOnTheBottom(computeRailBands(rails), resolved, board, anchors);
      const entry: Record<string, unknown> = { rails, bands };
      for (const key of ["tail", "center", "nose"] as const) {
        const sec = bands[key];
        if (sec.bottom) entry[`finished-${key}`] = finishedRailOnBottom(finishedRail(sec, sec.bounds.xAxisMin), sec.bottom, sec.boardThickness);
      }
      out[`${id}|asis|${tail}|${name}`] = entry;
    }
  }
}
writeFileSync(process.argv[2], JSON.stringify(out));
console.log("wrote", Object.keys(out).length, "boards");

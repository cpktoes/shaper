// Probe: the Fish with a Rolled Vee and eight channels at Off Stringer 3" — walls at the tail anchor.
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { channelFoamOff, channelWallsAt, DEFAULT_BOTTOM, foamOff, resolveBottom, startingChannels, startingCut } from "@/lib/geometry/bottom";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, railAnchorStations } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { inchesToMm, mm, mmToInches } from "@/lib/geometry/units";

const id = process.argv[2] ?? "fish";
const tail = process.argv[3] ?? "hard";
const count = Number(process.argv[4] ?? 8) as 8;
const off = Number(process.argv[5] ?? 3);
const fields = phase16Boards().find((b) => b.label === `${id}|asis|${tail}`)!.fields;
const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
const board = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
const bottom = structuredClone(DEFAULT_BOTTOM);
bottom.tail = startingCut("tail", "Rolled Vee", board);
bottom.channels = { ...startingChannels(count, board, bottom.channels), offStringer: inchesToMm(off) };
console.log("default channels", JSON.stringify(DEFAULT_BOTTOM.channels));
const resolved = resolveBottom(bottom, board);
const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
for (const key of ["tail", "center", "nose"] as const) {
  const s = anchors[key];
  const rail = board.railAt(s);
  const walls = channelWallsAt(resolved.channels, board, resolved.wingRule, s);
  console.log(key, "station", mmToInches(s).toFixed(2), "rail", mmToInches(rail).toFixed(3), "lift", mmToInches(foamOff(resolved, board, s, rail)).toFixed(3));
  for (const w of walls) {
    const a = channelFoamOff(resolved.channels, board, resolved.wingRule, s, mm(w - 1e-6));
    const b = channelFoamOff(resolved.channels, board, resolved.wingRule, s, mm(w + 1e-6));
    console.log("  wall", mmToInches(w).toFixed(3), "in from rail", mmToInches(rail - w).toFixed(3), "step", mmToInches(a - b).toFixed(3));
  }
}

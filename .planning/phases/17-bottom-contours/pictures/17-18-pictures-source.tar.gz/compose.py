# 17-18: put the before and after pictures side by side, a caption line over each row, into one PNG.
# Usage: python3 -I compose.py <pics-out dir> <output png>
import sys
from PIL import Image, ImageDraw, ImageFont

src, out = sys.argv[1], sys.argv[2]
rows = [
    ("fish-8-off3", "Fish, Rolled Vee, eight channels at Off Stringer 3\" - RAILS tail section, Finished Rail on"),
    ("fish-8", "Fish, Rolled Vee, the starting eight channels"),
    ("longboard-6", "Longboard (rolled rail), Rolled Vee, six channels - the inner walls sit under the rail's curve"),
]

def font(size):
    for path in ["/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()

title_font = font(34)
caption_font = font(26)
label_font = font(24)
pad = 24
gap = 30
pairs = [(Image.open(f"{src}/before-{key}.png").convert("RGB"), Image.open(f"{src}/after-{key}.png").convert("RGB")) for key, _ in rows]
col_w = max(max(b.width, a.width) for b, a in pairs)
width = pad * 2 + col_w * 2 + gap
title_h = 60
caption_h = 40
label_h = 34
height = pad + title_h + sum(caption_h + label_h + max(b.height, a.height) + pad for b, a in pairs) + pad
sheet = Image.new("RGB", (width, height), "white")
draw = ImageDraw.Draw(sheet)
draw.text((pad, pad), "17-18 - channels on RAILS, cut straight up (G-17-6): before (left) and after (right)", fill="black", font=title_font)
y = pad + title_h
for (key, caption), (before, after) in zip(rows, pairs):
    draw.text((pad, y), caption, fill="black", font=caption_font)
    y += caption_h
    draw.text((pad, y), "Before", fill=(120, 120, 120), font=label_font)
    draw.text((pad + col_w + gap, y), "After", fill=(120, 120, 120), font=label_font)
    y += label_h
    sheet.paste(before, (pad, y))
    sheet.paste(after, (pad + col_w + gap, y))
    draw.rectangle([pad - 1, y - 1, pad + before.width, y + before.height], outline=(200, 200, 200))
    draw.rectangle([pad + col_w + gap - 1, y - 1, pad + col_w + gap + after.width, y + after.height], outline=(200, 200, 200))
    y += max(before.height, after.height) + pad
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

// 17-18's pictures: RAILS' tail section with the Finished Rail on, 1280 wide, Imperial, on three boards.
// PICS_PHASE=before|after names the files. Run with the scratch pics.config.ts (desktop project only).
import { expect, test, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/lib/models/toolbar-tip";
import { OPEN_BOARD_STORAGE_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/lib/models/open-board";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/lib/geometry/presets";
import { inchesToMm } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/lib/geometry/units";
import { goToScreen } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a55d2b537d86d241d/e2e/helpers/screens";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/pics-out";
const PHASE = process.env.PICS_PHASE ?? "before";

async function openPreset(page: Page, id: string) {
  await page.addInitScript((key) => window.sessionStorage.setItem(key, "true"), BANNER_DISMISSAL_KEY);
  await page.addInitScript((key) => window.localStorage.setItem(key, "true"), TOOLBAR_TIP_DISMISSAL_KEY);
  const preset = BOARD_PRESETS.find((p) => p.id === id)!;
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: preset.name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  await expect(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2_000 });
      await card.click({ timeout: 2_000 });
    }
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 5_000 });
  }).toPass({ timeout: 90_000 });
  await goToScreen(page, "BOTTOM");
}

async function pickFrom(page: Page, menu: string, option: string) {
  const trigger = page.getByRole("combobox", { name: menu, exact: true });
  await expect(async () => {
    await trigger.click();
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2_000 });
    await expect(trigger.locator("[data-slot=select-value]")).toHaveText(option, { timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
}

async function shootTail(page: Page, name: string) {
  await goToScreen(page, "RAILS");
  await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeAttached({ timeout: 60_000 });
  const button = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /finished rail$/ });
  await expect(button).toHaveAttribute("aria-pressed", "true");
  const plot = page.locator('[data-rail-plot-row="desktop"] [data-rail-section-plot="tail"]');
  await expect(plot.locator("[data-finished-rail]")).toHaveCount(1);
  await page.waitForTimeout(800);
  await plot.screenshot({ path: `${OUT}/${PHASE}-${name}.png` });
}

/** Writes a change to the kept board into a fresh page's storage before the app reads it, then opens RAILS there. */
async function reopenWith(page: Page, change: (design: Record<string, any>) => void): Promise<Page> {
  // The kept copy is written a moment after a change: wait until it holds the channels just picked.
  const read = () => page.evaluate((key) => window.localStorage.getItem(key), OPEN_BOARD_STORAGE_KEY);
  await expect.poll(async () => JSON.parse((await read()) ?? "null")?.snapshot?.design?.bottom?.channels?.count ?? 0, { timeout: 30_000 }).toBeGreaterThan(0);
  const kept = JSON.parse((await read())!);
  change(kept.snapshot.design);
  const context = page.context();
  await page.close();
  const fresh = await context.newPage();
  await fresh.addInitScript(
    ([key, value]) => {
      if (window.sessionStorage.getItem("pics-written")) return;
      window.localStorage.setItem(key, value);
      window.sessionStorage.setItem("pics-written", "1");
    },
    [OPEN_BOARD_STORAGE_KEY, JSON.stringify(kept)] as const,
  );
  await fresh.goto("/design/bottom");
  await expect(fresh.locator("[data-bottom-card]").first()).toBeAttached({ timeout: 60_000 });
  return fresh;
}

test.setTimeout(240_000);
// Drawn at twice the dots, so the walls read clearly in the founder's picture; the page is still 1280 wide.
test.use({ deviceScaleFactor: 2 });

test("fish, Rolled Vee, eight channels at Off Stringer 3 inches", async ({ page }) => {
  await openPreset(page, "fish");
  await pickFrom(page, "Tail Cut", "Rolled Vee");
  await pickFrom(page, "Channels", "8 channels");
  const fresh = await reopenWith(page, (d) => {
    d.bottom.channels.offStringer = inchesToMm(3);
  });
  await shootTail(fresh, "fish-8-off3");
});

test("fish, Rolled Vee, the starting eight", async ({ page }) => {
  await openPreset(page, "fish");
  await pickFrom(page, "Tail Cut", "Rolled Vee");
  await pickFrom(page, "Channels", "8 channels");
  await shootTail(page, "fish-8");
});

test("longboard, Rolled Vee, six channels", async ({ page }) => {
  await openPreset(page, "longboard");
  await pickFrom(page, "Tail Cut", "Rolled Vee");
  await pickFrom(page, "Channels", "6 channels");
  await shootTail(page, "longboard-6");
});

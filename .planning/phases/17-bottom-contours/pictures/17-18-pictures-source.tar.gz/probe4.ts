// Probe 4: the Longboard's underside with channels vs the rail on the vee alone — where they part.
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { DEFAULT_BOTTOM, resolveBottom, startingChannels, startingCut } from "@/lib/geometry/bottom";
import {
  bottomRailLift, deriveEffectiveRails, designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES,
  railAnchorStations, railBandsOnTheBottom, railsOnTheBottom,
} from "@/lib/geometry/design";
import { finishedRail, type FinishedRail } from "@/lib/geometry/finished-rail";
import type { Point2D } from "@/lib/geometry/board";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom, railDrawnBottom } from "@/lib/geometry/rail-bottom";
import { mm } from "@/lib/geometry/units";

const fields = phase16Boards().find((b) => b.label === "longboard|asis|soft")!.fields;
const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
const board = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
const bottom = structuredClone(DEFAULT_BOTTOM);
bottom.tail = startingCut("tail", "Rolled Vee", board);
bottom.channels = startingChannels(6, board, bottom.channels);
const resolved = resolveBottom(bottom, board);
const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
const eff = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const bands = railBandsOnTheBottom(computeRailBands(railsOnTheBottom(eff, bottomRailLift(resolved, board), anchors)), resolved, board, anchors);
const sec = bands.tail;
const b = sec.bottom!;
const T = sec.boardThickness;
const plain = finishedRail(sec, sec.bounds.xAxisMin);
const { channelCut, ...veeOnly } = b;
const onVee = finishedRailOnBottom(plain, veeOnly, T);
const drawn = finishedRailOnBottom(plain, b, T);
const ends = (r: FinishedRail): Point2D[] => [r.start, ...r.steps.map((s) => s.to)];
console.log("plain kinds", plain.steps.map((s) => s.kind[0]).join(""));
const pe = ends(plain);
plain.steps.forEach((s, i) => console.log(i, s.kind, pe[i].x.toFixed(2), pe[i].y.toFixed(2), "->", s.to.x.toFixed(2), s.to.y.toFixed(2)));
const de = ends(drawn);
let apex = 1;
for (let i = 1; i < de.length; i++) if (de[i].x > de[apex].x) apex = i;
console.log("drawn steps", drawn.steps.length, "apex", apex, de[apex]);
// reference by sampling onVee underside
const ve = ends(onVee);
let vapex = 1;
for (let i = 1; i < ve.length; i++) if (ve[i].x > ve[vapex].x) vapex = i;
const ref: Point2D[] = [ve[vapex]];
for (let i = vapex; i < onVee.steps.length; i++) {
  const a = ve[i];
  const st = onVee.steps[i];
  if (st.kind === "line") { ref.push(st.to); continue; }
  for (let k = 1; k <= 2000; k++) {
    const t = k / 2000, u = 1 - t;
    ref.push(st.kind === "quad"
      ? { x: mm(u*u*a.x + 2*u*t*st.control.x + t*t*st.to.x), y: mm(u*u*a.y + 2*u*t*st.control.y + t*t*st.to.y) }
      : { x: mm(u**3*a.x + 3*u*u*t*st.c1.x + 3*u*t*t*st.c2.x + t**3*st.to.x), y: mm(u**3*a.y + 3*u*u*t*st.c1.y + 3*u*t*t*st.c2.y + t**3*st.to.y) });
  }
}
const h = (x: number) => { for (let i = 1; i < ref.length; i++) { const a = ref[i-1], c = ref[i]; if (Math.min(a.x,c.x) <= x && x <= Math.max(a.x,c.x)) return c.x === a.x ? Math.max(a.y,c.y) : a.y + (c.y-a.y)*(x-a.x)/(c.x-a.x); } return NaN; };
let shown = 0;
for (let i = apex + 1; i < de.length && shown < 15; i++) {
  if (de[i].x === de[i-1].x) continue;
  const want = Math.max(h(de[i].x), Math.min(railDrawnBottom(b, mm(de[i].x)), T));
  if (Math.abs(de[i].y - want) > 1e-3) { console.log("i", i, "x", de[i].x.toFixed(4), "y", de[i].y.toFixed(4), "ref", h(de[i].x).toFixed(4), "floor", railDrawnBottom(b, mm(de[i].x)).toFixed(4)); shown++; }
}
void channelCut;

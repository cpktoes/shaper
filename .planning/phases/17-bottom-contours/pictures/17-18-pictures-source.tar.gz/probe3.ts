// Probe 3: wall pairs in channelCut (both sides of the stringer), and a flat tail whose outer channel runs out through the rail.
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { channelFoamOff, DEFAULT_BOTTOM, resolveBottom, startingChannels, startingCut } from "@/lib/geometry/bottom";
import {
  bottomRailLift, deriveEffectiveRails, designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES,
  railAnchorStations, railBandsOnTheBottom, railsOnTheBottom,
} from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { inchesToMm, mm, mmToInches } from "@/lib/geometry/units";

function setup(label: string, tailCut: string | null, count: 4 | 6 | 8, change: Record<string, number> = {}) {
  const fields = phase16Boards().find((b) => b.label === label)!.fields;
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const board = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
  const bottom = structuredClone(DEFAULT_BOTTOM);
  if (tailCut) bottom.tail = startingCut("tail", tailCut as "Rolled Vee", board);
  bottom.channels = { ...startingChannels(count, board, bottom.channels), ...change } as typeof bottom.channels;
  const resolved = resolveBottom(bottom, board);
  const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
  const eff = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const rails = railsOnTheBottom(eff, bottomRailLift(resolved, board), anchors);
  const bands = railBandsOnTheBottom(computeRailBands(rails), resolved, board, anchors);
  return { board, resolved, anchors, bands, bottom };
}

const fish = setup("fish|asis|hard", "Rolled Vee", 8);
const rail = fish.board.railAt(fish.anchors.tail);
const cut = fish.bands.tail.bottom!.channelCut!;
console.log("fish starting 8: rail", mmToInches(rail).toFixed(3));
for (let i = 1; i < cut.length; i++) if (cut[i].x === cut[i - 1].x) console.log("  pair at", mmToInches(-cut[i].x).toFixed(3), "in", mmToInches(cut[i - 1].y).toFixed(3), mmToInches(cut[i].y).toFixed(3), -cut[i].x > rail ? "FAR" : "");

for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  for (const tail of ["hard", "soft"]) {
    for (const n of [4, 6, 8] as const) {
      const base = setup(`${id}|asis|${tail}`, null, n);
      console.log(id, tail, n, 'fins', mmToInches(base.board.frontFins).toFixed(2), 'deepest', mmToInches(base.resolved.channels.deepest).toFixed(2), 'anchor', mmToInches(base.anchors.tail).toFixed(2), 'start', mmToInches(base.resolved.channels.start).toFixed(2), 'end', mmToInches(base.resolved.channels.end).toFixed(2));
      for (let k = 0; k <= 40; k++) {
        const s = setup(`${id}|asis|${tail}`, null, n, { offStringer: inchesToMm(3), deepestFromFins: base.bottom.channels.deepestFromFins + inchesToMm(k) });
        const r = s.board.railAt(s.anchors.tail);
        const atRail = channelFoamOff(s.resolved.channels, s.board, s.resolved.wingRule, s.anchors.tail, r);
        if (atRail > 0) {
          console.log(id, tail, n, "deepest +", k, "in: channel at the rail", mmToInches(atRail).toFixed(4));
          break;
        }
      }
    }
  }
}
void mm;

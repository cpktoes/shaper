// Probe 2: RAILS' tail section after the change — the walls on both lines, and how far the thick line sits from the floor.
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { channelFoamOff, channelWallsAt, DEFAULT_BOTTOM, resolveBottom, startingChannels, startingCut } from "@/lib/geometry/bottom";
import {
  bottomRailLift, deriveEffectiveRails, designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES,
  railAnchorStations, railBandsOnTheBottom, railsOnTheBottom,
} from "@/lib/geometry/design";
import { finishedRail } from "@/lib/geometry/finished-rail";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom, railBottomLine, railDrawnBottom } from "@/lib/geometry/rail-bottom";
import { inchesToMm, mm, mmToInches } from "@/lib/geometry/units";

const id = process.argv[2] ?? "fish";
const tail = process.argv[3] ?? "hard";
const count = Number(process.argv[4] ?? 8) as 8;
const off = process.argv[5] === undefined ? null : Number(process.argv[5]);
const fields = phase16Boards().find((b) => b.label === `${id}|asis|${tail}`)!.fields;
const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
const board = designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
const bottom = structuredClone(DEFAULT_BOTTOM);
bottom.tail = startingCut("tail", "Rolled Vee", board);
bottom.channels = startingChannels(count, board, bottom.channels);
if (off !== null) bottom.channels.offStringer = mm(inchesToMm(off));
const resolved = resolveBottom(bottom, board);
const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
const eff = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const rails = railsOnTheBottom(eff, bottomRailLift(resolved, board), anchors);
const bands = railBandsOnTheBottom(computeRailBands(rails), resolved, board, anchors);
const sec = bands.tail;
const b = sec.bottom!;
console.log("planed", mmToInches(eff.tail.boardThickness).toFixed(3), "RAILS", mmToInches(sec.boardThickness).toFixed(3), "lift", mmToInches(b.lift).toFixed(3));
console.log("channelCut points", b.channelCut?.length);
const rail = board.railAt(anchors.tail);
const walls = channelWallsAt(resolved.channels, board, resolved.wingRule, anchors.tail);
const fr = finishedRailOnBottom(finishedRail(sec, sec.bounds.xAxisMin), b, sec.boardThickness);
const ends = [fr.start, ...fr.steps.map((s) => s.to)];
const line = railBottomLine(b, sec.bounds.xAxisMin, mm(0));
console.log("xAxisMin", mmToInches(sec.bounds.xAxisMin).toFixed(3), "steps", fr.steps.length, "kinds", fr.steps.map((s) => s.kind[0]).join(""));
for (const w of walls) {
  const x = -(rail - w);
  const step = channelFoamOff(resolved.channels, board, resolved.wingRule, anchors.tail, mm(w - 1e-6)) - channelFoamOff(resolved.channels, board, resolved.wingRule, anchors.tail, mm(w + 1e-6));
  const thin = line.findIndex((p, i) => i > 0 && p.x === x && line[i - 1].x === x);
  const thick = ends.findIndex((p, i) => i > 0 && p.x === x && ends[i - 1].x === x);
  console.log(
    "wall", mmToInches(rail - w).toFixed(3), "in; step", mmToInches(step).toFixed(3),
    "thin pair", thin >= 0 ? mmToInches(line[thin - 1].y - line[thin].y).toFixed(3) : "none",
    "thick pair", thick >= 0 ? mmToInches(ends[thick].y - ends[thick - 1].y).toFixed(3) : "none",
    "thick inboard vs floor", thick >= 0 ? mmToInches(ends[thick].y - railDrawnBottom(b, mm(x))).toFixed(4) : "",
  );
}
let longest = 0;
for (let i = 1; i < ends.length; i++) if (fr.steps[i - 1].kind === "line" && ends[i].y < 5 ) longest = Math.max(longest, Math.abs(ends[i].x - ends[i - 1].x));
console.log("longest underside-ish line piece (in)", mmToInches(longest).toFixed(4));

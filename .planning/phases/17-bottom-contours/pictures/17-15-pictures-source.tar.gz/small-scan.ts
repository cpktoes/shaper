// Scratch: where on the stock boards does a depth that is there read as less than the tape's smallest step?
import { bottomDepthCell } from "@/components/bottom/bottom-copy";
import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import {
  BOTTOM_CUT_NAMES,
  BOTTOM_DATA_DEPTH_SHOWN,
  BOTTOM_SECTIONS,
  DEFAULT_BOTTOM,
  bottomDataRows,
  bottomLayoutMarks,
  pickCut,
  resolveBottom,
  startingChannels,
  type BoardBottom,
  type BottomCutName,
  type BottomSectionKey,
  type ChannelCount,
} from "@/lib/geometry/bottom";
import { bottomPrintLines } from "@/lib/geometry/bottom-print";
import { LIVE_DESIGN_RULES, designBottomBoard, designFinPlacement, designSideProfile } from "@/lib/geometry/design";
import { formatDimBare, formatMarkBare } from "@/lib/geometry/measure-display";
import { buildOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "@/lib/geometry/volume";
import type { DesignSnapshotFields } from "@/lib/models/design-snapshot";

type Names = Partial<Record<BottomSectionKey, BottomCutName>>;
const SETS: Record<string, { names: Names; count: ChannelCount | 0 }> = {
  single6: { names: { center: "Deep Single Concave" }, count: 6 },
  opening: { names: { nose: "Teardrop Nose Concave", center: "Continuous Belly / Rolled Mid", tail: "Rolled Vee" }, count: 0 },
  every8: { names: { nose: "Teardrop Nose Concave", center: "Early Double Concave", tail: "Spiral Vee" }, count: 8 },
};
// Every single cut alone too, so no cut name goes unlooked at.
for (const section of BOTTOM_SECTIONS) {
  for (const name of BOTTOM_CUT_NAMES[section]) SETS[`${section}:${name}`] = { names: { [section]: name }, count: 0 };
}
for (const count of [4, 6, 8] as const) SETS[`ch${count}`] = { names: {}, count };

let depthSmall = 0;
let depthZeroOld = 0;
let markZero = 0;
for (const preset of BOARD_PRESETS) {
  const base = presetDesignFields(preset);
  const fields: Omit<DesignSnapshotFields, "bottom"> = { ...base, volume: DEFAULT_VOLUME_SPEC, finsImportTemplate: true, railsImportFoilThickness: true, boardName: "", finSystem: "fcs2" };
  const board = designBottomBoard(fields.outline, buildOutline(fields.outline), designSideProfile(fields, LIVE_DESIGN_RULES), designFinPlacement(fields));
  for (const [setName, set] of Object.entries(SETS)) {
    let bottom: BoardBottom = DEFAULT_BOTTOM;
    for (const section of BOTTOM_SECTIONS) {
      const name = set.names[section];
      if (name) bottom = pickCut(bottom, section, name, board);
    }
    if (set.count > 0) bottom = { ...bottom, channels: startingChannels(set.count as ChannelCount, board, bottom.channels) };
    const resolved = resolveBottom(bottom, board);
    const rows = bottomDataRows(resolved, board);
    const marks = bottomLayoutMarks(resolved, board);
    for (const system of ["imperial", "metric"] as const) {
      const zero = formatMarkBare(0 as never, system);
      const found: string[] = [];
      rows.forEach((row) => {
        for (const [col, v] of [["deepest", row.deepest], ["railLift", row.railLift]] as const) {
          const old = v < BOTTOM_DATA_DEPTH_SHOWN ? "-" : formatMarkBare(v, system);
          const now = bottomDepthCell(v, system);
          if (old === zero) depthZeroOld++;
          if (now.startsWith("<")) {
            depthSmall++;
            found.push(`${row.label === "station" ? formatDimBare(row.station, system) : row.label} ${col} ${v.toFixed(3)}mm was ${old} now ${now}`);
          }
          if (now === zero) throw new Error(`a depth cell still reads ${zero}: ${preset.id} ${setName} ${system}`);
        }
      });
      const markZeros: string[] = [];
      marks.rows.forEach((markRow, r) => {
        markRow.cells.forEach((value, c) => {
          if (value !== null && formatMarkBare(value, system) === zero) {
            markZero++;
            markZeros.push(`row ${r} col ${c} ${value.toFixed(3)}mm`);
          }
        });
      });
      const lines = bottomPrintLines ? bottomPrintLines(resolved, board, system) : [];
      const lineZero = lines.filter((line: string) => /(^|[ ,])0("| mm)/.test(line));
      if (found.length || markZeros.length || lineZero.length) {
        console.log(`${preset.id} ${setName} ${system}`);
        for (const f of found) console.log(`   depth: ${f}`);
        for (const f of markZeros) console.log(`   MARK reads zero: ${f}`);
        for (const f of lineZero) console.log(`   LINE has a zero: ${f}`);
      }
    }
  }
}
console.log(`depth cells that used to read zero: ${depthZeroOld}; that now read less-than: ${depthSmall}; layout marks that read zero: ${markZero}`);

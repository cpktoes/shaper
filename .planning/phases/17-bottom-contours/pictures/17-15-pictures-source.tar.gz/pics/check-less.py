# Scratch: reads each printed tables sheet back from the PDF and counts the "less than the tape's smallest step" cells
# and any depth cell that still prints a bare nought. A row of the depths table reads
#   <station> <stringer left> <deepest cut> <rail lift>
# so the bare nought is looked for in the last two cells of every row between the DEPTHS and LAYOUT headings.
# usage: python3 check-less.py <split dir> <name> [<name> ...]     (name = e.g. lb8-letter-p4)
import re
import sys
from pypdf import PdfReader

split = sys.argv[1]
for name in sys.argv[2:]:
    text = PdfReader(f"{split}/{name}.pdf").pages[0].extract_text() or ""
    flat = re.sub(r"[ \t]+", " ", text)
    start = flat.find("DEPTHS")
    end = flat.find("LAYOUT")
    depths = flat[start:end] if start >= 0 and end > start else ""
    rows = [line.strip() for line in depths.splitlines() if line.strip()]
    imperial_less = depths.count('<1/16"')
    metric_less = len(re.findall(r"<1(?![/\d])", depths))
    bare = []
    for line in rows:
        cells = line.split(" ")
        # every cell after the station; a mixed fraction is two words and neither is a nought, so a whole-word nought is a cell
        tail = cells[1:]
        if any(cell in ('0"', "0") for cell in tail):
            bare.append(line)
    print(f"{name}: depths rows read {len(rows)}; <1/16\" x{imperial_less}; <1 (mm) x{metric_less}; rows with a bare nought in a depth cell: {len(bare)}")
    for line in rows:
        if "<" in line:
            print("   ", line)
    for line in bare:
        print("    BARE:", line)

// Scratch: a picture of DATA's depths table on the BOTTOM screen for one board, from the worktree's own server on 3315.
// usage: node data-shot.mjs <boards.json> <case> <out.png> [imperial|metric]
import { readFileSync } from "node:fs";
import { open, gotoBottom, retry } from "./lib.mjs";

const boards = JSON.parse(readFileSync(process.argv[2], "utf8"));
const name = process.argv[3];
const out = process.argv[4];
const metric = process.argv[5] === "metric";

const { browser, page } = await open({ storage: { "shaper-open-board": boards[name] }, metric, scale: 2 });
try {
  await gotoBottom(page);
  await retry(async () => {
    if ((await page.locator("[data-bottom-data]").count()) === 0) await page.getByRole("tab", { name: /^DATA/ }).first().click({ timeout: 3000 });
    await page.locator("[data-bottom-data]").waitFor({ timeout: 3000 });
  });
  const table = page.locator("[data-bottom-depths]");
  await table.waitFor({ timeout: 60000 });
  // The page draws the stock board for a moment before the kept one: wait for a less-than cell.
  await page.waitForFunction(
    () => [...document.querySelectorAll("[data-bottom-depths] tbody td")].some((td) => (td.textContent ?? "").trim().startsWith("<")),
    null,
    { timeout: 60000 },
  );
  await page.waitForTimeout(500);
  await table.scrollIntoViewIfNeeded();
  await table.screenshot({ path: out });
  const cells = await page
    .locator("[data-bottom-depths] tr")
    .evaluateAll((trs) => trs.map((tr) => [...tr.querySelectorAll("th,td")].map((c) => (c.textContent ?? "").trim()).join(" | ")));
  console.log("DATA depths rows:\n" + cells.join("\n"));
  console.log("shot", out);
} finally {
  await browser.close();
}

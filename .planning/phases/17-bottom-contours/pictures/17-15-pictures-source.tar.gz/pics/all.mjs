// Scratch: prints every order form plan 17-15's pictures need, each as a real PDF from the worktree's own server
// on 3315 (headless Chrome, backgrounds off, as the browser's print dialog would).
// usage: node all.mjs <boards.json> <out-dir>
import { mkdirSync, readFileSync } from "node:fs";
import { open, gotoSummary, printPdf, RAIL_INSTRUCTIONS } from "./lib.mjs";

const boards = JSON.parse(readFileSync(process.argv[2], "utf8"));
const out = process.argv[3];
mkdirSync(out, { recursive: true });

// name, board, paper, system, Rail Band Instructions ticked
const JOBS = [
  ["sb6-letter", "shortboard-single6", "Letter", "imperial", false],
  ["sb6-a4", "shortboard-single6", "A4", "imperial", false],
  ["sb6-metric", "shortboard-single6", "Letter", "metric", false],
  ["sb6-ticked", "shortboard-single6", "Letter", "imperial", true],
  ["lbo-letter", "longboard-opening", "Letter", "imperial", false],
  ["sb8-letter", "shortboard-every8", "Letter", "imperial", false],
  ["lb8-letter", "longboard-every8", "Letter", "imperial", false],
  ["lb8-a4-metric", "longboard-every8", "A4", "metric", false],
  ["fish8-letter", "fish-every8", "Letter", "imperial", false],
];

for (const [name, board, format, system, ticked] of JOBS) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    const { browser, page } = await open({
      storage: { "shaper-open-board": boards[board], ...(ticked ? RAIL_INSTRUCTIONS : {}) },
      metric: system === "metric",
    });
    try {
      await gotoSummary(page);
      await page.locator("[data-bottom-sheet]").waitFor({ timeout: 90000 });
      await page.waitForTimeout(600);
      await printPdf(page, `${out}/${name}.pdf`, format);
      console.log("printed", name);
      break;
    } catch (error) {
      console.log(`retry ${name} (${attempt}): ${String(error).slice(0, 160)}`);
    } finally {
      await browser.close();
    }
  }
}
console.log("ALL PRINTED");

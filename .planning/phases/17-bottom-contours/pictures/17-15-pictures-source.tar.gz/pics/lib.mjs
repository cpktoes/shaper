// Scratch helpers for plan 17-15's pictures and print read-backs. Everything here drives the worktree's own
// test server on port 3315 and prints real pages with headless Chrome — nothing is a mock-up.
import { chromium, devices } from "@playwright/test";

export const BASE = "http://localhost:3315";

/** A computer-shaped page (1280 x 800). `storage` is written before every load. */
export async function open({ storage = {}, metric = false, scale = 1 } = {}) {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    ...devices["Desktop Chrome"],
    viewport: { width: 1280, height: 800 },
    deviceScaleFactor: scale,
    baseURL: BASE,
  });
  if (metric) await context.addCookies([{ name: "shaper-units", value: "metric", domain: "localhost", path: "/" }]);
  const page = await context.newPage();
  await page.addInitScript(
    ({ storage, metric }) => {
      window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
      if (metric) window.localStorage.setItem("shaper-units", "metric");
      for (const [key, value] of Object.entries(storage)) window.localStorage.setItem(key, value);
    },
    { storage, metric },
  );
  return { browser, context, page };
}

export const RAIL_INSTRUCTIONS = { "shaper-print-rail-instructions": "true" };

export async function retry(fn, tries = 20) {
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === tries - 1) throw error;
    }
  }
}

/** Waits until React owns the page (a hydrated element carries a fiber key). */
export async function hydrated(page, selector) {
  await page.waitForFunction(
    (sel) => {
      const el = document.querySelector(sel);
      return !!el && Object.keys(el).some((k) => k.startsWith("__reactFiber"));
    },
    selector,
    { timeout: 120000 },
  );
}

export async function gotoSummary(page) {
  await page.goto("/design/summary", { timeout: 180000 });
  await page.locator("[data-order-form-sheet]").first().waitFor({ timeout: 120000 });
  await hydrated(page, "[data-order-form-root]");
  await page.waitForTimeout(800);
}

export async function gotoBottom(page) {
  await page.goto("/design/bottom", { timeout: 180000 });
  await hydrated(page, '[role="tab"]');
  await page.locator("[data-bottom-top-view]").waitFor({ timeout: 60000 });
}

export async function pickFrom(page, selectName, option) {
  const trigger = page.getByRole("combobox", { name: selectName, exact: true });
  await retry(async () => {
    await trigger.scrollIntoViewIfNeeded({ timeout: 3000 });
    await trigger.click({ timeout: 3000 });
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 3000 });
  });
  await page.waitForTimeout(300);
}

/** Prints the page as the browser's print dialog would, with no background colours. */
export async function printPdf(page, path, format) {
  await page.pdf({ path, format, printBackground: false, margin: { top: "8mm", bottom: "8mm", left: "8mm", right: "8mm" } });
}

// Scratch: the close-up for the founder's ruling of 2026-11-10 — a depth that is there never prints as a nought. The
// paper crops are cut from the real printed PDFs (rendered large by qlmanage); the DATA pictures are the BOTTOM
// screen's own table. usage: node small-depth.mjs <dir with the pngs> <out.png> <regions.json>
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { chromium } from "@playwright/test";

const dir = process.argv[2];
const out = process.argv[3];
const regions = JSON.parse(readFileSync(process.argv[4], "utf8"));
const src = (name) => `file://${join(dir, name)}`;
/** A crop of a page: the region x..x+w, y..y+h of the image (as shares of its size), shown `width` wide. */
const crop = (name, width, region, ratio, caption) => {
  const full = width / region.w;
  const height = full * ratio * region.h;
  return (
    `<figure style="width:${width}px"><div class="crop" style="width:${width}px;height:${height}px">` +
    `<img src="${src(name)}" style="width:${full}px;margin-left:${-region.x * full}px;margin-top:${-region.y * full * ratio}px"></div>` +
    `<figcaption>${caption}</figcaption></figure>`
  );
};
const shot = (name, width, caption) =>
  `<figure style="width:${width}px"><img src="${src(name)}" style="width:${width}px"><figcaption>${caption}</figcaption></figure>`;

const html = `<!doctype html><meta charset="utf8"><style>
  body { margin: 0; padding: 30px 34px 34px; width: 1800px; box-sizing: border-box; background: #e9e6df; color: #1c1b19;
    font: 21px/1.35 -apple-system, "Helvetica Neue", Helvetica, Arial, sans-serif; }
  h1 { font-size: 34px; margin: 0 0 6px; } p { margin: 0 0 16px; max-width: 1700px; color: #4a4740; }
  .row { display: flex; gap: 22px; align-items: flex-start; margin-bottom: 26px; }
  figure { margin: 0; } img { display: block; background: #fff; }
  figure > img, .crop { box-shadow: 0 0 0 1px #b9b4a8, 0 2px 8px rgba(0,0,0,.18); background: #fff; }
  .crop { overflow: hidden; }
  figcaption { font-size: 20px; padding-top: 8px; color: #2c2a26; }
</style>
<h1>Plan 17-15 — a depth that is there never reads as a nought</h1>
<p>${regions.note}</p>
<div class="row">
  ${crop("lb8-letter-p4.pdf.png", 1000, regions.letter, regions.letterRatio, "On paper — the order form's Bottom Contours · Tables sheet, US Letter (a real print)")}
  ${shot("data-depths-imperial.png", 710, "On screen — BOTTOM's DATA tab, the same board (its last row, Nose tip, is scrolled out of the picture)")}
</div>
<div class="row">
  ${crop("lb8-a4-metric-p4.pdf.png", 1000, regions.a4, regions.a4Ratio, "On paper in Metric — the same sheet on A4")}
  ${shot("data-depths-metric.png", 710, "On screen in Metric")}
</div>`;

const htmlPath = join(dir, "small-depth.html");
writeFileSync(htmlPath, html);
const browser = await chromium.launch();
try {
  const tab = await browser.newPage({ viewport: { width: 1800, height: 900 }, deviceScaleFactor: 1 });
  await tab.goto(`file://${htmlPath}`);
  await tab.waitForLoadState("load");
  await tab.screenshot({ path: out, fullPage: true });
  const size = await tab.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.scrollHeight]);
  console.log("composed", out, size.join(" x "));
} finally {
  await browser.close();
}

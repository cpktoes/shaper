# Scratch: compares two flat-capture folders — markup, boxes and the printed pages' words and page counts.
# Run: python3 flat-compare.py <before> <after>
import hashlib
import sys
from pypdf import PdfReader

a, b = sys.argv[1], sys.argv[2]
ok = True


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()[:16]


for case in ("unticked", "ticked"):
    for kind in ("html", "boxes.json"):
        x, y = sha(f"{a}/{case}.{kind}"), sha(f"{b}/{case}.{kind}")
        same = x == y
        ok = ok and same
        print(f"{case}.{kind}: {'IDENTICAL' if same else 'DIFFERENT'} ({x} / {y})")
    for paper in ("letter", "a4"):
        ra, rb = PdfReader(f"{a}/{case}-{paper}.pdf"), PdfReader(f"{b}/{case}-{paper}.pdf")
        ta = [p.extract_text() for p in ra.pages]
        tb = [p.extract_text() for p in rb.pages]
        boxes_a = [tuple(round(float(v), 2) for v in p.mediabox) for p in ra.pages]
        boxes_b = [tuple(round(float(v), 2) for v in p.mediabox) for p in rb.pages]
        same = ta == tb and boxes_a == boxes_b
        ok = ok and same
        marks = [line for t in ta for line in t.splitlines() if "Page " in line and " of " in line]
        print(f"{case}-{paper}.pdf: {len(ra.pages)} pages / {len(rb.pages)} pages; words {'IDENTICAL' if ta == tb else 'DIFFERENT'}; paper {boxes_a[0]}; marks {marks}")

print("RESULT:", "IDENTICAL" if ok else "DIFFERENT")
sys.exit(0 if ok else 1)

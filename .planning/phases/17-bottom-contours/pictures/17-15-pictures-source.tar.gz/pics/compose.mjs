// Scratch: lays plan 17-15's printed pages out as one captioned picture. Every page in it is a real PDF printed from
// the worktree's own server (or built by the Overview Sheet's own builder) and rendered with qlmanage — no screenshots
// of the screen. usage: node compose.mjs <png-dir> <out.png> [page-alone.png]
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { chromium } from "@playwright/test";

const dir = process.argv[2];
const out = process.argv[3];
const alone = process.argv[4];
const src = (name) => `file://${join(dir, name)}`;

const page = (name, width, caption) =>
  `<figure style="width:${width}px"><img src="${src(name)}" style="width:${width}px"><figcaption>${caption}</figcaption></figure>`;
/** A crop of a page: the region x..x+w, y..y+h of the image (as shares of its size), shown `width` wide. */
const crop = (name, width, region, ratio, caption) => {
  const full = width / region.w;
  const height = full * ratio * region.h;
  return (
    `<figure style="width:${width}px"><div class="crop" style="width:${width}px;height:${height}px">` +
    `<img src="${src(name)}" style="width:${full}px;margin-left:${-region.x * full}px;margin-top:${-region.y * full * ratio}px"></div>` +
    `<figcaption>${caption}</figcaption></figure>`
  );
};
const row = (title, note, figures) => `<section><h2>${title}</h2><p class="note">${note}</p><div class="row">${figures.join("")}</div></section>`;

const LETTER = 11 / 8.5;
const specColumn = { x: 0.03, y: 0.1, w: 0.31, h: 0.52 };

const html = `<!doctype html><meta charset="utf8"><style>
  body { margin: 0; padding: 36px 40px 40px; width: 2400px; box-sizing: border-box; background: #e9e6df; color: #1c1b19;
    font: 22px/1.35 -apple-system, "Helvetica Neue", Helvetica, Arial, sans-serif; }
  h1 { font-size: 40px; margin: 0 0 6px; } h2 { font-size: 28px; margin: 34px 0 4px; }
  p { margin: 0 0 12px; max-width: 2200px; } .note { color: #4a4740; }
  .row { display: flex; gap: 20px; align-items: flex-start; }
  figure { margin: 0; } img { display: block; background: #fff; }
  figure > img, .crop { box-shadow: 0 0 0 1px #b9b4a8, 0 2px 8px rgba(0,0,0,.18); background: #fff; }
  .crop { overflow: hidden; }
  figcaption { font-size: 21px; padding-top: 8px; color: #2c2a26; }
</style>
<h1>Plan 17-15 — the printed bottom</h1>
<p>Every page below is a real print: the order form printed to PDF by headless Chrome from this plan's own build (backgrounds off, as a
printer does), and the Overview Sheet built by the app's own PDF builder. Nothing here is a picture of the screen.</p>
${row(
  "(a) (b) The BOTTOM CONTOURS page — Shortboard, Deep Single Concave and 6 channels",
  "The order form's new third page, on both papers. Top to bottom: the bottom from above with its marks, a section at each cut's deepest station with its gauge readings, the two tables, and how to shape each cut.",
  [page("sb6-letter-p3.pdf.png", 1150, "(a) US Letter — page 3 of 3"), page("sb6-a4-p3.pdf.png", 1150, "(b) A4 — the same page, same board")],
)}
${row(
  "(c) The Longboard with its three opening cuts — the tables take a sheet of their own",
  "Three sections and nineteen rows of numbers do not fit one sheet, so the two tables print whole on the next one, with the notes on reading them. The same Shortboard page in Metric is beside them.",
  [
    page("lbo-letter-p3.pdf.png", 765, "Longboard — page 3 of 4: the picture, three sections, how to shape"),
    page("lbo-letter-p4.pdf.png", 765, "Longboard — page 4 of 4: both tables, every row"),
    page("sb6-metric-p3.pdf.png", 765, "Shortboard, Metric — marks in mm, stations in cm"),
  ],
)}
${row(
  "(e) The worst case — a cut in every section and 8 channels",
  "Four sections two across, four notes; the tables (eleven columns of marks) move to their own sheet. On the Longboard, nineteen rows under eleven columns leave room for one of the three notes.",
  [
    page("sb8-letter-p3.pdf.png", 765, "Shortboard, every cut + 8 channels — page 3 of 4"),
    page("sb8-letter-p4.pdf.png", 765, "Shortboard — page 4 of 4: the tables"),
    page("lb8-letter-p4.pdf.png", 765, "Longboard, every cut + 8 channels — its tables' sheet"),
  ],
)}
${row(
  "(d) The whole order form with the Rail Band Instructions ticked — four sheets, PAGE 1 OF 4 … PAGE 4 OF 4",
  "Shortboard, Deep Single Concave and 6 channels. The new page falls third, after the double-sided pair; the Rail Band Instructions stay last.",
  [1, 2, 3, 4].map((n) => page(`sb6-ticked-p${n}.pdf.png`, 570, `Page ${n} of 4`)),
)}
${row(
  "(f) The Overview Sheet — the Bottom: lines",
  "One line of words per cut under the template's own figures, in the system the shaper picked; the drawing beside them is untouched. A flat board's sheet has no Bottom: head at all.",
  [
    crop("shortboard-deep-single-6ch-imperial-letter.pdf.png", 760, specColumn, LETTER, "Imperial — the spec column, close up"),
    crop("shortboard-deep-single-6ch-metric-letter.pdf.png", 760, specColumn, LETTER, "Metric — the same board"),
    page("shortboard-deep-single-6ch-imperial-letter.pdf.png", 760, "The whole Overview Sheet (Imperial)"),
  ],
)}
${row(
  "(g) A flat Shortboard's order form, before and after — nothing moved",
  "Printed before this plan's first edit and again after its last. The two prints were compared word for word and box for box (see the SUMMARY): identical.",
  [
    page("before-unticked-letter-p1.pdf.png", 570, "Before — page 1 of 2"),
    page("before-unticked-letter-p2.pdf.png", 570, "Before — page 2 of 2"),
    page("after-unticked-letter-p1.pdf.png", 570, "After — page 1 of 2"),
    page("after-unticked-letter-p2.pdf.png", 570, "After — page 2 of 2"),
  ],
)}`;

const htmlPath = join(dir, "compose.html");
writeFileSync(htmlPath, html);
const browser = await chromium.launch();
try {
  const tab = await browser.newPage({ viewport: { width: 2400, height: 1200 }, deviceScaleFactor: 1 });
  await tab.goto(`file://${htmlPath}`);
  await tab.waitForLoadState("load");
  await tab.screenshot({ path: out, fullPage: true });
  const size = await tab.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.scrollHeight]);
  console.log("composed", out, size.join(" x "));
  if (alone) {
    const one = await browser.newPage({ viewport: { width: 1700, height: 1200 }, deviceScaleFactor: 1 });
    writeFileSync(join(dir, "alone.html"), `<body style="margin:0;background:#fff"><img src="${src("sb6-letter-p3-big.pdf.png")}" style="display:block;width:1700px"></body>`);
    await one.goto(`file://${join(dir, "alone.html")}`);
    await one.waitForLoadState("load");
    await one.screenshot({ path: alone, fullPage: true });
    console.log("page alone", alone);
  }
} finally {
  await browser.close();
}

import { readFileSync } from "node:fs";
import { inflateSync } from "node:zlib";
const raw = readFileSync(process.argv[2]).toString("latin1");
let from = 0; let n = 0;
while (true) {
  let idx = raw.indexOf("stream", from);
  while (idx !== -1 && raw[idx - 1] === "d") idx = raw.indexOf("stream", idx + 1);
  if (idx === -1) break;
  let start = idx + 6; if (raw[start] === "\r") start++; if (raw[start] === "\n") start++;
  const end = raw.indexOf("endstream", start); if (end === -1) break; from = end + 9;
  let text; try { text = inflateSync(Buffer.from(raw.slice(start, end), "latin1")).toString("latin1"); } catch { continue; }
  n++;
  const cms = [...text.matchAll(/(-?[\d.]+)\s+-?[\d.]+\s+-?[\d.]+\s+-?[\d.]+\s+-?[\d.]+\s+-?[\d.]+\s+cm/g)];
  const res = [...text.matchAll(/-?[\d.]+\s+-?[\d.]+\s+(-?[\d.]+)\s+(-?[\d.]+)\s+re/g)];
  const head = raw.slice(Math.max(0, idx - 160), idx).replace(/\s+/g, " ").slice(-120);
  console.log(n, "len", text.length, "cm", cms.length, cms.slice(0, 2).map((m) => m[1]).join("x"), "re", res.length, "|", head, "|", JSON.stringify(text.slice(0, 90)));
}

# Scratch: reads a printed order form back with pypdf — page count, each page's size and page mark, whether the
# BOTTOM CONTOURS page's parts are there — and splits it into one-page PDFs for rendering.
# usage: python3 readback.py <form.pdf> [split-dir]
import os
import re
import sys
from pypdf import PdfReader, PdfWriter

path = sys.argv[1]
reader = PdfReader(path)
print(f"{os.path.basename(path)}: {len(reader.pages)} pages")
for i, page in enumerate(reader.pages):
    text = page.extract_text() or ""
    flat = re.sub(r"\s+", " ", text)
    mark = re.search(r"Page\s+\d+\s+of\s+\d+", flat, re.I)
    box = page.mediabox
    parts = []
    for word, name in (
        ("BOTTOM CONTOURS", "caption"),
        ("HEIGHT", "section"),
        ("At the deepest", "readings"),
        ("DEPTHS UNDER A STRAIGHTEDGE", "depths table"),
        ("LAYOUT MARKS", "marks table"),
        ("HOW TO SHAPE", "notes"),
    ):
        if word.lower() in flat.lower():
            parts.append(name)
    print(f"  page {i + 1}: {float(box.width):.1f} x {float(box.height):.1f} pt; {len(flat)} chars; mark: {mark.group(0) if mark else None}; parts: {', '.join(parts) or '-'}")
    if len(sys.argv) > 2:
        os.makedirs(sys.argv[2], exist_ok=True)
        writer = PdfWriter()
        writer.add_page(page)
        stem = os.path.splitext(os.path.basename(path))[0]
        with open(os.path.join(sys.argv[2], f"{stem}-p{i + 1}.pdf"), "wb") as handle:
            writer.write(handle)

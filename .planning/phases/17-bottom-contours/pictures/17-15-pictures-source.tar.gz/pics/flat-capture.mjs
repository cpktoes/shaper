// Scratch: the flat Shortboard's order form, captured the same way before and after plan 17-15's edits, so the
// two can be compared word for word and box for box. Run: node flat-capture.mjs <folder>
//
// For each of the two flat cases (Rail Band Instructions unticked, ticked) it writes:
//   <case>.html        the rendered markup of the whole order form
//   <case>.boxes.json  every element's box inside every sheet, in PRINT media (where the sheets are paper-sized)
//   <case>-letter.pdf / <case>-a4.pdf  the form printed on each paper
import { mkdirSync, writeFileSync } from "node:fs";
import { open, gotoSummary, printPdf, RAIL_INSTRUCTIONS } from "./lib.mjs";

const out = process.argv[2];
if (!out) throw new Error("usage: flat-capture.mjs <folder>");
mkdirSync(out, { recursive: true });

for (const [name, storage] of [
  ["unticked", {}],
  ["ticked", RAIL_INSTRUCTIONS],
]) {
  const { browser, page } = await open({ storage });
  await gotoSummary(page);
  const html = await page.locator("[data-order-form-root]").evaluate((el) => el.outerHTML);
  writeFileSync(`${out}/${name}.html`, html);
  await page.emulateMedia({ media: "print" });
  const boxes = await page.locator("[data-order-form-sheet]").evaluateAll((sheets) =>
    sheets.map((sheet) => ({
      scrollHeight: sheet.scrollHeight,
      clientHeight: sheet.clientHeight,
      boxes: [sheet, ...sheet.querySelectorAll("*")].map((el) => {
        const r = el.getBoundingClientRect();
        const round = (n) => Math.round(n * 100) / 100;
        return [el.tagName, round(r.x), round(r.y), round(r.width), round(r.height)];
      }),
    })),
  );
  writeFileSync(`${out}/${name}.boxes.json`, JSON.stringify(boxes));
  await printPdf(page, `${out}/${name}-letter.pdf`, "Letter");
  await printPdf(page, `${out}/${name}-a4.pdf`, "A4");
  await page.emulateMedia({ media: "screen" });
  console.log(`${name}: ${boxes.length} sheets; markup ${html.length} chars; boxes ${boxes.map((b) => b.boxes.length).join(" / ")}; clip ${boxes.map((b) => b.scrollHeight - b.clientHeight).join(" / ")}`);
  await browser.close();
}

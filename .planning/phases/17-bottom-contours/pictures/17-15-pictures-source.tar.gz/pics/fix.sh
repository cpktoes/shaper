#!/bin/bash
# Scratch: after the founder's look (a depth that is there never prints as 0") — re-prints only the order forms whose
# tables change, reads each back with pypdf, splits it into pages and renders the pages. Then takes the flat board's
# capture again and compares it with the one taken before the plan's first edit.
# usage: bash fix.sh <scratch w15 dir>   (run from the worktree root; drives the worktree's own server on 3315)
S="$1"
OUT="$S/final4"
mkdir -p "$OUT/split" "$OUT/png" "$OUT/big"
job() {
  # name case format system ticked
  for attempt in 1 2 3; do
    if node "$S/pics/print.mjs" "$S/boards.json" "$2" "$OUT/$1.pdf" "$3" "$4" "$5"; then break; fi
    echo "retry $1 ($attempt)"
  done
  python3 "$S/pics/readback.py" "$OUT/$1.pdf" "$OUT/split"
}
job lbo-letter longboard-opening Letter imperial no
job sb8-letter shortboard-every8 Letter imperial no
job lb8-letter longboard-every8 Letter imperial no
job lb8-a4-metric longboard-every8 A4 metric no
job fish8-letter fish-every8 Letter imperial no
job sb6-letter shortboard-single6 Letter imperial no
job sb6-metric shortboard-single6 Letter metric no
for f in "$OUT"/split/*.pdf; do qlmanage -t -s 1600 -o "$OUT/png" "$f" > /dev/null 2>&1; done
for f in lb8-letter-p4 lb8-a4-metric-p4; do qlmanage -t -s 4000 -o "$OUT/big" "$OUT/split/$f.pdf" > /dev/null 2>&1; done
node "$S/pics/flat-capture.mjs" "$S/flat-after4"
python3 "$S/pics/flat-compare.py" "$S/flat-before" "$S/flat-after4"
echo "FIX DONE"

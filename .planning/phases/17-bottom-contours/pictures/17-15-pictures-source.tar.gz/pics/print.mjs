// Scratch: prints the order form for one board as a real PDF, as the browser's print dialog would.
// usage: node print.mjs <boards.json> <case> <out.pdf> [Letter|A4] [imperial|metric] [ticked]
import { readFileSync } from "node:fs";
import { open, gotoSummary, printPdf, RAIL_INSTRUCTIONS } from "./lib.mjs";

const boards = JSON.parse(readFileSync(process.argv[2], "utf8"));
const name = process.argv[3];
const out = process.argv[4];
const format = process.argv[5] ?? "Letter";
const metric = process.argv[6] === "metric";
const ticked = process.argv[7] === "ticked";

const { browser, page } = await open({
  storage: { "shaper-open-board": boards[name], ...(ticked ? RAIL_INSTRUCTIONS : {}) },
  metric,
});
try {
  await gotoSummary(page);
  if (!name.endsWith("-flat")) await page.locator("[data-bottom-sheet]").waitFor({ timeout: 60000 });
  await page.waitForTimeout(600);
  await printPdf(page, out, format);
  console.log("printed", out);
} finally {
  await browser.close();
}

import re
p = '/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/lib/geometry/bottom.test.ts'
s = open(p).read()

# The two existing assertions now read the vee or belly alone (they pass either way on boards without channels).
a1 = '''      expect(r.railLift).toBe(foamOff(resolved, board, r.station, W));
      expect(r.deepest).toBe(deepestCutAt(resolved, board, r.station));'''
b1 = '''      expect(r.railLift).toBe(sectionsFoamOff(resolved, board, r.station, W));
      expect(r.deepest).toBe(deepestCutAt(resolved, board, r.station));'''
a2 = '''      expect(r.railLift).toBe(foamOff(vee, fish, r.station, fish.railAt(r.station)));'''
b2 = '''      expect(r.railLift).toBe(sectionsFoamOff(vee, fish, r.station, fish.railAt(r.station)));'''
for a, b in [(a1, b1), (a2, b2)]:
    assert s.count(a) == 1, a[:50]
    s = s.replace(a, b)

anchor = 'describe("DATA: the layout marks off the stringer (D-16) — golden", () => {'
assert s.count(anchor) == 1
block = r'''// The founder's answer of 2026-11-11 at his look at 17-18, "Match RAILS": DATA's Rail lift is the vee's or belly's
// lift at the rail — the figure RAILS thins the rail by (`bottomRailLift`). Channels are cut after the rail is shaped
// (D-05), so a channel never counts there, even one that runs out through the rail (D-43). Every other figure stays the
// one number. Every expected figure is the app's own (Rule 1).
describe("DATA's Rail lift counts the vee or belly alone, as RAILS does (the founder, 2026-11-11: \"Match RAILS\")", () => {
  const channelBoards = phase17ChannelBoards();
  /** A channelled board's bottom, resolved, with the same board's bottom with the channels set to None. */
  const setupOf = (fields: DesignSummaryFields) => {
    const board = bottomBoardOf(fields);
    const bottom = fields.bottom!;
    const resolved = resolveBottom(bottom, board);
    const none = resolveBottom({ ...bottom, channels: DEFAULT_BOTTOM.channels }, board);
    return { board, resolved, none };
  };

  it.each(["fish|hard|rolled-vee|6", "shortboard|hard|rolled-vee|6"])("%s: every row's Rail lift is RAILS' own rail lift, and the same board's with the channels set to None", (label) => {
    const { board, resolved, none } = setupOf(channelBoards.find((b) => b.label === label)!.fields);
    const rows = bottomDataRows(resolved, board);
    const noneRows = bottomDataRows(none, board);
    const railsLift = bottomRailLift(resolved, board);
    let lifted = 0;
    rows.forEach((r, k) => {
      expect(Object.is(r.railLift, railsLift(r.station))).toBe(true);
      expect(Object.is(r.railLift, noneRows[k].railLift)).toBe(true);
      if (r.railLift > 0) lifted++;
    });
    expect(lifted, "the vee lifts the rail somewhere (non-vacuity)").toBeGreaterThan(0);
  });

  const flatLabels = channelBoards.map((b) => b.label).filter((l) => /^(shortboard|fish|longboard)\|(hard|soft)\|flat\|[468]$/.test(l));

  it("the set: the Shortboard, the Fish and the Longboard, Hard Edge and soft, with a flat tail and four, six and eight channels", () => {
    expect(flatLabels).toHaveLength(18);
  });

  it.each(flatLabels)("%s: a channel that runs out through the rail never shows as Rail lift — every row reads the sections' number at the rail, 0 on a flat tail", (label) => {
    const { board, resolved } = setupOf(channelBoards.find((b) => b.label === label)!.fields);
    const rows = bottomDataRows(resolved, board);
    for (const r of rows) {
      const W = board.railAt(r.station);
      expect(r.railLift).toBe(sectionsFoamOff(resolved, board, r.station, W));
      expect(r.railLift).toBe(0);
    }
    // the tail row: the whole one number at the rail is a channel there, deep enough to have read as a figure in DATA
    const tail = rows[0];
    expect(tail.label).toBe("tail");
    expect(foamOff(resolved, board, tail.station, board.railAt(tail.station))).toBeGreaterThanOrEqual(BOTTOM_DATA_DEPTH_SHOWN);
  });

  it.each([...flatLabels, "fish|hard|rolled-vee|6", "shortboard|hard|rolled-vee|6"])("%s: every other figure is unchanged — Deepest cut and Stringer left still the one number, the rest as the board with no channels", (label) => {
    const { board, resolved, none } = setupOf(channelBoards.find((b) => b.label === label)!.fields);
    const rows = bottomDataRows(resolved, board);
    const noneRows = bottomDataRows(none, board);
    let channelled = 0;
    rows.forEach((r, k) => {
      expect(r.deepest).toBe(deepestCutAt(resolved, board, r.station));
      expect(r.deepest).toBeGreaterThanOrEqual(r.railLift);
      if (r.stringerLeft === null) expect(noneRows[k].stringerLeft).toBeNull();
      else expect(r.stringerLeft).toBe(board.thicknessAt(r.station) - foamOff(resolved, board, r.station, mm(0)));
      expect(r.station).toBe(noneRows[k].station);
      expect(r.label).toBe(noneRows[k].label);
      expect(r.width).toBe(noneRows[k].width);
      expect(r.reference).toBe(noneRows[k].reference);
      expect(r.atFloor).toBe(noneRows[k].atFloor);
      if (r.deepest > noneRows[k].deepest) channelled++;
    });
    expect(channelled, "the channels are in the Deepest cut (non-vacuity)").toBeGreaterThan(0);
  });

  it("without channels nothing moves: a flat bottom's every row reads 0 Rail lift on every board", () => {
    for (const { board: b } of BOARDS) {
      for (const r of bottomDataRows(resolveBottom(DEFAULT_BOTTOM, b), b)) expect(r.railLift).toBe(0);
    }
  });
});

'''
s = s.replace(anchor, block + anchor)

# imports
imp_a = '''import { deriveEffectiveRails, designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, summarizeDesign } from "./design";'''
imp_b = '''import { bottomRailLift, deriveEffectiveRails, designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES, summarizeDesign } from "./design";'''
assert s.count(imp_a) == 1
s = s.replace(imp_a, imp_b)
imp_c = 'import { phase16Boards, phase16SurfaceBoards } from "./__fixtures__/phase16-boards";'
assert s.count(imp_c) == 1
s = s.replace(imp_c, imp_c + '\nimport { phase17ChannelBoards } from "./__fixtures__/phase17-channel-boards";')
if 'BOTTOM_DATA_DEPTH_SHOWN' not in s.split('} from "./bottom";')[0]:
    s = s.replace('  BOTTOM_CUT_NAMES,\n', '  BOTTOM_CUT_NAMES,\n  BOTTOM_DATA_DEPTH_SHOWN,\n', 1)
open(p, 'w').write(s)
print('ok')

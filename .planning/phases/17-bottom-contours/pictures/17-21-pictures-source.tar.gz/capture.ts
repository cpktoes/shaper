// 17-21 regression capture. Writes three JSON files into argv[2] (a folder):
//  rails-kept.json — on the four presets, Hard Edge and soft: with no channels (a flat bottom, the five vees, the two
//    bellies, the Double Concave Exit, the Extending Single Concave) railBandsOnTheBottom's three sections; with the
//    starting six channels on each vee and belly every section whose bottom lifts the rail; each section that has a
//    bottom with its finished rail on that bottom.
//  litres.json — summarizeDesign's litres (toPrecision(17)) for every board of phase17ChannelBoards() and every board above.
//  data.json — bottomDataRows for the same boards.
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <out dir>
import { writeFileSync } from "node:fs";
import { phase16Boards } from "@/lib/geometry/__fixtures__/phase16-boards";
import { phase17ChannelBoards } from "@/lib/geometry/__fixtures__/phase17-channel-boards";
import {
  bottomDataRows,
  DEFAULT_BOTTOM,
  pickCut,
  resolveBottom,
  startingChannels,
  type BoardBottom,
  type BottomBoard,
  type BottomCutName,
  type BottomSectionKey,
} from "@/lib/geometry/bottom";
import {
  bottomRailLift,
  deriveEffectiveRails,
  designBottomBoard,
  designFinPlacement,
  designSideProfile,
  LIVE_DESIGN_RULES,
  railAnchorStations,
  railBandsOnTheBottom,
  railsOnTheBottom,
  summarizeDesign,
  type DesignSummaryFields,
} from "@/lib/geometry/design";
import { finishedRail } from "@/lib/geometry/finished-rail";
import { buildOutline } from "@/lib/geometry/outline";
import { computeRailBands } from "@/lib/geometry/rail-bands";
import { finishedRailOnBottom } from "@/lib/geometry/rail-bottom";

const LIFTERS: [BottomSectionKey, BottomCutName][] = [
  ["tail", "Panel Vee"],
  ["tail", "Spiral Vee"],
  ["tail", "Rolled Vee"],
  ["nose", "Reverse Vee Nose"],
  ["center", "Tri-Plane Hull Center"],
  ["nose", "Rolled Belly Entry"],
  ["center", "Continuous Belly / Rolled Mid"],
];
const CONCAVES: [BottomSectionKey, BottomCutName][] = [
  ["tail", "Double Concave Exit"],
  ["tail", "Extending Single Concave"],
];

const dir = process.argv[2];
const rails: Record<string, unknown> = {};
const litres: Record<string, string> = {};
const data: Record<string, unknown> = {};
const all = phase16Boards();

function boardOf(fields: DesignSummaryFields): BottomBoard {
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  return designBottomBoard(fields.outline, buildOutline(fields.outline), profile, designFinPlacement(fields));
}

function record(label: string, fields: DesignSummaryFields, onlyLifted: boolean) {
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const board = boardOf(fields);
  const resolved = resolveBottom(fields.bottom ?? DEFAULT_BOTTOM, board);
  const effectiveRails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const anchors = railAnchorStations(profile.effectiveFoil, fields.outline.length);
  const r = railsOnTheBottom(effectiveRails, bottomRailLift(resolved, board), anchors);
  const bands = railBandsOnTheBottom(computeRailBands(r), resolved, board, anchors);
  const entry: Record<string, unknown> = {};
  if (!onlyLifted) entry.rails = r;
  for (const key of ["tail", "center", "nose"] as const) {
    const sec = bands[key];
    if (onlyLifted && !(sec.bottom && sec.bottom.lift > 0)) continue;
    entry[key] = sec;
    if (sec.bottom) entry[`finished-${key}`] = finishedRailOnBottom(finishedRail(sec, sec.bounds.xAxisMin), sec.bottom, sec.boardThickness);
  }
  rails[label] = entry;
  litres[label] = summarizeDesign(fields).volumeLitres.toPrecision(17);
  data[label] = bottomDataRows(resolved, board);
}

for (const id of ["shortboard", "fish", "midlength", "longboard"]) {
  for (const tail of ["hard", "soft"]) {
    const base = all.find((b) => b.label === `${id}|asis|${tail}`)!.fields;
    const board = boardOf(base);
    record(`${id}|${tail}|flat`, { ...base, bottom: structuredClone(DEFAULT_BOTTOM) }, false);
    for (const [section, name] of [...LIFTERS, ...CONCAVES]) {
      const bottom: BoardBottom = pickCut(structuredClone(DEFAULT_BOTTOM), section, name, board);
      record(`${id}|${tail}|${name}`, { ...base, bottom }, false);
    }
    for (const [section, name] of LIFTERS) {
      const bottom: BoardBottom = pickCut(structuredClone(DEFAULT_BOTTOM), section, name, board);
      bottom.channels = startingChannels(6, board, bottom.channels);
      record(`${id}|${tail}|${name}|6ch`, { ...base, bottom }, true);
    }
  }
}
// The 49 channelled boards: litres and DATA only (their RAILS sections are what this plan changes).
for (const { label, fields } of phase17ChannelBoards()) {
  const board = boardOf(fields);
  const resolved = resolveBottom(fields.bottom!, board);
  litres[`p17|${label}`] = summarizeDesign(fields).volumeLitres.toPrecision(17);
  data[`p17|${label}`] = bottomDataRows(resolved, board);
}

writeFileSync(`${dir}/rails-kept.json`, JSON.stringify(rails));
writeFileSync(`${dir}/litres.json`, JSON.stringify(litres));
writeFileSync(`${dir}/data.json`, JSON.stringify(data));
console.log("rails", Object.keys(rails).length, "litres", Object.keys(litres).length, "data", Object.keys(data).length);

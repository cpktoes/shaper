// 17-21's pictures, 1280 wide, Imperial: RAILS' tail section with the Finished Rail on (the Shortboard with a flat
// tail and its starting six channels, the Fish with a flat tail and its starting eight), and BOTTOM's DATA on the Fish
// with a flat tail and eight channels; after, BOTTOM's VIEWER with the section at DATA's tail row.
// PICS_PHASE=before|after names the files. Run with the scratch pics.config.ts (desktop project only).
import { writeFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/lib/models/toolbar-tip";
import { bottomDataRows } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/lib/geometry/bottom";
import { boardWithBottom, openOnBoard } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/e2e/helpers/bottom-print";
import { BOTTOM_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/components/bottom/bottom-copy";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-beautiful-fermi-ad3fb7/7f5ae211-41b9-4a82-968a-00a7bd4ff836/scratchpad/p21/pics-out";
const PHASE = process.env.PICS_PHASE ?? "before";

async function dismiss(page: Page) {
  await page.addInitScript((key) => window.sessionStorage.setItem(key, "true"), BANNER_DISMISSAL_KEY);
  await page.addInitScript((key) => window.localStorage.setItem(key, "true"), TOOLBAR_TIP_DISMISSAL_KEY);
}

async function shootTail(page: Page, name: string, channelLabel: string) {
  await page.goto("/design/rails");
  await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeAttached({ timeout: 60_000 });
  const button = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /finished rail$/ });
  await expect(button).toHaveAttribute("aria-pressed", "true");
  const plot = page.locator('[data-rail-plot-row="desktop"] [data-rail-section-plot="tail"]');
  await expect(plot.locator("[data-finished-rail]")).toHaveCount(1);
  // The kept board replaces the stock one a moment after the page opens: wait for its channels to be drawn (after),
  // or for the page to settle (before, where the plot has no planed bottom to wait for).
  if (PHASE === "after") await expect(plot.locator("[data-rail-planed-bottom]")).toHaveCount(1, { timeout: 60_000 });
  await page.waitForTimeout(3_000);
  await plot.screenshot({ path: `${OUT}/${PHASE}-${name}.png` });
  void channelLabel;
}

test.setTimeout(240_000);
test.use({ deviceScaleFactor: 2 });

test("shortboard, flat tail, six channels — RAILS", async ({ page }) => {
  await dismiss(page);
  await openOnBoard(page, boardWithBottom("shortboard", { channels: 6 }));
  await shootTail(page, "rails-shortboard-6", "6 channels");
});

test("fish, flat tail, eight channels — RAILS", async ({ page }) => {
  await dismiss(page);
  await openOnBoard(page, boardWithBottom("fish", { channels: 8 }));
  await shootTail(page, "rails-fish-8", "8 channels");
});

test("fish, flat tail, eight channels — BOTTOM's DATA (and, after, the VIEWER at the tail row)", async ({ page }) => {
  await dismiss(page);
  const board = boardWithBottom("fish", { channels: 8 });
  await openOnBoard(page, board);
  await page.goto("/design/bottom");
  await expect(page.locator("[data-bottom-cut-line]")).toBeAttached({ timeout: 60_000 });
  await expect(page.locator("[data-bottom-channels-echo]")).not.toHaveText("None", { timeout: 60_000 });
  const dataTab = page.getByRole("tab", { name: "DATA", exact: true });
  await expect(async () => {
    if ((await page.locator("[data-bottom-data]").count()) === 0) await dataTab.click({ timeout: 2_000 });
    await expect(page.locator("[data-bottom-data]")).toBeVisible({ timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await page.waitForTimeout(3_000);
  await page.locator("[data-bottom-data]").screenshot({ path: `${OUT}/${PHASE}-data-fish-8.png` });
  // Where the tail row's Rail lift cell sits in that picture (in the picture's own dots, twice the page's), for the mark.
  const box = await page.locator("[data-bottom-data]").boundingBox();
  const cellBox = await page.locator("[data-bottom-depths] tbody tr").first().locator("td").nth(2).boundingBox();
  writeFileSync(
    `${OUT}/${PHASE}-data-cell.json`,
    JSON.stringify({ x: (cellBox!.x - box!.x) * 2, y: (cellBox!.y - box!.y) * 2, w: cellBox!.width * 2, h: cellBox!.height * 2 }),
  );
  // Which row is the tail row, for the caption: the rows as the app works them out.
  const rows = bottomDataRows(board.resolved, board.board);
  console.log("rows", JSON.stringify(rows.map((r) => ({ label: r.label, station: r.station, railLift: r.railLift, deepest: r.deepest }))));
  if (PHASE !== "after") return;
  // The VIEWER, with the section at DATA's tail row (the row with the smallest station off the tail).
  const tailRow = rows.reduce((a, b) => (b.station < a.station ? b : a));
  await page.getByRole("tab", { name: "VIEWER", exact: true }).click();
  const slider = page.getByRole("slider", { name: BOTTOM_COPY.sectionAt, exact: true });
  await expect(slider).toBeVisible({ timeout: 30_000 });
  const cutAt = async () => Number(await page.locator("[data-bottom-cut-at]").getAttribute("data-bottom-cut-at"));
  await slider.focus();
  // Right is toward the tail. Step until the line is at (or just past) the tail row's station, then back if past.
  for (let i = 0; i < 400 && (await cutAt()) > tailRow.station + 0.5; i++) await page.keyboard.press("ArrowRight");
  console.log("viewer at", await cutAt(), "tail row", tailRow.station);
  await page.waitForTimeout(2_000);
  await page.locator("[data-bottom-section]").screenshot({ path: `${OUT}/after-viewer-fish-8.png` });
});

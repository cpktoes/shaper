p='/Users/kontoes/Code/shaper/.claude/worktrees/agent-ad0592035e8cfc106/e2e/rails-channels.spec.ts'
s=open(p).read()
old_hdr=''' * What this proves: on the Fish with a Rolled Vee and eight channels, both lines on RAILS' tail plot hold vertical
 * drops — two points one above the other at the same x — and more of them than the same board with the channels set
 * back to None. No figure is typed: the drops are counted off the page's own drawing.
 */'''
new_hdr=''' * What this proves: on the Fish with a Rolled Vee and eight channels, both lines on RAILS' tail plot hold vertical
 * drops — two points one above the other at the same x — and more of them than the same board with the channels set
 * back to None. No figure is typed: the drops are counted off the page's own drawing.
 *
 * The founder's answer of 2026-11-11, "Show channels too": a board with no vee or belly shows its channels on RAILS
 * as well. On the Fish with a flat tail and eight channels, RAILS' tail plot now draws the flat planed bottom with every
 * channel wall cut straight up on the thin line and on the Finished Rail, each wall on both lines at the same place,
 * while the rail it bands is the rail it bands with no channels: the readout card reads the same and never names
 * BOTTOM, every band line but the bottom connector (now drawn as the planed bottom) and every mark dot stand where they
 * stand with None.
 */'''
assert s.count(old_hdr)==1
s=s.replace(old_hdr,new_hdr)
start=s.index("/** On RAILS, with the tail's plot and the finished rail both drawn, how many vertical drops each line holds. */")
end=s.index('test.describe("RAILS cuts the channels straight up (G-17-6)"')
new_fn=r'''interface TailPlot {
  /** How many vertical drops the Finished Rail and the thin planed bottom hold. */
  finished: number;
  planed: number;
  /** The x of every drop on each line, rounded to 0.01 of a drawing unit. */
  finishedDropXs: number[];
  planedDropXs: number[];
  /** Every band line's four coordinates (`x1,y1,x2,y2`), and every mark dot's centre (`cx,cy`). */
  bandLines: string[];
  dots: string[];
  /** The text of RAILS' readout card, `From ROCKER & FOIL`. */
  readout: string;
}

/**
 * On RAILS, with the tail's plot and the finished rail both drawn: the vertical drops each line holds, where they stand,
 * the band lines, the mark dots and the readout card. `planedBottoms` is how many planed-bottom lines the plot draws —
 * 1 where the bottom is drawn under the rail, 0 where the bottom connector is the straight line it always was.
 */
async function tailPlot(page: Page, planedBottoms: 0 | 1 = 1): Promise<TailPlot> {
  await goToScreen(page, "RAILS");
  const plot = page.locator('[data-rail-plot-row="desktop"] [data-rail-section-plot="tail"]');
  await expect(plot).toBeVisible({ timeout: 60_000 });
  const button = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /finished rail$/ });
  if ((await button.getAttribute("aria-pressed")) !== "true") await button.click();
  await expect(button).toHaveAttribute("aria-pressed", "true");
  await expect(plot.locator("[data-finished-rail]")).toHaveCount(1);
  await expect(plot.locator("[data-rail-planed-bottom]")).toHaveCount(planedBottoms);
  const card = importedReadout(page.locator("aside"), "From ROCKER & FOIL");
  await expect(card).toBeVisible();
  const readout = ((await card.textContent()) ?? "").replace(/\s+/g, " ").trim();
  const drawn = await plot.evaluate((svg) => {
    const dropXs = (points: { x: number; y: number }[]) => {
      const xs: number[] = [];
      for (let i = 1; i < points.length; i++) {
        if (Math.abs(points[i].x - points[i - 1].x) < 0.01 && Math.abs(points[i].y - points[i - 1].y) >= 1) {
          xs.push(Math.round(points[i].x * 100) / 100);
        }
      }
      return xs;
    };
    // The finished rail's path: every command's end point, in order (M, L, Q and C all end on their last pair).
    const d = svg.querySelector("[data-finished-rail]")!.getAttribute("d") ?? "";
    const pathPoints = (d.match(/[MLQC][^MLQCZ]*/g) ?? []).map((command) => {
      const numbers = command.slice(1).trim().split(/[\s,]+/).map(Number);
      return { x: numbers[numbers.length - 2], y: numbers[numbers.length - 1] };
    });
    const planed = (svg.querySelector("[data-rail-planed-bottom]")?.getAttribute("points") ?? "")
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .map((pair) => {
        const [x, y] = pair.split(",").map(Number);
        return { x, y };
      });
    const bandLines = [...svg.querySelectorAll("[data-rail-bands] line")].map((line) =>
      ["x1", "y1", "x2", "y2"].map((a) => line.getAttribute(a)).join(","),
    );
    const dots = [...svg.querySelectorAll("circle")].map((c) => `${c.getAttribute("cx")},${c.getAttribute("cy")}`);
    return { finishedDropXs: dropXs(pathPoints), planedDropXs: dropXs(planed), bandLines, dots };
  });
  return { ...drawn, finished: drawn.finishedDropXs.length, planed: drawn.planedDropXs.length, readout };
}

/** How many vertical drops each line holds, on a plot that draws its planed bottom (the Rolled Vee test below). */
async function tailDrops(page: Page): Promise<{ finished: number; planed: number }> {
  const { finished, planed } = await tailPlot(page, 1);
  return { finished, planed };
}

'''
s=s[:start]+new_fn+s[end:]
imp='import { forgetOpenBoardOnEveryLoad } from "./helpers/open-board";'
assert s.count(imp)==1
s=s.replace(imp,'import { importedReadout } from "./helpers/imported-readout";\n'+imp)
old_tail='''    expect(withChannels.finished).toBeGreaterThan(without.finished);
    expect(withChannels.planed).toBeGreaterThan(without.planed);
  });
});'''
new_tail='''    expect(withChannels.finished).toBeGreaterThan(without.finished);
    expect(withChannels.planed).toBeGreaterThan(without.planed);
  });

  test("on the Fish with a flat tail and eight channels, RAILS draws the walls on both lines, and its rail is the rail it bands with no channels", async ({
    page,
  }) => {
    test.setTimeout(240_000);
    await openFishOnBottom(page);
    // Only the channels: the tail stays Flat Exit.
    await pickFrom(page, "Channels", "8 channels");
    const withChannels = await tailPlot(page, 1);

    await goToScreen(page, "BOTTOM");
    await pickFrom(page, "Channels", "None");
    const without = await tailPlot(page, 0);

    // The walls: the planed bottom holds vertical drops, and the finished line stands at more places than with None (a
    // hard edge's face, split into pieces, stays one place).
    expect(withChannels.planed).toBeGreaterThan(0);
    expect(new Set(withChannels.finishedDropXs).size).toBeGreaterThan(new Set(without.finishedDropXs).size);
    // every wall on the thin line has a wall on the thick line at the same place
    const thick = new Set(withChannels.finishedDropXs);
    for (const x of withChannels.planedDropXs) expect(thick.has(x), `the Finished Rail drops at ${x} too`).toBe(true);

    // The rail itself: every band line is one of None's, one fewer (the bottom connector, drawn as the planed bottom
    // instead); every mark dot stands where it stands; the readout card reads the same and never names BOTTOM.
    const noneLines = new Set(without.bandLines);
    for (const line of withChannels.bandLines) expect(noneLines.has(line), `band line ${line}`).toBe(true);
    expect(withChannels.bandLines).toHaveLength(without.bandLines.length - 1);
    expect(withChannels.dots).toEqual(without.dots);
    expect(withChannels.readout).toBe(without.readout);
    expect(withChannels.readout).not.toMatch(/BOTTOM/i);
  });
});'''
assert s.count(old_tail)==1
s=s.replace(old_tail,new_tail)
open(p,'w').write(s)
print("ok")

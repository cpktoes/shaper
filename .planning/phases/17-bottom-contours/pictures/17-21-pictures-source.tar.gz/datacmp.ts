// 17-21 Task 3: DATA before and after. Every field but railLift identical; every railLift the sections' number at the
// rail (recomputed here with the app's own sectionsFoamOff); railLift identical on every board without channels.
// Prints the tail row's Rail lift before and after on the flat-tail channel boards (the SUMMARY's table).
// Run from the worktree root: npx --no-install tsx --tsconfig ./tsconfig.json <this> <before dir> <after dir>
import { readFileSync } from "node:fs";
import { phase17ChannelBoards } from "@/lib/geometry/__fixtures__/phase17-channel-boards";
import { resolveBottom, sectionsFoamOff, type BottomDataRow } from "@/lib/geometry/bottom";
import { designBottomBoard, designFinPlacement, designSideProfile, LIVE_DESIGN_RULES } from "@/lib/geometry/design";
import { buildOutline } from "@/lib/geometry/outline";
import { formatInchesFraction, mmToInches } from "@/lib/geometry/units";

const before = JSON.parse(readFileSync(`${process.argv[2]}/data.json`, "utf8")) as Record<string, BottomDataRow[]>;
const after = JSON.parse(readFileSync(`${process.argv[3]}/data.json`, "utf8")) as Record<string, BottomDataRow[]>;
let otherDiffs = 0;
let liftDiffs = 0;
const changedBoards = new Set<string>();
for (const label of Object.keys(before)) {
  const b = before[label];
  const a = after[label];
  if (a.length !== b.length) throw new Error(`${label}: row count`);
  b.forEach((row, k) => {
    const { railLift: lb, ...rb } = row;
    const { railLift: la, ...ra } = a[k];
    if (JSON.stringify(rb) !== JSON.stringify(ra)) otherDiffs++;
    if (lb !== la) {
      liftDiffs++;
      changedBoards.add(label);
    }
  });
}
// Every changed board carries channels.
const unchannelled = [...changedBoards].filter((l) => !l.startsWith("p17|") && !l.endsWith("|6ch"));
// Recompute railLift for the 49 channel boards.
let mismatch = 0;
const table: string[] = [];
for (const { label, fields } of phase17ChannelBoards()) {
  const board = designBottomBoard(fields.outline, buildOutline(fields.outline), designSideProfile(fields, LIVE_DESIGN_RULES), designFinPlacement(fields));
  const resolved = resolveBottom(fields.bottom!, board);
  after[`p17|${label}`].forEach((row) => {
    if (row.railLift !== sectionsFoamOff(resolved, board, row.station, board.railAt(row.station))) mismatch++;
  });
  if (label.includes("|flat|")) {
    const lb = before[`p17|${label}`][0].railLift;
    const la = after[`p17|${label}`][0].railLift;
    table.push(`${label}\t${mmToInches(lb).toFixed(3)}" (${formatInchesFraction(lb, 16)})\t${mmToInches(la).toFixed(3)}"`);
  }
}
console.log({ otherDiffs, liftDiffs, changedBoards: changedBoards.size, unchannelled, mismatch });
console.log(table.join("\n"));

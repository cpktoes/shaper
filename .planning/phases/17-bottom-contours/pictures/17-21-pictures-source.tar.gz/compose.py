# 17-21: put the before and after pictures side by side, a caption line over each row, into one PNG.
# Usage: python3 -I compose.py rails|data <pics-out dir> <output png>
import json
import sys
from PIL import Image, ImageDraw, ImageFont

mode, src, out = sys.argv[1], sys.argv[2], sys.argv[3]


def font(size):
    for path in ["/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()


title_font = font(34)
caption_font = font(26)
label_font = font(24)
pad = 24
gap = 30
title_h = 60
caption_h = 40
label_h = 34

if mode == "rails":
    title = "17-21 - RAILS shows the channels on a flat tail too (\"Show channels too\"): before (left) and after (right)"
    rows = [
        ("rails-shortboard-6", "Shortboard, flat tail, its starting six channels - RAILS tail section, Finished Rail on"),
        ("rails-fish-8", "Fish, flat tail, its starting eight channels - RAILS tail section, Finished Rail on"),
    ]
    pairs = [(Image.open(f"{src}/before-{k}.png").convert("RGB"), Image.open(f"{src}/after-{k}.png").convert("RGB")) for k, _ in rows]
    col_w = max(max(b.width, a.width) for b, a in pairs)
    width = pad * 2 + col_w * 2 + gap
    height = pad + title_h + sum(caption_h + label_h + max(b.height, a.height) + pad for b, a in pairs) + pad
    sheet = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text((pad, pad), title, fill="black", font=title_font)
    y = pad + title_h
    for (key, caption), (before, after) in zip(rows, pairs):
        draw.text((pad, y), caption, fill="black", font=caption_font)
        y += caption_h
        draw.text((pad, y), "Before", fill=(120, 120, 120), font=label_font)
        draw.text((pad + col_w + gap, y), "After", fill=(120, 120, 120), font=label_font)
        y += label_h
        sheet.paste(before, (pad, y))
        sheet.paste(after, (pad + col_w + gap, y))
        draw.rectangle([pad - 1, y - 1, pad + before.width, y + before.height], outline=(200, 200, 200))
        draw.rectangle([pad + col_w + gap - 1, y - 1, pad + col_w + gap + after.width, y + after.height], outline=(200, 200, 200))
        y += max(before.height, after.height) + pad
else:
    title = "17-21 - BOTTOM's DATA Rail lift counts the vee or belly alone (\"Match RAILS\"): Fish, flat tail, its starting eight channels"
    before = Image.open(f"{src}/before-data-fish-8.png").convert("RGB")
    after = Image.open(f"{src}/after-data-fish-8.png").convert("RGB")
    viewer = Image.open(f"{src}/after-viewer-fish-8.png").convert("RGB")
    cell = json.load(open(f"{src}/after-data-cell.json"))
    cols = [
        ("Before - DATA", before),
        ("After - DATA", after),
        ("After - VIEWER, the section at the tail row (its gauge at the rail is the founder's question)", viewer),
    ]
    width = pad * 2 + before.width + after.width + gap * 2 + viewer.width
    height = pad + title_h + caption_h + label_h + max(im.height for _, im in cols) + pad * 2
    sheet = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text((pad, pad), title, fill="black", font=title_font)
    y = pad + title_h
    draw.text((pad, y), "The tail row's Rail lift cell is ringed in red on both DATA pictures.", fill="black", font=caption_font)
    y += caption_h
    x = pad
    for i, (label, im) in enumerate(cols):
        lab = label if i < 2 else "After - VIEWER at the tail row"
        draw.text((x, y), lab, fill=(120, 120, 120), font=label_font)
        sheet.paste(im, (x, y + label_h))
        draw.rectangle([x - 1, y + label_h - 1, x + im.width, y + label_h + im.height], outline=(200, 200, 200))
        if i < 2:
            cx, cy = x + cell["x"], y + label_h + cell["y"]
            draw.rectangle([cx + 20, cy + 2, cx + cell["w"] + 10, cy + cell["h"] - 2], outline=(214, 40, 40), width=5)
        x += im.width + gap
sheet.save(out, optimize=True)
print("wrote", out, sheet.size)

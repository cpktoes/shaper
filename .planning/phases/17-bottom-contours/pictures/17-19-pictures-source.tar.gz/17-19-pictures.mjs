/**
 * 17-19 / 17-20 picture script. Takes BOTTOM's section with "Show the finished rail from RAILS" ticked, Height x4,
 * the section 6" from the tail, on (a) the Longboard with six channels and (b) the Shortboard with its tail's
 * Hard Edge unticked on RAILS and six channels; then the 3D screen's Bottom view of the same two boards; then
 * composes one captioned PNG.
 *
 *   WT=<worktree root> PORT=3319 OUT=<out dir> LABEL=before node 17-19-pictures.mjs
 *
 * A dev server must already be answering on PORT (IS_WEBPACK_TEST=1 and the playwright.config non-secret env).
 * Re-run with LABEL=after for 17-20.
 */
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";

const WT = process.env.WT;
const PORT = process.env.PORT ?? "3319";
const OUT = process.env.OUT;
const LABEL = process.env.LABEL ?? "before";
const require = createRequire(path.join(WT, "package.json"));
const { chromium } = require("playwright");
const base = `http://localhost:${PORT}`;
fs.mkdirSync(OUT, { recursive: true });

async function openPreset(page, name) {
  await page.goto(`${base}/`, { timeout: 120000 });
  const card = page.getByRole("button").filter({ hasText: name }).filter({ hasText: /Start Shaping|\d\.\d L/ }).first();
  for (let i = 0; i < 40 && !/\/design\/outline$/.test(page.url()); i++) {
    if ((await card.count()) > 0) {
      await card.scrollIntoViewIfNeeded({ timeout: 2000 }).catch(() => {});
      await card.click({ timeout: 2000 }).catch(() => {});
    }
    await page.waitForTimeout(1500);
  }
  if (!/\/design\/outline$/.test(page.url())) throw new Error("never reached TEMPLATE");
}

async function go(page, href) {
  const label = { "/design/bottom": "BOTTOM", "/design/rails": "RAILS", "/design/3d": "3D" }[href];
  const link = page.locator("nav:not([aria-label])").getByRole("link", { name: label, exact: true }).first();
  await link.click({ timeout: 90000 });
  await page.waitForURL(`**${href}`, { timeout: 90000 });
}

async function pickChannels(page, option) {
  for (let i = 0; i < 20; i++) {
    try {
      await page.getByRole("combobox", { name: "Channels", exact: true }).click({ timeout: 2000 });
      await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2000 });
      const echo = await page.locator("[data-bottom-channels-echo]").textContent({ timeout: 2000 });
      if (echo && echo !== "None") return;
    } catch {}
    await page.waitForTimeout(800);
  }
  throw new Error("could not pick channels");
}

async function sectionAtMm(page, targetMm) {
  const slider = page.getByRole("slider", { name: "Section at", exact: true });
  const cutAt = async () => Number(await page.locator("[data-bottom-cut-at]").getAttribute("data-bottom-cut-at"));
  await slider.focus();
  let stuck = false;
  for (let i = 0; i < 1500; i++) {
    const now = await cutAt();
    if (Math.abs(now - targetMm) < 0.5) return now;
    const key = now > targetMm ? "ArrowRight" : "ArrowLeft"; // right is toward the tail
    const far = !stuck && Math.abs(now - targetMm) > 270; // a Shift step is 10" (254 mm)
    await slider.focus();
    await page.keyboard.press(far ? `Shift+${key}` : key);
    if (far && Math.abs((await cutAt()) - now) < 0.01) stuck = true; // a big step that goes nowhere: use small ones
  }
  return cutAt();
}

async function bottomShots(page, tag) {
  await go(page, "/design/bottom");
  await page.locator("[data-bottom-cut-line]").waitFor({ state: "attached", timeout: 60000 });
  await pickChannels(page, "6 channels");
  await page.getByRole("button", { name: "Height ×4", exact: true }).click();
  const tick = page.getByRole("checkbox", { name: "Show the finished rail from RAILS" });
  if (!(await tick.isChecked())) await tick.click();
  const at = await sectionAtMm(page, 6 * 25.4);
  const sl = page.getByRole("slider", { name: "Section at", exact: true });
  console.log(tag, "slider", await sl.getAttribute("aria-valuemin"), await sl.getAttribute("aria-valuemax"), await sl.getAttribute("aria-valuenow"), await sl.getAttribute("aria-valuetext"));
  await page.waitForTimeout(800);
  await page.locator("[data-bottom-section]").screenshot({ path: path.join(OUT, `${tag}-section.png`) });
  await page.locator("[data-bottom-top-view]").screenshot({ path: path.join(OUT, `${tag}-top.png`) });
  const ghost = await page.locator("[data-bottom-ghost]").count();
  console.log(tag, "section at mm from tail", at, "ghost drawn", ghost);
}

async function threeD(page, tag) {
  await go(page, "/design/3d");
  const canvas = page.locator("[data-board-3d]");
  await canvas.waitFor({ state: "attached", timeout: 90000 });
  await page
    .waitForFunction(() => document.querySelector("[data-board-3d]")?.getAttribute("data-board-state") === "ready", null, { timeout: 90000 })
    .catch(() => {});
  const state = await canvas.getAttribute("data-board-state");
  console.log(tag, "3D state", state);
  const bottom = page.getByRole("group", { name: "Views" }).getByRole("button", { name: "Bottom", exact: true });
  await bottom.click();
  await page.waitForTimeout(2500);
  await page.locator("[data-three-d-drawing]").screenshot({ path: path.join(OUT, `${tag}-3d.png`) });
  return state;
}

const browser = await chromium.launch();
const shots = [];
for (const board of [
  { tag: "longboard", name: "Longboard", caption: 'Longboard (rolled rail), six channels, section 6" from the tail' },
  {
    tag: "shortboard-soft",
    name: "Shortboard",
    caption: 'Shortboard with a soft tail (Hard Edge unticked), six channels, section 6" from the tail',
    softTail: true,
  },
]) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await context.addInitScript(() => {
    try {
      sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
      localStorage.removeItem("shaper-open-board");
    } catch {}
  });
  const page = await context.newPage();
  await openPreset(page, board.name);
  if (board.softTail) {
    await go(page, "/design/rails");
    const tail = page.locator('[data-rail-group="tail"]');
    const hard = tail.getByRole("checkbox", { name: "Hard Edge" });
    await hard.waitFor({ timeout: 60000 });
    if (await hard.isChecked()) await hard.click();
    if (await hard.isChecked()) throw new Error("Hard Edge still ticked");
  }
  await bottomShots(page, board.tag);
  const state = await threeD(page, board.tag).catch((e) => {
    console.log(board.tag, "3D failed:", e.message);
    return "failed";
  });
  shots.push({ ...board, state });
  await context.close();
}

// Compose one captioned sheet.
const img = (f) => `data:image/png;base64,${fs.readFileSync(path.join(OUT, f)).toString("base64")}`;
const have = (f) => fs.existsSync(path.join(OUT, f));
const rows = shots
  .map(
    (s) => `<section><h2>${s.caption}</h2><div class="row">
  <figure><img src="${img(`${s.tag}-section.png`)}"><figcaption>BOTTOM, cross-section with the finished rail from RAILS ticked, Height x4</figcaption></figure>
  <figure><img src="${img(`${s.tag}-top.png`)}"><figcaption>The same board from above, the cutting line at 6" from the tail</figcaption></figure>
  ${have(`${s.tag}-3d.png`) && s.state !== "failed" ? `<figure><img src="${img(`${s.tag}-3d.png`)}"><figcaption>3D screen, Bottom view (the underside)</figcaption></figure>` : ""}
  </div></section>`,
  )
  .join("\n");
const html = `<html><body style="font-family:system-ui;margin:16px;background:#fff;color:#111;width:1700px">
<h1>Phase 17, G-17-6: channels under the finished rail — ${LABEL.toUpperCase()}</h1>
<style>h2{font-size:18px;margin:18px 0 6px}.row{display:flex;gap:12px;align-items:flex-start}figure{margin:0}img{max-width:560px;border:1px solid #999}figcaption{font-size:13px;margin-top:4px;color:#333}</style>
${rows}</body></html>`;
const compose = await browser.newPage({ viewport: { width: 1740, height: 900 } });
await compose.setContent(html);
await compose.waitForTimeout(500);
await compose.screenshot({ path: path.join(OUT, `17-19-${LABEL}.png`), fullPage: true });
await browser.close();
console.log("composed", path.join(OUT, `17-19-${LABEL}.png`));

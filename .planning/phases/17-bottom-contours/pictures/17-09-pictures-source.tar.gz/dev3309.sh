#!/bin/bash
# The worktree's own dev server on 3309, with the browser suite's own test-only env (playwright.config.ts), so the
# suite's runs reuse it. Never the founder's 3005.
cd /Users/kontoes/Code/shaper/.claude/worktrees/agent-acbbf20aa4e7ccee0 || exit 1
export NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY="pk_live_ZXhhbXBsZS5jbGVyay5hY2NvdW50cy5kZXYk"
export CLERK_SECRET_KEY="sk_live_fake-not-a-secret-for-playwright-only"
export DATABASE_URL="postgresql://user:pass@localhost:5432/shaper"
export SHAPER_BLANKS_SOURCE="seed-csv"
export SHAPER_CONTACT_STAND_IN="1"
export SHAPER_FORCED_ERROR="1"
export SHAPER_RACK_STAND_IN="1"
export IS_WEBPACK_TEST=1
exec npx next dev --port 3309

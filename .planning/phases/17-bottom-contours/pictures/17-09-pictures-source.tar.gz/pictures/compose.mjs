// Composes 17-09's shots into one captioned picture for the founder. Each shot was taken at deviceScaleFactor 2 and is
// shown at its true size on a 1280-wide screen (half its pixels), so the panel reads as it does on his computer.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const [SHOTS, OUT] = process.argv.slice(2);
const img = (name) => `data:image/png;base64,${readFileSync(`${SHOTS}/${name}.png`).toString("base64")}`;

const ROWS = [
  [["00-screen", "0 · The computer screen, 1280 × 800: the Shortboard with a Teardrop at the nose and an Early Double in the center — the panel beside its two drawings."]],
  [
    ["01-nose-teardrop", "1 · NOSE, Teardrop Nose Concave (Shortboard). Off Rail, Start, Deepest At, End, Depth, Smoothness, then the tick box — ticked on the Teardrop's starting numbers."],
    ["02-center-double", "2 · CENTER, Early Double Concave. Off Rail, then Off Stringer and Trough At (\"4\\\" from the stringer\"), then the stations, Depth and Smoothness."],
    ["03-tail-spiral-vee", "3 · TAIL, Spiral Vee (Mid-length). Off Rail, Off Stringer, Trough At … Depth, then Vee Lift, then Smoothness. Under Depth, the new rail sentence: this opening vee thins the tail rail (D-42, \"Warn, keep the numbers\")."],
  ],
  [
    ["04-tail-fish-panel-vee", "4 · TAIL, Panel Vee on the Fish, fresh: a vee shows only the stations, Depth (its lift at the rail) and Smoothness. The rail form of the floor sentence, in warning ink."],
    ["09-nose-stringer-floor", "5 · The stringer form. No preset reaches it at 1/2\", so this Shortboard was planed to 1 3/8\" at the center on ROCKER (its blank then stands 3/4\" at 12\" from the nose) and a Blended Nose Concave set to 1/2\": the floor holds the cut at the stringer, and the panel says where."],
    ["05-channels-six", "6 · CHANNELS inside TAIL, six on the Shortboard. Run and Longest on one row; Channel Width reads the ramp and the last wall off the rail (read out, never set); Start names the longest pair; Stagger names where the shortest pair starts."],
  ],
  [
    ["06-channels-squeezed", "7 · Eight asked at 4\": the set is squeezed to leave 1/2\" at the rail, and the Width label says what it was cut to — in the panel's own muted ink, never the warning colour."],
    ["07-run-menu-shortboard", "8 · Run on the Shortboard: Parallel, With the rail, Toe-in at the front fins' own toe."],
    ["08-run-longboard-820", "9a · The Longboard (a single fin) at an 820 window: Toe-in (no toe), cut with an ellipsis inside its box."],
    ["08-run-longboard-1280", "9b · The same at 1280: the column is wide enough and it reads whole."],
  ],
  [
    ["10-metric-center-double", "10 · Metric (the Fish): marks in whole millimetres, stations in centimetres, the Depth slider stopping at 12 mm."],
    ["11-metric-tail-channels", "11 · Metric: the Fish's Panel Vee with six channels — the rail sentence reads 6 mm, the channels' Width read-out in millimetres, Stagger in centimetres."],
  ],
];

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { margin: 0; padding: 28px 32px 36px; background: #f4f2ec; font: 14px/1.4 -apple-system, "Helvetica Neue", Arial, sans-serif; color: #1d2a33; }
  h1 { font-size: 22px; margin: 0 0 4px; letter-spacing: 0.04em; }
  .sub { color: #5b6770; margin-bottom: 22px; max-width: 1500px; }
  .row { display: flex; gap: 28px; align-items: flex-start; margin-bottom: 30px; }
  figure { margin: 0; background: #fff; border: 1px solid #d9d4c7; border-radius: 8px; padding: 12px; }
  figure img { display: block; }
  figcaption { margin-top: 10px; color: #33414b; font-size: 13px; }
</style></head><body>
<h1>BOTTOM — every row of every cut, and the CHANNELS block (plan 17-09)</h1>
<div class="sub">From the running app at 1280 wide (one shot at 820), the panel exactly as the founder's computer draws it. Every number is the app's own. Words in the two floor sentences are the executor's proposal — change any of them.</div>
${ROWS.map((row) => `<div class="row">${row.map(([name, caption]) => `<figure style="max-width:${name === "00-screen" ? 1290 : name.startsWith("08") || name.startsWith("07") || name.startsWith("06") ? 330 : 360}px"><img data-src="${name}" src="${img(name)}"><figcaption>${caption}</figcaption></figure>`).join("")}</div>`).join("")}
</body></html>`;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: 2 });
await page.setContent(html);
await page.evaluate(async () => {
  const imgs = [...document.querySelectorAll("img")];
  await Promise.all(imgs.map((im) => (im.complete ? null : new Promise((r) => (im.onload = r)))));
  for (const im of imgs) im.style.width = `${im.naturalWidth / 2}px`;
});
await page.screenshot({ path: OUT, fullPage: true });
await browser.close();
console.log("composed", OUT);

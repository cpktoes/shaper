// 17-09's pictures for the founder: the BOTTOM panel's rows and the CHANNELS block, from the worktree's own dev server
// (3309, never the founder's 3005), Chromium at 1280 wide, deviceScaleFactor 2. A taller window is used only where a card
// is longer than 800 dots, so the whole card fits in one picture; the panel is the same 320 dots wide either way.
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";

const OUT = process.argv[2];
mkdirSync(OUT, { recursive: true });
const BASE = "http://localhost:3309";
const ONLY = process.argv[3];
const want = (n) => !ONLY || ONLY.split(",").includes(String(n));
const browser = await chromium.launch();

async function newPage({ metric = false, height = 800, keepBoard = false } = {}) {
  const context = await browser.newContext({ viewport: { width: 1280, height }, deviceScaleFactor: 2 });
  await context.addInitScript(
    ([metricOn, keep]) => {
      sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
      if (metricOn) localStorage.setItem("shaper-units", "metric");
      if (!keep && !sessionStorage.getItem("keep-board")) localStorage.removeItem("shaper-open-board");
      // The stringer-form picture: the kept board's nose thinned to 7/8" at 12", written as the page loads — before
      // the app reads its kept copy and after the page that left wrote its own.
      if (sessionStorage.getItem("thin-nose")) {
        const raw = JSON.parse(localStorage.getItem("shaper-open-board"));
        raw.snapshot.design.foil.center = 34.925; // 1 3/8" at the center: the blank scales the nose to 3/4" at 12"
        localStorage.setItem("shaper-open-board", JSON.stringify(raw));
      }
    },
    [metric, keepBoard],
  );
  return context.newPage();
}

async function retry(fn, tries = 30) {
  let last;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  throw last;
}

async function openBottom(page, preset) {
  await page.goto(`${BASE}/`);
  const card = page.getByRole("button").filter({ hasText: "Start Shaping" }).filter({ hasText: preset }).first();
  await retry(async () => {
    if (!/\/design\/outline$/.test(page.url()) && (await card.count()) > 0) await card.click({ timeout: 3000 });
    await page.waitForURL(/\/design\/outline$/, { timeout: 5000 });
  });
  await page.locator("nav:not([aria-label])").getByRole("link", { name: "BOTTOM", exact: true }).click();
  await page.waitForURL("**/design/bottom");
  await page.locator("[data-bottom-card=center]").waitFor();
}

async function pickFrom(page, name, option) {
  const trigger = page.getByRole("combobox", { name, exact: true });
  const value = trigger.locator("[data-slot=select-value]");
  await retry(async () => {
    if ((await value.textContent()) === option) return;
    await trigger.click({ timeout: 3000 });
    await page.getByRole("option", { name: option, exact: true }).click({ timeout: 2000 });
    await page.waitForTimeout(300);
    if ((await value.textContent()) !== option) throw new Error(`${name} not ${option}`);
  });
  await page.keyboard.press("Escape").catch(() => {});
  await page.waitForTimeout(300);
}

async function press(page, slider, key, times = 1) {
  const s = page.getByRole("slider", { name: slider, exact: true });
  await s.focus();
  for (let i = 0; i < times; i++) await page.keyboard.press(key);
  await page.waitForTimeout(200);
}

async function shot(locator, file) {
  const p = locator.page();
  // the development server's own badge is not part of the app; nor is the focus ring a pick leaves behind
  await p.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await p.evaluate(() => document.activeElement instanceof HTMLElement && document.activeElement.blur());
  await locator.scrollIntoViewIfNeeded();
  await locator.page().mouse.move(0, 0);
  await locator.page().waitForTimeout(400);
  await locator.screenshot({ path: `${OUT}/${file}.png`, animations: "disabled" });
  console.log("shot", file);
}

const card = (page, s) => page.locator(`[data-bottom-card=${s}]`);

// 1. NOSE: the Teardrop, its tick box ticked. CENTER: an Early Double Concave (Off Stringer, Trough At).
if (want(1)) {
  const page = await newPage({ height: 1400 });
  await openBottom(page, "Shortboard");
  await pickFrom(page, "Nose Cut", "Teardrop Nose Concave");
  await shot(card(page, "nose"), "01-nose-teardrop");
  await pickFrom(page, "Center Cut", "Early Double Concave");
  await shot(card(page, "center"), "02-center-double");
  // the whole computer screen once, so the panel is seen beside its drawings
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.waitForTimeout(600);
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await page.evaluate(() => document.activeElement instanceof HTMLElement && document.activeElement.blur());
  await page.mouse.move(0, 0);
  await page.screenshot({ path: `${OUT}/00-screen.png` });
  console.log("shot 00-screen");
  await page.context().close();
}

// 2. TAIL: the Mid-length's Spiral Vee (Vee Lift) — and its rail-form floor sentence on a fresh pick (D-42).
if (want(2)) {
  const page = await newPage({ height: 1400 });
  await openBottom(page, "Mid-length");
  await pickFrom(page, "Tail Cut", "Spiral Vee");
  await shot(card(page, "tail"), "03-tail-spiral-vee");
  await page.context().close();
}

// 3. The Fish's Panel Vee, fresh: the rail form (D-42, "Warn, keep the numbers").
if (want(3)) {
  const page = await newPage({ height: 1400 });
  await openBottom(page, "Fish");
  await pickFrom(page, "Tail Cut", "Panel Vee");
  await shot(card(page, "tail"), "04-tail-fish-panel-vee");
  await page.context().close();
}

// 4. The CHANNELS block, six channels on the Shortboard: Run and Longest on one row, the Width read-out, Stagger.
if (want(4)) {
  const page = await newPage({ height: 2000 });
  await openBottom(page, "Shortboard");
  await pickFrom(page, "Channels", "6 channels");
  await shot(page.locator("[data-bottom-channels]"), "05-channels-six");
  // eight asked at 4": squeezed, the Width label says what it was cut to
  await pickFrom(page, "Channels", "8 channels");
  await press(page, "Channel Width", "End");
  await shot(page.locator("[data-bottom-channel-width]"), "06-channels-squeezed");
  // the Run menu open on the Shortboard
  await page.getByRole("combobox", { name: "Channel Run", exact: true }).click();
  await page.waitForTimeout(500);
  const runBox = await page.getByRole("combobox", { name: "Channel Run", exact: true }).boundingBox();
  const list = await page.getByRole("listbox").boundingBox();
  const clip = {
    x: Math.min(runBox.x, list.x) - 8,
    y: Math.min(runBox.y, list.y) - 8,
    width: Math.max(runBox.x + runBox.width, list.x + list.width) - Math.min(runBox.x, list.x) + 16,
    height: Math.max(runBox.y + runBox.height, list.y + list.height) - Math.min(runBox.y, list.y) + 16,
  };
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await page.screenshot({ path: `${OUT}/07-run-menu-shortboard.png`, clip });
  console.log("shot 07-run-menu-shortboard");
  await page.keyboard.press("Escape");
  await page.context().close();
}

// 5. The Longboard (a single fin): Toe-in (no toe), cut with an ellipsis at an 820 window and whole at 1280.
for (const width of want(5) ? [820, 1280] : []) {
  const page = await newPage({ height: 1600 });
  await page.setViewportSize({ width, height: 1600 });
  await openBottom(page, "Longboard");
  await pickFrom(page, "Channels", "6 channels");
  await pickFrom(page, "Channel Run", "Toe-in (no toe)");
  const row = page.locator("[data-bottom-channels] .grid").first();
  await shot(row, `08-run-longboard-${width}`);
  await page.context().close();
}

// 6. The stringer form: a concave the 1/4" floor holds. No preset reaches it at 1/2" (17-05), so the Shortboard's nose
//    centre is planed to 1 3/8" in its kept copy (ROCKER's centre thickness; the blank scales the nose to 3/4" at 12")
//    and a Blended Nose Concave set to 1/2".
if (want(6)) {
  const page = await newPage({ height: 1400, keepBoard: true });
  await openBottom(page, "Shortboard");
  await page.waitForTimeout(1500);
  await page.evaluate(() => {
    sessionStorage.setItem("keep-board", "1");
    sessionStorage.setItem("thin-nose", "1");
  });
  await page.goto(`${BASE}/design/bottom`);
  // the board as thinned, read back from its kept copy
  console.log("center thickness in the kept copy (mm)", await page.evaluate(() => JSON.parse(localStorage.getItem("shaper-open-board")).snapshot.design.foil.center));
  await page.locator("[data-bottom-card=nose]").waitFor();
  await page.waitForTimeout(1000);
  await pickFrom(page, "Nose Cut", "Blended Nose Concave");
  await press(page, "Nose Depth", "End");
  await page.waitForTimeout(500);
  await shot(card(page, "nose"), "09-nose-stringer-floor");
  await page.context().close();
}

// 7. Metric: the Early Double on the Shortboard, and the Fish's Panel Vee warning, in Metric.
if (want(7)) {
  const page = await newPage({ metric: true, height: 1400 });
  await openBottom(page, "Fish");
  await pickFrom(page, "Center Cut", "Early Double Concave");
  await shot(card(page, "center"), "10-metric-center-double");
  await pickFrom(page, "Tail Cut", "Panel Vee");
  await pickFrom(page, "Channels", "6 channels");
  await shot(card(page, "tail"), "11-metric-tail-channels");
  await page.context().close();
}

await browser.close();

const W = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbbf20aa4e7ccee0/lib/geometry";
const { phase16Boards } = await import(`${W}/__fixtures__/phase16-boards.ts`);
const B = await import(`${W}/bottom.ts`);
const D = await import(`${W}/design.ts`);
const { buildOutline } = await import(`${W}/outline.ts`);
const { boardSections } = await import(`${W}/volume.ts`);
const fields = phase16Boards().find((b: any) => b.label.startsWith("shortboard|asis|")).fields;
const geometry = buildOutline(fields.outline);
const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
const board = D.designBottomBoard(fields.outline, geometry, profile, D.designFinPlacement(fields));
const bottom = structuredClone(B.DEFAULT_BOTTOM);
bottom.nose = B.startingCut("nose", "Teardrop Nose Concave", board);
bottom.center = B.startingCut("center", "Early Double Concave", board);
bottom.tail = B.startingCut("tail", "Spiral Vee", board);
bottom.channels = B.startingChannels(6, board, bottom.channels);
const sections = boardSections(D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }));
const r = B.resolveBottom(bottom, board);
for (let k = 0; k < 3; k++) {
  const t = performance.now();
  B.bottomFloorFlags(r, board, sections);
  console.log("bottomFloorFlags ms", (performance.now() - t).toFixed(1));
}
let t = performance.now();
boardSections(D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }));
console.log("boardSections ms", (performance.now() - t).toFixed(1));

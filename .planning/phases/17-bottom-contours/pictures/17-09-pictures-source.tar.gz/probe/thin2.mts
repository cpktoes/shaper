const W = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbbf20aa4e7ccee0/lib/geometry";
const { phase16Boards } = await import(`${W}/__fixtures__/phase16-boards.ts`);
const B = await import(`${W}/bottom.ts`);
const D = await import(`${W}/design.ts`);
const { buildOutline } = await import(`${W}/outline.ts`);
const { boardSections } = await import(`${W}/volume.ts`);
const { inchesToMm, formatInchesFraction, mm } = await import(`${W}/units.ts`);
const base = phase16Boards().find((b: any) => b.label.startsWith("shortboard|asis|")).fields;
const variants: [string, any][] = [
  ["nose12 only", { ...base, foil: { ...base.foil, nose12: inchesToMm(0.875) } }],
  ["noseTip only", { ...base, foil: { ...base.foil, noseTip: inchesToMm(0.25) } }],
  ["center only 1.375", { ...base, foil: { ...base.foil, center: inchesToMm(1.375) } }],
  ["no blank + nose12", { ...base, blank: null, foil: { ...base.foil, nose12: inchesToMm(0.875) } }],
];
for (const [label, fields] of variants) {
  const geometry = buildOutline(fields.outline);
  const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
  const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = D.designBottomBoard(fields.outline, geometry, profile, D.designFinPlacement(fields));
  for (const [section, name] of [["nose", "Blended Nose Concave"], ["nose", "Teardrop Nose Concave"], ["center", "Deep Single Concave"], ["tail", "Extending Single Concave"]] as const) {
    const bottom = structuredClone(B.DEFAULT_BOTTOM);
    bottom[section] = { ...B.startingCut(section, name, board), depth: inchesToMm(0.5) };
    const sections = boardSections(D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }));
    const fl = B.bottomFloorFlags(B.resolveBottom(bottom, board), board, sections);
    console.log(label, "|", name, "| thick@12 from nose", formatInchesFraction(mm(board.thicknessAt(mm(board.length - inchesToMm(12))))), "|", fl.map((x: any) => `${x.section} s${x.stringer.length} r${x.rails.length}`).join("; "));
  }
}

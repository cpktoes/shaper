const W = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbbf20aa4e7ccee0/lib/geometry";
const { phase16Boards } = await import(`${W}/__fixtures__/phase16-boards.ts`);
const B = await import(`${W}/bottom.ts`);
const D = await import(`${W}/design.ts`);
const { buildOutline } = await import(`${W}/outline.ts`);
const { BOARD_PRESETS } = await import(`${W}/presets.ts`);
const { boardSections } = await import(`${W}/volume.ts`);
const { inchesToMm, formatInchesFraction, mm } = await import(`${W}/units.ts`);
const all = phase16Boards();
for (const preset of BOARD_PRESETS) {
  const label = `${preset.id}|asis|${preset.rails.tailHardEdge ? "hard" : "soft"}`;
  const fields = all.find((b: any) => b.label === label).fields;
  const geometry = buildOutline(fields.outline);
  const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
  const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = D.designBottomBoard(fields.outline, geometry, profile, D.designFinPlacement(fields));
  console.log(preset.id, "toe", board.toeDegrees, board.toeDegrees.toFixed(1), "len", formatInchesFraction(board.length));
  const flagsFor = (bottom: any) => B.bottomFloorFlags(B.resolveBottom(bottom, board), board, boardSections(D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board })));
  const show = (fl: any[]) => fl.map((x) => `${x.section} s${x.stringer.length} r${x.rails.length} at ${x.at == null ? "-" : formatInchesFraction(mm(x.at))}`).join("; ");
  for (const section of B.BOTTOM_SECTIONS) for (const name of B.BOTTOM_CUT_NAMES[section]) {
    if (B.cutKind(name) === "flat") continue;
    const bottom = structuredClone(B.DEFAULT_BOTTOM);
    bottom[section] = B.startingCut(section, name, board);
    const f = flagsFor(bottom);
    const bottom2 = structuredClone(bottom);
    bottom2[section] = { ...bottom2[section], depth: inchesToMm(0.5) };
    const f2 = flagsFor(bottom2);
    if (f.length || f2.length) console.log("  ", name, "| start:", show(f), "| at 1/2:", show(f2));
  }
  for (const count of [4, 6, 8] as const) {
    const bottom = structuredClone(B.DEFAULT_BOTTOM);
    bottom.channels = B.startingChannels(count, board, bottom.channels);
    const ro = B.channelReadout(B.resolveChannels(bottom.channels, board), board, "narrowest");
    console.log("   ch", count, "w", formatInchesFraction(ro.width), "fit", formatInchesFraction(ro.fittedWidth), ro.squeezed, "ramp", ro.rampDegrees, "last", formatInchesFraction(ro.lastWallOffRail), "short", formatInchesFraction(ro.shortestStart), "flags", show(flagsFor(bottom)));
  }
}

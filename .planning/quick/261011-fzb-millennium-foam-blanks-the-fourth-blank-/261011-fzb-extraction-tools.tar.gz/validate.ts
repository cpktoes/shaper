import { readFileSync } from "node:fs";
import { parseCsv } from "/Users/kontoes/Code/shaper/lib/blanks/csv";
import { rowsToBlankRecords, isPickable, isWellFormedBlankRecord } from "/Users/kontoes/Code/shaper/lib/blanks/catalog";
import { prepareBlank } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { mmToInches } from "/Users/kontoes/Code/shaper/lib/geometry/units";
const file = process.argv[2];
const records = rowsToBlankRecords(parseCsv(readFileSync(file, "utf8")), "millennium_foam_stations.csv");
console.log("records", records.length);
let pickable = 0, wellFormed = 0, prepared = 0;
const problems: string[] = [];
for (const r of records) {
  if (isPickable(r)) pickable++; else problems.push(`not pickable: ${r.name}`);
  if (isWellFormedBlankRecord(r)) wellFormed++; else problems.push(`not well formed: ${r.name}`);
  try { prepareBlank(r); prepared++; } catch (e) { problems.push(`prepare failed: ${r.name}: ${(e as Error).message}`); }
  const names = new Set(records.filter((o) => o.name === r.name));
  if (names.size > 1) problems.push(`duplicate name ${r.name}`);
}
console.log({ pickable, wellFormed, prepared, problems });
const longest = records.reduce((a, b) => (b.lengthMm > a.lengthMm ? b : a));
const shortest = records.reduce((a, b) => (b.lengthMm < a.lengthMm ? b : a));
console.log("longest", longest.name, mmToInches(longest.lengthMm), "shortest", shortest.name, mmToInches(shortest.lengthMm));
console.log("stations per blank", [...new Set(records.map((r) => r.stations.length))]);
console.log("example", JSON.stringify(records.find((r) => r.name === `6'1"DG`), null, 0).slice(0, 700));

import sys
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
import pypdf
r = pypdf.PdfReader(sys.argv[1])
print('pages', len(r.pages))
for i in range(len(r.pages)):
    p = r.pages[i]
    t = p.extract_text() or ''
    try:
        imgs = [(im.name, im.image.size) for im in p.images]
    except Exception as e:
        imgs = ['err', str(e)[:60]]
    mb = p.mediabox
    print('=== page', i+1, 'size', float(mb.width), float(mb.height), 'imgs', imgs[:4], 'chars', len(t))
    print(t[:700].replace('\n',' | '))

import json, re
from fractions import Fraction
b = json.load(open('blanks.json'))
ORDER_OUT = ['T0','T12','T24','T48','C','N48','N24','N12','N0']
POINTED = {'25','65','71'}   # fish / gun noses that come to a point: no nose-tip width printed
ROUNDED = set()
# typos settled by the centimetre line (and the neighbouring stations)
OVERRIDE = {
    ('22','N12','thickness'): (Fraction(35,16), 'thickness: catalog prints 2 13/16" but 5.55 cm here; used the cm value (2 3/16"), which fits the 12" and 24" stations either side'),
    ('52','T24','thickness'): (Fraction(49,16), 'thickness: catalog prints "3 1/6"" (no such fraction) but 7.77 cm here; used the cm value (3 1/16")'),
    ('66','T0','thickness'):  (Fraction(3,2),   'thickness: catalog prints "1 1/3"" (no such fraction) but 3.81 cm here; used the cm value (1 1/2")'),
}
EXTRA_NOTES = {
    ('22','C'): 'catalog\'s Max Width line prints 20 3/4"; this station prints 20 9/16" (52.23 cm) and is used',
    ('41','C'): 'catalog\'s Max Width line prints 21 1/2"; this station prints 21 15/16" (55.72 cm) and is used',
    ('54','C'): 'catalog\'s Max Thickness line prints 3 5/16"; this station prints 3 3/8" (8.57 cm) and is used',
    ('60','C'): 'catalog\'s Max Width line prints 22 5/16"; this station prints 22 1/4" (56.51 cm) and is used',
    ('67','C'): 'catalog\'s Max Thickness line prints 3 1/2"; this station prints 3 3/4" (9.52 cm) and is used',
    ('46','T0'): 'length: catalog prints a tip-to-tip deck of 7\'9 3/8" against a 7\'9" bottom length; both kept as printed',
    ('47','T0'): 'length: catalog prints a tip-to-tip deck of 7\'9 3/8" against a 7\'9" bottom length; both kept as printed',
    ('61','T12'): 'thickness: catalog prints 2 7/8" in both units here, though the thicker 9\'4"MT prints 2 9/16" at this station',
}
def dec(x):
    f = Fraction(x).limit_denominator(64)
    s = f"{float(f):.6f}".rstrip('0').rstrip('.')
    return s if '.' in s else s + '.0'
def frac_txt(x):
    f = Fraction(x).limit_denominator(64); w = f.numerator // f.denominator; r = f - w
    return (f"{w} {r}" if w and r else (str(w) if not r else str(r))) + '"'
def slug(name):
    m = re.match(r"(\d+)'(\d+)\"(.*)", name)
    return f"{m.group(1)}{m.group(2)}{m.group(3)}"
rows = []
summary = []
for pn in sorted(b, key=int):
    r = b[pn]; name = r['name']
    L = Fraction(r['bottom_in']).limit_denominator(64); D = Fraction(r['deck_in']).limit_denominator(64)
    pos = {'T0': 0, 'T12': 12, 'T24': 24, 'T48': 48, 'C': L/2, 'N48': L-48, 'N24': L-24, 'N12': L-12, 'N0': L}
    nflags = 0
    for lab in ORDER_OUT:
        st = r['stations'].get(lab)
        if st is None: continue
        vals = {}; flags = []
        for field in ('rocker','thickness','width'):
            c = st[field]
            key = (pn, lab, field)
            if key in OVERRIDE:
                vals[field] = OVERRIDE[key][0]; flags.append(OVERRIDE[key][1]); continue
            if c is None:
                vals[field] = None; continue
            v = Fraction(c['in']).limit_denominator(64)
            vals[field] = v
            if c['cm'] is not None and c['mismatch']:
                cm_in = c['cm']/2.54
                if abs(cm_in - float(v)) >= 0.06:
                    flags.append(f"{field}: catalog prints {frac_txt(v)} but {c['cm']:g} cm here; used the inch value")
        if lab == 'N0' and vals['width'] is None:
            if pn in POINTED:
                vals['width'] = Fraction(1)
                flags.append('width 1": pointed nose, not printed in catalog; 1" stands in for the point (0 is kept for a rounded nose)')
            else:
                vals['width'] = Fraction(0)
                flags.append('width 0: rounded nose, not printed in catalog')
        if lab in ('N24','T24') and vals['width'] is None and r['labels'] == ['12','0','12']:
            flags.append('width not printed at this station; the catalog draws only the 12" and centre stations on this blank')
        if (pn, lab) in EXTRA_NOTES: flags.append(EXTRA_NOTES[(pn, lab)])
        if lab == 'C': assert vals['rocker'] == 0, (pn, lab)
        nflags += len(flags)
        rows.append(['Millennium Foam', name, lab, dec(pos[lab]), '' if vals['rocker'] is None else dec(vals['rocker']), '' if vals['thickness'] is None else dec(vals['thickness']), '' if vals['width'] is None else dec(vals['width']), dec(L), dec(D), '' if r['volume_l'] is None else f"{r['volume_l']:g}", slug(name), pn, '; '.join(flags)])
    summary.append((name, pn, float(L), r['volume_l'], len(r['stations']), nflags))
def q(s):
    return '"' + s.replace('"', '""') + '"' if any(ch in s for ch in ',"\n') else s
header = 'vendor,blank_name,station,station_in_from_tail,rocker_in,thickness_in,width_in,length_in,deck_length_in,volume_l,catalog_slug,pdf_page,flag'
lines = [header] + [','.join(q(str(c)) for c in row) for row in rows]
open('millennium_foam_stations.csv', 'w', newline='').write('\r\n'.join(lines) + '\r\n')
print('rows', len(rows), 'blanks', len(summary), 'flags', sum(s[5] for s in summary))
for s in summary: print(f"  {s[0]:<9} p{s[1]:<3} {s[2]:>8.4f}in {str(s[3]):>7} L  stations={s[4]} flags={s[5]}")

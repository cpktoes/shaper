import sys, os, json, subprocess
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
from PIL import Image, ImageDraw
b = json.load(open('blanks.json'))
pdf = "/Users/kontoes/Downloads/MILL FULL CATALOG 2024 VR 9.27_opt.pdf"
cells = [c.split(':') for c in sys.argv[1].split(',')]   # page:station:field
out = sys.argv[2]
tiles = []
for pn, st, field in cells:
    c = b[pn]['stations'][st][field]
    x0, x1, y = c['pos']
    png = f'p{pn}.png'
    if not os.path.exists(png): subprocess.run(['./render', pdf, pn, '1.5', png], check=True, capture_output=True)
    im = Image.open(png); s = im.width/612.0; H = im.height
    cx = (x0+x1)/2
    box = (int((cx-45)*s), int(H-(y+16)*s), int((cx+45)*s), int(H-(y-16)*s))
    crop = im.crop(box).resize((540, 192))
    d = ImageDraw.Draw(crop); d.rectangle((0,0,230,14), fill='white'); d.text((2,1), f"p{pn} {b[pn]['name']} {st} {field}: read {c['txt']} cm={c['cm']}", fill='red')
    tiles.append(crop)
cols = 3; w, h = tiles[0].size; rows = (len(tiles)+cols-1)//cols
sheet = Image.new('RGB', (cols*w, rows*h), 'white')
for i, t in enumerate(tiles): sheet.paste(t, ((i%cols)*w, (i//cols)*h))
sheet.save(out); print(out, sheet.size)

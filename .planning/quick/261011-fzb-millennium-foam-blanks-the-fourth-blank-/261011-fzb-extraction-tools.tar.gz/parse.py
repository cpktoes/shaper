import json, re, sys
from fractions import Fraction
frags = json.load(open('frags.json'))

INCH = re.compile(r'^(?:(\d+)\s+)?(?:(\d+)\s*/\s*(\d+))?\s*(?:["”“″]|\'\')?$|^(\d+)\s*(?:["”“″])?$')
CM = re.compile(r'^\(\s*(\d*\.?\d+)\s*CM\s*\)$', re.I)

def inch_value(s):
    s = s.strip().replace('”','"').replace('“','"').replace('″','"')
    m = re.fullmatch(r'(?:(\d+)\s+)?(\d+)\s*/\s*(\d+)\s*"?', s)
    if m:
        whole = int(m.group(1)) if m.group(1) else 0
        return whole + Fraction(int(m.group(2)), int(m.group(3)))
    m = re.fullmatch(r'(\d+)\s*"?', s)
    if m:
        return Fraction(int(m.group(1)))
    return None

def cm_value(s):
    m = CM.match(s.strip())
    return float(m.group(1)) if m else None

TOKEN = re.compile(r'(?:\d+\s+)?\d+\s*/\s*\d+\s*["”“″]?|\d+\s*["”“″]|\bM\b|\b0\b|\(\s*\d*\.?\d+\s*CM\s*\)', re.I)

def tokens(f):
    """Split a fragment into label tokens with estimated x spans."""
    text = f['text']
    out = []
    width = max(f['displaced_tx'] - f['tx'], 1)
    n = max(len(text), 1)
    for m in TOKEN.finditer(text):
        tok = m.group(0).strip()
        x0 = f['tx'] + width * m.start() / n
        x1 = f['tx'] + width * m.end() / n
        out.append({'t': tok, 'x0': round(x0,1), 'x1': round(x1,1), 'y': f['ty'], 'h': f['font_height'], 'src': text})
    return out

def parse_feet(s):
    # "6' 1 11/16"" or "9’ 3 3/4”" or "7 11 5/16"" (missing foot mark) or "8' 5 3/16"
    s = s.replace('’', "'").replace('”','"').replace('“','"').replace('″','"').strip()
    m = re.match(r"(\d+)\s*['\s]\s*(\d+)?\s*(\d+\s*/\s*\d+)?\s*\"?\s*$", s)
    if not m: return None
    ft = int(m.group(1)); inch = int(m.group(2)) if m.group(2) else 0
    frac = Fraction(re.sub(r'\s','',m.group(3))) if m.group(3) else Fraction(0)
    return ft*12 + inch + frac

def parse_page(pn, fs):
    page = {'page': pn, 'notes': []}
    big = [f for f in fs if f['font_height'] > 30]
    page['name'] = big[0]['text'].strip() if big else None
    # headline
    head_x = None
    hl = {}
    allf = sorted(fs, key=lambda f: (-f['ty'], f['tx']))
    for i, f in enumerate(allf):
        t = f['text'].strip()
        m = re.match(r'(Bottom Length|Tip To Tip Deck|Tip To Tip Length|Tip to Tip Deck|Tip to tip deck|Bottom length|Max Width|Max width|Max Thickness|Max thickness|Volume)\s*:\s*(.*)$', t)
        if not m: continue
        key = m.group(1).lower()
        rest = m.group(2).strip()
        if key.startswith('bottom'): head_x = f['tx'] if head_x is None else min(head_x, f['tx'])
        # cm may be inline or in a following fragment
        cm = None
        mcm = re.search(r'\(\s*(\d*\.?\d+)\s*h?\s*CM\s*\)', rest, re.I)
        if mcm:
            cm = float(mcm.group(1)); rest = rest[:mcm.start()].strip()
        else:
            for g in allf[i+1:i+4]:
                mm = re.search(r'\(\s*(\d*\.?\d+)\s*h?\s*CM\s*\)', g['text'], re.I)
                if mm and abs(g['ty'] - f['ty']) < 16 and re.fullmatch(r'\s*\(.*\)\s*', g['text']):
                    cm = float(mm.group(1)); break
        if key == 'volume':
            mv = re.match(r'(\d*\.?\d+)\s*L', rest)
            hl['volume'] = float(mv.group(1)) if mv else rest
        elif key.startswith('bottom'):
            hl['bottom_in'] = parse_feet(rest); hl['bottom_cm'] = cm; hl['bottom_raw'] = rest
        elif key.startswith('tip'):
            hl['deck_in'] = parse_feet(rest); hl['deck_cm'] = cm; hl['deck_raw'] = rest; hl['deck_label'] = m.group(1)
        elif key.startswith('max w'):
            hl['maxw_in'] = inch_value(rest); hl['maxw_cm'] = cm; hl['maxw_raw'] = rest
        elif key.startswith('max t'):
            hl['maxt_in'] = inch_value(rest); hl['maxt_cm'] = cm; hl['maxt_raw'] = rest
    page['headline'] = hl
    if head_x is None:
        page['notes'].append('no Bottom Length headline found')
        head_x = 190.0
    # label tokens (exclude headline/body text fragments: those start at head_x and are long)
    toks = []
    for f in fs:
        t = f['text'].strip()
        if f['font_height'] > 30: continue
        if f['tx'] >= head_x - 2 and f['tx'] <= head_x + 60 and len(t) > 8 and not CM.match(t):
            continue  # headline / body text
        if re.search(r'[A-Za-z]{3,}', t) and not CM.match(t): continue
        toks.extend(tokens(f))
    # classify
    inch_toks = [t for t in toks if not CM.match(t['t'])]
    cm_toks = [t for t in toks if CM.match(t['t'])]
    # pair each inch token with a cm token: below (dy 7..14, x overlap) or same line immediately right
    def pair(it):
        best = None
        for c in cm_toks:
            dy = it['y'] - c['y']
            xc_i = (it['x0']+it['x1'])/2; xc_c = (c['x0']+c['x1'])/2
            if 6 <= dy <= 14 and abs(xc_i - xc_c) < 22:
                d = abs(xc_i - xc_c)
                if best is None or d < best[0]: best = (d, c)
            elif abs(dy) < 3 and 0 <= c['x0'] - it['x1'] < 12:
                best = (0, c)
        return best[1] if best else None
    for it in inch_toks:
        it['v'] = inch_value(it['t']) if it['t'] not in ('M',) else None
        c = pair(it)
        it['cm'] = cm_value(c['t']) if c else None
    side = [t for t in inch_toks if t['x0'] > head_x + 150]
    top = [t for t in inch_toks if t['x0'] <= head_x + 150]
    # top view: widths have cm partners, station labels do not (and are 12/24/0/M)
    station_lbl = [t for t in top if t['cm'] is None and t['t'].rstrip('"”“') in ('12','24','0','M')]
    widths = [t for t in top if t['cm'] is not None]
    others = [t for t in top if t['cm'] is None and t not in station_lbl]
    if others: page['notes'].append('unpaired top-view labels: ' + ', '.join(f"{o['t']}@({o['x0']:.0f},{o['y']:.0f})" for o in others))
    widths.sort(key=lambda t: -t['y'])
    station_lbl.sort(key=lambda t: -t['y'])
    page['station_labels'] = [t['t'] for t in station_lbl]
    page['widths'] = widths
    # side view: split by x gap into rocker (left) and thickness (right)
    side.sort(key=lambda t: t['x0'])
    rock, thick = [], []
    if side:
        xs = [ (t['x0']+t['x1'])/2 for t in side]
        # largest gap
        srt = sorted(side, key=lambda t: (t['x0']+t['x1'])/2)
        gaps = [((srt[i+1]['x0']+srt[i+1]['x1'])/2 - (srt[i]['x0']+srt[i]['x1'])/2, i) for i in range(len(srt)-1)]
        if gaps:
            g, i = max(gaps)
            split = ((srt[i]['x0']+srt[i]['x1'])/2 + (srt[i+1]['x0']+srt[i+1]['x1'])/2)/2
            rock = [t for t in side if (t['x0']+t['x1'])/2 < split]
            thick = [t for t in side if (t['x0']+t['x1'])/2 >= split]
    rock.sort(key=lambda t: -t['y']); thick.sort(key=lambda t: -t['y'])
    page['rocker'] = rock; page['thickness'] = thick
    return page

pages = {}
for pn in sorted(int(k) for k in frags):
    pages[pn] = parse_page(pn, frags[str(pn)])

def fmt(t):
    if t is None: return '   -   '
    v = t.get('v'); cm = t.get('cm')
    s = t['t'].replace('”','"').replace('“','"')
    ok = ''
    if v is not None and cm is not None:
        ok = 'ok' if abs(float(v)*2.54 - cm) < 0.035 else f'!!{float(v)*2.54:.2f}'
    return f"{s:>9} {('('+str(cm)+')') if cm is not None else '':>9} {ok:<8}"

for pn, p in pages.items():
    hl = p['headline']
    print(f"=== page {pn}  name={p['name']!r}  stations={p['station_labels']}  bottom={hl.get('bottom_raw')!r}->{hl.get('bottom_in')} cm={hl.get('bottom_cm')}  deck={hl.get('deck_raw')!r}->{hl.get('deck_in')} cm={hl.get('deck_cm')}  maxW={hl.get('maxw_in')}/{hl.get('maxw_cm')} maxT={hl.get('maxt_in')}/{hl.get('maxt_cm')} vol={hl.get('volume')}")
    for n in p['notes']: print('   NOTE', n)
    W, R, T = p['widths'], p['rocker'], p['thickness']
    print(f"   counts: widths={len(W)} rocker={len(R)} thickness={len(T)}")
    for i in range(max(len(W), len(R), len(T))):
        w = W[i] if i < len(W) else None; r = R[i] if i < len(R) else None; t = T[i] if i < len(T) else None
        print(f"   {i}: W {fmt(w)} | R {fmt(r)} | T {fmt(t)}")
json.dump({pn: {k: v for k, v in p.items()} for pn, p in pages.items()}, open('parsed.json','w'), default=str)

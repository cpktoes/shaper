import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import json, re
from fractions import Fraction
import parse3
from parse3 import norm, inch_value, CM_RE, ROW_ORDER
pages = parse3.pages

STATION_SETS = {3: ['N12','C','T12'], 5: ['N12','N24','C','T24','T12'], 7: ['N12','N24','N48','C','T48','T24','T12']}
NAME_LIKE = re.compile(r"\d+['’]\s*\d+\s*[\"”][A-Z]")

def fix_widths(p):
    # recompute from the raw tokens kept in p['widths'] values + unplaced notes is awkward; redo from frags
    pass

# Re-run the top-view assignment with the x-based rule, using parse3's tokeniser on the page fragments
frags = parse3.frags
def top_view(pn, p):
    ms = parse3.merge_lines(frags[str(pn)])
    head_x = p['head_x']
    toks = []
    for m in ms:
        if m['h'] > 30: continue
        if NAME_LIKE.search(m['raw']):
            m = dict(m); m['raw'] = NAME_LIKE.sub(lambda mm: ' '*len(mm.group(0)), m['raw'])
        toks.extend(parse3.tokens(m))
    inch_toks = [t for t in toks if not CM_RE.fullmatch(t['t'])]
    cm_toks = [t for t in toks if CM_RE.fullmatch(t['t']) and not (head_x - 5 <= t['x0'] < head_x + 200)]
    top = [t for t in inch_toks if not (t['x1'] > head_x + 160 and t['x0'] > head_x + 100)]
    for it in top:
        it['v'] = inch_value(it['t']) if it['t'] != 'M' else None
        best = None
        for c in cm_toks:
            dy = it['y'] - c['y']; xc_i = (it['x0']+it['x1'])/2; xc_c = (c['x0']+c['x1'])/2
            if 6 <= dy <= 14 and abs(xc_i - xc_c) < 24:
                if best is None or abs(xc_i-xc_c) < best[0]: best = (abs(xc_i-xc_c), c)
            elif abs(dy) < 3 and -2 <= c['x0'] - it['x1'] < 14: best = (0, c)
        it['cm'] = float(CM_RE.fullmatch(best[1]['t']).group(1)) if best else None
    is_station_val = lambda t: norm(t['t']).rstrip('"') in ('12','24','36','48','0','M')
    labels = [t for t in top if is_station_val(t) and t['x0'] > 120]
    rest = [t for t in top if t not in labels]
    tips = sorted([t for t in rest if t['x0'] >= 60], key=lambda t: -t['y'])
    stw = sorted([t for t in rest if t['x0'] < 60], key=lambda t: -t['y'])
    notes = []
    wmap = {}
    names = STATION_SETS.get(len(stw))
    if names is None:
        notes.append(f'station widths={len(stw)}: ' + ', '.join(f"{t['t']}@({t['x0']:.0f},{t['y']:.0f})" for t in stw))
    else:
        for n, t in zip(names, stw): wmap[n] = t
    if len(tips) == 2: wmap['N0'], wmap['T0'] = tips
    elif len(tips) == 1:
        # one tip label: nose if above the first station width, tail if below the last
        if stw and tips[0]['y'] > stw[0]['y']: wmap['N0'] = tips[0]; notes.append('no tail tip width label')
        else: wmap['T0'] = tips[0]; notes.append('no nose tip width label (rounded nose)')
    else:
        notes.append(f'tips={len(tips)}: ' + ', '.join(f"{t['t']}@({t['x0']:.0f},{t['y']:.0f})" for t in tips))
    # sanity: station labels found vs expected
    lab_vals = [norm(t['t']).rstrip('"') for t in sorted(labels, key=lambda t: -t['y'])]
    return wmap, notes, lab_vals

for pn, p in pages.items():
    wmap, notes, labs = top_view(pn, p)
    p['widths'] = wmap; p['notes'] = [n for n in p['notes'] if not n.startswith('width unplaced')] + notes
    p['labels'] = labs

def f(v): return None if v is None else float(v)
def mismatch(t):
    if t is None or t.get('v') is None or t.get('cm') is None: return False
    return abs(float(t['v'])*2.54 - t['cm']) >= 0.035

MANUAL_CM = {(35, 'N0', 'thickness'): 3.33}
out = {}
for pn, p in pages.items():
    hl = p['headline']
    rec = {'page': pn, 'name': p['name'], 'bottom_in': f(hl.get('bottom')), 'deck_in': f(hl.get('deck')), 'maxw_in': f(hl.get('maxw')), 'maxt_in': f(hl.get('maxt')), 'volume_l': hl.get('volume'), 'stations': {}, 'notes': p['notes'], 'labels': p['labels']}
    for lab in ['N0','N12','N24','N48','C','T48','T24','T12','T0']:
        w = p['widths'].get(lab); r = p['rocker'].get(lab); t = p['thickness'].get(lab)
        if w is None and r is None and t is None: continue
        rec['stations'][lab] = {
            'width': None if w is None else {'in': f(w['v']), 'txt': norm(w['t']), 'cm': w['cm'], 'mismatch': mismatch(w), 'pos': [w['x0'], w['x1'], w['y']]},
            'rocker': None if r is None else {'in': f(r['v']) if r['t'] != 'M' else 0.0, 'txt': norm(r['t']), 'cm': r['cm'], 'mismatch': mismatch(r), 'pos': [r['x0'], r['x1'], r['y']]},
            'thickness': None if t is None else {'in': f(t['v']), 'txt': norm(t['t']), 'cm': t['cm'], 'mismatch': mismatch(t), 'pos': [t['x0'], t['x1'], t['y']]},
        }
    for (mp, ml, mf), mcm in MANUAL_CM.items():
        if mp == pn and ml in rec['stations'] and rec['stations'][ml][mf]:
            c = rec['stations'][ml][mf]; c['cm'] = mcm; c['mismatch'] = abs(c['in']*2.54 - mcm) >= 0.035
    out[pn] = rec
json.dump(out, open('blanks.json', 'w'), indent=1)

# ---- report
def show(c):
    if c is None: return '    -     '
    s = c['txt'].replace('"','')
    flag = '!' if c['mismatch'] else (' ' if c['cm'] is not None else '?')
    return f"{s:>8}{flag} "
print('page name        | station | width      | rocker     | thickness')
for pn, r in out.items():
    print(f"=== p{pn} {r['name']:<9} bottom={r['bottom_in']} deck={r['deck_in']} maxW={r['maxw_in']} maxT={r['maxt_in']} vol={r['volume_l']} labels={r['labels']}")
    for n in r['notes']: print('   NOTE', n)
    for lab, st in r['stations'].items():
        print(f"   {lab:>3}: W {show(st['width'])} R {show(st['rocker'])} T {show(st['thickness'])}")

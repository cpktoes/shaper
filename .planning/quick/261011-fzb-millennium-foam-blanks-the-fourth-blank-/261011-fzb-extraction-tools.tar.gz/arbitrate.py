import json
from fractions import Fraction
b = json.load(open('blanks.json'))
ORDER = ['N0','N12','N24','N48','C','T48','T24','T12','T0']
def frac16(x):
    f = Fraction(x).limit_denominator(32)
    return f"{f.numerator//f.denominator} {f - f.numerator//f.denominator}".replace(' 0','').strip() if f.denominator > 1 else str(int(f))
rows = []
for pn, r in b.items():
    labs = [l for l in ORDER if l in r['stations']]
    for i, lab in enumerate(labs):
        st = r['stations'][lab]
        for field in ('width','rocker','thickness'):
            c = st[field]
            if c is None: continue
            if c['mismatch'] or c['cm'] is None and field != 'rocker' and not (field=='width' and lab in ('N0','T0')):
                prev = r['stations'][labs[i-1]][field] if i > 0 else None
                nxt = r['stations'][labs[i+1]][field] if i+1 < len(labs) else None
                pv = prev['txt'] if prev else '-'; nv = nxt['txt'] if nxt else '-'
                cm_in = None if c['cm'] is None else c['cm']/2.54
                cm_frac = '' if cm_in is None else frac16(cm_in)
                # does the cm reading land on a clean 1/16?
                clean = '' if cm_in is None else ('clean' if abs(cm_in*16 - round(cm_in*16)) < 0.08 else 'off-grid')
                rows.append((int(pn), r['name'], lab, field, c['txt'], f"{float(c['in'])*2.54:.2f}" if c['in'] is not None else '?', c['cm'], cm_frac, clean, pv, nv))
print(f"{'pg':>3} {'name':<9} {'st':<4} {'field':<9} {'inch':>10} {'in→cm':>6} {'cm':>7} {'cm→in':>9} {'grid':<8} {'prev':>9} {'next':>9}")
for row in rows:
    print(f"{row[0]:>3} {row[1]:<9} {row[2]:<4} {row[3]:<9} {row[4]:>10} {row[5]:>6} {str(row[6]):>7} {row[7]:>9} {row[8]:<8} {row[9]:>9} {row[10]:>9}")
print(len(rows))

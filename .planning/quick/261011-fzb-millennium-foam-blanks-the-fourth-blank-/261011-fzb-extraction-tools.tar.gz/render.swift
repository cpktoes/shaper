import Foundation
import PDFKit
import AppKit
let args = CommandLine.arguments
let url = URL(fileURLWithPath: args[1])
let pageNo = Int(args[2])!
let scale = CGFloat(Double(args[3])!)
let outPath = args[4]
guard let doc = PDFDocument(url: url), let page = doc.page(at: pageNo - 1) else { print("no page"); exit(1) }
let bounds = page.bounds(for: .mediaBox)
let size = NSSize(width: bounds.width * scale, height: bounds.height * scale)
let img = NSImage(size: size)
img.lockFocus()
NSColor.white.setFill()
NSRect(origin: .zero, size: size).fill()
let ctx = NSGraphicsContext.current!.cgContext
ctx.saveGState()
ctx.scaleBy(x: scale, y: scale)
page.draw(with: .mediaBox, to: ctx)
ctx.restoreGState()
img.unlockFocus()
let rep = NSBitmapImageRep(data: img.tiffRepresentation!)!
let png = rep.representation(using: .png, properties: [:])!
try! png.write(to: URL(fileURLWithPath: outPath))
print("wrote", outPath, Int(size.width), Int(size.height))

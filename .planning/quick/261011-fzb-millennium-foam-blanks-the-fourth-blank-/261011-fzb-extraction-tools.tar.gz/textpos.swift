import Foundation
import PDFKit
// Dumps every text run on the given pages with its bounds (PDF points, origin bottom-left) as JSON lines.
let args = CommandLine.arguments
let url = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: url) else { print("no doc"); exit(1) }
let pages: [Int] = args.count > 2 ? args[2].split(separator: ",").map { Int($0)! } : Array(1...doc.pageCount)
struct Run { var text: String; var x0: CGFloat; var y0: CGFloat; var x1: CGFloat; var y1: CGFloat }
for pn in pages {
    guard let page = doc.page(at: pn - 1), let s = page.string else { continue }
    let chars = Array(s)
    var runs: [Run] = []
    var cur: Run? = nil
    for (i, ch) in chars.enumerated() {
        let b = page.characterBounds(at: i)
        if ch == "\n" || ch == "\r" { if let c = cur { runs.append(c) }; cur = nil; continue }
        if b.isNull || b.isEmpty || (b.width == 0 && b.height == 0) {
            // whitespace with no bounds: keep as separator inside a run
            if cur != nil && ch == " " { cur!.text.append(" ") }
            continue
        }
        if var c = cur {
            let sameLine = abs(b.minY - c.y0) < 3.0 && abs(b.maxY - c.y1) < 3.0
            let gap = b.minX - c.x1
            if sameLine && gap < 6.0 && gap > -4.0 {
                c.text.append(ch); c.x1 = max(c.x1, b.maxX); c.y0 = min(c.y0, b.minY); c.y1 = max(c.y1, b.maxY)
                cur = c
                continue
            }
            runs.append(c)
        }
        cur = Run(text: String(ch), x0: b.minX, y0: b.minY, x1: b.maxX, y1: b.maxY)
    }
    if let c = cur { runs.append(c) }
    for r in runs {
        let t = r.text.trimmingCharacters(in: .whitespaces)
        if t.isEmpty { continue }
        let esc = t.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
        print("{\"page\":\(pn),\"x0\":\(String(format: "%.1f", r.x0)),\"y0\":\(String(format: "%.1f", r.y0)),\"x1\":\(String(format: "%.1f", r.x1)),\"y1\":\(String(format: "%.1f", r.y1)),\"t\":\"\(esc)\"}")
    }
}

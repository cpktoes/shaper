import sys, json
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
import pypdf
r = pypdf.PdfReader(sys.argv[1])
pages = [int(a) for a in sys.argv[2].split(',')] if len(sys.argv) > 2 else range(1, len(r.pages)+1)
out = {}
for pn in pages:
    p = r.pages[pn-1]
    items = []
    def visitor(text, cm, tm, fontDict, fontSize):
        t = text.strip()
        if not t: return
        # position = tm composed with cm
        x = cm[0]*tm[4] + cm[2]*tm[5] + cm[4]
        y = cm[1]*tm[4] + cm[3]*tm[5] + cm[5]
        items.append({'x': round(x,1), 'y': round(y,1), 't': t, 'fs': round(fontSize,1) if fontSize else None})
    p.extract_text(visitor_text=visitor)
    out[pn] = items
json.dump(out, open('pos.json','w'))
for pn in pages:
    print('=== page', pn)
    for it in sorted(out[pn], key=lambda i:(-i['y'], i['x'])):
        print(f"  x={it['x']:7.1f} y={it['y']:7.1f} fs={it['fs']}  {it['t']}")

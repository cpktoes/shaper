import json
b = json.load(open('blanks.json'))
ORDER = ['N0','N12','N24','N48','C','T48','T24','T12','T0']
def val(r, lab, f):
    st = r['stations'].get(lab); c = st and st[f]
    return None if not c else c['in']
for pn, r in b.items():
    labs = [l for l in ORDER if l in r['stations']]
    name = r['name']
    # centre rocker
    cr = r['stations']['C']['rocker']
    if cr is None or cr['txt'] not in ('0"', '0', 'M', '0“'): print(f"p{pn} {name}: C rocker is {cr and cr['txt']}")
    # rocker monotone away from centre
    rk = [(l, val(r, l, 'rocker')) for l in labs if val(r, l, 'rocker') is not None]
    ci = [i for i, (l, v) in enumerate(rk) if l == 'C'][0]
    nose = [v for l, v in rk[:ci+1]]; tail = [v for l, v in rk[ci:]]
    if any(nose[i] <= nose[i+1] for i in range(len(nose)-1)): print(f"p{pn} {name}: nose rocker not falling to centre: {[(l,v) for l,v in rk[:ci+1]]}")
    if any(tail[i] >= tail[i+1] for i in range(len(tail)-1)): print(f"p{pn} {name}: tail rocker not rising from centre: {[(l,v) for l,v in rk[ci:]]}")
    # widths unimodal with max at C (or within 1/16 of the headline max)
    ws = [(l, val(r, l, 'width')) for l in labs if val(r, l, 'width') is not None]
    wi = [i for i, (l, v) in enumerate(ws) if l == 'C'][0]
    wn = [v for l, v in ws[:wi+1]]; wt = [v for l, v in ws[wi:]]
    if any(wn[i] >= wn[i+1] for i in range(len(wn)-1)) or any(wt[i] <= wt[i+1] for i in range(len(wt)-1)):
        print(f"p{pn} {name}: widths not peaking at centre: {ws}")
    if r['maxw_in'] is not None and abs(max(v for l, v in ws) - r['maxw_in']) > 0.001:
        print(f"p{pn} {name}: headline max width {r['maxw_in']} vs widest station {max(v for l,v in ws)}")
    ts = [(l, val(r, l, 'thickness')) for l in labs if val(r, l, 'thickness') is not None]
    ti = [i for i, (l, v) in enumerate(ts) if l == 'C'][0]
    tn = [v for l, v in ts[:ti+1]]; tt = [v for l, v in ts[ti:]]
    if any(tn[i] >= tn[i+1] for i in range(len(tn)-1)) or any(tt[i] <= tt[i+1] for i in range(len(tt)-1)):
        print(f"p{pn} {name}: thickness not peaking at centre: {ts}")
    if r['maxt_in'] is not None and abs(max(v for l, v in ts) - r['maxt_in']) > 0.001:
        print(f"p{pn} {name}: headline max thickness {r['maxt_in']} vs thickest station {max(v for l,v in ts)}")
    if r['bottom_in'] is None or r['deck_in'] is None: print(f"p{pn} {name}: lengths {r['bottom_in']} {r['deck_in']}")
    elif r['deck_in'] > r['bottom_in']: print(f"p{pn} {name}: deck {r['deck_in']} longer than bottom {r['bottom_in']}")
    if r['volume_l'] is None: print(f"p{pn} {name}: no volume")
# sister pairs
pairs = [('46','47'),('52','53'),('36','37'),('57','58'),('61','62'),('49','50')]
for a, c in pairs:
    ra, rc = b[a], b[c]
    diffs = []
    for lab in ORDER:
        if lab not in ra['stations']: continue
        for f in ('width','rocker'):
            va, vc = val(ra, lab, f), val(rc, lab, f)
            if va != vc: diffs.append(f"{lab} {f}: {va} vs {vc}")
    tdiff = [round((val(rc, l, 'thickness') or 0) - (val(ra, l, 'thickness') or 0), 4) for l in ORDER if l in ra['stations']]
    print(f"sisters {ra['name']} / {rc['name']}: outline+rocker diffs {diffs or 'none'}; thickness delta by station {tdiff}; lengths {ra['bottom_in']}/{rc['bottom_in']} vol {ra['volume_l']}/{rc['volume_l']}")

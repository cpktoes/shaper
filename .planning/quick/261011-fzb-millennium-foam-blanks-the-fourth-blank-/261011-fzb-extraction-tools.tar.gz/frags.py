import sys, json
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
import pypdf
from pypdf.generic import ContentStream
from pypdf._text_extraction import _layout_mode
r = pypdf.PdfReader(sys.argv[1])
out = {}
for pn in range(14, 75):
    page = r.pages[pn-1]
    fonts = page._layout_mode_fonts()
    ops = iter(ContentStream(page["/Contents"].get_object(), page.pdf, "bytes").operations)
    groups = _layout_mode.text_show_operations(ops, fonts, True, None)
    out[pn] = [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in g.items()} for g in groups]
json.dump(out, open('frags.json', 'w'))
pn = int(sys.argv[2])
print(out[pn][0].keys())
for g in sorted(out[pn], key=lambda g: (-g['ty'], g['tx'])):
    print(f"tx={g['tx']:7.1f} ty={g['ty']:7.1f} h={g['font_height']:5.1f} dx={g['displaced_tx']:7.1f}  {g['text']!r}")

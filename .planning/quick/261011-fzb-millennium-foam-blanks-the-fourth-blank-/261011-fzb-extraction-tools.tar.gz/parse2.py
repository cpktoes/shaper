import json, re, sys
from fractions import Fraction
frags = json.load(open('frags.json'))
NAME_OVERRIDE = json.load(open('name_override.json')) if __import__('os').path.exists('name_override.json') else {}

CM_RE = re.compile(r'\(\s*(\d*\.?\d+)\s*h?\s*CM\s*\)', re.I)
Q = '"”“″'

def norm(s):
    s = s.replace('’', "'").replace('‘', "'")
    for q in '”“″': s = s.replace(q, '"')
    return re.sub(r'\s{2,}', ' ', s).strip()

def inch_value(s):
    s = norm(s)
    m = re.fullmatch(r'(?:(\d+)\s+)?(\d+)\s*/\s*(\d+)\s*"?', s)
    if m:
        whole = int(m.group(1)) if m.group(1) else 0
        return whole + Fraction(int(m.group(2)), int(m.group(3)))
    m = re.fullmatch(r'(\d+)\s*"?', s)
    if m: return Fraction(int(m.group(1)))
    return None

def parse_feet(s):
    s = norm(s)
    m = re.match(r"(\d+)\s*'?\s*(\d+)?\s*(\d+\s*/\s*\d+)?\s*\"?\s*$", s)
    if not m: return None
    ft = int(m.group(1)); inch = int(m.group(2)) if m.group(2) else 0
    frac = Fraction(re.sub(r'\s','',m.group(3))) if m.group(3) else Fraction(0)
    return ft*12 + inch + frac

def merge_lines(fs):
    """Group fragments into lines (same ty), merge touching/overlapping fragments."""
    fs = sorted(fs, key=lambda f: (-f['ty'], f['tx']))
    lines = []
    for f in fs:
        if lines and abs(lines[-1][-1]['ty'] - f['ty']) < 2.5:
            lines[-1].append(f)
        else:
            lines.append([f])
    merged = []
    for line in lines:
        line.sort(key=lambda f: f['tx'])
        cur = None
        for f in line:
            if cur is not None and f['tx'] - cur['dx'] < 6:
                cur['text'] = cur['text'] + ' ' + f['text']
                cur['dx'] = max(cur['dx'], f['displaced_tx'])
                cur['h'] = max(cur['h'], f['font_height'])
            else:
                if cur is not None: merged.append(cur)
                cur = {'text': f['text'], 'tx': f['tx'], 'dx': f['displaced_tx'], 'ty': f['ty'], 'h': f['font_height']}
        if cur is not None: merged.append(cur)
    for m in merged: m['text'] = norm(m['text'])
    return merged

TOKEN = re.compile(r'(?:\d+\s+)?\d+\s*/\s*\d+\s*"?|\d+\s*"|\bM\b|\b0\b|\(\s*\d*\.?\d+\s*CM\s*\)', re.I)

def tokens(f):
    out = []
    text = f['text']
    width = max(f['dx'] - f['tx'], 1); n = max(len(text), 1)
    for m in TOKEN.finditer(text):
        tok = m.group(0).strip()
        out.append({'t': tok, 'x0': f['tx'] + width*m.start()/n, 'x1': f['tx'] + width*m.end()/n, 'y': f['ty'], 'h': f['h'], 'src': text})
    return out

def parse_page(pn, fs):
    page = {'page': pn, 'notes': []}
    ms = merge_lines(fs)
    big = sorted([m for m in ms if m['h'] > 30], key=lambda m: m['tx'])
    name = ''.join(m['text'] for m in big) if big else None
    if str(pn) in NAME_OVERRIDE: name = NAME_OVERRIDE[str(pn)]
    page['name'] = norm(name) if name else None
    # headline
    hl = {}; head_x = None
    for i, m in enumerate(ms):
        t = m['text']
        if m['h'] > 30: continue
        key = None
        if re.search(r'Length\s*:', t) and 'Tip' not in t and 'tip' not in t: key = 'bottom'
        elif re.search(r'Tip\s*To\s*Tip|Tip\s*to\s*tip|Tip\s*to\s*Tip', t) and ':' in t: key = 'deck'
        elif re.search(r'Width\s*:', t, re.I): key = 'maxw'
        elif re.search(r'Thickness\s*:', t, re.I): key = 'maxt'
        elif re.search(r'Volume\s*:', t): key = 'volume'
        if key is None: continue
        rest = t.split(':', 1)[1].strip()
        if key == 'bottom': head_x = m['tx'] if head_x is None else min(head_x, m['tx'])
        cm = None
        mcm = CM_RE.search(rest)
        if mcm:
            cm = float(mcm.group(1)); rest = rest[:mcm.start()].strip()
        else:
            # the cm on a following line inside the headline block
            for g in ms[i+1:i+4]:
                if 0 < m['ty'] - g['ty'] < 18 and g['tx'] >= m['tx'] - 5 and g['tx'] < m['tx'] + 200:
                    mm = CM_RE.fullmatch(g['text'].strip())
                    if mm: cm = float(mm.group(1)); break
        if key == 'volume':
            mv = re.match(r'(\d*\.?\d+)\s*L', rest)
            hl['volume'] = float(mv.group(1)) if mv else rest
        elif key in ('bottom', 'deck'):
            hl[key+'_in'] = parse_feet(rest); hl[key+'_cm'] = cm; hl[key+'_raw'] = rest
        else:
            hl[key+'_in'] = inch_value(rest); hl[key+'_cm'] = cm; hl[key+'_raw'] = rest
    page['headline'] = hl
    if head_x is None:
        page['notes'].append('no Bottom Length headline found'); head_x = 190.0
    page['head_x'] = head_x
    # label tokens
    toks = []
    for m in ms:
        t = m['text']
        if m['h'] > 30: continue
        if m['tx'] >= head_x - 5 and m['tx'] <= head_x + 80 and len(t) > 8 and not CM_RE.fullmatch(t):
            continue
        if re.search(r'[A-Za-z]{3,}', t) and not CM_RE.fullmatch(t): continue
        toks.extend(tokens(m))
    inch_toks = [t for t in toks if not CM_RE.fullmatch(t['t'])]
    cm_toks = [t for t in toks if CM_RE.fullmatch(t['t'])]
    def pair(it):
        best = None
        for c in cm_toks:
            dy = it['y'] - c['y']
            xc_i = (it['x0']+it['x1'])/2; xc_c = (c['x0']+c['x1'])/2
            if 6 <= dy <= 14 and abs(xc_i - xc_c) < 24:
                d = abs(xc_i - xc_c)
                if best is None or d < best[0]: best = (d, c)
            elif abs(dy) < 3 and -2 <= c['x0'] - it['x1'] < 14:
                best = (0, c)
        return best[1] if best else None
    for it in inch_toks:
        it['v'] = inch_value(it['t']) if it['t'] != 'M' else None
        c = pair(it)
        it['cm'] = float(CM_RE.fullmatch(c['t']).group(1)) if c else None
    side = [t for t in inch_toks if t['x0'] > head_x + 150]
    top = [t for t in inch_toks if t['x0'] <= head_x + 150]
    is_station = lambda t: norm(t['t']).rstrip('"') in ('12','24','36','48','0','M')
    station_lbl = [t for t in top if t['cm'] is None and is_station(t)]
    widths = [t for t in top if not (t['cm'] is None and is_station(t))]
    widths.sort(key=lambda t: -t['y']); station_lbl.sort(key=lambda t: -t['y'])
    page['station_labels'] = [(norm(t['t']), round(t['y'],1)) for t in station_lbl]
    page['widths'] = widths
    side.sort(key=lambda t: (t['x0']+t['x1'])/2)
    rock, thick = [], []
    if len(side) >= 2:
        cs = [(t['x0']+t['x1'])/2 for t in side]
        gaps = [(cs[i+1]-cs[i], i) for i in range(len(cs)-1)]
        g, i = max(gaps)
        split = (cs[i]+cs[i+1])/2
        rock = [t for t in side if (t['x0']+t['x1'])/2 < split]
        thick = [t for t in side if (t['x0']+t['x1'])/2 >= split]
    rock.sort(key=lambda t: -t['y']); thick.sort(key=lambda t: -t['y'])
    page['rocker'] = rock; page['thickness'] = thick
    return page

pages = {pn: parse_page(pn, frags[str(pn)]) for pn in sorted(int(k) for k in frags)}

def fmt(t):
    if t is None: return '    -                        '
    v = t.get('v'); cm = t.get('cm')
    s = norm(t['t'])
    ok = ''
    if v is not None and cm is not None:
        ok = 'ok' if abs(float(v)*2.54 - cm) < 0.035 else f'!!{float(v)*2.54:.2f}'
    return f"{s:>9} {('('+str(cm)+')') if cm is not None else '':>9} {ok:<8}"

if __name__ == '__main__':
    for pn, p in pages.items():
        hl = p['headline']
        print(f"=== page {pn}  name={p['name']!r}  stations={[s[0] for s in p['station_labels']]}  bottom={hl.get('bottom_raw')!r}->{hl.get('bottom_in')} cm={hl.get('bottom_cm')}  deck={hl.get('deck_raw')!r}->{hl.get('deck_in')} cm={hl.get('deck_cm')}  maxW={hl.get('maxw_in')}/{hl.get('maxw_cm')} maxT={hl.get('maxt_in')}/{hl.get('maxt_cm')} vol={hl.get('volume')}")
        for n in p['notes']: print('   NOTE', n)
        W, R, T = p['widths'], p['rocker'], p['thickness']
        print(f"   counts: widths={len(W)} rocker={len(R)} thickness={len(T)}")
        for i in range(max(len(W), len(R), len(T))):
            w = W[i] if i < len(W) else None; r = R[i] if i < len(R) else None; t = T[i] if i < len(T) else None
            print(f"   {i}: W {fmt(w)} y={w['y'] if w else 0:5.0f} | R {fmt(r)} y={r['y'] if r else 0:5.0f} | T {fmt(t)} y={t['y'] if t else 0:5.0f}")
    json.dump(pages, open('parsed2.json','w'), default=str)

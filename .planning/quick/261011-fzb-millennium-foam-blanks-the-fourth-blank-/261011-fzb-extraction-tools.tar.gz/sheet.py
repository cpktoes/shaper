import sys, os, json, subprocess
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
from PIL import Image, ImageDraw
pdf = "/Users/kontoes/Downloads/MILL FULL CATALOG 2024 VR 9.27_opt.pdf"
pages = [int(a) for a in sys.argv[1].split(',')]
box = tuple(float(v) for v in sys.argv[2].split(','))  # x0,y0,x1,y1 in PDF points, origin bottom-left
out = sys.argv[3]
scale = 1.5
tiles = []
for pn in pages:
    png = f'p{pn}.png'
    if not os.path.exists(png):
        subprocess.run(['./render', pdf, str(pn), str(scale), png], check=True, capture_output=True)
    im = Image.open(png)
    H = im.height; scale = im.width / 612.0
    crop = im.crop((int(box[0]*scale), int(H - box[3]*scale), int(box[2]*scale), int(H - box[1]*scale)))
    d = ImageDraw.Draw(crop); d.rectangle((0,0,60,14), fill='white'); d.text((2,1), f'p{pn}', fill='red')
    tiles.append(crop)
cols = 5
w, h = tiles[0].size
rows = (len(tiles)+cols-1)//cols
sheet = Image.new('RGB', (cols*w, rows*h), 'white')
for i, t in enumerate(tiles): sheet.paste(t, ((i%cols)*w, (i//cols)*h))
sheet.save(out); print(out, sheet.size)

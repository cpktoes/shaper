import sys
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
import pypdf
r = pypdf.PdfReader(sys.argv[1])
for a in sys.argv[2].split(','):
    pn = int(a)
    print('=== page', pn)
    print(r.pages[pn-1].extract_text(extraction_mode="layout", layout_mode_space_vertically=True, layout_mode_scale_weight=1.0))

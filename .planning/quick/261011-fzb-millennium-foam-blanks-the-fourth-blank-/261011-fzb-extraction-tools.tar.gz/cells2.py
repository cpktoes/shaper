import sys, os, json, subprocess
sys.path.append('/Users/kontoes/Library/Python/3.9/lib/python/site-packages')
from PIL import Image, ImageDraw
b = json.load(open('blanks.json'))
pdf = "/Users/kontoes/Downloads/MILL FULL CATALOG 2024 VR 9.27_opt.pdf"
ORDER = ['N0','N12','N24','N48','C','T48','T24','T12','T0']
cells = []
for pn, r in b.items():
    for lab in ORDER:
        if lab not in r['stations']: continue
        st = r['stations'][lab]
        for field in ('width','rocker','thickness'):
            c = st[field]
            if c is None: continue
            if c['mismatch'] or (c['cm'] is None and not (field == 'rocker' and lab == 'C')):
                cells.append((pn, lab, field, c))
print(len(cells))
tiles = []
for pn, lab, field, c in cells:
    x0, x1, y = c['pos']
    png = f'p{pn}.png'
    if not os.path.exists(png): subprocess.run(['./render', pdf, pn, '1.5', png], check=True, capture_output=True)
    im = Image.open(png); s = im.width/612.0; H = im.height
    cx = (x0+x1)/2 + (50 if x0 > 340 else 0)
    box = (int((cx-55)*s), int(H-(y+15)*s), int((cx+55)*s), int(H-(y-13)*s))
    crop = im.crop(box).convert('RGB').resize((264, 67))
    d = ImageDraw.Draw(crop); d.rectangle((0,0,264,11), fill='white'); d.text((1,0), f"p{pn} {r['name'] if False else b[pn]['name']} {lab} {field[:5]} {c['txt']} cm={c['cm']}", fill='red')
    tiles.append(crop)
cols = 5; w, h = tiles[0].size; rows = (len(tiles)+cols-1)//cols
sheet = Image.new('RGB', (cols*w, rows*h), 'white')
for i, t in enumerate(tiles): sheet.paste(t, ((i%cols)*w, (i//cols)*h))
sheet.save('cells_all.png'); print(sheet.size)

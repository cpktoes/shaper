import json, re, sys, os
from fractions import Fraction
frags = json.load(open('frags.json'))
NAME_OVERRIDE = {'23': '6\'2"F'}   # headline drawn as outlines on this page; confirmed by eye on the render

CM_RE = re.compile(r'\(\s*(\d*\.?\d+)\s*h?\s*CM\s*\)', re.I)

def norm(s):
    s = s.replace('’', "'").replace('‘', "'")
    for q in '”“″': s = s.replace(q, '"')
    return re.sub(r'\s{2,}', ' ', s).strip()

def inch_value(s):
    s = norm(s)
    m = re.fullmatch(r'(?:(\d+)\s+)?(\d+)\s*/\s*(\d+)\s*"?', s)
    if m:
        return (int(m.group(1)) if m.group(1) else 0) + Fraction(int(m.group(2)), int(m.group(3)))
    m = re.fullmatch(r'(\d+)\s*"?', s)
    if m: return Fraction(int(m.group(1)))
    return None

def parse_feet(s):
    s = norm(s).replace('""', '"')
    m = re.match(r"(\d+)\s*'?\s*(\d+)?\s*(\d+\s*/\s*\d+)?\s*\"?\s*$", s)
    if not m: return None
    ft = int(m.group(1)); inch = int(m.group(2)) if m.group(2) else 0
    frac = Fraction(re.sub(r'\s','',m.group(3))) if m.group(3) else Fraction(0)
    return ft*12 + inch + frac

def merge_lines(fs):
    fs = sorted(fs, key=lambda f: (-f['ty'], f['tx']))
    lines = []
    for f in fs:
        if lines and abs(lines[-1][-1]['ty'] - f['ty']) < 2.5: lines[-1].append(f)
        else: lines.append([f])
    merged = []
    for line in lines:
        line.sort(key=lambda f: f['tx'])
        cur = None
        for f in line:
            if cur is not None and f['tx'] - cur['dx'] < 6:
                cur['raw'] = cur['raw'] + ' ' + f['text']
                cur['dx'] = max(cur['dx'], f['displaced_tx']); cur['h'] = max(cur['h'], f['font_height'])
            else:
                if cur is not None: merged.append(cur)
                cur = {'raw': f['text'], 'tx': f['tx'], 'dx': f['displaced_tx'], 'ty': f['ty'], 'h': f['font_height']}
        if cur is not None: merged.append(cur)
    for m in merged: m['text'] = norm(m['raw'])
    return merged

TOKEN = re.compile(r'(?:\d+\s+)?\d+\s*/\s*\d+\s*["”“″]?|\d+\s*["”“″]|\bM\b|(?<![\d.])0(?![\d.])|\(\s*\d*\.?\d+\s*CM\s*\)', re.I)

def tokens(f):
    raw = f['raw']
    has_letters = re.search(r'[A-Za-z]{3,}', re.sub(r'\(\s*\d*\.?\d+\s*CM\s*\)', '', raw, flags=re.I)) is not None
    ms = list(TOKEN.finditer(raw))
    out = []
    width = max(f['dx'] - f['tx'], 1); n = max(len(raw), 1)
    for i, m in enumerate(ms):
        tok = norm(m.group(0))
        first = m.start() == 0 or raw[:m.start()].strip() == ''
        last = i == len(ms) - 1 and raw[m.end():].strip() == ''
        if has_letters:
            # a label riding at the end of a body-text line: only when clearly separated
            if not last or len(raw[:m.start()]) - len(raw[:m.start()].rstrip()) < 3: continue
        x0 = f['tx'] + width*m.start()/n; x1 = f['tx'] + width*m.end()/n
        if first: x0 = f['tx']
        if last: x1 = f['dx']
        if first and last: x0, x1 = f['tx'], f['dx']
        out.append({'t': tok, 'x0': x0, 'x1': x1, 'y': f['ty'], 'exact': first or last, 'src': f['text']})
    return out

ROW_ORDER = ['N0', 'N12', 'N24', 'C', 'T24', 'T12', 'T0']

def parse_page(pn, fs):
    page = {'page': pn, 'notes': []}
    ms = merge_lines(fs)
    big = sorted([m for m in ms if m['h'] > 30], key=lambda m: m['tx'])
    name = ''.join(m['text'] for m in big) if big else None
    if str(pn) in NAME_OVERRIDE: name = NAME_OVERRIDE[str(pn)]
    page['name'] = re.sub(r'\s+', '', norm(name)) if name else None
    hl = {}; head_x = None
    for m in ms:
        t = m['text']
        if m['h'] > 30: continue
        key = None
        if re.search(r'Deck\s*:', t, re.I) or (re.search(r'Length\s*:', t, re.I) and re.search(r'T\s*i\s*p', t)): key = 'deck'
        elif re.search(r'Length\s*:', t, re.I): key = 'bottom'
        elif re.search(r'Width\s*:', t, re.I): key = 'maxw'
        elif re.search(r'Thickness\s*:', t, re.I): key = 'maxt'
        elif re.search(r'Volume\s*:', t, re.I): key = 'volume'
        if key is None or key in hl: continue
        rest = t.split(':', 1)[1].strip()
        if key == 'bottom': head_x = m['tx'] if head_x is None else min(head_x, m['tx'])
        mcm = CM_RE.search(rest)
        if mcm: rest = rest[:mcm.start()].strip()
        if key == 'volume':
            mv = re.match(r'(\d*\.?\d+)\s*L', rest); hl['volume'] = float(mv.group(1)) if mv else None; hl['volume_raw'] = rest
        elif key in ('bottom', 'deck'):
            hl[key] = parse_feet(rest); hl[key+'_raw'] = rest
        else:
            hl[key] = inch_value(rest); hl[key+'_raw'] = rest
    page['headline'] = hl
    if head_x is None: page['notes'].append('no Bottom Length headline'); head_x = 190.0
    page['head_x'] = head_x
    toks = []
    for m in ms:
        if m['h'] > 30: continue
        toks.extend(tokens(m))
    inch_toks = [t for t in toks if not CM_RE.fullmatch(t['t'])]
    cm_toks = [t for t in toks if CM_RE.fullmatch(t['t'])]
    def pair(it, side):
        best = None
        for c in cm_toks:
            if not side and c['x0'] >= head_x - 5 and c['x0'] < head_x + 200: continue  # the headline block's own cm lines
            dy = it['y'] - c['y']
            xc_i = (it['x0']+it['x1'])/2; xc_c = (c['x0']+c['x1'])/2
            if 6 <= dy <= 14 and abs(xc_i - xc_c) < 24:
                d = abs(xc_i - xc_c)
                if best is None or d < best[0]: best = (d, c)
            elif abs(dy) < 3 and -2 <= c['x0'] - it['x1'] < 14:
                best = (0, c)
        return best[1] if best else None
    side = [t for t in inch_toks if t['x1'] > head_x + 160 and t['x0'] > head_x + 100]
    top = [t for t in inch_toks if t not in side]
    for it in inch_toks:
        it['v'] = inch_value(it['t']) if it['t'] != 'M' else None
        c = pair(it, it in side)
        it['cm'] = float(CM_RE.fullmatch(c['t']).group(1)) if c else None
    is_station = lambda t: norm(t['t']).rstrip('"') in ('12','24','36','48','0','M')
    station_lbl = sorted([t for t in top if t['cm'] is None and is_station(t)], key=lambda t: -t['y'])
    widths = sorted([t for t in top if not (t['cm'] is None and is_station(t))], key=lambda t: -t['y'])
    # map station labels to names: 12,24,(48) above centre are N; below are T
    centre = [s for s in station_lbl if norm(s['t']).rstrip('"') in ('0','M')]
    st_named = []
    if len(centre) == 1:
        cy = centre[0]['y']
        for s in station_lbl:
            v = norm(s['t']).rstrip('"')
            if s is centre[0]: st_named.append(('C', s['y']))
            else: st_named.append((('N' if s['y'] > cy else 'T') + v, s['y']))
    else:
        page['notes'].append(f'centre label count {len(centre)}')
    page['stations_found'] = st_named
    # assign widths: nearest named station within 8pt; else tips (above first / below last)
    wmap = {}; unassigned = []
    for w in widths:
        best = min(st_named, key=lambda s: abs(s[1] - w['y']), default=None)
        if best and abs(best[1] - w['y']) <= 9 and best[0] not in wmap: wmap[best[0]] = w
        else: unassigned.append(w)
    if st_named:
        top_y = max(s[1] for s in st_named); bot_y = min(s[1] for s in st_named)
        for w in unassigned:
            if w['y'] > top_y + 9 and 'N0' not in wmap: wmap['N0'] = w
            elif w['y'] < bot_y - 9 and 'T0' not in wmap: wmap['T0'] = w
            else: page['notes'].append(f"width unplaced: {w['t']}@({w['x0']:.0f}-{w['x1']:.0f},{w['y']:.0f}) src={w['src']!r}")
    page['widths'] = wmap
    # side view: rows by y, then rocker (left) / thickness (right)
    side.sort(key=lambda t: -t['y'])
    rows = []
    for t in side:
        if rows and abs(rows[-1][0]['y'] - t['y']) < 15: rows[-1].append(t)
        else: rows.append([t])
    rk, th = {}, {}
    if len(rows) != 7:
        page['notes'].append(f'side rows={len(rows)}: ' + ' || '.join(', '.join(f"{t['t']}@({t['x0']:.0f},{t['y']:.0f})" for t in r) for r in rows))
    for i, r in enumerate(rows[:7]):
        r.sort(key=lambda t: t['x0'])
        label = ROW_ORDER[i] if len(rows) == 7 else f'row{i}'
        if len(r) == 2: rk[label], th[label] = r[0], r[1]
        elif len(r) == 1:
            page['notes'].append(f"side row {label} has one token {r[0]['t']}@({r[0]['x0']:.0f},{r[0]['y']:.0f})")
            rk[label] = r[0]
        else:
            page['notes'].append(f"side row {label} has {len(r)} tokens: " + ', '.join(f"{t['t']}@({t['x0']:.0f}-{t['x1']:.0f})" for t in r))
            rk[label], th[label] = r[0], r[-1]
    page['rocker'] = rk; page['thickness'] = th
    return page

pages = {pn: parse_page(pn, frags[str(pn)]) for pn in sorted(int(k) for k in frags)}
json.dump(pages, open('parsed3.json','w'), default=str)

def cell(t):
    if t is None: return '      -           '
    v, cm = t.get('v'), t.get('cm')
    s = norm(t['t'])
    if v is not None and cm is not None:
        ok = 'ok' if abs(float(v)*2.54 - cm) < 0.035 else f'!!{float(v)*2.54:.2f}'
    else: ok = '' if v is not None else '?'
    return f"{s:>9} {('('+str(cm)+')') if cm is not None else '':>9} {ok:<8}"

if __name__ == '__main__':
    for pn, p in pages.items():
        hl = p['headline']
        print(f"=== page {pn}  {p['name']}  bottom={hl.get('bottom')} deck={hl.get('deck')} maxW={hl.get('maxw')} maxT={hl.get('maxt')} vol={hl.get('volume')}  stations={[s[0] for s in p['stations_found']]}")
        for n in p['notes']: print('   NOTE', n)
        for lab in ROW_ORDER + [k for k in p['widths'] if k not in ROW_ORDER]:
            w = p['widths'].get(lab); r = p['rocker'].get(lab); t = p['thickness'].get(lab)
            print(f"   {lab:>3}: W {cell(w)} | R {cell(r)} | T {cell(t)}")

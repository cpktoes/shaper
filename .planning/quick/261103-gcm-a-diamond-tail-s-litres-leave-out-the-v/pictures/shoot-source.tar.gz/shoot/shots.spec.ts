// Quick 261103-gcm's picture script: VOLUME on a Shortboard with the Diamond tail button and on the
// Fish (a swallow), the home page's four preset cards, and the Fish's VOLUME tile in the phone's ☰
// sheet. Every mode prints what the screen shows beside what the app's own maths says it should
// show; SHOOT_TAG=before|after also takes pictures, SHOOT_TAG=read only prints. Scratch only.
import { expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/board";
import { deriveTemplateValues, summarizeDesign } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/design";
import { formatArea } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/measure-display";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/presets";
import { formatTileLitres } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/screen-tiles";
import { presetSummary } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/summary-line";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/models/toolbar-tip";
import { goToScreen, openPhoneMenu, screenTile } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/e2e/helpers/screens";

const TAG = process.env.SHOOT_TAG ?? "read";
const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/.planning/quick/261103-gcm-a-diamond-tail-s-litres-leave-out-the-v/pictures";

const SHORTBOARD = BOARD_PRESETS.find((p) => p.name === "Shortboard")!;
const FISH = BOARD_PRESETS.find((p) => p.name === "Fish")!;

function diamondFields() {
  const fields = presetDesignFields(SHORTBOARD);
  const d = TAIL_PRESETS.diamond;
  return {
    ...fields,
    outline: { ...fields.outline, tail: d.tail, tailAngle: d.tailAngle, tailFullness: d.tailFullness },
    railsImportFoilThickness: true,
    volume: DEFAULT_VOLUME_SPEC,
  };
}

function expected(name: "diamond" | "fish") {
  const outline = name === "diamond" ? diamondFields().outline : FISH.outline;
  const litres = name === "diamond" ? summarizeDesign(diamondFields()).volumeLitres : presetSummary(FISH).volumeLitres;
  const area = deriveTemplateValues(outline, buildOutline(outline)).area;
  return { litres: `${litres.toFixed(2)} L`, area: `${formatArea(area, "imperial")} (imported)`, exact: litres };
}

async function setUp(page: Page) {
  await page.addInitScript(
    ([bannerKey, tipKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY] as const,
  );
}

async function openPreset(page: Page, name?: string) {
  await page.goto("/");
  const cards = page.getByRole("button").filter({ hasText: "Start Shaping" });
  const button = name ? cards.filter({ hasText: name }).first() : cards.first();
  await expect(async () => {
    await button.click();
    await expect(page).toHaveURL(/\/design\/outline$/, { timeout: 3_000 });
  }).toPass({ timeout: 30_000 });
}

async function readVolume(page: Page) {
  const figure = page.getByText(/^\d+\.\d\d L$/).first();
  await expect(figure).toBeVisible();
  const litres = (await figure.innerText()).trim();
  const areaRow = page.getByText("Template Area", { exact: true }).first().locator("..");
  const area = (await areaRow.innerText()).replace("Template Area", "").trim();
  return { litres, area };
}

function report(label: string, shown: { litres: string; area: string }, want: ReturnType<typeof expected>) {
  console.log(`\n${TAG.toUpperCase()} — ${label}`);
  console.log(`  Estimated Volume shown ${shown.litres} | app's own ${want.litres} (${want.exact})`);
  console.log(`  Template Area    shown ${shown.area} | app's own ${want.area}`);
}

test.describe("computer", () => {
  test.use({ deviceScaleFactor: 2 });
  test.beforeEach(async ({ page }, info) => {
    test.skip(info.project.name !== "desktop", "computer shots");
    await setUp(page);
  });

  test("volume-diamond", async ({ page }) => {
    await openPreset(page);
    await page.getByRole("button", { name: "diamond", exact: true }).click();
    await goToScreen(page, "VOLUME");
    const shown = await readVolume(page);
    report("Shortboard with the Diamond button, VOLUME", shown, expected("diamond"));
    if (TAG !== "read") await page.screenshot({ path: `${PICTURES}/${TAG}-volume-diamond.png` });
  });

  test("volume-fish", async ({ page }) => {
    await openPreset(page, "Fish");
    await goToScreen(page, "VOLUME");
    const shown = await readVolume(page);
    report("Fish, VOLUME", shown, expected("fish"));
    if (TAG !== "read") await page.screenshot({ path: `${PICTURES}/${TAG}-volume-fish.png` });
  });

  test("home-cards", async ({ page }) => {
    await page.goto("/");
    const cards = page.getByRole("button").filter({ hasText: "Start Shaping" });
    await expect(cards).toHaveCount(BOARD_PRESETS.length);
    console.log(`\n${TAG.toUpperCase()} — home page preset cards`);
    for (let i = 0; i < BOARD_PRESETS.length; i++) {
      const text = (await cards.nth(i).innerText()).split("\n").map((s) => s.trim()).filter(Boolean);
      const own = formatTileLitres(presetSummary(BOARD_PRESETS[i]).volumeLitres);
      console.log(`  ${text[0]}: ${text[1]} | app's own litres ${own}`);
    }
    await page.evaluate(() => document.fonts.ready);
    const boxes = await cards.evaluateAll((els) => els.map((el) => el.getBoundingClientRect().toJSON()));
    const left = Math.min(...boxes.map((b) => b.left)) - 16;
    const top = Math.min(...boxes.map((b) => b.top)) - 16;
    const right = Math.max(...boxes.map((b) => b.right)) + 16;
    const bottom = Math.max(...boxes.map((b) => b.bottom)) + 16;
    if (TAG !== "read") {
      await page.screenshot({
        path: `${PICTURES}/${TAG}-home-cards.png`,
        fullPage: true,
        clip: { x: Math.max(0, left), y: Math.max(0, top), width: right - Math.max(0, left), height: bottom - Math.max(0, top) },
      });
    }
  });
});

test.describe("phone", () => {
  test.beforeEach(async ({ page }, info) => {
    test.skip(info.project.name !== "iphone", "phone shots");
    await setUp(page);
  });

  test("phone-volume-tile", async ({ page }) => {
    await openPreset(page, "Fish");
    const sheet = await openPhoneMenu(page);
    const tile = screenTile(page, "VOLUME");
    await expect(tile).toBeVisible();
    const line = (await tile.locator("[data-tile-picture]").innerText()).replace(/\s+/g, " ").trim();
    console.log(`\n${TAG.toUpperCase()} — phone ☰ VOLUME tile (Fish): ${line} | app's own ${formatTileLitres(presetSummary(FISH).volumeLitres)}`);
    if (TAG !== "read") await sheet.screenshot({ path: `${PICTURES}/${TAG}-phone-volume-tile.png` });
  });
});

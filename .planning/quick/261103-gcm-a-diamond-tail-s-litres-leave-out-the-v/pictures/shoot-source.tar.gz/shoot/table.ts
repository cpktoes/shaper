// Quick 261103-gcm: the SUMMARY's before/after table, from the app's own functions. Scratch only.
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/blanks/preset-blanks";
import { DEFAULT_BOARD_SPEC, TAIL_PRESETS, type TailShape } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/board";
import {
  deriveEffectiveRails,
  designSideProfile,
  LIVE_DESIGN_RULES,
  summarizeDesign,
  type DesignSummaryFields,
} from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/design";
import { formatArea } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/measure-display";
import { buildOutline, outlinePlanArea, sampleOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/presets";
import { DEFAULT_RAIL_BAND_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/rail-bands";
import { silhouette } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/screen-tiles";
import { computeCrossSectionVolume, DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-acbcab33b0181a151/lib/geometry/volume";

const first: DesignSummaryFields = {
  outline: DEFAULT_BOARD_SPEC.outline,
  rocker: DEFAULT_BOARD_SPEC.rocker,
  foil: DEFAULT_BOARD_SPEC.foil,
  rails: DEFAULT_RAIL_BAND_SPEC,
  volume: DEFAULT_VOLUME_SPEC,
  railsImportFoilThickness: true,
  blank: null,
};
const bases: [string, DesignSummaryFields][] = [
  ...BOARD_PRESETS.map((p): [string, DesignSummaryFields] => [p.name, { ...presetDesignFields(p), railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC }]),
  ["First board", first],
];
function tail(f: DesignSummaryFields, k: TailShape["kind"]): DesignSummaryFields {
  const t = TAIL_PRESETS[k];
  return { ...f, outline: { ...f.outline, tail: t.tail, tailAngle: t.tailAngle, tailFullness: t.tailFullness } };
}
function shoelace(pts: { station: number; w: number }[]) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i], q = pts[(i + 1) % pts.length];
    a += p.station * q.w - q.station * p.w;
  }
  return Math.abs(a) / 2;
}
function today(f: DesignSummaryFields) {
  const g = buildOutline(f.outline);
  const prof = designSideProfile(f, LIVE_DESIGN_RULES);
  return computeCrossSectionVolume({
    halfWidthAt: (s) => sampleOutline(g, s),
    foil: prof.effectiveFoil,
    thicknessAt: prof.thicknessAt,
    rails: deriveEffectiveRails(f.rails, prof.effectiveFoil, true),
    length: f.outline.length,
  }).volumeLitres;
}
console.log("board | area today mm2 | drawn | planArea | sq in today -> after | cm2 today -> after | litres today -> after");
for (const [name, base] of bases) {
  const rows: [string, DesignSummaryFields][] = [[`${name} as opened`, base], ...(["squash", "pin", "round", "diamond", "swallow"] as const).map((k): [string, DesignSummaryFields] => [`${name}, ${k} button`, tail(base, k)])];
  for (const [label, f] of rows) {
    const g = buildOutline(f.outline);
    const before = today(f);
    const after = summarizeDesign(f).volumeLitres;
    console.log(
      `${label} | ${g.area.toFixed(0)} | ${shoelace(silhouette(g)).toFixed(0)} | ${outlinePlanArea(g).toFixed(0)} | ${formatArea(g.area, "imperial")} -> ${formatArea(outlinePlanArea(g), "imperial")} | ${formatArea(g.area, "metric")} -> ${formatArea(outlinePlanArea(g), "metric")} | ${before.toFixed(4)} -> ${after.toFixed(4)} (${Object.is(before, after) ? "identical" : (after - before).toFixed(4)})`,
    );
  }
}

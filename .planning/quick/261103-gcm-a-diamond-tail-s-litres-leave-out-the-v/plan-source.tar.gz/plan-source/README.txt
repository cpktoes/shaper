Plan-time draft for quick 261103-gcm (2026-11-03). NOT a paste source: a cross-check.
Ran from the root of an rsync copy of main at 7a74e0ff (node_modules symlinked), with draft.diff applied:
  npx --no-install tsx --tsconfig ./tsconfig.json measure.ts     # the plan's tables
  npx --no-install tsx --tsconfig ./tsconfig.json area.ts        # outlinePlanArea == shoelace(silhouette), 38 outlines incl. wings (worst 2.2e-15)
  npx --no-install tsx --tsconfig ./tsconfig.json relations.ts   # the cut piece, whole-board and per-station relations (worst 9.4e-15)
draft.diff: outline.ts (tailCutStation, foamHalfWidth, outlinePlanArea - names are the plan's), volume.ts (a
cutStation split of the 51 stations; the `panels` override existed only for a fine reference and is NOT part of the
plan), design.ts (summarizeDesignWith + deriveTemplateValues wired). The draft's foamHalfWidth multiplies before it
divides; the plan asks for the fraction first so the end points land exactly.
With the draft: npx vitest run -> 7 failures, all expected: six in design.test.ts (the Fish rebuilt by hand with
sampleOutline; the Fish's area mapping) and lib/models/rack-stand-in.test.ts timing out at 30 s under the full
run's load (it never reads the litres path that changed). The preset-figures script rewrote only the Fish's litres.

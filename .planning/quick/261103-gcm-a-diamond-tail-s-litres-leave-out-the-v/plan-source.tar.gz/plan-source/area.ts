import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { TAIL_PRESETS, DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { buildOutline, outlinePlanArea } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { silhouette } from "@/lib/geometry/screen-tiles";
import { inchesToMm } from "@/lib/geometry/units";
import type { OutlineSpec, TailShape } from "@/lib/geometry/board";
function shoelace(pts: { station: number; w: number }[]) { let a = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p.station * q.w - q.station * p.w; } return Math.abs(a) / 2; }
const outlines: [string, OutlineSpec][] = [];
for (const p of BOARD_PRESETS) {
  const o = presetDesignFields(p).outline;
  for (const kind of ["squash", "pin", "round", "diamond", "swallow"] as const) {
    const t = TAIL_PRESETS[kind];
    outlines.push([`${p.id}+${kind}`, { ...o, tail: t.tail, tailAngle: t.tailAngle, tailFullness: t.tailFullness }]);
  }
  outlines.push([`${p.id} as is`, o]);
}
const fish = presetDesignFields(BOARD_PRESETS.find((p) => p.id === "fish")!).outline;
for (const st of [2, 2.5, 3, 4]) for (const d of [0.5, 1, 1.5]) outlines.push([`fish wing@${st} d${d}`, { ...fish, wings: [{ station: inchesToMm(st), depth: inchesToMm(d), run: inchesToMm(1), radius: inchesToMm(0.25), lock: "none" as any, finOffset: inchesToMm(0) }] }]);
const sbd = { ...DEFAULT_BOARD_SPEC.outline, tail: TAIL_PRESETS.diamond.tail, tailAngle: TAIL_PRESETS.diamond.tailAngle, tailFullness: TAIL_PRESETS.diamond.tailFullness };
for (const st of [5, 6]) outlines.push([`first+diamond wing@${st}`, { ...sbd, wings: [{ station: inchesToMm(st), depth: inchesToMm(1), run: inchesToMm(1), radius: inchesToMm(0.25), lock: "none" as any, finOffset: inchesToMm(0) }] }]);
let worst = 0;
for (const [name, o] of outlines) {
  const g = buildOutline(o);
  const t = shoelace(silhouette(g));
  const n = outlinePlanArea(g);
  const rel = Math.abs(n - t) / t;
  worst = Math.max(worst, rel);
  if (rel > 1e-12 || name.includes("wing")) console.log(name.padEnd(26), "area", g.area.toFixed(3), "planArea", n.toFixed(3), "shoelace", t.toFixed(3), "rel", rel.toExponential(2), "first", g.points[0].station.toFixed(2), g.points[0].halfWidth.toFixed(2), "close", g.centreCloseStation.toFixed(2));
}
console.log("worst rel", worst.toExponential(3), "cases", outlines.length);

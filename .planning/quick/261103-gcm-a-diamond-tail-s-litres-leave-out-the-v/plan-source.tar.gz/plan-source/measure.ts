// Plan-time measuring script (quick 261103-gcm). Needs draft.diff applied (it imports the draft's names).
import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { recordedPresetDesignFields } from "@/lib/geometry/__fixtures__/phase14-preset-blanks";
import { DEFAULT_BOARD_SPEC, TAIL_PRESETS, type TailShape } from "@/lib/geometry/board";
import { LIVE_DESIGN_RULES, type DesignSummaryFields, deriveEffectiveRails, designSideProfile, summarizeDesign } from "@/lib/geometry/design";
import { buildOutline, foamHalfWidth, outlinePlanArea, sampleOutline, tailCutStation } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { DEFAULT_RAIL_BAND_SPEC } from "@/lib/geometry/rail-bands";
import { silhouette } from "@/lib/geometry/screen-tiles";
import { DEFAULT_VOLUME_SPEC, SIMPSON_PANEL_COUNT, computeCrossSectionVolume, simpsonIntegrate } from "@/lib/geometry/volume";
import { type Mm, mm } from "@/lib/geometry/units";

function shoelace(pts: { station: number; w: number }[]): number {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    const q = pts[(i + 1) % pts.length];
    a += p.station * q.w - q.station * p.w;
  }
  return Math.abs(a) / 2;
}

function gridStations(length: number, cut: number, panels: number) {
  const h = length / panels;
  const m = cut > 0 ? Math.max(2, 2 * Math.round(cut / (2 * h))) : 0;
  const stations: number[] = [];
  if (m === 0) {
    for (let i = 0; i <= panels; i++) stations.push(i * h);
    return { stations, m, h1: 0, h2: h, h };
  }
  const h1 = cut / m;
  const h2 = (length - cut) / (panels - m);
  for (let i = 0; i <= m; i++) stations.push(i * h1);
  for (let i = 1; i <= panels - m; i++) stations.push(cut + i * h2);
  return { stations, m, h1, h2, h };
}

function simpsonOnGrid(values: number[], g: ReturnType<typeof gridStations>): number {
  if (g.m === 0) return simpsonIntegrate(values, g.h);
  return simpsonIntegrate(values.slice(0, g.m + 1), g.h1) + simpsonIntegrate(values.slice(g.m), g.h2);
}

function measure(label: string, fields: DesignSummaryFields) {
  const geometry = buildOutline(fields.outline);
  const L = fields.outline.length;
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const base = { foil: profile.effectiveFoil, thicknessAt: profile.thicknessAt, rails, length: L };
  const today = computeCrossSectionVolume({ ...base, halfWidthAt: (s) => sampleOutline(geometry, s) });
  const cut = tailCutStation(geometry);
  const foam = (s: Mm) => foamHalfWidth(geometry, s);
  const uniform = computeCrossSectionVolume({ ...base, halfWidthAt: foam });
  const split = computeCrossSectionVolume({ ...base, halfWidthAt: foam, cutStation: cut });
  const g0 = gridStations(L, 0, SIMPSON_PANEL_COUNT);
  const gs = gridStations(L, cut, SIMPSON_PANEL_COUNT);
  console.log(
    [
      label.padEnd(26),
      `cut ${cut.toFixed(1)}`,
      `templateArea ${geometry.area.toFixed(0)}`,
      `planArea ${outlinePlanArea(geometry).toFixed(0)}`,
      `shoelace ${shoelace(silhouette(geometry)).toFixed(0)}`,
      `litresPlanToday ${simpsonOnGrid(g0.stations.map((s) => 2 * sampleOutline(geometry, mm(s))), g0).toFixed(0)}`,
      `litresPlanNew ${simpsonOnGrid(gs.stations.map((s) => 2 * foamHalfWidth(geometry, mm(s))), gs).toFixed(0)}`,
      `| L today ${today.volumeLitres.toFixed(4)} (summary ${summarizeDesign(fields).volumeLitres.toFixed(4)})`,
      `uniform ${uniform.volumeLitres.toFixed(4)}`,
      `split ${split.volumeLitres.toFixed(4)}`,
    ].join("  "),
  );
}

const withTail = (fields: DesignSummaryFields, kind: TailShape["kind"]): DesignSummaryFields => {
  const p = TAIL_PRESETS[kind];
  return { ...fields, outline: { ...fields.outline, tail: p.tail, tailAngle: p.tailAngle, tailFullness: p.tailFullness } };
};
const asSummary = (f: ReturnType<typeof presetDesignFields>): DesignSummaryFields => ({ ...f, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC });

for (const preset of BOARD_PRESETS) {
  const live = asSummary(presetDesignFields(preset));
  measure(`${preset.id} (card)`, live);
  measure(`${preset.id} (record)`, asSummary(recordedPresetDesignFields(preset)));
  if (preset.id === "shortboard" || preset.id === "fish") {
    for (const kind of ["squash", "pin", "round", "diamond", "swallow"] as const) measure(`${preset.id} +${kind}`, withTail(live, kind));
  }
}
const first: DesignSummaryFields = {
  outline: DEFAULT_BOARD_SPEC.outline,
  rocker: DEFAULT_BOARD_SPEC.rocker,
  foil: DEFAULT_BOARD_SPEC.foil,
  rails: DEFAULT_RAIL_BAND_SPEC,
  volume: DEFAULT_VOLUME_SPEC,
  railsImportFoilThickness: true,
  blank: null,
};
measure("first board", first);
for (const kind of ["diamond", "swallow"] as const) measure(`first board +${kind}`, withTail(first, kind));

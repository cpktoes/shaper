import { presetDesignFields } from "@/lib/blanks/preset-blanks";
import { TAIL_PRESETS, DEFAULT_BOARD_SPEC, type OutlineSpec } from "@/lib/geometry/board";
import { LIVE_DESIGN_RULES, deriveEffectiveRails, designSideProfile, type DesignSummaryFields } from "@/lib/geometry/design";
import { buildOutline, foamHalfWidth, outlinePlanArea, sampleOutline, tailCutStation } from "@/lib/geometry/outline";
import { BOARD_PRESETS } from "@/lib/geometry/presets";
import { silhouette } from "@/lib/geometry/screen-tiles";
import { DEFAULT_VOLUME_SPEC, SIMPSON_PANEL_COUNT, computeCrossSectionVolume, simpsonIntegrate } from "@/lib/geometry/volume";
import { DEFAULT_RAIL_BAND_SPEC } from "@/lib/geometry/rail-bands";
import { mm } from "@/lib/geometry/units";
function shoelace(pts: { station: number; w: number }[]) { let a = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p.station * q.w - q.station * p.w; } return Math.abs(a) / 2; }
function stations(L: number, c: number) { const h = L / SIMPSON_PANEL_COUNT; if (c <= 0) return { st: Array.from({ length: 51 }, (_, i) => i * h), m: 0, h1: 0, h2: h }; const m = Math.max(2, 2 * Math.round(c / (2 * h))); const h1 = c / m, h2 = (L - c) / (SIMPSON_PANEL_COUNT - m); const st: number[] = []; for (let i = 0; i <= m; i++) st.push(i * h1); for (let i = 1; i <= SIMPSON_PANEL_COUNT - m; i++) st.push(c + i * h2); return { st, m, h1, h2 }; }
function simp(v: number[], g: ReturnType<typeof stations>) { return g.m === 0 ? simpsonIntegrate(v, g.h2) : simpsonIntegrate(v.slice(0, g.m + 1), g.h1) + simpsonIntegrate(v.slice(g.m), g.h2); }
const boards: [string, DesignSummaryFields][] = [];
const first: DesignSummaryFields = { outline: DEFAULT_BOARD_SPEC.outline, rocker: DEFAULT_BOARD_SPEC.rocker, foil: DEFAULT_BOARD_SPEC.foil, rails: DEFAULT_RAIL_BAND_SPEC, volume: DEFAULT_VOLUME_SPEC, railsImportFoilThickness: true, blank: null };
const all = [...BOARD_PRESETS.map((p) => [p.id, { ...presetDesignFields(p), railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC } as DesignSummaryFields] as const), ["first", first] as const];
for (const [id, f] of all) for (const k of ["squash", "pin", "round", "diamond", "swallow"] as const) { const t = TAIL_PRESETS[k]; boards.push([`${id}+${k}`, { ...f, outline: { ...f.outline, tail: t.tail, tailAngle: t.tailAngle, tailFullness: t.tailFullness } as OutlineSpec }]); }
let worstPiece = 0, worstWhole = 0, worstStation = 0, clamps = 0;
for (const [name, f] of boards) {
  const g = buildOutline(f.outline); const c = tailCutStation(g); const L = f.outline.length; const gs = stations(L, c);
  const foam = gs.st.map((s) => 2 * foamHalfWidth(g, mm(s))); const samp = gs.st.map((s) => 2 * sampleOutline(g, mm(s)));
  const sh = shoelace(silhouette(g)); const plan = outlinePlanArea(g);
  const Sfoam = simp(foam, gs);
  if (c > 0) {
    const diamond = g.centreCloseStation < g.points[0].station;
    const piece = diamond ? simpsonIntegrate(foam.slice(0, gs.m + 1), gs.h1) : simpsonIntegrate(gs.st.slice(0, gs.m + 1).map((s, i) => samp[i] - foam[i]), gs.h1);
    const target = diamond ? plan - g.area : g.area - plan;
    worstPiece = Math.max(worstPiece, Math.abs(piece - target) / target);
    const Scurve = diamond ? simpsonIntegrate(samp.slice(gs.m), gs.h2) : simp(samp, gs);
    worstWhole = Math.max(worstWhole, Math.abs((Sfoam - sh) - (Scurve - g.area)) / sh);
    for (let i = 0; i <= gs.m; i++) { const s = mm(gs.st[i]); const raw = sampleOutline(g, s) - (g.points[0].halfWidth * ((g.centreCloseStation - s) / (g.centreCloseStation - g.points[0].station))); if (!diamond && raw < 0) clamps++; }
    // station-level: removal vs 2 e T at in-cut stations
    const prof = designSideProfile(f, LIVE_DESIGN_RULES); const rails = deriveEffectiveRails(f.rails, prof.effectiveFoil, true);
    const base = { foil: prof.effectiveFoil, thicknessAt: prof.thicknessAt, rails, length: L, cutStation: c };
    const cut = computeCrossSectionVolume({ ...base, halfWidthAt: (s) => foamHalfWidth(g, s) });
    const unc = computeCrossSectionVolume({ ...base, halfWidthAt: (s) => sampleOutline(g, s) });
    for (let i = gs.m; i < gs.st.length; i++) if (!Object.is(cut.stationAreas[i], unc.stationAreas[i])) console.log("MISMATCH past corner", name, i);
    const T = (s: number) => prof.thicknessAt(mm(s));
    const rows = [];
    for (let i = 0; i < gs.m; i++) { const s = gs.st[i]; const removed = unc.stationAreas[i] - cut.stationAreas[i]; const e = sampleOutline(g, mm(s)) - foamHalfWidth(g, mm(s)); rows.push(`s${s.toFixed(1)} removed ${removed.toFixed(3)} 2eT ${(2 * e * T(s)).toFixed(3)} foamW ${foamHalfWidth(g, mm(s)).toFixed(2)}`); if (!diamond && foamHalfWidth(g, mm(s)) > 0) worstStation = Math.max(worstStation, Math.abs(removed - 2 * e * T(s)) / (2 * e * T(s))); }
    console.log(name.padEnd(20), "m", gs.m, "c", c.toFixed(2), "Lnew", cut.volumeLitres.toFixed(4), "Luncut-same-stations", unc.volumeLitres.toFixed(4), "|", rows.join(" ; "));
  } else {
    worstWhole = Math.max(worstWhole, Math.abs(plan - g.area));
    if (!Object.is(plan, g.area)) console.log("area not identical", name);
  }
}
console.log("worst piece rel", worstPiece.toExponential(2), "worst whole rel", worstWhole.toExponential(2), "worst station 2eT rel", worstStation.toExponential(2), "clamps", clamps);

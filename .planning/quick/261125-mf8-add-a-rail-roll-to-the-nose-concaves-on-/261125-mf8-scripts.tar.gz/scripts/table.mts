// Quick 261125-mf8, D-09: the before/after table for the SUMMARY, from two runs of measure.mts.
//   npx --no-install tsx table.mts <before label> <after label>
// Prints a markdown table (widest / typical miss in mm) and, under it, every file that is not identical. "identical" means
// the fitted cuts, every measured section value and the fitted rails all matched (one digest), not only the rounded figures.
import { readFileSync } from "node:fs";
const dir = new URL("../out/", import.meta.url);
const [a, b] = process.argv.slice(2);
const A = JSON.parse(readFileSync(new URL(a + ".json", dir), "utf8"));
const B = JSON.parse(readFileSync(new URL(b + ".json", dir), "utf8"));
const short = (n: string[]) => n.map((x) => x.replace(/ (Entry|Center|Exit)$/, "")).join(" · ");
const two = (v: number[] | null) => (v ? v.map((x) => x.toFixed(2)).join(" / ") : "none");
console.log(`| File | Bottom before | Bottom after | Rails before | Rails after | Cuts before | Cuts after | Open before | Open after |\n|---|---|---|---|---|---|---|---|---|`);
let ta = 0;
let tb = 0;
const moved: string[] = [];
for (const ra of A) {
  const rb = B.find((x: any) => x.file === ra.file);
  if (!rb) {
    moved.push(`${ra.file}: missing from ${b}`);
    continue;
  }
  ta += ra.secs;
  tb += rb.secs;
  const identical = ra.digest === rb.digest;
  if (!identical) moved.push(`${ra.file}: bottom ${ra.widest.toFixed(2)} / ${ra.typical.toFixed(2)} -> ${rb.widest.toFixed(2)} / ${rb.typical.toFixed(2)}, rails ${two(ra.rails)} -> ${two(rb.rails)}, ${rb.cuts.join(" · ")}${rb.roll !== rb.openedRoll ? ` (!! opens with a roll of ${rb.openedRoll}")` : ""}`);
  console.log(
    `| ${ra.file.replace(".brd", "")} | ${ra.widest.toFixed(2)} / ${ra.typical.toFixed(2)} | ${identical ? "identical" : `${rb.widest.toFixed(2)} / ${rb.typical.toFixed(2)}`} | ${two(ra.rails)} | ${identical ? "identical" : two(rb.rails)} | ${short(ra.cuts)} | ${identical ? "same" : short(rb.cuts)} | ${ra.secs.toFixed(2)} s | ${rb.secs.toFixed(2)} s |`,
  );
}
console.log(`| Total | | | | | | | ${ta.toFixed(1)} s | ${tb.toFixed(1)} s |`);
console.log(`\nNot identical (${moved.length}):\n${moved.map((m) => "- " + m).join("\n") || "- none"}`);

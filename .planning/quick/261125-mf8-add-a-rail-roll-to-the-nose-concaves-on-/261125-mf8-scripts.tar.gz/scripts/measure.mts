// Quick 261125-mf8, D-09: the founder's twelve sample files through the real import (brdLookFromBytes), one after another.
// The files are READ from ~/Downloads and never copied anywhere (the `_decrypt` copies and test-curves-v2.brd are skipped).
//
//   MF8_ROOT=<checkout root> npx --no-install tsx --tsconfig <the SAME checkout root>/tsconfig.json measure.mts <label> [reps]
//
// The tsconfig must be the measured checkout's own: lib code imports `@/lib/...`, and that alias resolves beside the tsconfig.
// Writes ../out/<label>.json beside this script's folder. `secs` is the fastest of `reps` opens (3 by default), because a
// single open wobbles by a second on a busy machine. Nothing of a file's own drawing is written out: only what the app fitted
// (names, numbers, how close) and one digest of the fitted cuts and the measured sections, so two runs can be called identical.
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";

const ROOT = process.env.MF8_ROOT;
if (!ROOT) throw new Error("set MF8_ROOT to the checkout to measure");
const { brdLookFromBytes } = await import(ROOT + "/lib/export/brd-look.ts");
const DL = homedir() + "/Downloads";
const FILES = readdirSync(DL)
  .filter((f) => f.endsWith(".brd") && !f.includes("_decrypt") && f !== "test-curves-v2.brd")
  // MF8_ONLY=92Log,Scoop measures only the files whose names hold one of those words (for a quick look; the table needs all twelve).
  .filter((f) => !process.env.MF8_ONLY || process.env.MF8_ONLY.split(",").some((word) => f.includes(word)))
  .sort();
const label = process.argv[2] ?? "run";
const reps = Number(process.argv[3] ?? 3);
const IN = 25.4;
const sixtyFourths = (v: number) => `${Math.round((v / IN) * 64)}/64"`;
// The build stores the roll as `railRoll`; spike 005's trial code called it `edgeRoll`.
const rollOf = (c: any): number => c.railRoll ?? c.edgeRoll ?? 0;
const cutWords = (c: any) => (c.depth > 0 ? `${c.name} ${sixtyFourths(c.depth)}${rollOf(c) > 0 ? `, Rail Roll ${sixtyFourths(rollOf(c))}` : ""}` : c.name);

const bytesOf = (f: string) => new Uint8Array(readFileSync(DL + "/" + f));
brdLookFromBytes(bytesOf(FILES[0]), FILES[0]); // warm up
const rows: any[] = [];
for (const f of FILES) {
  let secs = Infinity;
  let r: any = null;
  for (let rep = 0; rep < reps; rep++) {
    const bytes = bytesOf(f);
    const t0 = performance.now();
    r = brdLookFromBytes(bytes, f);
    secs = Math.min(secs, (performance.now() - t0) / 1000);
  }
  if (!r.ok) {
    console.log(f, "NOT OK", r.problem);
    continue;
  }
  const b = r.look.bottom;
  const ra = r.look.rails;
  const cuts3 = b ? [b.bottom.nose, b.bottom.center, b.bottom.tail] : [];
  const digest = createHash("sha1")
    .update(JSON.stringify({ cuts: cuts3, ours: b ? b.sections.map((s: any) => [s.station, s.ours, s.gap]) : [], rails: ra ? [ra.rails, ra.closeness] : null }))
    .digest("hex")
    .slice(0, 16);
  const row = {
    file: f,
    names: cuts3.map((c: any) => c.name),
    cuts: cuts3.map(cutWords),
    roll: cuts3.length ? +(rollOf(cuts3[0]) / IN).toFixed(3) : 0,
    openedRoll: r.fields?.bottom?.nose ? +(rollOf(r.fields.bottom.nose) / IN).toFixed(3) : 0,
    widest: b ? +b.closeness.largest.toFixed(3) : null,
    typical: b ? +b.closeness.typical.toFixed(3) : null,
    at: b ? [+(b.closeness.station / IN).toFixed(1), +(b.closeness.across / IN).toFixed(2)] : null,
    rails: ra ? [+ra.closeness.largest.toFixed(2), +ra.closeness.typical.toFixed(2)] : null,
    order: ra?.order ?? null,
    secs: +secs.toFixed(2),
    digest,
  };
  rows.push(row);
  console.log(`${f.padEnd(36)} bottom ${row.widest?.toFixed(2)} / ${row.typical?.toFixed(2)}  rails ${row.rails?.map((v) => v.toFixed(2)).join(" / ")} ${row.order}  ${row.secs.toFixed(2)} s\n    ${row.cuts.join(" · ")}${row.roll !== row.openedRoll ? `   !! the board opens with a roll of ${row.openedRoll}" (the look says ${row.roll}")` : ""}`);
}
console.log(`${rows.length} files, total ${rows.reduce((a, r) => a + r.secs, 0).toFixed(1)} s (fastest of ${reps})`);
const out = new URL("../out/", import.meta.url);
mkdirSync(out, { recursive: true });
writeFileSync(new URL(label + ".json", out), JSON.stringify(rows, null, 1));

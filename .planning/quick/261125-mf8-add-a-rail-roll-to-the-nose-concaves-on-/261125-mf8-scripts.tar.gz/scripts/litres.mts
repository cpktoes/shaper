// Plan-time check (quick 261125-mf8): the litres of a board with a Blended Nose Concave and a roll of 0, 1/8", 1/4" and 1/2".
//   ROOT=<checkout> [ROLL_KEY=railRoll] tsx --tsconfig <checkout>/tsconfig.json litres.mts
const ROOT = process.env.ROOT!;
const KEY = process.env.ROLL_KEY ?? "railRoll";
const imp = (p: string) => import(`${ROOT}/${p}`);
const B = await imp("lib/geometry/bottom.ts");
const D = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
for (const label of ["shortboard", "midlength", "longboard"]) {
  const fields = phase16Boards().find((b: any) => b.label.startsWith(`${label}|asis|`))!.fields;
  const board = D.designBottomBoard(fields.outline, buildOutline(fields.outline), D.designSideProfile(fields, D.LIVE_DESIGN_RULES), D.designFinPlacement(fields));
  const out: string[] = [];
  for (const r of [0, 1 / 8, 1 / 4, 1 / 2]) {
    const nose: any = { ...B.startingCut("nose", "Blended Nose Concave", board) };
    if (r > 0) nose[KEY] = inchesToMm(r);
    const s = D.summarizeDesign({ ...fields, bottom: { ...structuredClone(B.DEFAULT_BOTTOM), nose } });
    out.push(`roll ${r}" ${s.volumeLitres.toFixed(3)} L`);
  }
  console.log(label, out.join(" | "), "| flat", D.summarizeDesign(fields).volumeLitres.toFixed(3));
}

// Plan-time check (quick 261125-mf8): RAILS' nose rail standing on a rolled nose concave. The roll is a lift, so the nose
// rail is thinned by it (railsOnTheBottom) and the section is drawn on the bottom the cut leaves (railBandsOnTheBottom).
//   ROOT=<checkout> [ROLL_KEY=railRoll] tsx --tsconfig <checkout>/tsconfig.json rails.mts
const ROOT = process.env.ROOT!;
const KEY = process.env.ROLL_KEY ?? "railRoll";
const imp = (p: string) => import(`${ROOT}/${p}`);
const B = await imp("lib/geometry/bottom.ts");
const D = await imp("lib/geometry/design.ts");
const R = await imp("lib/geometry/rail-bands.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const IN = 25.4;
for (const label of ["shortboard", "midlength", "longboard"]) {
  const fields = phase16Boards().find((b: any) => b.label.startsWith(`${label}|asis|`))!.fields;
  const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
  const board = D.designBottomBoard(fields.outline, buildOutline(fields.outline), profile, D.designFinPlacement(fields));
  const effective = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const anchors = D.railAnchorStations(profile.effectiveFoil, fields.outline.length);
  for (const r of [0, 1 / 8, 1 / 4]) {
    const nose: any = { ...B.startingCut("nose", "Blended Nose Concave", board) };
    if (r > 0) nose[KEY] = inchesToMm(r);
    const resolved = B.resolveBottom({ ...structuredClone(B.DEFAULT_BOTTOM), nose }, board);
    const rails = D.railsOnTheBottom(effective, D.bottomRailLift(resolved, board), anchors);
    const bands = D.railBandsOnTheBottom(R.computeRailBands(rails), resolved, board, anchors);
    const b = bands.nose.bottom;
    console.log(`${label.padEnd(10)} roll ${r.toFixed(3)}": nose rail thickness ${(effective.nose.boardThickness / IN).toFixed(4)}" -> ${(rails.nose.boardThickness / IN).toFixed(4)}" (thinned ${((effective.nose.boardThickness - rails.nose.boardThickness) / IN).toFixed(4)}"); centre and tail rails ${rails.center === effective.center && rails.tail === effective.tail ? "untouched" : "CHANGED"}; nose section bottom ${b ? `drawn, ${b.across.length} points, lift ${(b.lift / IN).toFixed(4)}"` : "none"}`);
  }
}

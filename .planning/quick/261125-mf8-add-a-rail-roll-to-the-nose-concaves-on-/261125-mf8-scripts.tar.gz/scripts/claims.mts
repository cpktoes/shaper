// Plan-time check of the claims the plan's tests make (quick 261125-mf8): the floor's flags, RAILS' rail lift at the nose
// anchor and DATA's rail lift, for each nose concave at its starting numbers with a roll of 0, 1/8" and 1/2".
//   ROOT=<checkout> [ROLL_KEY=railRoll] tsx --tsconfig <checkout>/tsconfig.json claims.mts
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const B = await imp("lib/geometry/bottom.ts");
const D = await imp("lib/geometry/design.ts");
const { inchesToMm, mm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { boardSections } = await imp("lib/geometry/volume.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const IN = 25.4;
const KEY = process.env.ROLL_KEY ?? "railRoll";
for (const label of ["shortboard", "fish", "midlength", "longboard"]) {
  const fields = phase16Boards().find((b: any) => b.label.startsWith(`${label}|asis|`))!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
  const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = D.designBottomBoard(fields.outline, geometry, profile, D.designFinPlacement(fields));
  const anchors = D.railAnchorStations(profile.effectiveFoil, fields.outline.length);
  for (const name of ["Blended Nose Concave", "Teardrop Nose Concave", "Slight Single Concave Entry"]) {
    for (const r of [0, 1 / 8, 1 / 2]) {
      const nose: any = { ...B.startingCut("nose", name, board) };
      if (r > 0) nose[KEY] = inchesToMm(r);
      const bottom = { ...structuredClone(B.DEFAULT_BOTTOM), nose };
      const resolved = B.resolveBottom(bottom, board);
      const sections = boardSections(D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }));
      const flags = B.bottomFloorFlags(resolved, board, sections);
      const nf = flags.find((f: any) => f.section === "nose");
      const lift = D.bottomRailLift(resolved, board)(anchors.nose);
      const c = resolved.nose;
      const rows = B.bottomDataRows(resolved, board);
      const maxLift = Math.max(...rows.map((x: any) => x.railLift));
      console.log(`${label.padEnd(10)} ${name.padEnd(28)} roll ${r.toFixed(3)}": nose flag ${nf ? `stringer ${nf.stringer.length} rails ${nf.rails.length}` : "none"} | rail lift at the nose anchor (${((board.length - anchors.nose) / IN).toFixed(1)}" from the nose; Deepest At ${((board.length - c.deepest) / IN).toFixed(1)}", End ${((board.length - c.end) / IN).toFixed(1)}") ${(lift / IN).toFixed(4)}" | DATA max rail lift ${(maxLift / IN).toFixed(4)}"`);
    }
  }
}

// Plan-time measurement (quick 261125-mf8): a board the app writes with a nose concave and a roll, saved as a .brd and
// opened again through the real import (brdLookFromBytes).
//   ROOT=<checkout> [ROLL_KEY=railRoll] [CASES="board:name:depth16:roll64,..."] tsx --tsconfig <checkout>/tsconfig.json roundtrip.mts
// The build stores the roll as `railRoll` (the default here); spike 005's trial code called it `edgeRoll` (ROLL_KEY=edgeRoll).
const ROOT = process.env.ROOT!;
const imp = (p: string) => import(`${ROOT}/${p}`);
const { buildBoardSurface } = await imp("lib/geometry/board-surface.ts");
const { DEFAULT_BOTTOM, resolveBottom, startingCut } = await imp("lib/geometry/bottom.ts");
const { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } = await imp("lib/geometry/design.ts");
const { inchesToMm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const { brdBottomStations, brdText } = await imp("lib/export/brd.ts");
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");

const KEY = process.env.ROLL_KEY ?? "railRoll";
const IN = 25.4;
const cases = (process.env.CASES ?? "longboard:Blended Nose Concave:3:16,longboard:Blended Nose Concave:3:8,midlength:Blended Nose Concave:3:16,shortboard:Blended Nose Concave:3:16").split(",");

for (const c of cases) {
  const [label, name, d16, r64] = c.split(":");
  const fields = phase16Boards().find((b: any) => b.label === `${label}|asis|hard`)!.fields;
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = designBottomBoard(fields.outline, geometry, profile, designFinPlacement(fields));
  const nose: any = { ...startingCut("nose", name, board), depth: inchesToMm(Number(d16) / 16) };
  if (Number(r64) > 0) nose[KEY] = inchesToMm(Number(r64) / 64);
  const bottom = { ...structuredClone(DEFAULT_BOTTOM), nose };
  const surface = buildBoardSurface({ sections: designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }), geometry, rockerAt: profile.rockerAt });
  const bytes = Uint8Array.from(brdText(surface, { bottomStations: brdBottomStations(resolveBottom(bottom, board)) }).text, (ch: string) => ch.charCodeAt(0));
  const t0 = performance.now();
  const r = brdLookFromBytes(bytes, "x.brd");
  const secs = (performance.now() - t0) / 1000;
  if (!r.ok) { console.log(c, "NOT READ", r.problem); continue; }
  const b = r.look.bottom!;
  const cut = (k: any) => `${k.name} ${(k.depth / IN).toFixed(3)}"${k[KEY] ? ` roll ${(k[KEY] / IN).toFixed(3)}"` : ""}${k.offRail ? ` offRail ${(k.offRail / IN).toFixed(2)}"` : ""}`;
  const st = (k: any) => `start ${(k.start / IN).toFixed(1)} deepest ${(k.deepest / IN).toFixed(1)} end ${(k.end / IN).toFixed(1)}`;
  console.log(`${c.padEnd(48)} wrote: offRail ${(nose.offRail / IN).toFixed(2)}" ${st(nose)}`);
  console.log(`   -> ${cut(b.bottom.nose)} (${st(b.bottom.nose)}) · ${cut(b.bottom.center)} · ${cut(b.bottom.tail)}`);
  console.log(`   bottom ${b.closeness.largest.toFixed(2)} / ${b.closeness.typical.toFixed(2)}  rails ${r.look.rails ? r.look.rails.closeness.largest.toFixed(2) + " / " + r.look.rails.closeness.typical.toFixed(2) : "-"}  order ${r.look.rails?.order ?? "-"}  ${secs.toFixed(2)} s  fields.nose roll ${r.fields?.bottom?.nose?.[KEY] !== undefined ? (r.fields.bottom.nose[KEY] / IN).toFixed(3) : "none"}`);
}

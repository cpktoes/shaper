// Plan-time measurement (quick 261125-mf8): the nose retry in polishBrdBottom alone, on sections that are EXACTLY a written
// bottom's (the way lib/geometry/brd-bottom.test.ts's `exact` helper makes them: 40 stations, read out to the rail itself).
//   ROOT=<checkout> [ROLL_KEY=railRoll] tsx --tsconfig <checkout>/tsconfig.json exact.mts
const ROOT = process.env.ROOT!;
const KEY = process.env.ROLL_KEY ?? "railRoll";
const imp = (p: string) => import(`${ROOT}/${p}`);
const B = await imp("lib/geometry/bottom.ts");
const F = await imp("lib/geometry/brd-bottom.ts");
const D = await imp("lib/geometry/design.ts");
const { inchesToMm, mm } = await imp("lib/geometry/units.ts");
const { buildOutline } = await imp("lib/geometry/outline.ts");
const { phase16Boards } = await imp("lib/geometry/__fixtures__/phase16-boards.ts");
const IN = 25.4;
const cases = (process.env.CASES ?? "shortboard:Blended Nose Concave:3:16,shortboard:Blended Nose Concave:3:4,midlength:Blended Nose Concave:3:16").split(",");
for (const c of cases) {
  const [label, name, d16, r64] = c.split(":");
  const fields = phase16Boards().find((b: any) => b.label.startsWith(`${label}|asis|`))!.fields;
  const board = D.designBottomBoard(fields.outline, buildOutline(fields.outline), D.designSideProfile(fields, D.LIVE_DESIGN_RULES), D.designFinPlacement(fields));
  const nose: any = { ...B.startingCut("nose", name, board), depth: inchesToMm(Number(d16) / 16) };
  if (Number(r64) > 0) nose[KEY] = inchesToMm(Number(r64) / 64);
  const wanted = { ...structuredClone(B.DEFAULT_BOTTOM), nose };
  const resolved = B.resolveBottom(wanted, board);
  const lines = Array.from({ length: 40 }, (_, k) => 0.03 + (0.94 * k) / 39).map((share) => {
    const station = mm(share * board.length);
    const reach = board.railAt(station) / F.BRD_BOTTOM_WINDOW;
    const at0 = B.sectionsFoamOff(resolved, board, station, mm(0));
    const run = Array.from({ length: 61 }, (_, j) => {
      const x = (reach * j) / 60;
      return [x, B.sectionsFoamOff(resolved, board, station, mm(x)) - at0];
    });
    return { station, points: [...run, [reach, run[60][1] + 20], [0, run[60][1] + 40]] };
  });
  const t0 = performance.now();
  const grid = F.fitBottomToBrd(lines, board)!;
  const t1 = performance.now();
  const polished = F.polishBrdBottom(grid.bottom, grid.sections, board);
  const t2 = performance.now();
  const shown = (b: any) => F.measureBrdBottom(b, grid.sections, board).closeness;
  const cut = (k: any) => `${k.name} ${(k.depth / IN).toFixed(3)}"${k[KEY] ? ` roll ${(k[KEY] / IN).toFixed(3)}"` : ""}${k.offRail ? ` offRail ${(k.offRail / IN).toFixed(2)}"` : ""}`;
  const g = shown(grid.bottom);
  const p = shown(polished);
  console.log(`${c}\n   grid     ${cut(grid.bottom.nose)} · ${cut(grid.bottom.center)} · ${cut(grid.bottom.tail)}   ${g.largest.toFixed(3)} / ${g.typical.toFixed(3)}  (${((t1 - t0) / 1000).toFixed(1)} s)\n   polished ${cut(polished.nose)} · ${cut(polished.center)} · ${cut(polished.tail)}   ${p.largest.toFixed(3)} / ${p.typical.toFixed(3)}  (${((t2 - t1) / 1000).toFixed(1)} s)`);
}

Quick 261125-mf8: the measuring scripts and the planner's own results (2026-11-25).

scripts/measure.mts    the founder's twelve sample .brd files through the real import (brdLookFromBytes); writes out/<label>.json
scripts/table.mts      the before/after table for the SUMMARY from two of those runs
scripts/roundtrip.mts  a board the app writes with a nose concave and a roll, saved as a .brd and opened again
scripts/exact.mts      the nose retry in polishBrdBottom alone, on sections that are exactly a written bottom's
scripts/claims.mts     the floor's flags, RAILS' rail lift and DATA's rail lift for each nose concave with a roll
scripts/litres.mts     the litres of a board with a roll of 0, 1/8", 1/4" and 1/2"
scripts/rails.mts      RAILS' nose rail standing on a rolled nose concave

out/plan-*             the planner's runs. "trial" is spike 005's trial code (stored key `edgeRoll`, switched on with
                       SPIKE_STARTS=nose SPIKE_POLISH=roll-nose SPIKE_GATE_MM=1 SPIKE_ONE=1) in a throwaway copy of main 971c15da;
                       "before" and "today" are main 971c15da itself; "strict-bar" is the trial code with the quarter-millimetre
                       bar asked of every retry, not only of one that changes the nose's name.

Every script takes the checkout to measure from the environment and must be run with THAT checkout's own tsconfig. The
sample files are read where they are (~/Downloads) and never copied; nothing of a file's own drawing is written out.

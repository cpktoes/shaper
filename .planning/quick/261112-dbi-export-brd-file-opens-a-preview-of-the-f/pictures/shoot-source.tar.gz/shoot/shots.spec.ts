// Quick 261112-dbi's picture script: the Board file preview on a computer (light and dark, Deep Single Shortboard; the Fish),
// an upright iPhone and a sideways one. Scratch only.
import { devices, expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/blanks/preset-blanks";
import { DEFAULT_BOTTOM, pickCut, startingChannels, type BoardBottom } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/bottom";
import { LIVE_DESIGN_RULES, designBottomBoard, designFinPlacement, designSideProfile } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/banner-dismissal";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/toolbar-tip";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/components/3d/three-d-copy";

function strip<T extends { defaultBrowserType?: unknown }>(device: T) {
  const { defaultBrowserType, ...rest } = device;
  void defaultBrowserType;
  return rest;
}

const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/.planning/quick/261112-dbi-export-brd-file-opens-a-preview-of-the-f/pictures";

function fieldsOf(name: string, bottom?: BoardBottom) {
  const preset = BOARD_PRESETS.find((p) => p.name === name)!;
  return {
    ...presetDesignFields(preset),
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2" as const,
    ...(bottom ? { bottom } : {}),
  };
}

function deepSingleFourChannels(name: string): BoardBottom {
  const f = fieldsOf(name);
  const board = designBottomBoard(f.outline, buildOutline(f.outline), designSideProfile(f, LIVE_DESIGN_RULES), designFinPlacement(f));
  const cuts = pickCut(DEFAULT_BOTTOM, "center", "Deep Single Concave", board);
  return { ...cuts, channels: startingChannels(4, board, cuts.channels) };
}

async function setUp(page: Page, name: string, theme: "daylight" | "slate", bottom?: BoardBottom) {
  const raw = openBoardCopyJson(fieldsOf(name, bottom), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeValue]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem("shaper-theme", themeValue);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, theme] as const,
  );
  await page.addInitScript(() => { const st = document.createElement("style"); st.textContent = "nextjs-portal{display:none !important}"; document.addEventListener("DOMContentLoaded", () => document.head.appendChild(st)); });
  await page.goto("/design/3d");
  await expect(page.locator("[data-board-3d]")).toHaveAttribute("data-board-state", "ready", { timeout: 60_000 });
  await page.getByRole("button", { name: THREE_D_COPY.exportButton, exact: true }).click();
  const dialog = page.locator("[data-brd-preview]");
  await expect(dialog).toBeVisible();
  await expect(dialog.locator("[data-brd-preview-top] [data-brd-slice]").first()).toBeAttached();
  await page.waitForTimeout(600);
  return dialog;
}

test.describe("desktop", () => {
  test.use({ ...strip(devices["Desktop Chrome"]), viewport: { width: 1280, height: 800 } });
  for (const [theme, file] of [["daylight", "preview-desktop-light-deep-single.png"], ["slate", "preview-desktop-dark-deep-single.png"]] as const) {
    test(`deep single ${theme}`, async ({ page }) => {
      await setUp(page, "Shortboard", theme, deepSingleFourChannels("Shortboard"));
      await page.screenshot({ path: `${PICTURES}/${file}` });
    });
  }
  test("fish", async ({ page }) => {
    await setUp(page, "Fish", "daylight");
    await page.screenshot({ path: `${PICTURES}/preview-desktop-fish.png` });
  });
});

test.describe("phone upright", () => {
  test.use({ ...strip(devices["iPhone 14"]) });
  test("upright", async ({ page }) => {
    await setUp(page, "Shortboard", "daylight", deepSingleFourChannels("Shortboard"));
    await page.screenshot({ path: `${PICTURES}/preview-phone-upright.png` });
    const body = page.locator("[data-brd-preview-body]");
    await body.evaluate((el) => el.scrollTo({ top: el.scrollHeight }));
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${PICTURES}/preview-phone-upright-scrolled.png` });
  });
});

const { defaultBrowserType, viewport, ...iphoneLandscape } = devices["iPhone 14 landscape"];
void defaultBrowserType;
void viewport;
test.describe("phone sideways", () => {
  test.use({ ...iphoneLandscape, viewport: { width: 844, height: 390 } });
  test("sideways", async ({ page }) => {
    await setUp(page, "Shortboard", "daylight", deepSingleFourChannels("Shortboard"));
    await page.screenshot({ path: `${PICTURES}/preview-phone-sideways.png` });
    const body = page.locator("[data-brd-preview-body]");
    await body.evaluate((el) => el.scrollTo({ top: el.scrollHeight }));
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${PICTURES}/preview-phone-sideways-scrolled.png` });
  });
});

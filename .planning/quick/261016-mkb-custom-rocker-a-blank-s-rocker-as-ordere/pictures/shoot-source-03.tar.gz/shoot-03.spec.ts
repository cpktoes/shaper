import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen, openPhoneMenu } from "../../../../e2e/helpers/screens";
import {
  blankRockerLine,
  closeBlankPicker,
  customRockerDialog,
  openBlankPicker,
  openCustomizeRocker,
  pickSavedBlank,
  pickedCard,
  savedCards,
  waitForBlankButton,
} from "../../../../e2e/helpers/blank-picker";

// Plan 03's pictures (quick 261016-mkb): the Longboard preset in the US Blanks 9'4"B, with
// -1/4"N18" +1/8"T36" +1/8"T18" saved through the popup, then a second saved blank, +1/2"T, so two
// saved cards show beside the maker's natural 9'4"B.
const OUT = __dirname;
const SKETCH_NOTE = '-1/4"N18" +1/8"T36" +1/8"T18"';

async function setup(page: Page) {
  await page.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
    window.localStorage.setItem("shaper-theme", "slate");
  });
  await page.goto("/");
  const longboard = page.getByRole("button").filter({ hasText: "Longboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    await longboard.first().click();
    await page.waitForURL("**/design/outline", { timeout: 2_000 });
  }).toPass({ timeout: 30_000 });
  // The dev server's own badge is not part of the app; keep it out of the pictures.
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await goToScreen(page, "ROCKER");
  await waitForBlankButton(page);
}

async function pressUntil(page: Page, thumb: Locator, key: string, want: string, max = 80) {
  await thumb.focus();
  for (let i = 0; i < max; i++) {
    if ((await thumb.getAttribute("aria-valuetext")) === want) return;
    await page.keyboard.press(key);
  }
  await expect(thumb).toHaveAttribute("aria-valuetext", want);
}

const slider = (dialog: Locator, name: string) => dialog.getByRole("slider", { exact: true, name });

/** Saves the sketch's rocker, then a second blank with +1/2"T. Returns the blank's maker and name. */
async function saveTwo(page: Page): Promise<{ vendor: string; name: string }> {
  const name = (await pickedCard(page).locator("[data-blank-name]").innerText()).trim();
  let dialog = await openCustomizeRocker(page);
  await pressUntil(page, slider(dialog, "Nose rocker change"), "ArrowLeft", '-1/4"');
  await pressUntil(page, slider(dialog, "Nose bend starts"), "ArrowLeft", '18" in');
  await pressUntil(page, slider(dialog, "Tail rocker change"), "ArrowRight", '+1/8"');
  await pressUntil(page, slider(dialog, "Tail bend starts"), "ArrowLeft", '36" in');
  await dialog.getByRole("button", { name: "+ Add a second tail change" }).click();
  await expect(dialog.locator("[data-customize-rocker-note]")).toContainText(SKETCH_NOTE);
  await dialog.getByRole("button", { name: "Use and save as a new blank" }).click();
  await expect(customRockerDialog(page)).toBeHidden();
  await expect(blankRockerLine(page)).toHaveText(SKETCH_NOTE);

  dialog = await openCustomizeRocker(page);
  await dialog.getByRole("button", { name: "↺ Natural rocker" }).click();
  await pressUntil(page, slider(dialog, "Tail rocker change"), "ArrowRight", '+1/2"');
  await dialog.getByRole("button", { name: "Use and save as a new blank" }).click();
  await expect(customRockerDialog(page)).toBeHidden();
  await expect(blankRockerLine(page)).toHaveText('+1/2"T');
  const card = await openBlankPicker(page);
  const vendor = (await savedCards(card).first().getAttribute("data-vendor"))!;
  await closeBlankPicker(page);
  return { vendor, name };
}

/** Opens Pick a Blank searching the blank's name, so its saved twins and the natural one show together. */
async function pickerOn(page: Page, vendor: string, name: string): Promise<Locator> {
  const dialog = await openBlankPicker(page);
  await dialog.getByRole("searchbox", { name: "Search blanks" }).fill(`${vendor} ${name}`);
  await expect(savedCards(dialog)).toHaveCount(2);
  await dialog.getByRole("searchbox", { name: "Search blanks" }).blur();
  await page.mouse.move(1, 1);
  return dialog;
}

async function shot(page: Page, name: string, clip?: Locator) {
  await page.waitForTimeout(400);
  if (clip) await clip.screenshot({ path: `${OUT}/${name}` });
  else await page.screenshot({ path: `${OUT}/${name}` });
}

test("computer", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page);
  const { vendor, name } = await saveTwo(page);
  const dialog = await pickerOn(page, vendor, name);
  await shot(page, "03-computer-picker-saved.png");
  await dialog.locator("[data-drawn-toggle]").click();
  await expect(dialog.locator('li[data-blank-card][data-drawn="upright"]').first()).toBeVisible();
  await shot(page, "03-computer-picker-upright.png");
  await dialog.locator("[data-drawn-toggle]").click();
  await closeBlankPicker(page);

  // Put the sketch's blank back on the board, then look at the shop's sheet.
  await pickSavedBlank(page, vendor, `${name} ${SKETCH_NOTE}`);
  await expect(blankRockerLine(page)).toHaveText(SKETCH_NOTE);
  await goToScreen(page, "SUMMARY");
  const blankLine = page.getByText("Blank:", { exact: true }).locator("xpath=..");
  await expect(blankLine).toContainText(SKETCH_NOTE);
  // The Shaper Use Only box with the Blank line, centred in the window.
  await blankLine.evaluate((el) => el.scrollIntoView({ block: "center" }));
  await shot(page, "03-computer-order-form.png");
});

test("iphone", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone");
  await setup(page);
  const { vendor, name } = await saveTwo(page);
  const dialog = await pickerOn(page, vendor, name);
  await savedCards(dialog).first().scrollIntoViewIfNeeded();
  await shot(page, "03-iphone-picker-saved.png");
  await closeBlankPicker(page);
  await openPhoneMenu(page);
  await shot(page, "03-iphone-tiles.png");
});

test("pixel7 sideways", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "pixel7-sideways");
  await setup(page);
  const { vendor, name } = await saveTwo(page);
  await pickerOn(page, vendor, name);
  await shot(page, "03-pixel7-sideways-picker.png");
  await closeBlankPicker(page);
  await openPhoneMenu(page);
  await shot(page, "03-pixel7-sideways-tiles.png");
});

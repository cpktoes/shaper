import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";
import { blankRockerLine, customRockerDialog, openCustomizeRocker, waitForBlankButton } from "../../../../e2e/helpers/blank-picker";

// Plan 02's pictures (quick 261016-mkb): the Longboard preset in the US Blanks 9'4"B with
// -1/4"N18" +1/8"T36" +1/8"T18" set through the popup, so the red and the blue both show.
const OUT = __dirname;

async function setup(page: Page, opts: { theme?: string; metric?: boolean } = {}) {
  await page.addInitScript(
    ({ theme, metric }) => {
      window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
      window.localStorage.setItem("shaper-theme", theme);
      if (metric) window.localStorage.setItem("shaper-units", "metric");
    },
    { theme: opts.theme ?? "slate", metric: !!opts.metric },
  );
  await page.goto("/");
  const longboard = page.getByRole("button").filter({ hasText: "Longboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    await longboard.first().click();
    await page.waitForURL("**/design/outline", { timeout: 2_000 });
  }).toPass({ timeout: 30_000 });
  // The dev server's own badge is not part of the app; keep it out of the pictures.
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await goToScreen(page, "ROCKER");
  await waitForBlankButton(page);
}

async function pressUntil(page: Page, thumb: Locator, key: string, want: string, max = 80) {
  await thumb.focus();
  for (let i = 0; i < max; i++) {
    if ((await thumb.getAttribute("aria-valuetext")) === want) return;
    await page.keyboard.press(key);
  }
  await expect(thumb).toHaveAttribute("aria-valuetext", want);
}

const slider = (dialog: Locator, name: string) => dialog.getByRole("slider", { exact: true, name });

/** Opens the popup and sets -1/4"N18" +1/8"T36" +1/8"T18". */
async function setSketchRocker(page: Page, metric = false): Promise<Locator> {
  const dialog = await openCustomizeRocker(page);
  await pressUntil(page, slider(dialog, "Nose rocker change"), "ArrowLeft", metric ? "-6 mm" : '-1/4"');
  await pressUntil(page, slider(dialog, "Nose bend starts"), "ArrowLeft", metric ? /* 18" */ (await bendText(18, true)) : '18" in');
  await pressUntil(page, slider(dialog, "Tail rocker change"), "ArrowRight", metric ? "+3 mm" : '+1/8"');
  await pressUntil(page, slider(dialog, "Tail bend starts"), "ArrowLeft", metric ? await bendText(36, true) : '36" in');
  await dialog.getByRole("button", { name: "+ Add a second tail change" }).click();
  await expect(dialog.locator("[data-customize-rocker-note]")).toContainText('-1/4"N18" +1/8"T36" +1/8"T18"');
  await page.mouse.move(1, 1);
  await page.waitForTimeout(400);
  return dialog;
}

/** Whole inches in from a tip, in centimetres to one decimal as the app prints a dim. */
async function bendText(inches: number, metric: boolean): Promise<string> {
  return metric ? `${(inches * 2.54).toFixed(1)} cm in` : `${inches}" in`;
}

/** P-12: the popup's measured boxes, printed for the SUMMARY. */
async function measure(page: Page, label: string) {
  const sizes = await page.evaluate(() => {
    const box = (sel: string) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return `${Math.round(r.width)}×${Math.round(r.height)}`;
    };
    const dialog = document.querySelector("[data-customize-rocker-dialog]");
    const header = dialog?.firstElementChild as HTMLElement | null;
    return {
      viewport: `${window.innerWidth}×${window.innerHeight}`,
      popup: box("[data-customize-rocker-dialog]"),
      header: header ? `${Math.round(header.getBoundingClientRect().height)}` : null,
      body: box("[data-customize-rocker-body]"),
      rows: box("[data-customize-rocker-rows]"),
      drawingColumn: box("[data-customize-rocker-drawing-column]"),
      card: box("[data-custom-rocker-drawing]"),
      svg: box("[data-custom-rocker-drawing] svg[role='img']"),
      footer: box("[data-customize-rocker-footer]"),
    };
  });
  console.log(`P-12 ${label}: ${JSON.stringify(sizes)}`);
}

async function shot(page: Page, name: string, clip?: Locator) {
  await page.waitForTimeout(300);
  if (clip) await clip.screenshot({ path: `${OUT}/${name}` });
  else await page.screenshot({ path: `${OUT}/${name}` });
}

test("computer", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page);
  let dialog = await setSketchRocker(page);
  await measure(page, "computer");
  await shot(page, "02-computer-popup-blank.png");
  await dialog.locator("[data-show-board]").click();
  await shot(page, "02-computer-popup-board.png");
  await dialog.locator("[data-show-board]").click();
  // Zoomed 3x over the tail, where this rocker's red and blue stack: four steps in, then drag the tail
  // tip into view (both of the tail's bend marks show).
  for (let i = 0; i < 4; i++) await dialog.getByRole("button", { name: "Zoom in" }).click();
  const svg = dialog.locator("[data-blank-alone]");
  const box = (await svg.boundingBox())!;
  for (let i = 0; i < 2; i++) {
    await page.mouse.move(box.x + box.width * 0.85, box.y + box.height * 0.5);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.2, box.y + box.height * 0.5, { steps: 12 });
    await page.mouse.up();
  }
  await shot(page, "02-computer-popup-zoom.png");
  await dialog.getByRole("button", { name: "Back to 1x — the whole drawing" }).click();
  await dialog.getByRole("button", { name: "Use and save as a new blank" }).click();
  await expect(customRockerDialog(page)).toBeHidden();
  await expect(blankRockerLine(page)).toHaveText('-1/4"N18" +1/8"T36" +1/8"T18"');
  await page.waitForTimeout(400);
  await shot(page, "02-computer-viewer.png");
  await shot(page, "02-computer-sidebar.png", page.locator("[data-design-controls-scroll]"));
  await page.getByRole("tab", { name: "DATASHEET" }).click();
  await shot(page, "02-computer-datasheet.png");
  void dialog;
  dialog = customRockerDialog(page);
});

test("computer in Daylight", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page, { theme: "daylight" });
  await setSketchRocker(page);
  await shot(page, "02-computer-popup-daylight.png");
});

test("computer in Metric", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page, { metric: true });
  await setSketchRocker(page, true);
  await shot(page, "02-computer-popup-metric.png");
});

test("iPhone upright", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone");
  await setup(page);
  let dialog = await setSketchRocker(page);
  await measure(page, "iPhone upright, two buttons");
  await shot(page, "02-iphone-popup.png");
  await dialog.getByRole("button", { name: "Use and save as a new blank" }).click();
  await expect(customRockerDialog(page)).toBeHidden();
  // Reopened as Edit Custom Rocker: the footer's three buttons; the rows scrolled to TAIL.
  dialog = await openCustomizeRocker(page);
  await dialog.locator('[data-custom-rocker-end="tail"]').scrollIntoViewIfNeeded();
  await dialog.locator("[data-customize-rocker-rows]").evaluate((el) => el.scrollTo({ top: el.scrollHeight }));
  await page.waitForTimeout(400);
  await measure(page, "iPhone upright, three buttons");
  await shot(page, "02-iphone-popup-rows.png");
});

test("Pixel 7 sideways", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "pixel7-sideways");
  await setup(page);
  await setSketchRocker(page);
  await measure(page, "Pixel 7 sideways");
  await shot(page, "02-pixel7-sideways-popup.png");
});

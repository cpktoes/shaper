import { defineConfig, devices } from "@playwright/test";

// Scratch config for plan 02's pictures (quick 261016-mkb). Its own webpack dev server on port 3195,
// the suite's stand-in environment. Archived into shoot-source-02.tar.gz after the shoot.
const port = 3195;
const { defaultBrowserType: _p7, ...pixel7Landscape } = devices["Pixel 7 landscape"];
void _p7;

export default defineConfig({
  testDir: ".",
  testMatch: "shoot-02.spec.ts",
  fullyParallel: false,
  workers: 1,
  timeout: 180_000,
  webServer: {
    command: `npm run dev -- --port ${port}`,
    cwd: "../../../..",
    url: `http://localhost:${port}/design/outline`,
    reuseExistingServer: false,
    timeout: 180_000,
    env: {
      NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: "pk_live_ZXhhbXBsZS5jbGVyay5hY2NvdW50cy5kZXYk",
      CLERK_SECRET_KEY: "sk_live_fake-not-a-secret-for-playwright-only",
      DATABASE_URL: "postgresql://user:pass@localhost:5432/shaper",
      SHAPER_BLANKS_SOURCE: "seed-csv",
      SHAPER_CONTACT_STAND_IN: "1",
      SHAPER_FORCED_ERROR: "1",
      SHAPER_RACK_STAND_IN: "1",
      IS_WEBPACK_TEST: "1",
    },
  },
  use: { baseURL: `http://localhost:${port}` },
  projects: [
    { name: "computer", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 } } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
    { name: "pixel7-sideways", use: { ...pixel7Landscape } },
  ],
});

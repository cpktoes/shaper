/**
 * Scratch (quick 261016-mkb, plan 01, picture 01-the-bend.png): an HTML page of plain SVG showing the
 * custom rocker bent by the app's own maths on the two blanks the sketch was drawn on. Run from the
 * worktree root:
 *   npx --no-install tsx --tsconfig ./tsconfig.json <this file> <worktree root> <out.html>
 * Every figure comes from the app's own functions; nothing is typed.
 */
import { writeFileSync } from "node:fs";

const ROOT = process.argv[2];
const OUT = process.argv[3];

const { presetDesignFields } = await import(`${ROOT}/lib/blanks/preset-blanks.ts`);
const { BOARD_PRESETS } = await import(`${ROOT}/lib/geometry/presets.ts`);
const { prepareBlank } = await import(`${ROOT}/lib/geometry/blank-fit.ts`);
const { printedBlankStations, CATALOG_STATION_LABELS } = await import(`${ROOT}/lib/geometry/board-profile.ts`);
const cr = await import(`${ROOT}/lib/geometry/custom-rocker.ts`);
const { formatMark } = await import(`${ROOT}/lib/geometry/measure-display.ts`);
const { inchesToMm, mmToInches } = await import(`${ROOT}/lib/geometry/units.ts`);

type Change = { end: "nose" | "tail"; amount: number; fromTip?: number };
const nose = (a: number, f?: number): Change =>
  f === undefined ? { end: "nose", amount: inchesToMm(a) } : { end: "nose", amount: inchesToMm(a), fromTip: inchesToMm(f) };
const tail = (a: number, f?: number): Change =>
  f === undefined ? { end: "tail", amount: inchesToMm(a) } : { end: "tail", amount: inchesToMm(a), fromTip: inchesToMm(f) };

const PX_PER_IN = 12.5;
const KEYS = ["noseTip", "nose12", "center", "tail12", "tailTip"] as const;
const KEY_NAMES: Record<string, string> = { noseTip: "Nose tip", nose12: 'Nose 12"', center: "Centre", tail12: 'Tail 12"', tailTip: "Tail tip" };

function panel(id: string, makeSpec: (prepared: unknown) => { changes: Change[] }): string {
  const preset = BOARD_PRESETS.find((p: { id: string }) => p.id === id);
  const copy = presetDesignFields(preset).blank.copy;
  const natural = prepareBlank(copy);
  const spec = cr.normalizeSpec(makeSpec(natural), copy.lengthMm);
  const bent = cr.withCustomRocker(natural, spec);
  const L = copy.lengthMm;
  const Lin = mmToInches(L);
  const w = Lin * PX_PER_IN + 80;
  // Highest point drawn: the deck at either tip, bent or natural.
  let top = 0;
  const N = 400;
  const pts = (rocker: { sample(x: number): number }, deck: boolean) => {
    const out: string[] = [];
    for (let i = 0; i <= N; i++) {
      const x = (L * i) / N;
      const y = rocker.sample(x) + (deck ? natural.thickness.sample(x) : 0);
      top = Math.max(top, mmToInches(y));
      out.push(`${x}`);
    }
    return out;
  };
  pts(bent.rocker, true);
  pts(natural.rocker, true);
  const h = top * PX_PER_IN + 40;
  const sx = (x: number) => 40 + mmToInches(L - x) * PX_PER_IN; // nose left
  const sy = (y: number) => h - 20 - mmToInches(y) * PX_PER_IN;
  const path = (rocker: { sample(x: number): number }, deck: boolean) => {
    let d = "";
    for (let i = 0; i <= N; i++) {
      const x = (L * i) / N;
      const y = rocker.sample(x) + (deck ? natural.thickness.sample(x) : 0);
      d += `${i ? "L" : "M"}${sx(x).toFixed(2)},${sy(y).toFixed(2)}`;
    }
    return d;
  };
  const bends = spec.changes
    .map((c: Change) => {
      const p = cr.bendPoint(c, L);
      const y = bent.rocker.sample(p);
      return `<line x1="${sx(p)}" x2="${sx(p)}" y1="${sy(y) - 8}" y2="${sy(y) + 8}" stroke="#c62828" stroke-width="2"/>`;
    })
    .join("");
  const printed = printedBlankStations(copy);
  const ordered = cr.customPrintedStations(copy, spec);
  const figures = KEYS.map((key) => {
    const was = printed[key].rocker;
    const now = ordered[key].rocker;
    if (now === null) return `<td>${KEY_NAMES[key]}<br><b>—</b></td>`;
    const changed = was !== null && Math.abs(now - was) > 1e-9;
    return `<td>${KEY_NAMES[key]}<br><b>${formatMark(now, "imperial")}</b>${changed ? `<br><span class="was">natural ${formatMark(was, "imperial")}</span>` : ""}</td>`;
  }).join("");
  const lift = mmToInches(ordered.noseTip.rocker - printed.noseTip.rocker);
  const tailLift = mmToInches(ordered.tailTip.rocker - printed.tailTip.rocker);
  return `
  <section>
    <h2>${copy.vendor} ${cr.blankDisplayName(copy, spec)}</h2>
    <p class="sub">note <code>${cr.formatRockerNote(spec)}</code> · nose tip moved ${lift.toFixed(6)}" · tail tip moved ${tailLift.toFixed(6)}" · ${CATALOG_STATION_LABELS.noseTip} is on the left</p>
    <svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
      <line x1="${sx(L)}" x2="${sx(0)}" y1="${sy(0)}" y2="${sy(0)}" stroke="#bbb" stroke-width="1"/>
      <path d="${path(natural.rocker, false)}" fill="none" stroke="#555" stroke-width="1.5" stroke-dasharray="6 4"/>
      <path d="${path(natural.rocker, true)}" fill="none" stroke="#555" stroke-width="1.5" stroke-dasharray="6 4"/>
      <path d="${path(bent.rocker, false)}" fill="none" stroke="#111" stroke-width="2"/>
      <path d="${path(bent.rocker, true)}" fill="none" stroke="#111" stroke-width="2"/>
      ${bends}
    </svg>
    <table><tr>${figures}</tr></table>
  </section>`;
}

const stepImperial = inchesToMm(1 / 16);
const cases: [string, (prepared: unknown) => { changes: Change[] }][] = [
  ["longboard", () => ({ changes: [nose(0.5), nose(0.5, 18)] })],
  ["longboard", () => ({ changes: [nose(-0.25, 18), tail(0.125, 36), tail(0.125, 18)] })],
  ["longboard", (p) => ({ changes: [{ end: "tail", amount: Math.max(-inchesToMm(2), cr.floorOf(p, tail(-2), { changes: [] }, stepImperial)) }] })],
  ["shortboard", () => ({ changes: [nose(0.5), nose(0.5, 18)] })],
  ["shortboard", () => ({ changes: [nose(-0.25, 18), tail(0.125, 36), tail(0.125, 18)] })],
  ["shortboard", (p) => ({ changes: [{ end: "tail", amount: Math.max(-inchesToMm(2), cr.floorOf(p, tail(-2), { changes: [] }, stepImperial)) }] })],
];

const html = `<!doctype html><html><head><meta charset="utf-8"><style>
  body { font: 14px -apple-system, system-ui, sans-serif; margin: 24px; color: #111; background: #fff; }
  h1 { font-size: 20px; margin: 0 0 4px; } h2 { font-size: 16px; margin: 18px 0 2px; }
  .sub, .lead { color: #555; margin: 0 0 6px; } code { background: #f2f2f2; padding: 1px 4px; }
  table { border-collapse: collapse; margin-top: 4px; } td { border: 1px solid #ddd; padding: 4px 10px; text-align: center; min-width: 90px; }
  .was { color: #888; font-size: 12px; } section { border-top: 1px solid #eee; padding-top: 6px; }
</style></head><body>
<h1>The bend — a blank's rocker as ordered, on the app's own maths (quick 261016-mkb, plan 01)</h1>
<p class="lead">Side-on at true proportion, nose on the left. Dashed: the blank's natural rocker (bottom and deck). Solid: the blank bent as ordered. Red ticks: where each bend starts. Figures: the five catalogue stations as ordered (Imperial), the natural figure beneath any that changed. The last panel of each blank is -2"T held at that blank's floor.</p>
${cases.map(([id, make]) => panel(id, make)).join("\n")}
</body></html>`;
writeFileSync(OUT, html);
console.log(`wrote ${OUT}`);

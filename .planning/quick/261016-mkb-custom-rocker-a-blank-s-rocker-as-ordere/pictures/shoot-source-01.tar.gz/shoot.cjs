// Scratch (quick 261016-mkb, plan 01): screenshots the bend page with Playwright's own chromium from
// the worktree's node_modules. No dev server. Usage: node shoot.cjs <worktree root> <in.html> <out.png>
const path = require("node:path");
const fs = require("node:fs");
const [root, input, output] = process.argv.slice(2);
const { chromium } = require(path.join(root, "node_modules/playwright"));
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 2 });
  await page.setContent(fs.readFileSync(input, "utf8"));
  await page.screenshot({ path: output, fullPage: true });
  await browser.close();
  console.log(`wrote ${output}`);
})();

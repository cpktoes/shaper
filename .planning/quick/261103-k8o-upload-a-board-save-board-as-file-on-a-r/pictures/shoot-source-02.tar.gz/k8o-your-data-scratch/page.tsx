// SCRATCH ONLY (quick 261103-k8o plan 02, PC24) — never staged or committed. A stand-in render of the
// Your data page for pictures, because Clerk never settles under the suite's fake keys. Answers
// not-found unless the practice-rack flag is on, exactly as /test-rack does.
import { notFound } from "next/navigation";
import { rackStandInRouteEnabled } from "@/lib/models/rack-stand-in";
import { ScratchPanels } from "./scratch-panels";

export default function K8oYourDataScratchPage() {
  const enabled = rackStandInRouteEnabled({
    nodeEnv: process.env.NODE_ENV,
    flag: process.env.SHAPER_RACK_STAND_IN,
  });
  if (!enabled) notFound();
  return <ScratchPanels />;
}

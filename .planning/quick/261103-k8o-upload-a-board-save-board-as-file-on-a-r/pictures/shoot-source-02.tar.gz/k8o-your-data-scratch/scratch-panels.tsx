"use client";
// SCRATCH ONLY (quick 261103-k8o plan 02, PC24) — never staged or committed. Each panel is white, the
// width of Clerk's page area (560 dots on a computer, the full width less 16 on each side on a phone),
// bordered in the Daylight line colour. Beside the real page, the Import my designs view in each step,
// its props built by the app's own functions from a real file: the twelve practice boards as an Export
// my designs file (ids in the database's form), read with readDesignsFileText and planned with
// planImport against nine of their ids.
import type { ReactNode } from "react";
import { YourDataPage } from "@/components/account/your-data-page";
import { ImportDesignsView, type ImportDesignsViewProps, type ImportPreview } from "@/components/account/import-designs-view";
import { YOUR_DATA_COPY } from "@/components/account/your-data-copy";
import { buildDesignsExport } from "@/lib/account/account-data";
import { planImport, readDesignsFileText } from "@/lib/account/import-designs";
import type { ModelRow } from "@/lib/db/schema";
import { standInRackRows } from "@/lib/models/rack-stand-in";

const PANEL = "mx-4 my-4 max-w-[560px] border border-(--ramp-daylight-line) bg-white p-6 sm:mx-auto";
const NOW = new Date("2026-11-03T12:00:00.000Z");
const FILE_NAME = "shaper-assistant-designs-2026-11-03.json";

const rows: ModelRow[] = standInRackRows(12).map((row, i) => ({
  id: `0000a8a0-0000-4000-8000-${String(i + 1).padStart(12, "0")}`,
  clerkUserId: "user_stand_in",
  name: row.name,
  snapshot: row.snapshot,
  createdAt: row.updatedAt,
  updatedAt: row.updatedAt,
  locked: null,
}));
const read = readDesignsFileText(JSON.stringify(buildDesignsExport(rows, null, NOW), null, 2), {});
if (!read.ok) throw new Error(read.problem);
const accountIds = new Set(read.boards.slice(0, 9).map((board) => board.id as string));

function previewFor(includeCopies: boolean): ImportPreview {
  const plan = planImport(read.ok ? read.boards : [], accountIds, includeCopies);
  return {
    fileName: FILE_NAME,
    addNames: plan.add.map((board) => board.name),
    alreadyThere: plan.alreadyThere.length,
    unreadable: read.ok ? read.unreadable : [],
    includeCopies,
  };
}

const NOOP = () => {};
const BASE: Omit<ImportDesignsViewProps, "step" | "status"> = {
  onChoose: NOOP,
  onFileChosen: NOOP,
  onToggleCopies: NOOP,
  onImport: NOOP,
  onCancel: NOOP,
};

function Panel({ name, children }: { name: string; children: ReactNode }) {
  return (
    <div data-panel={name} className={PANEL}>
      {children}
    </div>
  );
}

export function ScratchPanels() {
  return (
    <main className="min-h-screen bg-(--ramp-daylight-well) py-4">
      <Panel name="page">
        <YourDataPage />
      </Panel>
      <Panel name="preview">
        <ImportDesignsView {...BASE} step={{ kind: "preview", preview: previewFor(false) }} status={null} />
      </Panel>
      <Panel name="preview-copies">
        <ImportDesignsView {...BASE} step={{ kind: "preview", preview: previewFor(true) }} status={null} />
      </Panel>
      <Panel name="importing">
        <ImportDesignsView
          {...BASE}
          step={{ kind: "importing", preview: previewFor(false), done: 25, total: 40 }}
          status={null}
        />
      </Panel>
      <Panel name="done">
        <ImportDesignsView
          {...BASE}
          step={{ kind: "idle" }}
          status={{ text: YOUR_DATA_COPY.import.done({ added: 3, alreadyThere: 9, copies: 0, failed: [] }), tone: "plain" }}
        />
      </Panel>
      <Panel name="refused">
        <ImportDesignsView {...BASE} step={{ kind: "idle" }} status={{ text: YOUR_DATA_COPY.import.notOurs, tone: "warning" }} />
      </Panel>
    </main>
  );
}

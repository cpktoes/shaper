// Quick 261103-k8o plan 02's picture script: the worktree's own Playwright config, pointed at this
// folder's spec, with the dev server started in the worktree on PW_PORT. Scratch only, archived as
// pictures/shoot-source-02.tar.gz.
import { defineConfig } from "@playwright/test";
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-adfad90dc369a97a2/playwright.config";

const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-adfad90dc369a97a2";
const server = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer;

export default defineConfig({
  ...base,
  testDir: "/private/tmp/claude-501/-Users-kontoes-Code-shaper/83ff3531-9289-46f6-95de-7b57b8eb15bc/scratchpad/k8o2-shoot/shoot",
  testMatch: "shots.spec.ts",
  testIgnore: [],
  timeout: 180_000,
  webServer: { ...server!, cwd: WORKTREE, reuseExistingServer: true },
});

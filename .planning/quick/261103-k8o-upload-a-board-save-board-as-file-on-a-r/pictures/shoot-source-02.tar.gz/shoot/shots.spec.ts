// Quick 261103-k8o plan 02's picture script: locator pictures of each white panel on the scratch
// route /k8o-your-data-scratch. SHOOT_TAG=before|after. Scratch only.
import { expect, test } from "@playwright/test";

const TAG = process.env.SHOOT_TAG ?? "before";
const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/agent-adfad90dc369a97a2/.planning/quick/261103-k8o-upload-a-board-save-board-as-file-on-a-r/pictures";

/** Panels shot on each device: [panel name, picture name]. */
const SHOTS: Record<string, [string, string][]> = {
  desktop:
    TAG === "before"
      ? [["page", "your-data-desktop"]]
      : [
          ["page", "your-data-desktop"],
          ["preview", "preview-desktop"],
          ["preview-copies", "preview-copies-desktop"],
          ["importing", "importing-desktop"],
          ["done", "done-desktop"],
          ["refused", "refused-desktop"],
        ],
  iphone:
    TAG === "before"
      ? [["page", "your-data-iphone"]]
      : [
          ["page", "your-data-iphone"],
          ["preview", "preview-iphone"],
        ],
};

test("Your data panels", async ({ page }, testInfo) => {
  const shots = SHOTS[testInfo.project.name];
  test.skip(!shots, "not shot on this device");
  await page.goto("/k8o-your-data-scratch");
  await expect(page.locator('[data-panel="page"] h1')).toBeVisible({ timeout: 120_000 });
  // The dev server's own "N" badge is never on the real site; keep it out of the pictures.
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await page.waitForTimeout(1500);
  for (const [panel, name] of shots!) {
    const locator = page.locator(`[data-panel="${panel}"]`);
    await locator.scrollIntoViewIfNeeded();
    await locator.screenshot({ path: `${PICTURES}/p2-${TAG}-${name}.png` });
  }
});

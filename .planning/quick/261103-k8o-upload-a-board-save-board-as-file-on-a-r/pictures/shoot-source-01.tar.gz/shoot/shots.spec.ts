// Quick 261103-k8o plan 01's picture script: the Board Rack's ⋯ menu, the home page under the preset
// cards, and (after) the replace prompt for a file, a refused three-board file and TEMPLATE straight
// after opening a file. SHOOT_TAG=before|after. Scratch only.
import { expect, test, type Locator, type Page } from "@playwright/test";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/lib/models/banner-dismissal";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/lib/models/toolbar-tip";
import { RACK_STAND_IN_ROUTE, standInRackRows } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/lib/models/rack-stand-in";
import { freshPracticeRack } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/e2e/helpers/practice-rack";
import { forgetOpenBoardOnEveryLoad } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/e2e/helpers/open-board";

const TAG = process.env.SHOOT_TAG ?? "before";
const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c/.planning/quick/261103-k8o-upload-a-board-save-board-as-file-on-a-r/pictures";

const FIRST = standInRackRows(15)[0];

async function setUp(page: Page) {
  await page.addInitScript(
    ([bannerKey, tipKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY] as const,
  );
  await freshPracticeRack(page);
}

async function unionClip(page: Page, locators: Locator[], pad: number) {
  const boxes = [];
  for (const l of locators) {
    const b = await l.boundingBox();
    if (b) boxes.push(b);
  }
  const x0 = Math.min(...boxes.map((b) => b.x)) - pad;
  const y0 = Math.min(...boxes.map((b) => b.y)) - pad;
  const x1 = Math.max(...boxes.map((b) => b.x + b.width)) + pad;
  const y1 = Math.max(...boxes.map((b) => b.y + b.height)) + pad;
  const vp = page.viewportSize()!;
  const x = Math.max(0, x0);
  const y = Math.max(0, y0);
  return { x, y, width: Math.min(vp.width, x1) - x, height: Math.min(vp.height, y1) - y };
}

test("the ⋯ menu", async ({ page }, info) => {
  await setUp(page);
  await page.goto(RACK_STAND_IN_ROUTE);
  await expect(page.locator("[data-rack-art][data-turn]")).toHaveCount(15);
  await page.waitForTimeout(800);
  await page.getByRole("button", { name: `Board actions for ${FIRST.name}` }).click();
  const menu = page.getByRole("menu");
  await expect(menu).toBeVisible();
  await page.waitForTimeout(400);
  const caption = page.locator(`[data-rack-caption="${FIRST.id}"]`);
  const clip = await unionClip(page, [caption, menu], 24);
  await page.screenshot({ path: `${PICTURES}/${TAG}-menu-${info.project.name}.png`, clip });
});

test("the home page under the presets", async ({ page }, info) => {
  await setUp(page);
  await forgetOpenBoardOnEveryLoad(page);
  // After: a taller computer window, so the picture of the content box holds the new button and its
  // line whole (at 800 tall the page's own scroller cuts the box off just under them).
  if (TAG === "after" && info.project.name === "desktop") await page.setViewportSize({ width: 1280, height: 1000 });
  await page.goto("/");
  await expect(page.getByRole("button").filter({ hasText: "Start Shaping" })).toHaveCount(4);
  await page.waitForTimeout(600);
  if (info.project.name === "desktop") {
    await page.locator("[data-setup-content]").screenshot({ path: `${PICTURES}/${TAG}-home-desktop.png` });
  } else {
    const footer = page.locator("footer").last();
    await footer.scrollIntoViewIfNeeded();
    await page.waitForTimeout(400);
    await page.screenshot({ path: `${PICTURES}/${TAG}-home-${info.project.name}.png` });
  }
});

// After pictures only: the replace prompt for a file, a refused three-board file, and TEMPLATE
// straight after opening a friend's board. Imports are loaded lazily so the before run never needs
// modules that did not exist yet.
async function afterModules() {
  const W = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-a5faaa49c1640e32c";
  const boardFile = await import(`${W}/lib/models/board-file`);
  const snapshot = await import(`${W}/lib/models/design-snapshot`);
  const account = await import(`${W}/lib/account/account-data`);
  const copy = await import(`${W}/components/setup/board-file-copy`);
  return { boardFile, snapshot, account, copy };
}

async function pick(page: Page, buttonText: string, name: string, text: string) {
  const [chooser] = await Promise.all([page.waitForEvent("filechooser"), page.getByRole("button", { name: buttonText }).click()]);
  await chooser.setFiles({ name, mimeType: "application/json", buffer: Buffer.from(text, "utf8") });
}

test("the replace prompt for a file", async ({ page }, info) => {
  test.skip(TAG !== "after" || info.project.name === "android");
  const { boardFile, snapshot, copy } = await afterModules();
  const fish = snapshot.parseSnapshot(standInRackRows(4)[1].snapshot);
  const text = boardFile.boardFileText(boardFile.buildBoardFile("Friend's Fish", fish, new Date()));
  await setUp(page);
  await page.goto("/");
  await page.getByRole("button").filter({ hasText: "Start Shaping" }).filter({ hasText: "Shortboard" }).first().click();
  await page.waitForURL("**/design/outline");
  await page.goBack();
  await page.waitForURL((url) => url.pathname === "/");
  await pick(page, copy.BOARD_FILE_COPY.button, "Friend's Fish.shaper-board.json", text);
  await expect(page.getByRole("alertdialog")).toBeVisible();
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${PICTURES}/${TAG}-replace-prompt-${info.project.name}.png` });
});

test("a three-board download picked", async ({ page }, info) => {
  test.skip(TAG !== "after" || info.project.name !== "desktop");
  const { account, copy } = await afterModules();
  const rows = standInRackRows(3).map((row, i) => ({
    id: `0000000${i}-0000-4000-8000-000000000000`,
    clerkUserId: "user_fake_k8o",
    name: row.name,
    snapshot: row.snapshot,
    createdAt: new Date(Date.UTC(2026, 9, 1, 12 - i)),
    updatedAt: new Date(Date.UTC(2026, 9, 2)),
    locked: null,
  }));
  const text = JSON.stringify(account.buildDesignsExport(rows, null, new Date()), null, 2);
  await setUp(page);
  await forgetOpenBoardOnEveryLoad(page);
  await page.setViewportSize({ width: 1280, height: 1000 });
  await page.goto("/");
  await pick(page, copy.BOARD_FILE_COPY.button, account.designsExportFileName(new Date()), text);
  await expect(page.locator("[data-board-file-status]")).toHaveText(copy.BOARD_FILE_COPY.manyBoards(3));
  const control = page.locator("[data-open-board-file]");
  const lastCard = page.getByRole("button").filter({ hasText: "Start Shaping" }).last();
  const clip = await unionClip(page, [lastCard, control], 24);
  await page.screenshot({ path: `${PICTURES}/${TAG}-many-boards-desktop.png`, clip });
});

test("TEMPLATE straight after opening a friend's board", async ({ page }, info) => {
  test.skip(TAG !== "after" || info.project.name !== "desktop");
  const { boardFile, snapshot, copy } = await afterModules();
  const fish = snapshot.parseSnapshot(standInRackRows(4)[1].snapshot);
  const text = boardFile.boardFileText(boardFile.buildBoardFile("Friend's Fish", fish, new Date()));
  await setUp(page);
  await page.goto("/");
  await pick(page, copy.BOARD_FILE_COPY.button, "Friend's Fish.shaper-board.json", text);
  await page.waitForURL("**/design/outline");
  await expect(page.locator("[data-board-silhouette='outline']").first()).toBeVisible();
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${PICTURES}/${TAG}-opened-desktop.png` });
});

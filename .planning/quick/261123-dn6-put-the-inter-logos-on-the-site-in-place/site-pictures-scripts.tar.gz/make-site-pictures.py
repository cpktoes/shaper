"""Makes the site's logo pictures from the founder's plain Inter drawings (quick 261123-dn6).

Usage: make-site-pictures.py <worktree> <scratch dir> <task pictures dir>

Needs Pillow and headless Google Chrome (see HOW-TO-RUN.txt). Never resizes a Chrome screenshot:
if it is not exactly the size asked for, it stops.
"""
import re
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


def report(path):
    im = Image.open(path)
    print(f"{path}: {im.size[0]}x{im.size[1]} {im.mode}")


def chrome_render(svg_path, out_path, w, h, scratch):
    subprocess.run(
        [
            CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
            "--force-device-scale-factor=1", "--default-background-color=00000000",
            f"--window-size={w},{h}", f"--user-data-dir={scratch}/chrome-profile",
            f"--screenshot={out_path}", f"file://{svg_path}",
        ],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    im = Image.open(out_path)
    if im.size != (w, h):
        raise SystemExit(f"Chrome gave {im.size}, not {(w, h)} — stopping, not resizing")
    return im.convert("RGBA")


def alpha_only(rgba, out_path):
    """A grey-plus-alpha PNG: every grey 255, the see-through taken from the render's alpha."""
    a = rgba.getchannel("A")
    la = Image.merge("LA", (Image.new("L", a.size, 255), a))
    la.save(out_path)


def main(w, scratch, pictures):
    w, scratch, pictures = Path(w), Path(scratch), Path(pictures)
    plain = w / "brand" / "inter" / "plain"

    # (a) Home Screen icons: downscales of the round black-on-white master.
    master = Image.open(plain / "round-black-on-white.png").convert("RGB")
    for size, dest in [(180, "app/apple-icon.png"), (192, "public/home-screen-icon-192.png"), (512, "public/home-screen-icon-512.png")]:
        master.resize((size, size), Image.LANCZOS).save(w / dest)
        report(w / dest)

    # (b) The side walls' circle: white, cut to the ring's outer edge (6.0 to 1994.0), 1024 square.
    svg = (plain / "round-transparent.svg").read_text(encoding="utf-8").replace("#111111", "#ffffff")
    svg = re.sub(r"<svg[^>]*>", '<svg xmlns="http://www.w3.org/2000/svg" viewBox="6 6 1988 1988" width="1024" height="1024">', svg, count=1)
    (scratch / "circle-white.svg").write_text(svg, encoding="utf-8")
    rgba = chrome_render(scratch / "circle-white.svg", scratch / "circle-render.png", 1024, 1024, scratch)
    alpha_only(rgba, w / "public" / "bay-logo-circle.png")
    report(w / "public" / "bay-logo-circle.png")

    # (c) The end walls' line logo: wordmark.svg white, 2048 by 237 (a 0.08% squash the wall's plane undoes).
    wm = (w / "brand" / "wordmark.svg").read_text(encoding="utf-8")
    wm = wm.replace('<path ', '<path fill="#ffffff" ', 1)
    wm = wm.replace('viewBox="0 0 1629.93 188.77"', 'viewBox="0 0 1629.93 188.77" width="2048" height="237" preserveAspectRatio="none"', 1)
    (scratch / "wordmark-white.svg").write_text(wm, encoding="utf-8")
    rgba = chrome_render(scratch / "wordmark-white.svg", scratch / "wordmark-render.png", 2048, 237, scratch)
    alpha_only(rgba, w / "public" / "bay-logo-wordmark.png")
    report(w / "public" / "bay-logo-wordmark.png")

    # Checks.
    for name, size in [("app/apple-icon.png", 180), ("public/home-screen-icon-192.png", 192), ("public/home-screen-icon-512.png", 512)]:
        im = Image.open(w / name)
        assert im.size == (size, size) and im.mode == "RGB", name
        for pt in [(0, 0), (size - 1, 0), (0, size - 1), (size - 1, size - 1)]:
            assert min(im.getpixel(pt)) >= 250, f"{name} corner {pt} is not white"
    for name, size in [("public/bay-logo-circle.png", (1024, 1024)), ("public/bay-logo-wordmark.png", (2048, 237))]:
        im = Image.open(w / name)
        assert im.size == size and im.mode == "LA", name
        a = im.getchannel("A")
        for pt in [(0, 0), (size[0] - 1, 0), (0, size[1] - 1), (size[0] - 1, size[1] - 1)]:
            assert a.getpixel(pt) == 0, f"{name} corner {pt} is not see-through"
        assert a.getextrema()[1] == 255, f"{name} is never fully opaque"
        assert im.getchannel("L").getextrema() == (255, 255), f"{name} grey is not all 255"
    print("all checks passed")

    # Pictures for the founder: the 180 icon and the iPhone look, before and after.
    after = w / "app" / "apple-icon.png"
    (pictures / "home-screen-icon-180-after.png").write_bytes(after.read_bytes())
    for tag in ("before", "after"):
        icon = Image.open(pictures / f"home-screen-icon-180-{tag}.png").convert("RGB")
        canvas = Image.new("RGB", (240, 240), (0x8A, 0x8A, 0x8A))
        mask = Image.new("L", (180, 180), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, 179, 179), radius=round(180 * 0.224), fill=255)
        canvas.paste(icon, (30, 30), mask)
        canvas.save(pictures / f"home-screen-icon-iphone-look-{tag}.png")


if __name__ == "__main__":
    main(*sys.argv[1:4])

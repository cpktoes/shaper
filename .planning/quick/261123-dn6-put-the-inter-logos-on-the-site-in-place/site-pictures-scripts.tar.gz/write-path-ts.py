"""Writes components/wordmark-path.ts from brand/wordmark.svg (verbatim d). Usage: write-path-ts.py <W>"""
import re, sys
w = sys.argv[1]
svg = open(f"{w}/brand/wordmark.svg", encoding="utf-8").read()
d = re.search(r' d="([^"]+)"', svg).group(1)
head = """/**
 * The outline of the founder’s Inter logo, “shaperassistant.com” — “shaper” Inter Bold, “assistant” and
 * “.com” Inter Light, every letter an outline (quick 261123-dn6). It is made from
 * brand/inter/plain/inline-transparent.svg by joining that drawing’s three parts into one shape and
 * moving it so the letters’ own box starts at the corner: nothing scaled, nothing redrawn. No letter
 * overlaps another, so filling it even-odd leaves every hole (the e, a, p, o, the c and m) open.
 * Copied verbatim from brand/wordmark.svg, which keeps the same outline as a file —
 * components/wordmark.test.ts fails if the two ever differ, and a second test re-makes it from the
 * founder’s drawing. Never hand-edit the numbers: re-make it with the archived script (brand/README.md
 * says where) instead.
 */
export const WORDMARK_PATH =
  "%s";

/** The letters’ own width. */
export const WORDMARK_WIDTH = 1629.93;

/** Their height, from the top of the i’s dot in “assistant” to the bottom of the p’s tail. */
export const WORDMARK_HEIGHT = 188.77;

/** How far down the box the letters stand: the baseline “shaper” and “assistant” sit on. */
export const WORDMARK_BASELINE = 147.95;
""" % d
open(f"{w}/components/wordmark-path.ts", "w", encoding="utf-8").write(head)

"""Makes brand/wordmark.svg from the founder's Inter inline drawing (quick 261123-dn6).

Usage: make-wordmark.py <inline-transparent.svg> <output wordmark.svg>

Joins the three paths (shaper, assistant, com), moves every point by x - 7.62 and
y + 147.95 (in whole hundredths, so nothing is rounded or scaled), checks the box
and that even-odd and nonzero fills cover the same area, then writes one line of SVG.
"""
import re
import sys
from decimal import Decimal

from fontTools.pens.areaPen import AreaPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path
import pathops

DX = -762    # hundredths
DY = 14795   # hundredths
WIDTH, HEIGHT = "1629.93", "188.77"

TOKEN = re.compile(r"[MLQHVZ]|-?\d+(?:\.\d+)?")


def num(h):
    """Hundredths (int) written as make2.py's num() would: two decimals, trailing zeros and dot stripped."""
    sign = "-" if h < 0 else ""
    h = abs(h)
    s = f"{sign}{h // 100}.{h % 100:02d}".rstrip("0").rstrip(".")
    return "0" if s == "-0" else s


def hundredths(text):
    return int((Decimal(text) * 100).to_integral_value())


def move(d):
    out = []
    cmd = None
    idx = 0
    for tok in TOKEN.findall(d):
        if tok in "MLQHVZ":
            cmd = tok
            idx = 0
            out.append(tok)
            continue
        h = hundredths(tok)
        if cmd in "MLQ":
            h += DX if idx % 2 == 0 else DY
        elif cmd == "H":
            h += DX
        elif cmd == "V":
            h += DY
        else:
            raise SystemExit(f"number after {cmd}")
        idx += 1
        # keep the drawing's own spacing: a space before a number that follows a number
        out.append(num(h))
    # rebuild with the original separators: walk the source again
    res = []
    it = iter(out)
    pos = 0
    for m in TOKEN.finditer(d):
        res.append(d[pos:m.start()])
        res.append(next(it))
        pos = m.end()
    res.append(d[pos:])
    return "".join(res)


def paths_of(svg):
    found = []
    for pid in ("shaper", "assistant", "com"):
        m = re.search(rf'<path id="{pid}"[^>]*? d="([^"]+)"', svg)
        if not m:
            raise SystemExit(f"no path {pid}")
        found.append(m.group(1))
    return found


def check(d):
    pen = BoundsPen(None)
    parse_path(d, pen)
    got = pen.bounds
    want = (0.0, 0.0, float(WIDTH), float(HEIGHT))
    ok_bounds = all(abs(a - b) <= 0.006 for a, b in zip(got, want))
    print("bounds", [round(v, 4) for v in got], "OK" if ok_bounds else "FAIL")
    if not ok_bounds:
        raise SystemExit("bounds are not 0 0 1629.93 188.77")

    eo = pathops.Path(); eo.fillType = pathops.FillType.EVEN_ODD
    wd = pathops.Path(); wd.fillType = pathops.FillType.WINDING
    parse_path(d, eo.getPen())
    parse_path(d, wd.getPen())
    xor = pathops.op(eo, wd, pathops.PathOp.XOR)
    ap = AreaPen(None)
    xor.draw(ap)
    area = abs(ap.value)
    print("even-odd vs nonzero XOR area", round(area, 6), "OK" if area < 1e-6 else "FAIL")
    if area >= 1e-6:
        raise SystemExit("even-odd and nonzero differ")


def main(src, dst):
    svg = open(src, encoding="utf-8").read()
    joined = "".join(move(d) for d in paths_of(svg))
    check(joined)
    out = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {WIDTH} {HEIGHT}">'
        f'<path fill-rule="evenodd" d="{joined}"/></svg>\n'
    )
    with open(dst, "w", encoding="utf-8") as f:
        f.write(out)
    print("wrote", dst, len(joined), "characters of path")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])

import sys
from PIL import Image, ImageDraw, ImageFont, ImageOps
S, B = sys.argv[1], sys.argv[2]
D = B + "/inter-draft"
font = ImageFont.truetype(S + "/inter-var.ttf", 44); font.set_variation_by_axes([600])
def lab(img, text):
    out = Image.new("RGB", (img.width, img.height + 90), "white")
    out.paste(img, (0, 90)); ImageDraw.Draw(out).text((20, 22), text, fill="#888", font=font); return out
def row(imgs, gap=60):
    out = Image.new("RGB", (sum(i.width for i in imgs) + gap * (len(imgs) - 1), max(i.height for i in imgs)), "white"); x = 0
    for i in imgs: out.paste(i, (x, 0)); x += i.width + gap
    return out
def col(imgs, gap=60):
    out = Image.new("RGB", (max(i.width for i in imgs), sum(i.height for i in imgs) + gap * (len(imgs) - 1)), "white"); y = 0
    for i in imgs: out.paste(i, (0, y)); y += i.height + gap
    return out
frame = lambda img, m=60: ImageOps.expand(img, border=m, fill="white")
def ring_crop(path, invert=False):
    # crop each round logo to its ring's own bounds so both rings show at the same size
    im = Image.open(path).convert("L"); m = im if invert else im.point(lambda v: 255 - v)
    return Image.open(path).convert("RGB").crop(m.point(lambda v: 255 if v > 128 else 0).getbbox())
def ring_pair(old, new, invert, out):
    sz = 1000
    o = ring_crop(old, invert).resize((sz, sz), Image.LANCZOS); n = ring_crop(new, invert).resize((sz, sz), Image.LANCZOS)
    bg = "black" if invert else "white"
    o = ImageOps.expand(o, border=30, fill=bg); n = ImageOps.expand(n, border=30, fill=bg)
    frame(row([lab(o, "OLD — Helvetica"), lab(n, "NEW — Inter")])).save(out)
ring_pair(B + "/circle-logo-source.jpg", D + "/round-black-on-white.png", False, D + "/compare-round.png")
ring_pair(B + "/circle-logo-white-on-black-source.jpg", D + "/round-white-on-black.png", True, D + "/compare-round-white-on-black.png")
def letters(path):
    im = Image.open(path).convert("L"); return im.crop(im.point(lambda v: 255 if v < 128 else 0).getbbox()).convert("RGB")
o, n = letters(B + "/wordmark-black-on-white-source.jpg"), letters(D + "/inline-black-on-white.png")
W = 1900
o = o.resize((W, round(o.height * W / o.width)), Image.LANCZOS); n = n.resize((W, round(n.height * W / n.width)), Image.LANCZOS)
frame(col([lab(frame(o, 20), "OLD — Helvetica"), lab(frame(n, 20), "NEW — Inter")], gap=90)).save(D + "/compare-inline.png")

"""Shaper Assistant logos in Inter: round and inline, every letter an outline, each part its own path.

Parts: ring (round only), shaper (Inter Bold 700), assistant and .com (Inter Light 300).
Each colour scheme names a fill per part and an optional background.
"""
import sys
from pathlib import Path
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

HERE = Path(sys.argv[1])
OUT = Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

FONTS = {}
for w in (300, 700):
    p = HERE / f"inter-{w}.ttf"
    FONTS[w] = (TTFont(p), hb.Font(hb.Face(hb.Blob.from_file_path(str(p)))))
UPM = FONTS[700][0]["head"].unitsPerEm
XH = FONTS[700][0]["OS/2"].sxHeight
BOLD, LIGHT = 700, 300
TRACK = -0.02  # Inter wants a little negative tracking at display sizes


def num(v):
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return "0" if s == "-0" else s


def run(text, wght, size, x0, baseline, track_em=0.0):
    ttf, font = FONTS[wght]
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties()
    hb.shape(font, buf, {"kern": True, "liga": False, "calt": False})
    gs = ttf.getGlyphSet(); order = ttf.getGlyphOrder()
    k = size / UPM
    pen = SVGPathPen(gs, ntos=num); bpen = BoundsPen(gs)
    x = 0.0; n = len(buf.glyph_infos)
    for i, (info, pos) in enumerate(zip(buf.glyph_infos, buf.glyph_positions)):
        t = (k, 0, 0, -k, x0 + (x + pos.x_offset) * k, baseline - pos.y_offset * k)
        g = gs[order[info.codepoint]]
        g.draw(TransformPen(pen, t)); g.draw(TransformPen(bpen, t))
        x += pos.x_advance + (track_em * UPM if i < n - 1 else 0)
    return pen.getCommands(), bpen.bounds, x * k


def union(*bs):
    return (min(b[0] for b in bs), min(b[1] for b in bs), max(b[2] for b in bs), max(b[3] for b in bs))


# ---------------- inline ----------------
def inline_parts():
    S = 200.0
    d1, b1, a1 = run("shaper", BOLD, S, 0, 0, TRACK)
    d2, b2, a2 = run("assistant", LIGHT, S, a1, 0, TRACK)
    d3, b3, _ = run(".com", LIGHT, S * 0.43, a1 + a2 + S * 0.03, 0, -0.005)
    bx = union(b1, b2, b3); pad = S * 0.25
    W, H = bx[2] - bx[0] + 2 * pad, bx[3] - bx[1] + 2 * pad
    tf = f"translate({num(pad - bx[0])},{num(pad - bx[1])})"
    return W, H, tf, {"shaper": d1, "assistant": d2, "com": d3}, None


# ---------------- round ----------------
def round_parts():
    D = 2000.0; R = D / 2
    ring_w = 15.5  # the original: 15 px on a 1930 px ring
    Sb = 330.0; Sl = Sb * 0.80; Sc = Sb * 0.31
    xh = XH * Sb / UPM
    d1, b1, _ = run("shaper", BOLD, Sb, 0, 0, TRACK)
    line_gap = xh * 1.30
    _, _, adv_sha = run("sha", BOLD, Sb, 0, 0, TRACK)
    _, bp, _ = run("p", BOLD, Sb, 0, 0)
    _, bl, _ = run("l", BOLD, Sb, 0, 0)
    stem = bl[2] - bl[0]
    p_stem_right = adv_sha + TRACK * Sb + bp[0] + stem
    _, _, adv_ass = run("ass", LIGHT, Sl, 0, 0, TRACK)
    _, bi, _ = run("i", LIGHT, Sl, 0, 0)
    x_ass = p_stem_right + stem * 0.45 - (adv_ass + TRACK * Sl + bi[0])
    d2, b2, _ = run("assistant", LIGHT, Sl, x_ass, line_gap, TRACK)
    _, bc, _ = run(".com", LIGHT, Sc, 0, 0, -0.005)
    d3, b3, _ = run(".com", LIGHT, Sc, b2[2] - (bc[2] - bc[0]) - bc[0], line_gap + xh * 0.43, -0.005)
    bx = union(b1, b2, b3)
    k = D * 0.85 / (bx[2] - bx[0])
    cx, cy = R - D * 0.005, R + D * 0.01
    tf = f"translate({num(cx - k * (bx[0] + bx[2]) / 2)},{num(cy - k * (bx[1] + bx[3]) / 2)}) scale({k:.5f})"
    ring = (R, R - ring_w / 2 - 6, ring_w)
    return D, D, tf, {"shaper": d1, "assistant": d2, "com": d3}, ring


def write(name, layout, colours, bg=None):
    W, H, tf, parts, ring = layout
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {num(W)} {num(H)}" width="{round(W)}" height="{round(H)}">']
    if bg:
        out.append(f'<rect id="background" width="{num(W)}" height="{num(H)}" fill="{bg}"/>')
    if ring:
        c, r, sw = ring
        out.append(f'<circle id="ring" cx="{num(c)}" cy="{num(c)}" r="{num(r)}" fill="none" stroke="{colours["ring"]}" stroke-width="{num(sw)}"/>')
    out.append(f'<g transform="{tf}">')
    for part in ("shaper", "assistant", "com"):
        out.append(f'<path id="{part}" fill="{colours[part]}" d="{parts[part]}"/>')
    out.append("</g></svg>\n")
    (OUT / f"{name}.svg").write_text("".join(out))


INK = "#111111"
WHITE = "#ffffff"
SAND, SAND_LINE, GREEN = "#dfdcd3", "#897c58", "#8ec1b8"       # Daylight canvas, Daylight line, Daylight accent
PHOS = "#26d026"                                               # Phosphor ink
# Canva recolours an SVG one distinct colour at a time, so give each part its own (near-identical) shade.
CANVA_DARK = {"ring": "#141414", "shaper": "#111111", "assistant": "#121212", "com": "#131313"}

L = {"round": round_parts(), "inline": inline_parts()}
for kind, lay in L.items():
    solid = lambda c: {"ring": c, "shaper": c, "assistant": c, "com": c}
    write(f"{kind}-black-on-white", lay, solid(INK), WHITE)
    write(f"{kind}-white-on-black", lay, solid(WHITE), INK)
    write(f"{kind}-transparent", lay, solid(INK))
    write(f"{kind}-canva-editable", lay, CANVA_DARK)
    write(f"{kind}-sand-green", lay, {"ring": SAND_LINE, "shaper": INK, "assistant": GREEN, "com": INK}, WHITE)
    write(f"{kind}-phosphor-transparent", lay, solid(PHOS))
    write(f"{kind}-phosphor-on-black", lay, solid(PHOS), "#000000")
print("ok")

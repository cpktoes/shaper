import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

const SHOOT = process.env.SHOOT ?? "before";
const OUT = ".planning/quick/261007-c3h-rocker-s-top-view-and-the-fit-check-a-bl/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

const PRESETS = [
  { name: "Mid-length", slug: "midlength" },
  { name: "Longboard", slug: "longboard" },
];

for (const preset of PRESETS) {
  test(`${preset.name} top view`, async ({ page }, testInfo) => {
    test.setTimeout(180_000);
    await dismiss(page);
    await page.goto("/");
    const card = page.getByRole("button").filter({ hasText: preset.name }).filter({ hasText: "Start Shaping" });
    await expect(async () => {
      if (new URL(page.url()).pathname === "/design/outline") return;
      await card.first().click({ timeout: 3_000 }).catch(() => undefined);
      await page.waitForURL("**/design/outline", { timeout: 15_000 });
    }).toPass({ timeout: 60_000 });
    await goToScreen(page, "ROCKER");
    if (testInfo.project.name === "desktop") {
      const inset = page.locator("[data-top-view-inset]");
      await expect(inset.locator("[data-top-view-blank]")).toBeVisible({ timeout: 60_000 });
      await page.waitForTimeout(1000);
      await page.screenshot({ path: file(`${SHOOT}-${preset.slug}-desktop.png`) });
      await inset.screenshot({ path: file(`${SHOOT}-${preset.slug}-mini.png`) });
      const b = await inset.boundingBox();
      if (!b) throw new Error("no box");
      await page.screenshot({
        path: file(`${SHOOT}-${preset.slug}-nose.png`),
        clip: { x: b.x, y: b.y, width: b.width * 0.35, height: b.height },
      });
    } else {
      await page.getByRole("tab", { name: "TOP VIEW" }).click();
      await expect(page.locator("[data-top-view-blank]")).toBeVisible({ timeout: 60_000 });
      await page.waitForTimeout(1000);
      await page.screenshot({ path: file(`${SHOOT}-${preset.slug}-iphone.png`) });
    }
  });
}

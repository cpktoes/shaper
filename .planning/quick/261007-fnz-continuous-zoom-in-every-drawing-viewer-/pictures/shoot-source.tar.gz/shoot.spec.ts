import path from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

/**
 * Quick 261007-fnz pictures. "proof": ROCKER at 1x, the drawing alone, before and after the zoom
 * work — they must match pixel for pixel (D4, D11). "founder": whole-screen pictures at 1x and 6x.
 */

const SHOOT = process.env.SHOOT ?? "before";
const OUT = ".planning/quick/261007-fnz-continuous-zoom-in-every-drawing-viewer-/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismissChrome(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function useMetric(page: Page) {
  await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
  await page.context().addCookies([{ name: "shaper-units", value: "metric", domain: "localhost", path: "/" }]);
}

function blankList(page: Page): Locator {
  return page.getByRole("list", { name: "Blanks" });
}

async function openRocker(page: Page) {
  await page.goto("/design/rocker");
  await expect(blankList(page)).toBeVisible({ timeout: 60_000 });
  await page.waitForFunction(() => {
    const owned = (el: Element | null) => !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
    return (
      owned(document.querySelector('ul[aria-label="Blanks"] button')) &&
      owned(document.querySelector('input[aria-label="Search blanks"]'))
    );
  });
}

async function pickFirstFittingBlank(page: Page): Promise<string> {
  const row = blankList(page).locator('li[data-group="fits"] button').first();
  const name = (await row.locator("[data-blank-name]").innerText()).trim();
  await row.click();
  await expect(page.locator("[data-picked-blank]")).toContainText(name);
  return name;
}

async function hideToolbars(page: Page) {
  await page.addStyleTag({
    content: "[data-viewer-toolbar], [data-viewer-zoom] { visibility: hidden !important; }",
  });
}

function sideView(page: Page): Locator {
  return page.locator('svg:has([data-board-silhouette="profile"])').first();
}

async function settle(page: Page) {
  await page.waitForTimeout(800);
}

test.describe("proof", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(testInfo.project.name.endsWith("-hd"), "proof shots run on desktop and iphone");
    test.setTimeout(180_000);
  });

  test("ROCKER fresh at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-fresh.png");
  });

  test("ROCKER with a blank and measuring points at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await page.getByRole("button", { name: "Show measuring points" }).click();
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-blank.png");
  });

  test("ROCKER turned upright at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await page.getByRole("button", { name: "Show measuring points" }).click();
    await page.getByRole("button", { name: "Rotate the board" }).click();
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-vertical.png");
  });

  test("ROCKER on an iPhone at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "iphone");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-iphone-blank.png");
  });

  test("the order form's ROCKER box", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await goToScreen(page, "SUMMARY");
    await expect(sideView(page)).toBeVisible({ timeout: 60_000 });
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-summary.png");
  });
});

test.describe("founder", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(testInfo.project.name !== "desktop-hd", "founder pictures are desktop-hd only");
    test.skip(SHOOT === "before", "the founder's pictures are taken after the zoom is built");
    test.setTimeout(180_000);
  });

  test("ROCKER at 1x with US Blanks 6'2\"A (the default board's first fitting blank)", async ({ page }) => {
    await dismissChrome(page);
    await openRocker(page);
    const name = await pickFirstFittingBlank(page);
    console.log(`first fitting blank: ${name}`);
    await expect(page.locator("[data-zoom-level]")).toHaveText("1x");
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file("rocker-1x.png") });
  });

  for (const system of ["imperial", "metric"] as const) {
    test(`ROCKER at 6x on the nose (${system})`, async ({ page }) => {
      await dismissChrome(page);
      if (system === "metric") await useMetric(page);
      await openRocker(page);
      await pickFirstFittingBlank(page);
      await page.waitForTimeout(500);
      // A few pixels in from the board's nose end, at the board's own height there.
      const at = await page.evaluate(() => {
        const path = document.querySelector('[data-board-silhouette="profile"]') as SVGPathElement | null;
        const m = path?.getScreenCTM();
        if (!path || !m) throw new Error("no profile");
        const left = path.getBoundingClientRect().left;
        const total = path.getTotalLength();
        const ys: number[] = [];
        for (let i = 0; i <= 4000; i++) {
          const p = path.getPointAtLength((total * i) / 4000);
          const sx = m.a * p.x + m.c * p.y + m.e;
          const sy = m.b * p.x + m.d * p.y + m.f;
          if (sx >= left + 3 && sx <= left + 5) ys.push(sy);
        }
        if (ys.length === 0) throw new Error("no nose points");
        return { x: Math.round(left + 4), y: Math.round(ys.reduce((a, b) => a + b, 0) / ys.length) };
      });
      await page.mouse.move(at.x, at.y);
      for (let i = 0; i < 10; i++) {
        await page.waitForTimeout(200);
        await page.mouse.wheel(0, -100);
      }
      await expect(page.locator("[data-zoom-level]")).toHaveText("6x");
      await expect(page.locator("[data-zoom-grid]")).toHaveCount(1);
      await page.waitForTimeout(1000);
      await page.screenshot({ path: file(system === "metric" ? "rocker-6x-nose-metric.png" : "rocker-6x-nose.png") });
    });
  }
});

/* ── Plan 02 ───────────────────────────────────────────────────────────────────────────────── */

const outlineSvg = (page: Page) => page.locator('svg:has([data-board-silhouette="outline"])').first();
const finsSvg = (page: Page) => page.locator("[data-fin-plot] svg").first();
const topViewSvg = (page: Page) => page.locator('svg[aria-label^="The board\'s outline seen from above"]').first();

async function openScreen(page: Page, href: string, ready: string) {
  await page.goto(href);
  await expect(page.locator(ready).first()).toBeVisible({ timeout: 60_000 });
  await page.waitForFunction(() => {
    const el = document.querySelector("main button, main [role=tab]");
    return !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
  });
}

async function openRails(page: Page) {
  await openScreen(page, "/design/rails", "svg[data-rail-section-plot]:visible");
}

test.describe("proof-02", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(testInfo.project.name.endsWith("-hd"), "proof shots run on desktop and iphone");
    test.setTimeout(180_000);
  });

  test("TEMPLATE at 1x — fresh, construction lines, turned, and on an iPhone", async ({ page }, testInfo) => {
    await dismissChrome(page);
    await openScreen(page, "/design/outline", '[data-board-silhouette="outline"]');
    if (testInfo.project.name === "iphone") {
      await hideToolbars(page);
      await settle(page);
      await expect(outlineSvg(page)).toHaveScreenshot("outline-1x-iphone.png");
      return;
    }
    await hideToolbars(page);
    await settle(page);
    await expect(outlineSvg(page)).toHaveScreenshot("outline-1x-desktop.png");
    await page.getByRole("button", { name: "Show construction lines", includeHidden: true }).dispatchEvent("click");
    await settle(page);
    await expect(outlineSvg(page)).toHaveScreenshot("outline-1x-desktop-construction.png");
    await page.getByRole("button", { name: "Rotate the board to horizontal", includeHidden: true }).dispatchEvent("click");
    await settle(page);
    await expect(outlineSvg(page)).toHaveScreenshot("outline-1x-desktop-horizontal.png");
  });

  test("RAILS at 1x — each plot on a computer, the one plot on an iPhone", async ({ page }, testInfo) => {
    await dismissChrome(page);
    await openRails(page);
    await hideToolbars(page);
    if (testInfo.project.name === "iphone") {
      await settle(page);
      await expect(page.locator('[data-rail-plot-row="phone"] svg[data-rail-section-plot]:visible')).toHaveScreenshot("rails-1x-iphone.png");
      return;
    }
    await expect(page.locator('[data-rail-plot-fit="measured"]')).toHaveCount(1);
    await settle(page);
    for (const key of ["nose", "center", "tail"] as const) {
      await expect(page.locator(`[data-rail-plot-row="desktop"] svg[data-rail-section-plot="${key}"]`)).toHaveScreenshot(
        `rails-1x-desktop-${key}.png`,
      );
    }
  });

  test("FINS at 1x", async ({ page }, testInfo) => {
    await dismissChrome(page);
    await openScreen(page, "/design/fins", "[data-fin-plot] svg");
    await hideToolbars(page);
    await settle(page);
    await expect(finsSvg(page)).toHaveScreenshot(testInfo.project.name === "iphone" ? "fins-1x-iphone.png" : "fins-1x-desktop.png");
  });

  test("the TOP VIEW at 1x — the iPhone's tab, the computer's corner picture", async ({ page }, testInfo) => {
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await hideToolbars(page);
    if (testInfo.project.name === "iphone") {
      await page.getByRole("tab", { name: "TOP VIEW" }).click();
      await settle(page);
      await expect(topViewSvg(page)).toHaveScreenshot("topview-1x-iphone-tab.png");
      return;
    }
    await settle(page);
    await expect(page.locator("[data-top-view-inset] svg")).toHaveScreenshot("topview-1x-desktop-inset.png");
  });

  test("the order form's TEMPLATE, RAILS and fin-marked drawings", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await goToScreen(page, "SUMMARY");
    await expect(outlineSvg(page)).toBeVisible({ timeout: 60_000 });
    await settle(page);
    await expect(page.locator('svg:has([data-board-silhouette="outline"])').nth(0)).toHaveScreenshot("summary-1x-outline.png");
    await expect(page.locator('svg:has([data-board-silhouette="outline"])').nth(1)).toHaveScreenshot("summary-1x-fins.png");
    await expect(page.locator('svg[data-rail-section-plot="center"]').first()).toHaveScreenshot("summary-1x-rails.png");
    await expect(page.locator('svg[data-rail-section-plot="nose"]').first()).toHaveScreenshot("summary-1x-rails-nose.png");
    await expect(page.locator('svg[data-rail-section-plot="tail"]').first()).toHaveScreenshot("summary-1x-rails-tail.png");
  });
});

/** Four wheel notches toward the reader at (x, y), 200 ms apart: 1x to 3x. */
async function wheelToThree(page: Page, at: { x: number; y: number }) {
  await page.mouse.move(Math.round(at.x), Math.round(at.y));
  for (let i = 0; i < 4; i++) {
    await page.waitForTimeout(200);
    await page.mouse.wheel(0, -100);
  }
}

/** The grid's line spacing on screen, in CSS pixels (across lines), or 0 with no grid. */
async function gridSpacing(page: Page, scope: string): Promise<number> {
  return page.evaluate((scope) => {
    const lines = [...document.querySelectorAll(`${scope} [data-zoom-grid] line`)] as SVGLineElement[];
    const n = (l: Element, a: string) => Number(l.getAttribute(a));
    const across = lines.filter((l) => n(l, "x1") === n(l, "x2"));
    const along = lines.filter((l) => n(l, "y1") === n(l, "y2"));
    const pick = across.length >= 2 ? across : along;
    if (pick.length < 2) return 0;
    const at = pick.map((l) => {
      const r = l.getBoundingClientRect();
      return across.length >= 2 ? r.left : r.top;
    });
    at.sort((a, b) => a - b);
    return (at[at.length - 1] - at[0]) / (at.length - 1);
  }, scope);
}

test.describe("founder-02", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(SHOOT === "before", "the founder's pictures are taken after the zoom is built");
    test.setTimeout(180_000);
  });

  test("TEMPLATE at 1x and at 3x over the tail third", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop-hd");
    await dismissChrome(page);
    await openScreen(page, "/design/outline", '[data-board-silhouette="outline"]');
    await settle(page);
    const b = await page.locator('[data-board-silhouette="outline"]').boundingBox();
    if (!b) throw new Error("no outline");
    console.log(`M5 TEMPLATE: ${(b.height / 72).toFixed(2)} px per inch at 1x (6'0" board, ${b.height.toFixed(1)} px long)`);
    await page.screenshot({ path: file("template-1x.png") });
    await wheelToThree(page, { x: b.x + b.width / 2, y: b.y + b.height * 0.78 });
    await expect(page.locator("[data-zoom-level]")).toHaveText("3x");
    await page.waitForTimeout(1000);
    console.log(`TEMPLATE grid at 3x: ${(await gridSpacing(page, "main")).toFixed(2)} px between lines`);
    await page.screenshot({ path: file("template-3x.png") });
  });

  test("RAILS at 1x, and the CENTER plot at 3x toward its apex", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop-hd");
    await dismissChrome(page);
    await openRails(page);
    await expect(page.locator('[data-rail-plot-fit="measured"]')).toHaveCount(1);
    await settle(page);
    const center = page.locator('[data-rail-plot-row="desktop"] svg[data-rail-section-plot="center"]');
    const fit = await center.evaluate((svg) => {
      const vb = (svg as SVGSVGElement).viewBox.baseVal;
      return svg.getBoundingClientRect().width / vb.width;
    });
    console.log(`M5 RAILS: ${(56 * fit).toFixed(2)} px per inch at 1x (fit ${fit.toFixed(3)})`);
    await page.screenshot({ path: file("rails-1x.png") });
    // The pointer on the rail's apex-centre dot, so the picture is the rail itself.
    const apex = await center.evaluate((svg) => {
      const dot = svg.querySelector('circle[fill="#a8425f"]');
      if (!dot) throw new Error("no apex-centre dot");
      const r = dot.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    });
    await wheelToThree(page, apex);
    await expect(page.locator('[data-rail-zoom-host="center"] [data-zoom-level]')).toHaveText("3x");
    await expect(page.locator('[data-rail-zoom-host="nose"] [data-zoom-level]')).toHaveText("1x");
    await page.waitForTimeout(1000);
    console.log(`RAILS grid at 3x: ${(await gridSpacing(page, '[data-rail-plot-row="desktop"]')).toFixed(2)} px between finer lines`);
    await page.screenshot({ path: file("rails-3x-center.png") });
  });

  test("FINS at 1x and at 3x over the centre fin", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop-hd");
    await dismissChrome(page);
    await openScreen(page, "/design/fins", "[data-fin-plot] svg");
    await settle(page);
    const fit = await finsSvg(page).evaluate((svg) => {
      const vb = (svg as SVGSVGElement).viewBox.baseVal;
      const r = svg.getBoundingClientRect();
      return Math.min(r.width / vb.width, r.height / vb.height);
    });
    console.log(`M5 FINS: ${(14 * fit).toFixed(2)} px per inch at 1x (fit ${fit.toFixed(3)})`);
    await page.screenshot({ path: file("fins-1x.png") });
    // The centre fin: the one fin mark drawn solid, on the stringer.
    const fin = await finsSvg(page).evaluate((svg) => {
      const marks = [...svg.querySelectorAll('line[stroke="var(--color-surf-accent-ink)"]')];
      const centre = marks.find((l) => (l.getAttribute("stroke-dasharray") ?? "none") === "none") ?? marks[0];
      if (!centre) throw new Error("no fin mark");
      const r = centre.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    });
    await wheelToThree(page, fin);
    await expect(page.locator("[data-zoom-level]")).toHaveText("3x");
    await page.waitForTimeout(1000);
    console.log(`FINS grid at 3x: ${(await gridSpacing(page, "[data-fin-plot]")).toFixed(2)} px between lines`);
    await page.screenshot({ path: file("fins-3x.png") });
  });

  test("the TOP VIEW tab on an iPhone at 1x and at 3x over the nose", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "iphone-hd");
    await dismissChrome(page);
    await openRocker(page);
    const name = await pickFirstFittingBlank(page);
    console.log(`first fitting blank: ${name}`);
    await page.getByRole("tab", { name: "TOP VIEW" }).click();
    await expect(topViewSvg(page)).toBeVisible();
    await page.evaluate(() => document.querySelector("main")?.scrollIntoView({ block: "start" }));
    await settle(page);
    const board = page.locator("[data-top-view-board]");
    const b = await board.boundingBox();
    if (!b) throw new Error("no board from above");
    console.log(`M5 TOP VIEW tab (iPhone 14): ${(b.height / 72).toFixed(2)} px per inch at 1x`);
    await page.screenshot({ path: file("topview-1x-iphone.png") });
    const nose = { x: b.x + b.width / 2, y: b.y + 14 };
    await topViewSvg(page).evaluate((el, at) => {
      for (let i = 0; i < 4; i++) {
        el.dispatchEvent(new WheelEvent("wheel", { deltaY: -100, clientX: at.x, clientY: at.y, bubbles: true, cancelable: true }));
      }
    }, nose);
    await expect(page.locator("[data-zoom-level]")).toHaveText("3x");
    await page.waitForTimeout(1000);
    console.log(`TOP VIEW grid at 3x: ${(await gridSpacing(page, "main")).toFixed(2)} px between lines (0 = no grid)`);
    await page.screenshot({ path: file("topview-3x-iphone.png") });
  });
});

import path from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

/**
 * Quick 261007-fnz pictures. "proof": ROCKER at 1x, the drawing alone, before and after the zoom
 * work — they must match pixel for pixel (D4, D11). "founder": whole-screen pictures at 1x and 6x.
 */

const SHOOT = process.env.SHOOT ?? "before";
const OUT = ".planning/quick/261007-fnz-continuous-zoom-in-every-drawing-viewer-/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismissChrome(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function useMetric(page: Page) {
  await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
  await page.context().addCookies([{ name: "shaper-units", value: "metric", domain: "localhost", path: "/" }]);
}

function blankList(page: Page): Locator {
  return page.getByRole("list", { name: "Blanks" });
}

async function openRocker(page: Page) {
  await page.goto("/design/rocker");
  await expect(blankList(page)).toBeVisible({ timeout: 60_000 });
  await page.waitForFunction(() => {
    const owned = (el: Element | null) => !!el && Object.keys(el).some((key) => key.startsWith("__reactFiber"));
    return (
      owned(document.querySelector('ul[aria-label="Blanks"] button')) &&
      owned(document.querySelector('input[aria-label="Search blanks"]'))
    );
  });
}

async function pickFirstFittingBlank(page: Page): Promise<string> {
  const row = blankList(page).locator('li[data-group="fits"] button').first();
  const name = (await row.locator("[data-blank-name]").innerText()).trim();
  await row.click();
  await expect(page.locator("[data-picked-blank]")).toContainText(name);
  return name;
}

async function hideToolbars(page: Page) {
  await page.addStyleTag({
    content: "[data-viewer-toolbar], [data-viewer-zoom] { visibility: hidden !important; }",
  });
}

function sideView(page: Page): Locator {
  return page.locator('svg:has([data-board-silhouette="profile"])').first();
}

async function settle(page: Page) {
  await page.waitForTimeout(800);
}

test.describe("proof", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(testInfo.project.name === "desktop-hd", "proof shots run on desktop and iphone");
    test.setTimeout(180_000);
  });

  test("ROCKER fresh at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-fresh.png");
  });

  test("ROCKER with a blank and measuring points at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await page.getByRole("button", { name: "Show measuring points" }).click();
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-blank.png");
  });

  test("ROCKER turned upright at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await page.getByRole("button", { name: "Show measuring points" }).click();
    await page.getByRole("button", { name: "Rotate the board" }).click();
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-desktop-vertical.png");
  });

  test("ROCKER on an iPhone at 1x", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "iphone");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await hideToolbars(page);
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-iphone-blank.png");
  });

  test("the order form's ROCKER box", async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== "desktop");
    await dismissChrome(page);
    await openRocker(page);
    await pickFirstFittingBlank(page);
    await goToScreen(page, "SUMMARY");
    await expect(sideView(page)).toBeVisible({ timeout: 60_000 });
    await settle(page);
    await expect(sideView(page)).toHaveScreenshot("rocker-1x-summary.png");
  });
});

test.describe("founder", () => {
  test.beforeEach(async ({}, testInfo) => {
    test.skip(testInfo.project.name !== "desktop-hd", "founder pictures are desktop-hd only");
    test.skip(SHOOT === "before", "the founder's pictures are taken after the zoom is built");
    test.setTimeout(180_000);
  });

  test("placeholder until Task 3", async () => {
    void useMetric;
    void file;
  });
});

import { devices } from "@playwright/test";
import base from "../../../../playwright.config";

export default {
  ...base,
  testDir: ".",
  testMatch: "shoot.spec.ts",
  testIgnore: [],
  snapshotPathTemplate: "{testDir}/1x-proof/{arg}{ext}",
  expect: { ...base.expect, toHaveScreenshot: { ...base.expect?.toHaveScreenshot, maxDiffPixels: 0 } },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 } },
    { name: "desktop-hd", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
};

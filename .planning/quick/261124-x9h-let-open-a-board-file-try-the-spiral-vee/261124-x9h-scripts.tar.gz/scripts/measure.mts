// Quick 261124-x9h, D-05: the founder's twelve sample files through the real import (brdLookFromBytes), one after another.
// The files are READ from ~/Downloads and never copied anywhere (the `_decrypt` copies and test-curves-v2.brd are skipped).
//
//   X9H_ROOT=<checkout root> npx --no-install tsx --tsconfig <the SAME checkout root>/tsconfig.json measure.mts <label> [reps]
//
// The tsconfig must be the measured checkout's own: lib code imports `@/lib/...`, and that alias resolves beside the tsconfig.
// Writes ../out/<label>.json beside this script's folder (make that folder first). `secs` is the fastest of `reps` opens (3 by
// default), because a single open wobbles by a second on a busy machine.
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";

const ROOT = process.env.X9H_ROOT;
if (!ROOT) throw new Error("set X9H_ROOT to the checkout to measure");
const { brdLookFromBytes } = await import(ROOT + "/lib/export/brd-look.ts");
const DL = homedir() + "/Downloads";
const FILES = readdirSync(DL)
  .filter((f) => f.endsWith(".brd") && !f.includes("_decrypt") && f !== "test-curves-v2.brd")
  .sort();
const label = process.argv[2] ?? "run";
const reps = Number(process.argv[3] ?? 3);
const IN = 25.4;
const sixtyFourths = (v: number) => `${Math.round((v / IN) * 64)}/64"`;
const cutWords = (c: any) => (c.depth > 0 ? `${c.name} ${sixtyFourths(c.depth)}` : c.name);

const bytesOf = (f: string) => new Uint8Array(readFileSync(DL + "/" + f));
brdLookFromBytes(bytesOf(FILES[0]), FILES[0]); // warm up
const rows: any[] = [];
for (const f of FILES) {
  let secs = Infinity;
  let r: any = null;
  for (let rep = 0; rep < reps; rep++) {
    const bytes = bytesOf(f);
    const t0 = performance.now();
    r = brdLookFromBytes(bytes, f);
    secs = Math.min(secs, (performance.now() - t0) / 1000);
  }
  if (!r.ok) {
    console.log(f, "NOT OK", r.problem);
    continue;
  }
  const b = r.look.bottom;
  const ra = r.look.rails;
  const row = {
    file: f,
    names: b ? [b.bottom.nose.name, b.bottom.center.name, b.bottom.tail.name] : [],
    cuts: b ? [cutWords(b.bottom.nose), cutWords(b.bottom.center), cutWords(b.bottom.tail)] : [],
    widest: b ? +b.closeness.largest.toFixed(3) : null,
    typical: b ? +b.closeness.typical.toFixed(3) : null,
    at: b ? [+(b.closeness.station / IN).toFixed(1), +(b.closeness.across / IN).toFixed(2)] : null,
    rails: ra ? [+ra.closeness.largest.toFixed(2), +ra.closeness.typical.toFixed(2)] : null,
    order: ra?.order ?? null,
    secs: +secs.toFixed(2),
  };
  rows.push(row);
  console.log(`${f.padEnd(36)} bottom ${row.widest?.toFixed(2)} / ${row.typical?.toFixed(2)}  rails ${row.rails?.map((v) => v.toFixed(2)).join(" / ")} ${row.order}  ${row.secs.toFixed(2)} s\n    ${row.cuts.join(" · ")}`);
}
console.log(`${rows.length} files, total ${rows.reduce((a, r) => a + r.secs, 0).toFixed(1)} s (fastest of ${reps})`);
const out = new URL("../out/", import.meta.url);
mkdirSync(out, { recursive: true });
writeFileSync(new URL(label + ".json", out), JSON.stringify(rows, null, 1));

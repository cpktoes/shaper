// Plan-time measurement for quick 261124-x9h: the app's own board written the way brd-fit-preview.test.ts's `writeWith` writes it
// (the fixture's fields as they are, not read as D-30 read them), opened through the real import (brdLookFromBytes), today and
// with the spike's fix (b) switched on (SPIKE_B=spiral). Reads the scratch worktree only.
const WT = process.env.SPIKE_ROOT!;
const G = await import(WT + "/lib/geometry/bottom.ts");
const { brdBottomStations, brdText } = await import(WT + "/lib/export/brd.ts");
const { brdLookFromBytes } = await import(WT + "/lib/export/brd-look.ts");
const { phase16Boards } = await import(WT + "/lib/geometry/__fixtures__/phase16-boards.ts");
const { bottomStationSlider } = await import(WT + "/lib/geometry/blank-reasons.ts");
const { buildBoardSurface } = await import(WT + "/lib/geometry/board-surface.ts");
const D = await import(WT + "/lib/geometry/design.ts");
const { buildOutline } = await import(WT + "/lib/geometry/outline.ts");
const { inchesToMm, mm, mmToInches } = await import(WT + "/lib/geometry/units.ts");

const labels = (process.argv[2] ?? "midlength|asis|hard").split(",");
const aheads = (process.argv[3] ?? "20,26").split(",").map(Number);
const stepsList = (process.argv[4] ?? "2").split(",").map(Number);
const words = (c: any) => (G.cutKind(c.name) === "flat" ? c.name : `${c.name} ${(mmToInches(c.depth) * 16).toFixed(2)}/16"`);
for (const label of labels) {
  const f = phase16Boards().find((b: any) => b.label === label).fields;
  const g = buildOutline(f.outline);
  const p = D.designSideProfile(f, D.LIVE_DESIGN_RULES);
  const r = D.deriveEffectiveRails(f.rails, p.effectiveFoil, f.railsImportFoilThickness);
  const board0 = D.designBottomBoard(f.outline, g, p, D.designFinPlacement(f));
  for (const steps of stepsList)
    for (const ahead of aheads) {
      let spec = { ...G.startingCut("tail", "Spiral Vee", board0), depth: inchesToMm(steps / 16) };
      const base = G.resolveCut("tail", spec, board0);
      const grid = bottomStationSlider(mm(0), board0.length, "imperial");
      const station = grid.toMm(Math.round(mmToInches(mm(board0.length - (base.start + inchesToMm(ahead)))) * 2) / 2);
      spec = G.keepStationsInOrder("tail", { ...spec, ...G.storeCutStation("tail", "start", station, board0) }, "start", board0, "narrowest");
      const bottom = { ...structuredClone(G.DEFAULT_BOTTOM), tail: spec };
      const s = buildBoardSurface({ sections: D.designCrossSectionInput(g, p, r, f.outline.length, { bottom, board: board0 }), geometry: g, rockerAt: p.rockerAt });
      const text = brdText(s, { bottomStations: brdBottomStations(G.resolveBottom(bottom, board0)) }).text;
      const bytes = Uint8Array.from(text, (ch: string) => ch.charCodeAt(0));
      console.log(`\n- ${label}: Spiral Vee ${steps}/16", Start ${mmToInches(G.resolveCut("tail", spec, board0).start).toFixed(1)}" from the tail (+${ahead}")`);
      for (const mode of ["", "spiral"]) {
        if (mode) process.env.SPIKE_B = mode;
        else delete process.env.SPIKE_B;
        const t0 = performance.now();
        const out = brdLookFromBytes(bytes, "x.brd");
        const secs = (performance.now() - t0) / 1000;
        if (!out.ok) {
          console.log("  NOT OK", out.problem);
          continue;
        }
        const lb = out.look.bottom!;
        const fb = out.fields?.bottom;
        console.log(
          `  ${(mode || "today").padEnd(7)} look: ${words(lb.bottom.nose)} | ${words(lb.bottom.center)} | ${words(lb.bottom.tail)}  shown ${lb.closeness.largest.toFixed(2)} / ${lb.closeness.typical.toFixed(2)}  rails ${out.look.rails ? out.look.rails.closeness.largest.toFixed(2) + " / " + out.look.rails.closeness.typical.toFixed(2) + " " + out.look.rails.order : "none"}  opens as: ${fb ? [fb.nose.name, fb.center.name, fb.tail.name].join(" | ") : "no bottom key"}  ${secs.toFixed(2)} s`,
        );
      }
    }
}

// Splices the two draft test snippets into the SCRATCH worktree's test files (never the repo's), so they can be run under
// vitest with the spike's switch on and off. Usage: node splice-drafts.cjs <scratch worktree>
const fs = require("node:fs");
const path = require("node:path");
const wt = process.argv[2];
if (!wt || !wt.includes("scratchpad")) throw new Error("give the scratch worktree");
const here = __dirname;

// 1. brd-bottom.test.ts: inside the "round trips" describe, after its last it.each.
{
  const file = path.join(wt, "lib/geometry/brd-bottom.test.ts");
  const lines = fs.readFileSync(file, "utf8").split("\n");
  const at = lines.findIndex((l) => l.includes('("the Mid-length with the mix %s"'));
  if (at < 0) throw new Error("anchor not found in brd-bottom.test.ts");
  if (lines.some((l) => l.includes("spiralAlone"))) console.log("brd-bottom.test.ts already spliced");
  else {
    lines.splice(at + 1, 0, "", ...fs.readFileSync(path.join(here, "draft-brd-bottom.test.snippet.ts"), "utf8").replace(/\n$/, "").split("\n"));
    fs.writeFileSync(file, lines.join("\n"));
    console.log("spliced brd-bottom.test.ts after line", at + 1);
  }
}

// 2. brd-look.test.ts: the imports it needs after its last import line, the describe at the end.
{
  const file = path.join(wt, "lib/export/brd-look.test.ts");
  let text = fs.readFileSync(file, "utf8");
  if (text.includes("261124-x9h")) console.log("brd-look.test.ts already spliced");
  else {
    text = text
      .replace(
        'import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } from "../geometry/design";',
        'import { bottomStationSlider } from "../geometry/blank-reasons";\nimport { DEFAULT_BOTTOM, keepStationsInOrder, resolveBottom, resolveCut, startingCut, storeCutStation } from "../geometry/bottom";\nimport { BRD_BOTTOM_FLAT_MM } from "../geometry/brd-bottom";\nimport { designBottomBoard, designCrossSectionInput, designFinPlacement, designSideProfile, deriveEffectiveRails, LIVE_DESIGN_RULES } from "../geometry/design";\nimport { inchesToMm, mm, mmToInches } from "../geometry/units";',
      )
      .replace('import { brdText } from "./brd";', 'import { brdBottomStations, brdText } from "./brd";');
    text = text.replace(/\n*$/, "\n") + fs.readFileSync(path.join(here, "draft-brd-look.test.snippet.ts"), "utf8");
    fs.writeFileSync(file, text);
    console.log("spliced brd-look.test.ts");
  }
}

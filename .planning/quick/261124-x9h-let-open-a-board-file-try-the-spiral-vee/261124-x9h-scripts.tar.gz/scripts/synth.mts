// Plan-time measurement for quick 261124-x9h: which app-written Spiral Vee board fails to come back as a Spiral Vee alone
// today, and comes back with the spike's fix (b) switched on (SPIKE_B=spiral). Reads the scratch worktree only.
const WT = process.env.SPIKE_ROOT!;
const G = await import(WT + "/lib/geometry/bottom.ts");
const BB = await import(WT + "/lib/geometry/brd-bottom.ts");
const { brdBottomStations, brdText } = await import(WT + "/lib/export/brd.ts");
const { readAnyBrd } = await import(WT + "/lib/export/brd-read.ts");
const { brdFitLook } = await import(WT + "/lib/export/brd-fit-preview.ts");
const { asD30Read, phase16Boards } = await import(WT + "/lib/geometry/__fixtures__/phase16-boards.ts");
const { bottomStationSlider } = await import(WT + "/lib/geometry/blank-reasons.ts");
const { buildBoardSurface } = await import(WT + "/lib/geometry/board-surface.ts");
const { fitBoardToBrd } = await import(WT + "/lib/geometry/brd-fit.ts");
const D = await import(WT + "/lib/geometry/design.ts");
const { buildOutline } = await import(WT + "/lib/geometry/outline.ts");
const { inchesToMm, mm, mmToInches } = await import(WT + "/lib/geometry/units.ts");

const BOARDS = phase16Boards();
function builder(label: string) {
  const fields = asD30Read(BOARDS.find((b: any) => b.label === label).fields);
  const geometry = buildOutline(fields.outline);
  const profile = D.designSideProfile(fields, D.LIVE_DESIGN_RULES);
  const rails = D.deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const board = D.designBottomBoard(fields.outline, geometry, profile, D.designFinPlacement(fields));
  const write = (bottom: any): string => {
    const surface = buildBoardSurface({
      sections: D.designCrossSectionInput(geometry, profile, rails, fields.outline.length, { bottom, board }),
      geometry,
      rockerAt: profile.rockerAt,
    });
    return brdText(surface, { bottomStations: brdBottomStations(G.resolveBottom(bottom, board)) }).text;
  };
  return { fields, board, write };
}
const onGrid = (board: any, fromTail: number) =>
  bottomStationSlider(mm(0), board.length, "imperial").toMm(Math.round(mmToInches(mm(board.length - fromTail)) * 2) / 2);

function spiral(board: any, aheadIn: number, steps: number) {
  let spec = G.startingCut("tail", "Spiral Vee", board);
  const base = G.resolveCut("tail", spec, board);
  spec = { ...spec, depth: inchesToMm(steps / 16) };
  if (aheadIn > 0)
    spec = G.keepStationsInOrder("tail", { ...spec, ...G.storeCutStation("tail", "start", mm(onGrid(board, base.start + inchesToMm(aheadIn))), board) }, "start", board, "narrowest");
  return { ...structuredClone(G.DEFAULT_BOTTOM), tail: spec };
}
const words = (c: any, board: any) => {
  if (G.cutKind(c.name) === "flat") return c.name;
  const r = G.resolveCut(c.name.includes("Entry") || c.name.includes("Nose") ? "nose" : "tail", c, board);
  return `${c.name} ${(mmToInches(c.depth) * 16).toFixed(2)}/16" start ${mmToInches(r.start).toFixed(1)}" deepest ${mmToInches(r.deepest).toFixed(1)}" end ${mmToInches(r.end).toFixed(1)}"`;
};

const labels = (process.argv[2] ?? "shortboard|asis|hard,midlength|asis|hard").split(",");
const aheads = (process.argv[3] ?? "0,8,14,20,26").split(",").map(Number);
const stepsList = (process.argv[4] ?? "2").split(",").map(Number);
const whole = process.argv[5] === "look";
for (const label of labels) {
  const src = builder(label);
  const b0 = G.resolveCut("tail", G.startingCut("tail", "Spiral Vee", src.board), src.board);
  console.log(`\n## ${label}  length ${mmToInches(src.board.length).toFixed(1)}"  frontFins ${mmToInches(src.board.frontFins).toFixed(1)}"  Spiral Vee starting Start ${mmToInches(b0.start).toFixed(1)}" from the tail`);
  for (const steps of stepsList)
    for (const ahead of aheads) {
      const wanted = spiral(src.board, ahead, steps);
      const w = G.resolveCut("tail", wanted.tail, src.board);
      const text = src.write(wanted);
      const read = readAnyBrd(Uint8Array.from(text, (ch: string) => ch.charCodeAt(0)));
      const b = read.board;
      const fit = fitBoardToBrd({ length: b.length, outline: b.outline, bottom: b.bottom, deck: b.deck });
      const board = BB.brdFittedBottomBoard(fit);
      console.log(`\n- written: Spiral Vee ${steps}/16", Start ${mmToInches(w.start).toFixed(1)}" from the tail (+${ahead}" ahead of the name's own); ${b.sections.length} sections`);
      for (const mode of ["", "spiral"]) {
        if (mode) process.env.SPIKE_B = mode;
        else delete process.env.SPIKE_B;
        const t0 = performance.now();
        const found = BB.fitBottomToBrd(b.sections, board);
        const secs = (performance.now() - t0) / 1000;
        const scorer = BB.brdBottomScorer(board, BB.brdBottomBlends(found.sections));
        const value = (x: any) => scorer.valueOfSpecs({ nose: x.nose, center: x.center, tail: x.tail });
        console.log(
          `  ${(mode || "today").padEnd(7)} fit: ${found.bottom.nose.name} | ${words(found.bottom.center, board)} | ${words(found.bottom.tail, board)}  shown ${found.closeness.largest.toFixed(2)} / ${found.closeness.typical.toFixed(2)}  score ${value(found.bottom).toFixed(3)} (written scores ${value(wanted).toFixed(3)})  ${secs.toFixed(2)} s`,
        );
        if (whole) {
          const t1 = performance.now();
          const look = brdFitLook(b);
          const s2 = (performance.now() - t1) / 1000;
          const lb = look.bottom!;
          console.log(
            `  ${(mode || "today").padEnd(7)} look: ${lb.bottom.nose.name} | ${words(lb.bottom.center, board)} | ${words(lb.bottom.tail, board)}  shown ${lb.closeness.largest.toFixed(2)} / ${lb.closeness.typical.toFixed(2)}  rails ${look.rails ? look.rails.closeness.largest.toFixed(2) + " / " + look.rails.closeness.typical.toFixed(2) + " " + look.rails.order : "none"}  ${s2.toFixed(2)} s`,
          );
        }
      }
    }
}

// Quick 261124-x9h, D-05: the before/after table for the SUMMARY, from two runs of measure.mts.
//   npx --no-install tsx table.mts <before label> <after label>
// Prints a markdown table (widest / typical miss in mm) and, under it, every file whose figures or names moved.
import { readFileSync } from "node:fs";
const dir = new URL("../out/", import.meta.url);
const [a, b] = process.argv.slice(2);
const A = JSON.parse(readFileSync(new URL(a + ".json", dir), "utf8"));
const B = JSON.parse(readFileSync(new URL(b + ".json", dir), "utf8"));
const short = (n: string[]) => n.map((x) => x.replace(/ (Entry|Center|Exit)$/, "")).join(" · ");
const two = (v: number[] | null) => (v ? v.map((x) => x.toFixed(2)).join(" / ") : "none");
console.log(`| File | Bottom before | Bottom after | Rails before | Rails after | Cuts before | Cuts after | Open before | Open after |\n|---|---|---|---|---|---|---|---|---|`);
let ta = 0;
let tb = 0;
const moved: string[] = [];
for (const ra of A) {
  const rb = B.find((x: any) => x.file === ra.file);
  if (!rb) {
    moved.push(`${ra.file}: missing from ${b}`);
    continue;
  }
  ta += ra.secs;
  tb += rb.secs;
  const same = ra.names.join() === rb.names.join();
  const bottomMoved = Math.abs(ra.widest - rb.widest) > 0.005 || Math.abs(ra.typical - rb.typical) > 0.005;
  const railsMoved = two(ra.rails) !== two(rb.rails) || ra.order !== rb.order;
  if (!same || bottomMoved || railsMoved) moved.push(`${ra.file}: ${!same ? "names " : ""}${bottomMoved ? "bottom " : ""}${railsMoved ? "rails" : ""}`.trim());
  console.log(
    `| ${ra.file.replace(".brd", "")} | ${ra.widest.toFixed(2)} / ${ra.typical.toFixed(2)} | ${rb.widest.toFixed(2)} / ${rb.typical.toFixed(2)} | ${two(ra.rails)} | ${two(rb.rails)} | ${short(ra.names)} | ${same ? "same" : short(rb.names)} | ${ra.secs.toFixed(2)} s | ${rb.secs.toFixed(2)} s |`,
  );
}
console.log(`| Total | | | | | | | ${ta.toFixed(1)} s | ${tb.toFixed(1)} s |`);
console.log(`\nMoved (${moved.length}):\n${moved.map((m) => "- " + m).join("\n") || "- none"}`);

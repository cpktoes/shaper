Quick 261125-v2f (Open a board file brings back a nose concave with its Rail Roll): the measuring scripts and results.
Packed by the planner 2026-11-25; the executor adds its own before/after runs to out/ and re-packs this archive.
Extract into a NEW, EMPTY folder in your own scratchpad (never under the repo or a worktree). Call scripts by absolute path.
The founder's .brd files are not in here and must never be: measure.mts reads them where they are, in ~/Downloads.

scripts/ (copied unchanged from spike 007's spike-source.tar.gz unless said)
  measure.mts      the twelve sample files through the real import (brdLookFromBytes), fastest of N opens, one digest a file
                   over the fitted cuts, every measured section value and the fitted rails. Writes out/<label>.json.
                     ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json <X>/scripts/measure.mts <label> 3
                   It must print "12 files". A line with "!!" means the board that opens lost the roll the preview shows.
  grid.mts         the 296-board round trip: the four presets' |asis|hard boards, each nose concave at Depth 1/16"..1/4" with a
                   Rail Roll 1/16"..1/4" (192), the same with no roll (48), and 56 belly/vee/mixed boards; written with the app's own
                   brdText and opened with brdLookFromBytes. Writes out/<label>.<shard>.jsonl (one board a line).
  run-grid.sh      NEW (the spike's had a hard-coded folder): <X>/scripts/run-grid.sh <checkout> <label> [shards=6] [first] [last]
                   runs grid.mts shards first..last-1 at once and waits for them (a foreground command); run 0 3 then 3 6 to
                   stay inside one call's ten minutes. 296 boards once every shard is done. Use a label of its own (grid-*),
                   never one a twelve-file run uses (same.mjs tells the two apart by out/<label>.json).
  analyze.mjs      scores grid runs: node <X>/scripts/analyze.mjs <label> [<label> ...]   (BY=1 for per preset)
  findingb.mjs     Finding B's ten boards and per-preset / per-name tallies: node findingb.mjs <today label> <trial label>
  realdiff.mjs     the controls: widest grew, invented rolls, false concaves: node realdiff.mjs <today label> <trial label>
  same.mjs         NEW: two runs board by board (grid) or file by file by digest (twelve): node same.mjs <labelA> <labelB>
  plan-exact.mts   NEW, plan time: the Shortboard written as exact sections (the brd-bottom.test.ts polish helper), the grid
                   answer, the polished answer and the nose's dish reading with its seed, for nine bottoms.
  plan-slice.mts   NEW, plan time: the planned unit-test slice through the real import, one open each, timed.
  plan-tie-board.mts  NEW, plan time: the one slice board that needs the founder's 0.05 mm tie (Fish, Slight 1/16", roll 1/8").
  plan-tieroll.mts NEW, plan time: replays spike 007's recommended choice on its hyb logs with and without "the tie's winner must
                   carry a Rail Roll above 0" (D-03's words). Reads spike 007's results/ folder (hyb.*.jsonl).
  plan-pick.mjs    NEW, plan time: spike 007's hyb and base results side by side per board (reads spike 007's results/ folder).

out/
  spike-base.*.jsonl, spike-hyb.*.jsonl   spike 007's grid runs: today (main d36cb614 = 687259d4 in code) and the recommended
                                          trial (S7_MODE=rec S7_TRIG=sig S7_TIE=0.05 S7_HYBRID=1). analyze: base 67/192, 57, 29;
                                          hyb 158/192, 145, 144; false concaves 0/48 both; invented rolls 2/48 -> 4/48.
  spike-t12-main.json, spike-t12-hyb.json the twelve files, today and the trial (digests: eleven equal, testLB differs).
  plan-exact-trial.txt / -today.txt       plan-exact.mts on the trial and on today's code.
  plan-slice-trial.txt / -today.txt       plan-slice.mts on the trial (7 of 7 rolled boards back within 1/16" with no other cut,
                                          28.5 s for 12 opens) and on today's code (1 of 7; 19.6 s).
  plan-tie-board.txt                      trial: Blended 4/64" roll 7.6/64", flat, 1.439/0.212; today: Rolled Belly Entry, 1.682/0.207.
  plan-tieroll.txt                        179 boards tried, 0 change with the roll condition.
  plan-trial-tests.log                    the seven .brd unit suites on the trial: 419 passed, 1 failed (mf8's "a 1/16" Rail Roll,
                                          whose grid answer is already under the millimetre gate: no retry..." - see the PLAN).
  plan-pick.txt                           plan-pick.mjs's listing.

Added by the executor (2026-11-25, worktree base 1590a6af, code commits 953a4ccf and 7707ee85):
  t12-before.json / t12-after.json        the twelve files on the untouched code (load 8.5-11.5) and on the build (load 30-46);
                                          same.mjs: before = spike-t12-main (0 differ), after = spike-t12-hyb (0 differ),
                                          before -> after testLB alone (typical 0.214 -> 0.213). t12-after.log is its output.
  t12-time-before.json / t12-time-after.json  the same twelve timed back to back at load 7-8 (before from an exported copy of
                                          the base's lib/ in scratch): 18.2 s -> 20.2 s; digests equal to the runs above.
  grid-before.*.jsonl / grid-after.*.jsonl the 296-board grid: before = spike-base (0 differ), after = spike-hyb (0 differ).
  same-*.txt, analyze-grid-before-after.txt, findingb-grid-before-after.txt, realdiff-grid-before-after.txt  the comparisons.
  npm-test.log, playwright.log            the unit suite and the three .brd browser specs on desktop, iphone and android.

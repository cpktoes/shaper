import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

// Plan 04's before/after pictures (quick 261102-gec, R2): the Shortboard preset on RAILS, its
// Advanced menus, and (after only) the Center Rail's Domed Deck Band at both ends of its slider.
const OUT = ".planning/quick/261102-gec-rails-v2-on-a-new-branch-the-rails-scree/pictures";
const SHOOT = process.env.SHOOT ?? "before";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function openShortboardRails(page: Page) {
  await dismiss(page);
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: "Shortboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    if (new URL(page.url()).pathname === "/design/outline") return;
    await card.first().click({ timeout: 3_000 }).catch(() => undefined);
    await page.waitForURL("**/design/outline", { timeout: 15_000 });
  }).toPass({ timeout: 60_000 });
  await goToScreen(page, "RAILS");
  await page.waitForFunction(
    () => {
      const b = document.querySelector("[data-viewer-toolbar] button");
      return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
    },
    undefined,
    { timeout: 60_000 },
  );
}

async function openAdvanced(page: Page, key: "nose" | "center" | "tail") {
  const group = page.locator(`[data-rail-group="${key}"]`);
  const heading = group.getByRole("button", { name: /^Advanced [▾▸]$/ });
  const reset = group.getByRole("button", { name: /Reset Advanced Settings/ });
  await expect(async () => {
    if (!(await reset.isVisible())) await heading.click();
    await expect(reset).toBeVisible({ timeout: 1_000 });
  }).toPass({ timeout: 15_000 });
  return { group, heading, reset };
}

const domeThumb = (page: Page, title: string) =>
  page.getByRole("slider", { name: `${title} Domed Deck Band nudge`, exact: true });

test("RAILS plan 04 pictures", async ({ page }, testInfo) => {
  test.setTimeout(180_000);
  await openShortboardRails(page);
  const project = testInfo.project.name;

  if (project === "desktop") {
    await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeVisible({
      timeout: 60_000,
    });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file(`p4-${SHOOT}-viewer-desktop.png`) });

    const nose = await openAdvanced(page, "nose");
    await nose.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(500);
    await page.screenshot({ path: file(`p4-${SHOOT}-advanced-nose-desktop.png`) });
    await nose.heading.click();

    const center = await openAdvanced(page, "center");
    await center.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(500);
    await page.screenshot({ path: file(`p4-${SHOOT}-advanced-center-desktop.png`) });

    if (SHOOT === "after") {
      const thumb = domeThumb(page, "Center Rail");
      await thumb.focus();
      await thumb.press("End");
      await expect(center.group.getByText(/^Domed Deck Band — .+ \(\+2"\)$/)).toBeVisible();
      await page.waitForTimeout(800);
      await page.screenshot({ path: file("p4-after-dome-plus2-desktop.png") });
      await thumb.press("Home");
      await expect(center.group.getByText(/^Domed Deck Band — .+ \(-2"\)$/)).toBeVisible();
      await page.waitForTimeout(800);
      await page.screenshot({ path: file("p4-after-dome-minus2-desktop.png") });
    }
  } else {
    const railTabs = page.getByRole("tablist").filter({ hasText: "NOSE" });
    await expect(railTabs).toBeVisible({ timeout: 60_000 });
    await railTabs.getByRole("tab", { name: "NOSE" }).click();
    await page.waitForTimeout(500);
    const nose = await openAdvanced(page, "nose");
    await nose.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(800);
    await page.screenshot({ path: file(`p4-${SHOOT}-advanced-iphone.png`) });

    if (SHOOT === "after") {
      await railTabs.getByRole("tab", { name: "CENTER" }).click();
      await page.waitForTimeout(500);
      const center = await openAdvanced(page, "center");
      const thumb = domeThumb(page, "Center Rail");
      await thumb.focus();
      await thumb.press("End");
      await expect(center.group.getByText(/^Domed Deck Band — .+ \(\+2"\)$/)).toBeVisible();
      const row = center.group.getByText(/^Domed Deck Band — /);
      await row.evaluate((el) => el.scrollIntoView({ block: "center" }));
      await page.waitForTimeout(800);
      await page.screenshot({ path: file("p4-after-dome-plus2-iphone.png") });
    }
  }
});

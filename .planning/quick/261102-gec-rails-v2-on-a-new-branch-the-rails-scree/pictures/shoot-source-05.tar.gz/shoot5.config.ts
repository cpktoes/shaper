import { devices } from "@playwright/test";
import base from "../../../../playwright.config";

export default {
  ...base,
  testDir: ".",
  testMatch: "shoot5.spec.ts",
  testIgnore: [],
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 } },
    { name: "iphone", use: { ...devices["iPhone 14"] } },
  ],
};

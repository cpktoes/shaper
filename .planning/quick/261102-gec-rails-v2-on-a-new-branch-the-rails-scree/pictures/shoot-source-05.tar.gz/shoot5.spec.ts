import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

// Plan 05's before/after pictures (quick 261102-gec, R2): the Shortboard preset on RAILS — the finished
// rail on a flat deck and on a domed one (Center Rail at Heavily Domed, 75%), in VIEWER and in View Full
// Sized, the Advanced menu, and (after only) the Center Rail's Sharp Bottom Edge ticked.
const OUT = ".planning/quick/261102-gec-rails-v2-on-a-new-branch-the-rails-scree/pictures";
const SHOOT = process.env.SHOOT ?? "before";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function openShortboardRails(page: Page) {
  await dismiss(page);
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: "Shortboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    if (new URL(page.url()).pathname === "/design/outline") return;
    await card.first().click({ timeout: 3_000 }).catch(() => undefined);
    await page.waitForURL("**/design/outline", { timeout: 15_000 });
  }).toPass({ timeout: 60_000 });
  await goToScreen(page, "RAILS");
  await page.waitForFunction(
    () => {
      const b = document.querySelector("[data-viewer-toolbar] button");
      return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
    },
    undefined,
    { timeout: 60_000 },
  );
}

async function openAdvanced(page: Page, key: "nose" | "center" | "tail") {
  const group = page.locator(`[data-rail-group="${key}"]`);
  const heading = group.getByRole("button", { name: /^Advanced [▾▸]$/ });
  const reset = group.getByRole("button", { name: /Reset Advanced Settings/ });
  await expect(async () => {
    if (!(await reset.isVisible())) await heading.click();
    await expect(reset).toBeVisible({ timeout: 1_000 });
  }).toPass({ timeout: 15_000 });
  return { group, heading, reset };
}

/** The slider inside the same row as a label line (SliderRow: the label is the row's first child). */
const deckProfileThumb = (page: Page, key: "nose" | "center" | "tail") =>
  page.locator(`[data-rail-group="${key}"]`).getByText(/^Deck Profile — /).locator("xpath=..").getByRole("slider");

async function fullSized(page: Page, name: string) {
  await page.locator("[data-viewer-toolbar]").getByRole("button", { name: "View Full Sized" }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await dialog.getByRole("tab", { name: "Center" }).click();
  await page.waitForTimeout(1000);
  await page.screenshot({ path: file(name) });
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
}

test("RAILS plan 05 pictures", async ({ page }, testInfo) => {
  test.setTimeout(240_000);
  await openShortboardRails(page);
  const project = testInfo.project.name;

  if (project === "desktop") {
    await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeVisible({
      timeout: 60_000,
    });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file(`p5-${SHOOT}-viewer-desktop.png`) });

    const center = await openAdvanced(page, "center");
    await center.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(500);
    await page.screenshot({ path: file(`p5-${SHOOT}-advanced-center-desktop.png`) });

    if (SHOOT === "after") {
      // The un-domed Shortboard with the Center Rail's Sharp Bottom Edge ticked, the bands ghosted so the
      // finished rail reads alone.
      const box = center.group.getByRole("checkbox", { name: "Sharp Bottom Edge" });
      await box.click();
      await expect(box).toHaveAttribute("aria-checked", "true");
      const ghost = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /the bands/ });
      await ghost.click();
      await expect(ghost).toHaveAttribute("aria-pressed", "true");
      await page.waitForTimeout(800);
      await page.screenshot({ path: file("p5-after-sharp-desktop.png") });
      await fullSized(page, "p5-after-sharp-fullsize-desktop.png");
      await ghost.click();
      await expect(ghost).toHaveAttribute("aria-pressed", "false");
      await box.click();
      await expect(box).toHaveAttribute("aria-checked", "false");
    }
    await center.heading.click();

    const thumb = deckProfileThumb(page, "center");
    await thumb.focus();
    await thumb.press("End");
    await expect(center.group.getByText(/^Deck Profile — /)).toBeVisible();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file(`p5-${SHOOT}-domed-desktop.png`) });
    await fullSized(page, `p5-${SHOOT}-domed-fullsize-desktop.png`);
  } else {
    const railTabs = page.getByRole("tablist").filter({ hasText: "NOSE" });
    await expect(railTabs).toBeVisible({ timeout: 60_000 });
    await railTabs.getByRole("tab", { name: "CENTER" }).click();
    await page.waitForTimeout(500);
    const center = await openAdvanced(page, "center");
    await center.reset.evaluate((el) => el.scrollIntoView({ block: "end" }));
    await page.waitForTimeout(800);
    await page.screenshot({ path: file(`p5-${SHOOT}-advanced-iphone.png`) });

    if (SHOOT === "after") {
      const box = center.group.getByRole("checkbox", { name: "Sharp Bottom Edge" });
      await box.click();
      await expect(box).toHaveAttribute("aria-checked", "true");
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.locator('[data-rail-section-plot="center"]').first().evaluate((el) => el.scrollIntoView({ block: "start" }));
      await page.waitForTimeout(800);
      await page.screenshot({ path: file("p5-after-sharp-iphone.png") });
    }
  }
});

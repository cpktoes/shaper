import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

// Plan 03's pictures (quick 261102-gec, R2): VOLUME and the preset cards, before and after volume counts the
// finished rail. SHOOT is "before" or "after".
const SHOOT = process.env.SHOOT ?? "before";
const OUT = ".planning/quick/261102-gec-rails-v2-on-a-new-branch-the-rails-scree/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, `p3-${SHOOT}-${name}`);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function settle(page: Page) {
  await page.waitForFunction(
    () => {
      const b = document.querySelector("button");
      return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
    },
    undefined,
    { timeout: 60_000 },
  );
  await page.waitForTimeout(1000);
}

test("VOLUME plan 03 pictures", async ({ page }, testInfo) => {
  test.setTimeout(240_000);
  await dismiss(page);
  const project = testInfo.project.name;

  if (project === "desktop") {
    // The first board a visitor sees, straight onto VOLUME.
    await page.goto("/design/volume");
    await expect(page.getByText("Estimated Volume").first()).toBeVisible({ timeout: 90_000 });
    await settle(page);
    await page.screenshot({ path: file("volume-desktop.png") });

    // The preset cards with their litres.
    await page.goto("/");
    const card = page.getByRole("button").filter({ hasText: "Shortboard" }).filter({ hasText: "Start Shaping" });
    await expect(card.first()).toBeVisible({ timeout: 90_000 });
    await settle(page);
    await card.first().evaluate((el) => el.scrollIntoView({ block: "center" }));
    await page.waitForTimeout(800);
    await page.screenshot({ path: file("presets-desktop.png") });

    // The Shortboard preset on VOLUME.
    await expect(async () => {
      if (new URL(page.url()).pathname === "/design/outline") return;
      await card.first().click({ timeout: 3_000 }).catch(() => undefined);
      await page.waitForURL("**/design/outline", { timeout: 15_000 });
    }).toPass({ timeout: 60_000 });
    await goToScreen(page, "VOLUME");
    await expect(page.getByText("Estimated Volume").first()).toBeVisible({ timeout: 60_000 });
    await settle(page);
    await page.screenshot({ path: file("volume-shortboard-desktop.png") });
  } else {
    await page.goto("/design/volume");
    await expect(page.getByText("Estimated Volume").first()).toBeVisible({ timeout: 90_000 });
    await settle(page);
    await page.screenshot({ path: file("volume-iphone.png"), fullPage: true });
  }
});

import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

// Plan 02's after pictures (quick 261102-gec, R2): the Shortboard preset on RAILS.
const OUT = ".planning/quick/261102-gec-rails-v2-on-a-new-branch-the-rails-scree/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

async function openShortboardRails(page: Page) {
  await dismiss(page);
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: "Shortboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    if (new URL(page.url()).pathname === "/design/outline") return;
    await card.first().click({ timeout: 3_000 }).catch(() => undefined);
    await page.waitForURL("**/design/outline", { timeout: 15_000 });
  }).toPass({ timeout: 60_000 });
  await goToScreen(page, "RAILS");
  await page.waitForFunction(
    () => {
      const b = document.querySelector("[data-viewer-toolbar] button");
      return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
    },
    undefined,
    { timeout: 60_000 },
  );
}

async function openAdvanced(page: Page, key: "nose" | "center" | "tail") {
  const group = page.locator(`[data-rail-group="${key}"]`);
  const heading = group.getByRole("button", { name: /^Advanced [▾▸]$/ });
  const reset = group.getByRole("button", { name: /Reset Advanced Settings/ });
  await expect(async () => {
    if (!(await reset.isVisible())) await heading.click();
    await expect(reset).toBeVisible({ timeout: 1_000 });
  }).toPass({ timeout: 15_000 });
  return { group, heading, reset };
}

test("RAILS plan 02 after pictures", async ({ page }, testInfo) => {
  test.setTimeout(180_000);
  await openShortboardRails(page);
  const project = testInfo.project.name;

  if (project === "desktop") {
    await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeVisible({ timeout: 60_000 });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file("p2-viewer-on-desktop.png") });

    const toggle = page.locator("[data-viewer-toolbar]").getByRole("button", { name: /finished rail$/ });
    await toggle.click();
    await page.waitForTimeout(600);
    await page.screenshot({ path: file("p2-viewer-off-desktop.png") });
    await toggle.click();
    await page.waitForTimeout(400);

    const nose = await openAdvanced(page, "nose");
    await nose.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(500);
    await page.screenshot({ path: file("p2-advanced-nose-desktop.png") });
    await nose.heading.click();

    const center = await openAdvanced(page, "center");
    await center.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(500);
    await page.screenshot({ path: file("p2-advanced-center-desktop.png") });
    await center.heading.click();

    await page.locator("[data-viewer-toolbar]").getByRole("button", { name: "View Full Sized" }).click();
    await expect(page.getByRole("dialog")).toBeVisible();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file("p2-fullsize-desktop.png") });
  } else if (project === "narrow") {
    const group = page.locator('[data-rail-group="nose"]');
    const readout = group.locator("[data-ratio-readout]");
    const slider = readout.locator("xpath=../..").getByRole("slider");
    // The widest half value the readout can show: 40.5/59.5, from the Shortboard's own Ratio.
    for (let i = 0; i < 80 && (await readout.textContent()) !== "Ratio — 40.5/59.5"; i++) {
      const top = Number((await readout.textContent())?.match(/— ([\d.]+)\//)?.[1]);
      await slider.press(top > 40.5 ? "ArrowLeft" : "ArrowRight");
    }
    await expect(readout).toHaveText("Ratio — 40.5/59.5");
    const row = readout.locator("xpath=../../..");
    await row.evaluate((el) => el.scrollIntoView({ block: "center" }));
    await page.waitForTimeout(500);
    const box = await row.boundingBox();
    if (!box) throw new Error("no Family/Ratio row");
    await page.screenshot({
      path: file("p2-ratio-narrow.png"),
      clip: { x: Math.max(0, box.x - 24), y: Math.max(0, box.y - 60), width: box.width + 48, height: box.height + 100 },
    });
  } else {
    const railTabs = page.getByRole("tablist").filter({ hasText: "NOSE" });
    await expect(railTabs).toBeVisible({ timeout: 60_000 });
    await railTabs.getByRole("tab", { name: "CENTER" }).click();
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file("p2-viewer-center-iphone.png") });

    await railTabs.getByRole("tab", { name: "NOSE" }).click();
    await page.waitForTimeout(500);
    const nose = await openAdvanced(page, "nose");
    await nose.heading.evaluate((el) => el.scrollIntoView({ block: "start" }));
    await page.waitForTimeout(800);
    await page.screenshot({ path: file("p2-advanced-iphone.png") });
  }
});

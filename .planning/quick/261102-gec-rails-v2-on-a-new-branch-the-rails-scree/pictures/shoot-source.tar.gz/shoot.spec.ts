import path from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";

const SHOOT = process.env.SHOOT ?? "before";
const OUT = ".planning/quick/261102-gec-rails-v2-on-a-new-branch-the-rails-scree/pictures";
const file = (name: string) => path.resolve(process.cwd(), OUT, name);

async function dismiss(page: Page) {
  await page.addInitScript(() => window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true"));
  await page.addInitScript(() => window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true"));
}

test("Shortboard RAILS", async ({ page }, testInfo) => {
  test.setTimeout(180_000);
  await dismiss(page);
  await page.goto("/");
  const card = page.getByRole("button").filter({ hasText: "Shortboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    if (new URL(page.url()).pathname === "/design/outline") return;
    await card.first().click({ timeout: 3_000 }).catch(() => undefined);
    await page.waitForURL("**/design/outline", { timeout: 15_000 });
  }).toPass({ timeout: 60_000 });
  await goToScreen(page, "RAILS");
  const pageTabs = page.getByRole("tablist").filter({ hasText: "DATA" });
  if (testInfo.project.name === "desktop") {
    await expect(page.locator('[data-rail-plot-row="desktop"][data-rail-plot-fit="measured"]')).toBeVisible({
      timeout: 60_000,
    });
    await page.waitForTimeout(1000);
    await page.screenshot({ path: file(`${SHOOT}-viewer-desktop.png`) });
    await pageTabs.getByRole("tab", { name: "DATA" }).click();
    await page.waitForTimeout(800);
    await page.screenshot({ path: file(`${SHOOT}-data-desktop.png`) });
    await pageTabs.getByRole("tab", { name: "INSTRUCTIONS" }).click();
    await page.waitForTimeout(800);
    await page.screenshot({ path: file(`${SHOOT}-instructions-desktop.png`) });
  } else {
    const railTabs = page.getByRole("tablist").filter({ hasText: "NOSE" });
    await expect(railTabs).toBeVisible({ timeout: 60_000 });
    for (const rail of ["NOSE", "CENTER", "TAIL"]) {
      await railTabs.getByRole("tab", { name: rail }).click();
      await page.waitForTimeout(1000);
      await page.screenshot({ path: file(`${SHOOT}-viewer-${rail.toLowerCase()}-iphone.png`) });
    }
    await pageTabs.getByRole("tab", { name: "DATA" }).click();
    await page.waitForTimeout(800);
    await page.screenshot({ path: file(`${SHOOT}-data-iphone.png`), fullPage: true });
  }
});

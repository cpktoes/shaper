Quick 261126-akp, Task 2 (2026-11-26): the import measured against today. The founder's .brd files are not in here; they were
read in place from ~/Downloads only.

BASE = 5a55b5fab15bb832eb6293a52ffb938b6f204d85 (the plan commit, before any edit), checked out as a scratch detached worktree
with node_modules linked from the main checkout. W = the executor's worktree at Task 1's commit a3bc5a22.

scripts/
  board.mts            spike 008/009's app-board builder, unchanged (a preset with a nose / centre cut, written with brdText).
  measure.mts          spike 008/009's twelve-file run, unchanged: brdLookFromBytes on each file, fastest of 3; writes out/<label>.json.
  same.mjs             spike 008/009's digest comparison of two twelve-file runs, unchanged.
  identity.mts         (from spike 009's litres.mts, rules loop dropped) 309 boards: every preset plain, each nose concave at
                       Depth 1/16"-1/4" and roll 0-1/4", bellies, Reverse Vee Nose, mixed and Tri-Plane boards, plus the Longboard
                       at Depth 3/16" with rolls of 1/64", 1/32", 3/64"; litres and digests of the .brd bytes and every section.
  identity-compare.mjs compares two identity runs and prints the Longboard litres table.
  time-lb.mts          (from spike 009's time9.mts, switch modes dropped) the three rolled app Longboards of the stop condition,
                       written by the checkout's own writer and opened through brdLookFromBytes, fastest of 3, with the figures.
  verdict.mjs          the stop condition: WORSE / SLOW per file and per Longboard, PASS (exit 0) or STOP (exit 1).
  railscard.mts        RAILS' three cards on the Longboard before and after the pull (the SUMMARY's Bottom Tuck table).

Commands (run from W as the working directory):
  uptime > out/load-base1.txt;  ROOT=$X/base npx --no-install tsx --tsconfig $X/base/tsconfig.json scripts/measure.mts base1 3
  uptime > out/load-after1.txt; ROOT=$W      npx --no-install tsx --tsconfig $W/tsconfig.json      scripts/measure.mts after1 3
  (the same for base2 / after2), and time-lb.mts with the same labels;
  ROOT=... npx --no-install tsx --tsconfig .../tsconfig.json scripts/identity.mts base|after; node scripts/identity-compare.mjs base after
  node scripts/verdict.mjs base1 after1 base2 after2      -> STOP (out/verdict-task1.txt)

out/
  base1/2, after1/2 (.json, .log)   twelve files, today and with Task 1's rule; load-*.txt the uptime before each run
  lb-*.json / lb-*.log              the three rolled app Longboards
  identity-base/after.json          the 309-board identity runs
  verdict-task1.txt                 the verdict on Task 1's rule: STOP
  candc1, candc2, canda (+ lb-)     the three import-side candidates, measured on W with the candidate applied
  candidate-1-c.diff                (c) the opened nose concave's Off Rail held in to where the fitted rails' Bottom Tuck 3 starts,
                                    the import's working boards fitted with no pull, the opened board measured with it
  candidate-2-c-polished.diff       (c) with the bottom polished again under the held Off Rail
  candidate-3-a.diff                (a) the bottom's reading widths following the pulled rail, in both orders
  railscard.txt                     RAILS' cards before and after the pull

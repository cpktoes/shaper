// Quick 261126-akp: RAILS' three cards on the Longboard (each nose concave, Depth 3/16", Rail Roll 1/4"), Bottom Tuck 1 / 2 / 3
// before and after the pull, worked out by the worktree's own code (railBandsPulledToMark over the cards the store builds).
//   ROOT=<worktree> npx --no-install tsx --tsconfig <worktree>/tsconfig.json railscard.mts
import { build, imp } from "./board.mts";
const { railStartLimiter } = await imp("lib/geometry/bottom.ts");
const { bottomRailLift, railAnchorStations, railBandsPulledToMark, railStringerDistances, railsOnTheBottom } = await imp("lib/geometry/design.ts");
const { computeRailBands } = await imp("lib/geometry/rail-bands.ts");
const { formatInchesFraction } = await imp("lib/geometry/units.ts");
const IN = 25.4;
const dec = (v: number) => `${(v / IN).toFixed(2)}"`;
for (const [name, d, r] of [["Teardrop Nose Concave", 3, 4], ["Blended Nose Concave", 3, 4], ["Slight Single Concave Entry", 3, 4]] as const) {
  const w = build({ board: "longboard", nose: [name, d, r] });
  const anchors = railAnchorStations(w.profile.effectiveFoil, w.fields.outline.length);
  const cards = computeRailBands(railsOnTheBottom(w.rails, bottomRailLift(w.resolved, w.board), anchors), "sixteenths", railStringerDistances(w.geometry, anchors));
  const { bands, pulled } = railBandsPulledToMark(cards, railStartLimiter(w.resolved, w.board), anchors);
  console.log(`${name}, Depth 3/16", Rail Roll 1/4" (Off Rail ${dec(w.resolved.nose.offRail)})`);
  for (const key of ["nose", "center", "tail"] as const) {
    const a = cards[key].result, b = bands[key].result;
    console.log(`  ${key.padEnd(6)} BT1/BT2/BT3 ${dec(a.bottomTuck1)} / ${dec(a.bottomTuck2)} / ${dec(a.bottomTuck3)}  ->  ${dec(b.bottomTuck1)} / ${dec(b.bottomTuck2)} / ${dec(b.bottomTuck3)}${pulled[key] ? "  (pulled)" : ""}`);
  }
}
void formatInchesFraction;

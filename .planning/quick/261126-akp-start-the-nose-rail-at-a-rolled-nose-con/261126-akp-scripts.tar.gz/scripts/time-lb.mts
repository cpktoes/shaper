// Quick 261126-akp (from spike 009's time9.mts, its switch modes dropped): the three rolled app Longboards the stop condition
// names, each built by the checkout at ROOT, written with the app's own .brd writer and opened through the real import
// (brdLookFromBytes), fastest of REPS. Also records what the look fitted, so the figures can be compared too.
//   ROOT=<checkout> REPS=3 npx --no-install tsx --tsconfig <checkout>/tsconfig.json time-lb.mts <label>
import { execSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { build, parseId, imp } from "./board.mts";
const { brdLookFromBytes } = await imp("lib/export/brd-look.ts");
const IDS = ["longboard|Blended Nose Concave|d3|r4", "longboard|Teardrop Nose Concave|d3|r4", "longboard|Slight Single Concave Entry|d2|r2"];
const reps = Number(process.env.REPS ?? 3);
const IN = 25.4;
const sixtyFourths = (v: number) => `${Math.round((v / IN) * 64)}/64"`;
const cutWords = (c: any) => (c.depth > 0 ? `${c.name} ${sixtyFourths(c.depth)}${(c.railRoll ?? 0) > 0 ? `, Rail Roll ${sixtyFourths(c.railRoll)}` : ""}` : c.name);
const items = IDS.map((id) => ({ id, bytes: build(parseId(id)).bytes }));
brdLookFromBytes(items[0].bytes, "x.brd"); // warm up
const rows: any[] = [];
for (const it of items) {
  const load = execSync("uptime").toString().trim().replace(/.*averages: /, "");
  let best = Infinity;
  let r: any = null;
  for (let k = 0; k < reps; k++) {
    const t0 = performance.now();
    r = brdLookFromBytes(it.bytes, "x.brd");
    best = Math.min(best, (performance.now() - t0) / 1000);
  }
  const b = r.ok ? r.look.bottom : null;
  const ra = r.ok ? r.look.rails : null;
  const cuts3 = b ? [b.bottom.nose, b.bottom.center, b.bottom.tail] : [];
  const row = {
    name: it.id,
    load,
    secs: +best.toFixed(2),
    names: cuts3.map((c: any) => c.name),
    cuts: cuts3.map(cutWords),
    widest: b ? +b.closeness.largest.toFixed(3) : null,
    typical: b ? +b.closeness.typical.toFixed(3) : null,
    rails: ra ? [+ra.closeness.largest.toFixed(2), +ra.closeness.typical.toFixed(2)] : null,
  };
  rows.push(row);
  console.log(JSON.stringify(row));
}
const label = process.argv[2] ?? "lb";
mkdirSync(new URL("../out/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../out/lb-${label}.json`, import.meta.url), JSON.stringify(rows, null, 1));

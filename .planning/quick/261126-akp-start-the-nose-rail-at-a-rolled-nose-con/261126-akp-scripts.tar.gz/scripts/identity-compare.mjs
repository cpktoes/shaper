// Quick 261126-akp: compare two identity.mts runs board by board, and print the Longboard litres table (D-03).
//   node identity-compare.mjs <labelBase> <labelAfter>
import { readFileSync } from "node:fs";
const [a, b] = process.argv.slice(2);
const load = (l) => JSON.parse(readFileSync(new URL(`../out/identity-${l}.json`, import.meta.url), "utf8"));
const A = new Map(load(a).map((r) => [r.id, r]));
const B = load(b);
let differ = 0;
let unexpected = 0;
const moved = [];
for (const r of B) {
  const o = A.get(r.id);
  if (!o) { console.log(`${r.id}: not in ${a}`); unexpected++; continue; }
  const same = o.litres === r.litres && o.brd === r.brd && o.surface === r.surface;
  if (same) continue;
  differ++;
  const rolledLong = r.board === "longboard" && r.kind === "roll";
  if (!rolledLong) { unexpected++; console.log(`UNEXPECTED ${r.id}: ${o.litres} -> ${r.litres}`); }
  moved.push({ id: r.id, d: r.litres - o.litres });
}
const rolledLong = B.filter((r) => r.board === "longboard" && r.kind === "roll").length;
console.log(`${B.length} boards compared; ${differ} differ (${moved.length} rolled Longboards of ${rolledLong}); ${unexpected} unexpected; ${B.length - differ} identical`);
const notMoved = B.filter((r) => r.board === "longboard" && r.kind === "roll" && !moved.some((m) => m.id === r.id)).map((r) => r.id);
if (notMoved.length) console.log(`rolled Longboards NOT moved: ${notMoved.join(", ")}`);
// The Longboard litres table, Depth 3/16" (d3): today and now at each roll.
const ROLLS = [["0", "0"], ["1/64\"", "0.25"], ["1/32\"", "0.5"], ["3/64\"", "0.75"], ["1/16\"", "1"], ["1/8\"", "2"], ["1/4\"", "4"]];
for (const name of ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"]) {
  console.log(`\n${name}, Depth 3/16" — roll: today -> now (change)`);
  for (const [words, r] of ROLLS) {
    const id = `longboard|${name}|d3|r${r}`;
    const o = A.get(id), n = B.find((x) => x.id === id);
    console.log(`  ${words.padEnd(6)} ${o.litres.toFixed(2)} -> ${n.litres.toFixed(2)} L (${(n.litres - o.litres >= 0 ? "+" : "") + (n.litres - o.litres).toFixed(2)})`);
  }
}
process.exit(unexpected ? 1 : 0);

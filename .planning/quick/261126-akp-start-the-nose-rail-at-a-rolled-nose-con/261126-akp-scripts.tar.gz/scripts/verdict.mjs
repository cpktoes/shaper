// Quick 261126-akp: the stop condition, judged. From paired rounds (base1 after1 base2 after2 ...): measure.mts's twelve-file
// outputs (../out/<label>.json) and time-lb.mts's three Longboards (../out/lb-<label>.json), with each run's `uptime`
// (../out/load-<label>.txt).
//
// WORSE: any of the four figures (widest and typical bottom miss, widest and typical rails miss, mm, rounded to 0.01 as the
// preview shows them) higher than today's, or any of the three cut names different. SLOW: the fastest-of-three open time more
// than 2.5 s above today's in the same paired round, judged on the quietest round (the lowest one-minute load of its two runs).
// Rounds whose load is over 8 are reported but never used for the judgement when a quieter one exists.
// Ends with PASS (exit 0) or STOP (exit 1).
//   node verdict.mjs base1 after1 base2 after2 [base3 after3 ...]
import { existsSync, readFileSync } from "node:fs";
const OUT = new URL("../out/", import.meta.url);
const labels = process.argv.slice(2);
if (labels.length < 2 || labels.length % 2) throw new Error("usage: node verdict.mjs base1 after1 [base2 after2 ...]");
const read = (name) => JSON.parse(readFileSync(new URL(name, OUT), "utf8"));
const loadOf = (label) => {
  const f = new URL(`load-${label}.txt`, OUT);
  if (!existsSync(f)) return NaN;
  const m = readFileSync(f, "utf8").match(/averages?:\s*([\d.]+)/);
  return m ? Number(m[1]) : NaN;
};
const rounds = [];
for (let i = 0; i < labels.length; i += 2) {
  const [base, after] = [labels[i], labels[i + 1]];
  const load = Math.max(loadOf(base), loadOf(after));
  rounds.push({
    base,
    after,
    load,
    files: { base: read(`${base}.json`), after: read(`${after}.json`) },
    lbs: { base: existsSync(new URL(`lb-${base}.json`, OUT)) ? read(`lb-${base}.json`) : [], after: existsSync(new URL(`lb-${after}.json`, OUT)) ? read(`lb-${after}.json`) : [] },
  });
}
for (const r of rounds) console.log(`round ${r.base} / ${r.after}: one-minute load ${r.load}`);
const usable = rounds.filter((r) => !(r.load > 8));
const judged = (usable.length ? usable : rounds).reduce((q, r) => (r.load < q.load ? r : q));
console.log(`open times judged on ${judged.base} / ${judged.after} (load ${judged.load})\n`);

const r2 = (v) => (v === null || v === undefined ? null : Math.round(v * 100) / 100);
const fig = (row) => [r2(row.widest), r2(row.typical), r2(row.rails?.[0]), r2(row.rails?.[1])];
const fmt = (f) => f.map((v) => (v === null ? "—" : v.toFixed(2))).join(" / ");
let stop = false;
const judge = (name, keyOf, list) => {
  const base = judged[list].base.find((x) => keyOf(x) === name);
  const after = judged[list].after.find((x) => keyOf(x) === name);
  if (!base || !after) { console.log(`${name}: MISSING`); stop = true; return; }
  // Figures and names from the first round (they never move between rounds: same.mjs checks that).
  const b0 = rounds[0][list].base.find((x) => keyOf(x) === name);
  const a0 = rounds[0][list].after.find((x) => keyOf(x) === name);
  const fb = fig(b0), fa = fig(a0);
  const worse = fa.some((v, k) => v !== null && fb[k] !== null && v > fb[k]) || JSON.stringify(b0.names) !== JSON.stringify(a0.names);
  const dt = after.secs - base.secs;
  const slow = dt > 2.5;
  const all = rounds.map((r) => {
    const b = r[list].base.find((x) => keyOf(x) === name), a = r[list].after.find((x) => keyOf(x) === name);
    return b && a ? `${b.secs.toFixed(2)}→${a.secs.toFixed(2)}` : "—";
  }).join(", ");
  const flags = [worse ? "WORSE" : "", slow ? "SLOW" : ""].filter(Boolean).join(" ") || "ok";
  if (worse || slow) stop = true;
  console.log(`${name}\n  figures (bottom widest / typical, rails widest / typical, mm) ${fmt(fb)} -> ${fmt(fa)}\n  cuts  ${b0.cuts.join(" · ")}\n     -> ${a0.cuts.join(" · ")}\n  open ${base.secs.toFixed(2)} -> ${after.secs.toFixed(2)} s (${dt >= 0 ? "+" : ""}${dt.toFixed(2)} s; every round ${all})  ${flags}`);
};
for (const row of rounds[0].files.base) judge(row.file, (x) => x.file, "files");
console.log("");
for (const row of rounds[0].lbs.base) judge(row.name, (x) => x.name, "lbs");
console.log(`\n${stop ? "STOP" : "PASS"}`);
process.exit(stop ? 1 : 0);

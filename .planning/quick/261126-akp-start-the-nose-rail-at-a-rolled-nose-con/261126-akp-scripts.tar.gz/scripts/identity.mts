// Quick 261126-akp (from spike 009's litres.mts, the rules loop dropped): every case board built by the checkout at ROOT —
// litres, and digests of the .brd bytes and of every section (the whole of boardSections and the station areas). Run once
// with ROOT at the BASE checkout and once at the worktree, then compare with identity-compare.mjs.
//   ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json identity.mts <label>
import { createHash } from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import { build, imp } from "./board.mts";
const { computeCrossSectionVolume, boardSections } = await imp("lib/geometry/volume.ts");
const BOARDS = ["shortboard", "midlength", "fish", "longboard"];
const NOSES = ["Teardrop Nose Concave", "Blended Nose Concave", "Slight Single Concave Entry"];
const cases: any[] = [];
for (const board of BOARDS) {
  cases.push({ id: `${board}|none`, kind: "plain", board });
  for (const name of NOSES) for (const d of [1, 2, 3, 4]) for (const r of [0, 1, 2, 3, 4]) cases.push({ id: `${board}|${name}|d${d}|r${r}`, kind: r ? "roll" : "noroll", board, nose: [name, d, r] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|RBE|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0] });
  for (const d of [1, 2, 3, 4]) cases.push({ id: `${board}|CB|d${d}`, kind: "belly", board, center: ["Continuous Belly / Rolled Mid", d] });
  for (const d of [2, 4]) cases.push({ id: `${board}|RBE+CB|d${d}`, kind: "belly", board, nose: ["Rolled Belly Entry", d, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|RVN|d2`, kind: "belly", board, nose: ["Reverse Vee Nose", 2, 0] });
  for (const d of [2, 4]) cases.push({ id: `${board}|BNC2+CB|d${d}`, kind: "belly", board, nose: ["Blended Nose Concave", 2, 0], center: ["Continuous Belly / Rolled Mid", d] });
  cases.push({ id: `${board}|TPH|d4`, kind: "belly", board, center: ["Tri-Plane Hull Center", 4] });
}
// The small rolls on the Longboard (sixteenths: 1/64" = 0.25, 1/32" = 0.5, 3/64" = 0.75), Depth 3/16", for the ease-in (D-03).
for (const name of NOSES) for (const r of [0.25, 0.5, 0.75]) cases.push({ id: `longboard|${name}|d3|r${r}`, kind: "roll", board: "longboard", nose: [name, 3, r] });
const h = (x: any) => createHash("sha1").update(typeof x === "string" ? x : JSON.stringify(x)).digest("hex").slice(0, 16);
const rows: any[] = [];
for (const c of cases) {
  const w = build(c);
  const vol = computeCrossSectionVolume(w.input);
  rows.push({
    id: c.id,
    kind: c.kind,
    board: c.board,
    litres: +vol.volumeLitres,
    brd: h(Buffer.from(w.bytes).toString("latin1")),
    surface: h({ sections: boardSections(w.input), areas: vol.stationAreas }),
  });
}
const label = process.argv[2] ?? "identity";
mkdirSync(new URL("../out/", import.meta.url), { recursive: true });
writeFileSync(new URL(`../out/identity-${label}.json`, import.meta.url), JSON.stringify(rows, null, 1));
console.log(`${rows.length} boards written to identity-${label}.json`);

Quick 261126-czw (four code-review points on the Rail Roll): the after-runs of the .brd measurement.
Packed by the executor 2026-11-26. No .brd file is in here: the founder's twelve sample files were read where they are, in
~/Downloads, and never copied.

scripts/   v2f's measuring scripts, unchanged (see 261125-v2f-scripts.tar.gz's README.txt for what each does and how to call it).

The "before" is v2f's own archived after-run: lib/ is byte-for-byte the same between v2f's 7707ee85 and this task's base
f6349c90 (git diff --quiet 7707ee85 f6349c90 -- lib exits 0), so v2f's t12-after.json and grid-after.*.jsonl are what the
untouched code gives. Both after-runs were taken on the worktree with Task 1 (the Depth-0 roll) and Task 2 (the tie for a
belly only, one measurement fewer) in place, before Task 3 touched lib/models.

out/
  czw-t12-after.json                     the twelve files through the real import, one open each ("12 files", no "!!" line).
  same-t12-after-czw-t12-after.txt       same.mjs t12-after czw-t12-after: 12 files compared, 0 differ.
  czw-grid-after.0..5.jsonl / .log       the 296-board round trip, six shards (run 0..3 then 3..6).
  same-grid-after-czw-grid-after.txt     same.mjs grid-after czw-grid-after: 296 boards compared, 0 differ.
  analyze-grid-after-czw-grid-after.txt  analyze.mjs grid-after czw-grid-after: every score equal (158/192, 145, 138, 144,
                                         0.67 / 0.09 mm, invented rolls 4/48, false concaves 0/48); only the timings move.

// Print evidence: an inline currentColor SVG versus a CSS mask drawn with background-color, printed
// by Chromium with "background graphics" OFF (page.pdf's printBackground: false, the dialog's
// default). Also screenshots the same page in Chromium and WebKit.
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const { chromium, webkit } = require("playwright");
const sharp = require("sharp");

const OUT = path.resolve(process.argv[2]);
const svg = fs.readFileSync(path.join(OUT, "wordmark.svg"), "utf8");
const pathD = svg.match(/ d="([^"]+)"/)[1];
const VB = svg.match(/viewBox="([^"]+)"/)[1];
// a white-ink mask file for the CSS-mask candidate
fs.writeFileSync(path.join(OUT, "mask.svg"), svg.replace("<path ", '<path fill="#000" '));
const html = `<html><head><style>
body{margin:20px;font:14px sans-serif;color:#1f2a3b}
.box{display:flex;align-items:center;gap:16px;margin:10px 0;height:40px}
.mask{width:300px;height:37.2px;background-color:currentColor;-webkit-mask-image:url(mask.svg);mask-image:url(mask.svg);-webkit-mask-size:100% 100%;mask-size:100% 100%;mask-repeat:no-repeat;-webkit-mask-repeat:no-repeat}
.exact{-webkit-print-color-adjust:exact;print-color-adjust:exact}
</style></head><body>
<div class="box"><span style="width:200px">A inline SVG</span><svg viewBox="${VB}" style="width:300px;height:auto;fill:currentColor"><path fill-rule="evenodd" d="${pathD}"/></svg></div>
<div class="box"><span style="width:200px">B CSS mask</span><span class="mask"></span></div>
<div class="box"><span style="width:200px">C CSS mask + exact</span><span class="mask exact"></span></div>
</body></html>`;
fs.writeFileSync(path.join(OUT, "printtest.html"), html);
const url = "file://" + path.join(OUT, "printtest.html");
for (const [name, bt] of [["chromium", chromium], ["webkit", webkit]]) {
  const b = await bt.launch();
  const p = await b.newPage({ viewport: { width: 600, height: 200 }, deviceScaleFactor: 2 });
  await p.goto(url);
  await p.waitForTimeout(300);
  await p.screenshot({ path: path.join(OUT, `printtest-screen-${name}.png`) });
  if (name === "chromium") {
    await p.emulateMedia({ media: "print" });
    await p.pdf({ path: path.join(OUT, "printtest-nobg.pdf"), printBackground: false, width: "7in", height: "2in" });
  }
  await b.close();
}
console.log("ok");

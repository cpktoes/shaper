// Render each traced SVG at the source's own pixel scale in headless Chromium and compare it
// with the levels-cleaned source crop. Run: node fidelity.mjs <src.jpg> <svg>...
import { createRequire } from "node:module";
import fs from "node:fs";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const sharp = require("sharp");
const { chromium } = require("playwright");

const [src, ...svgs] = process.argv.slice(2);
const X0 = 87, Y0 = 182, CW = 1854, CH = 230;
const { data } = await sharp(src).greyscale().extract({ left: X0, top: Y0, width: CW, height: CH }).raw().toBuffer({ resolveWithObject: true });
const srcInk = new Uint8Array(CW * CH);
for (let i = 0; i < CW * CH; i++) { let v = data[i]; v = v <= 40 ? 0 : v >= 225 ? 255 : ((v - 40) / 185) * 255; srcInk[i] = 255 - v; }

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: CW, height: CH }, deviceScaleFactor: 1 });
for (const s of svgs) {
  const body = fs.readFileSync(s, "utf8").replace("<svg ", `<svg width="${CW}" height="${CH}" preserveAspectRatio="none" style="display:block" `);
  await page.setContent(`<html><body style="margin:0;background:#fff">${body}</body></html>`);
  const png = await page.screenshot({ clip: { x: 0, y: 0, width: CW, height: CH } });
  const { data: r } = await sharp(png).greyscale().raw().toBuffer({ resolveWithObject: true });
  let diffSum = 0, flips = 0, far = 0;
  const th = (a) => a > 128;
  const rin = new Uint8Array(CW * CH);
  for (let i = 0; i < CW * CH; i++) { rin[i] = 255 - r[i]; diffSum += Math.abs(rin[i] - srcInk[i]); }
  // a flip is a pixel whose thresholded value differs; "far" = a flip with no agreeing pixel within 1px
  for (let y = 1; y < CH - 1; y++) for (let x = 1; x < CW - 1; x++) {
    const i = y * CW + x;
    if (th(rin[i]) !== th(srcInk[i])) {
      flips++;
      let ok = false;
      for (let dy = -1; dy <= 1 && !ok; dy++) for (let dx = -1; dx <= 1 && !ok; dx++) if (th(srcInk[i + dy * CW + dx]) === th(rin[i])) ok = true;
      if (!ok) far++;
    }
  }
  console.log(JSON.stringify({ svg: s.split("/").pop(), bytes: fs.statSync(s).size, meanAbsDiff: +(diffSum / (CW * CH)).toFixed(3), flips, farFlips: far }));
}
await browser.close();

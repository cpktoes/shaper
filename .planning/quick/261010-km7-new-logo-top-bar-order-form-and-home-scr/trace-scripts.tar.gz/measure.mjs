// Measure today's SHAPER ASSISTANT text widths in Inter (the app's own woff2) and render a
// side-by-side picture of today's text and the traced logo in the four themes' own ink.
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const { chromium, webkit } = require("playwright");

const OUT = path.resolve(process.argv[2]);
const svg = fs.readFileSync(path.join(OUT, "wordmark.svg"), "utf8");
const pathD = svg.match(/ d="([^"]+)"/)[1];
const VB = svg.match(/viewBox="([^"]+)"/)[1];
const ASPECT = Number(VB.split(" ")[2]) / Number(VB.split(" ")[3]);

const logo = (w, extra = "") => `<svg viewBox="${VB}" style="display:block;width:${w}px;height:auto;fill:currentColor;${extra}" role="img" aria-label="Shaper Assistant"><path fill-rule="evenodd" d="${pathD}"/></svg>`;
const themes = [
  ["Daylight", "#ffffff", "#1f2a3b"],
  ["Chalk", "#ffffff", "#1f2a3b"],
  ["Slate", "#12141a", "#f2f4f7"],
  ["Phosphor", "#050805", "#26d026"],
];
const css = `@font-face{font-family:Inter;font-weight:100 900;src:url(inter.woff2) format("woff2")}
body{margin:0;font-family:Inter,sans-serif}
.m{font-weight:800;letter-spacing:.15em;white-space:nowrap;display:inline-block}
.row{display:flex;align-items:center;justify-content:space-between;height:48px;padding:0 16px;width:328px;box-sizing:content-box}
.drow{display:flex;align-items:center;gap:40px;height:32px;padding:24px;width:520px}
.btn{height:44px;min-width:80px;border:1px solid currentColor;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700}
.lab{font:600 11px Inter;opacity:.7;width:90px}`;
const measureHtml = `<html><head><style>${css}</style></head><body>
<span id="xs" class="m" style="font-size:12px">SHAPER ASSISTANT</span><br>
<span id="sm" class="m" style="font-size:14px">SHAPER ASSISTANT</span><br>
<span id="smA" class="m" style="font-size:14px">ASSISTANT</span><br>
<span id="smS" class="m" style="font-size:14px">SHAPER</span><br>
<span id="of" class="m" style="font-size:20.5px">SHAPER ASSISTANT</span><br>
<span id="ofA" class="m" style="font-size:20.5px">ASSISTANT</span><br>
<span id="ofS" class="m" style="font-size:24.6px">ASSISTANT</span><br>
</body></html>`;
fs.writeFileSync(path.join(OUT, "measure.html"), measureHtml);

const results = {};
for (const [name, bt] of [["chromium", chromium], ["webkit", webkit]]) {
  const b = await bt.launch();
  const p = await b.newPage();
  await p.goto("file://" + path.join(OUT, "measure.html"));
  await p.evaluate(() => document.fonts.ready);
  results[name] = await p.evaluate(() => Object.fromEntries([...document.querySelectorAll("span")].map((s) => [s.id, +s.getBoundingClientRect().width.toFixed(1)])));
  await b.close();
}
console.log(JSON.stringify(results));
const xs = results.chromium.xs, sm = results.chromium.sm;
console.log(JSON.stringify({ aspect: +ASPECT.toFixed(4), phoneLogoH: +(xs / ASPECT).toFixed(1), desktopLogoH: +(sm / ASPECT).toFixed(1), narrowDesktopLogoW: results.chromium.smA, narrowDesktopLogoH: +(results.chromium.smA / ASPECT).toFixed(1) }));

// The picture: per theme, a phone bar (today vs logo) and a desktop-size mark (today vs logo).
let pic = `<html><head><style>${css}</style></head><body style="background:#888;padding:12px;display:grid;grid-template-columns:auto auto;gap:12px">`;
for (const [n, ground, ink] of themes) {
  for (const which of ["today", "logo"]) {
    pic += `<div style="background:${ground};color:${ink};border:1px solid #0003">
      <div style="font:600 11px Inter;padding:6px 16px 0;opacity:.7">${n} — ${which === "today" ? "today" : "new logo"} (phone bar, 360 wide)</div>
      <div class="row">${which === "today" ? `<span class="m" style="font-size:12px">SHAPER ASSISTANT</span>` : logo(xs)}<div class="btn">Saved</div></div>
      <div style="font:600 11px Inter;padding:0 24px;opacity:.7">${which === "today" ? "today" : "new logo"} (computer row)</div>
      <div class="drow">${which === "today" ? `<span class="m" style="font-size:14px">SHAPER ASSISTANT</span>` : logo(sm)}<span style="font:700 12px Inter;letter-spacing:.15em">TEMPLATE&nbsp;&nbsp;ROCKER&nbsp;&nbsp;RAILS</span></div>
    </div>`;
  }
}
pic += `</body></html>`;
fs.writeFileSync(path.join(OUT, "compare.html"), pic);
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1200, height: 900 }, deviceScaleFactor: 2 });
await p.goto("file://" + path.join(OUT, "compare.html"));
await p.evaluate(() => document.fonts.ready);
await p.screenshot({ path: path.join(OUT, "compare-themes.png"), fullPage: true });
await b.close();

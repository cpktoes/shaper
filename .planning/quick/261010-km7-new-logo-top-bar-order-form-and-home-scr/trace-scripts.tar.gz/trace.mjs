// Scratch tracer: wordmark JPEG -> single-colour SVG path (marching squares + corner-aware
// Schneider cubic fitting). Run: node trace.mjs <src.jpg> <out.svg> [tolPx]
import { createRequire } from "node:module";
import fs from "node:fs";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const sharp = require("sharp");

const [src, out, tolArg, padArg, decArg] = process.argv.slice(2);
const DEC = Number(decArg ?? 2), Q = 10 ** DEC;
const rq = (v) => Math.round(v * Q) / Q;
const TOL = Number(tolArg ?? 0.6); // max fitting error, source px
const PAD = Number(padArg ?? 0);

const img = sharp(src).greyscale();
const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
const W = info.width, H = info.height;
// levels: 0 below 40, 255 above 225, linear between; then ink = 255 - v (ink high)
const ink = new Float32Array(W * H);
for (let i = 0; i < W * H; i++) {
  let v = data[i];
  v = v <= 40 ? 0 : v >= 225 ? 255 : ((v - 40) / 185) * 255;
  ink[i] = 255 - v;
}
// bbox of ink > 128
let x0 = W, y0 = H, x1 = 0, y1 = 0;
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (ink[y * W + x] > 128) {
  if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
}
const g = (x, y) => (x < 0 || y < 0 || x >= W || y >= H ? 0 : ink[y * W + x]);
const ISO = 128;
// marching squares over cells (x,y)-(x+1,y+1), from x0-2..x1+2
const segs = new Map(); // key start point -> end point (oriented so ink on the left)
const key = (p) => `${p[0].toFixed(4)},${p[1].toFixed(4)}`;
const edges = [];
function interp(xa, ya, va, xb, yb, vb) {
  const t = (ISO - va) / (vb - va);
  return [xa + t * (xb - xa), ya + t * (yb - ya)];
}
for (let y = y0 - 2; y <= y1 + 1; y++) for (let x = x0 - 2; x <= x1 + 1; x++) {
  const a = g(x, y), b = g(x + 1, y), c = g(x + 1, y + 1), d = g(x, y + 1); // tl tr br bl
  let idx = 0;
  if (a > ISO) idx |= 8; if (b > ISO) idx |= 4; if (c > ISO) idx |= 2; if (d > ISO) idx |= 1;
  if (idx === 0 || idx === 15) continue;
  const T = () => interp(x, y, a, x + 1, y, b);
  const R = () => interp(x + 1, y, b, x + 1, y + 1, c);
  const B = () => interp(x, y + 1, d, x + 1, y + 1, c);
  const L = () => interp(x, y, a, x, y + 1, d);
  // segments oriented with ink on the right-hand side when walking (consistent orientation)
  const add = (p, q) => edges.push([p, q]);
  switch (idx) {
    case 1: add(L(), B()); break;
    case 2: add(B(), R()); break;
    case 3: add(L(), R()); break;
    case 4: add(R(), T()); break;
    case 5: { const ctr = (a + b + c + d) / 4; if (ctr > ISO) { add(L(), T()); add(R(), B()); } else { add(L(), B()); add(R(), T()); } break; }
    case 6: add(B(), T()); break;
    case 7: add(L(), T()); break;
    case 8: add(T(), L()); break;
    case 9: add(T(), B()); break;
    case 10: { const ctr = (a + b + c + d) / 4; if (ctr > ISO) { add(T(), R()); add(B(), L()); } else { add(T(), L()); add(B(), R()); } break; }
    case 11: add(T(), R()); break;
    case 12: add(R(), L()); break;
    case 13: add(R(), B()); break;
    case 14: add(B(), L()); break;
  }
}
for (const [p, q] of edges) segs.set(key(p), q);
// assemble loops
const loops = [];
const used = new Set();
for (const [p] of edges) {
  const k0 = key(p);
  if (used.has(k0)) continue;
  const loop = [p];
  let k = k0;
  used.add(k);
  for (;;) {
    const q = segs.get(k);
    if (!q) break;
    const kq = key(q);
    if (kq === k0) break;
    if (used.has(kq)) break;
    used.add(kq);
    loop.push(q);
    k = kq;
  }
  if (loop.length > 8) loops.push(loop);
}

// ---- Schneider curve fitting -------------------------------------------------------------
const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
const addv = (a, b) => [a[0] + b[0], a[1] + b[1]];
const mul = (a, s) => [a[0] * s, a[1] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
const len = (a) => Math.hypot(a[0], a[1]);
const norm = (a) => { const l = len(a) || 1; return [a[0] / l, a[1] / l]; };
const bez = (c, t) => { const u = 1 - t; return addv(addv(mul(c[0], u * u * u), mul(c[1], 3 * u * u * t)), addv(mul(c[2], 3 * u * t * t), mul(c[3], t * t * t))); };
const bezD = (c, t) => { const u = 1 - t; return addv(addv(mul(sub(c[1], c[0]), 3 * u * u), mul(sub(c[2], c[1]), 6 * u * t)), mul(sub(c[3], c[2]), 3 * t * t)); };
const bezDD = (c, t) => { const u = 1 - t; return addv(mul(addv(sub(c[2], mul(c[1], 2)), c[0]), 6 * u), mul(addv(sub(c[3], mul(c[2], 2)), c[1]), 6 * t)); };
function chordParam(pts) { const u = [0]; for (let i = 1; i < pts.length; i++) u.push(u[i - 1] + len(sub(pts[i], pts[i - 1]))); const L = u[u.length - 1] || 1; return u.map((v) => v / L); }
function genBez(pts, u, t1, t2) {
  const p0 = pts[0], p3 = pts[pts.length - 1];
  let C00 = 0, C01 = 0, C11 = 0, X0 = 0, X1 = 0;
  for (let i = 0; i < pts.length; i++) {
    const t = u[i], s = 1 - t;
    const A1 = mul(t1, 3 * s * s * t), A2 = mul(t2, 3 * s * t * t);
    C00 += dot(A1, A1); C01 += dot(A1, A2); C11 += dot(A2, A2);
    const tmp = sub(pts[i], bez([p0, p0, p3, p3], t));
    X0 += dot(A1, tmp); X1 += dot(A2, tmp);
  }
  const det = C00 * C11 - C01 * C01;
  let a1 = det === 0 ? 0 : (X0 * C11 - X1 * C01) / det;
  let a2 = det === 0 ? 0 : (C00 * X1 - C01 * X0) / det;
  const segL = len(sub(p3, p0)), eps = 1e-6 * segL;
  if (a1 < eps || a2 < eps) { a1 = a2 = segL / 3; }
  return [p0, addv(p0, mul(t1, a1)), addv(p3, mul(t2, a2)), p3];
}
function maxErr(pts, c, u) { let m = 0, at = Math.floor(pts.length / 2); for (let i = 1; i < pts.length - 1; i++) { const d = len(sub(bez(c, u[i]), pts[i])); if (d > m) { m = d; at = i; } } return [m, at]; }
function reparam(c, pts, u) { return u.map((t, i) => { const d = sub(bez(c, t), pts[i]); const d1 = bezD(c, t), d2 = bezDD(c, t); const num = dot(d, d1), den = dot(d1, d1) + dot(d, d2); return den === 0 ? t : Math.min(1, Math.max(0, t - num / den)); }); }
function fitCubic(pts, t1, t2, err, outArr) {
  if (pts.length === 2) { const d = len(sub(pts[1], pts[0])) / 3; outArr.push([pts[0], addv(pts[0], mul(t1, d)), addv(pts[1], mul(t2, d)), pts[1]]); return; }
  let u = chordParam(pts);
  let c = genBez(pts, u, t1, t2);
  let [e, split] = maxErr(pts, c, u);
  if (e < err) { outArr.push(c); return; }
  if (e < err * 4) { for (let k = 0; k < 20; k++) { u = reparam(c, pts, u); c = genBez(pts, u, t1, t2); [e, split] = maxErr(pts, c, u); if (e < err) { outArr.push(c); return; } } }
  if (split < 1) split = 1; if (split > pts.length - 2) split = pts.length - 2;
  const tc = norm(sub(pts[split - 1], pts[split + 1]));
  fitCubic(pts.slice(0, split + 1), t1, tc, err, outArr);
  fitCubic(pts.slice(split), mul(tc, -1), t2, err, outArr);
}
function tangentAt(pts, i, dir, span = 4) {
  // dir +1: forward tangent from pts[i]; -1: backward
  const j = Math.max(0, Math.min(pts.length - 1, i + dir * span));
  return norm(sub(pts[j], pts[i]));
}

// corner detection on the closed loop
function corners(loop) {
  const n = loop.length, k = 5, idx = [];
  const ang = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const a = loop[(i - k + n) % n], b = loop[i], c = loop[(i + k) % n];
    const v1 = norm(sub(a, b)), v2 = norm(sub(c, b));
    ang[i] = Math.acos(Math.max(-1, Math.min(1, dot(v1, v2)))); // pi = straight
  }
  for (let i = 0; i < n; i++) {
    if (ang[i] < (Math.PI * 140) / 180) {
      let isMin = true;
      for (let d = -k; d <= k; d++) if (d && ang[(i + d + n) % n] < ang[i]) { isMin = false; break; }
      if (isMin && (idx.length === 0 || i - idx[idx.length - 1] > k)) idx.push(i);
    }
  }
  return idx;
}

const ox = x0 - PAD, oy = y0 - PAD;
const vbW = x1 - x0 + 1 + 2 * PAD, vbH = y1 - y0 + 1 + 2 * PAD;
// target viewBox: scale so height = 100 units
const S = 100 / vbH;
const P = (p) => [((p[0] + 0.5 - ox) * S), ((p[1] + 0.5 - oy) * S)];
const f = (v) => { const r = rq(v); return (Object.is(r, -0) ? 0 : r).toString().replace(/^0\./, ".").replace(/^-0\./, "-."); };
let d = "";
let nCurves = 0;
for (const loop0 of loops) {
  // resample: drop near-duplicate points
  const loop = [];
  for (const p of loop0) if (!loop.length || len(sub(p, loop[loop.length - 1])) > 0.05) loop.push(p);
  const cs = corners(loop);
  const n = loop.length;
  const starts = cs.length ? cs : [0];
  const curves = [];
  for (let s = 0; s < starts.length; s++) {
    const a = starts[s], b = starts[(s + 1) % starts.length];
    const run = [];
    let i = a;
    do { run.push(loop[i]); i = (i + 1) % n; } while (i !== b);
    run.push(loop[b]);
    if (starts.length === 1 && run.length < 3) continue;
    const t1 = tangentAt(run, 0, 1), t2 = tangentAt(run, run.length - 1, -1);
    fitCubic(run, t1, t2, TOL, curves);
  }
  nCurves += curves.length;
  // emit with relative coords
  let cur = P(curves[0][0]).map(rq);
  d += `M${f(cur[0])} ${f(cur[1])}`;
  for (const c of curves) {
    const p1 = P(c[1]), p2 = P(c[2]), p3 = P(c[3]);
    // straight-ish? emit l
    const chord = sub(p3, cur);
    const lc = len(chord) || 1;
    const dev = Math.max(Math.abs((p1[0] - cur[0]) * chord[1] - (p1[1] - cur[1]) * chord[0]) / lc, Math.abs((p2[0] - cur[0]) * chord[1] - (p2[1] - cur[1]) * chord[0]) / lc);
    if (dev < 0.02) d += `l${f(p3[0] - cur[0])} ${f(p3[1] - cur[1])}`;
    else d += `c${f(p1[0] - cur[0])} ${f(p1[1] - cur[1])} ${f(p2[0] - cur[0])} ${f(p2[1] - cur[1])} ${f(p3[0] - cur[0])} ${f(p3[1] - cur[1])}`;
    cur = [rq(cur[0] + rq(p3[0] - cur[0])), rq(cur[1] + rq(p3[1] - cur[1]))];
  }
  d += "z";
}
d = d.replace(/ -/g, "-");
const vw = rq(vbW * S);
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${vw} 100"><path fill-rule="evenodd" d="${d}"/></svg>\n`;
fs.writeFileSync(out, svg);
console.log(JSON.stringify({ bbox: [x0, y0, x1, y1], crop: [vbW, vbH], aspect: vbW / vbH, viewBox: [vw, 100], loops: loops.length, curves: nCurves, bytes: svg.length }));

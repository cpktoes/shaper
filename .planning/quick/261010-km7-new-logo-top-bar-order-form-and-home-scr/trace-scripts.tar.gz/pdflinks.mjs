// Plan-time check: does Chromium's page.pdf keep <a href> as link annotations, readable from the raw bytes?
import { createRequire } from "node:module"; import fs from "node:fs"; import path from "node:path";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const { chromium } = require("playwright");
const OUT = path.resolve(process.argv[2]);
const b = await chromium.launch(); const p = await b.newPage();
await p.setContent(`<html><head><style>.s{height:9in;break-after:page;display:flex;align-items:flex-end}a{color:inherit;text-decoration:none}</style></head><body>
${[1,2,3].map(n=>`<div class="s"><span><a href="https://www.ShaperAssistant.com">www.ShaperAssistant.com</a> · Page ${n} of 3</span></div>`).join("")}</body></html>`);
const pdf = await p.pdf({ format: "Letter", printBackground: false });
fs.writeFileSync(path.join(OUT, "pdflinks.pdf"), pdf);
const raw = pdf.toString("latin1");
console.log("URI strings in raw bytes:", [...raw.matchAll(/\/URI\s*\(([^)]*)\)/g)].map(m=>m[1]));
console.log("pages:", (raw.match(/\/Type\s*\/Page\b/g)||[]).length, "annots arrays:", (raw.match(/\/Annots\s*\[/g)||[]).length);
await b.close();

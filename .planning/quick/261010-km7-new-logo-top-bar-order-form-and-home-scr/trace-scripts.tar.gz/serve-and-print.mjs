import http from "node:http"; import fs from "node:fs"; import path from "node:path";
import { createRequire } from "node:module";
const require = createRequire("/Users/kontoes/Code/shaper/package.json");
const { chromium, webkit } = require("playwright");
const OUT = path.resolve(process.argv[2]);
const types = { ".html": "text/html", ".svg": "image/svg+xml", ".woff2": "font/woff2", ".png": "image/png" };
const srv = http.createServer((q, r) => { const f = path.join(OUT, decodeURIComponent(q.url.split("?")[0])); if (!f.startsWith(OUT) || !fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { "content-type": types[path.extname(f)] || "application/octet-stream" }); fs.createReadStream(f).pipe(r); });
await new Promise((ok) => srv.listen(3197, "127.0.0.1", ok));
const url = "http://127.0.0.1:3197/printtest.html";
for (const [name, bt] of [["chromium", chromium], ["webkit", webkit]]) {
  const b = await bt.launch(); const p = await b.newPage({ viewport: { width: 600, height: 200 }, deviceScaleFactor: 2 });
  await p.goto(url); await p.waitForTimeout(500);
  await p.screenshot({ path: path.join(OUT, `printtest-screen-${name}.png`) });
  if (name === "chromium") { await p.emulateMedia({ media: "print" }); await p.pdf({ path: path.join(OUT, "printtest-nobg.pdf"), printBackground: false, width: "7in", height: "2in" }); }
  await b.close();
}
srv.close(); console.log("ok");

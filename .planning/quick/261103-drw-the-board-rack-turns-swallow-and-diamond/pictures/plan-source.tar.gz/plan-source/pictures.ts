// Plan pictures: today's turn (ink) against the one-rule turn (magenta), at the hover rack's own scale.
// Scratch only. Run: npx tsx scratch-drw/pictures.ts <outdir>
import { writeFileSync } from "node:fs";
import { chromium } from "playwright";
import { presetDesignFields } from "../lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "../lib/geometry/board";
import { LIVE_DESIGN_RULES, designSideProfile } from "../lib/geometry/design";
import { buildOutline } from "../lib/geometry/outline";
import { BOARD_PRESETS } from "../lib/geometry/presets";
import * as NEW from "../lib/geometry/rack-art";
import * as TODAY from "../lib/geometry/rack-art-today";
import { rackScale } from "../lib/geometry/rack-layout";
import { polylinePath } from "../lib/geometry/screen-tiles";

const out = process.argv[2];
const P = Object.fromEntries(BOARD_PRESETS.map((p) => [p.id, p]));
const ANGLES = [0, 30, 60, 85, 89, 90];
const SCALE = rackScale(380, 0); // a quiver up to 7'0": the hover rack's largest scale
const CLOSE = 3; // the tail close-up's magnification over the rack's scale
const CLOSE_MM = 130; // how much of the tail the close-up shows
const INK = "#1d1d1f";
const NEWC = "#d0007a";

function board(fields: any) {
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  return { today: TODAY.buildRackBoardArt(profile, geometry), now: NEW.buildRackBoardArt(profile, geometry) };
}

function withTail(id: string, kind: "diamond") {
  const f = presetDesignFields(P[id]);
  const tp = TAIL_PRESETS[kind];
  return { ...f, outline: { ...f.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness } };
}

type Pt = { station: number; x: number };
const path = (pts: Pt[], scale: number, cx: number, floor: number, closed: boolean) =>
  polylinePath(pts.map((p) => ({ x: cx + p.x * scale, y: floor - p.station * scale })), closed);

function sheet(title: string, sub: string, b: ReturnType<typeof board>) {
  const colW = 200;
  const fullH = b.now.length * SCALE + 30;
  const closeH = CLOSE_MM * SCALE * CLOSE + 30;
  const W = colW * ANGLES.length + 40;
  let svg = "";
  ANGLES.forEach((d, i) => {
    const th = (d * Math.PI) / 180;
    const cx = 20 + colW * i + colW / 2;
    const floor = 60 + fullH - 10;
    const tp = TODAY.turnedBoardPoints(b.today, th);
    const np = NEW.turnedBoardPoints(b.now, th);
    const ts = TODAY.stringerPoints(b.today, th);
    const ns = NEW.stringerPoints(b.now, th);
    const op = Math.sin(th).toFixed(3);
    svg += `<text x="${cx}" y="48" text-anchor="middle" font-size="15" font-weight="600">${d}°</text>`;
    svg += `<path d="${path(tp, SCALE, cx, floor, true)}" fill="#f1efe9" stroke="${INK}" stroke-width="1.1" stroke-linejoin="round"/>`;
    svg += `<path d="${path(ts, SCALE, cx, floor, false)}" fill="none" stroke="${INK}" stroke-width="0.8" stroke-dasharray="3 2" opacity="${op}"/>`;
    svg += `<path d="${path(np, SCALE, cx, floor, true)}" fill="none" stroke="${NEWC}" stroke-width="1.1" stroke-linejoin="round"/>`;
    svg += `<path d="${path(ns, SCALE, cx, floor, false)}" fill="none" stroke="${NEWC}" stroke-width="0.8" stroke-dasharray="3 2" opacity="${op}"/>`;
    // close-up of the tail
    const cs = SCALE * CLOSE;
    const cfloor = 60 + fullH + 30 + closeH - 10;
    const clip = `c${i}`;
    svg += `<clipPath id="${clip}"><rect x="${20 + colW * i + 4}" y="${cfloor - CLOSE_MM * cs}" width="${colW - 8}" height="${CLOSE_MM * cs + 6}"/></clipPath>`;
    svg += `<rect x="${20 + colW * i + 4}" y="${cfloor - CLOSE_MM * cs}" width="${colW - 8}" height="${CLOSE_MM * cs + 6}" fill="none" stroke="#bbb" stroke-width="0.5"/>`;
    svg += `<g clip-path="url(#${clip})">`;
    svg += `<path d="${path(tp, cs, cx, cfloor, true)}" fill="#f1efe9" stroke="${INK}" stroke-width="1.1" stroke-linejoin="round"/>`;
    svg += `<path d="${path(ts, cs, cx, cfloor, false)}" fill="none" stroke="${INK}" stroke-width="0.8" stroke-dasharray="3 2" opacity="${op}"/>`;
    svg += `<path d="${path(np, cs, cx, cfloor, true)}" fill="none" stroke="${NEWC}" stroke-width="1.3" stroke-linejoin="round"/>`;
    svg += `<path d="${path(ns, cs, cx, cfloor, false)}" fill="none" stroke="${NEWC}" stroke-width="0.8" stroke-dasharray="3 2" opacity="${op}"/>`;
    svg += `</g>`;
  });
  const H = 60 + fullH + 30 + closeH + 50;
  svg += `<text x="20" y="${60 + fullH + 22}" font-size="12" fill="#555">The tail, three times larger (the bottom ${CLOSE_MM} mm of the board):</text>`;
  svg += `<text x="20" y="${H - 18}" font-size="12" fill="#555"><tspan fill="${INK}" font-weight="600">Grey fill, black line</tspan> = the board as the live site draws it today. <tspan fill="${NEWC}" font-weight="600">Magenta line</tspan> = the new drawing. Dashed = the stringer (it fades in as the board turns, as on the rack).</text>`;
  return `<!doctype html><html><body style="margin:0;background:#fbfaf7;font-family:-apple-system,Helvetica,sans-serif">
  <div style="padding:14px 20px 0"><div style="font-size:17px;font-weight:700">${title}</div><div style="font-size:13px;color:#444;margin-top:3px">${sub}</div></div>
  <svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${svg}</svg></body></html>`;
}

const fish = board(presetDesignFields(P.fish));
const dia = board(withTail("shortboard", "diamond"));
const pages = [
  {
    file: "plan-fish-swallow.png",
    html: sheet(
      "The Fish (swallow tail) turning on the Board Rack — today vs the new drawing",
      `Drawn at the computer rack's own size (${SCALE.toFixed(3)} dots per mm). Today the tail stays square until 89.5°, then the notch appears all at once; the new drawing opens the notch as the board turns.`,
      fish,
    ),
  },
  {
    file: "plan-diamond.png",
    html: sheet(
      "A Shortboard with the Diamond tail turning on the Board Rack — today vs the new drawing",
      `Drawn at the computer rack's own size (${SCALE.toFixed(3)} dots per mm). Today a thin spike (the "nipple") sticks out behind a squared-off tail until 89.5°, then the diamond appears; the new drawing keeps the diamond's point all the way round.`,
      dia,
    ),
  },
];

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ deviceScaleFactor: 2, viewport: { width: 1260, height: 800 } });
  for (const p of pages) {
    writeFileSync(`${out}/${p.file.replace(".png", ".html")}`, p.html);
    await page.setContent(p.html);
    await page.screenshot({ path: `${out}/${p.file}`, fullPage: true });
    console.log(`${out}/${p.file}`);
  }
  await browser.close();
})();

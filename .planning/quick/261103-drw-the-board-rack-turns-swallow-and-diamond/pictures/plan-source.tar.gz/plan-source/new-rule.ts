// Prototype of the one-rule turn (quick 261103-drw). Scratch only — never committed.
import type { BoardSideProfile } from "../lib/geometry/board-profile";
import type { OutlineGeometry } from "../lib/geometry/outline";
import { silhouette } from "../lib/geometry/screen-tiles";
import { mm } from "../lib/geometry/units";

export interface Sec { station: number; rocker: number; deck: number; half: number }
export interface NewArt {
  length: number;
  tMid: number;
  maxDeck: number;
  sections: Sec[]; // union stations, tail to nose
  notch: { sections: Sec[]; a: number[] } | null; // stations s0..c (inclusive), notch edge a(s)
  closeStation: number;
  silhouette: { station: number; w: number }[];
}

export function edgePolyline(geometry: OutlineGeometry): { station: number; w: number }[] {
  const pts = geometry.points.map((p) => ({ station: p.station as number, w: p.halfWidth as number }));
  if (geometry.centreCloseStation < pts[0].station) return [{ station: geometry.centreCloseStation, w: 0 }, ...pts];
  return pts;
}

function interp(poly: { station: number; w: number }[], s: number): number {
  if (s <= poly[0].station) return poly[0].w;
  for (let i = 0; i < poly.length - 1; i++) {
    const p0 = poly[i];
    const p1 = poly[i + 1];
    if (s >= p0.station && s <= p1.station) {
      const t = p1.station > p0.station ? (s - p0.station) / (p1.station - p0.station) : 0;
      return p0.w + (p1.w - p0.w) * t;
    }
  }
  return poly[poly.length - 1].w;
}

export function buildNewArt(profile: BoardSideProfile, geometry: OutlineGeometry, steps = 64): NewArt {
  const L = profile.length as number;
  const poly = edgePolyline(geometry);
  const set = new Set<number>();
  for (let i = 0; i <= steps; i++) set.add((L * i) / steps);
  for (const p of poly) set.add(p.station);
  const c = geometry.centreCloseStation as number;
  set.add(c);
  const stations = [...set].filter((s) => s >= 0 && s <= L).sort((a, b) => a - b);
  const sec = (s: number): Sec => ({
    station: s,
    rocker: profile.rockerAt(mm(s)),
    deck: profile.deckAt(mm(s)),
    half: interp(poly, s),
  });
  // The polygon's edges start at the polyline's first station (a diamond: its tip at c).
  const sections = stations.filter((s) => s >= poly[0].station).map(sec);
  const s0 = geometry.points[0].station as number;
  const w0 = geometry.points[0].halfWidth as number;
  let notch: NewArt["notch"] = null;
  if (c > s0) {
    const ns = sections.filter((x) => x.station <= c);
    notch = { sections: ns, a: ns.map((x) => (w0 * (c - x.station)) / (c - s0)) };
  }
  const maxDeck = Math.max(...stations.map((s) => profile.deckAt(mm(s))));
  // keep today's tMid exactly: max over the 65 uniform stations
  let maxDeck65 = -Infinity;
  for (let i = 0; i <= steps; i++) maxDeck65 = Math.max(maxDeck65, profile.deckAt(mm((L * i) / steps)));
  return { length: L, tMid: maxDeck65 / 2, maxDeck, sections, notch, closeStation: c, silhouette: silhouette(geometry) };
}

const xcOf = (st: Sec, tMid: number, cos: number) => ((st.rocker + st.deck) / 2 - tMid) * cos;
const extOf = (st: Sec, cos: number, sin: number) =>
  Math.sqrt(((st.deck - st.rocker) / 2) ** 2 * cos ** 2 + st.half ** 2 * sin ** 2);

/** The notch's inner edge offset g about the section centre (positive = a gap shows). */
export function gapOf(st: Sec, a: number, cos: number, sin: number): number {
  const b = (st.deck - st.rocker) / 2;
  const r = st.half > 0 ? Math.min(1, a / st.half) : 1;
  return a * sin - b * Math.sqrt(1 - r * r) * cos;
}

export function newPoints(art: NewArt, theta: number): { station: number; x: number }[] {
  const cos = Math.cos(theta);
  const sin = Math.sin(theta);
  const left: { station: number; x: number }[] = [];
  const right: { station: number; x: number }[] = [];
  for (const st of art.sections) {
    const xc = xcOf(st, art.tMid, cos);
    const e = extOf(st, cos, sin);
    left.push({ station: st.station, x: xc - e });
    right.push({ station: st.station, x: xc + e });
  }
  const closure: { station: number; x: number }[] = [];
  if (art.notch) {
    const ns = art.notch.sections;
    const g = ns.map((st, j) => Math.min(gapOf(st, art.notch!.a[j], cos, sin), extOf(st, cos, sin)));
    const xc = ns.map((st) => xcOf(st, art.tMid, cos));
    let k = g.findIndex((v) => v <= 0);
    if (k < 0) k = ns.length - 1; // never: g at c is -b cos <= 0
    let sStar: number;
    let xStar: number;
    if (k === 0) {
      sStar = ns[0].station;
      xStar = xc[0];
    } else {
      const t = g[k - 1] / (g[k - 1] - g[k]);
      sStar = ns[k - 1].station + t * (ns[k].station - ns[k - 1].station);
      xStar = xc[k - 1] + t * (xc[k] - xc[k - 1]);
    }
    const up = ns.map((st, j) => (j < k ? { station: st.station, x: xc[j] + g[j] } : { station: sStar, x: xStar }));
    const down = ns.map((st, j) => (j < k ? { station: st.station, x: xc[j] - g[j] } : { station: sStar, x: xStar })).reverse();
    closure.push(...up, ...down);
  } else {
    const st = art.sections.find((x) => x.station === art.closeStation) ?? art.sections[0];
    closure.push({ station: art.closeStation, x: xcOf(st, art.tMid, cos) });
  }
  return [...left, ...right.reverse(), ...closure];
}

export function newSpan(art: NewArt, theta: number) {
  const xs = newPoints(art, theta).map((p) => p.x);
  return { left: Math.min(...xs), right: Math.max(...xs) };
}

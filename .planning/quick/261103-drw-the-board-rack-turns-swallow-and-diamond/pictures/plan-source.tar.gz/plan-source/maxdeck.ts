import { presetDesignFields } from "../lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "../lib/geometry/board";
import { LIVE_DESIGN_RULES, designSideProfile } from "../lib/geometry/design";
import { buildOutline } from "../lib/geometry/outline";
import { BOARD_PRESETS } from "../lib/geometry/presets";
import { buildRackBoardArt } from "../lib/geometry/rack-art";
import { rackModelsFromRows } from "../lib/models/rack-models";
import { standInRackRows } from "../lib/models/rack-stand-in";
const boards: any[] = [];
for (const p of BOARD_PRESETS) for (const kind of ["pin","round","diamond","squash","swallow"] as const) for (const hs of [false,true]) {
  const f = presetDesignFields(p); const tp = TAIL_PRESETS[kind];
  boards.push({ ...f, ...(hs ? { blank: null } : {}), outline: { ...f.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness } });
}
for (const m of rackModelsFromRows(standInRackRows(15))) boards.push(m.snapshot);
let dDeck = 0, dHalf = 0, minRocker = Infinity;
for (const f of boards) {
  const art = buildRackBoardArt(designSideProfile(f, LIVE_DESIGN_RULES), buildOutline(f.outline));
  const sd = Math.max(...art.sections.map((s) => s.deck)), sh = Math.max(...art.sections.map((s) => s.half));
  dDeck = Math.max(dDeck, sd - art.maxDeck); dHalf = Math.max(dHalf, sh - art.maxHalf);
  minRocker = Math.min(minRocker, ...art.sections.map((s) => s.rocker));
}
console.log(`${boards.length} boards: max over the drawn stations exceeds the 65-station max by deck ${dDeck.toFixed(4)} mm, half-width ${dHalf.toFixed(4)} mm; lowest rocker anywhere ${minRocker.toFixed(4)} mm`);

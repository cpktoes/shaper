// Measurements for the plan (quick 261103-drw). Scratch only.
import { presetDesignFields } from "../lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "../lib/geometry/board";
import { LIVE_DESIGN_RULES, designSideProfile } from "../lib/geometry/design";
import { buildOutline, sampleOutline } from "../lib/geometry/outline";
import { BOARD_PRESETS } from "../lib/geometry/presets";
import { RACK_OUTLINE_SWITCH_RAD, buildRackBoardArt, drawnSpan, turnedBoardPoints } from "../lib/geometry/rack-art";
import { rackScale } from "../lib/geometry/rack-layout";
import { mm, mmToInches } from "../lib/geometry/units";
import { rackBoardFigures, rackModelsFromRows } from "../lib/models/rack-models";
import { standInRackRows } from "../lib/models/rack-stand-in";
import { buildNewArt, gapOf, newPoints, newSpan } from "./new-rule";

const P = Object.fromEntries(BOARD_PRESETS.map((p) => [p.id, p]));
const deg = (d: number) => (d * Math.PI) / 180;

function fieldsWithTail(id: string, kind: "diamond" | "swallow", handSet = false) {
  const f = presetDesignFields(P[id]);
  const tp = TAIL_PRESETS[kind];
  const outline = { ...f.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness };
  return handSet ? { ...f, outline, blank: null } : { ...f, outline };
}

function caseOf(name: string, fields: ReturnType<typeof presetDesignFields> | any) {
  const geometry = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  return { name, geometry, profile, art: buildRackBoardArt(profile, geometry), nart: buildNewArt(profile, geometry) };
}

const FISH = caseOf("Fish (preset swallow)", presetDesignFields(P.fish));
const DIA = caseOf("Shortboard with the diamond tail button", fieldsWithTail("shortboard", "diamond"));
const DIA_H = caseOf("hand-set Shortboard, diamond", fieldsWithTail("shortboard", "diamond", true));
const DIA_MID = caseOf("Mid-length with the diamond tail button", fieldsWithTail("midlength", "diamond"));
const SW_SB = caseOf("Shortboard with the swallow tail button", fieldsWithTail("shortboard", "swallow"));

// --- 1. the notch formula against a brute-force minimum over the piece
{
  let worst = 0;
  let n = 0;
  for (let trial = 0; trial < 4000; trial++) {
    const w = 50 + Math.random() * 200;
    const b = 2 + Math.random() * 30;
    const a = Math.random() * w;
    const th = Math.random() * Math.PI / 2;
    const cos = Math.cos(th), sin = Math.sin(th);
    let min = Infinity;
    // sample the piece u in [a, w], v in [-b sqrt(1-(u/w)^2), +...]
    for (let i = 0; i <= 400; i++) {
      const u = a + ((w - a) * i) / 400;
      const vmax = b * Math.sqrt(Math.max(0, 1 - (u / w) ** 2));
      for (const v of [-vmax, vmax]) min = Math.min(min, u * sin + v * cos);
      // interior points never beat the boundary for a linear function, but check a few
      for (let j = 1; j < 4; j++) min = Math.min(min, u * sin + (-vmax + (2 * vmax * j) / 4) * cos);
    }
    const formula = gapOf({ station: 0, rocker: 0, deck: 2 * b, half: w }, a, cos, sin);
    worst = Math.max(worst, Math.abs(min - formula));
    n++;
  }
  console.log(`1. notch formula vs brute force over ${n} random sections: worst |diff| = ${worst.toExponential(2)} mm`);
}

// --- 2. tails today
for (const c of [FISH, SW_SB, DIA, DIA_H, DIA_MID]) {
  const g = c.geometry;
  console.log(
    `\n${c.name}: length ${mmToInches(mm(c.profile.length)).toFixed(1)}", tail kind ${(c as any).geometry.tailBlockPinned ? "pinned" : ""} pts[0]=(${g.points[0].station.toFixed(1)}, ${g.points[0].halfWidth.toFixed(1)}) centreClose=${g.centreCloseStation.toFixed(1)} diamondDepth=${g.effectiveDiamondDepth.toFixed(1)}`,
  );
  const st = c.art.stations;
  const zeroes = st.filter((s) => s.station < g.points[0].station && s.half === 0).map((s) => s.station.toFixed(1));
  console.log(`  today's stations inside the tail's V with half-width 0 (sampleOutline fallback): ${zeroes.join(", ") || "none"}`);
  const T0 = c.profile.deckAt(mm(0)) - c.profile.rockerAt(mm(0));
  console.log(`  thickness at the tail tip (station 0): ${T0.toFixed(2)} mm`);
}

// --- 3. diamond tip flat at 60 and 85 (the new rule) and today's nipple
const SCALES = { hover15: rackScale(380, 2844.8), hover7: rackScale(380, 2133.6), swipe357: rackScale(357, 2844.8) };
console.log(`\nscales (dots/mm): ${JSON.stringify(Object.fromEntries(Object.entries(SCALES).map(([k, v]) => [k, +v.toFixed(4)])))}`);
for (const c of [DIA, DIA_H, DIA_MID]) {
  for (const d of [30, 60, 85, 89]) {
    const pts = newPoints(c.nart, deg(d));
    // flat = the two edges at station 0
    const at0 = pts.filter((p) => p.station === 0).map((p) => p.x);
    const flat = Math.max(...at0) - Math.min(...at0);
    // today: the nipple — the stations below the diamond depth have half 0, width T cos
    const todayPts = turnedBoardPoints(c.art, deg(d));
    const N = c.art.stations.length;
    const D = c.geometry.points[0].station;
    let nippleW = 0, nippleLen = 0;
    c.art.stations.forEach((s, i) => {
      if (s.station < D) {
        nippleW = Math.max(nippleW, todayPts[i].x - todayPts[2 * N - 1 - i].x);
        nippleLen = s.station;
      }
    });
    console.log(
      `  ${c.name} at ${d}°: new tip flat ${flat.toFixed(2)} mm = ${(flat * SCALES.hover7).toFixed(2)} dots (hover, 7'0" scale) / ${(flat * SCALES.hover15).toFixed(2)} (hover, practice-rack scale); today's nipple ${nippleW.toFixed(2)} mm wide, ${nippleLen.toFixed(0)}-${D.toFixed(0)} mm long = ${(D * SCALES.hover7).toFixed(1)} dots`,
    );
  }
}

// --- 4. room change (drawn span) new vs today, every stand-in board + the cases, every 0.5 degree
{
  const arts = rackModelsFromRows(standInRackRows(30)).map((m) => {
    const snap = m.snapshot as any;
    return { name: m.name, art: rackBoardFigures(snap).art, nart: buildNewArt(designSideProfile(snap, LIVE_DESIGN_RULES), buildOutline(snap.outline)) };
  });
  const all = [...arts, ...[FISH, SW_SB, DIA, DIA_H, DIA_MID].map((c) => ({ name: c.name, art: c.art, nart: c.nart }))];
  let worst = { d: 0, name: "", at: 0, today: 0, now: 0 };
  let worstBelowSwitch = { d: 0, name: "", at: 0 };
  for (const b of all) {
    for (let t = 0; t <= 900; t++) {
      const th = deg(t / 10);
      const a = drawnSpan(b.art, th);
      const n = newSpan(b.nart, th);
      const today = Math.max(-a.left, a.right);
      const now = Math.max(-n.left, n.right);
      const d = now - today;
      if (Math.abs(d) > Math.abs(worst.d)) worst = { d, name: b.name, at: t / 10, today, now };
      if (th < RACK_OUTLINE_SWITCH_RAD && Math.abs(d) > Math.abs(worstBelowSwitch.d)) worstBelowSwitch = { d, name: b.name, at: t / 10 };
    }
  }
  console.log(`\n4. halfExtent new - today, largest over ${all.length} boards x 901 angles: ${worst.d.toFixed(4)} mm (${worst.name} at ${worst.at}°: ${worst.today.toFixed(3)} -> ${worst.now.toFixed(3)}) = ${(worst.d * SCALES.hover7).toFixed(4)} dots at the 7'0" hover scale`);
  console.log(`   below the old switch: ${worstBelowSwitch.d.toFixed(4)} mm (${worstBelowSwitch.name} at ${worstBelowSwitch.at}°)`);
  // at mid-turn
  for (const t of [30, 45, 60]) {
    let w = 0, nm = "";
    for (const b of all) {
      const a = drawnSpan(b.art, deg(t));
      const n = newSpan(b.nart, deg(t));
      const d = Math.max(-n.left, n.right) - Math.max(-a.left, a.right);
      if (Math.abs(d) > Math.abs(w)) { w = d; nm = b.name; }
    }
    console.log(`   at ${t}°: largest change ${w.toFixed(4)} mm (${nm}) = ${(w * SCALES.hover7).toFixed(4)} dots`);
  }
}

// --- 5. step-to-step move (symmetric Hausdorff between consecutive polygons) per 0.1 degree
function segDist(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
  const dx = bx - ax, dy = by - ay;
  const l2 = dx * dx + dy * dy;
  const t = l2 > 0 ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2)) : 0;
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}
function directed(A: { station: number; x: number }[], B: { station: number; x: number }[]) {
  let worst = 0;
  for (const p of A) {
    let best = Infinity;
    for (let i = 0; i < B.length; i++) {
      const q = B[i], r = B[(i + 1) % B.length];
      const d = segDist(p.x, p.station, q.x, q.station, r.x, r.station);
      if (d < best) best = d;
    }
    if (best > worst) worst = best;
  }
  return worst;
}
const hausdorff = (A: any[], B: any[]) => Math.max(directed(A, B), directed(B, A));
for (const c of [FISH, DIA, DIA_H]) {
  let worstToday = { d: 0, at: 0 };
  let worstNew = { d: 0, at: 0 };
  for (let t = 0; t < 900; t++) {
    const a = deg(t / 10), b = deg((t + 1) / 10);
    const dt = hausdorff(turnedBoardPoints(c.art, a), turnedBoardPoints(c.art, b));
    const dn = hausdorff(newPoints(c.nart, a), newPoints(c.nart, b));
    if (dt > worstToday.d) worstToday = { d: dt, at: t / 10 };
    if (dn > worstNew.d) worstNew = { d: dn, at: t / 10 };
  }
  // across the switch exactly
  const across = hausdorff(turnedBoardPoints(c.art, RACK_OUTLINE_SWITCH_RAD - 1e-6), turnedBoardPoints(c.art, RACK_OUTLINE_SWITCH_RAD));
  console.log(
    `\n5. ${c.name}: largest move between frames 0.1° apart — today ${worstToday.d.toFixed(2)} mm (${(worstToday.d * SCALES.hover7).toFixed(2)} dots) at ${worstToday.at}°; new ${worstNew.d.toFixed(3)} mm (${(worstNew.d * SCALES.hover7).toFixed(3)} dots) at ${worstNew.at}°. Today across the switch alone (1e-6 rad): ${across.toFixed(2)} mm`,
  );
}

// --- 6. relations: 0 deg = side profile, 90 deg = silhouette, vertex counts
for (const c of [FISH, DIA, DIA_H, SW_SB]) {
  const p0 = newPoints(c.nart, 0);
  const p90 = newPoints(c.nart, Math.PI / 2);
  const sil = c.nart.silhouette.map(({ station, w }) => ({ station, x: 0 - w }));
  // silhouette is a subsequence of p90 (closeTo 1e-9)
  let j = 0;
  for (const p of p90) if (j < sil.length && Math.abs(p.station - sil[j].station) < 1e-9 && Math.abs(p.x - sil[j].x) < 1e-9) j++;
  // every p90 point on the silhouette boundary
  const off = Math.max(...p90.map((p) => directed([p], sil)));
  // 0 deg: every point on the side profile's own boundary
  const n = c.nart.sections.length;
  let worst0 = 0;
  c.nart.sections.forEach((s, i) => {
    worst0 = Math.max(worst0, Math.abs(p0[i].x - (s.rocker - c.nart.tMid)), Math.abs(p0[2 * n - 1 - i].x - (s.deck - c.nart.tMid)));
  });
  console.log(
    `\n6. ${c.name}: ${p0.length} vertices at every angle (today ${turnedBoardPoints(c.art, 0).length} at rest, ${turnedBoardPoints(c.art, Math.PI / 2).length} turned). 90°: silhouette matched ${j}/${sil.length} in order, farthest point off it ${off.toExponential(2)} mm. 0°: edges vs rocker/deck worst ${worst0.toExponential(2)} mm; tMid same as today: ${c.nart.tMid === c.art.tMid}`,
  );
  if (c.nart.notch) {
    const ns = c.nart.notch;
    // notch visible depth s* by angle
    const depths = [0, 1, 2, 5, 10, 30, 60, 85, 89, 90].map((d) => {
      const pts = newPoints(c.nart, deg(d));
      const clos = pts.slice(2 * n);
      const top = Math.max(...clos.map((p) => p.station));
      const gapAt0 = clos[0].x - clos[clos.length - 1].x;
      return `${d}°: notch reaches ${top.toFixed(1)} of ${c.nart.closeStation.toFixed(1)} mm, ${gapAt0.toFixed(1)} mm wide at the tail`;
    });
    console.log(`   notch stations ${ns.sections.length}; ${depths.join("; ")}`);
  }
}

// Point-to-point continuity of the new rule vs a bound from the board's size. Scratch only.
import { presetDesignFields } from "../lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "../lib/geometry/board";
import { LIVE_DESIGN_RULES, designSideProfile } from "../lib/geometry/design";
import { buildOutline } from "../lib/geometry/outline";
import { BOARD_PRESETS } from "../lib/geometry/presets";
import { rackModelsFromRows } from "../lib/models/rack-models";
import { standInRackRows } from "../lib/models/rack-stand-in";
import { buildNewArt, newPoints } from "./new-rule";

const deg = (d: number) => (d * Math.PI) / 180;
const boards: { name: string; fields: any }[] = [];
for (const p of BOARD_PRESETS) {
  boards.push({ name: p.name, fields: presetDesignFields(p) });
  for (const kind of ["pin", "round", "diamond", "squash", "swallow"] as const) {
    const f = presetDesignFields(p);
    const tp = TAIL_PRESETS[kind];
    boards.push({ name: `${p.name}+${kind}`, fields: { ...f, outline: { ...f.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness } } });
    boards.push({ name: `${p.name}+${kind} hand-set`, fields: { ...f, blank: null, outline: { ...f.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness } } });
  }
}
for (const m of rackModelsFromRows(standInRackRows(15))) boards.push({ name: m.name, fields: m.snapshot });

let worstRatio = { r: 0, name: "", at: 0 };
let worstCount = 0;
const DT = deg(0.1);
for (const b of boards) {
  const geometry = buildOutline(b.fields.outline);
  const art = buildNewArt(designSideProfile(b.fields, LIVE_DESIGN_RULES), geometry);
  const maxHalf = Math.max(...art.sections.map((s) => s.half));
  const bound = (art.maxDeck + maxHalf) * DT;
  let prev = newPoints(art, 0);
  const n0 = prev.length;
  for (let t = 1; t <= 900; t++) {
    const cur = newPoints(art, deg(t / 10));
    if (cur.length !== n0) worstCount++;
    let mv = 0;
    for (let i = 0; i < cur.length; i++) mv = Math.max(mv, Math.hypot(cur[i].x - prev[i].x, cur[i].station - prev[i].station));
    if (mv / bound > worstRatio.r) worstRatio = { r: mv / bound, name: b.name, at: t / 10 };
    prev = cur;
  }
}
console.log(`${boards.length} boards; vertex count changed with angle on ${worstCount} frames`);
console.log(`largest point move per 0.1° / ((maxDeck + maxHalf) * 0.1°): ${worstRatio.r.toFixed(3)} (${worstRatio.name} at ${worstRatio.at}°)`);

/**
 * The Board Rack's turn (Phase 15 R3): each board standing on its tail, rail facing you, turning its
 * real turn to show its outline.
 *
 * The turn is worked out, not animated from pictures. Along the board at 65 stations (tail 0 to nose
 * at the board's length) the cross-section is taken as an ellipse — the outline's half-width across,
 * half the thickness deep — and projected at the turn angle θ from the board's OWN numbers: its
 * rocker and deck (`BoardSideProfile`, the very profile `summarizeDesign` reads) and its outline
 * (`sampleOutline`). So at 0 degrees the picture is exactly the board's side profile, deck facing
 * right; as it turns the rail swings away, the deck comes round and the stringer slides from the rail
 * edge to the centre; and from just under 90 degrees (`RACK_OUTLINE_SWITCH_RAD`) up it is exactly the
 * TEMPLATE silhouette (`silhouette` in `screen-tiles.ts`), a swallow's notch included. The formula is
 * the one the Board Rack sketches proved (`.claude/skills/sketch-findings-shaper/references/board-rack.md`,
 * "The turn maths").
 *
 * Every coordinate is in the board's own millimetres: `station` along the board from the tail, `x`
 * across it from the turning axis, positive toward the deck at rest. The turning axis sits at half
 * the board's greatest deck height (`tMid`), so the side view and the outline both stand centred.
 *
 * Pure, like everything under `lib/geometry/` (CLAUDE.md Rule 1): no React, browser or database
 * imports, so the turn can be checked against the presets in isolation.
 */

import type { BoardSideProfile } from "./board-profile";
import { sampleOutline, type OutlineGeometry } from "./outline";
import { polylinePath, silhouette } from "./screen-tiles";
import { type Mm, mm } from "./units";

/** How many steps the rack samples along a board: 64 steps, so 65 stations tail to nose. */
export const RACK_ART_STEPS = 64;


/** The clear dots between a board's drawn left edge and the furthest-right reach of its vertical
 * words (their descenders). */
export const SPINE_ANCHOR_GAP = 4;

/** How far, as a share of the font size, a descender reaches right of the words' baseline once they
 * are turned to read tail to nose — so the baseline stands this much further left. */
export const SPINE_DESCENDER_EM = 0.25;

/** One station along the board: its bottom (rocker), its deck and its outline's half-width. */
export interface RackStation {
  station: Mm;
  rocker: Mm;
  deck: Mm;
  half: Mm;
}

/** Everything the rack needs to draw one board at any angle, in millimetres. */
export interface RackBoardArt {
  length: Mm;
  /** 65 stations, tail (0) to nose (`length`). */
  stations: readonly RackStation[];
  /** The turning axis: half the greatest deck height. */
  tMid: number;
  /** The greatest deck height along the board. */
  maxDeck: number;
  /** The outline's greatest half-width. */
  maxHalf: number;
  /** The TEMPLATE silhouette, as `screen-tiles.ts` draws it. */
  silhouette: readonly { station: number; w: number }[];
  /** PROTOTYPE: the drawn edges' stations — the 65, the silhouette's own and the closing station. */
  sections: readonly RackStation[];
  /** PROTOTYPE: a swallow's notch — its stations from the tail to the crotch and the notch edge there. */
  notch: { sections: readonly RackStation[]; edge: readonly number[] } | null;
  /** PROTOTYPE: where the tail closes on the stringer. */
  closeStation: number;
}

/** A point of a turned board: `station` along it from the tail, `x` across it from the turning axis
 * (positive toward the deck at rest), both in millimetres. */
export interface RackPoint {
  station: number;
  x: number;
}

function assertFinite(field: string, value: number, index: number): void {
  if (!Number.isFinite(value)) throw new Error(`rack art: ${field} at station ${index} is not a finite number`);
}

/**
 * A board's rack art from its own side profile and outline. Throws an `Error` naming the first
 * value that isn't a finite number, so a board whose picture can't be worked out is caught before
 * the rack draws it (WR-05).
 */
export function buildRackBoardArt(
  profile: BoardSideProfile,
  geometry: OutlineGeometry,
  steps: number = RACK_ART_STEPS,
): RackBoardArt {
  const length = profile.length;
  assertFinite("length", length, 0);
  const outline = silhouette(geometry);
  outline.forEach((point, i) => {
    assertFinite("outline station", point.station, i);
    assertFinite("outline half-width", point.w, i);
  });
  const edge = tailAwareEdge(geometry);
  const section = (station: number, i: number): RackStation => {
    const rocker = profile.rockerAt(mm(station));
    assertFinite("rocker", rocker, i);
    const deck = profile.deckAt(mm(station));
    assertFinite("deck", deck, i);
    const half = halfOnEdge(edge, station);
    assertFinite("half-width", half, i);
    return { station: mm(station), rocker, deck, half: mm(half) };
  };
  const stations: RackStation[] = [];
  for (let i = 0; i <= steps; i++) stations.push(section((length * i) / steps, i));
  const close = geometry.centreCloseStation;
  const wanted = new Set<number>(stations.map((st) => st.station));
  for (const p of edge) wanted.add(p.station);
  wanted.add(close);
  const sections = [...wanted]
    .filter((s) => s >= edge[0].station && s <= length)
    .sort((a, b) => a - b)
    .map((s, i) => section(s, i));
  const s0 = geometry.points[0].station;
  const w0 = geometry.points[0].halfWidth;
  const notch =
    close > s0
      ? (() => {
          const inside = sections.filter((st) => st.station <= close);
          return { sections: inside, edge: inside.map((st) => (w0 * (close - st.station)) / (close - s0)) };
        })()
      : null;
  const maxDeck = Math.max(...stations.map((st) => st.deck));
  const maxHalf = Math.max(...stations.map((st) => st.half));
  return { length, stations, tMid: maxDeck / 2, maxDeck, maxHalf, silhouette: outline, sections, notch, closeStation: close };
}

/** The right edge tail to nose: the outline's points, led by the tail's own point when it closes behind
 * them (a diamond's tip). */
function tailAwareEdge(geometry: OutlineGeometry): { station: number; w: number }[] {
  const points = geometry.points.map((p) => ({ station: p.station as number, w: p.halfWidth as number }));
  return geometry.centreCloseStation < points[0].station ? [{ station: geometry.centreCloseStation, w: 0 }, ...points] : points;
}

function halfOnEdge(edge: readonly { station: number; w: number }[], station: number): number {
  for (let i = 0; i < edge.length - 1; i++) {
    const p0 = edge[i];
    const p1 = edge[i + 1];
    if (station >= p0.station && station <= p1.station) {
      const t = p1.station > p0.station ? (station - p0.station) / (p1.station - p0.station) : 0;
      return p0.w + (p1.w - p0.w) * t;
    }
  }
  return station < edge[0].station ? edge[0].w : edge[edge.length - 1].w;
}

/** Where one station's cross-section is centred across the board, turned by an angle whose cosine
 * is `cos`: halfway between its rocker and its deck, measured from the turning axis. */
function sectionCentre({ rocker, deck }: RackStation, tMid: number, cos: number): number {
  return ((rocker + deck) / 2 - tMid) * cos;
}

/** Half of one station's cross-section as it shows turned: its ellipse (half the thickness deep,
 * the outline's half-width across) projected at the angle whose cosine and sine are `cos`, `sin`. */
function sectionHalf({ rocker, deck, half }: RackStation, cos: number, sin: number): number {
  return Math.sqrt(((deck - rocker) / 2) ** 2 * cos ** 2 + half ** 2 * sin ** 2);
}

function notchGap(st: RackStation, edge: number, cos: number, sin: number): number {
  const b = (st.deck - st.rocker) / 2;
  const r = st.half > 0 ? Math.min(1, edge / st.half) : 1;
  return Math.min(edge * sin - b * Math.sqrt(1 - r * r) * cos, sectionHalf(st, cos, sin));
}

export function turnedBoardPoints(art: RackBoardArt, theta: number): RackPoint[] {
  const cos = Math.cos(theta);
  const sin = Math.sin(theta);
  const low: RackPoint[] = [];
  const high: RackPoint[] = [];
  for (const st of art.sections) {
    const xc = sectionCentre(st, art.tMid, cos);
    const ext = sectionHalf(st, cos, sin);
    low.push({ station: st.station, x: xc - ext });
    high.push({ station: st.station, x: xc + ext });
  }
  const closure: RackPoint[] = [];
  if (art.notch) {
    const ns = art.notch.sections;
    const g = ns.map((st, j) => notchGap(st, art.notch!.edge[j], cos, sin));
    const xc = ns.map((st) => sectionCentre(st, art.tMid, cos));
    let k = g.findIndex((v) => v <= 0);
    if (k < 0) k = ns.length - 1;
    let sStar: number = ns[0].station;
    let xStar = xc[0];
    if (k > 0) {
      const t = g[k - 1] / (g[k - 1] - g[k]);
      sStar = ns[k - 1].station + t * (ns[k].station - ns[k - 1].station);
      xStar = xc[k - 1] + t * (xc[k] - xc[k - 1]);
    }
    const up = ns.map((st, j) => (j < k ? { station: st.station, x: xc[j] + g[j] } : { station: sStar, x: xStar }));
    const down = ns.map((st, j) => (j < k ? { station: st.station, x: xc[j] - g[j] } : { station: sStar, x: xStar }));
    closure.push(...up, ...down.reverse());
  } else {
    const st = art.sections.find((x) => x.station === art.closeStation) ?? art.sections[0];
    closure.push({ station: art.closeStation, x: sectionCentre(st, art.tMid, cos) });
  }
  return [...low, ...high.reverse(), ...closure];
}

/** Rack millimetres to screen dots: x across from the board's axis at `cx`, stations up from the floor. */
function toScreen(points: readonly RackPoint[], scale: number, cx: number, floorY: number) {
  return points.map((p) => ({ x: cx + p.x * scale, y: floorY - p.station * scale }));
}

/** The board's outline at `theta` as an SVG path, `scale` dots per millimetre, its axis at `cx`,
 * standing on the floor at `floorY`. */
export function turnedBoardPath(art: RackBoardArt, theta: number, scale: number, cx: number, floorY: number): string {
  return polylinePath(toScreen(turnedBoardPoints(art, theta), scale, cx, floorY), true);
}

/** The stringer at `theta`, tail to nose: on the deck edge at rest, on the centreline turned. */
export function stringerPoints(art: RackBoardArt, theta: number): RackPoint[] {
  const cos = Math.cos(theta);
  const from = art.notch ? art.closeStation : 0;
  const crotch = art.notch ? art.notch.sections[art.notch.sections.length - 1] : null;
  const along = [...(crotch ? [crotch] : []), ...art.stations.filter((st) => st.station >= from && (!crotch || st.station > crotch.station))];
  return along.map(({ station, deck }) => ({ station, x: (deck - art.tMid) * cos }));
}

/** The stringer at `theta` as an open SVG path, placed like `turnedBoardPath`. */
export function stringerPath(art: RackBoardArt, theta: number, scale: number, cx: number, floorY: number): string {
  return polylinePath(toScreen(stringerPoints(art, theta), scale, cx, floorY), false);
}

/**
 * How far the drawn board reaches from its axis at `theta`, on whichever side reaches further, in
 * dots — what the rack opens around a turning board: half the side view at rest, the TEMPLATE
 * outline's widest half-width turned, and in between exactly what `drawnSpan` finds. It is read off
 * the drawing rather than estimated from the board's greatest thickness and width, because part-way
 * round a board reaches further than either suggests: its cross-sections sit off the axis (thin
 * through the middle, high at the nose), which carries the drawn edge up to 3.7 dots past such an
 * estimate at about 35 degrees on the computer's rack — enough for a neighbour's words to touch it
 * (rack-room.test.ts).
 */
export function halfExtent(art: RackBoardArt, theta: number, scale: number): number {
  const { left, right } = drawnSpan(art, theta);
  return Math.max(-left, right) * scale;
}

/**
 * How far the drawn board reaches either side of its axis at `theta`, in millimetres: exactly the
 * least and greatest x of `turnedBoardPoints`, worked out from the same edges without building the
 * polygon — the rack asks this for every board on every frame.
 */
export function drawnSpan(art: RackBoardArt, theta: number): { left: number; right: number } {
  let left = Infinity;
  let right = -Infinity;
  const cos = Math.cos(theta);
  const sin = Math.sin(theta);
  for (const st of art.sections) {
    const xc = sectionCentre(st, art.tMid, cos);
    const ext = sectionHalf(st, cos, sin);
    if (xc - ext < left) left = xc - ext;
    if (xc + ext > right) right = xc + ext;
  }
  return { left, right };
}

/**
 * Where a board's vertical words start, in dots from its axis: the baseline point of words turned
 * with `rotate(-90)`, whose glyphs sit to the left of it. It stands `gap` dots left of the board's
 * own drawn left edge at `theta`, less `SPINE_DESCENDER_EM` of the font size for descenders reaching
 * right of the baseline — so no word ever crosses its board (the SPEC's prohibition, R4).
 */
export function spineAnchorX(
  art: RackBoardArt,
  theta: number,
  scale: number,
  fontSize: number,
  gap: number = SPINE_ANCHOR_GAP,
): number {
  return drawnSpan(art, theta).left * scale - gap - SPINE_DESCENDER_EM * fontSize;
}

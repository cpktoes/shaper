// What the browser spec will read, simulated on the path strings at the racks' scales. Scratch only.
import { presetDesignFields } from "../lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "../lib/geometry/board";
import { LIVE_DESIGN_RULES, designSideProfile } from "../lib/geometry/design";
import { buildOutline } from "../lib/geometry/outline";
import { BOARD_PRESETS } from "../lib/geometry/presets";
import * as NEW from "../lib/geometry/rack-art";
import * as TODAY from "../lib/geometry/rack-art-today";
import { HOVER_SLOT, SWIPE_SLOT } from "../lib/geometry/rack-layout";

const P = Object.fromEntries(BOARD_PRESETS.map((p) => [p.id, p]));
const parse = (d: string) => {
  const n = d.match(/-?\d+(\.\d+)?/g)!.map(Number);
  const pts: { x: number; y: number }[] = [];
  for (let i = 0; i < n.length; i += 2) pts.push({ x: n[i], y: n[i + 1] });
  return pts;
};
const crossings = (pts: { x: number; y: number }[], y: number) => {
  let c = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    if ((a.y - y) * (b.y - y) < 0) c++;
  }
  return c;
};
const widthAt = (pts: { x: number; y: number }[], y: number) => {
  const xs: number[] = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    if ((a.y - y) * (b.y - y) < 0) xs.push(a.x + ((y - a.y) / (b.y - a.y)) * (b.x - a.x));
  }
  return Math.max(...xs) - Math.min(...xs);
};

const fishF = presetDesignFields(P.fish);
const sb = presetDesignFields(P.shortboard);
const tp = TAIL_PRESETS.diamond;
const diaF = { ...sb, outline: { ...sb.outline, tail: tp.tail, tailAngle: tp.tailAngle, tailFullness: tp.tailFullness } };

for (const [label, fields, slot, scale] of [
  ["Fish, hover", fishF, HOVER_SLOT, 380 / 2844.8],
  ["Fish, swipe", fishF, SWIPE_SLOT, 357 / 2844.8],
  ["Diamond, hover", diaF, HOVER_SLOT, 380 / 2844.8],
  ["Diamond, swipe", diaF, SWIPE_SLOT, 357 / 2844.8],
] as const) {
  const g = buildOutline((fields as any).outline);
  const prof = designSideProfile(fields as any, LIVE_DESIGN_RULES);
  const art = NEW.buildRackBoardArt(prof, g);
  const old = TODAY.buildRackBoardArt(prof, g);
  const bound = 2 * (art.maxDeck + art.maxHalf) * scale * ((Math.PI / 2) / slot);
  let worst = 0, counts = new Set<number>(), oldCounts = new Set<number>();
  const crossNew: string[] = [], crossOld: string[] = [], widthNew: string[] = [], widthOld: string[] = [];
  let prev: { x: number; y: number }[] | null = null;
  for (let d = slot; d >= 0; d--) {
    const th = (Math.PI / 2) * (1 - d / slot);
    const deg = Math.round((th * 180) / Math.PI);
    const pn = parse(NEW.turnedBoardPath(art, th, scale, 0, 0));
    const po = parse(TODAY.turnedBoardPath(old, th, scale, 0, 0));
    counts.add(pn.length); oldCounts.add(po.length);
    if (prev) for (let i = 0; i < pn.length; i++) worst = Math.max(worst, Math.hypot(pn[i].x - prev[i].x, pn[i].y - prev[i].y));
    prev = pn;
    const h = (y: number) => -y * scale;
    if (g.centreCloseStation > 0) {
      const y = h(g.centreCloseStation / 4);
      crossNew.push(`${deg}:${crossings(pn, y)}`); crossOld.push(`${deg}:${crossings(po, y)}`);
    } else {
      const D = g.effectiveDiamondDepth;
      const y = h(D / 2);
      const need = 2 * (g.points[0].halfWidth / 2) * Math.sin(th - Math.PI / 180) * scale;
      widthNew.push(`${deg}:${(widthAt(pn, y) - need).toFixed(1)}`); widthOld.push(`${deg}:${(widthAt(po, y) - need).toFixed(1)}`);
    }
  }
  console.log(`\n${label}: scale ${scale.toFixed(4)}, slot ${slot}; vertex counts new ${[...counts]} today ${[...oldCounts]}; largest move per 1-dot step ${worst.toFixed(2)} dots vs bound ${bound.toFixed(2)}`);
  if (crossNew.length) {
    console.log(`  crossings a quarter up the notch, new: ${crossNew.filter((_, i) => i % 4 === 0).join(" ")}`);
    console.log(`  today: ${crossOld.filter((_, i) => i % 4 === 0).join(" ")}`);
  } else {
    console.log(`  width half-way up the V minus sin(θ-1°)·V width, new: ${widthNew.filter((_, i) => i % 4 === 0).join(" ")}`);
    console.log(`  today: ${widthOld.filter((_, i) => i % 4 === 0).join(" ")}`);
  }
}

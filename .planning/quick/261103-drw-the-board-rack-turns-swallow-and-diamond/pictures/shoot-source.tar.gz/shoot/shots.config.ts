// Quick 261103-drw's picture script: the worktree's own Playwright config, pointed at this folder's
// spec, with the dev server started in (or reused from) the worktree. Scratch only, archived as
// pictures/shoot-source.tar.gz.
import { defineConfig } from "@playwright/test";
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/playwright.config";

const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75";
const server = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer;

export default defineConfig({
  ...base,
  testDir: "/private/tmp/claude-501/-Users-kontoes-Code-shaper/83ff3531-9289-46f6-95de-7b57b8eb15bc/scratchpad/shoot",
  testMatch: "shots.spec.ts",
  testIgnore: [],
  timeout: 180_000,
  webServer: { ...server!, cwd: WORKTREE, reuseExistingServer: true },
});

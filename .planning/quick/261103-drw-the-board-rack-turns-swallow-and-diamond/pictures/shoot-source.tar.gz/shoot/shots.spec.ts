// Quick 261103-drw's picture script: holds the Fish (practice board 2) and a Shortboard with the
// Diamond tail button part-way through its turn on the Board Rack, through the racks' REAL input — the
// cursor on a computer, the held scroll on a phone — and photographs the board with its neighbours.
// SHOOT_TAG=before|after takes pictures; SHOOT_TAG=table only prints the table. Every mode prints, per
// board and rack: data-turn, the drawn outline's point count, and for the Fish how many times a line a
// quarter of the way up its notch crosses the drawing, for the diamond the drawn width half-way up its V
// against sin(turn - 1 degree) x the V's width there. Scratch only.
//
// Time is held still with Playwright's clock while each frame is read, so the rack's rest (180 ms on a
// computer) and the phone's settle (120 ms) never fire mid-read: every reading is a frame the shaper
// would see while still moving.
import { expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/blanks/preset-blanks";
import { TAIL_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/geometry/board";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/geometry/presets";
import { HOVER_SLOT } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/geometry/rack-layout";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/models/banner-dismissal";
import { IN_PROGRESS_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/models/rack-order";
import { rackModelsFromRows } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/models/rack-models";
import { RACK_STAND_IN_ROUTE, standInRackRows } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/models/rack-stand-in";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/lib/models/toolbar-tip";
import { freshPracticeRack } from "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/e2e/helpers/practice-rack";

const TAG = process.env.SHOOT_TAG ?? "table";
const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/agent-ae646865a98b76d75/.planning/quick/261103-drw-the-board-rack-turns-swallow-and-diamond/pictures";
const TARGETS = [0, 10, 30, 45, 60, 80, 88, 90];
const PICTURE_TARGETS: Record<number, string> = { 45: "45", 88: "88" };

const ROWS = standInRackRows(15);
const FISH_ROW = ROWS[1];
const FISH = rackModelsFromRows(ROWS)[1].snapshot;
const FISH_OUTLINE = buildOutline(FISH.outline);
const SHORTBOARD = presetDesignFields(BOARD_PRESETS[0]);
const DIAMOND_OUTLINE = buildOutline({
  ...SHORTBOARD.outline,
  tail: TAIL_PRESETS.diamond.tail,
  tailAngle: TAIL_PRESETS.diamond.tailAngle,
  tailFullness: TAIL_PRESETS.diamond.tailFullness,
});

test.use({ deviceScaleFactor: 3 });

async function setUp(page: Page) {
  await page.addInitScript(
    ([bannerKey, tipKey]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY] as const,
  );
  await freshPracticeRack(page);
  await page.clock.install();
}

async function openRack(page: Page, count: number) {
  await page.goto(RACK_STAND_IN_ROUTE);
  await expect(page.locator("[data-rack-board]")).toHaveCount(count);
  await expect(page.locator("[data-rack-art][data-turn]")).toHaveCount(count);
}

async function startDiamondAndComeBack(page: Page) {
  await page.getByRole("button").filter({ hasText: "Start Shaping" }).first().click();
  await page.waitForURL("**/design/outline");
  await page.getByRole("button", { name: "diamond", exact: true }).click();
  await page.goBack();
  await page.waitForURL((url) => url.pathname === RACK_STAND_IN_ROUTE);
  await expect(page.locator("[data-rack-board]")).toHaveCount(16);
  await expect(page.locator("[data-rack-board]").first()).toHaveAttribute("data-rack-board", IN_PROGRESS_KEY);
  await expect(page.locator(`[data-rack-art="${IN_PROGRESS_KEY}"]`)).toHaveAttribute("data-turn", "90");
}

type Pt = { x: number; y: number };

/** The board's drawn outline (its body path), its turn, and the rack's order of boards. */
async function readBoard(page: Page, key: string) {
  return page.evaluate((wanted) => {
    const group = document.querySelector(`[data-rack-art="${wanted}"]`);
    const d = group?.querySelector("path")?.getAttribute("d") ?? "";
    return { turn: Number(group?.getAttribute("data-turn")), d };
  }, key);
}

function parse(d: string): Pt[] {
  const n = (d.match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
  const pts: Pt[] = [];
  for (let i = 0; i + 1 < n.length; i += 2) pts.push({ x: n[i], y: n[i + 1] });
  return pts;
}

function crossingXs(pts: Pt[], y: number): number[] {
  const xs: number[] = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    if ((a.y - y) * (b.y - y) < 0) xs.push(a.x + ((y - a.y) / (b.y - a.y)) * (b.x - a.x));
  }
  return xs;
}

interface Row {
  target: number;
  turn: number;
  points: number;
  reading: string;
}

/** What one frame shows: for the Fish the crossings a quarter of the way up its notch, for the diamond
 * the drawn width half-way up its V minus sin(turn - 1 deg) x the V's own width there (dots). */
function reading(kind: "fish" | "diamond", d: string, scale: number): string {
  const pts = parse(d);
  const floor = Math.max(...pts.map((p) => p.y));
  if (kind === "fish") {
    const y = floor - (FISH_OUTLINE.centreCloseStation / 4) * scale;
    return `${crossingXs(pts, y).length} crossings`;
  }
  return "";
}

function diamondReading(d: string, scale: number, turn: number): string {
  const pts = parse(d);
  const floor = Math.max(...pts.map((p) => p.y));
  const y = floor - (DIAMOND_OUTLINE.effectiveDiamondDepth / 2) * scale;
  const xs = crossingXs(pts, y);
  const width = Math.max(...xs) - Math.min(...xs);
  const need = 2 * (DIAMOND_OUTLINE.points[0].halfWidth / 2) * Math.sin(((turn - 1) * Math.PI) / 180) * scale;
  return `width ${width.toFixed(2)} dots, need ${Math.max(0, need).toFixed(2)} (margin ${(width - need).toFixed(2)})`;
}

function scaleOf(d: string, lengthMm: number): number {
  const ys = parse(d).map((p) => p.y);
  return (Math.max(...ys) - Math.min(...ys)) / lengthMm;
}

/** The board and its two neighbours, from their drawings' boxes, down past the floor line. */
async function clipFor(page: Page, key: string) {
  return page.evaluate((wanted) => {
    const groups = Array.from(document.querySelectorAll("[data-rack-art]"));
    const k = groups.findIndex((g) => g.getAttribute("data-rack-art") === wanted);
    const boxes = groups.slice(Math.max(0, k - 1), k + 2).map((g) => g.getBoundingClientRect());
    const left = Math.min(...boxes.map((b) => b.left)) - 10;
    const right = Math.max(...boxes.map((b) => b.right)) + 10;
    const top = Math.min(...boxes.map((b) => b.top)) - 10;
    const bottom = Math.max(...boxes.map((b) => b.bottom)) + 14;
    return { x: Math.max(0, left), y: Math.max(0, top), width: right - Math.max(0, left), height: bottom - Math.max(0, top) };
  }, key);
}

async function shoot(page: Page, name: string, key: string, turn: number) {
  if (TAG === "table") return;
  const clip = await clipFor(page, key);
  const file = `${PICTURES}/${TAG}-${name}.png`;
  await page.screenshot({ path: file, clip });
  console.log(`  picture ${TAG}-${name}.png at data-turn ${turn}`);
}

function printTable(label: string, rows: Row[]) {
  console.log(`\n${TAG.toUpperCase()} — ${label}`);
  console.log("  target | data-turn | points | reading");
  for (const r of rows) console.log(`  ${String(r.target).padStart(6)} | ${String(r.turn).padStart(9)} | ${String(r.points).padStart(6)} | ${r.reading}`);
}

/** The hover rack: the cursor `round(48 x (1 - target / 90))` dots right of the board's slot centre. */
async function sweepHover(page: Page, key: string, slotX: number, y: number, kind: "fish" | "diamond", scaleKey: string, name: string) {
  await page.clock.pauseAt(Date.now() + 1000);
  const rows: Row[] = [];
  const fishScale = scaleOf((await readBoard(page, scaleKey)).d, FISH.outline.length);
  for (const target of TARGETS) {
    await page.mouse.move(slotX + Math.round(HOVER_SLOT * (1 - target / 90)), y);
    await page.waitForTimeout(30);
    await page.clock.runFor(48);
    const { turn, d } = await readBoard(page, key);
    const points = (d.match(/[ML]/g) ?? []).length;
    const r = kind === "fish" ? reading("fish", d, scaleOf(d, FISH.outline.length)) : diamondReading(d, fishScale, turn);
    rows.push({ target, turn, points, reading: r });
    if (PICTURE_TARGETS[target]) await shoot(page, `hover-${name}-${PICTURE_TARGETS[target]}`, key, turn);
  }
  printTable(`hover rack (computer), ${name}`, rows);
}

/** The swipe rack: the screen's middle held `f` slots from the board, snapping off. */
async function sweepSwipe(page: Page, key: string, index: number, kind: "fish" | "diamond", scaleKey: string, name: string) {
  await page.clock.pauseAt(Date.now() + 1000);
  const rows: Row[] = [];
  const fishScale = scaleOf((await readBoard(page, scaleKey)).d, FISH.outline.length);
  for (const target of TARGETS) {
    const f = 1 - target / 90;
    await page.evaluate(
      ([i, along]) => {
        const root = document.querySelector<HTMLElement>("[data-rack-kind]");
        const box = document.querySelector<HTMLElement>("[data-rack-scroller]");
        if (!root || !box) throw new Error("no rack");
        box.style.scrollSnapType = "none";
        const slot = Number(root.getAttribute("data-rack-slot"));
        // Whole dots, at least one off the board short of a full turn: a phone's scroller rounds a
        // fraction of a dot away, which would land "nearly turned" on fully turned.
        let off = Math.round(along * slot);
        if (along > 0 && off === 0) off = 1;
        box.scrollLeft = i === 0 ? off : i * slot - off;
      },
      [index, f] as const,
    );
    await page.waitForTimeout(60);
    await page.clock.runFor(48);
    const { turn, d } = await readBoard(page, key);
    const points = (d.match(/[ML]/g) ?? []).length;
    const r = kind === "fish" ? reading("fish", d, scaleOf(d, FISH.outline.length)) : diamondReading(d, fishScale, turn);
    rows.push({ target, turn, points, reading: r });
    if (PICTURE_TARGETS[target]) await shoot(page, `phone-${name}-${PICTURE_TARGETS[target]}`, key, turn);
  }
  await page.evaluate(() => {
    const box = document.querySelector<HTMLElement>("[data-rack-scroller]");
    if (box) box.style.scrollSnapType = "";
  });
  printTable(`swipe rack (${test.info().project.name}), ${name}`, rows);
}

test.describe("computer", () => {
  test.beforeEach(async ({ page }, info) => {
    test.skip(info.project.name !== "desktop", "computer shots");
    await setUp(page);
  });

  test("the Fish on the hover rack", async ({ page }) => {
    await openRack(page, 15);
    const box = await page.locator(`[data-rack-board="${ROWS[0].id}"]`).boundingBox();
    if (!box) throw new Error("no board 1");
    const first = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
    await sweepHover(page, FISH_ROW.id, first.x + HOVER_SLOT, first.y, "fish", FISH_ROW.id, "fish");
  });

  test("the diamond on the hover rack", async ({ page }) => {
    await openRack(page, 15);
    await startDiamondAndComeBack(page);
    const box = await page.locator(`[data-rack-board="${IN_PROGRESS_KEY}"]`).boundingBox();
    if (!box) throw new Error("no in-progress board");
    const first = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
    const { d } = await readBoard(page, IN_PROGRESS_KEY);
    console.log(`diamond's drawn length / Shortboard length: ${(scaleOf(d, 1) / scaleOf((await readBoard(page, FISH_ROW.id)).d, FISH.outline.length) / SHORTBOARD.outline.length).toFixed(4)}`);
    await sweepHover(page, IN_PROGRESS_KEY, first.x, first.y, "diamond", FISH_ROW.id, "diamond");
  });
});

test.describe("phone", () => {
  test.beforeEach(async ({ page }, info) => {
    test.skip(info.project.name !== "iphone", "phone shots");
    await setUp(page);
  });

  test("the Fish on the swipe rack", async ({ page }) => {
    await openRack(page, 15);
    await sweepSwipe(page, FISH_ROW.id, 1, "fish", FISH_ROW.id, "fish");
  });

  test("the diamond on the swipe rack", async ({ page }) => {
    await openRack(page, 15);
    await startDiamondAndComeBack(page);
    await sweepSwipe(page, IN_PROGRESS_KEY, 0, "diamond", FISH_ROW.id, "diamond");
  });
});

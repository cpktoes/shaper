import { expect, test, type Locator, type Page } from "@playwright/test";
import { goToScreen } from "../../../../e2e/helpers/screens";
import { openCustomizeRocker, waitForBlankButton } from "../../../../e2e/helpers/blank-picker";

// Quick 261017-ojc's pictures: the Longboard preset in the US Blanks 9'4"B with -1/4"N18" +1/8"T36"
// +1/8"T18" set through the popup's rows, so NAT and CUSTOM differ and the red and the blue both show.
const OUT = __dirname;

async function setup(page: Page, opts: { theme?: string; metric?: boolean } = {}) {
  await page.addInitScript(
    ({ theme, metric }) => {
      window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
      window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
      window.localStorage.setItem("shaper-theme", theme);
      if (metric) window.localStorage.setItem("shaper-units", "metric");
    },
    { theme: opts.theme ?? "slate", metric: !!opts.metric },
  );
  await page.goto("/");
  const longboard = page.getByRole("button").filter({ hasText: "Longboard" }).filter({ hasText: "Start Shaping" });
  await expect(async () => {
    await longboard.first().click();
    await page.waitForURL("**/design/outline", { timeout: 2_000 });
  }).toPass({ timeout: 30_000 });
  await page.addStyleTag({ content: "nextjs-portal { display: none !important; }" });
  await goToScreen(page, "ROCKER");
  await waitForBlankButton(page);
}

async function pressUntil(page: Page, thumb: Locator, key: string, want: string | RegExp, max = 80) {
  await thumb.focus();
  for (let i = 0; i < max; i++) {
    const now = (await thumb.getAttribute("aria-valuetext")) ?? "";
    if (typeof want === "string" ? now === want : want.test(now)) return;
    await page.keyboard.press(key);
  }
  await expect(thumb).toHaveAttribute("aria-valuetext", want);
}

const slider = (dialog: Locator, name: string) => dialog.getByRole("slider", { exact: true, name });

/** Opens the popup and sets -1/4"N18" +1/8"T36" +1/8"T18" — the bend points read off the note. */
async function setRocker(page: Page, metric = false): Promise<Locator> {
  const dialog = await openCustomizeRocker(page);
  const note = dialog.locator("[data-customize-rocker-note]");
  await pressUntil(page, slider(dialog, "Nose rocker change"), "ArrowLeft", metric ? "-6 mm" : '-1/4"');
  const noseBend = slider(dialog, "Nose bend starts");
  await noseBend.focus();
  for (let i = 0; i < 60 && !(await note.innerText()).includes('-1/4"N18"'); i++) await page.keyboard.press("ArrowLeft");
  await pressUntil(page, slider(dialog, "Tail rocker change"), "ArrowRight", metric ? "+3 mm" : '+1/8"');
  const tailBend = slider(dialog, "Tail bend starts");
  await tailBend.focus();
  for (let i = 0; i < 60 && !(await note.innerText()).includes('+1/8"T36"'); i++) await page.keyboard.press("ArrowRight");
  await dialog.getByRole("button", { name: "+ Add a second tail change" }).click();
  await expect(note).toContainText('-1/4"N18" +1/8"T36" +1/8"T18"');
  await page.mouse.move(1, 1);
  await page.waitForTimeout(400);
  return dialog;
}

/** The drawing's real boxes, for the SUMMARY: the svg, its label scale, the foam's drawn length. */
async function measure(page: Page, label: string) {
  const sizes = await page.evaluate(() => {
    const box = (sel: string) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return `${r.width.toFixed(1)}×${r.height.toFixed(1)}`;
    };
    const svg = document.querySelector("[data-custom-rocker-drawing] svg[role='img']");
    return {
      viewport: `${window.innerWidth}×${window.innerHeight}`,
      card: box("[data-custom-rocker-drawing]"),
      svg: box("[data-custom-rocker-drawing] svg[role='img']"),
      viewBox: svg?.getAttribute("viewBox"),
      labelScale: svg?.getAttribute("data-blank-view-label-scale"),
      foam: box("[data-custom-rocker-drawing] [data-blank-silhouette]"),
      board: box("[data-custom-rocker-drawing] [data-board-silhouette]"),
    };
  });
  console.log(`[ojc boxes] ${label}: ${JSON.stringify(sizes)}`);
}

async function shot(page: Page, name: string) {
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/${name}` });
}

test("computer", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page);
  const dialog = await setRocker(page);
  await measure(page, "computer, board off");
  await shot(page, "ojc-computer-off.png");
  await dialog.locator("[data-show-board]").click();
  await measure(page, "computer, board on");
  await shot(page, "ojc-computer-on.png");
});

test("computer in Daylight", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page, { theme: "daylight" });
  const dialog = await setRocker(page);
  await shot(page, "ojc-computer-off-daylight.png");
  await dialog.locator("[data-show-board]").click();
  await shot(page, "ojc-computer-on-daylight.png");
});

test("computer in Metric", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "computer");
  await setup(page, { metric: true });
  const dialog = await setRocker(page, true);
  await dialog.locator("[data-show-board]").click();
  await measure(page, "computer, Metric, board on");
  await shot(page, "ojc-computer-on-metric.png");
});

test("iPhone upright", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "iphone");
  await setup(page);
  const dialog = await setRocker(page);
  await measure(page, "iPhone upright, board off");
  await shot(page, "ojc-iphone-off.png");
  await dialog.locator("[data-show-board]").click();
  await measure(page, "iPhone upright, board on");
  await shot(page, "ojc-iphone-on.png");
  await dialog.locator("[data-show-dimensions]").click();
  await measure(page, "iPhone upright, board on, Dimensions off");
  await shot(page, "ojc-iphone-on-no-dimensions.png");
});

test("Pixel 7 sideways", async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== "pixel7-sideways");
  await setup(page);
  const dialog = await setRocker(page);
  await dialog.locator("[data-show-board]").click();
  await measure(page, "Pixel 7 sideways, board on");
  await shot(page, "ojc-pixel7-sideways-on.png");
  await dialog.locator("[data-show-dimensions]").click();
  await measure(page, "Pixel 7 sideways, board on, Dimensions off");
  await shot(page, "ojc-pixel7-sideways-on-no-dimensions.png");
});

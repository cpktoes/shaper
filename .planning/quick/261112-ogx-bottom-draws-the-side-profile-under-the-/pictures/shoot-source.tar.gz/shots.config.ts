// Quick 261112-lmr's picture script: the worktree's own Playwright config, pointed at this folder's spec, with the dev
// server started in (or reused from) the worktree on PW_PORT. Scratch only, archived as pictures/shoot-source.tar.gz.
import { defineConfig } from "@playwright/test";
import base from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/playwright.config";

const WORKTREE = "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17";
const server = Array.isArray(base.webServer) ? base.webServer[0] : base.webServer;

export default defineConfig({
  ...base,
  testDir: "/private/tmp/claude-501/-Users-kontoes-Code-shaper/86389bad-1284-4de0-86f8-1a82686fc51e/scratchpad/ogx/shoot",
  testMatch: "shots.spec.ts",
  testIgnore: [],
  timeout: 180_000,
  webServer: { ...server!, cwd: WORKTREE, reuseExistingServer: true },
});

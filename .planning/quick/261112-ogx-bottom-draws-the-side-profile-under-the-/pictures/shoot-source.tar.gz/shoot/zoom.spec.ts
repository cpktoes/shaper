// Quick 261112-ogx: side view zoomed in both themes (the dashed rail line against the ink edge), and the section box at 1280 x 900.
import { expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/blanks/preset-blanks";
import { DEFAULT_BOTTOM, pickCut } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/bottom";
import { LIVE_DESIGN_RULES, designBottomBoard, designFinPlacement, designSideProfile } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/banner-dismissal";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/toolbar-tip";

const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/.planning/quick/261112-ogx-bottom-draws-the-side-profile-under-the-/pictures";

async function open(page: Page, theme: string) {
  const preset = BOARD_PRESETS.find((p) => p.name === "Shortboard")!;
  const f = { ...presetDesignFields(preset), volume: DEFAULT_VOLUME_SPEC, finsImportTemplate: true, railsImportFoilThickness: true, boardName: "", finSystem: "fcs2" as const };
  const b = designBottomBoard(f.outline, buildOutline(f.outline), designSideProfile(f, LIVE_DESIGN_RULES), designFinPlacement(f));
  const raw = openBoardCopyJson({ ...f, bottom: pickCut(DEFAULT_BOTTOM, "center", "Deep Single Concave", b) }, { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([k1, k2, k3, v, t]) => {
      sessionStorage.setItem(k1, "true");
      localStorage.setItem(k2, "true");
      localStorage.setItem(k3, v);
      localStorage.setItem("shaper-theme", t);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, theme] as const,
  );
  await page.goto("/design/bottom");
  await expect(page.locator("[data-bottom-side-view]")).toHaveAttribute("data-height", /\d/, { timeout: 60_000 });
  await page.waitForTimeout(800);
}

test.describe("zoom", () => {
  test.use({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 3 });
  for (const theme of ["daylight", "slate"]) {
    test(`side view zoom ${theme}`, async ({ page }) => {
      await open(page, theme);
      const box = (await page.locator("[data-bottom-box=side]").boundingBox())!;
      await page.screenshot({ path: `${PICTURES}/bottom-desktop-side-zoom-${theme}.png`, clip: { x: box.x + 90, y: box.y - 30, width: 700, height: box.height + 70 } });
    });
  }
  test("section box at 1280x900", async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 900 });
    await open(page, "daylight");
    console.log("BOX900", JSON.stringify(await page.locator("[data-bottom-box=section]").boundingBox()));
  });
});

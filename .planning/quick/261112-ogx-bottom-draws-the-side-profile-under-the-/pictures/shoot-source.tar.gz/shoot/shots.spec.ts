// Quick 261112-ogx's picture script: BOTTOM's VIEWER with its side view, on a computer (light and dark on the Deep Single
// Shortboard, a Rolled Vee, a flat board, at x4, Metric), an upright iPhone and a sideways one, and the Board file
// preview at x1. Scratch only, archived as pictures/shoot-source.tar.gz.
import { devices, expect, test, type Page } from "@playwright/test";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/blanks/preset-blanks";
import { DEFAULT_BOTTOM, pickCut, type BoardBottom } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/bottom";
import { LIVE_DESIGN_RULES, designBottomBoard, designFinPlacement, designSideProfile } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/volume";
import { BANNER_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/banner-dismissal";
import { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/open-board";
import { TOOLBAR_TIP_DISMISSAL_KEY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/models/toolbar-tip";
import { THREE_D_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/components/3d/three-d-copy";
import { BOTTOM_COPY } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/components/bottom/bottom-copy";

function strip<T extends { defaultBrowserType?: unknown }>(device: T) {
  const { defaultBrowserType, ...rest } = device;
  void defaultBrowserType;
  return rest;
}

const PICTURES =
  "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/.planning/quick/261112-ogx-bottom-draws-the-side-profile-under-the-/pictures";

function fieldsOf(name: string, bottom?: BoardBottom) {
  const preset = BOARD_PRESETS.find((p) => p.name === name)!;
  return {
    ...presetDesignFields(preset),
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2" as const,
    ...(bottom ? { bottom } : {}),
  };
}

function boardOf(name: string) {
  const f = fieldsOf(name);
  return designBottomBoard(f.outline, buildOutline(f.outline), designSideProfile(f, LIVE_DESIGN_RULES), designFinPlacement(f));
}
const deepSingle = (name: string): BoardBottom => pickCut(DEFAULT_BOTTOM, "center", "Deep Single Concave", boardOf(name));
const rolledVee = (name: string): BoardBottom => pickCut(DEFAULT_BOTTOM, "tail", "Rolled Vee", boardOf(name));

async function seed(page: Page, name: string, theme: "daylight" | "slate", bottom?: BoardBottom, metric = false) {
  const raw = openBoardCopyJson(fieldsOf(name, bottom), { modelId: null, ownerId: null, locked: false, dirty: true });
  await page.addInitScript(
    ([bannerKey, tipKey, boardKey, board, themeValue]) => {
      window.sessionStorage.setItem(bannerKey, "true");
      window.localStorage.setItem(tipKey, "true");
      window.localStorage.setItem(boardKey, board);
      window.localStorage.setItem("shaper-theme", themeValue);
    },
    [BANNER_DISMISSAL_KEY, TOOLBAR_TIP_DISMISSAL_KEY, OPEN_BOARD_STORAGE_KEY, raw, theme] as const,
  );
  if (metric) {
    await page.addInitScript(() => window.localStorage.setItem("shaper-units", "metric"));
    await page.context().addCookies([{ name: "shaper-units", value: "metric", domain: "localhost", path: "/" }]);
  }
  await page.addInitScript(() => {
    const st = document.createElement("style");
    st.textContent = "nextjs-portal{display:none !important}";
    document.addEventListener("DOMContentLoaded", () => document.head.appendChild(st));
  });
}

async function openBottom(page: Page) {
  await page.goto("/design/bottom");
  await expect(page.locator("[data-bottom-side-view]")).toHaveAttribute("data-height", /\d/, { timeout: 60_000 });
  await page.waitForTimeout(800);
}

const desktop = { viewport: { width: 1280, height: 800 } };

test.describe("desktop", () => {
  test.use(desktop);
  test("deep single light", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"));
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-deep-single.png` });
  });
  test("deep single slate", async ({ page }) => {
    await seed(page, "Shortboard", "slate", deepSingle("Shortboard"));
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-deep-single-slate.png` });
  });
  test("rolled vee", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", rolledVee("Shortboard"));
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-rolled-vee.png` });
  });
  test("flat", async ({ page }) => {
    await seed(page, "Shortboard", "daylight");
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-flat.png` });
  });
  test("x4", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"));
    await openBottom(page);
    await page.getByRole("button", { name: BOTTOM_COPY.sideHeightButtonName(4), exact: true }).click();
    await page.waitForTimeout(500);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-x4.png` });
  });
  test("metric", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"), true);
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-desktop-metric.png` });
  });
});

test.describe("iphone upright", () => {
  test.use({ ...strip(devices["iPhone 14"]), viewport: { width: 390, height: 844 } });
  test("upright", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"));
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-phone-upright.png` });
  });
});

test.describe("iphone sideways", () => {
  test.use(strip(devices["iPhone 14 landscape"]));
  test("sideways", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"));
    await openBottom(page);
    await page.screenshot({ path: `${PICTURES}/bottom-phone-sideways-top.png` });
    await page.locator("[data-bottom-section-at]").scrollIntoViewIfNeeded();
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${PICTURES}/bottom-phone-sideways.png` });
  });
});

test.describe("preview", () => {
  test.use(desktop);
  test("preview at x1", async ({ page }) => {
    await seed(page, "Shortboard", "daylight", deepSingle("Shortboard"));
    await page.goto("/design/3d");
    await expect(page.locator("[data-board-3d]")).toHaveAttribute("data-board-state", "ready", { timeout: 60_000 });
    await page.getByRole("button", { name: THREE_D_COPY.exportButton, exact: true }).click();
    const dialog = page.locator("[data-brd-preview]");
    await expect(dialog).toBeVisible();
    await expect(dialog.locator("[data-brd-preview-top] [data-brd-slice]").first()).toBeAttached();
    await page.waitForTimeout(600);
    await page.locator("[data-brd-preview-body]").evaluate((el) => el.scrollTo({ top: el.scrollHeight }));
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${PICTURES}/preview-x1.png` });
  });
});

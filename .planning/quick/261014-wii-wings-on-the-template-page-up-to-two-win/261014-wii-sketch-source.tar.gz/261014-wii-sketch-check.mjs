import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
const require = createRequire(import.meta.url);
const C = require("./curves.js");
const data = JSON.parse(readFileSync(new URL("./sketch013-data.json", import.meta.url)));
const b = data.boards[0], sp = b.spec;
const g = C.buildOutline({ length: sp.lengthIn, widePointWidth: sp.widePointWidthIn, widePointOffset: sp.widePointOffsetIn, tailRailLength: sp.tailRailLength, noseRailLength: sp.noseRailLength, noseAngle: sp.noseAngle, noseFullness: sp.noseFullness, tailAngle: sp.tailAngle, tailFullness: sp.tailFullness, tail: { kind: sp.tail.kind, endWidth: sp.tail.endWidthIn } });
let ok = true;
for (const w of [{ on: true, station: 11, depth: 0.375, run: 0, smoothing: 0 }, { on: true, station: 11, depth: 0.375, run: 0, smoothing: 3 }, { on: true, station: 11, depth: 0.375, run: 1, smoothing: 3 }, { on: true, station: 11, depth: 1, run: 0.5, smoothing: 0.25 }, { on: true, station: 30, depth: 0.5, run: 0.5, smoothing: 1 }]) {
  const f = C.wingFootprint(w), R = C.effectiveRadius(w), Rmax = C.maxRadius(w);
  let prev = -1, mono = true, maxJump = 0;
  for (let s = f.hi + 0.5; s >= f.lo - 0.5; s -= 0.001) { const p = C.stepProfile(w, s); if (p < prev - 1e-9) mono = false; if (prev >= 0) maxJump = Math.max(maxJump, p - prev); prev = p; }
  const pts = C.wingedPoints(g, [w], "a");
  const over = Math.max(...pts.map((p) => p[1] - g.cw)), under = Math.min(...pts.map((p) => p[1]));
  const block = 2 * C.wingedHalfWidth(g, [w], "a", g.tailPodStation + 1e-9);
  console.log(`run ${w.run}" depth ${w.depth}" radius asked ${w.smoothing}" → fits ${Rmax.toFixed(3)}", used ${R.toFixed(3)}"; step from ${f.hi.toFixed(3)}" to ${f.lo.toFixed(3)}" (${(f.hi - f.lo).toFixed(3)}" long); profile monotone ${mono}, largest step ${maxJump.toFixed(4)}; A keeps block ${block.toFixed(3)}; never above widepoint ${over <= 1e-9}, min hw ${under.toFixed(3)}`);
  if (!mono || over > 1e-9 || under < -1e-9 || Math.abs(block - 2 * g.bw) > 1e-6) { ok = false; console.log("   FAIL:", { mono, over, under, block, bw2: 2 * g.bw }); }
  // the rounded step's shape is a circle of radius R at each end: check the first arc's points are R from its centre
  if (R > 0) { const sh = f.shape, C1 = { x: w.station + sh.t, y: R }; const dev = Math.max(...sh.points.slice(0, 8).map((p) => Math.abs(Math.hypot(p.x - C1.x, p.y - C1.y) - R))); if (dev > 1e-9) { ok = false; console.log("   arc deviates", dev); } }
}
// with no rounding the step is exactly the straight step from (S,0) to (S-r,d)
const w0 = { on: true, station: 11, depth: 0.375, run: 0.5, smoothing: 0 };
console.log("no rounding: share at 10.75\" =", C.stepProfile(w0, 10.75).toFixed(3), "(expect 0.500)");
if (Math.abs(C.stepProfile(w0, 10.75) - 0.5) > 1e-9) ok = false;
console.log(ok ? "ALL CHECKS PASS" : "CHECKS FAILED");

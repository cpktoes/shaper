Quick 261127-kkw (a centre-to-nose rail blend control, like the tail's): the executor's scratch scripts and the
before/after measurements. Packed 2026-11-27 from worktree base 16b4e97c; code commits 0540a199 (the record),
f1169096 (RAILS), 982b7c10 (3D), 12ec7961 (GUIDE).

No .brd file is in here and none must ever be: the founder's sample files were read where they are, in ~/Downloads,
by the earlier task's measure.mts (packed in .planning/quick/261125-v2f-.../261125-v2f-scripts.tar.gz, not repeated here).
Extract into a NEW, EMPTY folder in a scratchpad (never under the repo or a worktree) and call scripts by absolute path.

scripts/
  kkw-presets.mts   the four presets as their cards open them today (presetDesignFields, the live blank pick): litres to
                    17 digits, the 3D surface's SHA-256 and the .brd file's SHA-256, through the record's own helpers
                    (lib/geometry/__fixtures__/nose-blend-boards.ts).
                      ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json <X>/scripts/kkw-presets.mts
  kkw-moves.mts     what the two sliders move, for the SUMMARY (no test types these figures): the litres of the stock 6'0",
                    the same board with the nose's Symmetrical ticked and the Shortboard, untouched, with Ends At at 14" and
                    with Blends From at 30"; and what the sliders show and how far they run on eight board lengths.
  shots-t2.mjs      pictures of the nose rail's rows on RAILS (a computer, a Pixel 7) and on 3D with Rail Blend Controls
                    open; needs the suite's dev server on port 3161.   node shots-t2.mjs <checkout> <outDir>
  shots-t3.mts      pictures of the new GUIDE card and the tail's beside it on the Shortboard, the Longboard, a 4'0" board
                    and a Shortboard with 18"/30" stored, on a computer and at a 360-wide phone; same dev server.
                      ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json shots-t3.mts <outDir>

out/
  kkw-presets-before.txt / kkw-presets-after.txt   kkw-presets.mts on the untouched code (base 16b4e97c plus the record's
                                                   own fixture file) and after the three code commits. Identical, line for line.
  kkw-t12-before.json / .log                       the earlier task's measure.mts, label kkw-t12-before, one open each, on the
                                                   untouched code: "12 files", no "!!" line.
  kkw-t12-after.json / .log                        the same after the change: "12 files", no "!!" line.
  same-kkw-t12-before-kkw-t12-after.txt            same.mjs's line: 12 files compared, 0 differ.
  kkw-moves.txt                                    kkw-moves.mts's output after the change.

The record itself (142 litres, 44 3D shapes, 12 board files) is not here: it is lib/geometry/__fixtures__/nose-blend-pin.json,
written once by scripts/extract-nose-blend-pin.ts in commit 0540a199 and held by lib/geometry/nose-blend-pin.test.ts.

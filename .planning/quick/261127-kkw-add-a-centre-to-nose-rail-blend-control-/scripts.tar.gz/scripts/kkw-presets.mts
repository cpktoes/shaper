// Quick 261127-kkw: the four presets as their cards open them TODAY (presetDesignFields, the live blank pick),
// litres to 17 digits, the 3D surface's digest and the .brd file's digest. Run before and after the change:
//   ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json <X>/scripts/kkw-presets.mts > out/kkw-presets-<when>.txt
const ROOT = process.env.ROOT;
if (!ROOT) throw new Error("set ROOT to the checkout");
const { BOARD_PRESETS } = await import(`${ROOT}/lib/geometry/presets.ts`);
const { presetDesignFields } = await import(`${ROOT}/lib/blanks/preset-blanks.ts`);
const { DEFAULT_VOLUME_SPEC } = await import(`${ROOT}/lib/geometry/volume.ts`);
const { summarizeDesign } = await import(`${ROOT}/lib/geometry/design.ts`);
const { noseBlendSurface, noseBlendSurfaceDigest, noseBlendFileDigest } = await import(
  `${ROOT}/lib/geometry/__fixtures__/nose-blend-boards.ts`
);
for (const preset of BOARD_PRESETS) {
  const fields = { ...presetDesignFields(preset), railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
  const surface = noseBlendSurface(fields);
  console.log(
    `${preset.id}: ${summarizeDesign(fields).volumeLitres.toPrecision(17)} L, surface ${noseBlendSurfaceDigest(surface)}, file ${noseBlendFileDigest(surface)}`,
  );
}

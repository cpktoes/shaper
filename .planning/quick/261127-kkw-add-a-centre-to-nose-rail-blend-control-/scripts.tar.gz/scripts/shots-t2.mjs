// Quick 261127-kkw, Task 2: pictures of the nose rail's rows on RAILS (a computer and a phone) and on 3D.
//   node shots-t2.mjs <worktree> <outDir>
import { createRequire } from "node:module";
const [root, out] = process.argv.slice(2);
const require = createRequire(`${root}/package.json`);
const { chromium, devices } = require("playwright");
const base = "http://localhost:3161";

async function prep(context) {
  await context.addInitScript(() => {
    window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
    window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
  });
}

async function openAdvanced(page, key) {
  const group = page.locator(`[data-rail-group="${key}"]`);
  const heading = group.getByRole("button", { name: /^Advanced [▾▸]$/ });
  for (let i = 0; i < 30; i++) {
    if (await group.getByRole("button", { name: /Reset Advanced Settings/ }).isVisible().catch(() => false)) break;
    await heading.click().catch(() => {});
    await page.waitForTimeout(500);
  }
  return group;
}

const browser = await chromium.launch();

// RAILS on a computer.
{
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await prep(context);
  const page = await context.newPage();
  await page.goto(`${base}/design/rails`);
  await page.waitForFunction(() => {
    const b = document.querySelector("[data-viewer-toolbar] button");
    return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
  });
  const nose = await openAdvanced(page, "nose");
  await page.getByRole("slider", { name: "Nose Rail ends at", exact: true }).press("PageDown");
  await nose.getByText(/^Nose Rail Blends From — /).scrollIntoViewIfNeeded();
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${out}/rails-nose-advanced-desktop.png` });
  await nose.screenshot({ path: `${out}/rails-nose-card-desktop.png` });
  await context.close();
}

// RAILS on a phone (Pixel 7).
{
  const context = await browser.newContext({ ...devices["Pixel 7"] });
  await prep(context);
  const page = await context.newPage();
  await page.goto(`${base}/design/rails`);
  await page.waitForFunction(() => {
    const b = document.querySelector("[data-viewer-toolbar] button");
    return !!b && Object.keys(b).some((k) => k.startsWith("__reactProps"));
  });
  const nose = await openAdvanced(page, "nose");
  await nose.getByText(/^Nose Rail Ends At — /).scrollIntoViewIfNeeded();
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${out}/rails-nose-advanced-phone.png` });
  await context.close();
}

// 3D on a computer, Rail Blend Controls open.
{
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  await prep(context);
  const page = await context.newPage();
  await page.goto(`${base}/design/3d`);
  const fold = page.getByRole("button", { name: /Rail Blend Controls/ });
  for (let i = 0; i < 60; i++) {
    if ((await fold.getAttribute("aria-expanded").catch(() => null)) === "true") break;
    await fold.click().catch(() => {});
    await page.waitForTimeout(500);
  }
  await page.locator("[data-three-d-tail-rail]").scrollIntoViewIfNeeded();
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${out}/three-d-rail-blend-desktop.png` });
  await page.locator("[data-three-d-rail-blend]").screenshot({ path: `${out}/three-d-rail-blend-group-desktop.png` });
  await context.close();
}

await browser.close();
console.log("done");

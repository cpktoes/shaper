// Quick 261127-kkw, Task 3: pictures of the new GUIDE card (Nose Rail Blends From · Nose Rail Ends At) and the tail's
// beside it, on the Shortboard, the Longboard and a 4'0" board, on a computer and at a 360-wide phone.
//   ROOT=<worktree> npx --no-install tsx --tsconfig <worktree>/tsconfig.json shots-t3.mts <outDir>
import { createRequire } from "node:module";
const ROOT = process.env.ROOT!;
const out = process.argv[2];
const require = createRequire(`${ROOT}/package.json`);
const { chromium } = require("playwright");
const { BOARD_PRESETS } = await import(`${ROOT}/lib/geometry/presets.ts`);
const { presetDesignFields } = await import(`${ROOT}/lib/blanks/preset-blanks.ts`);
const { DEFAULT_BOARD_SPEC } = await import(`${ROOT}/lib/geometry/board.ts`);
const { holdOutlineToLength } = await import(`${ROOT}/lib/geometry/board-size.ts`);
const { DEFAULT_RAIL_BAND_SPEC } = await import(`${ROOT}/lib/geometry/rail-bands.ts`);
const { DEFAULT_FIN_PLACEMENT_SPEC } = await import(`${ROOT}/lib/geometry/fins.ts`);
const { DEFAULT_VOLUME_SPEC } = await import(`${ROOT}/lib/geometry/volume.ts`);
const { inchesToMm } = await import(`${ROOT}/lib/geometry/units.ts`);
const { OPEN_BOARD_STORAGE_KEY, openBoardCopyJson } = await import(`${ROOT}/lib/models/open-board.ts`);
const { RAILS_GUIDE_CARD_IDS } = await import(`${ROOT}/lib/geometry/guide-rails.ts`);

const rest = { volume: DEFAULT_VOLUME_SPEC, finsImportTemplate: true, railsImportFoilThickness: true, boardName: "", finSystem: "fcs2" };
const preset = (id: string) => ({ ...presetDesignFields(BOARD_PRESETS.find((p: { id: string }) => p.id === id)), ...rest });
const boards: Record<string, unknown> = {
  shortboard: preset("shortboard"),
  longboard: preset("longboard"),
  "four-foot": {
    outline: holdOutlineToLength({ ...DEFAULT_BOARD_SPEC.outline, length: inchesToMm(48) }),
    rocker: DEFAULT_BOARD_SPEC.rocker,
    foil: DEFAULT_BOARD_SPEC.foil,
    rails: DEFAULT_RAIL_BAND_SPEC,
    fins: DEFAULT_FIN_PLACEMENT_SPEC,
    blank: null,
    ...rest,
  },
  "shortboard-stored-18-30": { ...preset("shortboard"), rails: { ...preset("shortboard").rails, noseRailBlendsFrom: inchesToMm(18), noseRailEndsAt: inchesToMm(30) } },
};

const browser = await chromium.launch();
for (const [name, fields] of Object.entries(boards)) {
  const raw = openBoardCopyJson(fields, { modelId: null, ownerId: null, locked: false, dirty: true });
  for (const [device, viewport, scale] of [
    ["desktop", { width: 1280, height: 800 }, 2],
    ["phone360", { width: 360, height: 780 }, 3],
  ] as const) {
    const context = await browser.newContext({ viewport, deviceScaleFactor: scale, hasTouch: device !== "desktop", isMobile: device !== "desktop" });
    await context.addInitScript(
      ([key, value]: [string, string]) => {
        window.sessionStorage.setItem("shaper-sign-in-banner-dismissed", "true");
        window.localStorage.setItem("shaper-toolbar-tip-dismissed", "true");
        window.localStorage.setItem(key, value);
      },
      [OPEN_BOARD_STORAGE_KEY, raw],
    );
    const page = await context.newPage();
    await page.goto("http://localhost:3161/design/rails");
    const tab = page.getByRole("tab", { name: "GUIDE", exact: true });
    for (let i = 0; i < 60; i++) {
      await tab.click({ timeout: 2000 }).catch(() => {});
      if (await page.locator("[data-guide]").isVisible().catch(() => false)) break;
      await page.waitForTimeout(500);
    }
    await page.waitForTimeout(1500);
    for (const [which, id] of [["nose", RAILS_GUIDE_CARD_IDS.noseBlends], ["tail", RAILS_GUIDE_CARD_IDS.blends]] as const) {
      const card = page.locator(`[data-guide] [data-guide-card="${id}"]`);
      await card.scrollIntoViewIfNeeded();
      await page.waitForTimeout(300);
      await card.screenshot({ path: `${out}/guide-${which}-${name}-${device}.png` });
    }
    console.log(`${name} ${device}: ${await page.locator("[data-guide] [data-guide-card]").count()} cards`);
    await context.close();
  }
}
await browser.close();

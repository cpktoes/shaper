// Quick 261127-kkw: what the nose's two sliders move, for the SUMMARY (no test types these figures).
//   ROOT=<checkout> npx --no-install tsx --tsconfig <checkout>/tsconfig.json <X>/scripts/kkw-moves.mts
const ROOT = process.env.ROOT;
if (!ROOT) throw new Error("set ROOT to the checkout");
const { noseBlendSweepBoards } = await import(`${ROOT}/lib/geometry/__fixtures__/nose-blend-boards.ts`);
const { phase16LiveBoards } = await import(`${ROOT}/lib/geometry/__fixtures__/phase16-boards.ts`);
const { summarizeDesign } = await import(`${ROOT}/lib/geometry/design.ts`);
const { inchesToMm, mmToInches } = await import(`${ROOT}/lib/geometry/units.ts`);
const { noseBlendsFrom, noseEndsAt, hardEdgeBlendsFromWindow, hardEdgeEndsAtWindow, hardEdgeWindowOnGrid } = await import(
  `${ROOT}/lib/geometry/rail-bands.ts`
);
type Fields = { outline: { length: number }; rails: Record<string, unknown> };
const litres = (fields: Fields, nose: Record<string, number> = {}) =>
  summarizeDesign({ ...fields, rails: { ...fields.rails, ...nose } }).volumeLitres;
const show = (label: string, fields: Fields) => {
  const untouched = litres(fields);
  const short = litres(fields, { noseRailEndsAt: inchesToMm(14) });
  const long = litres(fields, { noseRailBlendsFrom: inchesToMm(30) });
  console.log(`${label}: untouched ${untouched.toFixed(4)} L, Ends At 14" ${short.toFixed(4)} L, Blends From 30" ${long.toFixed(4)} L`);
};
const sweep = noseBlendSweepBoards();
const live = phase16LiveBoards();
show("stock 6'0\" (nose rail = centre's)", live.find((b: { label: string }) => b.label === "stock|hard").fields);
show("stock 6'0\", nose Symmetrical", sweep.find((b: { label: string }) => b.label === "sweep|72|symmetrical").fields);
show("Shortboard preset", live.find((b: { label: string }) => b.label === "shortboard|asis|hard").fields);
for (const lengthIn of [48, 56, 60, 63.5, 72, 73.875, 108, 144]) {
  const L = inchesToMm(lengthIn);
  const from = noseBlendsFrom({}, L);
  const ends = noseEndsAt({}, L);
  const fromTop = hardEdgeWindowOnGrid(hardEdgeBlendsFromWindow(ends, L)).max;
  const endsWindow = hardEdgeWindowOnGrid(hardEdgeEndsAtWindow(from, L));
  console.log(
    `${lengthIn}": shows ${mmToInches(from)}" / ${mmToInches(ends)}"; Blends From 12" to ${fromTop}"; Ends At ${endsWindow.min}" to ${endsWindow.max}"; true centre ${lengthIn / 2}"`,
  );
}

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
const here = new URL(".", import.meta.url);
const raw = JSON.parse(readFileSync(new URL("./sketch013-data.json", here)));
// Embed only what the page needs: the spec (the port rebuilds the curve), the app's 161 points (for the check
// readout and the ghost), the fin marks and the 12" widths.
const data = { boards: raw.boards.map((b) => ({ id: b.id, name: b.name, spec: b.spec, points: b.points, marks: b.marks, finSetup: b.finSetup, tailWidthAt12In: b.tailWidthAt12In, noseWidthAt12In: b.noseWidthAt12In, areaSqIn: b.areaSqIn, widePointStationIn: b.widePointStationIn })) };
const curves = readFileSync(new URL("./curves.js", here), "utf8").replace(/\nif \(typeof module[^\n]*\n?/, "\n");
const html = readFileSync(new URL("./template.html", here), "utf8")
  .replace("/*__DATA__*/", JSON.stringify(data))
  .replace("/*__CURVES__*/", curves.trim());
const dir = "/Users/kontoes/Code/shaper/.planning/sketches/013-wings-on-the-outline";
mkdirSync(dir, { recursive: true });
const out = `${dir}/index.html`;
writeFileSync(out, html);
console.log("wrote", out, html.length, "bytes");

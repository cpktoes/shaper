import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
const require = createRequire(import.meta.url);
const C = require("./curves.js");
const data = JSON.parse(readFileSync(new URL("./sketch013-data.json", import.meta.url)));
const specOf = (s) => ({ length: s.lengthIn, widePointWidth: s.widePointWidthIn, widePointOffset: s.widePointOffsetIn, tailRailLength: s.tailRailLength, noseRailLength: s.noseRailLength, noseAngle: s.noseAngle, noseFullness: s.noseFullness, tailAngle: s.tailAngle, tailFullness: s.tailFullness, tail: { kind: s.tail.kind, endWidth: s.tail.endWidthIn, depth: s.tail.depthIn, crotchDepth: s.tail.crotchDepthIn } });
let allOk = true;
for (const b of data.boards) {
  const g = C.buildOutline(specOf(b.spec));
  let worst = 0, worstS = 0;
  if (g.points.length !== b.points.length) { console.log(`${b.name}: POINT COUNT ${g.points.length} vs app ${b.points.length}`); allOk = false; }
  for (let i = 0; i < Math.min(g.points.length, b.points.length); i++) { const d = Math.max(Math.abs(g.points[i][0] - b.points[i][0]), Math.abs(g.points[i][1] - b.points[i][1])); if (d > worst) { worst = d; worstS = b.points[i][0]; } }
  const d12 = Math.max(Math.abs(g.tailWidthAt12 - b.tailWidthAt12In), Math.abs(g.noseWidthAt12 - b.noseWidthAt12In));
  // exact curve vs the app's polyline at every app point
  let worstExact = 0; for (const [s, hw] of b.points) worstExact = Math.max(worstExact, Math.abs(C.exactHalfWidthAt(g, s) - hw));
  console.log(`${b.name}: port vs app max |Δ| = ${worst.toExponential(2)}" (at ${worstS.toFixed(1)}"), 12" widths |Δ| = ${d12.toExponential(2)}", exact curve vs app points max |Δ| = ${worstExact.toExponential(2)}"`);
  if (worst > 1e-5 || d12 > 1e-5 || worstExact > 1e-5) allOk = false;
  // wings: off = base exactly; on = never above the widepoint, never below 0; A keeps the block, B narrows it
  const off = [{ on: false }, { on: false }];
  const two = [{ on: true, station: 11, depth: 0.375, run: 0.25, smoothing: 0 }, { on: true, station: 15.5, depth: 0.25, run: 0, smoothing: 1.5 }];
  for (const v of ["a", "b", "c"]) {
    const pOff = C.wingedPoints(g, off, v), pOn = C.wingedPoints(g, two, v);
    let dOff = 0; for (const [s, hw] of pOff) dOff = Math.max(dOff, Math.abs(hw - C.exactHalfWidthAt(g, s)));
    const over = Math.max(...pOn.map((p) => p[1] - g.cw)), under = Math.min(...pOn.map((p) => p[1]));
    const blockOn = 2 * C.wingedHalfWidth(g, two, v, g.tailPodStation + 1e-9), blockBase = 2 * g.bw;
    const r = C.wingReadouts(g, two, v);
    const line = `   ${v.toUpperCase()}: wings off = base (max |Δ| ${dOff.toExponential(1)}), above widepoint by ${over.toExponential(1)}, min hw ${under.toFixed(3)}, block ${blockBase.toFixed(3)} → ${blockOn.toFixed(3)}, W1 ahead ${r[0].widthAhead.toFixed(3)} behind ${r[0].widthBehind.toFixed(3)} (base ${r[0].baseAhead.toFixed(3)}/${r[0].baseBehind.toFixed(3)}), W2 ahead ${r[1].widthAhead.toFixed(3)} behind ${r[1].widthBehind.toFixed(3)}, area ${C.areaOf(pOff).toFixed(1)} → ${C.areaOf(pOn).toFixed(1)} sq in`;
    console.log(line);
    if (dOff > 1e-9 || over > 1e-9 || under < -1e-9) allOk = false;
  }
}
// the step profile: 0 ahead, 1 behind, monotone through, continuous when smoothed
for (const w of [{ station: 11, depth: 1, run: 0, smoothing: 0 }, { station: 11, depth: 1, run: 1, smoothing: 0 }, { station: 11, depth: 1, run: 0, smoothing: 3 }, { station: 11, depth: 1, run: 0.5, smoothing: 1 }]) {
  let prev = -1, mono = true, maxJump = 0;
  for (let s = 12; s >= 6; s -= 0.001) { const p = C.stepProfile(w, s); if (p < prev - 1e-12) mono = false; if (prev >= 0) maxJump = Math.max(maxJump, p - prev); prev = p; }
  console.log(`profile run ${w.run} smoothing ${w.smoothing}: ahead ${C.stepProfile(w, 11.0001)}, behind ${C.stepProfile(w, 11 - w.run - w.smoothing - 1e-4)}, monotone ${mono}, largest step between 1/1000" samples ${maxJump.toFixed(4)}`);
  if (!mono) allOk = false;
}
console.log(allOk ? "ALL CHECKS PASS" : "CHECKS FAILED");

// Scratch: pull the real boards and their fin placement for sketch 013 out of the app's own geometry.
// Run from the repo root: npx --no-install tsx <this file>
import { writeFileSync } from "node:fs";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { DEFAULT_BOARD_SPEC, type OutlineSpec } from "/Users/kontoes/Code/shaper/lib/geometry/board";
import { buildOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { computeFinPlacement, DEFAULT_FIN_PLACEMENT_SPEC, importedFinTailFromOutline, type FinPlacementSpec } from "/Users/kontoes/Code/shaper/lib/geometry/fins";
import { mm, mmToInches } from "/Users/kontoes/Code/shaper/lib/geometry/units";

const inch = (v: number) => Number(mmToInches(mm(v)).toFixed(6));
const pt = (p: { x: number; y: number }) => [inch(p.x), inch(p.y)];

function specOut(o: OutlineSpec) {
  const tail: Record<string, unknown> = { kind: o.tail.kind };
  if ("endWidth" in o.tail) tail.endWidthIn = inch(o.tail.endWidth);
  if ("depth" in o.tail) tail.depthIn = inch(o.tail.depth);
  if ("crotchDepth" in o.tail) tail.crotchDepthIn = inch(o.tail.crotchDepth);
  return {
    lengthIn: inch(o.length), widePointWidthIn: inch(o.widePointWidth), widePointOffsetIn: inch(o.widePointOffset),
    tailRailLength: o.tailRailLength, noseRailLength: o.noseRailLength,
    noseAngle: o.noseAngle, noseFullness: o.noseFullness, tailAngle: o.tailAngle, tailFullness: o.tailFullness, tail,
  };
}

function boardOut(id: string, name: string, outline: OutlineSpec, fins: FinPlacementSpec) {
  const g = buildOutline(outline);
  // FINS with Import Template ticked: length, tail width at 12" and tail shape come from the drawn outline.
  const finSpec: FinPlacementSpec = { ...fins, boardLength: outline.length, tailWidth12: g.tailWidthAt12in, tailShape: outline.tail.kind };
  const placement = computeFinPlacement(finSpec, importedFinTailFromOutline(g));
  return {
    id, name,
    spec: specOut(outline),
    points: g.points.map((p) => [inch(p.station), inch(p.halfWidth)]),
    knots: g.knots.map((k) => ({ point: pt(k.point), tangent: k.tangent })),
    handles: g.handles.map((h) => ({ from: pt(h.from), to: pt(h.to) })),
    segments: g.segments.map((s) => ({ p0: pt(s.p0), c0: pt(s.c0), c1: pt(s.c1), p1: pt(s.p1) })),
    widePointStationIn: inch(g.widePointStation), tailPodStationIn: inch(g.tailPodStation), centreCloseStationIn: inch(g.centreCloseStation),
    halfTailBlockWidthIn: inch(g.halfTailBlockWidth), tailBlockPinned: g.tailBlockPinned,
    tailWidthAt12In: inch(g.tailWidthAt12in), noseWidthAt12In: inch(g.noseWidthAt12in), areaSqIn: Number((g.area / 25.4 / 25.4).toFixed(4)),
    finSetup: finSpec.finSetup, frontModel: finSpec.frontModel,
    marks: placement.marks.map((m) => ({ role: m.role, side: m.side, offTailIn: inch(m.offTail), lateralIn: inch(m.lateral), leadingOffTailIn: inch(m.leadingOffTail), leadingLateralIn: inch(m.leadingLateral), baseLengthIn: inch(m.baseLength), toeIn: inch(m.toe) })),
    resolved: Object.fromEntries(Object.entries(placement.resolved).map(([k, v]) => [k, inch(v as number)])),
    modelHeader: placement.modelHeader,
  };
}

const boards = [
  boardOut("default", "Default board", DEFAULT_BOARD_SPEC.outline, DEFAULT_FIN_PLACEMENT_SPEC),
  ...BOARD_PRESETS.map((p) => boardOut(p.id, p.name, p.outline, p.fins)),
];
const path = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/b288fa20-4f5f-4fe4-bff7-04c98fd10bf4/scratchpad/s013/sketch013-data.json";
writeFileSync(path, JSON.stringify({ boards }));
for (const b of boards) {
  const front = b.marks.filter((m) => m.role === "front" && m.side === 1)[0] ?? b.marks.filter((m) => m.side === 1)[0];
  console.log(`${b.name}: ${b.spec.lengthIn}" x ${b.spec.widePointWidthIn}" ${b.spec.tail.kind}, tail12 ${b.tailWidthAt12In}", nose12 ${b.noseWidthAt12In}", ${b.finSetup}/${b.frontModel}; front fin trailing ${front?.offTailIn}" off tail, leading ${front?.leadingOffTailIn}", base ${front?.baseLengthIn}", in from stringer ${front?.lateralIn}"; marks: ${b.marks.map((m) => m.role + (m.side === 0 ? "" : m.side > 0 ? "R" : "L")).join(" ")}`);
}

/* curves.js — sketch 013. The app's outline curve (lib/geometry/outline.ts `buildOutline`), ported to inches
   line for line, plus the three wing constructions this sketch compares. Throwaway sketch code: the app's
   TypeScript stays the one truth, and check013.mjs proves this port reproduces its 161 points. */

const MARGIN = 16, DIAMOND_DEPTH_CAP = 5, DIAMOND_BLOCK_MARGIN = 2, MEASURE_STATION = 12;
const HANDLE_CAP = 0.48, OVERSHOOT = 0.92, SAMPLES_PER_SEGMENT = 80, EPSILON = 1e-6;
const railMult = (pct) => 0.8 + (pct / 100) * 0.8;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function tailHandleMaxLength(dirY, chord, cw, bw) {
  if (Math.abs(dirY) <= EPSILON) return HANDLE_CAP * chord;
  return Math.min(HANDLE_CAP * chord, (OVERSHOOT * (cw - bw)) / dirY);
}
function noseHandleMaxLength(dirY, chord, cw) {
  if (Math.abs(dirY) <= EPSILON) return HANDLE_CAP * chord;
  return Math.min(HANDLE_CAP * chord, (OVERSHOOT * cw) / Math.abs(dirY));
}
function bez1(p0, p1, p2, p3, t) { const mt = 1 - t; return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3; }

function interpolateHalfWidth(points, station) {
  for (let i = 0; i < points.length - 1; i++) {
    const [y0, x0] = points[i], [y1, x1] = points[i + 1];
    if (station >= y0 && station <= y1) { const t = y1 > y0 ? (station - y0) / (y1 - y0) : 0; return x0 + (x1 - x0) * t; }
  }
  return points[points.length - 1][1];
}

/* spec: { length, widePointWidth, widePointOffset, tailRailLength, noseRailLength, noseAngle, noseFullness,
   tailAngle, tailFullness, tail: { kind, endWidth?, depth?, crotchDepth? } } — inches and degrees. */
function buildOutline(spec) {
  const length = spec.length, cw = spec.widePointWidth / 2, tail = spec.tail;
  const tailBlockPinned = tail.kind === "pin" || tail.kind === "round";
  let bw = 0, tailPodStation = 0, centreCloseStation = 0, effectiveDiamondDepth = 0;
  switch (tail.kind) {
    case "pin": case "round": bw = 0; break;
    case "squash": bw = tail.endWidth / 2; break;
    case "diamond": bw = tail.endWidth / 2; effectiveDiamondDepth = Math.max(0, Math.min(tail.depth, DIAMOND_DEPTH_CAP, tail.endWidth - DIAMOND_BLOCK_MARGIN)); tailPodStation = effectiveDiamondDepth; break;
    case "swallow": bw = tail.endWidth / 2; centreCloseStation = tail.crotchDepth; break;
  }
  const widePointStation = Math.max(MARGIN, Math.min(length - MARGIN, length / 2 + spec.widePointOffset));
  const tailRad = (spec.tailAngle * Math.PI) / 180, noseRad = (spec.noseAngle * Math.PI) / 180;
  const dir0 = { x: Math.cos(tailRad), y: Math.sin(tailRad) }, dir4 = { x: Math.cos(noseRad), y: -Math.sin(noseRad) }, dir2 = { x: 1, y: 0 };
  const P0 = { x: tailPodStation, y: Math.max(0, bw) }, P2 = { x: widePointStation, y: cw }, P4 = { x: length, y: 0 };
  const knotPoints = [P0, P2, P4], knotDirs = [dir0, dir2, dir4];
  const chord = (a, b) => Math.hypot(b.x - a.x, b.y - a.y);
  const chords = [chord(P0, P2), chord(P2, P4)];
  const inLen0 = railMult(spec.tailRailLength) * HANDLE_CAP * chords[0];
  const outLen1 = railMult(spec.noseRailLength) * HANDLE_CAP * chords[1];
  const outLen0 = (spec.tailFullness / 100) * tailHandleMaxLength(dir0.y, chords[0], cw, P0.y);
  const inLen1 = (spec.noseFullness / 100) * noseHandleMaxLength(dir4.y, chords[1], cw);
  const outLen = [outLen0, outLen1], inLen = [inLen0, inLen1];
  const controls = [];
  for (let i = 0; i < 2; i++) {
    const A = knotPoints[i], Ad = knotDirs[i], B = knotPoints[i + 1], Bd = knotDirs[i + 1];
    controls.push({ c1: { x: A.x + outLen[i] * Ad.x, y: A.y + outLen[i] * Ad.y }, c2: { x: B.x - inLen[i] * Bd.x, y: B.y - inLen[i] * Bd.y } });
  }
  const raw = [];
  for (let seg = 0; seg < 2; seg++) {
    const A = knotPoints[seg], B = knotPoints[seg + 1], c = controls[seg], start = seg === 0 ? 0 : 1;
    for (let i = start; i <= SAMPLES_PER_SEGMENT; i++) {
      const t = i / SAMPLES_PER_SEGMENT;
      raw.push([bez1(A.x, c.c1.x, c.c2.x, B.x, t), Math.max(0, Math.min(bez1(A.y, c.c1.y, c.c2.y, B.y, t), cw))]);
    }
  }
  raw.sort((a, b) => a[0] - b[0]);
  const points = raw;
  const tailWidthAt12 = 2 * interpolateHalfWidth(points, Math.min(MEASURE_STATION, length));
  const noseWidthAt12 = 2 * interpolateHalfWidth(points, Math.max(0, length - MEASURE_STATION));
  let area = 0;
  for (let i = 0; i < raw.length - 1; i++) area += ((raw[i][1] + raw[i + 1][1]) / 2) * (raw[i + 1][0] - raw[i][0]);
  area *= 2;
  const segments = [0, 1].map((i) => ({ p0: knotPoints[i], c0: controls[i].c1, c1: controls[i].c2, p1: knotPoints[i + 1] }));
  return { spec, length, cw, bw, tailBlockPinned, widePointStation, tailPodStation, centreCloseStation, effectiveDiamondDepth, knots: knotPoints, dirs: knotDirs, controls, segments, points, tailWidthAt12, noseWidthAt12, area };
}

/* The exact curve (not the 161-point polyline) at a station, by solving the Bezier for its station. */
function exactHalfWidthAt(g, s) {
  if (s <= g.tailPodStation) return g.bw;
  if (s >= g.length) return 0;
  const seg = s <= g.widePointStation ? g.segments[0] : g.segments[1];
  let lo = 0, hi = 1;
  for (let i = 0; i < 60; i++) { const mid = (lo + hi) / 2; if (bez1(seg.p0.x, seg.c0.x, seg.c1.x, seg.p1.x, mid) < s) lo = mid; else hi = mid; }
  const t = (lo + hi) / 2;
  return clamp(bez1(seg.p0.y, seg.c0.y, seg.c1.y, seg.p1.y, t), 0, g.cw);
}
/* The exact curve's slope dy/ds at a station (for the key's angle readouts). */
function exactSlopeAt(g, s, h = 1e-3) { return (exactHalfWidthAt(g, s + h) - exactHalfWidthAt(g, s - h)) / (2 * h); }

/* ---- wings ----
   A wing: { on, station, depth, run, smoothing }. `station` is where the outline LEAVES the main curve (the
   nose-side edge of the step); the full depth is reached `run + smoothing` further toward the tail. `run` is
   the straight part of the step along the stringer (0 = square step); `smoothing` is spread half on each
   corner, easing them (0 = sharp corners). */
function wingFootprint(w) { return { hi: w.station, lo: w.station - w.run - w.smoothing, inner: w.station - w.run - w.smoothing }; }

/* Share of the depth taken at station s: 0 ahead of the step, 1 behind it, eased through it. */
function stepProfile(w, s) {
  const T = w.run + w.smoothing, hi = w.station, lo = hi - T;
  if (s >= hi) return 0;
  if (s <= lo || T <= 0) return 1;
  const u = (hi - s) / T;                 // 0 at the outer corner, 1 at the inner corner
  const a = (w.smoothing / 2) / T;        // eased share at each end, 0 (sharp) to 1/2 (all ease)
  if (a <= 0) return u;
  const k = 1 / (1 - a);
  if (u <= a) return (k * u * u) / (2 * a);
  if (u >= 1 - a) return 1 - (k * (1 - u) * (1 - u)) / (2 * a);
  return k * (u - a / 2);
}

/* Half-width at station s with the wings applied, under one of the three constructions:
   "a" — the tail is re-drawn to the block you set: each wing's depth fades to nothing at the tail pod.
   "b" — the tail is moved in: each wing's depth is carried all the way to the tail (the block narrows).
   "c" — a flyer: the tail is as drawn; the outline AHEAD of the wing is widened by the depth, fading out by the widepoint. */
function wingedHalfWidth(g, wings, variant, s) {
  const base = exactHalfWidthAt(g, s);
  if (s <= g.tailPodStation) {
    if (variant !== "b") return base;
    let hw = base; for (const w of wings) if (w.on) hw -= w.depth; return clamp(hw, 0, g.cw);
  }
  let hw = base;
  for (const w of wings) {
    if (!w.on) continue;
    const p = stepProfile(w, s), inner = wingFootprint(w).inner;
    if (variant === "a") {
      const fade = inner > g.tailPodStation ? clamp((s - g.tailPodStation) / (inner - g.tailPodStation), 0, 1) : 0;
      hw -= w.depth * p * fade;
    } else if (variant === "b") {
      hw -= w.depth * p;
    } else {
      const fadeWp = w.station < g.widePointStation ? clamp((g.widePointStation - s) / (g.widePointStation - w.station), 0, 1) : 0;
      hw += w.depth * (1 - p) * fadeWp;
    }
  }
  return clamp(hw, 0, g.cw);
}

/* A dense list of [station, halfWidth] for drawing: the app's own 161 stations, every 1/20" through the tail
   and every wing's own corners (twice, a hair apart, so a square step draws vertical). */
function wingedPoints(g, wings, variant, tailZoomTo = 30) {
  const st = new Set(g.points.map((p) => p[0]));
  for (let s = 0; s <= Math.min(tailZoomTo, g.length); s += 0.05) st.add(Number(s.toFixed(4)));
  for (const w of wings) if (w.on) {
    const f = wingFootprint(w);
    for (const s of [f.hi, f.lo, f.hi - w.smoothing / 2, f.lo + w.smoothing / 2]) { st.add(s); st.add(s - 1e-6); st.add(s + 1e-6); }
  }
  st.add(g.tailPodStation); st.add(g.widePointStation); st.add(g.length);
  const stations = [...st].filter((s) => s >= 0 && s <= g.length).sort((a, b) => a - b);
  return stations.map((s) => [s, wingedHalfWidth(g, wings, variant, s)]);
}

function areaOf(points) { let a = 0; for (let i = 0; i < points.length - 1; i++) a += ((points[i][1] + points[i + 1][1]) / 2) * (points[i + 1][0] - points[i][0]); return 2 * a; }

/* Readouts for the captions and the zoom's dimension lines. */
function wingReadouts(g, wings, variant) {
  return wings.map((w) => {
    if (!w.on) return null;
    const f = wingFootprint(w);
    return {
      station: w.station, inner: f.inner, depth: w.depth,
      widthAhead: 2 * wingedHalfWidth(g, wings, variant, f.hi + 1e-6),
      widthBehind: 2 * wingedHalfWidth(g, wings, variant, f.inner - 1e-6),
      baseAhead: 2 * exactHalfWidthAt(g, f.hi), baseBehind: 2 * exactHalfWidthAt(g, f.inner),
    };
  });
}

if (typeof module !== "undefined") module.exports = { buildOutline, exactHalfWidthAt, exactSlopeAt, stepProfile, wingFootprint, wingedHalfWidth, wingedPoints, areaOf, wingReadouts, interpolateHalfWidth, clamp };

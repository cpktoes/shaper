// Pictures of sketch 013 in headless Chromium: every tab in Slate and Daylight at 1440 wide, plus a phone width.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const { mkdirSync } = require("node:fs");
const dir = "/Users/kontoes/Code/shaper/.planning/sketches/013-wings-on-the-outline";
const pictures = `${dir}/pictures`;
mkdirSync(pictures, { recursive: true });
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const shots = [
    ...["a", "b", "c", "x"].flatMap((v) => ["slate", "daylight"].map((t) => ({ v, t, w: 1440, wings: "two", name: `${v}-${t}` }))),
    { v: "a", t: "slate", w: 1440, wings: "one", name: "a-slate-one-wing-sharp" },
    { v: "a", t: "slate", w: 390, wings: "two", name: "a-slate-phone" },
  ];
  for (const s of shots) {
    const page = await browser.newPage({ viewport: { width: s.w, height: 900 }, deviceScaleFactor: 2 });
    page.on("console", (m) => { if (m.type() === "error") errors.push(`${s.name}: ${m.text()}`); });
    page.on("pageerror", (e) => errors.push(`${s.name}: ${e.message}`));
    await page.addInitScript(({ v, t, wings }) => { localStorage.setItem("sketch013-picked", JSON.stringify({ variant: v, theme: t, wings })); }, s);
    await page.goto(`file://${dir}/index.html`);
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(250);
    await page.screenshot({ path: `${pictures}/${s.name}.png`, fullPage: true });
    console.log("shot", s.name);
    await page.close();
  }
  // the moment a wing is added: Show fins switches on and the popup asks the shaper to dial in the placement
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push(`popup: ${e.message}`));
  await page.addInitScript(() => { localStorage.setItem("sketch013-picked", JSON.stringify({ variant: "a", theme: "slate", wings: "none", showFins: false })); });
  await page.goto(`file://${dir}/index.html`);
  await page.evaluate(() => document.fonts.ready);
  await page.click('button[data-set="wings"][data-v="one"]');
  await page.waitForTimeout(250);
  await page.screenshot({ path: `${pictures}/popup-slate.png` });
  const finsOn = await page.$eval('input[data-check="showFins"]', (el) => el.checked);
  console.log("shot popup-slate; Show fins after adding a wing:", finsOn);
  await page.close();
  await browser.close();
  console.log(errors.length ? `CONSOLE ERRORS:\n${errors.join("\n")}` : "no console errors");
})();

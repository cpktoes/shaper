import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
const require = createRequire(import.meta.url);
const C = require("./curves.js");
const data = JSON.parse(readFileSync(new URL("./sketch012-data.json", import.meta.url)));
const all = [...data.presets.map((p) => ({ tag: p.name, record: p.record, todayWidth: p.todayWidth })), ...data.blanks.map((b) => ({ tag: "", record: b.record, todayWidth: b.todayWidth }))];
for (const { tag, record, todayWidth } of all) {
  const curve = C.todayCurve(record);
  let worst = 0;
  for (const [x, w] of todayWidth) worst = Math.max(worst, Math.abs(curve.sample(x) - w));
  const seg = C.noseSegment(record), co = C.parabolaCoefficients(record), hb = C.variantBHandles(record);
  const cPts = C.variantC(record), bPts = C.variantB(record);
  const mono = (pts) => { let ok = true; const i0 = pts.findIndex(([x]) => x >= seg.last.x - 1e-9); for (let i = i0 + 1; i < pts.length; i++) if (pts[i][1] > pts[i - 1][1] + 1e-9) ok = false; return ok; };
  console.log(`${record.vendor} ${record.name}${tag ? " (" + tag + ")" : ""}: port vs app max |Δ| = ${worst.toExponential(2)} in over ${todayWidth.length} samples`);
  console.log(`   last printed ${seg.last.label ?? ""}@${(seg.tip.x - seg.last.x).toFixed(2)}" in: hw ${(seg.last.y / 2).toFixed(3)}", today's slope there dhw/dd = ${co.mk.toFixed(4)}, today's angle at the tip = ${(Math.atan(Math.abs(curve.slopeAt(seg.tip.x) / 2)) * 180 / Math.PI).toFixed(1)}° per rail (slope ${(curve.slopeAt(seg.tip.x) / 2).toFixed(3)})`);
  console.log(`   B: chord ${hb.chord.toFixed(2)}", handles ${(hb.chord / 3).toFixed(2)}" (1/3), monotone ${mono(bPts)}`);
  console.log(`   C: a ${co.a.toFixed(3)} b ${co.b.toFixed(3)} tip radius ${co.tipRadius.toFixed(2)}" pointed ${co.pointed}, monotone ${mono(cPts)}, circle-through-station radius ${((seg.D * seg.D + (seg.last.y / 2) ** 2) / (2 * seg.D)).toFixed(2)}"`);
}

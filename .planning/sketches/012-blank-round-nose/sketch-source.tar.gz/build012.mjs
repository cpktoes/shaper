import { readFileSync, writeFileSync } from "node:fs";
const here = new URL(".", import.meta.url);
const raw = JSON.parse(readFileSync(new URL("./sketch012-data.json", here)));
// Embed only what the page draws: the port recomputes today's curve from the printed stations.
const data = {
  presets: raw.presets.map((p) => ({ id: p.id, name: p.name, blankStartIn: p.blankStartIn, blankEndIn: p.blankEndIn, board: p.board, marks: p.marks, record: p.record })),
  blanks: raw.blanks.map((b) => ({ record: b.record })),
};
const curves = readFileSync(new URL("./curves.js", here), "utf8").replace(/\nif \(typeof module[^\n]*\n?/, "\n");
const html = readFileSync(new URL("./template.html", here), "utf8")
  .replace("/*__DATA__*/", JSON.stringify(data))
  .replace("/*__CURVES__*/", curves.trim());
const out = "/Users/kontoes/Code/shaper/.planning/sketches/012-blank-round-nose/index.html";
writeFileSync(out, html);
console.log("wrote", out, html.length, "bytes");

const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const dir = "/Users/kontoes/Code/shaper/.planning/sketches/012-blank-round-nose";
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 2 });
  const errors = [];
  page.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") errors.push(`${m.type()}: ${m.text()}`); });
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  await page.goto("file://" + path.join(dir, "index.html"));
  await page.waitForTimeout(600);
  const shots = [["a", "slate"], ["b", "slate"], ["c", "slate"], ["x", "slate"], ["x", "daylight"], ["b", "daylight"]];
  const names = { a: "a-today", b: "b-control-point", c: "c-parabola", x: "side-by-side" };
  for (const [v, theme] of shots) {
    await page.evaluate(([v, theme]) => { state.variant = v; state.theme = theme; save(); renderAll(); }, [v, theme]);
    await page.waitForTimeout(250);
    await page.screenshot({ path: path.join(dir, "pictures", `${names[v]}-${theme}.png`), fullPage: true });
    const cells = await page.$$eval(".cell", (cs) => cs.map((c) => c.dataset.blank));
    console.log(v, theme, "cells:", cells.join(" | "));
  }
  // The B slider: a fuller and a tighter handle, for the README's pictures.
  for (const k of [0.2, 0.5]) {
    await page.evaluate((k) => { state.variant = "b"; state.theme = "slate"; state.k = k; save(); renderAll(); }, k);
    await page.waitForTimeout(250);
    const cell = await page.$('.cell[data-blank="9\'4\\"B"]');
    await cell.screenshot({ path: path.join(dir, "pictures", `b-control-point-${Math.round(k * 100)}pct-longboard.png`) });
  }
  await page.evaluate(() => { state.k = 0.333; state.variant = "b"; save(); renderAll(); });
  // Some facts the README quotes, read off the page itself.
  const facts = await page.evaluate(() => ITEMS.map((it) => { const seg = noseSegment(it.record), co = parabolaCoefficients(it.record), h = variantBHandles(it.record, 1 / 3), t = todayCurve(it.record); return `${it.record.vendor} ${it.record.name}: span ${seg.D}" hw ${(seg.last.y / 2).toFixed(2)} today ${(Math.atan(Math.abs(t.slopeAt(seg.tip.x) / 2)) * 180 / Math.PI).toFixed(0)}° | B chord ${h.chord.toFixed(2)} handle ${(h.chord / 3).toFixed(2)} | C tip radius ${co.tipRadius.toFixed(1)}`; }));
  console.log(facts.join("\n"));
  console.log("console problems:", errors.length ? errors.join("\n") : "none");
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

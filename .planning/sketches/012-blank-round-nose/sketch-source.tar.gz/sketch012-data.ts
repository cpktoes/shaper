// Scratch: pull the real blanks and boards for sketch 012 out of the app's own geometry.
// Run from the repo root: npx --no-install tsx --tsconfig ./tsconfig.json <this file>
import { writeFileSync } from "node:fs";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/lib/geometry/presets";
import { PRESET_BLANKS } from "/Users/kontoes/Code/shaper/lib/blanks/preset-blanks";
import { readSeedCatalog } from "/Users/kontoes/Code/shaper/lib/blanks/seed-files";
import { prepareBlank } from "/Users/kontoes/Code/shaper/lib/geometry/blank-fit";
import { buildBlankProfile } from "/Users/kontoes/Code/shaper/lib/geometry/board-profile";
import { buildBlankTopView } from "/Users/kontoes/Code/shaper/lib/geometry/blank-top-view";
import { buildOutline } from "/Users/kontoes/Code/shaper/lib/geometry/outline";
import { silhouette } from "/Users/kontoes/Code/shaper/lib/geometry/screen-tiles";
import { DEFAULT_BLANK_CUT, type BlankRecord } from "/Users/kontoes/Code/shaper/lib/geometry/blank";
import { mm, mmToInches } from "/Users/kontoes/Code/shaper/lib/geometry/units";

const inch = (v: number) => Number(mmToInches(mm(v)).toFixed(6));

function recordOut(record: BlankRecord) {
  return {
    vendor: record.vendor,
    name: record.name,
    lengthIn: inch(record.lengthMm),
    stations: record.stations.map((s) => ({
      label: s.label,
      fromTailIn: inch(s.fromTailMm),
      widthIn: s.widthMm === null ? null : inch(s.widthMm),
    })),
  };
}

/** Today's full-width curve in the blank's own coordinates, sampled every 1/4" plus every station. */
function todayWidth(record: BlankRecord) {
  const prepared = prepareBlank(record);
  const xs: number[] = [];
  const L = record.lengthMm;
  const step = 25.4 / 4;
  for (let x = 0; x < L; x += step) xs.push(x);
  xs.push(L);
  for (const s of record.stations) if (s.widthMm !== null) xs.push(s.fromTailMm);
  xs.sort((a, b) => a - b);
  return xs.map((x) => [inch(x), inch(prepared.width.sample(x))]);
}

const out: Record<string, unknown> = { presets: [], blanks: [] };

// The two presets whose blank prints a 0-wide nose, with the board on it as ROCKER draws it today.
for (const preset of BOARD_PRESETS) {
  if (!preset.blank) continue;
  const record = PRESET_BLANKS.blanks.find((b) => b.vendor === preset.blank!.vendor && b.name === preset.blank!.name);
  if (!record) throw new Error(`no blank for ${preset.id}`);
  const n0 = record.stations.find((s) => s.label === "N0");
  if (!n0 || n0.widthMm !== 0) continue;
  const geometry = buildOutline(preset.outline);
  const board = {
    length: preset.outline.length,
    centerThickness: preset.foil.center,
    noseTip: preset.foil.noseTip,
    tailTip: preset.foil.tailTip,
    nose12Offset: mm(0),
    tail12Offset: mm(0),
    ...DEFAULT_BLANK_CUT,
  };
  const profile = buildBlankProfile(prepareBlank(record), board, preset.blank.placement);
  if (!profile.blank) throw new Error("no side view");
  const view = buildBlankTopView({ blank: profile.blank, geometry, length: preset.outline.length, samples: 120 });
  (out.presets as unknown[]).push({
    id: preset.id,
    name: preset.name,
    boardLengthIn: inch(preset.outline.length),
    blankStartIn: inch(profile.blank.start),
    blankEndIn: inch(profile.blank.end),
    board: silhouette(geometry).map((p) => [inch(p.station), inch(p.w)]),
    todayOutline: view.blankOutline.map((s) => [inch(s.station), inch(s.halfWidth)]),
    marks: view.marks.map((m) => ({ label: m.label, stationIn: inch(m.station), halfWidthIn: inch(m.halfWidth) })),
    record: recordOut(record),
    todayWidth: todayWidth(record),
  });
}

// Three more catalogue blanks with a 0-wide nose, one per span of the last printed segment.
const wanted: [string, RegExp][] = [
  ["Arctic Foam", /^9'3"? ?LB$/],
  ["Marko Foam", /^9'1"? ?Machine All$/],
  ["US Blanks", /^11'2"?C$/],
];
const catalogue = readSeedCatalog();
for (const [vendor, re] of wanted) {
  const record = catalogue.find((b) => b.vendor === vendor && re.test(b.name));
  if (!record) throw new Error(`no ${vendor} blank matching ${re}`);
  (out.blanks as unknown[]).push({ record: recordOut(record), todayWidth: todayWidth(record) });
}

const path = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/2a467eee-f7dc-45c3-ab53-3b9d325cf67c/scratchpad/sketch012-data.json";
writeFileSync(path, JSON.stringify(out));
console.log("presets:", (out.presets as { id: string; name: string; record: { name: string }; blankStartIn: number; blankEndIn: number }[]).map((p) => `${p.id} (${p.name}) on ${p.record.name} start ${p.blankStartIn} end ${p.blankEndIn}`).join("; "));
console.log("blanks:", (out.blanks as { record: { vendor: string; name: string; lengthIn: number } }[]).map((b) => `${b.record.vendor} ${b.record.name} ${b.record.lengthIn}"`).join("; "));

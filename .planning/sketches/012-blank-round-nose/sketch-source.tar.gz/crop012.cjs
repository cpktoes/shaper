const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const dir = "/Users/kontoes/Code/shaper/.planning/sketches/012-blank-round-nose";
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 2 });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message)); page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  await page.goto("file://" + path.join(dir, "index.html")); await page.waitForTimeout(500);
  const out = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/2a467eee-f7dc-45c3-ab53-3b9d325cf67c/scratchpad";
  for (const [v, theme, name] of [["a", "slate", "crop-a-longboard"], ["b", "slate", "crop-b-longboard"], ["b", "daylight", "crop-b-daylight-marko"], ["x", "daylight", "crop-x-daylight-marko"]]) {
    await page.evaluate(([v, theme]) => { state.variant = v; state.theme = theme; state.k = 0.333; save(); renderAll(); }, [v, theme]);
    await page.waitForTimeout(250);
    const sel = name.includes("longboard") ? '.cell[data-blank="9\'4\\"B"]' : '.cell[data-blank="9\'1\\" Machine All"]';
    await (await page.$(sel)).screenshot({ path: path.join(out, name + ".png") });
  }
  console.log("errors:", errors.length ? errors.join("; ") : "none");
  await browser.close();
})();

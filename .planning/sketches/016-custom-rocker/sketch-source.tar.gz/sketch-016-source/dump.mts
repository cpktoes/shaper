// Dump the ROCKER side profile (natural) for the Longboard and Shortboard presets in their blanks,
// in the BOARD's frame, as the viewer samples it — plus the blank's own natural rocker in the blank's frame.
import { writeFileSync } from "node:fs";
const ROOT = "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275";
const { BOARD_PRESETS } = await import(`${ROOT}/lib/geometry/presets.ts`);
const { presetDesignFields } = await import(`${ROOT}/lib/blanks/preset-blanks.ts`);
const { designSideProfile, LIVE_DESIGN_RULES } = await import(`${ROOT}/lib/geometry/design.ts`);
const { prepareBlank } = await import(`${ROOT}/lib/geometry/blank-fit.ts`);
const { printedBlankStations } = await import(`${ROOT}/lib/geometry/board-profile.ts`);
const IN = 25.4;
const out: any = {};
for (const id of ["longboard", "shortboard"]) {
  const preset = BOARD_PRESETS.find((p: any) => p.id === id);
  const fields = presetDesignFields(preset);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const blank = profile.blank;
  const L = profile.length;
  const prepared = prepareBlank(fields.blank.copy);
  const rec = fields.blank.copy;
  const N = 200;
  const board = [] as number[][];
  for (let i = 0; i <= N; i++) { const s = (L * i) / N; board.push([s / IN, profile.rockerAt(s) / IN, profile.thicknessAt(s) / IN]); }
  const blankPts = [] as number[][];
  for (let i = 0; i <= N; i++) { const s = blank.start + ((blank.end - blank.start) * i) / N; blankPts.push([s / IN, blank.bottomAt(s) / IN, blank.deckAt(s) / IN]); }
  const nat = [] as number[][];
  for (let i = 0; i <= N; i++) { const x = (rec.lengthMm * i) / N; nat.push([x / IN, prepared.rocker.sample(x) / IN]); }
  out[id] = {
    preset: preset.name, boardLengthIn: L / IN, widthIn: fields.outline.widePointWidth / IN, centerIn: fields.foil.center / IN,
    blank: { vendor: rec.vendor, name: rec.name, pdfPage: rec.pdfPage, lengthIn: rec.lengthMm / IN, volumeL: rec.volumeLitres, startIn: blank.start / IN, endIn: blank.end / IN, placementIn: blank.placement / IN,
      centreFromTailIn: rec.stations.find((s: any) => s.label === "C").fromTailMm / IN,
      stations: rec.stations.map((s: any) => ({ label: s.label, xIn: s.fromTailMm / IN, rockerIn: s.rockerMm === null ? null : s.rockerMm / IN, thickIn: s.thicknessMm === null ? null : s.thicknessMm / IN, widthIn: s.widthMm === null ? null : s.widthMm / IN })),
      printed: printedBlankStations(rec) },
    stations: profile.stations.map((st: any) => ({ key: st.key, name: st.name, sIn: st.station / IN })),
    stationRockerIn: Object.fromEntries(Object.entries(profile.stationRocker).map(([k, v]: any) => [k, v / IN])),
    foilIn: Object.fromEntries(Object.entries(profile.effectiveFoil).map(([k, v]: any) => [k, v / IN])),
    foamOffDeckIn: Object.fromEntries(Object.entries(blank.foamOffDeck).map(([k, v]: any) => [k, v / IN])),
    foamOffBottomIn: Object.fromEntries(Object.entries(blank.foamOffBottom).map(([k, v]: any) => [k, v / IN])),
    tips: { nose: blank.tips.nose.station / IN, tail: blank.tips.tail.station / IN },
    board, blankPts, nat,
  };
}
writeFileSync(process.argv[2], JSON.stringify(out));
for (const [k, v] of Object.entries<any>(out)) console.log(k, v.blank.vendor, v.blank.name, "L", v.boardLengthIn, "blank", v.blank.lengthIn, "start", v.blank.startIn.toFixed(2), "placement", v.blank.placementIn, "rocker", JSON.stringify(v.stationRockerIn));

import sys, re, json
tpl, data, out = sys.argv[1:4]
d = json.load(open(data))
s = open(tpl).read().replace('/*__DATA__*/{}', json.dumps(d, separators=(',', ':')))
# body fragment: no doctype/html/head/body; title + style first
head_start = s.index('<title>'); 
s = s[head_start:]
s = s.replace('</head>\n<body>\n', '').replace('</body>\n</html>\n', '')
s = s.replace('<title>Sketch 016 — Custom rocker on ROCKER</title>', '<title>Custom Rocker Sketch</title>')
tokens = '''<style>
  /* Layout: the ROCKER page mocked at three device sizes; tokens are the app's own Daylight (light) and Slate (dark) palettes. */
  :root { --color-bg: #ffffff; --color-surface: #ffffff; --color-canvas: #dfdcd3; --color-well: #efece5; --color-border: #c9c2ad; --color-line: #897c58; --color-text: #1f2a3b; --color-text-muted: #566171; --color-primary: #8ec1b8; --color-on-primary: #1f2a3b; --color-accent-ink: #1f6f68; --color-board: #f6f3ea; --color-warning-ink: #a8470f; --color-page: #cfcabd; --font-sans: "Inter", Roboto, system-ui, sans-serif; --tracking-architectural: 0.15em; }
  @media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { --color-bg: #12141a; --color-surface: #12141a; --color-canvas: #1a1d25; --color-well: #1b1f26; --color-border: #333842; --color-line: #6a707c; --color-text: #f2f4f7; --color-text-muted: #a1a8b4; --color-primary: #18526d; --color-on-primary: #f2f4f7; --color-accent-ink: #3490bc; --color-board: #1a2732; --color-warning-ink: #ff9670; --color-page: #0b0c10; color-scheme: dark; } }
  :root[data-theme="dark"] { --color-bg: #12141a; --color-surface: #12141a; --color-canvas: #1a1d25; --color-well: #1b1f26; --color-border: #333842; --color-line: #6a707c; --color-text: #f2f4f7; --color-text-muted: #a1a8b4; --color-primary: #18526d; --color-on-primary: #f2f4f7; --color-accent-ink: #3490bc; --color-board: #1a2732; --color-warning-ink: #ff9670; --color-page: #0b0c10; color-scheme: dark; }
  body { background: var(--color-page); color: var(--color-text); }
</style>
'''
s = s.replace('<style>\n', tokens + '<style>\n', 1)
s = s.replace('<script>\nconst DATA =', '<script>\nwindow.__publish = true;\nconst DATA =', 1)
assert 'window.__publish = true' in s and '<title>Custom Rocker Sketch</title>' in s and '<!doctype' not in s
open(out, 'w').write(s)
print('artifact', len(s))

const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1320, height: 1240 }, deviceScaleFactor: 3 });
  await p.goto('file://' + process.argv[2]);
  const nums = await p.evaluate(() => {
    try { localStorage.clear(); } catch (e) {}
    Object.assign(state, { variant: 'd', device: 'computer', board: 'longboard', popup: true, showBoard: false, saved: [], savedIdx: null, rocker: { nose: [], tail: [] }, draft: { nose: [], tail: [{ a: 0.5, f: null }] } });
    render();
    const nat = geometry({ nose: [], tail: [] }), cus = geometry(state.draft);
    const at = (pts, s) => pts.reduce((best, p) => (Math.abs(p[0] - s) < Math.abs(best[0] - s) ? p : best));
    return { tailTipNaturalBottom: at(nat.blankBottom, nat.start)[1], tailTipCustomBottom: at(cus.blankBottom, cus.start)[1], at12: at(cus.blankBottom, 12)[1] - at(nat.blankBottom, 12)[1], shift: cus.shift, blankTipNat: nat.blankLev(0), blankTipCus: cus.blankLev(0) };
  });
  console.log(JSON.stringify(nums));
  const art = await p.$('.rart');
  await art.screenshot({ path: process.argv[3] });
  await b.close();
})();

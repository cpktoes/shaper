const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const [html, outdir] = process.argv.slice(2);
  const b = await chromium.launch();
  const errors = [];
  const shots = [
    ['a-computer-viewer', { variant: 'a', device: 'computer', tab: 'viewer' }, [1320, 1240]],
    ['a-computer-datasheet', { variant: 'a', device: 'computer', tab: 'datasheet' }, [1320, 1240]],
    ['b-computer-viewer', { variant: 'b', device: 'computer', tab: 'viewer' }, [1320, 1240]],
    ['c-computer-viewer', { variant: 'c', device: 'computer', tab: 'viewer' }, [1320, 1240]],
    ['a-phone-upright', { variant: 'a', device: 'phone', tab: 'viewer' }, [390, 760]],
    ['a-phone-sideways', { variant: 'a', device: 'side', tab: 'viewer' }, [844, 420]],
    ['a-computer-picker-saved', { variant: 'a', device: 'computer', tab: 'viewer', picker: true, saved: [{ board: 'longboard', note: '-1/4"N18" +1/8"T36" +1/8"T18"', rocker: { nose: [{ a: -0.25, f: 18 }], tail: [{ a: 0.125, f: 36 }, { a: 0.125, f: 18 }] } }] }, [1320, 1240]],
    ['a-phone-picker-saved', { variant: 'a', device: 'phone', tab: 'viewer', picker: true, saved: [{ board: 'longboard', note: '-1/4"N18" +1/8"T36" +1/8"T18"', rocker: { nose: [{ a: -0.25, f: 18 }], tail: [{ a: 0.125, f: 36 }, { a: 0.125, f: 18 }] } }] }, [390, 760]],
    ['a-computer-saved-line', { variant: 'a', device: 'computer', tab: 'viewer', saved: [{ board: 'longboard', note: '-1/4"N18" +1/8"T36" +1/8"T18"', rocker: { nose: [{ a: -0.25, f: 18 }], tail: [{ a: 0.125, f: 36 }, { a: 0.125, f: 18 }] } }] }, [1320, 1240]],
    ['a-computer-daylight-reverse', { variant: 'a', device: 'computer', tab: 'viewer', theme: 'daylight', rocker: { nose: [], tail: [{ a: -2, f: null }] } }, [1320, 1240]],
  ];
  for (const [name, st, [w, h]] of shots) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 2 });
    p.on('pageerror', (e) => errors.push(name + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errors.push(name + ': ' + m.text()); });
    await p.goto('file://' + html);
    await p.evaluate((s) => { try { localStorage.clear(); } catch (e) {} Object.assign(state, JSON.parse(JSON.stringify(s))); if (!s.rocker) state.rocker = { nose: [{ a: -0.25, f: 18 }], tail: [{ a: 0.125, f: 36 }, { a: 0.125, f: 18 }] }; state.text = noteOf(state.rocker); render(); }, st);
    await p.waitForTimeout(400);
    const target = name.includes('saved-line') ? 'Rocker' : st.device === 'computer' ? 'Blank' : 'Rocker';
    await p.evaluate((t) => { document.querySelectorAll('.sidebar').forEach((sb) => { const sect = [...sb.querySelectorAll('.sect')].find((e) => e.textContent.trim().startsWith(t)); if (sect) sb.scrollTop = sect.offsetTop - sb.offsetTop - 4; }); }, target);
    await p.waitForTimeout(100);
    await p.screenshot({ path: `${outdir}/${name}.png`, fullPage: true });
    await p.close();
  }
  console.log(errors.length ? 'ERRORS\n' + errors.join('\n') : 'no page errors');
  await b.close();
})();

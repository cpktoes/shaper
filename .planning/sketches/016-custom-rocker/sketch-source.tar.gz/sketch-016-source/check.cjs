const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1320, height: 940 } });
  p.on('pageerror', (e) => console.log('PAGEERROR', e.message, e.stack && e.stack.split('\n').slice(0, 3).join(' | ')));
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') console.log('CONSOLE', m.type(), m.text()); });
  await p.goto('file://' + process.argv[2]); await p.waitForTimeout(500);
  console.log('state:', await p.evaluate(() => typeof state), 'stage children:', await p.evaluate(() => document.getElementById('stage').children.length));
  await b.close();
})();

// proves the stacking rule on the built page: +1/2"N from centre + +1/2"N18" = 1" at the nose tip
const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => { const b = await chromium.launch(); const p = await b.newPage(); await p.goto('file://' + process.argv[2]);
  const r = await p.evaluate(() => { state.board = 'longboard'; const nat = geometry({ nose: [], tail: [] }); const two = geometry({ nose: [{ a: 0.5, f: null }, { a: 0.5, f: 18 }], tail: [] }); const L = nat.bl.lengthIn; return { natTip: nat.blankLev(L), twoTip: two.blankLev(L), at18: two.blankLev(L - 18) - nat.blankLev(L - 18), at30: two.blankLev(L - 30) - nat.blankLev(L - 30) }; });
  console.log(JSON.stringify(r)); await b.close(); })();

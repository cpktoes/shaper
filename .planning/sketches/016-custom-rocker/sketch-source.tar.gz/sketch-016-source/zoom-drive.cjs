// drives the popup's zoom the way a shaper would: the + button, the wheel over the nose, a drag — and reads the viewBox back
const { chromium } = require('/Users/kontoes/Code/shaper/node_modules/playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1320, height: 1000 } });
  await p.goto('file://' + process.argv[2]);
  await p.evaluate(() => { try { localStorage.clear(); } catch (e) {} Object.assign(state, { variant: 'd', device: 'computer', board: 'longboard', popup: true, draft: { nose: [{ a: -0.25, f: 18 }], tail: [{ a: 0.125, f: 36 }] }, zoom: 1, pan: { x: 0, y: 0 } }); render(); });
  const vb = () => p.evaluate(() => document.querySelector('[data-zoomable] svg.mainart').getAttribute('viewBox'));
  const out = { start: await vb() };
  await p.click('[data-act="zoomin"]'); out.afterPlus = await vb();
  await p.click('[data-act="zoomin"]'); out.afterPlusPlus = await vb();
  const svg = await p.$('[data-zoomable] svg.mainart'); const box = await svg.boundingBox();
  await p.mouse.move(box.x + box.width * 0.9, box.y + box.height * 0.5); await p.mouse.wheel(0, -100); await p.waitForTimeout(100); out.afterWheelAtNose = await vb(); out.zoom = await p.evaluate(() => state.zoom);
  await p.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5); await p.mouse.down(); await p.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.5, { steps: 5 }); await p.mouse.up(); await p.waitForTimeout(100); out.afterDragLeft = await vb();
  await p.click('[data-act="zoomfit"]'); out.afterFit = await vb(); out.zoomAfterFit = await p.evaluate(() => state.zoom);
  out.strokeAt1x = await p.evaluate(() => document.querySelector('[data-zoomable] svg.mainart path[stroke="var(--adj-1)"]').getAttribute('stroke-width'));
  await p.click('[data-act="zoomin"]'); await p.click('[data-act="zoomin"]'); out.strokeAt2x = await p.evaluate(() => document.querySelector('[data-zoomable] svg.mainart path[stroke="var(--adj-1)"]').getAttribute('stroke-width'));
  console.log(JSON.stringify(out, null, 1)); await b.close();
})();

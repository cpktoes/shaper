import sys, json
tpl, data, out = sys.argv[1:4]
d = json.load(open(data))
html = open(tpl).read().replace('/*__DATA__*/{}', json.dumps(d, separators=(',', ':')))
open(out, 'w').write(html)
print('built', len(html))

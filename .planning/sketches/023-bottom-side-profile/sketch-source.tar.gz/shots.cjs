// Sketch 023's pictures, headless Chromium from the sketch file. Run: node shots.cjs <index.html> <pictures-dir> [only]
const { chromium } = require("/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/node_modules/playwright");
const path = require("node:path");
const [, , HTML, OUT, ONLY] = process.argv;
const url = (q) => "file://" + path.resolve(HTML) + (q ? "?" + q : "");

const DESK = { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 };
const PHONE = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true };
const shots = [
  // name, context, query, steps
  ["desktop-A-deep-single", DESK, "variant=A&bare=1"],
  ["desktop-B-deep-single", DESK, "variant=B&bare=1", async (p) => p.click('.tab[data-page="side"]')],
  ["desktop-B-viewer-tab", DESK, "variant=B&bare=1"],
  ["desktop-C-deep-single", DESK, "variant=C&bare=1", async (p) => p.click('#vtog [data-v="side"]')],
  ["desktop-C-from-below", DESK, "variant=C&bare=1"],
  ["desktop-A-rolled-vee", DESK, "variant=A&board=shortboard-vee&bare=1"],
  ["desktop-A-slate", DESK, "variant=A&bare=1", async (p) => p.evaluate(() => { const s = window.sketch; s.state.theme = "slate"; s.applyChrome(); s.render(true); })],
  ["desktop-A-metric", DESK, "variant=A&bare=1", async (p) => p.evaluate(() => { const s = window.sketch; s.state.units = "metric"; s.applyChrome(); s.render(true); })],
  ["phone-A-deep-single", PHONE, "variant=A&bare=1"],
  ["phone-B-deep-single", PHONE, "variant=B&bare=1", async (p) => p.click('.tab[data-page="side"]')],
  ["phone-B-height-x8", PHONE, "variant=B&bare=1", async (p) => { await p.click('.tab[data-page="side"]'); await p.click('#sideExag [data-e="8"]'); }],
  ["phone-C-deep-single", PHONE, "variant=C&bare=1", async (p) => p.click('#vtog [data-v="side"]')],
  ["phone-A-rolled-vee", PHONE, "variant=A&board=shortboard-vee&bare=1"],
];

(async () => {
  const browser = await chromium.launch();
  for (const [name, opts, q, step] of shots) {
    if (ONLY && !name.includes(ONLY)) continue;
    const ctx = await browser.newContext(opts); const page = await ctx.newPage();
    page.on("pageerror", (e) => console.log("ERROR", name, e.message));
    await page.goto(url(q)); await page.waitForFunction(() => window.sketch && document.querySelector("#views svg path.board"));
    await page.evaluate(() => document.fonts.ready);
    if (step) await step(page);
    await page.waitForTimeout(400);
    await page.screenshot({ path: path.join(OUT, name + ".png") });
    await ctx.close(); console.log("took", name);
  }
  await browser.close();
})();

"""Assemble sketch 023: the template + the real board figures + the wordmark outline.

Writes the self-contained index.html into the sketch folder, and a body-fragment copy for the Artifact
(its title and styles first, no document skeleton, the stage colour as a root token that follows the
viewer's light or dark choice). Run with: python3 -I build.py <repo-root>
"""
import json, re, sys, pathlib

here = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path(sys.argv[1])
out_dir = repo / ".planning" / "sketches" / "023-bottom-side-profile"
out_dir.mkdir(parents=True, exist_ok=True)

template = (here / "template.html").read_text()
boards = json.dumps(json.load(open(here / "boards.json")), separators=(",", ":"))
wordmark = (here / "wordmark.txt").read_text().strip()

# The phone block is written once against `#app.phone`; it also applies by width alone, the app's own switch.
ps, pe = template.index("/* PHONE-START */"), template.index("/* PHONE-END */")
phone_block = template[ps + len("/* PHONE-START */"):pe]
by_width = "@media (max-width: 819.98px) {" + phone_block.replace("#app.phone", "#app") + "}\n"
template = template[:pe] + by_width + template[pe:]
page = template.replace("__BOARDS__", boards).replace("__WORDMARK__", wordmark)
(out_dir / "index.html").write_text(page)

# ---- the Artifact copy ----
styles = re.search(r"<style>(.*?)</style>", page, re.S).group(1)
body = re.search(r"<body>(.*)</body>", page, re.S).group(1)
styles = styles.replace("html, body { margin: 0; height: 100%; }", "html, body { height: 100%; }")
styles = styles.replace(
    "body { display: flex; flex-direction: column; height: 100dvh; background: #c9c5ba; font-family: Inter, Roboto, system-ui, sans-serif; }",
    ":root { --stage: #c9c5ba; }\n"
    "@media (prefers-color-scheme: dark) { :root:not([data-theme=\"light\"]) { --stage: #0d0f14; color-scheme: dark; } }\n"
    ":root[data-theme=\"dark\"] { --stage: #0d0f14; color-scheme: dark; }\n"
    "body { background: var(--stage); }\n"
    "#sketch023 { display: flex; flex-direction: column; height: 100%; background: var(--stage); font-family: Inter, Roboto, system-ui, sans-serif; }",
)
fragment = (
    "<title>Bottom Side Profile</title>\n"
    '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">\n'
    "<style>" + styles + "</style>\n"
    '<div id="sketch023">' + body + "</div>"
)
(here / "artifact.html").write_text(fragment)
print("wrote", out_dir / "index.html", len(page), "bytes; artifact fragment", len(fragment))

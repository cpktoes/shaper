// a quick look at the boxes. Run: node probe.cjs <index.html> <query> <js-expression>
const { chromium } = require("/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/node_modules/playwright");
const path = require("node:path");
const [, , HTML, Q, EXPR, W, H] = process.argv;
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: +(W || 1280), height: +(H || 800) } });
  page.on("pageerror", (e) => console.log("ERROR", e.message));
  await page.goto("file://" + path.resolve(HTML) + "?" + Q); await page.waitForFunction(() => window.sketch && document.querySelector("#views svg path.board"));
  await page.waitForTimeout(300);
  console.log(JSON.stringify(await page.evaluate(EXPR), null, 1));
  await browser.close();
})();

/* Sketch 023's real board figures, read from the app's own maths in the close-bottom-17 worktree. Never hand-type a
   board number. Sketch 021's reader, re-pointed at the four presets as the app opens them (presetDesignFields, the way
   quick 261112-lmr's pictures build them), plus the one thing 021 never needed: the planed rocker along the board, so
   the side profile can be drawn. Also writes the app's own sideProfileLines for the two cross-check boards.
   Run from the worktree: npx tsx <this file> */
import { writeFileSync } from "node:fs";
import { presetDesignFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/blanks/preset-blanks";
import { DEFAULT_BOTTOM, pickCut, resolveBottom, type BoardBottom, type BottomBoard } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/bottom";
import { LIVE_DESIGN_RULES, designBottomBoard, designFinPlacement, designSideProfile, summarizeDesign } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/presets";
import { DEFAULT_VOLUME_SPEC } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/volume";
import { sideProfileLines } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/side-profile";
import { mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/lib/geometry/units";

const OUT = "/private/tmp/claude-501/-Users-kontoes-Code-shaper/86389bad-1284-4de0-86f8-1a82686fc51e/scratchpad/sketch023/src";
const STATIONS = 721; // every 1/720 of the board: under 1/6" apart on a 9'6"
const r2 = (v: number) => Math.round(v * 100) / 100;
const IN = 25.4;

function fieldsOf(name: string, bottom?: BoardBottom) {
  const preset = BOARD_PRESETS.find((p) => p.name === name)!;
  return {
    ...presetDesignFields(preset),
    volume: DEFAULT_VOLUME_SPEC,
    finsImportTemplate: true,
    railsImportFoilThickness: true,
    boardName: "",
    finSystem: "fcs2" as const,
    ...(bottom ? { bottom } : {}),
  };
}

const out: unknown[] = [];
for (const preset of BOARD_PRESETS) {
  const fields = fieldsOf(preset.name);
  const g = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const placement = designFinPlacement(fields);
  const board = designBottomBoard(fields.outline, g, profile, placement);
  const L = board.length as number;
  const litres = summarizeDesign(fields).volumeLitres as number;
  const curve: number[] = [], natural: number[] = [], narrow: number[] = [], foam: number[] = [], thick: number[] = [], rocker: number[] = [];
  for (let i = 0; i < STATIONS; i++) {
    const s = mm((i / (STATIONS - 1)) * L);
    curve.push(r2(board.railAt(s)));
    natural.push(r2(board.curveAt(s)));
    narrow.push(r2(board.narrowestAt(s)));
    foam.push(r2(board.foamAt(s)));
    thick.push(r2(profile.thicknessAt(s)));
    rocker.push(r2(profile.rockerAt(s)));
  }
  const hasFront = placement.marks.some((m) => m.role === "front");
  out.push({
    id: preset.id, name: preset.name, L: r2(L), litres,
    wide: r2(board.widePoint), widePointWidth: r2(board.widePointWidth),
    fin: r2(board.frontFins), finWord: hasFront ? "Front fins" : "Fin", toeDeg: Math.round(board.toeDegrees * 100) / 100,
    tail: fields.outline.tail.kind, close: r2(g.centreCloseStation), block: r2(g.points[0].halfWidth), first: r2(g.points[0].station),
    wings: [],
    outline: g.points.map((p) => [r2(p.station), r2(p.halfWidth)]),
    curve, natural, narrow, foam, thick, rocker,
  });
  console.log(preset.name, "L", (L / IN).toFixed(2), "litres", litres.toFixed(2), "wide", ((board.widePoint as number) / IN).toFixed(2), "fin", ((board.frontFins as number) / IN).toFixed(2),
    "rocker nose", (profile.rockerAt(board.length) / IN).toFixed(3), "tail", (profile.rockerAt(mm(0)) / IN).toFixed(3), "thick mid", (profile.thicknessAt(mm(L / 2)) / IN).toFixed(3));
}
writeFileSync(`${OUT}/boards.json`, JSON.stringify({ boards: out }));

// the app's own side profiles for the two cross-check boards, every 1" from the tail to the nose
function appLines(name: string, label: string, pick: (b: BottomBoard) => BoardBottom) {
  const f0 = fieldsOf(name);
  const g = buildOutline(f0.outline);
  const profile = designSideProfile(f0, LIVE_DESIGN_RULES);
  const board = designBottomBoard(f0.outline, g, profile, designFinPlacement(f0));
  const bottom = pick(board);
  const resolved = resolveBottom(bottom, board);
  const lines = sideProfileLines(resolved, board, profile);
  // the lines are read every 1/4"; every fourth point is a whole inch, and the last is the nose itself
  const pts = lines.points.filter((_, i) => i % 4 === 0 || i === lines.points.length - 1).map((p) => ({
    s: p.station, stringer: p.stringerBottom, rail: p.railBottom, deck: p.deck, planed: p.planedBottom,
  }));
  return { label, board: name, center: bottom.center.name, tail: bottom.tail.name, stringerThickness: lines.stringerThickness, maxThickness: lines.maxThickness, points: pts };
}
const checks = [
  appLines("Shortboard", "deep-single", (b) => pickCut(DEFAULT_BOTTOM, "center", "Deep Single Concave", b)),
  appLines("Shortboard", "rolled-vee", (b) => pickCut(DEFAULT_BOTTOM, "tail", "Rolled Vee", b)),
];
for (const c of checks) console.log(c.label, c.center, c.tail, "stringer", (c.stringerThickness / IN).toFixed(3), "max", (c.maxThickness / IN).toFixed(3), "points", c.points.length);
writeFileSync(`${OUT}/app-side-profiles.json`, JSON.stringify(checks));

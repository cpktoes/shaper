import sys
p = sys.argv[1]; t = open(p).read()
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (a, t.count(a)); t = t.replace(a, b)
rep('document.getElementById("secrow").innerHTML = cards.map(', 'document.getElementById("secTabs").innerHTML = cards.map(')
rep('document.querySelectorAll("#secrow .tab")', 'document.querySelectorAll("#secTabs .tab")')
rep('// the sketch reads its starting variant, board and page from the address (#A, #B-side, ?board=…), for the pictures',
    '// the sketch reads its starting variant and board from the address (?variant=B&board=shortboard-vee&bare=1), for the pictures')
rep('''  if (el.matches("select[data-sel]")) { const sk = el.dataset.sel; state.cuts[sk] = makeCut(sk, el.value, B); state.active = sk; state.live = sk; buildControls();''',
'''  if (el.matches("select[data-sel]")) { const sk = el.dataset.sel;
    // D-42, as the app's pickCut: a center single still on its opening numbers follows a new tail in or out of a vee
    if (sk === "tail" && state.cuts.center.kind === "single") { const was = makeCut("center", state.cuts.center.name, B, state.cuts.tail.name);
      if (["start", "deep", "end", "depth", "off", "smooth"].every((f) => Math.abs(was[f] - state.cuts.center[f]) < 1e-6)) state.cuts.center = makeCut("center", state.cuts.center.name, B, el.value); }
    state.cuts[sk] = makeCut(sk, el.value, B, sk === "center" ? state.cuts.tail.name : undefined); state.active = sk; state.live = sk; buildControls();''')
rep('window.sketch = { state, render, setBoard,', 'window.sketch = { state, render, setBoard, sideAt, sideLines, sectionsOff, rockerAt, thickAt, B: () => B,')
open(p, "w").write(t); print("ok")

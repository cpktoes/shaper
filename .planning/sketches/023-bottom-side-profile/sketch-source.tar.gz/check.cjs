// Sketch 023's checks: no page errors on any variant, theme, units or board; the side profile cross-checked against the
// app's own sideProfileLines every 1" from the tail to the nose on the two boards; the phone heights measured.
// Run: node check.cjs <index.html> <app-side-profiles.json> <scratch-out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/.claude/worktrees/close-bottom-17/node_modules/playwright");
const fs = require("node:fs");
const path = require("node:path");
const [, , HTML, APP, OUTDIR] = process.argv;
const url = (q) => "file://" + path.resolve(HTML) + (q ? "?" + q : "");
const ready = (page) => page.waitForFunction(() => window.sketch && document.querySelector("#views svg path.board"));

(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const results = {};

  // ---- the cross-check ----
  const app = JSON.parse(fs.readFileSync(APP, "utf8"));
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    page.on("pageerror", (e) => errors.push("cross: " + e.message));
    for (const c of app) {
      const board = c.label === "deep-single" ? "shortboard" : "shortboard-vee";
      await page.goto(url(`board=${board}`)); await ready(page);
      const mine = await page.evaluate((stations) => {
        const sk = window.sketch; const L = sk.B().L;
        const lines = sk.sideLines();
        return { cuts: [sk.state.cuts.nose.name, sk.state.cuts.center.name, sk.state.cuts.tail.name], L, pts: stations.map((s) => sk.sideAt(s)), strT: lines.stringerThickness, maxT: lines.maxThickness };
      }, c.points.map((p) => p.s));
      let worst = { gap: 0 }; const per = { stringer: 0, rail: 0, deck: 0 };
      c.points.forEach((p, i) => {
        const m = mine.pts[i];
        for (const f of ["stringer", "rail", "deck"]) { const g = Math.abs(m[f] - p[f]); per[f] = Math.max(per[f], g); if (g > worst.gap) worst = { gap: g, line: f, s: p.s, app: p[f], sketch: m[f] }; }
      });
      results[c.label] = { cuts: mine.cuts, appCuts: [c.center, c.tail], points: c.points.length, worst, perLine: per,
        stringerThickness: { app: c.stringerThickness, sketch: mine.strT }, maxThickness: { app: c.maxThickness, sketch: mine.maxT } };
    }
    await page.close();
  }

  // ---- every variant, theme, units and board loads without an error ----
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    page.on("pageerror", (e) => errors.push("sweep: " + e.message));
    await page.goto(url()); await ready(page);
    for (const v of ["A", "B", "C"]) for (const b of ["shortboard", "shortboard-vee", "fish", "midlength", "longboard"]) for (const u of ["imperial", "metric"]) {
      await page.click(`#bar [data-var="${v}"]`); await page.click(`#bar [data-b="${b}"]`); await page.click(`#bar [data-u="${u}"]`);
      if (v === "B") { await page.click('.tab[data-page="side"]'); }
      if (v === "C") { await page.click('#vtog [data-v="side"]'); }
      await page.waitForTimeout(60);
      const ok = await page.evaluate(() => !!document.querySelector("#side path.board") || getComputedStyle(document.getElementById("sideView")).display === "none");
      if (!ok) errors.push(`no side view: ${v} ${b} ${u}`);
      await page.click('.tab[data-page="data"]'); await page.click('.tab[data-page="guide"]'); await page.click('.tab[data-page="viewer"]');
    }
    await page.close();
  }

  // ---- live: a slider redraws the side view; dragging along the side view moves the section; A's two lines line up ----
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    page.on("pageerror", (e) => errors.push("live: " + e.message));
    await page.goto(url("variant=A&bare=1")); await ready(page); await page.waitForTimeout(200);
    const before = await page.evaluate(() => ({ d: document.querySelector("#side path.board").getAttribute("d"), facts: document.getElementById("sideFacts").textContent }));
    await page.evaluate(() => { const el = document.querySelector('input.rng[data-cut="center"][data-key="depth"]'); el.value = 0.5; el.dispatchEvent(new Event("input", { bubbles: true })); });
    await page.waitForTimeout(150);
    const after = await page.evaluate(() => ({ d: document.querySelector("#side path.board").getAttribute("d"), facts: document.getElementById("sideFacts").textContent }));
    results.live = { sliderRedraws: before.d !== after.d, factsBefore: before.facts, factsAfterDepthHalfInch: after.facts };
    // A: the cutting line stands at the same x on the bottom view and the side view
    const xs = await page.evaluate(() => [...document.querySelectorAll("#top line.cutline, #side line.cutline")].map((l) => { const r = l.getBoundingClientRect(); return Math.round((r.left + r.width / 2) * 10) / 10; }));
    results.live.cutLineX = xs;
    // drag on the side view to 12" from the tail
    const target = await page.evaluate(() => { const sk = window.sketch, L = sk.B().L, svg = document.getElementById("side"), r = svg.getBoundingClientRect(), k = +svg.dataset.k;
      const vx = 500 + (L / 2 - 12 * 25.4) * k; return { x: r.left + vx * r.width / 1000, y: r.top + r.height / 2 }; });
    await page.mouse.move(target.x + 80, target.y); await page.mouse.down(); await page.mouse.move(target.x, target.y, { steps: 5 }); await page.mouse.up();
    await page.waitForTimeout(150);
    results.live.dragTo12in = await page.evaluate(() => ({ stationIn: Math.round(window.sketch.state.station / 25.4 * 100) / 100, caption: document.getElementById("secCap").textContent }));
    // picking a Rolled Vee in TAIL puts the rail above the stringer in the tail
    await page.selectOption('select[data-sel="tail"]', "Rolled Vee"); await page.waitForTimeout(150);
    results.live.rolledVeeAt6in = await page.evaluate(() => { const q = window.sketch.sideAt(6 * 25.4); return { railAboveStringerMm: Math.round((q.rail - q.stringer) * 100) / 100, center: window.sketch.state.cuts.center.end / 25.4 }; });
    await page.close();
  }

  // ---- the phone: how tall the pinned drawing is, and how much is left for the controls, on a 390 x 844 iPhone ----
  results.phone = {};
  for (const v of ["A", "B", "C"]) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
    const page = await ctx.newPage(); page.on("pageerror", (e) => errors.push("phone: " + e.message));
    await page.goto(url(`variant=${v}&bare=1`)); await ready(page);
    if (v === "B") await page.click('.tab[data-page="side"]');
    if (v === "C") await page.click('#vtog [data-v="side"]');
    await page.waitForTimeout(200);
    results.phone[v] = await page.evaluate(() => {
      const h = (sel) => { const el = document.querySelector(sel); return el && getComputedStyle(el).display !== "none" ? Math.round(el.getBoundingClientRect().height) : 0; };
      const strip = document.querySelector(".strip").getBoundingClientRect(), tabs = document.querySelector(".tabs").getBoundingClientRect();
      return { topBar: h(".topbar"), drawing: h(".main"), controls: h(".side"), bottomView: h("#top"), sideView: h("#side"), section: h("#sec"),
        sideKeyLines: Math.round(h("#sideKey") / 14), roomAfterTabs: Math.round(strip.right - tabs.right - 6), name: getComputedStyle(document.getElementById("boardName")).display !== "none",
        pageScrolls: document.documentElement.scrollWidth > window.innerWidth };
    });
    await ctx.close();
  }

  results.errors = errors;
  fs.writeFileSync(path.join(OUTDIR, "check-results.json"), JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results, null, 2));
  await browser.close();
})();

const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const { mkdirSync } = require("node:fs");
const dir = "/Users/kontoes/Code/shaper/.planning/sketches/014-wings-tab";
const pictures = `${dir}/pictures`;
mkdirSync(pictures, { recursive: true });
const W1 = { station: 11, depth: 0.375, run: 0.25, smoothing: 0, lock: true, edge: "trailing", finOffset: 0 };
const STINGER = { station: 30, depth: 0.5, run: 0.75, smoothing: 3, lock: false, edge: "trailing", finOffset: 0 };
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const open = async (st, w = 1360, h = 980) => {
    const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 2 });
    page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
    page.on("pageerror", (e) => errors.push(e.message));
    await page.addInitScript((s) => localStorage.setItem("sketch014-picked", JSON.stringify(s)), st);
    await page.goto(`file://${dir}/index.html`);
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(250);
    return page;
  };
  const shot = async (page, name, el = ".device") => { const d = await page.$(el); await d.screenshot({ path: `${pictures}/${name}.png` }); console.log("shot", name); };
  for (const theme of ["daylight", "slate"]) {
    let page = await open({ variant: "b", theme, device: "computer", tab: "wings", wings: [W1] }); await shot(page, `wings-tab-${theme}`); await page.close();
    for (const v of ["a", "b", "c"]) { page = await open({ variant: v, theme, device: "computer", tab: "wings", wings: [W1, STINGER] }); await shot(page, `${v}-stinger-${theme}`); await page.close(); }
  }
  let page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "wings", wings: [W1, STINGER], construction: true }); await shot(page, "b-stinger-construction-on-daylight"); await page.close();
  page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "viewer", wings: [W1, STINGER] }); await shot(page, "viewer-tab-daylight"); await page.close();
  page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "wings", wings: [] });
  await shot(page, "empty-tab-daylight");
  await page.click(".device [data-add]"); await page.waitForTimeout(250);
  await shot(page, "first-wing-popup-daylight");
  console.log("after adding: tab label", await page.$eval(".device .tab.on", (e) => e.textContent), "| show fins", await page.$eval('.device input[data-check="showFins"]', (e) => e.checked));
  await page.close();
  // the slider's range reaches the board's centre, and the jump happens past 24"
  page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "wings", wings: [{ ...W1, lock: false }] });
  const max = await page.$eval('.device input[data-field="station"]', (e) => e.max), min = await page.$eval('.device input[data-field="station"]', (e) => e.min), step = await page.$eval('.device input[data-field="run"]', (e) => e.step + " to " + e.max);
  const radiusTop = await page.$eval('.device input[data-field="smoothing"]', (e) => e.max);
  await page.$eval('.device input[data-field="run"]', (e) => { e.value = "1"; e.dispatchEvent(new Event("input", { bubbles: true })); });
  await page.waitForTimeout(100);
  console.log(`corner radius slider top: ${radiusTop}" for a 3/8" square step; ${await page.$eval('.device input[data-field="smoothing"]', (e) => e.max)}" once the run is 1"`);
  await page.$eval('.device input[data-field="run"]', (e) => { e.value = "0.25"; e.dispatchEvent(new Event("input", { bubbles: true })); });
  await page.$eval('.device input[data-field="station"]', (e) => { e.value = "24"; e.dispatchEvent(new Event("input", { bubbles: true })); });
  await page.waitForTimeout(100);
  const at24 = await page.$eval("svg[data-closeup]", (s) => s.getAttribute("viewBox"));
  await page.$eval('.device input[data-field="station"]', (e) => { e.value = "24.125"; e.dispatchEvent(new Event("input", { bubbles: true })); });
  await page.waitForTimeout(100);
  const past = await page.$eval("svg[data-closeup]", (s) => [s.getAttribute("viewBox"), s.dataset.zs]);
  console.log(`position ${min}" to ${max}" (centre); run step ${step}"; viewBox at 24": ${at24}; at 24 1/8": ${past[0]} (zs ${Number(past[1]).toFixed(2)} px/in)`);
  await page.close();
  // a real drag with the window following (C) and the stinger: the outer point 1" up
  page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "wings", wings: [STINGER], construction: true });
  const outer = await page.$('[data-handle="outer"]'); const ob = await outer.boundingBox();
  const sb = await (await page.$("svg[data-closeup]")).boundingBox(); const vb = await page.$eval("svg[data-closeup]", (s) => [s.viewBox.baseVal.width, s.viewBox.baseVal.height, Number(s.dataset.zs)]);
  const pxPerIn = vb[2] * Math.min(sb.width / vb[0], sb.height / vb[1]);
  await page.mouse.move(ob.x + ob.width / 2, ob.y + ob.height / 2); await page.mouse.down(); await page.mouse.move(ob.x + ob.width / 2, ob.y + ob.height / 2 - pxPerIn, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(150);
  console.log("B drag with a stinger at 30\" (construction on): outer point 1\" up → position", await page.evaluate(() => JSON.parse(localStorage.getItem("sketch014-picked")).wings[0].station));
  await page.close();
  page = await open({ variant: "b", theme: "daylight", device: "phone", tab: "wings", wings: [W1, STINGER] }, 600, 1000); await shot(page, "b-stinger-phone-daylight"); await page.close();
  // with construction off there must be no grab point on the drawing
  page = await open({ variant: "b", theme: "daylight", device: "computer", tab: "wings", wings: [W1] });
  console.log("grab points with Show construction off:", (await page.$$("[data-handle]")).length, "| after the toolbar's construction button:", await (async () => { await page.click('.device [data-toggle="construction"]'); await page.waitForTimeout(150); return (await page.$$("[data-handle]")).length; })());
  await page.close();
  await browser.close();
  console.log(errors.length ? `CONSOLE ERRORS:\n${errors.join("\n")}` : "no console errors");
})().catch((e) => { console.error(e); process.exit(1); });

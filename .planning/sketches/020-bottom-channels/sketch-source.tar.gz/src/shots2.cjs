// Pictures of particular states of sketch 020. Run: node shots2.cjs <index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path"); const fs = require("node:fs");
const url = "file://" + path.resolve(process.argv[2]); const out = process.argv[3]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(url); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const set = (fn) => page.evaluate(fn).then(() => page.waitForTimeout(150));
  // the section through the channels, the ruler of six walls
  await set(() => { const s = window.sketch; s.state.station = 8 * 25.4; s.state.live = "channels"; s.state.active = "channels"; s.render(true); });
  await page.screenshot({ path: path.join(out, "desktop-A-channels-section.png") });
  // a double concave exit under the channels: the double's flat, trough and edge on the ruler
  await page.selectOption('select[data-sel="tail"]', "Double Concave Exit"); await page.waitForTimeout(150);
  await set(() => { const s = window.sketch; s.state.station = s.state.cuts.tail.deep; s.state.live = "tail"; s.state.active = "tail"; s.render(true); });
  await page.screenshot({ path: path.join(out, "desktop-A-double-section.png") });
  // the layout-marks table
  await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(150);
  await page.evaluate(() => { const p = document.getElementById("dataPanel"); p.scrollTop = p.scrollHeight; });
  await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-A-data-marks.png") });
  await page.click('.tabs [data-page="viewer"]');
  // eight channels, parallel to the stringer, on the Fish
  await page.click('#bar [data-b="fish"]'); await page.waitForTimeout(150);
  await set(() => { const s = window.sketch; s.state.ch.count = 8; s.state.ch.run = "parallel"; s.state.station = 6 * 25.4; s.state.live = "channels"; s.state.active = "channels"; s.render(true); });
  await page.screenshot({ path: path.join(out, "desktop-fish-8-parallel.png") });
  // the winged Fish, narrowest rule, section just ahead of the wing
  await page.click('#bar [data-b="fishwing"]'); await page.waitForTimeout(150);
  await set(() => { const s = window.sketch; s.state.station = 12 * 25.4; s.state.live = "channels"; s.state.active = "channels"; s.render(true); });
  await page.screenshot({ path: path.join(out, "desktop-fishwing-narrow-12.png") });
  await page.close();
  // the phone: the channels section and the TAIL card in variant B scrolled to its channels block
  const ph = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  await ph.goto(url); await ph.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  await ph.evaluate(() => { const s = window.sketch; s.state.station = 8 * 25.4; s.state.live = "channels"; s.state.active = "channels"; s.render(true); }); await ph.waitForTimeout(150);
  await ph.screenshot({ path: path.join(out, "phone-A-channels-section.png") });
  await ph.click('#bar [data-v="B"]'); await ph.waitForTimeout(100);
  await ph.evaluate(() => { const s = window.sketch; s.state.active = "tail"; s.state.live = "channels"; s.render(true); }); await ph.waitForTimeout(150);
  await ph.evaluate(() => { const c = document.getElementById("controls"); const el = c.querySelector('[data-cut="channels"]'); c.scrollTop = el.offsetTop - 70; }); await ph.waitForTimeout(100);
  await ph.screenshot({ path: path.join(out, "phone-B-tail-channels.png") });
  await ph.close(); await browser.close();
  console.log("done");
})();

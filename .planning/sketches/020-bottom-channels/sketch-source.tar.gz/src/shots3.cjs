const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path"); const fs = require("node:fs");
const url = "file://" + path.resolve(process.argv[2]); const out = process.argv[3]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(url); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const set = (fn) => page.evaluate(fn).then(() => page.waitForTimeout(150));
  // the channels card: Longest beside Run, the Stagger slider under Start
  await set(() => { const s = window.sketch; s.state.live = "channels"; s.state.active = "channels"; s.render(true); document.querySelector('.sidesec[data-sec="channels"]').scrollIntoView({ block: "start" }); });
  const card = await page.$('.sidesec[data-sec="channels"]'); await card.screenshot({ path: path.join(out, "desktop-A-channels-card.png") });
  // the Fish with the outer pair longest, 3" stagger, the section 6" from the tail
  await page.click('#bar [data-b="fish"]'); await page.waitForTimeout(120);
  await set(() => { const s = window.sketch; s.state.live = "channels"; s.state.active = "channels"; s.render(true); });
  await page.selectOption("select[data-longer]", "outer"); await page.waitForTimeout(80);
  await set(() => { const s = window.sketch; s.state.ch.stagger = 3 * 25.4; s.state.station = 6 * 25.4; s.render(true); });
  await page.screenshot({ path: path.join(out, "desktop-fish-outer-longest.png") });
  console.log((await page.evaluate(() => [...document.querySelectorAll('.sidesec[data-sec="channels"] [data-lbl]')].map((e) => e.textContent))).join(" / "));
  await browser.close();
})();

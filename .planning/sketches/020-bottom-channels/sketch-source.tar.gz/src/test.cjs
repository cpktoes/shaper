// Headless checks of sketch 020 at a computer's width and an upright phone's, with pictures.
// Run: node test.cjs <path-to-index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const fs = require("node:fs");

const file = process.argv[2];
const out = process.argv[3];
fs.mkdirSync(out, { recursive: true });
const url = "file://" + path.resolve(file);

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  const errors = [];

  // ---- a computer: 1280 x 800 ----
  let page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("pageerror", (e) => errors.push("desktop: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("desktop console: " + m.text()); });
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const desk = await page.evaluate(() => {
    const app = document.getElementById("app");
    const side = document.querySelector(".side").getBoundingClientRect();
    const sec = document.getElementById("sec").getBoundingClientRect();
    return { phone: app.classList.contains("phone"), side: [side.x, side.width, side.height], sec: [sec.width, sec.height],
      rects: document.querySelectorAll("#top .shade rect").length, isos: document.querySelectorAll("#top .iso").length, foot: document.getElementById("foot").innerText, sections: document.querySelectorAll(".sidesec").length,
      shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, secrow: document.querySelectorAll("#secrow .tab").length,
      ruler: document.querySelectorAll("#sec .ruler").length, rulerWords: document.getElementById("sec").textContent.includes("Off the stringer"), litresOff: window.sketch.litresOff() };
  });
  console.log("desktop", JSON.stringify(desk));
  if (desk.phone) problems.push("desktop got the phone layout");
  if (desk.side[1] !== 340) problems.push("sidebar is not 340 wide: " + desk.side[1]);
  if (desk.shown !== 4 || desk.secrow !== 4) problems.push("variant A should have four cards and a four-button switch: " + desk.shown + "/" + desk.secrow);
  if (desk.rects < 100) problems.push("no shade drawn");
  if (desk.isos < 4) problems.push("too few contour lines for 1/16\" steps on a 1/4\" cut: " + desk.isos);
  if (desk.ruler < 3) problems.push("the layout-marks ruler is missing on a computer");
  await page.screenshot({ path: path.join(out, "desktop-A-daylight.png") });

  // the channels take foam: litres with 6 channels > without; the planning memory's test single still ~0.55 L alone
  const check = await page.evaluate(() => {
    const s = window.sketch; const B = s.state; const IN = 25.4;
    const withCh = s.litresOff(); const edges = s.channelEdges(B.ch, B.ch.deep).map((e) => e.map((v) => +(v / IN).toFixed(2)));
    const marks = s.marksOf("channels", B.ch, B.ch.deep).map((m) => m.col);
    // the channel is a ramp into a wall: nothing at its top edge, the full depth at the wall (stringer side by default)
    // the stringer is the first peak, the floor deepens outward to the wall at the rail side, the wall's top is the next peak
    const [a0, b0] = s.channelEdges(B.ch, B.ch.deep)[0]; const atWall = s.foamOff(B.ch.deep, b0 - 0.3), atTop = s.foamOff(B.ch.deep, a0 + 0.3), mid = s.foamOff(B.ch.deep, (a0 + b0) / 2);
    const nextPeak = s.foamOff(B.ch.deep, b0 + 0.3);
    B.ch.wall = "stringer"; const atWallR = s.foamOff(B.ch.deep, a0 + 0.3); B.ch.wall = "rail";
    const fit = s.channelFit(B.ch); const fitIn = { w: fit.w / IN, offRail: fit.offRail / IN, squeezed: fit.squeezed };
    // toe-in: the walls move inward toward the nose and outward toward the tail
    B.ch.run = "toe"; const toeNose = s.channelEdges(B.ch, B.ch.deep + 6 * IN)[0][1], toeTail = s.channelEdges(B.ch, B.ch.deep - 4 * IN)[0][1]; B.ch.run = "rail";
    B.ch.count = 0; const noCh = s.litresOff();
    const c = B.cuts.center;
    B.cuts.nose = { ...B.cuts.nose, kind: "flat", depth: 0 }; B.cuts.tail = { ...B.cuts.tail, kind: "flat", depth: 0 };
    Object.assign(c, { kind: "single", off: 2 * IN, start: 74 * IN - 16 * IN, deep: (36 + 10.88) / 2 * IN, end: 6 * IN, depth: 3 / 16 * IN, smooth: 50, pointed: false, spiral: false });
    const single = s.litresOff();
    // a double's Off Stringer leaves the stringer whole
    Object.assign(c, { kind: "double", off: 1.5 * IN, offS: 1 * IN, trough: 3 * IN, depth: 1 / 8 * IN, smooth: 50 });
    const atStringer = s.foamOff(c.deep, 0), atHalf = s.foamOff(c.deep, 0.5 * IN), atTrough = s.foamOff(c.deep, 3 * IN);
    return { withCh, noCh, edges, marks, single, atStringer, atHalf, atTrough, atWall, atTop, mid, atWallR, nextPeak, fitIn, toeNose: toeNose / IN, toeTail: toeTail / IN };
  });
  console.log("channels check:", JSON.stringify(check));
  if (!(check.atWall > 5.5 && check.atTop < 1.2 && check.mid > 2 && check.mid < 4.5)) problems.push("the channel is not a ramp deepening out to a wall at the rail side: " + JSON.stringify([check.atTop, check.mid, check.atWall]));
  if (!(check.nextPeak < 1.2)) problems.push("the top of the wall should be the next channel's peak: " + check.nextPeak);
  if (!(check.atWallR > 5.5)) problems.push("the wall did not move to the stringer side: " + check.atWallR);
  if (!(check.fitIn.w === 1.75 && !check.fitIn.squeezed && check.fitIn.offRail > 1 && check.fitIn.offRail < 2)) problems.push("six channels at 1 3/4 should fit the Shortboard with the last wall 1-2 in off the rail: " + JSON.stringify(check.fitIn));
  if (!(check.toeNose < 1.75 - 0.2 && check.toeTail > 1.75 + 0.1)) problems.push("toe-in should move the walls inward toward the nose and outward toward the tail: " + JSON.stringify([check.toeNose, check.toeTail]));
  if (!(check.withCh > check.noCh + 0.1)) problems.push("six channels took no foam: " + check.withCh + " vs " + check.noCh);
  if (check.edges.length !== 3 || check.edges[0][0] !== 0 || check.edges[0][1] !== check.edges[1][0]) problems.push("six channels should be three a side abutting from the stringer: " + JSON.stringify(check.edges));
  if (check.marks.length !== 3 || check.marks[0] !== "Wall 1") problems.push("channel marks should be the three walls: " + check.marks.join(","));
  if (!(check.single > 0.4 && check.single < 0.7)) problems.push("litres off the test single is off: " + check.single);
  if (check.atStringer > 1e-6 || check.atHalf > 1e-6 || check.atTrough < 2) problems.push("a double's Off Stringer flat is not flat: " + JSON.stringify([check.atStringer, check.atHalf, check.atTrough]));

  // the winged Fish: the two Off Rail rules give different edges at the wing's step, and the narrowest one never steps
  await page.click('#bar [data-b="fishwing"]'); await page.waitForTimeout(120);
  const wing = await page.evaluate(() => {
    const s = window.sketch; const B = s.state; const IN = 25.4;
    // the winged Fish opens with an extending single concave 1 3/4" off the rail: its edge is what the rule moves
    const probe = () => { const c = B.cuts.tail; return [s.cutHalfWidth(c, 12 * IN) / IN, s.cutHalfWidth(c, 10 * IN) / IN, c.off / IN]; };
    B.wingRule = "narrow"; const narrow = probe(); B.wingRule = "natural"; const natural = probe(); B.wingRule = "narrow"; s.render(false);
    return { narrow, natural, offRail: B.ch.off / IN, rail10: s.railHalfWidth ? s.railHalfWidth(10 * IN) / IN : null, wings: document.getElementById("topCap").textContent };
  });
  console.log("winged fish, the single's edge at 12\" and 10\" (narrow / natural):", JSON.stringify(wing));
  if (!(Math.abs(wing.narrow[0] - wing.natural[0]) > 0.2)) problems.push("the wing rule makes no difference ahead of the wing");
  // behind the wing's inner corner the narrowest rule measures off the real rail; the natural rule sits outside it by the wing's take
  if (wing.rail10 !== null && Math.abs(wing.narrow[1] - (wing.rail10 - wing.narrow[2])) > 0.02) problems.push("the narrowest rule should measure the concave's edge off the real rail behind the wing: " + wing.narrow[1] + " vs " + (wing.rail10 - wing.narrow[2]));
  if (!(wing.natural[1] > wing.narrow[1] + 0.1)) problems.push("the natural rule should sit outside the real rail behind the wing");
  if (!/wing/.test(wing.wings)) problems.push("the winged board's caption does not say so");
  await page.screenshot({ path: path.join(out, "desktop-fishwing-narrow.png") });
  await page.click('#bar [data-w="natural"]'); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-fishwing-natural.png") });
  await page.click('#bar [data-w="narrow"]'); await page.click('#bar [data-b="shortboard"]'); await page.waitForTimeout(120);

  // drag the section line: the section caption must follow
  const before = await page.textContent("#secCap");
  const grab = await page.$("#grab");
  const gb = await grab.boundingBox();
  await page.mouse.move(gb.x + gb.width / 2, gb.y + gb.height / 2);
  await page.mouse.down();
  await page.mouse.move(gb.x + 150, gb.y + gb.height / 2, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(100);
  const after = await page.textContent("#secCap");
  console.log("section caption before/after drag:", before, "|", after);
  if (before === after) problems.push("dragging the section line did not move the section");

  // every variant, theme and units pair draws without error; the variants put the channels where they say
  for (const v of ["A", "B", "C"]) for (const t of ["daylight", "chalk", "slate", "phosphor"]) {
    await page.click(`#bar [data-v="${v}"]`); await page.click(`#bar [data-t="${t}"]`); await page.waitForTimeout(60);
    if (t === "daylight") {
      const shape = await page.evaluate(() => ({ cards: [...document.querySelectorAll(".sidesec")].map((e) => e.dataset.sec), secrow: document.querySelectorAll("#secrow .tab").length,
        tailHasChannels: !!document.querySelector('.sidesec[data-sec="tail"] [data-cut="channels"]'), tailPicker: [...document.querySelectorAll('select[data-sel="tail"] option')].map((o) => o.value),
        tailCut: window.sketch.state.cuts.tail.kind, foot: document.getElementById("foot").innerText.split("\n")[1] }));
      console.log("variant", v, JSON.stringify(shape));
      if (v === "A" && (shape.cards.length !== 4 || shape.secrow !== 4)) problems.push("A should have a CHANNELS card and switch button");
      if (v === "B" && (shape.cards.length !== 3 || !shape.tailHasChannels)) problems.push("B should carry the channels inside the TAIL card");
      if (v === "C" && (!shape.tailPicker.includes("Channels") || shape.tailCut !== "channels")) problems.push("C should offer Channels as a tail cut and have the Shortboard open on it");
    }
    if (v === "A" || t === "slate") await page.screenshot({ path: path.join(out, `desktop-${v}-${t}.png`) });
  }
  await page.click('#bar [data-v="A"]'); await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(80);
  const metricFoot = await page.textContent("#foot");
  const metricLbl = await page.evaluate(() => [...document.querySelectorAll("#sections [data-lbl]")].map((e) => e.textContent));
  console.log("metric foot:", metricFoot.replace(/\n/g, " | "));
  console.log("metric labels:", metricLbl.join(" / "));
  if (!/mm/.test(metricFoot)) problems.push("metric foot shows no millimetres");
  if (!metricLbl.some((l) => / cm from the/.test(l))) problems.push("metric station labels do not read in cm");
  if (!metricLbl.some((l) => /Depth — \d+ mm/.test(l))) problems.push("metric depth does not read in whole mm");
  if (!metricLbl.some((l) => /Off Stringer — \d+ mm/.test(l))) problems.push("metric Off Stringer does not read in whole mm");
  await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  const data = await page.evaluate(() => ({ tables: document.querySelectorAll("#dataPanel table").length, rows: document.querySelectorAll("#dataPanel tbody tr").length, heads: [...document.querySelectorAll("#dataPanel th")].map((e) => e.textContent.trim()) }));
  console.log("DATA (metric):", JSON.stringify(data));
  if (data.tables !== 2) problems.push("DATA should have the depths table and the layout-marks table: " + data.tables);
  if (!data.heads.some((h) => /Wall 3/.test(h)) || !data.heads.some((h) => /Center edge/.test(h))) problems.push("the layout-marks table lacks its columns: " + data.heads.join(","));
  await page.screenshot({ path: path.join(out, "desktop-data-metric.png") });
  await page.click('#bar [data-u="imperial"]'); await page.click('#bar [data-t="daylight"]');
  await page.click('.tabs [data-page="viewer"]');
  for (const b of ["fish", "midlength", "longboard"]) { await page.click(`#bar [data-b="${b}"]`); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${b}.png`) }); }
  // the sketch bar's phone frame on a computer must give the same phone stack
  await page.click('#bar [data-b="shortboard"]'); await page.click('#bar [data-f="1"]'); await page.waitForTimeout(150);
  const framed = await page.evaluate(() => ({ topbar: getComputedStyle(document.querySelector(".topbar")).display, w: document.getElementById("app").getBoundingClientRect().width,
    shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, sec: document.getElementById("sec").getBoundingClientRect().height }));
  console.log("phone frame on a computer:", JSON.stringify(framed));
  if (framed.topbar !== "flex" || framed.w !== 390 || framed.shown !== 1) problems.push("the phone frame does not give the phone stack");
  if (framed.sec < 90) problems.push("the framed section drawing is squashed: " + framed.sec);
  await page.screenshot({ path: path.join(out, "desktop-phone-frame.png") });
  await page.click('#bar [data-f="0"]');
  await page.close();

  // ---- an upright phone: 390 x 844 (iPhone 14), touch ----
  page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push("phone: " + e.message));
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const ph = await page.evaluate(() => {
    const main = document.querySelector(".main").getBoundingClientRect();
    const side = document.querySelector(".side").getBoundingClientRect();
    const bar = document.querySelector(".topbar").getBoundingClientRect();
    const shown = [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec);
    const secrow = getComputedStyle(document.getElementById("secrow")).display;
    const row = document.getElementById("secrow").getBoundingClientRect();
    return { topbar: [bar.height, getComputedStyle(document.querySelector(".topbar")).display], main: [main.y, main.height], side: [side.y, side.height], shown, secrow, rowW: row.width, rowH: row.height,
      tabs: document.querySelectorAll("#secrow .tab").length, ruler: document.querySelectorAll("#sec .ruler").length, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight };
  });
  console.log("phone", JSON.stringify(ph));
  if (ph.topbar[1] !== "flex" || ph.main[0] > ph.side[0]) problems.push("phone did not get the phone layout (width alone)");
  if (ph.shown.length !== 1) problems.push("phone should show one section's controls, shows " + ph.shown.join(","));
  if (ph.secrow === "none" || ph.tabs !== 4) problems.push("phone has no four-button switch in A");
  if (ph.rowH > 40) problems.push("the four-button switch wrapped onto two lines: " + ph.rowH);
  if (ph.ruler > 0) problems.push("the layout ruler should stay off a phone's section");
  if (ph.docScroll > ph.inner + 2) problems.push("the phone page scrolls as a whole (" + ph.docScroll + " > " + ph.inner + ")");
  const boxes = await page.evaluate(() => ({ top: document.getElementById("top").getBoundingClientRect().height, sec: document.getElementById("sec").getBoundingClientRect().height, bar: document.getElementById("bar").getBoundingClientRect().height }));
  console.log("phone boxes:", JSON.stringify(boxes));
  if (boxes.sec < 90) problems.push("the phone's section drawing is squashed: " + boxes.sec);
  if (boxes.bar > 60) problems.push("the sketch bar is too tall on a phone: " + boxes.bar);
  await page.screenshot({ path: path.join(out, "phone-A-daylight.png") });
  // the switch changes which section's controls show, the channels card included
  await page.tap('#secrow [data-sec="channels"]'); await page.waitForTimeout(80);
  const shownCh = await page.evaluate(() => [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec));
  console.log("after tapping CHANNELS:", shownCh);
  if (shownCh.join() !== "channels") problems.push("CHANNELS switch did not show the channel controls");
  await page.screenshot({ path: path.join(out, "phone-A-channels.png") });
  // a thumb tap on the board moves the section
  const b4 = await page.textContent("#secCap");
  const topBox = await (await page.$("#top")).boundingBox();
  await page.touchscreen.tap(topBox.x + topBox.width * 0.3, topBox.y + topBox.height / 2);
  await page.waitForTimeout(80);
  const aft = await page.textContent("#secCap");
  console.log("phone tap on the board:", b4, "|", aft);
  if (b4 === aft) problems.push("tapping the board on a phone did not move the section");
  await page.click('#bar [data-b="fishwing"]'); await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "phone-fishwing-slate.png") });
  await page.click('#bar [data-v="B"]'); await page.tap('#secrow [data-sec="tail"]'); await page.click('#bar [data-t="phosphor"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-B-tail-phosphor.png") });
  await page.click('#bar [data-v="C"]'); await page.click('#bar [data-t="daylight"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-C-tail.png") });
  await page.click('#bar [data-v="A"]'); await page.click('#bar [data-u="metric"]'); await page.click('#bar [data-b="longboard"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "phone-longboard-metric.png") });
  await page.click('#bar [data-b="shortboard"]'); await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-data.png") });
  await page.close();

  await browser.close();
  console.log("\nERRORS:", errors.length ? errors.join("\n") : "none");
  console.log("PROBLEMS:", problems.length ? problems.join("\n") : "none");
  process.exit(problems.length || errors.length ? 1 : 0);
})();

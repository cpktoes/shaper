/* Sketch 020's real board figures, read from the app's own maths. Never hand-type a board number.
   Sketch 019's reader plus: the curve the shaper drew (wingless) and the narrowest outline carried forward through
   any wings — the two candidates for what "Off Rail" is measured from — and a fifth board, the Fish with a wing. */
import { writeFileSync } from "node:fs";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/__fixtures__/phase16-boards";
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, summarizeDesign, deriveEffectiveFins, LIVE_DESIGN_RULES } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/design";
import { buildOutline, foamHalfWidth, sampleOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/outline";
import { curveHalfWidthAt, wingFootprint, placedWings, type Wing } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/wings";
import { boardSections } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/volume";
import { sampledFinishedRail } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/finished-rail";
import { computeFinPlacement, importedFinTailFromOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/presets";
import { mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/units";

const STATIONS = 241;      // the long table: width, thickness, every 1/240 of the board
const SECTIONS = 49;       // real cross-sections down the board
// across the half-section, as a share of the half-width: closer together at the rail where it turns
const U = [0, .2, .4, .55, .68, .78, .85, .9, .93, .955, .975, .988, .996, 1];
const r1 = (v: number) => Math.round(v * 10) / 10;
const IN = 25.4;

function at(run: [number, number][], x: number): number {
  for (let i = 0; i < run.length - 1; i++) {
    const [x0, y0] = run[i], [x1, y1] = run[i + 1];
    if ((x >= x0 && x <= x1) || (x >= x1 && x <= x0)) {
      const t = x1 === x0 ? 0 : (x - x0) / (x1 - x0);
      return y0 + (y1 - y0) * t;
    }
  }
  return run[run.length - 1][1];
}

const all = phase16Boards();
type Fields = ReturnType<typeof phase16Boards>[number]["fields"];
const jobs: { id: string; name: string; fields: Fields }[] = [];
for (const preset of BOARD_PRESETS) {
  const hard = preset.rails.tailHardEdge ? "hard" : "soft";
  const board = all.find((b) => b.label === `${preset.id}|asis|${hard}`)!;
  jobs.push({ id: preset.id, name: preset.name, fields: board.fields });
}
// the fifth board: the Fish with one wing, 1/4" deep with a 1" run, placed by hand 4" ahead of its fins' station
{
  const fish = jobs.find((j) => j.id === "fish")!;
  const g0 = buildOutline(fish.fields.outline);
  const fins0 = computeFinPlacement(
    deriveEffectiveFins(fish.fields.fins, fish.fields.finsImportTemplate, fish.fields.outline, g0),
    fish.fields.finsImportTemplate ? importedFinTailFromOutline(g0) : null,
  );
  const front = fins0.marks.some((m) => m.role === "front") ? fins0.marks.filter((m) => m.role === "front") : fins0.marks;
  const finS = Math.max(...front.map((m) => m.offTail as number));
  const wing: Wing = { station: mm(finS + 4 * IN), depth: mm(IN / 4), run: mm(IN), radius: mm(0), lock: null, finOffset: mm(0) };
  jobs.push({ id: "fishwing", name: "Fish, winged", fields: { ...fish.fields, outline: { ...fish.fields.outline, wings: [wing] } } });
}

const out: unknown[] = [];
for (const job of jobs) {
  const fields = job.fields;
  const g = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const input = designCrossSectionInput(g, profile, rails, fields.outline.length);
  const L = fields.outline.length as number;
  const litres = summarizeDesign(fields).volumeLitres as number;
  const wings = placedWings(fields.outline.wings ?? [], g);
  const pod = g.tailPodStation as number;
  // the narrowest outline carried forward: behind the last wing it IS the rail; ahead, each wing's full depth stays
  // taken off the curve (the fade toward the tail pod is the app's own), so the reference never steps
  const narrowAt = (s: number) => {
    let take = 0;
    if (s > pod) for (const w of wings) { const inner = wingFootprint(w).inner as number; take += (w.depth as number) * (inner > pod ? Math.max(0, Math.min(1, (s - pod) / (inner - pod))) : 0); }
    return Math.max(0, (curveHalfWidthAt(g, mm(s)) as number) - take);
  };

  const curve: number[] = [], natural: number[] = [], narrow: number[] = [], foam: number[] = [], thick: number[] = [];
  for (let i = 0; i < STATIONS; i++) {
    const s = mm((i / (STATIONS - 1)) * L);
    curve.push(r1(sampleOutline(g, s)));
    natural.push(r1(curveHalfWidthAt(g, s)));
    narrow.push(r1(narrowAt(s as number)));
    foam.push(r1(foamHalfWidth(g, s)));
    thick.push(r1(profile.thicknessAt(s)));
  }

  const stations = Array.from({ length: SECTIONS }, (_, i) => mm((i / (SECTIONS - 1)) * L));
  const secs = boardSections(input, stations);
  const sections = secs.map((sec) => {
    const s = sec.station as number;
    const W = sec.halfWidth as number;
    const inner = Math.max(0, (sampleOutline(g, sec.station) as number) - W);
    if (!sec.result || W <= 0) return { s: r1(s), W: 0, T: r1(sec.thickness), inner: r1(inner), lo: U.map(() => 0), hi: U.map(() => 0) };
    const half = sec.blended ?? sampledFinishedRail(sec.result, sec.domed, W);
    let apex = 0;
    for (let i = 1; i < half.length; i++) if (half[i][0] > half[apex][0]) apex = i;
    const deck = half.slice(0, apex + 1) as [number, number][];
    const bottom = half.slice(apex) as [number, number][];
    return {
      s: r1(s), W: r1(W), T: r1(sec.thickness), inner: r1(inner),
      hi: U.map((u) => r1(at(deck, u * W))),
      lo: U.map((u) => r1(at(bottom, u * W))),
    };
  });

  const fins = computeFinPlacement(
    deriveEffectiveFins(fields.fins, fields.finsImportTemplate, fields.outline, g),
    fields.finsImportTemplate ? importedFinTailFromOutline(g) : null,
  );
  const frontMarks = fins.marks.some((m) => m.role === "front") ? fins.marks.filter((m) => m.role === "front") : fins.marks;
  out.push({
    id: job.id, name: job.name, L: r1(L), litres,
    wide: r1(g.widePointStation), widePointWidth: r1(fields.outline.widePointWidth as number),
    fin: r1(Math.max(...frontMarks.map((m) => m.offTail as number))), finWord: fins.marks.some((m) => m.role === "front") ? "Front fins" : "Fin",
    finSetup: fields.fins.finSetup, tail: fields.outline.tail.kind,
    close: r1(g.centreCloseStation), block: r1(g.points[0].halfWidth), first: r1(g.points[0].station),
    wings: wings.map((w) => ({ station: r1(w.station), depth: r1(w.depth), run: r1(w.run), inner: r1(wingFootprint(w).inner) })),
    outline: g.points.map((p) => [r1(p.station), r1(p.halfWidth)]),
    curve, natural, narrow, foam, thick, sections,
  });
  const wingNote = wings.length ? ` wing at ${((wings[0].station as number) / IN).toFixed(2)}" depth ${((wings[0].depth as number) / IN).toFixed(3)}" inner ${((wingFootprint(wings[0]).inner as number) / IN).toFixed(2)}"` : "";
  console.log(job.name, "L", (L / IN).toFixed(2), "litres", litres.toFixed(2), "wide", ((g.widePointStation as number) / IN).toFixed(2),
    "fin", (Math.max(...frontMarks.map((m) => m.offTail as number)) / IN).toFixed(2), "pod", (pod / IN).toFixed(2), wingNote);
  if (wings.length) {
    for (const sIn of [6, 9, 10, 11, 11.5, 12, 14, 20]) { const s = sIn * IN; console.log(`  at ${sIn}": rail ${(sampleOutline(g, mm(s)) / IN).toFixed(3)} natural ${(curveHalfWidthAt(g, mm(s)) / IN).toFixed(3)} narrow ${(narrowAt(s) / IN).toFixed(3)}`); }
  }
}
writeFileSync("/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-unruffled-jackson-c76275/7b5389e2-7382-49ed-ba5a-3a8051c827d3/scratchpad/020/boards.json", JSON.stringify({ U, boards: out }));

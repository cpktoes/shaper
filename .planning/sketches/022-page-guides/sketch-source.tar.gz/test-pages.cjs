// Headless checks of sketch 022's round two: TEMPLATE, RAILS, VOLUME and FINS, on a computer and an upright phone, with pictures.
// Run: node test-pages.cjs <path-to-index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path"); const fs = require("node:fs");
const file = process.argv[2], out = process.argv[3]; fs.mkdirSync(out, { recursive: true });
const url = "file://" + path.resolve(file);
const PAGES = {
  outline: { tabs: "viewer,wings,guide", words: "VIEWER|ADD WINGS|GUIDE", cards: 22, heads: "Board Length,Nose Controls,Widepoint Controls,Tail Controls,Wings", tags: { length: `6'2"`, width: '18 3/4"', offset: '-1"', tail_squash: "On this board", tailBlock: '4"', noseAngle: "50°", wingAdd: "None yet", depth: "Diamond & swallow only" }, ghosted: 17, infos: 0, title: "Template Builder" },
  rails: { tabs: "viewer,data,instructions,guide", words: "VIEWER|DATA|INSTRUCTIONS|GUIDE", cards: 17, heads: "Inputs,Nose Rail · Center Rail · Tail Rail,Advanced", tags: { importFoil: "On this board", thickness: '2 1/4"', family: "med/knifey", ratio: "60/40", hardEdge: "On this board", deckProfile: '2 1/4" · Flat' }, ghosted: 16, title: "Rail Band Calculator" },
  volume: { tabs: "estimate,guide", words: "ESTIMATE|GUIDE", cards: 8, heads: "Inputs,What the ESTIMATE card reads", tags: { importVol: "On this board", volLength: `6'2"`, volWidth: '18 3/4"', boardType: "Balanced", volume: "29.61 L" }, ghosted: 3, title: "Volume Estimator" },
  fins: { tabs: "viewer,data,guide", words: "VIEWER|DATA|GUIDE", cards: 23, heads: "Inputs,Convention,Single Fin,Twin,Thruster,2+1,Quad,Advanced", tags: { setup_thruster: "On this board", thruster_basic: "On this board", importFins: "On this board", finBase: '4 1/2"', convention: 'to 1/16"', quad_mckeeLB: `Needs 8'0"` }, ghosted: 4, infos: 14, title: "Fin Setup & Placement" },
};
(async () => {
  const browser = await chromium.launch(); const problems = [], errors = [];
  let page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("pageerror", (e) => errors.push("desktop: " + e.message)); page.on("console", (m) => { if (m.type() === "error") errors.push("desktop console: " + m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#svg-viewer path.board").length > 0);
  const order = await page.evaluate(() => [...document.querySelectorAll("#bar [data-pg]")].map((b) => b.dataset.pg + ":" + b.textContent));
  if (order.join() !== "outline:Template,rocker:Rocker,rails:Rails,volume:Volume,fins:Fins") problems.push("the bar's Page buttons should be the app's five pages in order: " + order.join());
  for (const [pg, want] of Object.entries(PAGES)) {
    await page.click(`#bar [data-pg="${pg}"]`); await page.waitForTimeout(250);
    const d = await page.evaluate(() => { const vis = (sel) => [...document.querySelectorAll(sel)].filter((e) => getComputedStyle(e).display !== "none");
      return { tabs: vis(".tabs .tab").map((e) => e.dataset.page), words: vis(".tabs .tab").map((e) => e.innerText.trim()), title: document.getElementById("pageTitle").textContent, nav: (document.querySelector(".nav .links a.on") || {}).textContent,
        boards: document.querySelectorAll("#svg-viewer path, #svg-viewer line, #panel-estimate .estrow").length, labels: [...document.querySelectorAll("#sidebar .lbl, #sidebar .check")].map((e) => e.textContent.trim()).slice(0, 14) }; });
    console.log(pg, JSON.stringify(d));
    if (d.tabs.join() !== want.tabs) problems.push(`${pg}: tabs should be ${want.tabs}: ` + d.tabs.join());
    if (d.words.join("|") !== want.words) problems.push(`${pg}: tab words: ` + d.words.join("|"));
    if (d.title !== want.title) problems.push(`${pg}: the sidebar title should be the page's: ` + d.title);
    if (d.boards < 3) problems.push(`${pg}: the first tab draws nothing`);
    if (pg === "fins") { // both rail fins, one each side of the stringer, and the center fin between them
      const xs = await page.evaluate(() => [...new Set([...document.querySelectorAll("#svg-viewer line.finmark")].map((l) => Math.round(+l.getAttribute("x1"))))].sort((a, b) => a - b));
      if (xs.length !== 3 || Math.abs(xs[0] + xs[2] - 2 * xs[1]) > 2) problems.push("fins: the VIEWER should draw a rail fin each side of the center fin: " + xs.join(","));
    }
    for (const t of want.tabs.split(",")) { if (t === "guide" || t === "viewer" || t === "estimate") continue; await page.click(`.tabs [data-page="${t}"]`); await page.waitForTimeout(150); const len = await page.evaluate((t) => (document.getElementById("panel-" + t) || { innerHTML: "" }).innerHTML.length, t); if (len < 40) problems.push(`${pg}: the ${t} tab is empty`); if (t === "data" || t === "wings") await page.screenshot({ path: path.join(out, `desktop-${pg}-${t}.png`) }); }
    await page.click('.tabs [data-page="viewer"], .tabs [data-page="estimate"]').catch(() => {}); await page.waitForTimeout(150); await page.screenshot({ path: path.join(out, `desktop-${pg}-viewer.png`) });
    await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(350);
    const g = await page.evaluate(() => { const cards = [...document.querySelectorAll("#panel-guide .card")];
      return { n: cards.length, heads: [...document.querySelectorAll("#panel-guide .datahead")].map((e) => e.firstChild.textContent.trim()), tags: Object.fromEntries(cards.map((c) => [c.dataset.key, (c.querySelector("h4 .now") || {}).textContent || ""])),
        noPic: cards.filter((c) => !c.querySelector("svg") || c.querySelectorAll("svg path, svg line").length < 3).map((c) => c.dataset.key), noHow: cards.filter((c) => !/How to shape\S/.test((c.querySelector("p.how") || {}).textContent || "")).map((c) => c.dataset.key),
        badSent: cards.filter((c) => { const k = c.querySelector("p").textContent.split(/\.\s+/).length; return k < 2 || k > 4; }).map((c) => c.dataset.key), ghosted: cards.filter((c) => c.querySelectorAll("svg .ghost").length > 0).map((c) => c.dataset.key),
        cols: new Set([...document.querySelectorAll("#panel-guide .cards")].flatMap((cs) => [...cs.querySelectorAll(".card")].map((c) => Math.round(c.getBoundingClientRect().x)))).size, scroll: document.getElementById("panel-guide").scrollHeight > document.getElementById("panel-guide").clientHeight,
        overflow: cards.filter((c) => c.scrollWidth > c.clientWidth + 1).length, note: document.querySelector("#panel-guide .guidenote").textContent,
        infos: cards.filter((c) => /Model info\S/.test((c.querySelector("p.info") || {}).textContent || "")).map((c) => c.dataset.key),
        badCap: cards.filter((c) => { const cap = c.querySelector(".ghostcap"); return cap && /^dashed/.test(cap.textContent) && !c.querySelectorAll("svg .ghost").length; }).map((c) => c.dataset.key),
        order: cards.map((c) => c.dataset.key) }; });
    console.log(pg + " guide", JSON.stringify({ n: g.n, heads: g.heads, ghosted: g.ghosted.length, cols: g.cols, tags: g.tags }));
    if (g.n !== want.cards) problems.push(`${pg}: GUIDE should have ${want.cards} cards: ${g.n}`);
    if (g.heads.join() !== want.heads) problems.push(`${pg}: GUIDE groups: ` + g.heads.join(" | "));
    if (g.noPic.length) problems.push(`${pg}: cards without a cartoon: ` + g.noPic.join(","));
    if (g.noHow.length) problems.push(`${pg}: cards without a How to shape: ` + g.noHow.join(","));
    if (g.badSent.length) problems.push(`${pg}: cards with the wrong number of sentences: ` + g.badSent.join(","));
    if (g.ghosted.length !== want.ghosted) problems.push(`${pg}: ${want.ghosted} cards should carry a pushed drawing in dashes, got ${g.ghosted.length}: ` + g.ghosted.join(","));
    if ((want.infos || 0) !== g.infos.length) problems.push(`${pg}: ${want.infos || 0} cards should carry a Model info note, got ${g.infos.length}: ` + g.infos.join(","));
    if (g.badCap.length) problems.push(`${pg}: a card says "dashed" with nothing dashed on it: ` + g.badCap.join(","));
    if (pg === "fins") { // the Convention card draws the whole thruster twice (strip and close-up): six fin lines at six heights
      const ys = await page.evaluate(() => new Set([...document.querySelectorAll('#panel-guide .card[data-key="convention"] svg line.finmark')].map((l) => Math.round(+l.getAttribute("y1")))).size);
      if (ys < 6) problems.push("fins: the Convention card should draw both rail fins and the center fin, strip and close-up: " + ys + " heights"); }
    if (pg === "fins") { const want3 = "importFins,convention,setup_single,setup_twin,twin_upright,twin_keel,twin_trailer,setup_thruster,thruster_proportional,thruster_basic,thruster_mckeeSB,thruster_mckeeGun,setup_2plus1,setup_quad,quad_basic,quad_basicOffRail,quad_mckeeSB,quad_mckeeLB,quad_center,finBase,finForward,finOffRail,finToe"; if (g.order.join() !== want3) problems.push("fins: the cards should run setup by setup, each with its models: " + g.order.join()); }
    for (const [k, v] of Object.entries(want.tags)) if (g.tags[k] !== v) problems.push(`${pg}: card ${k} should carry ${v}: ` + g.tags[k]);
    if (g.cols !== 3) problems.push(`${pg}: a computer shows three cards across: ` + g.cols);
    if (!g.scroll) problems.push(`${pg}: the GUIDE should scroll inside the folder`);
    if (g.overflow) problems.push(`${pg}: a card's content runs wider than the card: ` + g.overflow);
    if (!/your Shortboard/.test(g.note)) problems.push(`${pg}: the GUIDE's note should name the board: ` + g.note);
    await page.screenshot({ path: path.join(out, `desktop-${pg}-guide.png`) });
    await page.evaluate(() => { const p = document.getElementById("panel-guide"); p.scrollTop = p.scrollHeight * 0.45; }); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${pg}-guide-mid.png`) });
    await page.evaluate(() => { const p = document.getElementById("panel-guide"); p.scrollTop = p.scrollHeight; }); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${pg}-guide-end.png`) });
  }
  // the guide follows the board on every page: the Fish (a twin, a swallow, family 2)
  await page.click('#bar [data-b="fish"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(300);
  const fishFins = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll("#panel-guide .card")].map((c) => [c.dataset.key, (c.querySelector("h4 .now") || {}).textContent || ""])));
  if (fishFins.setup_twin !== "On this board" || fishFins.twin_upright !== "On this board" || fishFins.setup_thruster !== "") problems.push("FINS GUIDE should follow the Fish (a twin, Modern/Upright): " + JSON.stringify(fishFins));
  await page.screenshot({ path: path.join(out, "desktop-fins-guide-fish.png") });
  await page.click('#bar [data-pg="outline"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(300);
  const fishTpl = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll("#panel-guide .card")].map((c) => [c.dataset.key, (c.querySelector("h4 .now") || {}).textContent || ""])));
  if (fishTpl.tail_swallow !== "On this board" || fishTpl.tail_squash !== "" || !/2 3\/4"/.test(fishTpl.depth)) problems.push("TEMPLATE GUIDE should follow the Fish (a swallow 2 3/4 deep): " + JSON.stringify(fishTpl));
  await page.screenshot({ path: path.join(out, "desktop-outline-guide-fish.png") });
  await page.click('#bar [data-pg="rails"]'); await page.click('#bar [data-b="longboard"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(300);
  const lbRails = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll("#panel-guide .card")].map((c) => [c.dataset.key, (c.querySelector("h4 .now") || {}).textContent || ""])));
  if (lbRails.hardEdge !== "" || lbRails.symmetrical !== "On this board" || lbRails.ratio !== "50/50") problems.push("RAILS GUIDE should follow the Longboard (no hard edge, symmetrical, 50/50): " + JSON.stringify(lbRails));
  await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(150); await page.screenshot({ path: path.join(out, "desktop-rails-guide-longboard-slate.png") });
  // Metric on every page: no errors, the TEMPLATE's width in cm, RAILS marks in mm
  await page.click('#bar [data-t="daylight"]'); await page.click('#bar [data-b="shortboard"]'); await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(250);
  for (const pg of ["outline", "rails", "volume", "fins"]) { await page.click(`#bar [data-pg="${pg}"]`); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(250); const tags = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll("#panel-guide .card")].map((c) => [c.dataset.key, (c.querySelector("h4 .now") || {}).textContent || ""]))); if (pg === "outline" && tags.width !== "47.6 cm") problems.push("metric TEMPLATE width should read 47.6 cm: " + tags.width); if (pg === "rails" && tags.thickness !== "57 mm") problems.push("metric RAILS thickness should read 57 mm: " + tags.thickness); if (pg === "fins" && tags.finBase !== "114 mm") problems.push("metric FINS base should read 114 mm: " + tags.finBase); }
  await page.screenshot({ path: path.join(out, "desktop-fins-guide-metric.png") });
  await page.click('#bar [data-u="imperial"]');
  for (const t of ["chalk", "phosphor"]) { await page.click(`#bar [data-t="${t}"]`); await page.waitForTimeout(100); } await page.click('#bar [data-t="daylight"]');
  await page.close();

  // ---- an upright phone ----
  page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push("phone: " + e.message)); page.on("console", (m) => { if (m.type() === "error") errors.push("phone console: " + m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#svg-viewer path.board").length > 0);
  for (const [pg, want] of Object.entries(PAGES)) {
    await page.click(`#bar [data-pg="${pg}"]`); await page.waitForTimeout(300);
    const ph = await page.evaluate(() => { const tabs = [...document.querySelectorAll(".tabs .tab")].filter((e) => getComputedStyle(e).display !== "none"); const strip = document.querySelector(".strip").getBoundingClientRect();
      return { words: tabs.map((e) => e.innerText.trim()), stripH: strip.height, right: Math.max(...tabs.map((e) => e.getBoundingClientRect().right)), docScroll: document.documentElement.scrollHeight, inner: window.innerHeight, vb: (document.getElementById("svg-viewer") || { getAttribute: () => "" }).getAttribute("viewBox"), secrow: document.querySelectorAll("#secrow-viewer .tab").length }; });
    console.log("phone " + pg, JSON.stringify(ph));
    if (ph.stripH > 40 || ph.right > 390) problems.push(`${pg} on a phone: the tabs wrapped or ran off: ` + JSON.stringify([ph.stripH, ph.right]));
    if (ph.docScroll > ph.inner + 2) problems.push(`${pg} on a phone: the page scrolls as a whole`);
    if (pg === "outline" && !/^0 0 \d+ 1000$/.test(ph.vb)) problems.push("TEMPLATE on an upright phone stands the board nose up: " + ph.vb);
    if (pg === "rails" && ph.secrow !== 3) problems.push("RAILS on a phone should have the NOSE · CENTER · TAIL switch: " + ph.secrow);
    await page.screenshot({ path: path.join(out, `phone-${pg}-viewer.png`) });
    await page.tap('.tabs [data-page="guide"]'); await page.waitForTimeout(350);
    const pg2 = await page.evaluate(() => { const p = document.getElementById("panel-guide"); const cards = [...p.querySelectorAll(".card")]; return { n: cards.length, cols: new Set(cards.slice(0, 6).map((c) => Math.round(c.getBoundingClientRect().x))).size, scrolls: p.scrollHeight > p.clientHeight, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight, overflow: cards.filter((c) => c.scrollWidth > c.clientWidth + 1).length }; });
    if (pg2.n !== want.cards || pg2.cols !== 1 || !pg2.scrolls || pg2.overflow) problems.push(`${pg} GUIDE on a phone: ` + JSON.stringify(pg2));
    if (pg2.docScroll > pg2.inner + 2) problems.push(`${pg} GUIDE makes the phone page scroll as a whole`);
    await page.screenshot({ path: path.join(out, `phone-${pg}-guide.png`) });
    await page.evaluate(() => { const p = document.getElementById("panel-guide"); p.scrollTop = p.scrollHeight * 0.5; }); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `phone-${pg}-guide-mid.png`) });
  }
  await page.close(); await browser.close();
  console.log("\nERRORS:", errors.length ? errors.join("\n") : "none"); console.log("PROBLEMS:", problems.length ? problems.join("\n") : "none");
  process.exit(problems.length || errors.length ? 1 : 0);
})();

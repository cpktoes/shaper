/* ============ round two: TEMPLATE, RAILS, VOLUME and FINS — each page's own picture, and its GUIDE ============ */
const PAGES = __PAGES__;
const PG = () => PAGES.boards[state.board];
const deg = (v) => `${Math.round(v)}°`, pct = (v) => `${+(+v).toFixed(2)}%`;
const signedDim = (v) => { const p = dim(Math.abs(v)); return markBare(v) === markBare(0) ? (metric() ? "0 cm" : '0"') : (v < 0 ? "-" : "+") + p; };
const sqin = (mm2) => metric() ? `${Math.round(mm2 / 100)} cm²` : `${(mm2 / 645.16).toFixed(1)} sq in`;
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
// a closed outline from above: the right half tail→nose, the left half back, closed to the stringer where the tail closes (a swallow's crotch, a diamond's tip)
function outlinePath(O, X, Y) {
  let d = ""; for (const [s, w] of O.pts) d += (d ? "L" : "M") + f1(X(s)) + " " + f1(Y(w));
  for (let j = O.pts.length - 1; j >= 0; j--) d += "L" + f1(X(O.pts[j][0])) + " " + f1(Y(-O.pts[j][1]));
  if (Math.abs(O.close - O.first) > 0.5) d += "L" + f1(X(O.close)) + " " + f1(Y(0));
  return d + "Z";
}
const halfAt = (O, s) => { const p = O.pts; if (s <= p[0][0]) return p[0][1]; for (let j = 1; j < p.length; j++) if (p[j][0] >= s) { const [s0, w0] = p[j - 1], [s1, w1] = p[j]; return w0 + (w1 - w0) * ((s - s0) / ((s1 - s0) || 1)); } return 0; };
// the drawing conventions shared by the four pages' cartoons: the dimension line with end ticks (vertical and horizontal) and the lab
const vdim = (x, ya, yb, text, side = "right", cls = "") => { const t = Math.min(ya, yb), b = Math.max(ya, yb); return `<line class="dim" stroke-width="1" x1="${f1(x)}" y1="${f1(t)}" x2="${f1(x)}" y2="${f1(b)}"/><line class="dim" stroke-width="1" x1="${f1(x - 3)}" y1="${f1(t)}" x2="${f1(x + 3)}" y2="${f1(t)}"/><line class="dim" stroke-width="1" x1="${f1(x - 3)}" y1="${f1(b)}" x2="${f1(x + 3)}" y2="${f1(b)}"/><text class="val ${cls}" font-size="10" x="${f1(x + (side === "right" ? 5 : -5))}" y="${f1((t + b) / 2 + 3.5)}" text-anchor="${side === "right" ? "start" : "end"}">${svgEsc(text)}</text>`; };
const hdim = (xa, xb, y, text, above = true, anchor = "middle") => { const l = Math.min(xa, xb), r = Math.max(xa, xb); const tx = anchor === "end" ? r : anchor === "start" ? l : (l + r) / 2; return `<line class="dim" stroke-width="1" x1="${f1(l)}" y1="${f1(y)}" x2="${f1(r)}" y2="${f1(y)}"/><line class="dim" stroke-width="1" x1="${f1(l)}" y1="${f1(y - 3)}" x2="${f1(l)}" y2="${f1(y + 3)}"/><line class="dim" stroke-width="1" x1="${f1(r)}" y1="${f1(y - 3)}" x2="${f1(r)}" y2="${f1(y + 3)}"/><text class="val" font-size="10" x="${f1(tx)}" y="${f1(above ? y - 4 : y + 12)}" text-anchor="${anchor}">${svgEsc(text)}</text>`; };
const labAt = (x, y, text, anchor = "start", cls = "lab") => `<text class="${cls}" font-size="8" x="${f1(x)}" y="${f1(y)}" text-anchor="${anchor}">${svgEsc(text)}</text>`;
const ghostCap = (text) => `<text class="lab" font-size="8" x="296" y="9" text-anchor="end" style="fill:var(--ghost)">${svgEsc("dashed · " + text)}</text>`;
// a card's frame: the whole board from above (nose left) in a strip, then one window under it; `draw(g, Xz, Yz, kz)` fills the window
function cardFrame(O, opts) {
  const { hTop = 76, hDet = 120, win, id, fins, stations } = opts; const H = hTop + 6 + hDet;
  const L = O.L, k = Math.min(284 / L, (hTop - 12) / (O.wideW || 1)); const cy = hTop / 2;
  const X = (s) => 8 + (L - s) * k + (284 - L * k) / 2, Y = (y) => cy + y * k;
  let out = `<path class="board" stroke-width="1" d="${outlinePath(O, X, Y)}"/>`;
  out += `<line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${f1(X(L) - 4)}" y1="${cy}" x2="${f1(X(Math.max(0, O.close)) + 4)}" y2="${cy}"/>`;
  if (stations) for (const [s, cut] of stations) out += `<line class="${cut ? "cutline" : "station"}" stroke-width="1" stroke-dasharray="${cut ? "7 2.5 1.5 2.5" : "5 4"}" x1="${f1(X(s))}" y1="${f1(Y(-halfAt(O, s)) - (cut ? 5 : 2))}" x2="${f1(X(s))}" y2="${f1(Y(halfAt(O, s)) + (cut ? 5 : 2))}"/>`;
  // a mark's lateral and leadLat are already signed by its side (the left fin's are negative) — never multiply by the side again
  if (fins) for (const m of fins) out += `<line class="finmark" stroke-width="1.5" x1="${f1(X(m.offTail))}" y1="${f1(Y(m.lateral))}" x2="${f1(X(m.leadOff))}" y2="${f1(Y(m.leadLat))}"/>`;
  // the window: along the board [s0, s1], across [-w, w] or [0, w] (one rail), zoomed to fit the box
  const top0 = hTop + 6, x0 = 8, w = 284; const span = win.s1 - win.s0; const across = (win.half ? 1 : 2) * win.w;
  const kz = Math.min(w / span, (hDet - 14) / across);
  const Xz = (s) => x0 + w / 2 + ((win.s0 + win.s1) / 2 - s) * kz, Yz = win.half ? (y) => top0 + hDet - 7 - y * kz : (y) => top0 + hDet / 2 + y * kz;
  out += `<rect class="win" stroke-width="1" stroke-dasharray="7 2.5 1.5 2.5" x="${f1(X(win.s1))}" y="${f1(Y(-win.w) - 3)}" width="${f1(X(win.s0) - X(win.s1))}" height="${f1(2 * win.w * k + 6)}"/>`;
  const cid = `${id}w`; let g = opts.draw(Xz, Yz, kz, { x0, w, top0, hDet });
  out += `<defs><clipPath id="${cid}"><rect x="${x0}" y="${top0}" width="${w}" height="${hDet}"/></clipPath></defs><g clip-path="url(#${cid})">${g}</g><rect class="station" stroke-width="1" x="${x0}" y="${top0}" width="${w}" height="${hDet}" rx="3"/>`;
  if (opts.cap) out += labAt(x0 + 4, top0 + 10, opts.cap);
  return `<svg viewBox="0 0 300 ${H}" aria-hidden="true">${out}</svg>${opts.ghostWord ? `<div class="ghostcap">dashed · ${svgEsc(opts.ghostWord)}</div>` : opts.drawnWord ? `<div class="ghostcap drawn">drawn as · ${svgEsc(opts.drawnWord)}</div>` : ""}`;
}

/* ============ TEMPLATE ============ */
const TEMPLATE_GUIDE = {
  length: ["How long the board is, tip to tip along the stringer — the number every other template number hangs from.", "A longer board paddles and glides more and holds a line; a shorter one turns quicker and fits a tighter pocket. The 12\" stations and the wide point move with it."],
  noseAngle: ["How sharp the nose comes to its point: pointy at 35°, round at 90°.", "A pointy nose cuts into a steep face and trims the swing weight; a round nose carries foam forward for paddling and noseriding."],
  noseFull: ["How much the curve bellies out between the wide point and the nose — thin keeps it straight, full pushes the width forward.", "Fullness up front adds paddle and planing area ahead of your chest; thinner keeps the entry rail curved and easier to set."],
  width: ["The board's full width at its widest point.", "Wider floats, paddles and planes earlier and is steadier under foot; narrower rolls rail to rail quicker and holds a steeper face."],
  offset: ["Where the wide point sits along the board: at the centre, or slid toward the nose (+) or the tail (−).", "Forward carries the width into the front half for paddle and trim; back tightens the nose and loads the tail for drive and pivot."],
  tailRail: ["How far the tail's rail runs straight before it curves in — short bends early, long keeps the width back.", "A long tail rail holds the width into the tail for speed and planing; a short one pulls the tail in for a tighter turning arc."],
  noseRail: ["How far the nose's rail runs before it curves to the tip.", "A long nose rail carries width forward and straightens the entry; a short one lets the nose curve in sooner."],
  tail_pin: ["A tail that closes to a point, no block.", "The least area in the tail: holds in big, steep surf and sinks easily into a turn, but gives up planing speed in small waves."],
  tail_round: ["A tail that closes in one continuous curve, no corners.", "Smooth and forgiving rail to rail; carries more area than a pin and releases softly."],
  tail_diamond: ["A tail cut to a point behind two corners, the diamond's depth setting how far the point runs back.", "The corners give a release point like a squash while the point keeps the outline shorter and the rail line clean."],
  tail_squash: ["A tail cut square across a block, the corners rounded.", "The planing area and two hard release points of most modern shortboards: fast in small waves, quick off the top."],
  tail_swallow: ["A tail cut into two points with a crotch between them.", "Each tip holds like a pin while the width between them keeps the planing speed — the fish's tail."],
  tailBlock: ["The width of the tail across its block, on a squash, diamond or swallow.", "A wider block means more area and lift in the tail; narrower tightens the turn and the bite."],
  depth: ["Only a diamond or swallow tail has a depth: how far the cut runs in — the diamond's point behind its corners, the swallow's crotch between its tips.", "On a pin, round or squash tail the slider is greyed out. Deeper makes each tip more its own pin and loosens the tail; shallower keeps more of the block's area working."],
  tailAngle: ["How sharp the tail curve comes to the block or point: pointy at 30°, round at 90°.", "A pointier tail pulls the outline in through the fins for hold; a rounder one keeps width behind the fins for speed and release."],
  tailFull: ["How much the curve bellies out between the wide point and the tail.", "Fuller carries width into the tail for planing and drive; thinner straightens the tail rail for a cleaner line and a tighter arc."],
  wingAdd: ["A step in the outline ahead of the fins where the rail jumps in toward the stringer — up to two.", "The step lets the tail behind it run narrower and release while the width ahead keeps planing; the corner gives the rail a bite point."],
  wingPos: ["Where the wing's corner sits along the board, from the tail.", "Further back puts the step on top of the fins for a sharper release; further forward shortens the planing tail behind it."],
  wingDepth: ["How far the rail steps in at the wing, toward the stringer.", "A deeper wing narrows the tail more and bites harder; a shallow one is a hint of a corner."],
  wingRun: ["How long the step takes along the board: square at zero, a slanted step at two inches.", "A square step is a hard corner that releases sharply; a longer run blends the wing into the rail for a softer break."],
  wingRadius: ["How round the wing's corner is, from a sharp point to the largest radius that fits.", "Sharp bites and releases; round softens the corner so the water lets go gradually."],
  wingLock: ["Ties the wing to the front fin's trailing-edge mark, so it follows the fins; the offset sets how far ahead or behind it sits.", "A wing at the fins releases water right where the fins hold; move the fins on FINS and the wing moves with them."],
};
const TEMPLATE_HOW = {
  length: "Mark the length on the stringer and square both tips; every station is measured from the tail tip, so get that mark first.",
  noseAngle: "Trace the template to the nose and fair the last foot with a long batten; sand the tip to the angle by eye against the drawing, keeping both sides the same.",
  noseFull: "Spring a batten through the wide point and the nose mark and check the curve has no flat spot; fullness is set in the template, not after cutting.",
  width: "Mark half the width each side of the stringer at the wide point station and spring the batten through it; a true wide point reads the same both sides.",
  offset: "Measure the wide point station from the tail tip before marking the width; the curve either side follows from where this mark lands.",
  tailRail: "Lay a straightedge along the tail rail and mark where it leaves the straight; trim the template so the curve starts there and runs clean to the tail.",
  noseRail: "As the tail rail: a straightedge along the nose rail shows where the curve begins; fair the template so it bends there and nowhere else.",
  tail_pin: "Cut the outline to a point on the stringer, then round the tip with a block so the glass can wrap it.",
  tail_round: "Cut the curve through and fair it with a batten so no flat or corner is left anywhere around the tail.",
  tail_diamond: "Mark the block width and the depth, cut the two straight edges to the point, and keep the corners crisp with a block.",
  tail_squash: "Mark the block width across the tail, cut square, and round the two corners to a small radius with a block.",
  tail_swallow: "Mark the block width and the crotch depth on the stringer, cut the V with a saw and clean it with a file, then round the two tips.",
  tailBlock: "Mark half the block each side of the stringer at the tail and cut across; check the width with a square before rounding the corners.",
  depth: "On a diamond or swallow, mark the depth on the stringer from the tail and saw the cut in to the mark; a file squares the inside corners.",
  tailAngle: "Fair the last foot of the tail curve with a batten through the block corners; the angle sets itself once the batten lies clean.",
  tailFull: "Spring a batten through the wide point and the tail block and look for flats; adjust the template before cutting.",
  wingAdd: "Cut the outline to the wingless curve first, mark the wing's station on both rails, then cut the step in with a saw and square it with a block.",
  wingPos: "Measure the station from the tail tip on both rails with a square and mark it before cutting; both wings must land at the same station.",
  wingDepth: "Mark the depth in from the rail at the wing's station and cut back to it, checking both sides against the template.",
  wingRun: "Mark where the step starts and ends along the rail; cut the slant between them with a saw and fair it with a block.",
  wingRadius: "Round the corner with a block or a dowel wrapped in paper to the radius; a sharp wing is left as the saw cut it.",
  wingLock: "Mark the front fin's trailing edge on the rail from the FINS page, measure the offset from it, and cut the wing there.",
};
function templateCards() {
  const P = PG().outline, O = P.base, sp = P.spec, V = P.variants; const w0 = V.wingAdd.wings[0];
  const tailOn = (k) => sp.tail === k;
  return [
    { group: "length", key: "length", name: "Board Length", tag: len(O.L), variant: "lengthPlus", win: "whole", dims: ["length"], ghostWord: `${len(V.lengthPlus.L)}` },
    { group: "nose", key: "noseAngle", name: "Nose Angle", tag: deg(sp.noseAngle), variant: "noseAnglePlus", win: "nose", dims: ["noseAngle"], ghostWord: `${deg(Math.min(90, sp.noseAngle + PAGES.push.angle))}` },
    { group: "nose", key: "noseFull", name: "Fullness", tag: pct(sp.noseFullness), variant: "noseFullPlus", win: "nose", dims: ["noseFull"], ghostWord: `${pct(Math.min(100, sp.noseFullness + PAGES.push.full))} full` },
    { group: "wide", key: "width", name: "Width", tag: dim(O.wideW), variant: "widthPlus", win: "wide", dims: ["width"], ghostWord: `${dim(V.widthPlus.wideW)} wide` },
    { group: "wide", key: "offset", name: "Offset", tag: signedDim(sp.offset), variant: "offsetNose", win: "wide", dims: ["offset"], ghostWord: `${signedDim(sp.offset + PAGES.push.offset)}` },
    { group: "wide", key: "tailRail", name: "Tail Rail", tag: pct(sp.tailRail), variant: "tailRailPlus", win: "tailhalf", dims: ["tailRail"], ghostWord: `${pct(Math.min(100, sp.tailRail + PAGES.push.rail))} long` },
    { group: "wide", key: "noseRail", name: "Nose Rail", tag: pct(sp.noseRail), variant: "noseRailPlus", win: "nosehalf", dims: ["noseRail"], ghostWord: `${pct(Math.min(100, sp.noseRail + PAGES.push.rail))} long` },
    ...["pin", "round", "diamond", "squash", "swallow"].map((k) => ({ group: "tail", key: `tail_${k}`, name: cap(k), tag: tailOn(k) ? "On this board" : "", on: tailOn(k), base: `tail_${k}`, variant: null, win: "tail", dims: ["block"] })),
    { group: "tail", key: "tailBlock", name: "Tail Block", tag: O.pinned ? "—" : dim(O.block), variant: V.tailBlockPlus ? "tailBlockPlus" : null, win: "tail", dims: ["block"], ghostWord: V.tailBlockPlus ? `${dim(V.tailBlockPlus.block)} block` : null, note: O.pinned ? "a pin or round tail has no block" : null },
    // Depth is a diamond's or a swallow's alone: on those the board's own depth is pushed; on any other tail the card draws the board as a swallow in dashes, so the depth is still seen
    sp.tail === "diamond" || sp.tail === "swallow"
      ? { group: "tail", key: "depth", name: "Depth", tag: mark(sp.tail === "diamond" ? O.depth : O.close - O.first), variant: V.depthPlus ? "depthPlus" : null, win: "tail", dims: ["depth"], ghostWord: V.depthPlus ? `${mark(sp.tail === "diamond" ? V.depthPlus.depth : V.depthPlus.close - V.depthPlus.first)} deep` : null }
      : { group: "tail", key: "depth", name: "Depth", tag: "Diamond & swallow only", variant: "tail_swallow", win: "tail", dims: ["ghostDepth"], ghostWord: `as a swallow, ${mark(V.tail_swallow.close - V.tail_swallow.first)} deep`, note: `no depth on a ${sp.tail} tail` },
    { group: "tail", key: "tailAngle", name: "Tail Angle", tag: sp.tail === "diamond" ? "—" : deg(sp.tailAngle), variant: V.tailAnglePlus ? "tailAnglePlus" : null, win: "tail", dims: ["tailAngle"], ghostWord: V.tailAnglePlus ? `${deg(Math.min(90, sp.tailAngle + PAGES.push.tailAngle))}` : null },
    { group: "tail", key: "tailFull", name: "Fullness", tag: pct(sp.tailFullness), variant: "tailFullPlus", win: "tail", dims: ["tailFull"], ghostWord: `${pct(Math.min(100, sp.tailFullness + PAGES.push.full))} full` },
    { group: "wings", key: "wingAdd", name: "+ Add a wing", tag: O.wings.length ? `${O.wings.length} on this board` : "None yet", variant: "wingAdd", win: "tail", dims: ["wing"], ghostWord: `a ${mark(w0.depth)} wing at ${dim(w0.station)}` },
    { group: "wings", key: "wingPos", name: "Position from tail", tag: dim(w0.station), base: "wingAdd", variant: "wingPos", win: "tail", dims: ["wingPos"], ghostWord: `${dim(V.wingPos.wings[0].station)} from the tail` },
    { group: "wings", key: "wingDepth", name: "Depth", tag: mark(w0.depth), base: "wingAdd", variant: "wingDepth", win: "tail", dims: ["wing"], ghostWord: `${mark(V.wingDepth.wings[0].depth)} deep` },
    { group: "wings", key: "wingRun", name: "Vertical run", tag: mark(w0.run), base: "wingAdd", variant: "wingRun", win: "tail", dims: ["wingRun"], ghostWord: `${mark(V.wingRun.wings[0].run)} run` },
    { group: "wings", key: "wingRadius", name: "Corner radius", tag: mark(w0.radius), base: "wingAdd", variant: "wingRadius", win: "tail", dims: ["wing"], ghostWord: `${mark(V.wingRadius.wings[0].radius)} radius` },
    { group: "wings", key: "wingLock", name: "Lock to front fin · Offset from the fin", tag: w0.lock ? "Locked" : "No front fin", base: "wingAdd", variant: w0.lock ? "wingOffset" : null, win: "tail", dims: ["wingPos"], ghostWord: w0.lock ? `${signedMark(V.wingOffset.wings[0].finOffset)} from the fin` : null, fins: true },
  ];
}
const TEMPLATE_GROUPS = [["length", "Board Length"], ["nose", "Nose Controls"], ["wide", "Widepoint Controls"], ["tail", "Tail Controls"], ["wings", "Wings", "the WINGS tab's own sidebar"]];
function templateCartoon(c, id) {
  const P = PG().outline; const O = c.base ? P.variants[c.base] : P.base; const G = c.variant ? P.variants[c.variant] : null;
  const L = O.L; const wins = { whole: { s0: -2 * IN, s1: L + (G ? 6 * IN : 0) + 2 * IN, w: O.wideW / 2 + 5 * IN }, nose: { s0: L - 30 * IN, s1: L + 2 * IN, w: halfAt(O, L - 30 * IN) + IN }, tail: { s0: -2 * IN, s1: 30 * IN, w: halfAt(O, 30 * IN) + 1.5 * IN },
    wide: { s0: O.wide - 20 * IN, s1: O.wide + 20 * IN, w: O.wideW / 2 + 1.5 * IN }, tailhalf: { s0: -2 * IN, s1: L / 2 + 4 * IN, w: O.wideW / 2 + 3 * IN }, nosehalf: { s0: L / 2 - 4 * IN, s1: L + 2 * IN, w: O.wideW / 2 + 3 * IN } };
  const win = wins[c.win]; const fins = c.fins ? PG().fins.base.marks : null;
  return cardFrame(O, { hTop: 70, hDet: c.win === "whole" || c.win === "tailhalf" || c.win === "nosehalf" ? 100 : 140, win, id, fins, cap: { whole: "Whole board", nose: "Nose", tail: "Tail", wide: "Wide point", tailhalf: "Tail half", nosehalf: "Nose half" }[c.win], ghostWord: G && c.ghostWord ? c.ghostWord : null,
    draw: (Xz, Yz, kz) => {
      let g = `<path class="board" stroke-width="1" d="${outlinePath(O, Xz, Yz)}"/>`;
      g += `<line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${f1(Xz(L) - 6)}" y1="${f1(Yz(0))}" x2="${f1(Xz(Math.max(0, O.close)) + 6)}" y2="${f1(Yz(0))}"/>`;
      for (const s of [12 * IN, L - 12 * IN]) if (s > win.s0 && s < win.s1) g += `<line class="station" stroke-width="1" stroke-dasharray="5 4" x1="${f1(Xz(s))}" y1="${f1(Yz(-halfAt(O, s)) - 4)}" x2="${f1(Xz(s))}" y2="${f1(Yz(halfAt(O, s)) + 4)}"/>`;
      if (O.wide > win.s0 && O.wide < win.s1) g += `<line class="widepoint" stroke-width="1" stroke-dasharray="2 3" x1="${f1(Xz(O.wide))}" y1="${f1(Yz(-O.wideW / 2) - 4)}" x2="${f1(Xz(O.wide))}" y2="${f1(Yz(O.wideW / 2) + 4)}"/>`;
      if (fins) for (const m of fins) g += `<line class="finmark" stroke-width="2" x1="${f1(Xz(m.offTail))}" y1="${f1(Yz(m.lateral))}" x2="${f1(Xz(m.leadOff))}" y2="${f1(Yz(m.leadLat))}"/><circle class="findot" r="2.5" cx="${f1(Xz(m.offTail))}" cy="${f1(Yz(m.lateral))}"/>`;
      if (G) g += `<path class="ghost" stroke-width="1.2" stroke-dasharray="3 2" d="${outlinePath(G, Xz, Yz)}"/>`;
      for (const d of c.dims) {
        if (d === "length") g += hdim(Xz(0), Xz(L), Yz(O.wideW / 2) + 10, len(L), false);
        if (d === "width") g += vdim(Xz(O.wide) + 6, Yz(-O.wideW / 2), Yz(O.wideW / 2), dim(O.wideW));
        if (d === "offset") { g += `<line class="station" stroke-width="1" stroke-dasharray="5 4" x1="${f1(Xz(L / 2))}" y1="${f1(Yz(-halfAt(O, L / 2)) - 4)}" x2="${f1(Xz(L / 2))}" y2="${f1(Yz(halfAt(O, L / 2)) + 4)}"/>`; if (Math.abs(O.wide - L / 2) > 3) g += hdim(Xz(L / 2), Xz(O.wide), Yz(-O.wideW / 2) - 10, signedDim(O.wide - L / 2)); else g += labAt(Xz(L / 2) + 4, Yz(-O.wideW / 2) - 12, "At center"); }
        if (d === "noseAngle") g += labAt(Xz(L) - 6, Yz(0) - 14, `${deg(PG().outline.spec.noseAngle)} · ${pct(PG().outline.spec.noseFullness)}`, "end", "val");
        if (d === "noseFull") g += labAt(Xz(L - 14 * IN), Yz(-halfAt(O, L - 14 * IN)) - 6, `${pct(PG().outline.spec.noseFullness)} full`, "middle", "val");
        if (d === "tailRail") g += labAt(Xz(10 * IN), Yz(-halfAt(O, 10 * IN)) - 6, `Tail Rail ${pct(PG().outline.spec.tailRail)}`, "middle", "val");
        if (d === "noseRail") g += labAt(Xz(L - 16 * IN), Yz(-halfAt(O, L - 16 * IN)) - 6, `Nose Rail ${pct(PG().outline.spec.noseRail)}`, "middle", "val");
        if (d === "block" && !O.pinned && O.block > 1) g += vdim(Xz(O.first) + 8, Yz(-O.block / 2), Yz(O.block / 2), dim(O.block));
        if (d === "depth" && Math.abs(O.close - O.first) > 1) g += hdim(Xz(O.first), Xz(O.close), Yz(O.block / 2) + 10, mark(Math.abs(O.close - O.first)), false);
        if (d === "ghostDepth" && G && Math.abs(G.close - G.first) > 1) g += hdim(Xz(G.first), Xz(G.close), Yz(Math.max(O.block, G.block) / 2) + 10, mark(Math.abs(G.close - G.first)), false);
        if (d === "tailAngle") g += labAt(Xz(8 * IN), Yz(-halfAt(O, 8 * IN)) - 6, PG().outline.spec.tail === "diamond" ? "set by the diamond" : deg(PG().outline.spec.tailAngle), "middle", "val");
        if (d === "tailFull") g += labAt(Xz(14 * IN), Yz(-halfAt(O, 14 * IN)) - 6, `${pct(PG().outline.spec.tailFullness)} full`, "middle", "val");
        if ((d === "wing" || d === "wingPos" || d === "wingRun") && O.wings.length) { const w = O.wings[0]; const outer = halfAt(O, w.station + w.run + IN), inner = halfAt(O, w.inner);
          if (d === "wing") g += vdim(Xz(w.station + 0.5 * w.run) + 7, Yz(-outer), Yz(-outer + w.depth), mark(w.depth));
          if (d === "wingPos") g += hdim(Xz(0), Xz(w.station), Yz(-outer) - 10, dim(w.station));
          if (d === "wingRun") g += hdim(Xz(w.stepStart), Xz(w.station), Yz(-outer) - 10, mark(w.run)); }
      }
      if (c.note) g += labAt(Xz(win.s1) + 8, Yz(0) - 6, c.note, "start");   // inside the board at the window's nose end, over the stringer, where nothing else is drawn
      return g;
    } });
}
const templateGuideNote = () => `What each control on this page is, what it does to the board, and how it is shaped. Every card is your ${svgEsc(B.name)}'s outline the way VIEWER draws it, nose left — the whole board, then the part the control shapes, closer, with the setting pushed in muted dashes. The tail shapes are each drawn on this board; the wing cards draw the board with the wing the WINGS tab would add first.`;
function buildTemplateSidebar() {
  const P = PG().outline, O = P.base, sp = P.spec; const feet = Math.floor(O.L / IN / 12), inches = Math.round(O.L / IN - feet * 12);
  const shapes = ["pin", "round", "diamond", "squash", "swallow"];
  let h = `<div class="ruled">Board Length</div><div class="group"><div><div class="lbl">Board Length — ${len(O.L)}</div>${metric() ? `<div class="field">${fmtCm(O.L)} <span>cm</span></div>` : `<div class="two"><div class="selwrap"><select aria-label="Feet"><option>${feet}'</option></select></div><div class="selwrap"><select aria-label="Inches"><option>${inches}"</option></select></div></div>`}<input class="rng" type="range" min="60" max="120" value="${O.L / IN}" style="--p:${(O.L / IN - 60) / 60 * 100}%" aria-label="Board Length"></div></div>`;
  h += `<div class="ruled">Nose Controls</div><div class="group"><div class="two">${slider(`Nose Angle — ${deg(sp.noseAngle)}`, "Pointy", "Round", (sp.noseAngle - 35) / 55 * 100)}${slider(`Fullness — ${pct(sp.noseFullness)}`, "Thin", "Full", sp.noseFullness)}</div></div>`;
  h += `<div class="ruled">Widepoint Controls</div><div class="group"><div class="two">${slider(`Width — ${dim(O.wideW)}`, "Thin", "Thick", (O.wideW / IN - 16) / 9 * 100)}${slider(`Offset — ${signedDim(sp.offset)}`, "Tail", "Nose", (sp.offset / IN + 12) / 24 * 100)}</div><div class="two">${slider(`Tail Rail — ${pct(sp.tailRail)}`, "Short", "Long", sp.tailRail)}${slider(`Nose Rail — ${pct(sp.noseRail)}`, "Short", "Long", sp.noseRail)}</div></div>`;
  h += `<div class="ruled">Tail Controls</div><div class="group"><div class="shapes">${shapes.map((k) => `<button type="button" class="${k === sp.tail ? "on" : ""}">${tailIcon(k)}<span>${cap(k)}</span></button>`).join("")}</div>`;
  h += `<div class="two">${slider(`Tail Block — ${O.pinned ? dim(0) : dim(O.block)}`, undefined, undefined, O.pinned ? 0 : O.block / IN / 16 * 100)}${slider(`Depth — ${sp.tail === "diamond" ? mark(O.depth) : sp.tail === "swallow" ? mark(O.close - O.first) : "—"}`, undefined, undefined, sp.tail === "swallow" ? (O.close - O.first) / IN / 8 * 100 : sp.tail === "diamond" ? O.depth / IN / 5 * 100 : 0)}</div>`;
  h += `<div class="two">${slider(`Tail Angle — ${deg(sp.tailAngle)}`, "Pointy", "Round", (sp.tailAngle - 30) / 60 * 100)}${slider(`Fullness — ${pct(sp.tailFullness)}`, "Thin", "Full", sp.tailFullness)}</div></div>`;
  return h;
}
// the tail-shape buttons' small icons (tail-shape-icon.tsx): a tail seen from above, nose up
function tailIcon(k) { const tails = { pin: "M4 2 L14 2 L9 22 Z", round: "M3 2 L15 2 Q15 22 9 22 Q3 22 3 2 Z", diamond: "M3 2 L15 2 L15 14 L9 22 L3 14 Z", squash: "M3 2 L15 2 L15 16 Q15 22 9 22 Q3 22 3 16 Z", swallow: "M3 2 L15 2 L15 22 L9 14 L3 22 Z" }; return `<svg viewBox="0 0 18 24" width="18" height="24" aria-hidden="true"><path d="${tails[k]}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`; }
function drawOutlineViewer() {
  const fit = fitBig("svg-viewer", "outline"); if (!fit) return; const { A, C, px, vertical } = fit; const P = PG().outline, O = P.base, L = O.L;
  const S = { line: `stroke-width="${sw(px, 1)}"`, board: `stroke-width="${sw(px, 2)}"`, lab: `font-size="${sw(px, 10)}"`, val: `font-size="${sw(px, 13)}"` };
  const padX = 60 * px, k = Math.min((A - 2 * padX) / L, (C - 150 * px) / (O.wideW)); const cy = C / 2;
  const X = (s) => padX + (L - s) * k + (A - 2 * padX - L * k) / 2, Y = (y) => cy + y * k;
  let out = `<path class="board" ${S.board} d="${outlinePath(O, X, Y)}"/>`;
  out += `<line class="stringer" ${S.line} stroke-dasharray="${sw(px, 16)} ${sw(px, 4)} ${sw(px, 4)} ${sw(px, 4)}" x1="${f1(X(L) - 8 * px)}" y1="${cy}" x2="${f1(X(Math.max(0, O.close)) + 8 * px)}" y2="${cy}"/>`;
  for (const s of [12 * IN, L / 2, L - 12 * IN]) { const hw = halfAt(O, s); out += `<line class="station" ${S.line} stroke-dasharray="${s === L / 2 ? sw(px, 16) + " " + sw(px, 4) + " " + sw(px, 4) + " " + sw(px, 4) : sw(px, 5) + " " + sw(px, 4)}" x1="${f1(X(s))}" y1="${f1(Y(-hw) - 6 * px)}" x2="${f1(X(s))}" y2="${f1(Y(hw) + 6 * px)}"/>`; }
  out += `<line class="widepoint" ${S.line} stroke-dasharray="${sw(px, 2)} ${sw(px, 3)}" x1="${f1(X(O.wide))}" y1="${f1(Y(-O.wideW / 2) - 6 * px)}" x2="${f1(X(O.wide))}" y2="${f1(Y(O.wideW / 2) + 6 * px)}"/><circle class="knot" r="${sw(px, 2.6)}" cx="${f1(X(O.wide))}" cy="${f1(Y(O.wideW / 2))}"/><circle class="knot" r="${sw(px, 2.6)}" cx="${f1(X(O.wide))}" cy="${f1(Y(-O.wideW / 2))}"/>`;
  // the right rail's read-outs (OutputRail): Nose @ 12" · Center · Tail @ 12"; the left gutter's chips (CalloutChip): LENGTH · WIDEPOINT · WP OFFSET · TAIL BLOCK
  const yR = Y(-O.wideW / 2) - 44 * px, yL = Y(O.wideW / 2) + 48 * px;
  const reads = [[L - 12 * IN, `Nose @ ${station()}`, O.nose12], [L / 2, "Center", 2 * halfAt(O, L / 2)], [12 * IN, `Tail @ ${station()}`, O.tail12]];
  for (const [s, name, v] of reads) { const hw = halfAt(O, s); out += `<line class="station" ${S.line} x1="${f1(X(s))}" y1="${f1(Y(hw))}" x2="${f1(X(s))}" y2="${f1(yR - 16 * px)}"/><line class="tick" ${S.line} x1="${f1(X(s) - 4 * px)}" y1="${f1(Y(hw) + 4 * px)}" x2="${f1(X(s) + 4 * px)}" y2="${f1(Y(hw) - 4 * px)}"/>` + up(vertical, X(s), yR, `<text class="val b" ${S.val} x="${f1(X(s))}" y="${f1(yR - 2 * px)}" text-anchor="middle">${svgEsc(dimBare(v))}</text><text class="lab" ${S.lab} x="${f1(X(s))}" y="${f1(yR + 11 * px)}" text-anchor="middle" style="letter-spacing:.08em;text-transform:none;font-weight:700">${svgEsc(name)}</text>`); }
  const chips = [["LENGTH", metric() ? len(L) : `${len(L)} (${dim(L)})`], ["WIDEPOINT", dim(O.wideW)], ["WP OFFSET", Math.abs(O.wide - L / 2) < 1 ? "At center" : `${dim(Math.abs(O.wide - L / 2))} ${O.wide > L / 2 ? "forward" : "back"}`]];
  if (!O.pinned) chips.push(["TAIL BLOCK", `${dim(O.block)} wide`]);
  const slot = (i) => L - (10 + 16 * i) * IN;
  chips.forEach(([name, v], i) => { const s = slot(i); const wch = (vertical ? 36 : 92) * px, hch = (vertical ? 96 : 32) * px; out += `<rect class="chip" ${S.line} x="${f1(X(s) - wch / 2)}" y="${f1(yL - hch / 2)}" width="${f1(wch)}" height="${f1(hch)}" rx="${sw(px, 4)}"/>` + up(vertical, X(s), yL, `<text class="lab" ${S.lab} x="${f1(X(s))}" y="${f1(yL - 4 * px)}" text-anchor="middle" style="letter-spacing:.08em;font-weight:700;${name === "WIDEPOINT" ? "fill:var(--accent-ink)" : ""}">${name}</text><text class="val b" ${S.val} x="${f1(X(s))}" y="${f1(yL + 11 * px)}" text-anchor="middle">${svgEsc(v)}</text>`); });
  document.getElementById("svg-viewer").innerHTML = vertical ? `<g transform="translate(${C} 0) rotate(90)">${out}</g>` : out;
  document.getElementById("note-viewer").textContent = `${B.name} · ${len(L)} × ${dim(O.wideW)} · ${cap(P.spec.tail)} tail${O.pinned ? "" : `, ${dim(O.block)} block`} · nose ${deg(P.spec.noseAngle)} / ${pct(P.spec.noseFullness)}, tail ${deg(P.spec.tailAngle)} / ${pct(P.spec.tailFullness)}.`;
}
function drawWingsTab() {
  const fit = fitBig("svg-wings", "outline"); if (!fit) return; const { A, C, px, vertical } = fit; const O = PG().outline.base; const L = O.L;
  const s1 = 30 * IN; const padX = 24 * px; const k = Math.min((A - 2 * padX) / s1, (C - 40 * px) / (2 * halfAt(O, s1) + 2 * IN)); const cy = C / 2;
  const X = (s) => A - padX - s * k, Y = (y) => cy + y * k;
  const cut = O.pts.filter(([s]) => s <= s1); let d = ""; for (const [s, w] of cut) d += (d ? "L" : "M") + f1(X(s)) + " " + f1(Y(w)); d += `L${f1(X(s1))} ${f1(Y(halfAt(O, s1)))}L${f1(X(s1))} ${f1(Y(-halfAt(O, s1)))}`; for (let j = cut.length - 1; j >= 0; j--) d += "L" + f1(X(cut[j][0])) + " " + f1(Y(-cut[j][1])); if (Math.abs(O.close - O.first) > 0.5) d += "L" + f1(X(O.close)) + " " + f1(Y(0));
  let out = `<path class="board" stroke-width="${sw(px, 2)}" d="${d}Z"/><line class="stringer" stroke-width="${sw(px, 1)}" stroke-dasharray="${sw(px, 16)} ${sw(px, 4)} ${sw(px, 4)} ${sw(px, 4)}" x1="${f1(X(s1))}" y1="${cy}" x2="${f1(X(Math.max(0, O.close)) + 8 * px)}" y2="${cy}"/>`;
  out += `<line class="station" stroke-width="${sw(px, 1)}" stroke-dasharray="${sw(px, 5)} ${sw(px, 4)}" x1="${f1(X(12 * IN))}" y1="${f1(Y(-halfAt(O, 12 * IN)) - 6 * px)}" x2="${f1(X(12 * IN))}" y2="${f1(Y(halfAt(O, 12 * IN)) + 6 * px)}"/>`;
  document.getElementById("svg-wings").innerHTML = vertical ? `<g transform="translate(${C} 0) rotate(90)">${out}</g>` : out;
  document.getElementById("note-wings").textContent = "The WINGS tab: the tail close-up, with the wing controls in place of the sidebar once a wing is added. This board has no wings — the GUIDE's Wings cards draw the first wing the + Add a wing button would place.";
}

/* ============ RAILS ============ */
const RAIL_COLORS = { domedBand: "#6b8e4e", band1: "var(--accent-ink)", band2: "#b5563a", hardEdge: "var(--ink)", tuck1: "#7d5ba6", tuck2: "#3a6ea5", boardConn: "var(--ink)", bottomConn: "var(--ink)", railConn: "var(--ink)" };
const RAIL_APEX = "#a8425f";
const RAILS_GUIDE = {
  importFoil: ["Takes each rail's thickness from ROCKER & FOIL — the nose 12\", centre and tail 12\" thicknesses the foil gives — instead of three sliders here.", "Every mark below is worked from the thickness, so the rails follow the foil as you change it; untick it to set the three thicknesses by hand."],
  thickness: ["The board's thickness at this station, deck to bottom — the number every rail mark is a share of.", "A thicker rail carries more foam and float and forgives a clumsy edge; a thinner rail bites and rolls over quicker."],
  deckProfile: ["How much the deck domes down toward the rail: flat leaves the full thickness out to the rail, heavily domed tapers it to three quarters.", "Doming thins the rail without thinning the stringer — a lively, sensitive rail under a thick, floaty board — and sets the Tapered Thickness the marks are worked from."],
  family: ["The rail's character from boxy to knifey: how much of the thickness is apex.", "Boxy is full and forgiving with lots of foam at the edge; knifey is pinched and sharp, quick to bury and quick to release."],
  ratio: ["How the rail's thickness splits above and below the apex: 60/40 puts the apex low with more deck above it, 50/50 centres it.", "A low apex (more above) turns more of the rail downward for bite and hold; a high apex gives a fuller, more forgiving edge in the water."],
  symmetrical: ["Makes the bottom tucks mirror the deck marks, so the rail is the same above and below the apex.", "An even rail that rolls the same both ways and is simple to shape; off, the bottom tuck follows the apex instead for a harder working edge."],
  hardEdge: ["A sharp corner where the bottom meets the rail, instead of a tuck — tail only.", "Water lets go cleanly off a hard edge, so the tail is faster and releases in a turn; a tucked edge holds on and forgives."],
  scaled: ["Shrinks every mark of a nose or tail rail to a share of what the centre's rule would give — 1.00 is the full rule.", "Scaling down keeps the thin ends' bands from running too far across a narrow nose or tail; 1.00 shapes them by the same rule as the centre."],
  apexThickness: ["Adds to or takes from the apex band's thickness — how much of the rail's edge is the near-vertical apex.", "A thicker apex is a fuller, more forgiving edge; a thinner one is a sharper, more sensitive rail."],
  deckMark1: ["Moves the first deck mark — how far in from the rail the first deck band is laid out.", "Further in cuts a wider first band and a flatter deck roll; nearer the rail keeps more deck and a quicker turn-down."],
  deckMark3: ["Moves the third deck mark — the farthest the deck bands reach toward the stringer.", "Further in blends the deck down over a wider band for a softer, rounder rail; nearer keeps the deck flat for longer."],
  domedDeckBand: ["Moves where the domed deck starts dropping from the full thickness toward the rail.", "Further in domes more of the deck for a thinner rail under a thicker centre; nearer keeps the deck flat almost to the rail."],
  singleTuck: ["Cuts the bottom with one tuck band instead of two.", "One wider band is quicker to shape and softer in the water; two give a tighter, more controlled tuck."],
  bottomTuck1: ["Moves the first bottom tuck mark — how far in from the rail the first tuck band is laid out.", "Further in tucks more of the bottom for a softer, more forgiving edge; nearer keeps the bottom flat out to the edge."],
  bottomTuck3: ["Moves the last bottom tuck mark — where the bottom band stops and the flat bottom begins.", "Further in rolls more of the bottom into the rail; nearer leaves a flatter, faster bottom."],
  sharpBottomTuck: ["Leaves the last bottom tuck as a corner instead of blending it round.", "A crisp line where the tuck meets the bottom releases water sooner — a touch of hard edge along the whole rail."],
  blends: ["Where the tail's hard edge fades into the tucked rail: it runs sharp from the tail to Blends From, fades, and is fully tucked by Ends At.", "A longer hard edge drives further up the rail for speed and release; a shorter one hands over to the tuck sooner for a smoother rail through the turn."],
};
const RAILS_HOW = {
  importFoil: "Leave it ticked and set the thicknesses on ROCKER; untick only when you want a rail worked from a thickness the foil does not give.",
  thickness: "Check the planed thickness with calipers at the 12\" stations and the centre before marking the rails; every band mark is laid out from it.",
  deckProfile: "Pencil the Domed Deck Band mark in from the rail on the deck and plane the deck down from that line to the Tapered Thickness at the rail, checking with calipers.",
  family: "Lay out the apex marks from DATA on the rail's side and cut the rail bands to them; a knifey rail takes the bands further, a boxy one leaves more of the side standing.",
  ratio: "Mark the Apex Center up from the bottom on the rail's side at each station and join the marks with a batten; the bands above and below meet on that line.",
  symmetrical: "Mark the bottom tucks from DATA, which now equal the deck marks, and cut the bottom bands to mirror the deck bands.",
  hardEdge: "Plane the bottom flat right out to the rail through the tail and cut the rail band down to meet it in a corner; keep the corner crisp with a block and no sanding.",
  scaled: "Lay out the nose and tail marks from DATA — they are already scaled — and cut the bands to them rather than carrying the centre's marks to the ends.",
  apexThickness: "Mark Rail Mark 1 and Rail Tuck 1 on the rail's side from DATA and leave the band between them standing when the deck and bottom bands are cut.",
  deckMark1: "Pencil Deck Mark 1 in from the rail along the deck and cut the first deck band from that line down to Rail Mark 1 with the planer.",
  deckMark3: "Pencil Deck Mark 3 in from the rail and cut the second deck band from it down to the first, blending the two bands with a screen.",
  domedDeckBand: "Pencil the Domed Deck Band line and plane the deck from it out to the rail in long passes until the rail reads the Tapered Thickness.",
  singleTuck: "Pencil one Bottom Tuck mark and cut a single band from it up to Rail Tuck 1, then round it with a screen.",
  bottomTuck1: "Pencil Bottom Tuck 1 in from the rail on the bottom and cut the first tuck band from it up to Rail Tuck 1.",
  bottomTuck3: "Pencil Bottom Tuck 3 on the bottom and cut the second tuck band from it to the first; leave the bottom flat inside the line.",
  sharpBottomTuck: "Cut the last tuck band but do not round where it meets the flat bottom; a light pass with a block keeps the line straight.",
  blends: "Pencil Blends From and Ends At on the rail from the tail; cut the edge hard behind the first mark and screen it progressively rounder until it is the tucked rail at the second.",
};
function railsCards() {
  const R = PG().rails, c = R.spec.center, t = R.spec.tail;
  const fam = ["", "boxy", "boxy/med", "med", "med/knifey", "knifey"];
  return [
    { group: "inputs", key: "importFoil", name: "Import Rocker & Foil Values", tag: R.importing ? "On this board" : "", on: R.importing, sec: "center", variant: null, dims: ["thickness"] },
    { group: "inputs", key: "thickness", name: `Board Thickness · Thickness @${metric() ? " " : ""}${station()}`, tag: mark(c.T), sec: "center", variant: "thicknessPlus", dims: ["thickness"], ghostWord: `${mark(c.T + PAGES.push.thick)} thick` },
    { group: "rails", key: "deckProfile", name: "Deck Profile", tag: `${mark(R.base.center.railT)}${R.base.center.domed ? "" : " · Flat"}`, sec: "center", variant: "deckProfile", dims: ["tapered"], ghostWord: `domed to ${mark(R.variants.deckProfile.railT)}` },
    { group: "rails", key: "family", name: "Family", tag: fam[c.family], sec: "center", variant: "family", dims: ["apex"], ghostWord: R.variants.family.word },
    { group: "rails", key: "ratio", name: "Ratio", tag: `${c.ratioTop}/${100 - c.ratioTop}`, sec: "center", variant: "ratio", dims: ["apexCenter"], ghostWord: `${R.variants.ratio.top}/${100 - R.variants.ratio.top}` },
    { group: "rails", key: "symmetrical", name: "Symmetrical", tag: c.symmetrical ? "On this board" : "", on: c.symmetrical, sec: "center", variant: "symmetrical", dims: ["tuck1"], ghostWord: R.variants.symmetrical.on ? "symmetrical" : "not symmetrical" },
    { group: "rails", key: "hardEdge", name: "Hard Edge", tag: R.hardEdge ? "On this board" : "", on: R.hardEdge, sec: "tail", variant: "hardEdge", dims: ["edge"], ghostWord: R.variants.hardEdge.on ? "hard edge" : "tucked" },
    { group: "advanced", key: "scaled", name: "Scaled from center by", tag: t.scale.toFixed(2), sec: "tail", variant: "scaled", dims: ["deckMark1"], ghostWord: `${PAGES.push.scale.toFixed(2)}` },
    { group: "advanced", key: "apexThickness", name: "Apex Thickness", tag: mark(R.base.center.result.apexLenRange), sec: "center", variant: "apexThickness", dims: ["apex"], ghostWord: `${signedMark(PAGES.push.apex)}` },
    { group: "advanced", key: "deckMark1", name: "Deck Mark 1", tag: mark(R.base.center.result.deckMark1), sec: "center", variant: "deckMark1", dims: ["deckMark1"], ghostWord: `${signedMark(PAGES.push.deckMark)}` },
    { group: "advanced", key: "deckMark3", name: "Deck Mark 3", tag: mark(R.base.center.result.deckMark3), sec: "center", variant: "deckMark3", dims: ["deckMark3"], ghostWord: `${signedMark(PAGES.push.deckMark)}` },
    { group: "advanced", key: "domedDeckBand", name: "Domed Deck Band", tag: mark(R.base.center.result.domedDeckBand), sec: "center", variant: "domedDeckBand", dims: ["domedBand"], ghostWord: `${signedMark(PAGES.push.domedBand)}` },
    { group: "advanced", key: "singleTuck", name: "Use Single Tuck", tag: c.singleTuck ? "On this board" : "", on: c.singleTuck, sec: "center", variant: "singleTuck", dims: ["tuck3"], ghostWord: "one tuck" },
    { group: "advanced", key: "bottomTuck1", name: "Bottom Tuck 1", tag: mark(R.base.center.result.bottomTuck1), sec: "center", variant: "bottomTuck1", dims: ["tuck1"], ghostWord: `${signedMark(PAGES.push.tuck1)}` },
    { group: "advanced", key: "bottomTuck3", name: "Bottom Tuck 3", tag: mark(R.base.center.result.bottomTuck3), sec: "center", variant: "bottomTuck3", dims: ["tuck3"], ghostWord: `${signedMark(PAGES.push.tuck3)}` },
    { group: "advanced", key: "sharpBottomTuck", name: "Sharp Bottom Tuck", tag: c.sharp ? "On this board" : "", on: c.sharp, sec: "center", variant: "sharpBottomTuck", dims: ["tuck3"], ghostWord: "sharp" },
    { group: "advanced", key: "blends", name: "Tail Rail Blends From · Tail Rail Ends At", tag: `${dim(R.blendsFrom)} · ${dim(R.endsAt)}`, sec: "tail", variant: "blends", plan: true, dims: [], ghostWord: `${dim(R.blendsFrom + PAGES.push.blends)} · ${dim(R.endsAt + PAGES.push.blends)}` },
  ];
}
const RAILS_GROUPS = [["inputs", "Inputs"], ["rails", "Nose Rail · Center Rail · Tail Rail", "every rail has these; drawn at the center, the tail for Hard Edge"], ["advanced", "Advanced", "each rail's fold"]];
// one section's plot, as rail-section-plot.tsx draws it: x = 0 at the rail, running toward the stringer; y up from the bottom; the bands coloured, the finished rail in ink
function railPlot(sec, X, Y, px, opts = {}) {
  const S = sec; let g = "";
  const xMin = S.xMin - IN, yMax = S.yMax; const sw1 = opts.thin ? 1 : 1.2;
  for (let x = 0; x >= xMin; x -= IN) g += `<line class="grid" stroke-width="${px}" x1="${f1(X(x))}" y1="${f1(Y(0))}" x2="${f1(X(x))}" y2="${f1(Y(yMax))}"/>`;
  for (let y = 0; y <= yMax; y += IN) g += `<line class="grid" stroke-width="${px}" x1="${f1(X(xMin))}" y1="${f1(Y(y))}" x2="${f1(X(0.5 * IN))}" y2="${f1(Y(y))}"/>`;
  g += `<line class="refdash" stroke-width="${px}" stroke-dasharray="3 3" x1="${f1(X(xMin))}" y1="${f1(Y(0))}" x2="${f1(X(0.5 * IN))}" y2="${f1(Y(0))}"/><line class="refdash" stroke-width="${px}" stroke-dasharray="3 3" x1="${f1(X(xMin))}" y1="${f1(Y(S.domed ? S.T : S.tEff))}" x2="${f1(X(0.5 * IN))}" y2="${f1(Y(S.domed ? S.T : S.tEff))}"/>`;
  g += `<line class="refdash" stroke-width="${px}" stroke-dasharray="2 3" x1="${f1(X(0))}" y1="${f1(Y(0) + 6)}" x2="${f1(X(0))}" y2="${f1(Y(yMax))}"/>`;
  if (!opts.noFill) { let d = ""; for (const [x, y] of S.rail) d += (d ? "L" : "M") + f1(X(x)) + " " + f1(Y(y)); g += `<path class="railfill" d="${d}L${f1(X(S.rail[S.rail.length - 1][0]))} ${f1(Y(0))}L${f1(X(S.rail[0][0]))} ${f1(Y(0))}Z"/>`; }
  for (const s of S.segments) g += `<line stroke="${RAIL_COLORS[s.key]}" stroke-width="${2 * px * sw1}" stroke-linecap="round" x1="${f1(X(s.p1[0]))}" y1="${f1(Y(s.p1[1]))}" x2="${f1(X(s.p2[0]))}" y2="${f1(Y(s.p2[1]))}"/>`;
  { let d = ""; for (const [x, y] of S.rail) d += (d ? "L" : "M") + f1(X(x)) + " " + f1(Y(y)); g += `<path class="finished" stroke-width="${3 * px}" d="${d}"/>`; }
  for (const s of S.segments) for (const p of [s.p1, s.p2]) g += `<circle class="markdot" r="${2.75 * px}" cx="${f1(X(p[0]))}" cy="${f1(Y(p[1]))}"/>`;
  g += `<circle r="${3 * px}" fill="${RAIL_APEX}" cx="${f1(X(0))}" cy="${f1(Y(S.result.apexCenter))}"/>`;
  return g;
}
function railsCartoon(c, id) {
  const R = PG().rails, O = PG().outline.base; const base = R.base[c.sec]; const G = c.variant && !c.plan ? R.variants[c.variant] : null;
  const st = R.anchors[c.sec]; const stations = [[R.anchors.nose, c.sec === "nose"], [R.anchors.center, c.sec === "center"], [R.anchors.tail, c.sec === "tail"]];
  if (c.plan) { // the hard edge's run along the tail, from above: sharp to Blends From, fading to the tucked rail by Ends At
    const win = { s0: -2 * IN, s1: Math.max(R.endsAt, R.endsAt + PAGES.push.blends) + 6 * IN, w: halfAt(O, R.endsAt + 8 * IN) + 1.5 * IN };
    return cardFrame(O, { hTop: 60, hDet: 110, win, id, stations: [[R.anchors.tail, true]], cap: "Tail, from above", ghostWord: c.ghostWord, draw: (Xz, Yz) => {
      let g = `<path class="board" stroke-width="1" d="${outlinePath(O, Xz, Yz)}"/>`;
      const band = (from, to, cls, dash) => { let d = ""; for (let s = 0; s <= to; s += IN / 2) { const w = halfAt(O, s); d += `${s ? "L" : "M"}${f1(Xz(s))} ${f1(Yz(-w))}`; } let d2 = ""; for (let s = 0; s <= to; s += IN / 2) { const w = halfAt(O, s); d2 += `${s ? "L" : "M"}${f1(Xz(s))} ${f1(Yz(w))}`; } return `<path class="${cls}" stroke-width="${from ? 1.2 : 3}" ${dash ? `stroke-dasharray="${dash}"` : ""} d="${d}"/><path class="${cls}" stroke-width="${from ? 1.2 : 3}" ${dash ? `stroke-dasharray="${dash}"` : ""} d="${d2}"/>`; };
      g += band(false, R.blendsFrom, "edge"); g += band(true, R.endsAt, "edge", "2 3");
      for (const [s, nm, dy] of [[R.blendsFrom, "Blends From", -4], [R.endsAt, "Ends At", 11]]) g += `<line class="mark" stroke-width="1" stroke-dasharray="4 3" x1="${f1(Xz(s))}" y1="${f1(Yz(-halfAt(O, s)) - 5)}" x2="${f1(Xz(s))}" y2="${f1(Yz(halfAt(O, s)) + 5)}"/>` + labAt(Xz(s), Yz(0) + dy, `${nm} ${dim(s)}`, "middle", "val");
      for (const s of [R.blendsFrom + PAGES.push.blends, R.endsAt + PAGES.push.blends]) g += `<line class="mark ghost" stroke-width="1" stroke-dasharray="4 3" x1="${f1(Xz(s))}" y1="${f1(Yz(-halfAt(O, s)) - 5)}" x2="${f1(Xz(s))}" y2="${f1(Yz(halfAt(O, s)) + 5)}"/>`;
      return g; } });
  }
  const hw = R.halfAt[c.sec]; const win = { s0: st - 3 * IN, s1: st + 3 * IN, w: hw + IN };
  const hTop = 60, hDet = 120, H = hTop + 6 + hDet; const L = O.L, k = Math.min(284 / L, (hTop - 12) / O.wideW), cy = hTop / 2;
  const X = (s) => 8 + (L - s) * k + (284 - L * k) / 2, Y = (y) => cy + y * k;
  let out = `<path class="board" stroke-width="1" d="${outlinePath(O, X, Y)}"/><line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${f1(X(L) - 4)}" y1="${cy}" x2="${f1(X(Math.max(0, O.close)) + 4)}" y2="${cy}"/>`;
  for (const [s, cut] of stations) out += `<line class="${cut ? "cutline" : "station"}" stroke-width="1" stroke-dasharray="${cut ? "7 2.5 1.5 2.5" : "5 4"}" x1="${f1(X(s))}" y1="${f1(Y(-halfAt(O, s)) - (cut ? 6 : 2))}" x2="${f1(X(s))}" y2="${f1(Y(halfAt(O, s)) + (cut ? 6 : 2))}"/>`;
  // the section: x from the rail (right) toward the stringer (left), the box fitted to the farthest mark and the thickness
  const top0 = hTop + 6; const xMin = Math.min(base.xMin, G ? G.xMin : 0) - IN, yMax = Math.max(base.yMax, G ? G.yMax : 0);
  const kz = Math.min(270 / (-xMin + 0.5 * IN), (hDet - 26) / yMax); const Xz = (x) => 8 + 284 - 18 - (0 - x) * kz + 0 * x, Yz = (y) => top0 + hDet - 10 - y * kz;
  let g = railPlot(base, Xz, Yz, 1);
  if (G) { let d = ""; for (const [x, y] of G.rail) d += (d ? "L" : "M") + f1(Xz(x)) + " " + f1(Yz(y)); g += `<path class="ghost" stroke-width="1.4" stroke-dasharray="3 2" d="${d}"/>`; for (const s of G.segments) for (const p of [s.p1, s.p2]) g += `<circle class="ghostdot" r="2" cx="${f1(Xz(p[0]))}" cy="${f1(Yz(p[1]))}"/>`; }
  const r = base.result;
  for (const d of c.dims) {
    if (d === "thickness") g += vdim(Xz(-r.domedDeckBand) - 10, Yz(0), Yz(base.T), `${mark(base.T)} thick`, "left");
    if (d === "tapered") g += vdim(Xz(-r.deckMark3), Yz(0), Yz(base.tEff), `${mark(base.railT)} at the rail`, "left");
    if (d === "apex") g += vdim(Xz(0) + 8, Yz(r.railTuck1), Yz(r.railMark1), `Apex ${mark(r.apexLenRange)}`, "left");
    if (d === "apexCenter") g += vdim(Xz(0) + 8, Yz(0), Yz(r.apexCenter), `Apex Center ${mark(r.apexCenter)}`, "left");
    if (d === "deckMark1") g += hdim(Xz(0), Xz(-r.deckMark1), Yz(base.T) - 8, `Deck Mark 1 · ${mark(r.deckMark1)}`, true, "end");
    if (d === "deckMark3") g += hdim(Xz(0), Xz(-r.deckMark3), Yz(base.T) - 8, `Deck Mark 3 · ${mark(r.deckMark3)}`, true, "end");
    if (d === "domedBand") g += hdim(Xz(0), Xz(-r.domedDeckBand), Yz(base.T) - 8, `Domed Deck Band · ${mark(r.domedDeckBand)}`, true, "end");
    if (d === "tuck1" && r.bottomTuck1 > 1) g += hdim(Xz(0), Xz(-r.bottomTuck1), Yz(0) + 4, `Bottom Tuck 1 · ${mark(r.bottomTuck1)}`, false, "end");
    if (d === "tuck3") g += r.hardEdge ? labAt(Xz(0) - 4, Yz(0) + 12, "Hard Edge", "end", "val") : hdim(Xz(0), Xz(-r.bottomTuck3), Yz(0) + 4, `Bottom Tuck 3 · ${mark(r.bottomTuck3)}`, false, "end");
    if (d === "edge") g += labAt(Xz(0) - 4, Yz(0) + 12, r.hardEdge ? "Hard Edge" : `Tucked · Bottom Tuck 3 ${mark(r.bottomTuck3)}`, "end", "val");
  }
  out += `<defs><clipPath id="${id}w"><rect x="8" y="${top0}" width="284" height="${hDet}"/></clipPath></defs><g clip-path="url(#${id}w)">${g}</g><rect class="station" stroke-width="1" x="8" y="${top0}" width="284" height="${hDet}" rx="3"/>`;
  out += labAt(12, top0 + 10, `${cap(c.sec)} · ${dim(st)} from the tail`);
  return `<svg viewBox="0 0 300 ${H}" aria-hidden="true">${out}</svg>${G && c.ghostWord ? `<div class="ghostcap">dashed · ${svgEsc(c.ghostWord)}</div>` : ""}`;
}
const railsGuideNote = () => `What each control on this page is, what it does to the rail, and how it is shaped. Every card is your ${svgEsc(B.name)}'s own rail the way VIEWER draws it — the board from above with the three stations, then the cross-section at one of them: the bands in their colours, the finished rail in ink, with the setting pushed in muted dashes. Each rail has the same controls; the cards draw the center's, and the tail's where only the tail has the control.`;
function buildRailsSidebar() {
  const R = PG().rails; const fam = ["", "boxy", "boxy/med", "med", "med/knifey", "knifey"];
  let h = `<div class="ruled">Inputs</div><div class="group"><label class="check"><input type="checkbox" ${R.importing ? "checked" : ""}>Import Rocker &amp; Foil Values</label>`;
  if (R.importing) h += `<div class="rcard"><div class="cap">From ROCKER &amp; FOIL</div><dl class="figs three"><div class="fig"><dt>Nose @ ${station()}</dt><dd>${mark(R.spec.nose.T)}</dd></div><div class="fig"><dt>Center</dt><dd>${mark(R.spec.center.T)}</dd></div><div class="fig"><dt>Tail @ ${station()}</dt><dd>${mark(R.spec.tail.T)}</dd></div></dl></div>`;
  h += `</div>`;
  for (const k of ["nose", "center", "tail"]) { const s = R.spec[k], b = R.base[k];
    h += `<div class="ruled"><span>${cap(k)} Rail</span><label class="check" style="font-size:12px"><input type="checkbox" checked aria-label="View ${cap(k)} Rail">View</label></div><div class="group">`;
    if (!R.importing) h += slider(`${k === "center" ? "Board Thickness" : `Thickness @${metric() ? " " : ""}${station()}`} — ${mark(s.T)}`, undefined, undefined, 50);
    h += slider(`Deck Profile — ${mark(b.railT)} (Tapered Thickness)`, "Flat", "Heavily Domed", (100 - s.deckPercent) / 25 * 100);
    h += `<div class="two"><div><div class="lbl">Family — ${fam[s.family]}</div><input class="rng" type="range" min="1" max="5" value="${s.family}" style="--p:${(s.family - 1) / 4 * 100}%" aria-label="${cap(k)} Rail Family"><div class="hints"><span>Boxy</span><span>Medium</span><span>Knifey</span></div></div><div><div class="lbl">Ratio — ${s.ratioTop}/${100 - s.ratioTop}</div><input class="rng" type="range" min="20" max="80" value="${s.ratioTop}" style="--p:${(s.ratioTop - 20) / 60 * 100}%" aria-label="${cap(k)} Rail Ratio"><div class="hints"><span>20/80</span><span>50/50</span><span>80/20</span></div></div></div>`;
    h += `<label class="check"><input type="checkbox" ${s.symmetrical ? "checked" : ""}>Symmetrical</label>`;
    if (k === "tail") h += `<label class="check"><input type="checkbox" ${R.hardEdge ? "checked" : ""}>Hard Edge</label>`;
    h += `<div><button class="advhead" type="button"><span>Advanced</span><span>▸</span></button></div></div>`; }
  h += `<div class="group"><label class="check"><input type="checkbox">Include Rail Band Instructions in Print</label><div class="smallnote">Adds a third reference page to the printed order form, explaining what each rail band mark means.</div></div>`;
  return h;
}
let railSec = "center";
function drawRailsViewer() {
  const fit = fitBig("svg-viewer", "flat"); if (!fit) return; const { A, C, px } = fit; const R = PG().rails;
  const phone = window.matchMedia("(max-width: 819.98px)").matches || state.frame;
  const keys = phone ? [railSec] : ["nose", "center", "tail"];
  const xMin = Math.min(...keys.map((k) => R.base[k].xMin)) - IN, yMax = Math.max(...keys.map((k) => R.base[k].yMax));
  const rows = keys.length; const rowH = (C - 10 * px) / rows; const padL = 40 * px;
  const kz = Math.min((A - padL - 24 * px) / (-xMin + 0.5 * IN), (rowH - 36 * px) / yMax);
  let out = "";
  keys.forEach((k, i) => { const top = 10 * px + i * rowH; const plotH = yMax * kz + 30 * px; const yb = top + (rowH + plotH) / 2 - 18 * px; const Xz = (x) => A - 24 * px - (0 - x) * kz, Yz = (y) => yb - y * kz;
    out += `<text class="lab" font-size="${sw(px, 11)}" x="${f1(padL)}" y="${f1(Yz(yMax) - 8 * px)}" text-anchor="start">${cap(k)}</text>`;
    out += railPlot(R.base[k], Xz, Yz, px);
    for (let x = 0; x >= xMin; x -= IN) out += `<text class="val muted" font-size="${sw(px, 9)}" x="${f1(Xz(x))}" y="${f1(Yz(0) + 12 * px)}" text-anchor="middle">${metric() ? Math.round(-x) : Math.round(-x / IN)}</text>`;
    for (let y = IN; y <= yMax; y += IN) out += `<text class="val muted" font-size="${sw(px, 9)}" x="${f1(Xz(xMin) - 6 * px)}" y="${f1(Yz(y) + 3 * px)}" text-anchor="end">${metric() ? Math.round(y) : Math.round(y / IN)}</text>`; });
  document.getElementById("svg-viewer").innerHTML = out;
  const secrow = document.getElementById("secrow-viewer"); if (secrow) secrow.innerHTML = ["nose", "center", "tail"].map((k) => `<button class="tab${k === railSec ? " on" : ""}" data-sec="${k}">${k.toUpperCase()}</button>`).join("");
  document.getElementById("note-viewer").innerHTML = `<span class="keydot" style="background:${RAIL_APEX}"></span>Apex Center <span class="keydot" style="background:var(--accent-ink)"></span>Rail Band 1 <span class="keydot" style="background:#b5563a"></span>Rail Band 2 ${R.hardEdge ? `<span class="keydot" style="background:var(--ink)"></span>Hard Edge ` : ""}<span class="keydot" style="background:#7d5ba6"></span>Rail Tuck 1 <span class="keydot" style="background:#3a6ea5"></span>Rail Tuck 2 <span class="keydot" style="background:#6b8e4e"></span>Domed Deck Band <span class="keyline"></span>Finished Rail`;
}
function drawRailsData() {
  const R = PG().rails; const rows = [["Rail Side", ["boardThickness", "Board Thickness"], ["thickness", "Tapered Rail Thickness"], ["apexLenRange", "Apex Thickness"], ["apexCenter", "Apex Center"], ["railMark1", "Rail Mark 1"], ["railTuck1", "Rail Tuck 1"]], ["Deck Side", ["domedDeckBand", "Domed Deck Band"], ["deckMark1", "Deck Mark 1"], ["deckMark2", "Deck Mark 2"], ["deckMark3", "Deck Mark 3"]], ["Bottom", ["bottomTuck1", "Bottom Tuck 1"], ["bottomTuck2", "Bottom Tuck 2"], ["bottomTuck3", "Bottom Tuck 3"]]];
  const cell = (k, key) => { const r = R.base[k].result; if (key === "bottomTuck3" && r.hardEdge) return "Hard Edge"; const v = r[key]; return v === undefined || v < IN / 32 ? "—" : markBare(v); };
  let h = `<table class="data"><thead><tr><th></th>${["nose", "center", "tail"].map((k) => `<th>${cap(k)}${unit("mm")}</th>`).join("")}</tr></thead><tbody>`;
  for (const [grp, ...list] of rows) { h += `<tr><td colspan="4" class="ink" style="font-size:10px;font-weight:800;letter-spacing:.15em;text-transform:uppercase;padding-top:12px">${grp}</td></tr>`; for (const [key, name] of list) h += `<tr><td>${name}</td>${["nose", "center", "tail"].map((k) => `<td>${cell(k, key)}</td>`).join("")}</tr>`; }
  h += `</tbody></table><div class="datanotes"><p>This rail band calculator is intended to provide a quantitative aspect to shaping consistent surfboard rails. It's recommended to understand how rail shapes affect surfboard performance, and how these marks can result in producing your desired outcome.</p></div>`;
  document.getElementById("panel-data").innerHTML = h;
}
function drawRailsInstructions() {
  document.getElementById("panel-instructions").innerHTML = `<div class="datahead">Understanding Rail Markings</div><div class="intro">Example rail with mark definitions — as on the live page, a fixed example rail with every mark named, Flat or Domed.</div><div class="datahead">Turning Marks Into Rail Bands</div><div class="intro"><p style="margin:4px 0">1. Use Deck Marks (solid lines) as a guide to blend the Deck Bands into the nose and tail (dashed lines) smoothly.</p><p style="margin:4px 0">2. Use Rail Marks (solid lines) as a guide to blend the rail side of the Deck Bands toward the nose and tail (dashed line).</p><p style="margin:4px 0">3. The Bottom Tuck (solid line) band should blend into a hard edge around 16-22" from the tail (dashed line).</p></div><div class="datanotes"><p>Not part of this sketch — the live page's three cards stand here.</p></div>`;
}

/* ============ VOLUME ============ */
const VOLUME_GUIDE = {
  importVol: ["Measures the board you drew — its template area and 51 real cross-sections with the RAILS rails — instead of the quick estimate from a board type.", "The accurate litres, quoted everywhere the app shows volume; unticked, the page becomes a quick calculator for a board you know only by length, width and thickness."],
  volLength: ["The board's length for the quick estimate — one of the three numbers the quick figure multiplies.", "Longer means more area and more litres at the same width and thickness; an inch of length is worth less than an inch of width."],
  volWidth: ["The board's width for the quick estimate.", "Width is the quickest way to add litres: a wider board carries more area along its whole length."],
  volThick: ["The centre thickness for the quick estimate — the foil's one number.", "Thickness adds litres everywhere at once: a quarter inch at the centre is about two litres on a shortboard."],
  boardType: ["How full the outline and foil are for the quick estimate, from a pulled-in performance shape to a beefy one.", "The same length, width and thickness give six litres more on a beefy board than a performance one; tune it against a board whose litres you know."],
  volume: ["The board's volume in litres — how much foam is in it.", "More litres float you higher for paddling and glide and forgive a flat section; fewer sink into the wave face for hold and let the board turn off the rail. Shapers quote it against your weight and fitness."],
  area: ["The board's plan area — the area of the template seen from above.", "The area the board planes on: more area, more lift and earlier planing; the litres are this area times the effective thickness."],
  weighted: ["The thickness the board averages along its length once the rails and the thin tips are counted — the number the area is multiplied by.", "Two boards with the same centre thickness differ here by their foil and rails: fuller rails and a thicker tail and nose carry more litres."],
};
const VOLUME_HOW = {
  importVol: "Finish TEMPLATE, ROCKER and RAILS first; the litres here follow them. Compare the figure with a blank's catalogue volume before you cut — the foam off should be the difference.",
  volLength: "Measure tip to tip along the stringer; for a board already glassed, the length on the sticker is usually the blank's, so check it.",
  volWidth: "Measure the widest point with a straightedge across the deck, not around the rail.",
  volThick: "Calipers at the centre, deck to bottom, at the wide point.",
  boardType: "Find a board you know the litres of, enter its three numbers and slide the type until the estimate matches; keep that setting for boards of the same family.",
  volume: "Volume is read, not shaped: once the template, foil and rails are set it is what they add up to. To change it, go back to thickness and width first.",
  area: "Trace the finished template onto paper to check it against the board; the area follows the outline and nothing else.",
  weighted: "Nothing to mark: it falls out of the foil and the rail bands. A thicker tail 12\" or fuller rails raise it; a thinner nose lowers it.",
};
function volumeCards() {
  const V = PG().volume; const q = V.quick;
  return [
    { group: "inputs", key: "importVol", name: "Import Designed Board", tag: V.importing ? "On this board" : "", on: V.importing, kind: "sections", dims: ["L", "W"], ghostWord: null },
    { group: "inputs", key: "volLength", name: "Board Length", tag: len(V.length), kind: "plan", ghost: "length", dims: ["L"], ghostWord: `${len(V.length + PAGES.push.volLength)} → ${V.variants.lengthPlus.litres.toFixed(1)} L quick estimate` },
    { group: "inputs", key: "volWidth", name: "Board Width", tag: dim(V.width), kind: "plan", ghost: "width", dims: ["W"], ghostWord: `${dim(V.width + PAGES.push.volWidth)} → ${V.variants.widthPlus.litres.toFixed(1)} L quick estimate` },
    { group: "inputs", key: "volThick", name: "Center Thickness", tag: dim(V.thick), kind: "section", ghost: "thick", dims: ["T"], ghostWord: `${dim(V.thick + PAGES.push.volThick)} → ${V.variants.thickPlus.litres.toFixed(1)} L quick estimate` },
    { group: "inputs", key: "boardType", name: "Board Type", tag: V.typeLabel, kind: "types", dims: [] },
    { group: "reads", key: "volume", name: "Estimated Volume", tag: `${V.quoted.toFixed(2)} L`, kind: "sections", dims: [] },
    { group: "reads", key: "area", name: V.importing ? "Template Area" : "Board Area (estimated)", tag: sqin(V.estimator.area), kind: "plan", shade: true, dims: ["L", "W"] },
    { group: "reads", key: "weighted", name: V.estimator.geomReady ? "Length-Weighted Effective Thickness" : "Weighted Thickness", tag: mark(V.estimator.weighted), kind: "section", dims: ["T", "weighted"] },
  ];
}
const VOLUME_GROUPS = [["inputs", "Inputs", "the three sliders and Board Type show only when Import Designed Board is unticked"], ["reads", "What the ESTIMATE card reads"]];
// the centre cross-section from RAILS, both rails, as a closed shape in a frame where x is the distance from the stringer
function sectionPath(sec, hw, Xs, Ys, scaleY = 1) {
  const pts = sec.rail.map(([x, y]) => [hw + x, y * scaleY]); let d = `M${f1(Xs(0))} ${f1(Ys(pts[0][1]))}`; for (const [x, y] of pts) d += `L${f1(Xs(x))} ${f1(Ys(y))}`;
  for (let j = pts.length - 1; j >= 0; j--) d += `L${f1(Xs(-pts[j][0]))} ${f1(Ys(pts[j][1]))}`; return d + "Z";
}
function volumeCartoon(c, id) {
  const V = PG().volume, O = PG().outline.base, sec = PG().rails.base.center; const L = O.L, hw = O.wideW / 2;
  if (c.kind === "types") { // the seven steps, Performance to Beefy, with the quick estimate at each
    let out = ""; const x0 = 24, x1 = 276, y = 70; for (let i = 0; i < 7; i++) { const x = x0 + (x1 - x0) * i / 6; const on = i === V.typeIndex; out += `<line class="dim" stroke-width="1" x1="${x}" y1="${y - (on ? 10 : 5)}" x2="${x}" y2="${y + 5}"/>` + labAt(x, y + 18, `${V.variants.types[i].litres.toFixed(1)}`, "middle", on ? "val b" : "val muted") + (on ? labAt(x, y - 16, `${V.factors.labels[i]} · ${V.variants.types[i].litres.toFixed(1)} L`, "middle", "val b") : ""); }
    out += `<line class="dim" stroke-width="1" x1="${x0}" y1="${y}" x2="${x1}" y2="${y}"/>` + labAt(x0, 30, "Performance") + labAt(x1, 30, "Beefy", "end") + labAt(150, 110, `the quick estimate for ${len(V.length)} × ${dim(V.width)} × ${dim(V.thick)}, in litres`, "middle");
    return `<svg viewBox="0 0 300 120" aria-hidden="true">${out}</svg>`; }
  const win = c.kind === "section" ? { s0: L / 2 - 6 * IN, s1: L / 2 + 6 * IN, w: hw + IN } : { s0: -2 * IN, s1: L + (c.ghost === "length" ? PAGES.push.volLength : 0) + 2 * IN, w: hw + (c.ghost === "width" ? PAGES.push.volWidth / 2 : 0) + 5 * IN };
  return cardFrame(O, { hTop: 60, hDet: c.kind === "section" ? 110 : 100, win, id, stations: c.kind === "section" ? [[L / 2, true]] : null, cap: c.kind === "section" ? "Center cross-section, from RAILS" : c.kind === "sections" ? `${V.panelCount + 1} cross-sections, every ${dim(L / V.panelCount)}` : "Plan, from above", ghostWord: c.ghostWord, draw: (Xz, Yz, kz, box) => {
    let g = "";
    if (c.kind === "section") { const ky = kz; const Xs = (x) => Xz(L / 2) + x * kz, Ys = (y) => box.top0 + box.hDet - 12 - y * ky;
      g += `<line class="baseline" stroke-width="1" stroke-dasharray="4 3" x1="${box.x0}" y1="${f1(Ys(0))}" x2="${box.x0 + box.w}" y2="${f1(Ys(0))}"/><path class="board" stroke-width="1" d="${sectionPath(sec, hw, Xs, Ys)}"/>`;
      if (c.ghost === "thick") g += `<path class="ghost" stroke-width="1.2" stroke-dasharray="3 2" d="${sectionPath(sec, hw, Xs, Ys, (V.thick + PAGES.push.volThick) / V.thick)}"/>`;
      if (c.dims.includes("T")) g += vdim(Xs(0) + 6, Ys(0), Ys(sec.T), `${dim(sec.T)} center`);
      if (c.dims.includes("weighted")) g += `<line class="mark" stroke-width="1" stroke-dasharray="4 3" x1="${f1(Xs(-hw))}" y1="${f1(Ys(V.estimator.weighted))}" x2="${f1(Xs(hw))}" y2="${f1(Ys(V.estimator.weighted))}"/>` + vdim(Xs(hw) + 14, Ys(0), Ys(V.estimator.weighted), `${mark(V.estimator.weighted)} weighted`);
      return g; }
    g += `<path class="board${c.shade ? " shaded" : ""}" stroke-width="1" d="${outlinePath(O, Xz, Yz)}"/>`;
    if (c.kind === "sections") for (const s of V.stations) g += `<line class="station" stroke-width="1" x1="${f1(Xz(s))}" y1="${f1(Yz(-halfAt(O, s)))}" x2="${f1(Xz(s))}" y2="${f1(Yz(halfAt(O, s)))}"/>`;
    g += `<line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${f1(Xz(L) - 6)}" y1="${f1(Yz(0))}" x2="${f1(Xz(Math.max(0, O.close)) + 6)}" y2="${f1(Yz(0))}"/>`;
    if (c.ghost === "length") { const f = (L + PAGES.push.volLength) / L; const Gs = { ...O, L: L * f, pts: O.pts.map(([s, w]) => [s * f, w]), close: O.close * f, first: O.first * f }; g += `<path class="ghost" stroke-width="1.2" stroke-dasharray="3 2" d="${outlinePath(Gs, Xz, Yz)}"/>`; }
    if (c.ghost === "width") { const f = (V.width + PAGES.push.volWidth) / V.width; const Gs = { ...O, pts: O.pts.map(([s, w]) => [s, w * f]) }; g += `<path class="ghost" stroke-width="1.2" stroke-dasharray="3 2" d="${outlinePath(Gs, Xz, Yz)}"/>`; }
    if (c.dims.includes("L")) g += hdim(Xz(0), Xz(L), Yz(hw) + 10, len(L), false);
    if (c.dims.includes("W")) g += vdim(Xz(O.wide) + 6, Yz(-hw), Yz(hw), dim(O.wideW));
    return g; } });
}
const volumeGuideNote = () => `What each control and figure on this page is, what it does, and how it is checked on a board. Every card is your ${svgEsc(B.name)} — the plan from above and the center cross-section from RAILS — with the quick estimate's number pushed in muted dashes and the litres it would give. The accurate figure the page quotes is the ${PG().volume.panelCount + 1} cross-sections; the three sliders and Board Type belong to the quick estimate.`;
function buildVolumeSidebar() {
  const V = PG().volume;
  let h = `<div class="ruled">Inputs</div><div class="group"><label class="check"><input type="checkbox" ${V.importing ? "checked" : ""}>Import Designed Board</label>`;
  if (V.importing) h += `<div class="rcard"><div class="cap">From TEMPLATE and ROCKER &amp; FOIL</div><dl class="figs three"><div class="fig"><dt>Length</dt><dd>${len(V.length)}</dd></div><div class="fig"><dt>Width</dt><dd>${dim(V.width)}</dd></div><div class="fig"><dt>Thickness</dt><dd>${dim(V.thick)}</dd></div></dl><div class="footline">Rail shapes from RAILS</div></div>`;
  else h += slider(`Board Length — ${len(V.length)}`, undefined, undefined, (V.length / IN - 60) / 60 * 100) + slider(`Board Width — ${dim(V.width)}`, undefined, undefined, (V.width / IN - 16) / 8 * 100) + slider(`Center Thickness — ${dim(V.thick)}`, undefined, undefined, (V.thick / IN - 1.75) / 1.75 * 100) + slider("Board Type", "Performance", "Beefy", V.typeIndex / 6 * 100);
  return h + `</div>`;
}
function drawEstimate() {
  const V = PG().volume, e = V.estimator; const row = (l, v, strong) => `<div class="estrow"><span>${l}</span><b${strong ? ' class="big"' : ""}>${v}</b></div>`;
  let h = row(V.importing ? "Template Area" : "Board Area (estimated)", `${sqin(e.area)}${V.importing ? " (imported)" : ""}`);
  if (e.geomReady) h += row("Tail Cross-Section Thickness", mark(e.tail)) + row("Center Cross-Section Thickness", mark(e.center)) + row("Nose Cross-Section Thickness", mark(e.nose));
  h += row(e.geomReady ? "Length-Weighted Effective Thickness" : "Weighted Thickness", mark(e.weighted));
  h += `<div class="estrow total"><span>Estimated Volume</span><span><b class="big">${V.quoted.toFixed(2)} L</b><small>${V.panelCount + 1} cross-sections integrated</small></span></div><div class="estmethod">From the board's own finished cross-sections along its length.</div><div class="datanotes" style="margin-top:auto"><p><i>This figure is real cross-sections taken along the board's own length, added up with Simpson's rule — checkable against a published blank's own stated volume.</i></p></div>`;
  document.getElementById("panel-estimate").innerHTML = h;
}

/* ============ FINS ============ */
const FINS_GUIDE = {
  convention: () => ["All positions use the trailing-edge convention: off-tail and off-rail are measured to the trailing edge of the fin base, and toe-in is the leading edge's inward offset from that trailing edge (regardless of fin base length).", `Rears are often defined by a trailing edge spread rather than off-tail measurement, and every value is rounded to the nearest ${metric() ? "millimetre" : '1/16"'}.`],
  importFins: ["Takes the board's length, its tail width at 12\" and its tail shape from TEMPLATE — the three numbers every fin position is worked from.", "The fins follow the outline as you change it; untick to place fins for a board you know only by those three numbers."],
  setup_single: ["One fin on the stringer in a long box, set well forward of the tail.", "Pivot and glide: a single fin trims and carves long arcs and holds a straight line; it does not want to be pumped."],
  setup_twin: ["Two fins out by the rails and nothing on the stringer.", "Loose and fast: twins skate and release off the tail and love small, soft waves; they slide out when pushed hard."],
  setup_thruster: ["Two front fins by the rails and a centre fin behind them.", "The all-rounder: the centre fin holds what the twins give away, so it drives through turns and pumps for speed."],
  setup_2plus1: ["A long centre box with two small side bites ahead of it.", "A single fin's glide and trim with the side bites' extra hold through a turn — the mid-length and longboard standard."],
  setup_quad: ["Two pairs of rail fins, front and rear, and nothing on the stringer.", "Fast and holding: the rear pair carries the drive down the line and bites in a hollow face; looser than a thruster off the top."],
  thruster_proportional: ["Front fins placed at a fixed share of the board's length, so a longer board puts them further up.", "A simple rule that keeps the cluster in proportion to the board; a touch further forward than the other models on a long board."],
  thruster_basic: ["Front fins placed by a straight-line rule that moves them up at half the rate of the board's length.", "Conservative: the cluster stays nearer the tail as the board grows, for a tighter, more pivoty feel."],
  thruster_mckeeSB: ["Rusty's and McKee's shortboard numbers: the front fins by the board's length and the tail's width, with a McKee toe aimed at a point near the nose.", "The modern performance standard — drive with release; a narrow tail pulls the cluster back."],
  thruster_mckeeGun: ["McKee's gun placement: the cluster set for long, drawn-out turns at speed.", "Fins further up and toed for hold on a big, fast face; less pivot, more drive."],
  quad_basic: ["The rear pair placed by a spread from the stringer, a set distance forward of the tail.", "A classic quad spread: the rears sit inside the fronts for drive down the line."],
  quad_basicOffRail: ["The rear pair placed in from the rail, half a front base plus a quarter inch behind the fronts.", "Rears close to the rail and close behind the fronts: loose and quick, the fins working as a pair."],
  quad_mckeeSB: ["McKee's shortboard and gun quad numbers: the rears spread by the tail's width and toed to aim near the nose.", "A balanced quad that holds in a hollow wave and still pivots."],
  quad_mckeeLB: ["McKee's longboard quad: the rears set further up and spread for a board eight feet or longer.", "Drive and hold for a long board without the centre fin's drag; it needs the length to work."],
  quad_center: ["A fifth box on the stringer behind the quad's rear pair.", "Ride it as a quad, a thruster or a five-fin — the box costs nothing when empty and adds a centre fin's hold when you want it."],
  twin_upright: ["The modern twin: upright fins by the rails, toed in.", "Fast and loose with more drive than a keel; the everyday twin."],
  twin_keel: ["Keel fins: long, low bases set further back with little toe.", "The retro fish feel: glide and down-the-line speed, long drawn turns, little pivot."],
  twin_trailer: ["Upright twins with a small trailer fin behind them on the stringer.", "A twin's speed with a touch of hold at the tail, so it releases less when pushed."],
  finBase: ["The length of the fin's base along the board — the fin's footprint, trailing edge to leading edge.", "A longer base drives and holds more; a shorter one pivots. The leading-edge mark moves with it."],
  finForward: ["Slides a fin set forward or back from where its model puts it, up to an inch and a half either way.", "Back is drivey — the fins hold and the board tracks; forward is loose and quick to pivot."],
  finOffRail: ["How far in from the rail the fins' trailing edges sit.", "Closer to the rail bites earlier and feels looser; closer to the stringer is more forgiving and drives straighter."],
  finToe: ["How much the leading edge points in toward the stringer, as a distance at the leading edge.", "More toe-in is looser and turns easier at the cost of speed; less is drivey and fast down the line."],
};
const FINS_HOW = {
  convention: "Mark the trailing edge first — off the tail along the stringer, squared across, then in from the rail — and lay the leading edge from it with the toe; the base length moves the leading-edge mark, never the trailing edge.",
  importFins: "Leave it ticked and finish TEMPLATE first — the fin marks are measured from the tail tip and in from the rail you drew.",
  setup_single: "Mark the box's centre on the stringer at the off-tail distance from DATA and route the box square to the stringer, the length of the box.",
  setup_twin: "Mark each fin's trailing edge off the tail on the stringer and square across, then measure in from the rail at that mark; mark the leading edge with the toe and join the two for the box.",
  setup_thruster: "Mark the two front trailing edges off the tail and in from the rail, their leading edges with the toe, then the centre fin's trailing edge on the stringer.",
  setup_2plus1: "Mark the centre box as a single, then the two side bites off the tail and in from the rail with their toe.",
  setup_quad: "Mark the front pair as a thruster's fronts, then the rear pair off the tail and in from the rail (or out from the stringer, as DATA gives it) with their toe.",
  thruster_proportional: "Use DATA's marks for this model — off tail, off rail and toe — and check both sides measure the same before routing.",
  thruster_basic: "Use DATA's marks for this model and check both sides the same; the toe is a quarter inch here.",
  thruster_mckeeSB: "Use DATA's marks; for the toe, aim each fin's leading edge at the point the McKee table gives near the nose and check with a straightedge laid along the fin's base.",
  thruster_mckeeGun: "As the shortboard model, aimed with the table; keep the cluster symmetrical with a straightedge from each fin to its aim point.",
  quad_basic: "Mark the rear pair's trailing edges off the tail and out from the stringer by the half spread in DATA, square across, then their toe.",
  quad_basicOffRail: "Mark the rear pair in from the rail at their off-tail mark; the toe and base as DATA gives them.",
  quad_mckeeSB: "Mark the rears by DATA's half spread and off-tail, and aim their leading edges with the McKee table.",
  quad_mckeeLB: "As McKee SB/Gun, with the longboard table's aim points; the board must be eight feet or longer.",
  quad_center: "Mark a centre box behind the rears at DATA's off-tail distance, square to the stringer.",
  twin_upright: "Mark the trailing edges off the tail and in from the rail, then the leading edges with the toe, and join them for the boxes.",
  twin_keel: "As the upright twin, with the keel's longer base: mark both ends of the base and keep the toe small.",
  twin_trailer: "Mark the twins as uprights, then the trailer's trailing edge on the stringer four inches off the tail.",
  finBase: "Mark both ends of the base on the board — trailing edge first, then the base length forward along the toe line — and route the box to those marks.",
  finForward: "Move both trailing-edge marks the same amount along the board before marking the leading edges; measure from the tail tip each time.",
  finOffRail: "Measure in from the rail at each trailing-edge mark with a rule held square to the stringer; mark both sides and check them against each other.",
  finToe: "Mark the leading edge the toe distance further in from the rail than the trailing edge, then lay a straightedge through the two marks to pencil the box line.",
};
// MODEL INFO's notes on where each model's placement guidance comes from (components/fins/fin-model-info.tsx, verbatim),
// each on the card of the setup or model it describes — the tab itself is gone (the founder, 2026-11-09)
const FINS_INFO = {
  setup_single: "Single fin box placement comes from an established fixed range rather than a length equation — the default value is in a common working range (4 1/2\" to 6\") and can be fine-tuned by the forward/aft slider in the advanced menu, rather than solved for.",
  setup_twin: "All twin placements come from established fixed ranges rather than a length equation — they're centered in a working range (Modern = 7\" to 8\", Keel = 6\" to 6 1/2\", and Upright+Trailer = at ~10\") and can be adjusted by the forward/aft slider in the advanced menu, rather than solved for.",
  twin_upright: "Good for shorter base (generally ≤ 5 1/2\"), more upright twin fins.",
  twin_keel: "Use for wide base (generally > 5 1/2\"), retro-style twin fins.",
  twin_trailer: "Typically used with shorter-base, thruster-like, twins with a small trailer fin for added hold and drive.",
  thruster_proportional: "A straightforward linear length-scaled placement based on a smaller range of short board. It's the simplest of the four and the least tuned for longer boards.",
  thruster_basic: "Also scales linearly with length, but more slowly. It follows a \"half rate convention\" based on the idea that stance width scales slower than board length.",
  thruster_mckeeSB: "Fitted to Greg McKee's published fin-placement guidance for shortboards and guns respectively. Also follows a \"half rate\" style convention.",
  thruster_mckeeGun: "Fitted to Greg McKee's published fin-placement guidance for shortboards and guns respectively. Also follows a \"half rate\" style convention.",
  setup_2plus1: "The center fin box placement follows the Single Model above. Side bite placements come from an established fixed range, scaled off a length anchor of 9' rather than a length equation — the default value is centered in a working range (15\" to 16 1/2\") and can be adjusted by the forward/aft slider in the advanced menu, rather than solved for.",
  quad_basic: "Uses the front Basic Model as input. Rears are placed at 1/2 the front distance from tail as default. Rears use common spread values which tend to put the fins closer to the stringer than the Off-Rail Model, resulting in a looser board.",
  quad_basicOffRail: "Uses the front Basic Model as input. Rears are placed at 1/2 the front distance +1/4\" from tail as default. Rears use common Off-Rail values which tend to put the fins closer to the rail (wider spread) than the Spread Model, resulting in a board with extra drive. The slightly farther forward rear fins help to avoid feeling tracky.",
  quad_mckeeSB: "McKee's shortboard/gun rear-pair guidance, paired with the matching front model.",
  quad_mckeeLB: "McKee's dedicated longboard front-and-rear guidance, for boards 8'0\" and longer. On a shorter board the app uses McKee SB/Gun instead.",
};
function finsCards() {
  const F = PG().fins, b = F.base, V = F.variants; const r = b.resolved;
  const has = (role) => b.marks.some((m) => m.role === role);
  const onSetup = (s) => b.setup === s;
  const list = [{ group: "inputs", key: "importFins", name: "Import Designed Board", tag: "On this board", on: true, base: null, variant: null, dims: ["offTail", "offRail"] },
    { group: "convention", key: "convention", name: "Trailing-edge convention", tag: metric() ? "to the millimetre" : 'to 1/16"', on: false, base: null, variant: null, dims: ["offTail", "offRail", "toe", "baseUpper"] }];
  // one group per Fin Setup, in the sidebar's order: the setup's own card, then its models or templates (the founder, 2026-11-09)
  const setupCard = (s) => ({ group: s.value, key: `setup_${s.value}`, name: s.label, tag: onSetup(s.value) ? "On this board" : "", on: onSetup(s.value), base: `setup_${s.value}`, variant: null, dims: ["offTail", "offRail"] });
  for (const s of F.setups) {
    list.push(setupCard(s));
    if (s.value === "twin") for (const t of F.twinTemplates) list.push({ group: "twin", key: `twin_${t.value}`, name: t.label, tag: b.setup === "twin" && b.twinTemplate === t.value ? "On this board" : "", on: b.setup === "twin" && b.twinTemplate === t.value, base: `twin_${t.value}`, variant: null, dims: ["offTail", "baseUpper"] });
    if (s.value === "thruster") for (const m of F.thrusterModels) list.push({ group: "thruster", key: `thruster_${m.value}`, name: m.label, tag: b.setup === "thruster" && b.frontModel === m.value ? "On this board" : "", on: b.setup === "thruster" && b.frontModel === m.value, base: `thruster_${m.value}`, variant: null, dims: ["offTail", "toe"] });
    if (s.value === "quad") {
      for (const m of F.quadModels) list.push({ group: "quad", key: `quad_${m.value}`, name: m.label, tag: b.setup === "quad" && b.quadRearModel === m.value ? "On this board" : V[`quad_${m.value}`].disabled ? `Needs 8'0"` : "", on: b.setup === "quad" && b.quadRearModel === m.value, base: `quad_${m.value}`, variant: null, dims: ["rearOffTail"] });
      list.push({ group: "quad", key: "quad_center", name: "Add 5th/Center fin", tag: b.setup === "quad" && b.centerOn ? "On this board" : "", on: b.setup === "quad" && b.centerOn, base: "quad_center", variant: null, dims: ["centerOffTail"] });
    }
  }
  const fwd = has("front") ? "front" : has("rear") ? "rear" : "center";
  list.push({ group: "advanced", key: "finBase", name: has("front") || has("rear") ? "Fin Base Length" : "Fin Box Length", tag: mark(b.marks[0].base), base: null, variant: "basePlus", dims: ["base"], ghostWord: `${mark(b.marks[0].base + PAGES.push.finBase)} base` });
  list.push({ group: "advanced", key: "finForward", name: "Aft/Forward position", tag: mark(b.marks.find((m) => m.role === fwd).offTail), base: null, variant: "forwardPlus", dims: ["offTail"], ghostWord: `${mark(PAGES.push.finForward)} forward` });
  list.push({ group: "advanced", key: "finOffRail", name: "Off-Rail", tag: has("front") || has("rear") ? mark(has("front") ? r.forwardOffRail : r.rearOffRail) : "— (no rail fins)", base: null, variant: has("front") || has("rear") ? "offRailCloser" : null, dims: ["offRail"], ghostWord: has("front") || has("rear") ? `${mark(V.offRailCloser.resolved.forwardOffRail || V.offRailCloser.resolved.rearOffRail)} off the rail` : null });
  list.push({ group: "advanced", key: "finToe", name: "Toe-In", tag: has("front") || has("rear") ? mark(has("front") ? r.forwardToe : r.rearToe) : "— (no rail fins)", base: null, variant: has("front") || has("rear") ? "toePlus" : null, dims: ["toe"], ghostWord: has("front") || has("rear") ? `${mark(PAGES.push.finToe)} toe-in` : null });
  return list;
}
const FINS_GROUPS = [["inputs", "Inputs"], ["convention", "Convention", "how every mark below is measured"],
  ["single", "Single Fin", "one box on the stringer"], ["twin", "Twin", "two rail fins, placed by one of three templates"], ["thruster", "Thruster", "the front pair by one of four front models (the quad's front pair uses them too), the center fin behind"],
  ["2plus1", "2+1", "a single's center box with two side bites"], ["quad", "Quad", "the rear pair by one of four rear models, each bringing its matching front model; a fifth box behind if you want it"],
  ["advanced", "Advanced", "the forward fins'; the rear pair and the center fin have the same"]];
function finLines(marks, Xz, Yz, ghost) {
  let g = ""; for (const m of marks) { const x1 = Xz(m.offTail), y1 = Yz(m.lateral), x2 = Xz(m.leadOff), y2 = Yz(m.leadLat);   // lateral is signed by the side already
    g += ghost ? `<line class="ghost" stroke-width="2" stroke-dasharray="3 2" x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/>` : `<line class="finmark" stroke-width="2.5" ${m.kind === "rail" ? 'stroke-dasharray="8 4"' : m.kind === "stringer" ? 'stroke-dasharray="2 3"' : ""} x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/><circle class="findot" r="3" cx="${f1(x1)}" cy="${f1(y1)}"/><circle class="findot" r="3" cx="${f1(x2)}" cy="${f1(y2)}"/>`; }
  return g;
}
function finsCartoon(c, id) {
  const F = PG().fins, O = PG().outline.base; const base = c.base ? F.variants[c.base] : F.base; const G = c.variant ? F.variants[c.variant] : null;
  const win = { s0: -1.5 * IN, s1: 24 * IN, w: halfAt(O, 24 * IN) + IN };
  return cardFrame(O, { hTop: 60, hDet: 170, win, id, fins: base.marks, cap: `Tail, ${dim(24 * IN)} from above`, ghostWord: G && c.ghostWord ? c.ghostWord : null, drawnWord: !G && c.base && base.modelHeader ? base.modelHeader : null, draw: (Xz, Yz) => {
    let g = `<path class="board" stroke-width="1" d="${outlinePath(O, Xz, Yz)}"/><line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${f1(Xz(26 * IN))}" y1="${f1(Yz(0))}" x2="${f1(Xz(Math.max(0, O.close)) + 6)}" y2="${f1(Yz(0))}"/>`;
    g += `<line class="station" stroke-width="1" stroke-dasharray="5 4" x1="${f1(Xz(12 * IN))}" y1="${f1(Yz(-halfAt(O, 12 * IN)) - 4)}" x2="${f1(Xz(12 * IN))}" y2="${f1(Yz(halfAt(O, 12 * IN)) + 4)}"/>`;
    g += finLines(base.marks, Xz, Yz, false); if (G) g += finLines(G.marks, Xz, Yz, true);
    const pick = (role) => base.marks.find((m) => m.role === role && m.side !== -1) || base.marks[0];
    const front = pick("front"), rear = pick("rear"), center = base.marks.find((m) => m.role === "center");
    const up = (m) => base.marks.find((k) => k.role === m.role && k.side === -1) || m;   // the same fin on the upper side
    // dimension lines sit outside the board, the drafting way: off-tail just below the rail at the fin's own station (the
    // tail is narrower there, so the line clears the tail), the center fin's above the upper rail
    for (const d of c.dims) {
      if (d === "offTail" && front) g += hdim(Xz(0), Xz(front.offTail), Yz(halfAt(O, front.offTail)) + 12, `${mark(front.offTail)} off tail`, false);
      if (d === "offTail" && !front && center) g += hdim(Xz(0), Xz(center.offTail), Yz(halfAt(O, center.offTail)) + 12, `${mark(center.offTail)} off tail`, false);
      if (d === "rearOffTail" && rear) g += hdim(Xz(0), Xz(rear.offTail), Yz(halfAt(O, rear.offTail)) + 12, `${mark(rear.offTail)} off tail`, false);
      if (d === "centerOffTail" && center) g += hdim(Xz(0), Xz(center.offTail), Yz(-halfAt(O, center.offTail)) - 12, `center ${mark(center.offTail)} off tail`);
      if (d === "offRail" && front && front.kind === "rail") { const hwm = halfAt(O, front.offTail); g += vdim(Xz(front.offTail) - 6, Yz(hwm), Yz(front.lateral), `${mark(hwm - front.lateral)} off rail`, "right"); }   // the label on the tail side of the line, clear of the fin
      // toe-in on the upper fin: a dashed reference through its trailing edge, parallel to the stringer, and the gap to the
      // leading edge dimensioned nose-ward of it, where the board is empty
      if (d === "toe" && front && front.toe > 0.5) { const u = up(front); g += `<line class="refdash" stroke-width="1" stroke-dasharray="2 3" x1="${f1(Xz(u.offTail))}" y1="${f1(Yz(u.lateral))}" x2="${f1(Xz(u.leadOff) - 14)}" y2="${f1(Yz(u.lateral))}"/>` + vdim(Xz(u.leadOff) - 8, Yz(u.lateral), Yz(u.leadLat), `${mark(u.toe)} toe`, "left"); }
      if (d === "base" && (front || center)) { const m = front || center; g += hdim(Xz(m.offTail), Xz(m.leadOff), Yz(m.lateral) + (m.side >= 0 ? 12 : -8), `${mark(m.base)} base`, m.side < 0); }
      // the base on the upper fin, above it, clear of the off-tail and off-rail lines on the lower one (the Convention and twin cards)
      if (d === "baseUpper" && (front || center)) { const m = (front && base.marks.find((k) => k.role === front.role && k.side === -1)) || front || center; g += hdim(Xz(m.offTail), Xz(m.leadOff), Yz(m.lateral) - 8, `${mark(m.base)} base`, true); }
    }
    return g; } });
}
const finsGuideNote = () => `Each fin setup with its models or templates: what it is, what it does to the ride, where its numbers come from (the MODEL INFO notes, now on the cards) and how the marks are laid out. Every card is your ${svgEsc(B.name)}'s tail the way VIEWER draws it — the last ${dim(24 * IN)} from above, the fins as lines from trailing edge to leading edge — each setup and model drawn on this board, and the Advanced settings pushed in muted dashes. No cant: the page has none.`;
function buildFinsSidebar() {
  const F = PG().fins, b = F.base, O = PG().outline.base;
  let h = `<div class="ruled">Inputs</div><div class="group"><label class="check"><input type="checkbox" checked>Import Designed Board</label><div class="rcard"><div class="cap">From TEMPLATE</div><dl class="figs three"><div class="fig"><dt>Length</dt><dd>${len(O.L)}</dd></div><div class="fig"><dt>Tail @ ${station()}</dt><dd>${dim(O.tail12)}</dd></div><div class="fig"><dt>Tail</dt><dd>${cap(PG().outline.spec.tail)}</dd></div></dl></div></div>`;
  h += `<div class="ruled">Fin Selection</div><div class="group"><div><div class="lbl">Fin Setup</div><div class="shapes five">${F.setups.map((s) => `<button type="button" class="${s.value === b.setup ? "on" : ""}">${finIcon(s.value)}<span>${s.label}</span></button>`).join("")}</div></div>`;
  if (b.setup === "thruster") h += `<div><div class="lbl">Thruster Model</div><div class="pills">${F.thrusterModels.map((m) => `<button type="button" class="${m.value === b.frontModel ? "on" : ""}">${m.label}</button>`).join("")}</div></div>`;
  if (b.setup === "quad") h += `<div><div class="lbl">Quad Model</div><div class="pills">${F.quadModels.map((m) => `<button type="button" class="${m.value === b.quadRearModel ? "on" : ""}"${F.variants[`quad_${m.value}`].disabled ? " disabled" : ""}>${m.label}</button>`).join("")}</div></div><label class="check"><input type="checkbox" ${b.centerOn ? "checked" : ""}>Add 5th/Center fin</label>`;
  if (b.setup === "twin") h += `<div><div class="lbl">Twin Template</div><div class="pills">${F.twinTemplates.map((t) => `<button type="button" class="${t.value === b.twinTemplate ? "on" : ""}">${t.label}</button>`).join("")}</div></div>`;
  h += `<div><button class="advhead" type="button"><span>Advanced</span><span>▸</span></button></div></div>`;
  return h;
}
function finIcon(k) { const dots = { single: [[9, 14]], twin: [[4, 10], [14, 10]], thruster: [[4, 9], [14, 9], [9, 16]], "2plus1": [[4, 8], [14, 8], [9, 15]], quad: [[4, 8], [14, 8], [6, 15], [12, 15]] }[k]; return `<svg viewBox="0 0 18 24" width="18" height="24" aria-hidden="true"><path d="M3 2 L15 2 L15 16 Q15 22 9 22 Q3 22 3 16 Z" fill="none" stroke="currentColor" stroke-width="1.2"/>${dots.map(([x, y]) => `<line x1="${x}" y1="${y - 2.5}" x2="${x}" y2="${y + 2.5}" stroke="currentColor" stroke-width="1.8"/>`).join("")}</svg>`; }
function drawFinsViewer() {
  const fit = fitBig("svg-viewer", "flat"); if (!fit) return; const { A, C, px } = fit; const F = PG().fins, b = F.base, O = PG().outline.base;
  // the tail from above, tail at the bottom and nose up, the last 24" (fin-viewer.tsx), with the dimension lines the page draws
  const span = 24 * IN, hw = halfAt(O, span) + 2 * IN; const k = Math.min((C - 40 * px) / span, (A - 160 * px) / (2 * hw)); const cx = A / 2, yT = C - 16 * px;
  const X = (y) => cx + y * k, Y = (s) => yT - s * k;
  let d = ""; for (const [s, w] of O.pts) if (s <= span + 2 * IN) d += (d ? "L" : "M") + f1(X(w)) + " " + f1(Y(s)); const ptsIn = O.pts.filter(([s]) => s <= span + 2 * IN); for (let j = ptsIn.length - 1; j >= 0; j--) d += "L" + f1(X(-ptsIn[j][1])) + " " + f1(Y(ptsIn[j][0])); if (Math.abs(O.close - O.first) > 0.5) d += "L" + f1(X(0)) + " " + f1(Y(O.close));
  let out = `<path class="board" stroke-width="${sw(px, 1.5)}" d="${d}Z"/><line class="stringer" stroke-width="${sw(px, 1)}" stroke-dasharray="${sw(px, 16)} ${sw(px, 4)} ${sw(px, 4)} ${sw(px, 4)}" x1="${cx}" y1="${f1(Y(span + 2 * IN))}" x2="${cx}" y2="${f1(Y(Math.max(0, O.close)) + 6 * px)}"/>`;
  out += `<line class="station" stroke-width="${sw(px, 1)}" stroke-dasharray="${sw(px, 5)} ${sw(px, 4)}" x1="${f1(X(-halfAt(O, 12 * IN)) - 6 * px)}" y1="${f1(Y(12 * IN))}" x2="${f1(X(halfAt(O, 12 * IN)) + 6 * px)}" y2="${f1(Y(12 * IN))}"/>`;
  for (const m of b.marks) { const x1 = X(m.lateral), y1 = Y(m.offTail), x2 = X(m.leadLat), y2 = Y(m.leadOff);   // lateral is signed by the side already
    out += `<line class="finmark" stroke-width="${sw(px, 2.5)}" ${m.kind === "rail" ? `stroke-dasharray="${sw(px, 8)} ${sw(px, 4)}"` : m.kind === "stringer" ? `stroke-dasharray="${sw(px, 2)} ${sw(px, 3)}"` : ""} x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/><circle class="findot" r="${sw(px, 3.5)}" cx="${f1(x1)}" cy="${f1(y1)}"/><circle class="findot" r="${sw(px, 3.5)}" cx="${f1(x2)}" cy="${f1(y2)}"/>`; }
  const left = b.marks.find((m) => m.side === -1 && m.role !== "rear") || b.marks.find((m) => m.role === "center"), right = b.marks.find((m) => m.side === 1 && m.role !== "rear");
  const S = { line: `stroke-width="${sw(px, 1)}"`, val: `font-size="${sw(px, 11)}"` };
  const vd = (x, ya, yb, text, anchor) => `<line class="dim" ${S.line} x1="${f1(x)}" y1="${f1(ya)}" x2="${f1(x)}" y2="${f1(yb)}"/><line class="dim" ${S.line} x1="${f1(x - 4 * px)}" y1="${f1(ya)}" x2="${f1(x + 4 * px)}" y2="${f1(ya)}"/><line class="dim" ${S.line} x1="${f1(x - 4 * px)}" y1="${f1(yb)}" x2="${f1(x + 4 * px)}" y2="${f1(yb)}"/><text class="val" ${S.val} x="${f1(x + (anchor === "start" ? 6 : -6) * px)}" y="${f1((ya + yb) / 2 + 4 * px)}" text-anchor="${anchor}">${svgEsc(text)}</text>`;
  const hd = (xa, xb, y, text) => `<line class="dim" ${S.line} x1="${f1(xa)}" y1="${f1(y)}" x2="${f1(xb)}" y2="${f1(y)}"/><line class="dim" ${S.line} x1="${f1(xa)}" y1="${f1(y - 4 * px)}" x2="${f1(xa)}" y2="${f1(y + 4 * px)}"/><line class="dim" ${S.line} x1="${f1(xb)}" y1="${f1(y - 4 * px)}" x2="${f1(xb)}" y2="${f1(y + 4 * px)}"/><text class="val" ${S.val} x="${f1((xa + xb) / 2)}" y="${f1(y - 6 * px)}" text-anchor="middle">${svgEsc(text)}</text>`;
  if (left) { const xl = X(-hw) - 10 * px; out += `<line class="ext" ${S.line} x1="${f1(X(left.lateral))}" y1="${f1(Y(left.offTail))}" x2="${f1(xl)}" y2="${f1(Y(left.offTail))}"/>` + vd(xl, Y(0), Y(left.offTail), mark(left.offTail), "end"); if (left.toe > 0.5) out += hd(X(-left.lateral), X(-left.leadLat), Y(left.leadOff) - 10 * px, mark(left.toe)); }
  if (right && right.kind === "rail") { const hwm = halfAt(O, right.offTail); out += hd(X(right.lateral), X(hwm), Y(right.offTail) - 10 * px, mark(hwm - right.lateral)); }
  document.getElementById("svg-viewer").innerHTML = out;
  document.getElementById("note-viewer").innerHTML = `<span class="findotkey"></span>Trailing &amp; Leading Edges${b.legend.map((l) => ` · Base Length (${svgEsc(l.label)}): ${mark(l.base)}`).join("")} · ${svgEsc(b.modelHeader)}`;
}
function drawFinsData() {
  const F = PG().fins, b = F.base, O = PG().outline.base;
  let h = `<div class="intro">${len(O.L)} · ${dim(O.tail12)} tail @${station()} · ${svgEsc(b.modelHeader)}${b.isModified ? " · Modified" : ""} · ${cap(PG().outline.spec.tail)} tail</div>`;
  for (const s of b.sections) { h += `<div class="datahead">${svgEsc(s.label)}</div><table class="data"><tbody>`; for (const g of s.groups) { h += `<tr><td colspan="2" class="ink" style="font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase">${g.heading}</td></tr>`; for (const r of g.rows) h += `<tr><td>${svgEsc(r.label)}</td><td>${mark(r.value)}</td></tr>`; if (g.fullSpread !== null) h += `<tr><td>Full Spread</td><td>${mark(g.fullSpread)}</td></tr>`; } h += `</tbody></table>`; }
  document.getElementById("panel-data").innerHTML = h;
}
// MODEL INFO is no longer a tab: its text sits on the GUIDE's cards (FINS_INFO), one note per setup or model

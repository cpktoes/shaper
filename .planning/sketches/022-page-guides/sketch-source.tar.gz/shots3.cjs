// Close-ups of round three's cards: each card screenshotted on its own, on a computer and on a phone.
const { chromium, devices } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("path");
const [,, file, out] = process.argv; const url = "file://" + path.resolve(file);
const WANT = [["outline", "depth"], ["fins", "convention"], ["fins", "setup_twin"], ["fins", "twin_upright"], ["fins", "setup_thruster"], ["fins", "thruster_mckeeSB"], ["fins", "setup_2plus1"], ["fins", "quad_mckeeLB"], ["fins", "quad_center"]];
(async () => {
  const browser = await chromium.launch();
  for (const [name, ctxOpts] of [["desktop", { viewport: { width: 1280, height: 800 } }], ["phone", { ...devices["iPhone 14"] }]]) {
    const ctx = await browser.newContext(ctxOpts); const page = await ctx.newPage();
    await page.goto(url); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#svg-viewer path.board").length > 0);
    for (const [pg, key] of WANT) {
      await page.click(`#bar [data-pg="${pg}"]`); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
      const card = page.locator(`#panel-guide .card[data-key="${key}"]`); await card.scrollIntoViewIfNeeded(); await page.waitForTimeout(120);
      await card.screenshot({ path: path.join(out, `card-${name}-${pg}-${key}.png`) });
    }
    // the Fish: the Depth card with the board's own swallow pushed, and FINS' Twin group on the board that is a twin
    await page.click('#bar [data-b="fish"]'); await page.click('#bar [data-pg="outline"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
    let c = page.locator('#panel-guide .card[data-key="depth"]'); await c.scrollIntoViewIfNeeded(); await page.waitForTimeout(120); await c.screenshot({ path: path.join(out, `card-${name}-outline-depth-fish.png`) });
    await page.click('#bar [data-pg="fins"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
    c = page.locator('#panel-guide .card[data-key="setup_twin"]'); await c.scrollIntoViewIfNeeded(); await page.waitForTimeout(120);
    await page.screenshot({ path: path.join(out, `${name}-fins-guide-twin-group-fish.png`) });
    await ctx.close();
  }
  await browser.close(); console.log("shots done");
})();

/* Sketch 022, round two: the TEMPLATE, RAILS, VOLUME and FINS figures of each board, read from the app's own maths, and the
   same figures with ONE setting pushed per GUIDE card — every pushed outline through buildOutline, every pushed rail
   section through computeRailSectionOutput + finishedRail, every pushed fin set through computeFinPlacement, every pushed
   estimate through computeVolume. Run: node_modules/.bin/tsx --tsconfig <repo>/tsconfig.json pages-data.ts <out.json> */
import { writeFileSync } from "node:fs";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/__fixtures__/phase16-boards";
import { designSideProfile, LIVE_DESIGN_RULES, deriveEffectiveRails, deriveEffectiveFins, deriveTemplateValues, deriveRailValues, deriveEffectiveVolume, designCrossSectionInput, type DesignSummaryFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/design";
import { buildOutline, sampleOutline, type OutlineGeometry } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/presets";
import { TAIL_PRESETS, type OutlineSpec, type TailShape } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/board";
import { nextWing, placedWings, wingRadiusTop, wingFootprint, effectiveWingRadius, type Wing } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/wings";
import { computeRailBands, computeRailSectionOutput, type RailBandSpec, type RailSectionKey, type RailSectionOutput, type RailSectionSpec } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/rail-bands";
import { finishedRail } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/finished-rail";
import { computeFinPlacement, importedFinTailFromOutline, resetAdvanced, FIN_SETUPS, THRUSTER_FRONT_MODELS, QUAD_REAR_MODELS, TWIN_TEMPLATES, type FinPlacementSpec } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/fins";
import { computeVolume, computeCrossSectionVolume, DEFAULT_VOLUME_SPEC, AREA_FACTORS, THICKNESS_FACTORS, BOARD_TYPE_LABELS } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/volume";
import { readSeedCatalog } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/blanks/seed-files";
import { isPickable } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/blanks/catalog";
import { mm, degrees, type Mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/units";

const IN = 25.4;
const r1 = (v: number) => Math.round(v * 10) / 10;
const r2 = (v: number) => Math.round(v * 100) / 100;
const num = (o: Record<string, unknown>) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, typeof v === "number" ? r1(v) : v]));

// the same five boards as board-data.ts (the fifth is the Shortboard in a longer blank; its outline, rails, fins and volume are the Shortboard's)
const all = phase16Boards();
const jobs: { id: string; fields: DesignSummaryFields }[] = [];
for (const preset of BOARD_PRESETS) { const hard = preset.rails.tailHardEdge ? "hard" : "soft"; jobs.push({ id: preset.id, fields: all.find((b) => b.label === `${preset.id}|asis|${hard}`)!.fields }); }
{ const sb = jobs.find((j) => j.id === "shortboard")!; const L = sb.fields.outline.length as number; const want = sb.fields.foil.center + sb.fields.blank!.deckSkin + IN / 4;
  const longer = readSeedCatalog().filter((r) => r.vendor === "US Blanks" && isPickable(r) && r.lengthMm > L + 5 * IN && r.lengthMm < L + 9 * IN && (r.stations.find((s) => s.label === "C")!.thicknessMm as number) >= want).sort((a, b) => Math.abs(a.lengthMm - (L + 6 * IN)) - Math.abs(b.lengthMm - (L + 6 * IN)));
  if (longer.length) jobs.push({ id: "shortboardlong", fields: { ...sb.fields, blank: { ...sb.fields.blank!, copy: longer[0], placement: mm(0), rocker: undefined } } }); }

const PUSH = { length: 6 * IN, angle: 20, tailAngle: 25, full: 30, width: IN, offset: 3 * IN, rail: 30, block: 2 * IN, depth: IN, wingPos: 4 * IN, wingDepth: IN / 2, wingRun: 1.5 * IN, wingOffset: 2 * IN,
  thick: IN / 4, deckPercent: 85, scale: 0.7, apex: IN / 4, deckMark: IN / 2, domedBand: 2 * IN, tuck1: IN / 4, tuck3: 0.75 * IN, blends: 6 * IN,
  finBase: IN, finForward: IN, finOffRail: -IN / 2, finToe: IN / 2, volLength: 6 * IN, volWidth: IN, volThick: IN / 4 };

function outlineOf(g: OutlineGeometry) {
  const wings = placedWings(g.wings ?? [], g);
  return { L: r1(g.length), pts: g.points.map((p) => [r1(p.station), r1(p.halfWidth)]), close: r1(g.centreCloseStation), first: r1(g.points[0].station), block: r1(g.halfTailBlockWidth * 2), pinned: g.tailBlockPinned,
    wide: r1(g.widePointStation), wideW: r1(g.halfWidePointWidth * 2), nose12: r1(g.noseWidthAt12in), tail12: r1(g.tailWidthAt12in), depth: r1(g.effectiveDiamondDepth), tailAngle: Math.round(g.tailAngle as number), anglePinned: g.tailAnglePinned,
    wings: wings.map((w) => ({ station: r1(w.station), depth: r1(w.depth), run: r1(w.run), radius: r1(effectiveWingRadius(w)), lock: w.lock, finOffset: r1(w.finOffset), inner: r1(wingFootprint(w).inner), stepStart: r1(wingFootprint(w).stepStart) })) };
}
function secOf(o: RailSectionOutput, x0: number) {
  const fr = finishedRail(o, mm(Math.min(x0, o.bounds.xAxisMin)));
  return { domed: o.domed, T: r1(o.boardThickness), railT: r1(o.railThicknessClamped), tEff: r1(o.thicknessEff), result: num(o.result as unknown as Record<string, unknown>),
    segments: o.segments.map((s) => ({ key: s.key, label: s.label, p1: [r1(s.p1.x), r1(s.p1.y)], p2: [r1(s.p2.x), r1(s.p2.y)] })), rail: fr.samples.map((p) => [r1(p.x), r1(p.y)]), xMin: r1(o.bounds.xAxisMin), yMax: r1(o.bounds.yAxisMax) };
}

const out: Record<string, unknown> = {};
for (const job of jobs) {
  const f = job.fields; const o = f.outline; const L = o.length as number;
  const g = buildOutline(o);
  const profile = designSideProfile(f, LIVE_DESIGN_RULES);
  // ---- FINS first: the wing's lock reads the front fins' trailing edge ----
  const tailIn = importedFinTailFromOutline(g);
  const finSpec = deriveEffectiveFins(f.fins, true, o, g);
  const finsOf = (spec: FinPlacementSpec) => { const r = computeFinPlacement(spec, tailIn);
    return { setup: spec.finSetup, frontModel: spec.frontModel, quadRearModel: spec.quadRearModel, twinTemplate: spec.twinTemplate, centerOn: spec.quadCenterFinOn, modelHeader: r.modelHeader, isModified: r.isModified, notes: r.notes,
      marks: r.marks.map((m) => ({ role: m.role, side: m.side, offTail: r1(m.offTail), lateral: r1(m.lateral), leadOff: r1(m.leadingOffTail), leadLat: r1(m.leadingLateral), base: r1(m.baseLength), toe: r1(m.toe), kind: m.lateralKind, lateralValue: m.lateralValue === null ? null : r1(m.lateralValue) })),
      legend: r.legend.map((l) => ({ label: l.label, base: r1(l.baseLength), dash: l.dash })), sections: r.sections.map((s) => ({ label: s.label, groups: s.groups.map((gr) => ({ heading: gr.heading, rows: gr.rows.map((row) => ({ label: row.label, value: r1(row.value) })), fullSpread: gr.fullSpread === null ? null : r1(gr.fullSpread) })) })),
      resolved: num(r.resolved as unknown as Record<string, unknown>) }; };
  const finBase = finsOf(finSpec);
  const reset = (setup: FinPlacementSpec["finSetup"], tt = finSpec.twinTemplate) => resetAdvanced(setup, tt);
  const finVariants: Record<string, unknown> = {};
  for (const s of FIN_SETUPS) finVariants[`setup_${s.value}`] = { label: s.label, ...finsOf({ ...finSpec, finSetup: s.value, advanced: reset(s.value) }) };
  for (const m of THRUSTER_FRONT_MODELS) finVariants[`thruster_${m.value}`] = { label: m.label, ...finsOf({ ...finSpec, finSetup: "thruster", frontModel: m.value, advanced: reset("thruster") }) };
  for (const m of QUAD_REAR_MODELS) finVariants[`quad_${m.value}`] = { label: m.label, disabled: m.value === "mckeeLB" && L < 96 * IN, ...finsOf({ ...finSpec, finSetup: "quad", quadRearModel: m.value, quadCenterFinOn: false, advanced: reset("quad") }) };
  finVariants.quad_center = finsOf({ ...finSpec, finSetup: "quad", quadRearModel: finSpec.quadRearModel === "mckeeLB" ? "mckeeSB" : finSpec.quadRearModel, quadCenterFinOn: true, advanced: reset("quad") });
  for (const t of TWIN_TEMPLATES) finVariants[`twin_${t.value}`] = { label: t.label, ...finsOf({ ...finSpec, finSetup: "twin", twinTemplate: t.value, advanced: reset("twin", t.value) }) };
  const adv = finSpec.advanced;
  finVariants.basePlus = finsOf({ ...finSpec, advanced: { ...adv, baseLenForward: mm(adv.baseLenForward + PUSH.finBase), baseLenForwardOverridden: true, baseLenCenter: mm(adv.baseLenCenter + PUSH.finBase), baseLenCenterOverridden: true, baseLenRear: mm(adv.baseLenRear + PUSH.finBase), baseLenRearOverridden: true } });
  finVariants.forwardPlus = finsOf({ ...finSpec, advanced: { ...adv, forwardPositionOffset: mm(adv.forwardPositionOffset + PUSH.finForward), centerPositionOffset: mm(adv.centerPositionOffset + PUSH.finForward), rearPositionOffset: mm(adv.rearPositionOffset + PUSH.finForward) } });
  finVariants.offRailCloser = finsOf({ ...finSpec, advanced: { ...adv, forwardOffRailNudge: mm(adv.forwardOffRailNudge + PUSH.finOffRail), rearOffRailNudge: mm(adv.rearOffRailNudge + PUSH.finOffRail) } });
  finVariants.toePlus = finsOf({ ...finSpec, advanced: { ...adv, forwardToeOverride: mm(PUSH.finToe), rearToeOverride: mm(PUSH.finToe) } });
  const frontMarks = finBase.marks.filter((m) => m.role === "front"); const rearMarks = finBase.marks.filter((m) => m.role === "rear");
  const edges = { front: frontMarks.length ? mm(Math.max(...frontMarks.map((m) => m.offTail))) : null, rear: rearMarks.length ? mm(Math.max(...rearMarks.map((m) => m.offTail))) : null };

  // ---- TEMPLATE ----
  const ov = (patch: Partial<OutlineSpec>) => outlineOf(buildOutline({ ...o, ...patch }));
  const tailK = o.tail.kind;
  const tailWith = (kind: TailShape["kind"]) => { const p = TAIL_PRESETS[kind]; return ov({ tail: p.tail, tailAngle: p.tailAngle, tailFullness: p.tailFullness }); };
  const wing0 = nextWing([], edges, g, "imperial");
  const wingBoard = (w: Partial<Wing>) => ov({ wings: [{ ...wing0, ...w }] });
  const outlineVariants: Record<string, unknown> = {
    lengthPlus: ov({ length: mm(L + PUSH.length) }), noseAnglePlus: ov({ noseAngle: degrees(Math.min(90, (o.noseAngle as number) + PUSH.angle)) }), noseFullPlus: ov({ noseFullness: Math.min(100, o.noseFullness + PUSH.full) }),
    widthPlus: ov({ widePointWidth: mm(o.widePointWidth + PUSH.width) }), offsetNose: ov({ widePointOffset: mm(o.widePointOffset + PUSH.offset) }),
    tailRailPlus: ov({ tailRailLength: Math.min(100, o.tailRailLength + PUSH.rail) }), noseRailPlus: ov({ noseRailLength: Math.min(100, o.noseRailLength + PUSH.rail) }),
    tail_pin: tailWith("pin"), tail_round: tailWith("round"), tail_diamond: tailWith("diamond"), tail_squash: tailWith("squash"), tail_swallow: tailWith("swallow"),
    tailBlockPlus: tailK === "squash" || tailK === "diamond" || tailK === "swallow" ? ov({ tail: { ...o.tail, endWidth: mm((o.tail as { endWidth: number }).endWidth + PUSH.block) } as TailShape }) : null,
    depthPlus: tailK === "diamond" ? ov({ tail: { ...o.tail, depth: mm((o.tail as { depth: number }).depth + PUSH.depth) } as TailShape }) : tailK === "swallow" ? ov({ tail: { ...o.tail, crotchDepth: mm((o.tail as { crotchDepth: number }).crotchDepth + PUSH.depth) } as TailShape }) : null,
    tailAnglePlus: tailK === "diamond" ? null : ov({ tailAngle: degrees(Math.min(90, (o.tailAngle as number) + PUSH.tailAngle)) }), tailFullPlus: ov({ tailFullness: Math.min(100, o.tailFullness + PUSH.full) }),
    wingAdd: wingBoard({}), wingPos: wingBoard({ lock: null, station: mm(wing0.station + PUSH.wingPos) }), wingDepth: wingBoard({ depth: mm(PUSH.wingDepth) }), wingRun: wingBoard({ run: mm(PUSH.wingRun) }),
    wingRadius: wingBoard({ radius: wingRadiusTop(wing0, "imperial") }), wingOffset: wingBoard({ finOffset: mm(wing0.finOffset + PUSH.wingOffset) }),
  };
  const outline = { base: outlineOf(g), spec: { noseAngle: Math.round(o.noseAngle as number), noseFullness: o.noseFullness, tailAngle: Math.round(o.tailAngle as number), tailFullness: o.tailFullness, tailRail: o.tailRailLength, noseRail: o.noseRailLength, offset: r1(o.widePointOffset), tail: tailK }, variants: outlineVariants, wingRadiusTop: r1(wingRadiusTop(wing0, "imperial")) };

  // ---- RAILS ----
  const rails = deriveEffectiveRails(f.rails, profile.effectiveFoil, f.railsImportFoilThickness);
  const rb = computeRailBands(rails);
  const x0 = Math.min(rb.nose.bounds.xAxisMin, rb.center.bounds.xAxisMin, rb.tail.bounds.xAxisMin);
  const keys: RailSectionKey[] = ["nose", "center", "tail"];
  const rv = (key: RailSectionKey, patch: Partial<RailSectionSpec>, hard = key === "tail" ? rails.tailHardEdge : false) => ({ sec: key, ...secOf(computeRailSectionOutput(key, { ...rails[key], ...patch }, hard), x0) });
  const c = rails.center, t = rails.tail;
  const anchors = { tail: 12 * IN, center: L / 2, nose: L - 12 * IN };
  const railVariants: Record<string, unknown> = {
    thicknessPlus: rv("center", { boardThickness: mm(c.boardThickness + PUSH.thick) }), deckProfile: rv("center", { deckPercent: PUSH.deckPercent }),
    family: { word: c.family <= 3 ? "knifey" : "boxy", ...rv("center", { family: c.family <= 3 ? 5 : 1 }) }, ratio: { top: c.ratioTopPercent >= 50 ? 35 : 70, ...rv("center", { ratioTopPercent: c.ratioTopPercent >= 50 ? 35 : 70 }) },
    symmetrical: { on: !c.symmetrical, ...rv("center", { symmetrical: !c.symmetrical }) }, hardEdge: { on: !rails.tailHardEdge, ...rv("tail", rails.tailHardEdge ? {} : { symmetrical: false }, !rails.tailHardEdge) },
    scaled: rv("tail", { scaleFromCenter: PUSH.scale }), apexThickness: rv("center", { nudges: { ...c.nudges, apexThickness: mm(c.nudges.apexThickness + PUSH.apex) } }),
    deckMark1: rv("center", { nudges: { ...c.nudges, deckMark1: mm(c.nudges.deckMark1 + PUSH.deckMark) } }), deckMark3: rv("center", { nudges: { ...c.nudges, deckMark3: mm(c.nudges.deckMark3 + PUSH.deckMark) } }),
    domedDeckBand: rv("center", { nudges: { ...c.nudges, domedDeckBand: mm(c.nudges.domedDeckBand + PUSH.domedBand) } }), singleTuck: rv("center", { singleTuck: true }),
    bottomTuck1: rv("center", { nudges: { ...c.nudges, bottomTuck1: mm(c.nudges.bottomTuck1 + PUSH.tuck1) } }), bottomTuck3: rv("center", { nudges: { ...c.nudges, bottomTuck3: mm(c.nudges.bottomTuck3 + PUSH.tuck3) } }),
    sharpBottomTuck: rv("center", { sharpBottomTuck: true }),
  };
  const railsOut = { importing: f.railsImportFoilThickness, hardEdge: rails.tailHardEdge, blendsFrom: r1(rails.tailHardEdgeBlendsFrom ?? 18 * IN), endsAt: r1(rails.tailHardEdgeEndsAt ?? L / 6 + 18 * IN),
    spec: Object.fromEntries(keys.map((k) => [k, { T: r1(rails[k].boardThickness), deckPercent: r2(rails[k].deckPercent), family: rails[k].family, ratioTop: rails[k].ratioTopPercent, symmetrical: rails[k].symmetrical, singleTuck: rails[k].singleTuck, sharp: rails[k].sharpBottomTuck, scale: rails[k].scaleFromCenter, nudges: num(rails[k].nudges as unknown as Record<string, unknown>) }])),
    anchors: num(anchors), halfAt: num({ tail: sampleOutline(g, mm(anchors.tail)), center: sampleOutline(g, mm(anchors.center)), nose: sampleOutline(g, mm(anchors.nose)) }),
    base: Object.fromEntries(keys.map((k) => [k, secOf(rb[k], x0)])), x0: r1(x0), variants: railVariants };

  // ---- VOLUME ----
  const tv = deriveTemplateValues(o, g); const rvv = deriveRailValues(rb);
  const vol = f.volume ?? DEFAULT_VOLUME_SPEC;
  const eff = deriveEffectiveVolume(vol, tv, rvv);
  const res = computeVolume(eff, tv, rvv);
  const xs = computeCrossSectionVolume(designCrossSectionInput(g, profile, rails, o.length));
  const quickSpec = { length: eff.length, width: eff.width, centerThickness: eff.centerThickness, boardTypeIndex: vol.boardTypeIndex, importTemplateDimensions: false, importRailThickness: false };
  const quick = (patch: Partial<typeof quickSpec>) => { const q = computeVolume({ ...quickSpec, ...patch }, null, null); return { litres: r2(q.volumeLitres), area: r2(q.area), weighted: r1(q.weightedThickness), label: q.boardTypeLabel }; };
  const volume = { importing: eff.importTemplateDimensions, length: r1(eff.length), width: r1(eff.width), thick: r1(eff.centerThickness), typeIndex: vol.boardTypeIndex, typeLabel: BOARD_TYPE_LABELS[vol.boardTypeIndex], quoted: r2(xs.volumeLitres),
    estimator: { litres: r2(res.volumeLitres), area: r2(res.area), weighted: r1(res.weightedThickness), tail: res.tailCrossSectionThickness === null ? null : r1(res.tailCrossSectionThickness), center: res.centerCrossSectionThickness === null ? null : r1(res.centerCrossSectionThickness), nose: res.noseCrossSectionThickness === null ? null : r1(res.noseCrossSectionThickness), geomReady: res.geomReady },
    stations: xs.stations.map((s) => r1(s)), stationAreas: xs.stationAreas.map((a) => r1(a)), panelCount: xs.panelCount,
    quick: quick({}), variants: { lengthPlus: quick({ length: mm(eff.length + PUSH.volLength) }), widthPlus: quick({ width: mm(eff.width + PUSH.volWidth) }), thickPlus: quick({ centerThickness: mm(eff.centerThickness + PUSH.volThick) }), types: AREA_FACTORS.map((_, i) => quick({ boardTypeIndex: i })) },
    factors: { area: AREA_FACTORS, thickness: THICKNESS_FACTORS, labels: BOARD_TYPE_LABELS } };

  out[job.id] = { outline, rails: railsOut, volume, fins: { base: finBase, variants: finVariants, edges: { front: edges.front === null ? null : r1(edges.front), rear: edges.rear === null ? null : r1(edges.rear) }, setups: FIN_SETUPS, thrusterModels: THRUSTER_FRONT_MODELS, quadModels: QUAD_REAR_MODELS, twinTemplates: TWIN_TEMPLATES } };
  console.log(job.id, "outline wide", r1(g.widePointStation / IN), "tail", tailK, "| rails center family", c.family, "ratio", c.ratioTopPercent, "hard", rails.tailHardEdge, "| vol quoted", r2(xs.volumeLitres), "est", r2(res.volumeLitres), "quick", quick({}).litres, "| fins", finBase.modelHeader, "marks", finBase.marks.length, "front edge", edges.front === null ? "—" : r1((edges.front as number) / IN));
}
writeFileSync(process.argv[2], JSON.stringify({ push: PUSH, boards: out }));
console.log("wrote", process.argv[2]);

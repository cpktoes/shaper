/* Sketch 022's real board figures, read from the app's own maths. Never hand-type a board number.
   For ROCKER's GUIDE: each board's side profile as the page draws it (the board in its blank), and the same
   profile with ONE setting pushed per card — a thicker centre, thicker tips, the board slid along its blank, a
   deeper deck skin, each Pin tips to, a thinning start moved in, the 12" fine-tunes, more nose or tail rocker
   (the blank bent from the centre), and a maker's bend 18" in — every one built by `designSideProfile`, the one
   recipe every screen reads. Run: node_modules/.bin/tsx --tsconfig <repo>/tsconfig.json board-data.ts <out.json> */
import { writeFileSync } from "node:fs";
const W = "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/__fixtures__/phase16-boards";
import { designSideProfile, LIVE_DESIGN_RULES, type DesignSummaryFields } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/design";
import { buildOutline, sampleOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/outline";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/presets";
import { placementRange } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/blank-fit";
import { formatRockerNote, prepareBoardBlank, type BlankRockerSpec } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/custom-rocker";
import { readSeedCatalog } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/blanks/seed-files";
import { isPickable } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/blanks/catalog";
import { DEFAULT_FIT_DEFAULTS } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/fit-defaults-preference";
import { mm, type Mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/units";
import type { FoilStationKey } from "/Users/kontoes/Code/shaper/.claude/worktrees/elastic-joliot-3e9625/lib/geometry/foil";

const IN = 25.4;
const N = 121;   // board stations, tail (0) to nose (L)
const M = 161;   // blank stations, its tail to its nose, in the board's coordinates
const r1 = (v: number) => Math.round(v * 10) / 10;
const r2 = (v: number) => Math.round(v * 100) / 100;
const KEYS: FoilStationKey[] = ["tailTip", "tail12", "center", "nose12", "noseTip"];

// the amounts each card pushes its setting by — honest exaggerations, each labelled on the cartoon
const PUSH = { center: IN / 2, tips: (3 / 8) * IN, skin: IN / 2, startIn: 24 * IN, fine: IN / 4, rocker: IN, bend: IN / 2, bendFrom: 18 * IN };

const all = phase16Boards();
type Fields = DesignSummaryFields;
const jobs: { id: string; name: string; fields: Fields }[] = [];
for (const preset of BOARD_PRESETS) {
  const hard = preset.rails.tailHardEdge ? "hard" : "soft";
  const board = all.find((b) => b.label === `${preset.id}|asis|${hard}`)!;
  jobs.push({ id: preset.id, name: preset.name, fields: board.fields });
}
// a fifth board: the Shortboard in a longer US Blanks blank, so the Placement card has room to slide (the
// presets' own blanks are within an inch of their boards, so their slider barely moves)
{
  const sb = jobs.find((j) => j.id === "shortboard")!;
  const L = sb.fields.outline.length as number;
  const want = sb.fields.foil.center + sb.fields.blank!.deckSkin + IN / 4;
  const longer = readSeedCatalog().filter((r) => r.vendor === "US Blanks" && isPickable(r) && r.lengthMm > L + 5 * IN && r.lengthMm < L + 9 * IN
    && (r.stations.find((s) => s.label === "C")!.thicknessMm as number) >= want).sort((a, b) => Math.abs(a.lengthMm - (L + 6 * IN)) - Math.abs(b.lengthMm - (L + 6 * IN)));
  if (longer.length) {
    const copy = longer[0];
    jobs.push({ id: "shortboardlong", name: `Shortboard · ${copy.name} blank`, fields: { ...sb.fields, blank: { ...sb.fields.blank!, copy, placement: mm(0), rocker: undefined } } });
    console.log("longer blank for the Shortboard:", copy.vendor, copy.name, (copy.lengthMm / IN).toFixed(2), "in");
  } else console.log("no longer US Blanks blank found for the Shortboard");
}

function sampleProfile(fields: Fields) {
  const p = designSideProfile(fields, LIVE_DESIGN_RULES);
  const L = p.length as number;
  const rocker: number[] = [], deck: number[] = [];
  for (let i = 0; i < N; i++) { const s = mm((i / (N - 1)) * L); rocker.push(r1(p.rockerAt(s))); deck.push(r1(p.deckAt(s))); }
  const b = p.blank;
  let blank: Record<string, unknown> | null = null;
  if (b) {
    const start = b.start as number, end = b.end as number;
    const bottom: number[] = [], top: number[] = [];
    for (let i = 0; i < M; i++) { const s = mm(start + ((end - start) * i) / (M - 1)); bottom.push(r1(b.bottomAt(s))); top.push(r1(b.deckAt(s))); }
    const rec = (f: Record<FoilStationKey, Mm>) => Object.fromEntries(KEYS.map((k) => [k, r1(f[k])]));
    blank = {
      start: r1(start), end: r1(end), bottom, top, placement: r1(b.placement), centerGap: r1(b.centerGap),
      cut: { deckSkin: r1(b.cut.deckSkin), tipStyle: b.cut.tipStyle, fineTuneSurface: b.cut.fineTuneSurface },
      derived12: { nose12: r1(b.derived12.nose12), tail12: r1(b.derived12.tail12) },
      foamOffDeck: rec(b.foamOffDeck), foamOffBottom: rec(b.foamOffBottom),
      tips: Object.fromEntries((["nose", "tail"] as const).map((e) => { const t = b.tips[e]; return [e, { fromTip: r1(t.fromTip), station: r1(t.station), automatic: t.automatic, automaticStart: r1(t.automaticStart), reachesStation: t.reachesStation, flag: t.flag ? t.flag.kind : null, range: [r1(t.range.min), r1(t.range.max)] }]; })),
    };
  }
  return { L: r1(L), rocker, deck, blank, stationRocker: Object.fromEntries(KEYS.map((k) => [k, r1(p.stationRocker[k])])), foil: Object.fromEntries(KEYS.map((k) => [k, r1(p.effectiveFoil[k])])) };
}

const out: unknown[] = [];
for (const job of jobs) {
  const f = job.fields; const bl = f.blank!;
  const L = f.outline.length as number;
  const base = sampleProfile(f);
  const g = buildOutline(f.outline);
  const outline: number[] = []; for (let i = 0; i < N; i++) outline.push(r1(sampleOutline(g, mm((i / (N - 1)) * L))));
  const prepared = prepareBoardBlank(bl);
  const b0 = base.blank!;
  const start = b0.start as number, end = b0.end as number;
  const blankWidth: number[] = []; for (let i = 0; i < M; i++) { const u = ((end - start) * i) / (M - 1); blankWidth.push(r1(prepared.width.sample(u))); }
  const printed = Object.fromEntries(KEYS.map((k) => { const st = { noseTip: "N0", nose12: "N12", center: "C", tail12: "T12", tailTip: "T0" }[k]; const row = bl.copy.stations.find((s) => s.label === st); return [k, row ? { rocker: row.rockerMm === null ? null : r1(row.rockerMm), thickness: row.thicknessMm === null ? null : r1(row.thicknessMm), width: row.widthMm === null ? null : r1(row.widthMm) } : null]; }));
  const range = placementRange(bl.copy.lengthMm, f.outline.length);
  const withBlank = (patch: Partial<typeof bl>) => ({ ...f, blank: { ...bl, ...patch } });
  const noseAuto = (b0.tips as { nose: { automaticStart: number } }).nose.automaticStart, tailAuto = (b0.tips as { tail: { automaticStart: number } }).tail.automaticStart;
  const noseStart = Math.max(PUSH.startIn, noseAuto + 8 * IN), tailStart = Math.max(PUSH.startIn, tailAuto + 8 * IN);
  const bend: BlankRockerSpec = { changes: [{ end: "nose", amount: mm(PUSH.bend), fromTip: mm(PUSH.bendFrom) }] };
  const variants: Record<string, unknown> = {
    centerPlus: { amount: PUSH.center, ...sampleProfile({ ...f, foil: { ...f.foil, center: mm(f.foil.center + PUSH.center) } }) },
    tipsPlus: { amount: PUSH.tips, ...sampleProfile({ ...f, foil: { ...f.foil, noseTip: mm(f.foil.noseTip + PUSH.tips), tailTip: mm(f.foil.tailTip + PUSH.tips) } }) },
    placeNose: range.max > 0.5 ? { amount: r1(range.max), ...sampleProfile(withBlank({ placement: range.max })) } : null,
    skinPlus: { amount: PUSH.skin, ...sampleProfile(withBlank({ deckSkin: mm(PUSH.skin) })) },
    pinDeck: { ...sampleProfile(withBlank({ tipStyle: "pinDeck" })) },
    pinBottom: { ...sampleProfile(withBlank({ tipStyle: "bottom" })) },
    noseStartIn: { amount: r1(noseStart), ...sampleProfile(withBlank({ noseThinningStart: mm(noseStart) })) },
    tailStartIn: { amount: r1(tailStart), ...sampleProfile(withBlank({ tailThinningStart: mm(tailStart) })) },
    fineUp: { amount: PUSH.fine, ...sampleProfile(withBlank({ nose12Offset: mm(PUSH.fine), tail12Offset: mm(PUSH.fine) })) },
    fineDeckDown: { amount: -PUSH.fine, ...sampleProfile(withBlank({ tail12Offset: mm(-PUSH.fine), fineTuneSurface: "deck" })) },
    fineBottomDown: { amount: -PUSH.fine, ...sampleProfile(withBlank({ tail12Offset: mm(-PUSH.fine), fineTuneSurface: "bottom" })) },
    noseRockerPlus: { amount: PUSH.rocker, ...sampleProfile(withBlank({ rocker: { changes: [{ end: "nose", amount: mm(PUSH.rocker) }] } })) },
    tailRockerPlus: { amount: PUSH.rocker, ...sampleProfile(withBlank({ rocker: { changes: [{ end: "tail", amount: mm(PUSH.rocker) }] } })) },
    customBend: { amount: PUSH.bend, fromTip: PUSH.bendFrom, note: formatRockerNote(bend), ...sampleProfile(withBlank({ rocker: bend })) },
  };
  out.push({
    id: job.id, name: job.name, L: r1(L), widePointStation: r1(g.widePointStation), tail: f.outline.tail.kind,
    stations: Object.fromEntries(designSideProfile(f, LIVE_DESIGN_RULES).stations.map((s) => [s.key, r1(s.station)])),
    blank: { ...base.blank, vendor: bl.copy.vendor, name: bl.copy.name, lengthMm: r1(bl.copy.lengthMm), centerThickness: r1(prepared.centerThicknessMm), printed, width: blankWidth,
      placementRange: [r1(range.min), r1(range.max)], nose12Offset: r1(bl.nose12Offset), tail12Offset: r1(bl.tail12Offset), rockerNote: formatRockerNote(bl.rocker), custom: !!(bl.rocker && bl.rocker.changes.length) },
    outline, foilSettings: { center: r1(f.foil.center), noseTip: r1(f.foil.noseTip), tailTip: r1(f.foil.tailTip) },
    rocker: base.rocker, deck: base.deck, stationRocker: base.stationRocker, foil: base.foil, variants,
  });
  const t = b0.tips as Record<string, { fromTip: number; automatic: boolean }>;
  console.log(job.name, "L", (L / IN).toFixed(2), "blank", bl.copy.name, (bl.copy.lengthMm / IN).toFixed(2), "slide ±", (range.max / IN).toFixed(2), "rocker nose/tail", (base.stationRocker.noseTip / IN).toFixed(2), (base.stationRocker.tailTip / IN).toFixed(2),
    "thinning", (t.nose.fromTip / IN).toFixed(1), (t.tail.fromTip / IN).toFixed(1), "gap", (b0.centerGap as number / IN).toFixed(3));
}
writeFileSync(process.argv[2], JSON.stringify({ planerMaxDepth: r1(DEFAULT_FIT_DEFAULTS.planerMaxDepth), push: PUSH, boards: out }));
console.log("wrote", process.argv[2]);

// Headless checks of sketch 022 at a computer's width and an upright phone's, with pictures.
// Run: node test.cjs <path-to-index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const fs = require("node:fs");

const file = process.argv[2];
const out = process.argv[3];
fs.mkdirSync(out, { recursive: true });
const url = "file://" + path.resolve(file);
const CARDS = 14, GHOSTED = 11; // every card but Blank and the two Pin tips to cards carries a pushed profile in dashes

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  const errors = [];

  // ---- a computer: 1280 x 800 ----
  let page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("pageerror", (e) => errors.push("desktop: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("desktop console: " + m.text()); });
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#side path.board").length > 0);
  const desk = await page.evaluate(() => {
    const app = document.getElementById("app");
    const side = document.querySelector(".side").getBoundingClientRect();
    const svg = document.getElementById("side").getBoundingClientRect();
    const vis = (sel) => [...document.querySelectorAll(sel)].filter((e) => getComputedStyle(e).display !== "none");
    return { phone: app.classList.contains("phone"), side: [side.x, side.width, side.height], svg: [svg.width, svg.height],
      tabs: vis(".tabs .tab").map((e) => e.dataset.page), tabWords: vis(".tabs .tab").map((e) => e.innerText.trim()),
      blank: document.querySelectorAll("#side .blankfoam").length, board: document.querySelectorAll("#side path.board").length, marks: document.querySelectorAll("#side .mark").length, chips: document.querySelectorAll("#side .chip").length,
      labels: [...document.querySelectorAll("#sidebar .lbl")].map((e) => e.textContent), boardName: document.getElementById("boardName").textContent,
      sideWords: document.getElementById("side").textContent, vertical: document.getElementById("side").getAttribute("viewBox") };
  });
  console.log("desktop", JSON.stringify(desk));
  if (desk.phone) problems.push("desktop got the phone layout");
  if (desk.side[1] !== 340) problems.push("sidebar is not 340 wide: " + desk.side[1]);
  if (desk.tabs.join() !== "viewer,planing,datasheet,guide") problems.push("a computer's tabs should be VIEWER · PLANING · DATASHEET · GUIDE: " + desk.tabs.join());
  if (desk.tabWords.join("|") !== "VIEWER|PLANING|DATASHEET|GUIDE") problems.push("a computer keeps the full tab words: " + desk.tabWords.join("|"));
  if (desk.blank < 1 || desk.board < 1 || desk.marks !== 2) problems.push("the VIEWER should draw the blank, the board and two thinning marks: " + JSON.stringify([desk.blank, desk.board, desk.marks]));
  if (desk.chips !== 3) problems.push("with a blank the three thickness inputs are cards: " + desk.chips);
  for (const want of ["Center Thickness — 2 1/4\"", "Nose Tip — 7/16\"", "Tail Tip — 15/16\"", "Placement — centered", "Deck Skin — 1/8\"", "Pin tips to", "Nose Thinning Starts — 12\"", "Tail Thinning Starts — 12\""]) if (!desk.labels.some((l) => l.startsWith(want))) problems.push("sidebar lacks the real label " + want + ": " + desk.labels.join(" / "));
  if (!/Thickness/.test(desk.sideWords) || !/Rocker/.test(desk.sideWords)) problems.push("the VIEWER's two rails should be titled Thickness and Rocker");
  if (!desk.vertical.startsWith("0 0 1000 ")) problems.push("a computer's side view lies flat (viewBox 1000 wide): " + desk.vertical);
  await page.screenshot({ path: path.join(out, "desktop-viewer.png") });
  for (const t of ["planing", "datasheet"]) { await page.click(`.tabs [data-page="${t}"]`); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${t}.png`) }); }
  const data = await page.evaluate(() => ({ rows: document.querySelectorAll("#dataPanel tbody tr").length, typed: document.querySelectorAll("#dataPanel td.typed span").length, planing: document.querySelectorAll("#planingPanel tbody tr").length }));
  if (data.rows < 10 || data.typed !== 3 || data.planing !== 5) problems.push("DATASHEET and PLANING should carry their rows (nine data rows, three typed thicknesses, five planing stations): " + JSON.stringify(data));

  // GUIDE on a computer: fourteen cards in four groups, every card with its cartoon (the whole board and at least one detail
  // window), the board's own value beside its name, its two sentences and its How to shape note; eleven with a pushed profile
  await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
  const guide = await page.evaluate(() => {
    const cards = [...document.querySelectorAll("#guidePanel .card")];
    const info = cards.map((c) => ({ key: c.dataset.key, name: c.querySelector("h4 span").textContent, tag: (c.querySelector("h4 .now") || {}).textContent || "",
      boards: c.querySelectorAll("svg path.board").length, blanks: c.querySelectorAll("svg .blankfoam").length, wins: c.querySelectorAll("svg .win").length, ghosts: c.querySelectorAll("svg path.ghost").length, dims: c.querySelectorAll("svg .dim").length,
      sentences: c.querySelector("p").textContent.split(/\.\s+/).length, how: /How to shape\S/.test((c.querySelector("p.how") || {}).textContent || ""), on: c.classList.contains("on") }));
    return { n: cards.length, info, heads: [...document.querySelectorAll("#guidePanel .datahead")].map((e) => e.firstChild.textContent.trim()),
      panelScroll: document.getElementById("guidePanel").scrollHeight > document.getElementById("guidePanel").clientHeight, viewerHidden: getComputedStyle(document.getElementById("viewerPanel")).display === "none",
      cols: new Set([...document.querySelectorAll("#guidePanel .cards")[1].querySelectorAll(".card")].map((c) => Math.round(c.getBoundingClientRect().x))).size, note: document.querySelector("#guidePanel .guidenote").textContent };
  });
  console.log("guide:", JSON.stringify({ n: guide.n, heads: guide.heads, cols: guide.cols, tags: guide.info.map((i) => i.key + "=" + i.tag) }));
  if (guide.n !== CARDS) problems.push(`GUIDE should have ${CARDS} cards: ` + guide.n);
  if (guide.heads.join() !== "Inputs,Blank,Rocker,Foil") problems.push("GUIDE should be headed Inputs, Blank, Rocker, Foil: " + guide.heads.join(" | "));
  const noPic = guide.info.filter((i) => i.boards < 2 || i.wins < 1 || i.blanks < 2); if (noPic.length) problems.push("every card needs its cartoon — the whole board in its blank and a detail window: " + noPic.map((i) => i.key).join(","));
  const noHow = guide.info.filter((i) => !i.how); if (noHow.length) problems.push("every card needs its How to shape line: " + noHow.map((i) => i.key).join(","));
  const bad = guide.info.filter((i) => i.sentences < 2 || i.sentences > 4); if (bad.length) problems.push("each card should carry a sentence or two per part: " + bad.map((i) => i.key + ":" + i.sentences).join(","));
  const ghosted = guide.info.filter((i) => i.ghosts > 0).map((i) => i.key); if (ghosted.length !== GHOSTED) problems.push(`${GHOSTED} cards should carry a pushed profile in dashes: ` + ghosted.join(","));
  const noDim = guide.info.filter((i) => i.dims < 1); if (noDim.length) problems.push("every card should dimension its number: " + noDim.map((i) => i.key).join(","));
  const tag = (k) => (guide.info.find((i) => i.key === k) || {}).tag;
  if (tag("center") !== '2 1/4"' || tag("tips") !== '7/16" · 15/16"' || tag("placement") !== "centered" || tag("skin") !== '1/8"' || tag("pinDeck") !== "On this board" || tag("pinBottom") !== "" || tag("noseStart") !== '12" · Automatic' || tag("fine") !== "No tweak" || tag("fineFrom") !== "Deck" || tag("custom") !== "Natural rocker")
    problems.push("the Shortboard's own values should sit beside the names: " + guide.info.map((i) => i.key + "=" + i.tag).join(" / "));
  if (!/^\d+ \d+\/\d+"$|^\d+"$/.test(tag("noseRocker") || "")) problems.push("the Nose Rocker card should carry the board's nose rocker: " + tag("noseRocker"));
  if (!/US Blanks 6'3"RP/.test(tag("blank") || "")) problems.push("the Blank card should name the blank: " + tag("blank"));
  if (guide.info.filter((i) => i.on).map((i) => i.key).join() !== "pinDeck") problems.push("only the active Pin tips to option should be marked On this board");
  for (const [key, words] of [["center", "Center Thickness"], ["tips", "Nose Tip · Tail Tip"], ["placement", "Placement"], ["skin", "Deck Skin"], ["custom", "Customize Rocker"], ["pinDeck", "Pin tips to · Deck"], ["noseStart", "Nose Thinning Starts"], ["fine", 'Nose @ 12" · Tail @ 12"'], ["fineFrom", "Fine tune from"]]) { const i = guide.info.find((x) => x.key === key); if (!i || i.name !== words) problems.push(`card ${key} should be named as the page labels it (${words}): ` + (i && i.name)); }
  if (!guide.panelScroll || !guide.viewerHidden) problems.push("the GUIDE panel should scroll inside the folder with the viewer hidden");
  if (guide.cols !== 3) problems.push("a computer should show three cards across: " + guide.cols);
  if (!/your Shortboard in its US Blanks 6'3"RP blank/.test(guide.note)) problems.push("the GUIDE's note should name the board and its blank: " + guide.note);
  await page.screenshot({ path: path.join(out, "desktop-guide.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 700; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-guide-rocker.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 1500; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-guide-foil.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 0; });
  // a close picture of two cards, for the founder's eye on the cartoon itself
  await page.evaluate(() => document.querySelector('#guidePanel .card[data-key="noseRocker"]').scrollIntoView({ block: "start" })); await page.waitForTimeout(150);
  const cardBox = await (await page.$('#guidePanel .card[data-key="noseRocker"]')).boundingBox();
  await page.screenshot({ path: path.join(out, "desktop-card-close.png"), clip: { x: Math.max(0, cardBox.x - 6), y: Math.max(0, cardBox.y - 6), width: Math.min(1280 - cardBox.x, cardBox.width * 2 + 22), height: Math.min(800 - cardBox.y, cardBox.height + 12) } });
  await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "desktop-guide-slate.png") });
  // the guide follows the board: the Fish's own numbers, the Fish's blank
  await page.click('#bar [data-b="fish"]'); await page.waitForTimeout(250);
  const fish = await page.evaluate(() => ({ tags: [...document.querySelectorAll("#guidePanel .card")].map((c) => c.dataset.key + "=" + ((c.querySelector("h4 .now") || {}).textContent || "")), note: document.querySelector("#guidePanel .guidenote").textContent, n: document.querySelectorAll("#guidePanel .card").length }));
  if (!fish.tags.includes('center=2 1/2"') || !/your Fish in its US Blanks 5'10"RP blank/.test(fish.note) || fish.n !== CARDS) problems.push("GUIDE should follow the board: " + JSON.stringify(fish));
  await page.click('#bar [data-t="daylight"]'); await page.screenshot({ path: path.join(out, "desktop-guide-fish.png") });
  // the longer blank: Placement has room, and its card says how far the dashes slid
  await page.click('#bar [data-b="shortboardlong"]'); await page.waitForTimeout(250);
  const longer = await page.evaluate(() => { const c = document.querySelector('#guidePanel .card[data-key="placement"]'); return { ghosts: c.querySelectorAll("path.ghost").length, words: c.querySelector("svg").textContent, tag: c.querySelector("h4 .now").textContent }; });
  if (longer.ghosts < 2 || !/slid 2 3\/8" to the nose/.test(longer.words)) problems.push("in the longer blank the Placement card should slide the board 2 3/8\" toward the nose in dashes: " + JSON.stringify(longer));
  await page.screenshot({ path: path.join(out, "desktop-guide-longer-blank.png") });
  await page.click('#bar [data-b="shortboard"]');
  // every theme draws without error, on the GUIDE
  for (const t of ["daylight", "chalk", "slate", "phosphor"]) { await page.click(`#bar [data-t="${t}"]`); await page.waitForTimeout(80); if (t === "phosphor" || t === "chalk") await page.screenshot({ path: path.join(out, `desktop-guide-${t}.png`) }); }
  await page.click('#bar [data-t="daylight"]');
  // Metric: the tags and the sidebar read in mm and cm
  await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(200);
  const met = await page.evaluate(() => ({ tags: [...document.querySelectorAll("#guidePanel .card")].map((c) => c.dataset.key + "=" + ((c.querySelector("h4 .now") || {}).textContent || "")), names: [...document.querySelectorAll("#guidePanel .card h4 span:first-child")].map((e) => e.textContent), labels: [...document.querySelectorAll("#sidebar .lbl")].map((e) => e.textContent) }));
  console.log("metric:", JSON.stringify(met.tags));
  if (!met.tags.includes("center=57 mm") || !met.tags.includes("skin=3 mm") || !met.tags.includes("noseStart=30.5 cm · Automatic")) problems.push("metric tags should read in whole mm (marks) and cm (a thinning start): " + met.tags.join(" / "));
  if (!met.names.includes("Nose @ 30.5 cm · Tail @ 30.5 cm")) problems.push("the 12\" card should read 30.5 cm in Metric: " + met.names.join(" / "));
  if (!met.labels.some((l) => /Center Thickness — 57 mm/.test(l)) || !met.labels.some((l) => /Nose Thinning Starts — 30.5 cm/.test(l))) problems.push("metric sidebar labels: " + met.labels.join(" / "));
  await page.screenshot({ path: path.join(out, "desktop-guide-metric.png") });
  await page.click('.tabs [data-page="datasheet"]'); await page.waitForTimeout(100); await page.screenshot({ path: path.join(out, "desktop-datasheet-metric.png") });
  await page.click('#bar [data-u="imperial"]'); await page.click('.tabs [data-page="viewer"]');
  for (const b of ["midlength", "longboard"]) { await page.click(`#bar [data-b="${b}"]`); await page.waitForTimeout(150); await page.screenshot({ path: path.join(out, `desktop-viewer-${b}.png`) }); }
  await page.click('#bar [data-b="longboard"]'); await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(200); await page.screenshot({ path: path.join(out, "desktop-guide-longboard.png") });
  // the sketch bar's phone frame on a computer must give the phone stack, with the five short tabs
  await page.click('#bar [data-b="shortboard"]'); await page.click('.tabs [data-page="viewer"]'); await page.click('#bar [data-f="1"]'); await page.waitForTimeout(200);
  const framed = await page.evaluate(() => ({ topbar: getComputedStyle(document.querySelector(".topbar")).display, w: document.getElementById("app").getBoundingClientRect().width,
    tabs: [...document.querySelectorAll(".tabs .tab")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.innerText.trim()), vb: document.getElementById("side").getAttribute("viewBox") }));
  console.log("phone frame on a computer:", JSON.stringify(framed));
  if (framed.topbar !== "flex" || framed.w !== 390) problems.push("the phone frame does not give the phone stack");
  if (framed.tabs.join("|") !== "VIEWER|TOP|PLANING|DATA|GUIDE") problems.push("the phone frame should show VIEWER · TOP · PLANING · DATA · GUIDE: " + framed.tabs.join("|"));
  if (!/^0 0 \d+ 1000$/.test(framed.vb)) problems.push("in the phone frame the board stands nose up (viewBox 1000 tall): " + framed.vb);
  await page.screenshot({ path: path.join(out, "desktop-phone-frame.png") });
  await page.click('#bar [data-f="0"]');
  await page.close();

  // ---- an upright phone: 390 x 844 (iPhone 14), touch ----
  page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push("phone: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("phone console: " + m.text()); });
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#side path.board").length > 0);
  const ph = await page.evaluate(() => {
    const main = document.querySelector(".main").getBoundingClientRect();
    const side = document.querySelector(".side").getBoundingClientRect();
    const bar = document.querySelector(".topbar").getBoundingClientRect();
    const strip = document.querySelector(".strip").getBoundingClientRect();
    const tabs = [...document.querySelectorAll(".tabs .tab")].filter((e) => getComputedStyle(e).display !== "none");
    return { topbar: [bar.height, getComputedStyle(document.querySelector(".topbar")).display], main: [main.y, main.height], side: [side.y, side.height], stripH: strip.height, stripW: strip.width,
      tabs: tabs.map((e) => e.innerText.trim()), tabsRight: Math.max(...tabs.map((e) => e.getBoundingClientRect().right)), docScroll: document.documentElement.scrollHeight, inner: window.innerHeight,
      vb: document.getElementById("side").getAttribute("viewBox"), svg: [document.getElementById("side").getBoundingClientRect().width, document.getElementById("side").getBoundingClientRect().height], bar: document.getElementById("bar").getBoundingClientRect().height };
  });
  console.log("phone", JSON.stringify(ph));
  if (ph.topbar[1] !== "flex" || ph.main[0] > ph.side[0]) problems.push("phone did not get the phone layout (width alone)");
  if (ph.tabs.join("|") !== "VIEWER|TOP|PLANING|DATA|GUIDE") problems.push("a phone's tabs should be VIEWER · TOP · PLANING · DATA · GUIDE: " + ph.tabs.join("|"));
  if (ph.stripH > 40 || ph.tabsRight > 390) problems.push("the five tabs wrapped or ran off the phone: " + JSON.stringify([ph.stripH, ph.tabsRight]));
  if (ph.docScroll > ph.inner + 2) problems.push("the phone page scrolls as a whole (" + ph.docScroll + " > " + ph.inner + ")");
  if (!/^0 0 \d+ 1000$/.test(ph.vb)) problems.push("an upright phone stands the board nose up: " + ph.vb);
  if (ph.bar > 60) problems.push("the sketch bar is too tall on a phone: " + ph.bar);
  await page.screenshot({ path: path.join(out, "phone-viewer.png") });
  await page.tap('.tabs [data-page="top"]'); await page.waitForTimeout(200);
  const top = await page.evaluate(() => ({ shown: getComputedStyle(document.getElementById("topPanel")).display !== "none", blank: document.querySelectorAll("#topv .blankfoam").length, board: document.querySelectorAll("#topv path.board").length }));
  if (!top.shown || top.blank < 1 || top.board < 1) problems.push("TOP on a phone should draw the blank from above with the board on it: " + JSON.stringify(top));
  await page.screenshot({ path: path.join(out, "phone-top.png") });
  // GUIDE on a phone: one card across, scrolling inside the pinned panel, the page itself still not scrolling
  await page.tap('.tabs [data-page="guide"]'); await page.waitForTimeout(300);
  const phGuide = await page.evaluate(() => { const p = document.getElementById("guidePanel"); const cards = [...document.querySelectorAll("#guidePanel .card")];
    return { n: cards.length, cols: new Set(cards.slice(0, 6).map((c) => Math.round(c.getBoundingClientRect().x))).size, scrolls: p.scrollHeight > p.clientHeight, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight, cardW: cards[0].getBoundingClientRect().width,
      overflow: cards.filter((c) => c.scrollWidth > c.clientWidth + 1).length }; });
  console.log("phone guide:", JSON.stringify(phGuide));
  if (phGuide.n !== CARDS || phGuide.cols !== 1 || !phGuide.scrolls) problems.push("GUIDE on a phone should be one card across, scrolling: " + JSON.stringify(phGuide));
  if (phGuide.docScroll > phGuide.inner + 2) problems.push("GUIDE makes the phone page scroll as a whole");
  if (phGuide.overflow) problems.push("a card's content runs wider than the card on a phone: " + phGuide.overflow);
  await page.screenshot({ path: path.join(out, "phone-guide.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 1400; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "phone-guide-blank.png") });
  await page.click('#bar [data-t="slate"]'); await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(200);
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 3200; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "phone-guide-foil-slate-metric.png") });
  await page.click('#bar [data-t="daylight"]'); await page.click('#bar [data-u="imperial"]'); await page.tap('.tabs [data-page="datasheet"]'); await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(out, "phone-data.png") });
  // a phone turned sideways (844 x 390): the desktop shell by width, the board lying flat, GUIDE still scrolling inside its folder
  await page.setViewportSize({ width: 844, height: 390 }); await page.waitForTimeout(250);
  await page.tap('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
  const side = await page.evaluate(() => ({ phone: getComputedStyle(document.querySelector(".topbar")).display === "flex", tabs: [...document.querySelectorAll(".tabs .tab")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.page), docScroll: document.documentElement.scrollHeight, inner: window.innerHeight,
    cols: new Set([...document.querySelectorAll("#guidePanel .cards")[1].querySelectorAll(".card")].map((c) => Math.round(c.getBoundingClientRect().x))).size }));
  console.log("phone sideways:", JSON.stringify(side));
  if (side.phone || side.tabs.join() !== "viewer,planing,datasheet,guide") problems.push("a phone held sideways is wider than 820 and gets the desktop shell and tabs: " + JSON.stringify(side));
  if (side.docScroll > side.inner + 2) problems.push("sideways, the page scrolls as a whole");
  await page.screenshot({ path: path.join(out, "phone-sideways-guide.png") });
  await page.close();

  await browser.close();
  console.log("\nERRORS:", errors.length ? errors.join("\n") : "none");
  console.log("PROBLEMS:", problems.length ? problems.join("\n") : "none");
  process.exit(problems.length || errors.length ? 1 : 0);
})();

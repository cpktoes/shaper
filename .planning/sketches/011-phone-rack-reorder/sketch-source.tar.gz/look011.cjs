// Scratch only: one look at the published copy on an iPhone-sized touch screen, light and dark.
const { chromium, devices } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
(async () => {
  const browser = await chromium.launch();
  for (const scheme of ["light", "dark"]) {
    const ctx = await browser.newContext({ ...devices["iPhone 13"], colorScheme: scheme });
    const page = await ctx.newPage();
    const errors = []; page.on("pageerror", (e) => errors.push(String(e))); page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
    await page.goto("file://" + __dirname + "/publish/preview.html"); await page.waitForTimeout(900);
    const info = await page.evaluate(() => ({ onPhone: document.body.classList.contains("on-phone"), w: innerWidth, h: innerHeight, bg: getComputedStyle(document.querySelector(".screen")).backgroundColor, hScroll: document.documentElement.scrollWidth > innerWidth, middle: rack.list[rack.middle()].name }));
    await page.screenshot({ path: __dirname + `/shots/publish-${scheme}.png` });
    console.log(scheme, JSON.stringify(info), "errors", JSON.stringify(errors));
    await ctx.close();
  }
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

# Scratch only: turns sketch 011's page into the published copy (a page body for the artifact viewer).
import re, sys
src = open("/Users/kontoes/Code/shaper/.planning/sketches/011-phone-rack-reorder/index.html").read()
s = src
# The viewer supplies the document skeleton, charset and viewport: keep only the page's own content.
s = s.replace('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n', "")
s = s.replace("<title>Sketch 011 — Moving boards on a phone</title>", "<title>Board Rack Reorder</title>")
s = s.replace('<link id="theme-link" rel="stylesheet" href="../themes/app-slate.css">\n', "")
s = s.replace("</head>\n<body>\n", "").replace("</body>\n</html>\n", "")
assert "<head>" not in s and "<body>" not in s and "<html" not in s, "skeleton tags left"
slate = {"--color-bg": "#12141a", "--color-surface": "#12141a", "--color-canvas": "#1a1d25", "--color-well": "#1b1f26", "--color-tab-active": "#12141a", "--color-border": "#333842", "--color-line": "#6a707c", "--color-text": "#f2f4f7", "--color-text-muted": "#a1a8b4", "--color-primary": "#18526d", "--color-on-primary": "#f2f4f7", "--color-accent-ink": "#3490bc", "--color-board": "#1a2732", "--color-warning-ink": "#ff9670", "--color-page": "#0b0c10", "--shadow-lg": "0 10px 24px rgba(0,0,0,0.45)"}
day = {"--color-bg": "#ffffff", "--color-surface": "#ffffff", "--color-canvas": "#dfdcd3", "--color-well": "#dfdcd3", "--color-tab-active": "#ffffff", "--color-border": "#897c58", "--color-line": "#897c58", "--color-text": "#1f2a3b", "--color-text-muted": "#566171", "--color-primary": "#8ec1b8", "--color-on-primary": "#1f2a3b", "--color-accent-ink": "#48605c", "--color-board": "#d9f2ed", "--color-warning-ink": "#ac3811", "--color-page": "#c9c5ba", "--shadow-lg": "0 10px 24px rgba(0,0,0,0.18)"}
decl = lambda d: " ".join(f"{k}: {v};" for k, v in d.items())
tokens = f"""  /* The app's own palettes: Daylight when the phone is light, Slate when it's dark. */
  :root {{ {decl(day)} --font-sans: "Inter", Roboto, system-ui, sans-serif; --tracking-architectural: 0.15em; }}
  @media (prefers-color-scheme: dark) {{ :root:not([data-theme="light"]) {{ {decl(slate)} color-scheme: dark; }} }}
  :root[data-theme="dark"] {{ {decl(slate)} color-scheme: dark; }}
"""
s = s.replace("<style>\n", "<style>\n" + tokens, 1)
# The sticky tab strip and the floating tools clear the phone's notch and home bar.
s = s.replace("#variant-nav { position: sticky; top: 0;", "#variant-nav { position: sticky; top: env(safe-area-inset-top, 0px);", 1)
s = s.replace("#sketch-tools { position: fixed; bottom: 12px;", "#sketch-tools { position: fixed; bottom: calc(12px + env(safe-area-inset-bottom, 0px));", 1)
s = s.replace("body.on-phone #variant-nav { padding: 6px 8px;", "body.on-phone #variant-nav { padding: 6px 16px;", 1)
# The page's height on a phone leaves room for the viewer's safe-area padding.
old = 'const Hs = onPhone ? window.innerHeight - document.getElementById("variant-nav").offsetHeight : ph.h;'
assert old in s
s = s.replace(old, 'const rootCs = getComputedStyle(document.documentElement), padY = (parseFloat(rootCs.paddingTop) || 0) + (parseFloat(rootCs.paddingBottom) || 0);\n  const Hs = onPhone ? window.innerHeight - padY - document.getElementById("variant-nav").offsetHeight : ph.h;')
# Theme: follow the phone by default; Dark and Light stay in the sketch tools.
s = s.replace('const DEFAULTS = { variant: "a", count: 15, units: "imperial", theme: "slate",', 'const DEFAULTS = { variant: "a", count: 15, units: "imperial", theme: "auto",', 1)
old = """function applyTheme() {
  const root = document.documentElement.style;
  for (const [k, v] of Object.entries({ ...COMMON_VARS, ...PALETTES[state.theme] })) root.setProperty(k, v);"""
assert old in s
s = s.replace(old, """function applyTheme() {
  const root = document.documentElement.style;
  if (!PALETTES[state.theme]) { for (const k of Object.keys(PALETTES.slate)) root.removeProperty(k); root.removeProperty("color-scheme"); return; }
  for (const [k, v] of Object.entries({ ...COMMON_VARS, ...PALETTES[state.theme] })) root.setProperty(k, v);
  root.setProperty("color-scheme", state.theme === "slate" ? "dark" : "light");""")
old = """mk("t-theme", "theme", [["slate", "Dark (slate)"], ["daylight", "Light (daylight)"]]);"""
assert old in s
s = s.replace(old, """mk("t-theme", "theme", [["auto", "Follow my phone"], ["slate", "Dark (slate)"], ["daylight", "Light (daylight)"]]);""")
s = s.replace('try { Object.assign(state, JSON.parse(localStorage.getItem("sketch011") || "{}")); } catch (e) {}', 'try { Object.assign(state, JSON.parse(localStorage.getItem("board-rack-reorder") || "{}")); } catch (e) {}')
s = s.replace('function save() { try { localStorage.setItem("sketch011", JSON.stringify(state)); } catch (e) {} }', 'function save() { try { localStorage.setItem("board-rack-reorder", JSON.stringify(state)); } catch (e) {} }')
open(sys.argv[1], "w").write(s)
# A local preview wraps it the way the viewer does.
open(sys.argv[2], "w").write('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><style>:root{color-scheme:light;padding-block:env(safe-area-inset-top,0) env(safe-area-inset-bottom,0)}body{margin:0;font:14px system-ui;background:#fafaf8}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' + s + "</body></html>")
print(len(s), "bytes; title:", re.search(r"<title>(.*?)</title>", s).group(1))

// Scratch only: drives sketch 011 with a mouse in headless Chromium — hold and drag, Arrange, Move buttons.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const OUT = __dirname + "/shots/";
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = []; page.on("pageerror", (e) => errors.push(String(e))); page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  await page.goto("file:///Users/kontoes/Code/shaper/.planning/sketches/011-phone-rack-reorder/index.html");
  await page.waitForTimeout(700);
  const set = async (o) => { await page.evaluate((o) => { Object.assign(state, o); renderAll(); }, o); await page.waitForTimeout(500); };
  const at = (name) => page.evaluate((name) => { const b = rack.list.findIndex((x) => x.name === name); const rc = rack.sc.getBoundingClientRect(); return { x: rc.left + (rack.lastX[b] - rack.sc.scrollLeft) * phoneScale, y: rc.top + (rack.floorY - 90) * phoneScale, gy: rc.top + (rack.floorY + rack.floorPad + 17) * phoneScale, b }; }, name);
  const order = () => page.evaluate(() => rack.order.map((b) => rack.list[b].name).slice(0, 7).join(" | "));
  const mid = () => page.evaluate(() => rack.list[rack.middle()].name);
  const toastText = () => page.evaluate(() => document.getElementById("toast").textContent);
  console.log("scale", await page.evaluate(() => phoneScale));
  // A: quick drag scrolls the rack; holding lifts a board.
  await page.screenshot({ path: OUT + "011-a-rest.png" });
  let s = await at("Untitled Board");
  await page.mouse.move(s.x + 150, s.y); await page.mouse.down(); await page.mouse.move(s.x + 30, s.y, { steps: 6 }); await page.mouse.up(); await page.waitForTimeout(700);
  console.log("A swipe -> middle:", await mid(), "| order:", await order());
  const egg = await at("Egg");
  await page.mouse.move(egg.x, egg.y); await page.mouse.down(); await page.waitForTimeout(520);
  console.log("A after hold, dragging:", await page.evaluate(() => !!rack.drag));
  await page.mouse.move(egg.x - 30, egg.y, { steps: 5 }); await page.mouse.move(egg.x - 82, egg.y, { steps: 8 }); await page.waitForTimeout(250);
  await page.screenshot({ path: OUT + "011-a-carrying.png" });
  console.log("A carrying, slot:", await page.evaluate(() => rack.drag && rack.drag.slot), "| caption:", await page.evaluate(() => document.getElementById("cap").innerText.slice(0, 40)));
  await page.mouse.up(); await page.waitForTimeout(900);
  console.log("A dropped:", await order(), "| middle:", await mid(), "|", await toastText());
  await page.screenshot({ path: OUT + "011-a-dropped.png" });
  // A: carry toward the right edge — the rack should scroll along.
  const keel = await at("Keel Twin");
  await page.mouse.move(keel.x, keel.y); await page.mouse.down(); await page.waitForTimeout(520);
  const edgeX = await page.evaluate(() => { const rc = rack.sc.getBoundingClientRect(); return rc.left + (rack.W - 12) * phoneScale; });
  const sl0 = await page.evaluate(() => rack.sc.scrollLeft);
  await page.mouse.move(edgeX, keel.y, { steps: 10 }); await page.waitForTimeout(900);
  const sl1 = await page.evaluate(() => rack.sc.scrollLeft);
  console.log("A edge auto-scroll:", Math.round(sl0), "->", Math.round(sl1), "slot", await page.evaluate(() => rack.drag && rack.drag.slot));
  await page.mouse.up(); await page.waitForTimeout(900);
  console.log("A after edge drop:", await page.evaluate(() => rack.order.map((b) => rack.list[b].name).join(" | ")));
  // A: the unsaved board can't be lifted.
  await page.evaluate(() => rack.goTo(0, false)); await page.waitForTimeout(400);
  const un = await at("Untitled Board");
  await page.mouse.move(un.x, un.y); await page.mouse.down(); await page.waitForTimeout(520); await page.mouse.up(); await page.waitForTimeout(150);
  console.log("A unsaved:", await toastText());

  // B: Arrange, drag a grip, Done.
  await set({ variant: "b" });
  await page.click("#arrange"); await page.waitForTimeout(500);
  await page.screenshot({ path: OUT + "011-b-arranging.png" });
  const step = await at("Step-Up");
  await page.mouse.move(step.x, step.gy); await page.mouse.down(); await page.mouse.move(step.x - 60, step.gy, { steps: 8 }); await page.waitForTimeout(250);
  await page.screenshot({ path: OUT + "011-b-carrying.png" });
  await page.mouse.up(); await page.waitForTimeout(900);
  console.log("B grip drop:", await order(), "| arranging:", await page.evaluate(() => rack.arranging));
  await page.click("#arrange"); await page.waitForTimeout(700);
  console.log("B done -> arranging:", await page.evaluate(() => rack.arranging), "| button:", await page.textContent("#arrange"));

  // C: Move buttons.
  await set({ variant: "c" });
  await page.evaluate(() => rack.goTo(5, false)); await page.waitForTimeout(500);
  console.log("C middle:", await mid(), "| order:", await order());
  await page.screenshot({ path: OUT + "011-c-rest.png" });
  await page.click('[data-move="-1"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: OUT + "011-c-moving.png" });
  await page.waitForTimeout(600);
  await page.click('[data-move="-1"]'); await page.waitForTimeout(700);
  console.log("C after two left:", await order(), "| middle:", await mid());
  await page.screenshot({ path: OUT + "011-c-moved.png" });
  console.log("errors", JSON.stringify(errors));
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

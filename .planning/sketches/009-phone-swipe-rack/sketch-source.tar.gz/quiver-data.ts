/* Scratch only (sketch 009/010): runs the app's own board maths over a realistic quiver and writes
   each board's side profile, outline and card line as JSON for the sketch to draw. Never committed. */
import { writeFileSync } from "node:fs";
import { isPickable } from "@/lib/blanks/catalog";
import { readSeedCatalog } from "@/lib/blanks/seed-files";
import { provisionalPresetPick } from "@/lib/blanks/preset-blanks";
import { DEFAULT_BLANK_CUT, type BoardBlank } from "@/lib/geometry/blank";
import { prepareBlank, thinningStartsOf } from "@/lib/geometry/blank-fit";
import { buildBoardProfile } from "@/lib/geometry/board-profile";
import { summarizeDesign } from "@/lib/geometry/design";
import { DEFAULT_FOIL_SPEC } from "@/lib/geometry/foil";
import { buildOutline, sampleOutline } from "@/lib/geometry/outline";
import { BOARD_PRESETS, type BoardPreset } from "@/lib/geometry/presets";
import { DEFAULT_FALLBACK_ROCKER } from "@/lib/geometry/rocker";
import { formatSummaryLine, presetSummary } from "@/lib/geometry/summary-line";
import { formatFeetInches, inchesToMm, mm, type Mm } from "@/lib/geometry/units";
import { DEFAULT_VOLUME_SPEC } from "@/lib/geometry/volume";

const catalogue = readSeedCatalog();
const prepared = catalogue.filter(isPickable).map(prepareBlank);
const byId = Object.fromEntries(BOARD_PRESETS.map((p) => [p.id, p])) as Record<BoardPreset["id"], BoardPreset>;

type Tail = BoardPreset["outline"]["tail"];
interface Spec {
  name: string;
  base: BoardPreset["id"];
  lengthIn: number;
  widthIn: number;
  centerIn: number;
  offsetIn?: number;
  tail?: Tail;
  touched: string; // ISO date
  inProgress?: boolean;
  keepPresetBlank?: boolean;
}

const sq = (w: number): Tail => ({ kind: "squash", endWidth: inchesToMm(w) });
const sw = (w: number, d: number): Tail => ({ kind: "swallow", endWidth: inchesToMm(w), crotchDepth: inchesToMm(d) });
const round: Tail = { kind: "round" };
const pin: Tail = { kind: "pin" };

const named: Spec[] = [
  { name: "Untitled Board", base: "shortboard", lengthIn: 74, widthIn: 18.75, centerIn: 2.25, touched: "2026-10-05", inProgress: true, keepPresetBlank: true },
  { name: "Daily Driver", base: "shortboard", lengthIn: 72, widthIn: 18.5, centerIn: 2.1875, tail: sq(4), touched: "2026-10-04" },
  { name: "Keel Twin", base: "fish", lengthIn: 66, widthIn: 20.75, centerIn: 2.5, tail: sw(10, 2.75), touched: "2026-09-30" },
  { name: "Step-Up", base: "shortboard", lengthIn: 78, widthIn: 18.625, centerIn: 2.375, tail: pin, touched: "2026-09-28" },
  { name: "Egg", base: "midlength", lengthIn: 84, widthIn: 21.5, centerIn: 2.75, tail: round, touched: "2026-09-25" },
  { name: "Groveler", base: "shortboard", lengthIn: 66, widthIn: 20, centerIn: 2.375, offsetIn: 1, tail: sq(5), touched: "2026-09-21" },
  { name: "Log", base: "longboard", lengthIn: 112, widthIn: 23, centerIn: 3, tail: sq(8.5), touched: "2026-09-18" },
  { name: "Hybrid", base: "shortboard", lengthIn: 70, widthIn: 19.5, centerIn: 2.375, tail: round, touched: "2026-09-12" },
  { name: "Noserider", base: "longboard", lengthIn: 110, widthIn: 23, centerIn: 2.875, tail: sq(9), touched: "2026-09-08" },
  { name: "Single Fin Mid", base: "midlength", lengthIn: 90, widthIn: 21, centerIn: 2.75, tail: round, touched: "2026-09-03" },
  { name: "Big Fish", base: "fish", lengthIn: 72, widthIn: 21, centerIn: 2.625, tail: sw(10.5, 2.75), touched: "2026-08-30" },
  { name: "Funboard", base: "midlength", lengthIn: 96, widthIn: 22, centerIn: 2.875, tail: round, touched: "2026-08-27" },
  { name: "Gun", base: "shortboard", lengthIn: 90, widthIn: 19.25, centerIn: 2.75, offsetIn: 2, tail: pin, touched: "2026-08-24" },
  { name: "Performance Log", base: "longboard", lengthIn: 108, widthIn: 22.25, centerIn: 2.75, tail: sq(8), touched: "2026-08-20" },
  { name: "Mini Simmons", base: "fish", lengthIn: 62, widthIn: 21.5, centerIn: 2.5, tail: sq(12), touched: "2026-08-16" },
];

// A pro shaper's customer boards, for the 30-board rack: small, deterministic variations.
const customers = ["Jake", "Maria", "Kai", "Lena", "Tomás", "Priya", "Ben", "Sofia", "Hiro", "Ava", "Noah", "Ines", "Leo", "Mia", "Sam"];
const kinds: Array<Pick<Spec, "base" | "lengthIn" | "widthIn" | "centerIn" | "tail"> & { label: string }> = [
  { label: "Daily", base: "shortboard", lengthIn: 71, widthIn: 18.75, centerIn: 2.25, tail: sq(4) },
  { label: "Fish", base: "fish", lengthIn: 67, widthIn: 20.5, centerIn: 2.5, tail: sw(10, 2.75) },
  { label: "Mid", base: "midlength", lengthIn: 88, widthIn: 21.25, centerIn: 2.75, tail: round },
  { label: "Log", base: "longboard", lengthIn: 111, widthIn: 22.75, centerIn: 3, tail: sq(8.5) },
  { label: "Step-Up", base: "shortboard", lengthIn: 77, widthIn: 18.5, centerIn: 2.375, tail: pin },
];
const extra: Spec[] = customers.map((who, i) => {
  const k = kinds[i % kinds.length];
  const dl = [-2, 1, -1, 2, 0, 1, -1][i % 7];
  const dw = [0.25, -0.25, 0.5, 0, -0.125, 0.375][i % 6];
  const d = new Date(Date.UTC(2026, 7, 14 - i * 3));
  return {
    name: `${who}'s ${k.label}`,
    base: k.base,
    lengthIn: k.lengthIn + dl,
    widthIn: k.widthIn + dw,
    centerIn: k.centerIn,
    tail: k.tail,
    touched: d.toISOString().slice(0, 10),
  };
});

const N = 64;
const out = [] as unknown[];
for (const spec of [...named, ...extra]) {
  const base = byId[spec.base];
  const outline = {
    ...base.outline,
    length: inchesToMm(spec.lengthIn),
    widePointWidth: inchesToMm(spec.widthIn),
    ...(spec.offsetIn === undefined ? {} : { widePointOffset: inchesToMm(spec.offsetIn) }),
    ...(spec.tail ? { tail: spec.tail } : {}),
  };
  const foilTips = { noseTip: base.foil.noseTip, center: inchesToMm(spec.centerIn), tailTip: base.foil.tailTip };
  const asPreset: BoardPreset = { ...base, outline, foil: foilTips, blank: undefined };
  let pickVendor: string, pickName: string, placement: Mm;
  if (spec.keepPresetBlank && base.blank) {
    pickVendor = base.blank.vendor; pickName = base.blank.name; placement = base.blank.placement;
  } else {
    const pick = provisionalPresetPick(asPreset, prepared);
    pickVendor = pick.vendor; pickName = pick.name; placement = pick.placementMm;
  }
  const record = catalogue.find((b) => b.vendor === pickVendor && b.name === pickName)!;
  const blank: BoardBlank = { copy: record, placement, nose12Offset: mm(0), tail12Offset: mm(0), ...DEFAULT_BLANK_CUT };
  const foil = { ...DEFAULT_FOIL_SPEC, ...foilTips };
  const fields = { outline, rocker: DEFAULT_FALLBACK_ROCKER, foil, rails: base.rails, blank, railsImportFoilThickness: true, volume: DEFAULT_VOLUME_SPEC };
  const summary = summarizeDesign(fields);
  const profile = buildBoardProfile({
    length: outline.length,
    rocker: DEFAULT_FALLBACK_ROCKER,
    foil,
    blank: {
      prepared: prepareBlank(record),
      placement,
      nose12Offset: mm(0),
      tail12Offset: mm(0),
      deckSkin: blank.deckSkin,
      tipStyle: blank.tipStyle,
      fineTuneSurface: blank.fineTuneSurface,
      ...thinningStartsOf(blank),
    },
    handSetCurve: "root",
  });
  const geometry = buildOutline(outline);
  const L = outline.length as number;
  const stations: number[] = [], rocker: number[] = [], deck: number[] = [], half: number[] = [];
  for (let i = 0; i <= N; i++) {
    const s = mm((L * i) / N);
    stations.push(+(s as number).toFixed(2));
    rocker.push(+(profile.rockerAt(s) as number).toFixed(2));
    deck.push(+(profile.deckAt(s) as number).toFixed(2));
    half.push(+(sampleOutline(geometry, s) as number).toFixed(2));
  }
  // The exact TEMPLATE silhouette (right half tail->nose), decimated, plus where the tail closes.
  const pts = geometry.points;
  const step = Math.max(1, Math.floor(pts.length / 90));
  const outlinePts: [number, number][] = [];
  for (let i = 0; i < pts.length; i += step) outlinePts.push([+pts[i].station.toFixed(1), +pts[i].halfWidth.toFixed(1)]);
  const last = pts[pts.length - 1];
  if (outlinePts[outlinePts.length - 1][0] !== +last.station.toFixed(1)) outlinePts.push([+last.station.toFixed(1), +last.halfWidth.toFixed(1)]);
  out.push({
    name: spec.name,
    inProgress: !!spec.inProgress,
    touched: spec.touched,
    blank: `${pickVendor} ${pickName}`,
    tail: outline.tail.kind,
    lengthMm: +L.toFixed(1),
    lengthLabel: formatFeetInches(outline.length),
    lineImperial: formatSummaryLine(summary, "imperial"),
    lineMetric: formatSummaryLine(summary, "metric"),
    litres: +(summary.volumeLitres as number).toFixed(2),
    stations, rocker, deck, half,
    outline: outlinePts,
    closeStation: +(geometry.centreCloseStation as number).toFixed(1),
  });
  console.log(`${spec.name.padEnd(18)} ${formatSummaryLine(summary, "imperial").padEnd(36)} ${pickVendor} ${pickName}  pts=${pts.length}`);
}
const presets = BOARD_PRESETS.map((p) => {
  const g = buildOutline(p.outline);
  const summary = presetSummary(p);
  const pts = g.points;
  const step = Math.max(1, Math.floor(pts.length / 90));
  const outlinePts: [number, number][] = [];
  for (let i = 0; i < pts.length; i += step) outlinePts.push([+pts[i].station.toFixed(1), +pts[i].halfWidth.toFixed(1)]);
  const last = pts[pts.length - 1];
  if (outlinePts[outlinePts.length - 1][0] !== +last.station.toFixed(1)) outlinePts.push([+last.station.toFixed(1), +last.halfWidth.toFixed(1)]);
  return { name: p.name, descriptor: p.descriptor, lengthMm: +(p.outline.length as number).toFixed(1), lineImperial: formatSummaryLine(summary, "imperial"), lineMetric: formatSummaryLine(summary, "metric"), outline: outlinePts, closeStation: +(g.centreCloseStation as number).toFixed(1) };
});
writeFileSync(process.argv[2], JSON.stringify({ boards: out, presets }));

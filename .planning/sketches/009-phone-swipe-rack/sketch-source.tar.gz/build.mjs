// Scratch only: injects the quiver data into a sketch template and writes the self-contained page.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
const [tpl, out] = process.argv.slice(2);
const data = JSON.parse(readFileSync(new URL("./quiver.json", import.meta.url)));
const r1 = (v) => Math.round(v * 10) / 10;
for (const b of [...data.boards]) {
  for (const k of ["stations", "rocker", "deck", "half"]) b[k] = b[k].map(r1);
}
const json = JSON.stringify(data);
const html = readFileSync(tpl, "utf8").replace("/*__DATA__*/null", json);
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, html);
console.log(`${out}: ${(html.length / 1024).toFixed(0)} KB`);

// a close picture of the ruler under the section, on a computer. Run: node ruler-shot.cjs <index.html> <out.png>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  await page.goto("file://" + path.resolve(process.argv[2])); await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  await page.selectOption("select[data-count]", "6"); await page.waitForTimeout(150);
  await page.evaluate(() => { const s = window.sketch; s.state.station = 8 * 25.4; s.state.live = "channels"; s.state.active = "tail"; s.render(false); }); await page.waitForTimeout(200);
  const box = await (await page.$(".view.sec")).boundingBox();
  await page.screenshot({ path: process.argv[3], clip: { x: box.x - 4, y: box.y - 4, width: box.width + 8, height: box.height + 8 } });
  await browser.close(); console.log("done");
})();

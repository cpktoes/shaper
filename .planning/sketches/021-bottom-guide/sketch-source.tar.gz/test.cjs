// Headless checks of sketch 021 at a computer's width and an upright phone's, with pictures.
// Run: node test.cjs <path-to-index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const fs = require("node:fs");

const file = process.argv[2];
const out = process.argv[3];
fs.mkdirSync(out, { recursive: true });
const url = "file://" + path.resolve(file);

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  const errors = [];

  // ---- a computer: 1280 x 800 ----
  let page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("pageerror", (e) => errors.push("desktop: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("desktop console: " + m.text()); });
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const desk = await page.evaluate(() => {
    const app = document.getElementById("app");
    const side = document.querySelector(".side").getBoundingClientRect();
    const sec = document.getElementById("sec").getBoundingClientRect();
    return { phone: app.classList.contains("phone"), side: [side.x, side.width, side.height], sec: [sec.width, sec.height],
      rects: document.querySelectorAll("#top .shade rect").length, isos: document.querySelectorAll("#top .iso").length, foot: document.querySelectorAll("#foot, .foot").length, sections: document.querySelectorAll(".sidesec").length,
      shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, secrow: document.querySelectorAll("#secrow .tab").length,
      ruler: document.querySelectorAll("#sec .ruler").length, rulerWords: document.getElementById("sec").textContent.includes("Off the stringer"), litresOff: window.sketch.litresOff(),
      variantBtns: document.querySelectorAll("#bar [data-v], #bar [data-w]").length, tabs: [...document.querySelectorAll(".tabs .tab")].map((e) => e.dataset.page),
      tailHasChannels: !!document.querySelector('.sidesec[data-sec="tail"] [data-cut="channels"]'), count: window.sketch.state.ch.count, countSel: (document.querySelector("select[data-count]") || {}).value,
      runSel: document.querySelectorAll("select[data-run]").length, wingSel: document.querySelectorAll("select[data-wing]").length, wingRow: document.getElementById("wingRow").innerHTML.length };
  });
  console.log("desktop", JSON.stringify(desk));
  if (desk.phone) problems.push("desktop got the phone layout");
  if (desk.side[1] !== 340) problems.push("sidebar is not 340 wide: " + desk.side[1]);
  if (desk.variantBtns !== 0) problems.push("the bar should have no variant or wing-rule buttons left");
  if (desk.tabs.join() !== "viewer,data,guide") problems.push("the tabs should be VIEWER · DATA · GUIDE: " + desk.tabs.join());
  if (desk.shown !== 3 || desk.secrow !== 3 || !desk.tailHasChannels) problems.push("B: three cards with the channels inside TAIL: " + JSON.stringify([desk.shown, desk.secrow, desk.tailHasChannels]));
  if (desk.count !== 0 || desk.countSel !== "0" || desk.runSel !== 0) problems.push("every board should open with no channels (and no Run menu until there are some): " + JSON.stringify([desk.count, desk.countSel, desk.runSel]));
  if (desk.wingSel !== 0 || desk.wingRow !== 0) problems.push("a wingless board should show no wing-rule selector");
  if (desk.foot !== 0) problems.push("the three readouts should be gone from the viewer");
  if (desk.rects < 100) problems.push("no shade drawn");
  if (desk.isos < 3) problems.push("too few contour lines for 1/16\" steps on the opening single concave: " + desk.isos);
  if (desk.ruler < 3) problems.push("the layout-marks ruler is missing on a computer");
  await page.screenshot({ path: path.join(out, "desktop-daylight.png") });

  // every board opens with none; picking a count gives that count's starting width, Parallel, the inner pair longest
  for (const b of ["fish", "midlength", "longboard", "fishwing", "shortboard"]) { await page.click(`#bar [data-b="${b}"]`); await page.waitForTimeout(80);
    const n = await page.evaluate(() => window.sketch.state.ch.count); if (n !== 0) problems.push(b + " opens with channels: " + n); }
  await page.selectOption("select[data-count]", "4"); await page.waitForTimeout(80);
  const four = await page.evaluate(() => { const c = window.sketch.state.ch; return { w: c.width / 25.4, run: c.run, longer: c.longer, runSel: document.querySelector("select[data-run]").value, runText: document.querySelector("select[data-run] option:checked").textContent }; });
  await page.selectOption("select[data-count]", "8"); await page.waitForTimeout(80);
  const eight = await page.evaluate(() => window.sketch.state.ch.width / 25.4);
  await page.selectOption("select[data-count]", "6"); await page.waitForTimeout(80);
  const six = await page.evaluate(() => ({ w: window.sketch.state.ch.width / 25.4, longerSel: document.querySelectorAll("select[data-longer]").length, staggerRow: document.querySelectorAll('[data-row="stagger"]').length,
    staggerLbl: (document.querySelector('[data-row="stagger"] [data-lbl]') || {}).textContent, note: (document.querySelector('.sidesec[data-sec="tail"] .flatnote') || {}).textContent }));
  console.log("counts:", JSON.stringify({ four, eight, six }));
  if (!(four.w === 2.5 && eight === 1.25 && six.w === 1.75)) problems.push("the starting width should follow the count (2 1/2 · 1 3/4 · 1 1/4): " + JSON.stringify([four.w, six.w, eight]));
  if (four.run !== "parallel" || four.runSel !== "parallel" || four.runText !== "Parallel") problems.push("the run should open Parallel to the stringer: " + JSON.stringify(four));
  if (four.longer !== "inner") problems.push("the inner pair should run longest to start");
  if (six.longerSel !== 1 || six.staggerRow !== 1) problems.push("the channels block should have a Longest choice and a Stagger slider: " + JSON.stringify([six.longerSel, six.staggerRow]));
  if (!/Stagger — 2" per channel · the outer pair starts \d/.test(six.staggerLbl || "")) problems.push("the Stagger label should read 2 in per channel and where the outer pair starts: " + six.staggerLbl);
  if (!/but the channels/.test(six.note || "")) problems.push("a flat tail with channels should say so: " + six.note);
  await page.selectOption("select[data-longer]", "same"); await page.waitForTimeout(60);
  const sameRows = await page.evaluate(() => document.querySelectorAll('[data-row="stagger"]').length);
  await page.selectOption("select[data-longer]", "inner"); await page.waitForTimeout(60);
  const innerRows = await page.evaluate(() => document.querySelectorAll('[data-row="stagger"]').length);
  if (sameRows !== 0 || innerRows !== 1) problems.push("the Stagger slider should hide for All the same length and return for a pair: " + JSON.stringify([sameRows, innerRows]));
  await page.evaluate(() => { const c = document.getElementById("controls"); const el = c.querySelector('[data-cut="channels"]'); c.scrollTop = el.offsetTop - 60; const s = window.sketch; s.state.station = 8 * 25.4; s.state.live = "channels"; s.render(false); });
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(out, "desktop-tail-channels.png") });

  // the channel maths, unchanged from 020 (six channels on the Shortboard)
  const check = await page.evaluate(() => {
    const s = window.sketch; const B = s.state; const IN = 25.4;
    const withCh = s.litresOff(); const edges = s.channelEdges(B.ch, B.ch.deep).map(([a, b]) => [a, b].map((v) => +(v / IN).toFixed(2)));
    const marks = s.marksOf("channels", B.ch, B.ch.deep).map((m) => m.col);
    const [a0, b0] = s.channelEdges(B.ch, B.ch.deep)[0]; const atWall = s.foamOff(B.ch.deep, b0 - 0.3), atTop = s.foamOff(B.ch.deep, a0 + 0.3), mid = s.foamOff(B.ch.deep, (a0 + b0) / 2);
    const nextPeak = s.foamOff(B.ch.deep, b0 + 0.3);
    const ahead = B.ch.start - 1 * IN; const [, b1] = s.channelEdges(B.ch, ahead)[1], [, b2] = s.channelEdges(B.ch, ahead)[2];
    const starts = [0, 1, 2].map((j) => +(s.chStart(B.ch, j) / IN).toFixed(2));
    const marksAhead = s.marksOf("channels", B.ch, ahead).map((m) => m.col);
    const chOff = (y) => s.cutOff(B.ch, ahead, y, s.railHalfWidth(ahead));
    const innerAhead = chOff(s.channelEdges(B.ch, ahead)[0][1] - 0.3), outerAhead = chOff(b2 - 0.3), midAhead = chOff(b1 - 0.3);
    B.ch.longer = "outer"; const marksOuter = s.marksOf("channels", B.ch, ahead).map((m) => m.col); const outerFirst = chOff(b2 - 0.3), innerLast = chOff(s.channelEdges(B.ch, ahead)[0][1] - 0.3);
    B.ch.longer = "same"; const marksSame = s.marksOf("channels", B.ch, ahead).map((m) => m.col);
    B.ch.longer = "inner"; B.ch.stagger = 20 * IN; const clamped = +(s.chStart(B.ch, 2) / IN).toFixed(2); B.ch.stagger = 2 * IN;
    const fit = s.channelFit(B.ch); const fitIn = { w: fit.w / IN, offRail: fit.offRail / IN, squeezed: fit.squeezed };
    // parallel (the default) rules the walls straight: the same mark six inches ahead and four behind the deepest station
    const parNose = s.channelEdges(B.ch, B.ch.deep + 6 * IN)[0][1], parTail = s.channelEdges(B.ch, B.ch.deep - 4 * IN)[0][1];
    B.ch.run = "toe"; const toeNose = s.channelEdges(B.ch, B.ch.deep + 6 * IN)[0][1], toeTail = s.channelEdges(B.ch, B.ch.deep - 4 * IN)[0][1]; B.ch.run = "parallel";
    B.ch.count = 0; const noCh = s.litresOff();
    const c = B.cuts.center;
    B.cuts.nose = { ...B.cuts.nose, kind: "flat", depth: 0 }; B.cuts.tail = { ...B.cuts.tail, kind: "flat", depth: 0 };
    Object.assign(c, { kind: "single", off: 2 * IN, start: 74 * IN - 16 * IN, deep: (36 + 10.88) / 2 * IN, end: 6 * IN, depth: 3 / 16 * IN, smooth: 50, pointed: false, spiral: false });
    const single = s.litresOff();
    Object.assign(c, { kind: "double", off: 1.5 * IN, offS: 1 * IN, trough: 3 * IN, depth: 1 / 8 * IN, smooth: 50 });
    const atStringer = s.foamOff(c.deep, 0), atHalf = s.foamOff(c.deep, 0.5 * IN), atTrough = s.foamOff(c.deep, 3 * IN);
    return { withCh, noCh, edges, marks, single, atStringer, atHalf, atTrough, atWall, atTop, mid, nextPeak, fitIn, parNose: parNose / IN, parTail: parTail / IN, toeNose: toeNose / IN, toeTail: toeTail / IN,
      starts, marksAhead, innerAhead, midAhead, outerAhead, marksOuter, outerFirst, innerLast, marksSame, clamped, deepIn: B.ch.deep / IN };
  });
  console.log("channels check:", JSON.stringify(check));
  if (!(check.atWall > 5.5 && check.atTop < 1.2 && check.mid > 2 && check.mid < 4.5)) problems.push("the channel is not a ramp deepening out to a wall at the rail side: " + JSON.stringify([check.atTop, check.mid, check.atWall]));
  if (!(check.nextPeak < 1.2)) problems.push("the top of the wall should be the next channel's peak: " + check.nextPeak);
  if (!(check.starts[0] === check.starts[1] + 2 && check.starts[1] === check.starts[2] + 2)) problems.push("the inner pair should run longest with each channel out 2 in shorter: " + JSON.stringify(check.starts));
  if (!(check.marksAhead.length === 1 && check.marksAhead[0] === "Wall 1")) problems.push("an inch behind the longest start only Wall 1 should be ruled: " + check.marksAhead.join(","));
  if (!(check.innerAhead > 0.05 && check.midAhead < 1e-6 && check.outerAhead < 1e-6)) problems.push("ahead of their starts the shorter channels should take nothing: " + JSON.stringify([check.innerAhead, check.midAhead, check.outerAhead]));
  if (!(check.marksOuter.length === 1 && check.marksOuter[0] === "Wall 3" && check.outerFirst > 0.05 && check.innerLast < 1e-6)) problems.push("with the outer pair longest only Wall 3 should be ruled there: " + JSON.stringify([check.marksOuter, check.outerFirst, check.innerLast]));
  if (check.marksSame.length !== 3) problems.push("all the same length should rule every wall there: " + check.marksSame.join(","));
  if (Math.abs(check.clamped - (check.deepIn + 1)) > 0.01) problems.push("a stagger too long should stop an inch ahead of the deepest station: " + check.clamped + " vs " + (check.deepIn + 1));
  if (!(check.fitIn.w === 1.75 && !check.fitIn.squeezed && check.fitIn.offRail > 1 && check.fitIn.offRail < 2)) problems.push("six channels at 1 3/4 should fit the Shortboard with the last wall 1-2 in off the rail: " + JSON.stringify(check.fitIn));
  if (!(Math.abs(check.parNose - 1.75) < 0.01 && Math.abs(check.parTail - 1.75) < 0.01)) problems.push("parallel should rule the first wall straight at 1 3/4: " + JSON.stringify([check.parNose, check.parTail]));
  if (!(check.toeNose < 1.75 - 0.2 && check.toeTail > 1.75 + 0.1)) problems.push("toe-in should move the walls inward toward the nose and outward toward the tail: " + JSON.stringify([check.toeNose, check.toeTail]));
  if (!(check.withCh > check.noCh + 0.1)) problems.push("six channels took no foam: " + check.withCh + " vs " + check.noCh);
  if (check.edges.length !== 3 || check.edges[0][0] !== 0 || check.edges[0][1] !== check.edges[1][0]) problems.push("six channels should be three a side abutting from the stringer: " + JSON.stringify(check.edges));
  if (check.marks.length !== 3 || check.marks[0] !== "Wall 1") problems.push("channel marks should be the three walls: " + check.marks.join(","));
  if (!(check.single > 0.4 && check.single < 0.7)) problems.push("litres off the test single is off: " + check.single);
  if (check.atStringer > 1e-6 || check.atHalf > 1e-6 || check.atTrough < 2) problems.push("a double's Off Stringer flat is not flat: " + JSON.stringify([check.atStringer, check.atHalf, check.atTrough]));

  // the winged Fish: the selector appears, opens on Narrowest, and the two rules differ at the wing's step
  await page.click('#bar [data-b="fishwing"]'); await page.waitForTimeout(120);
  const wing = await page.evaluate(() => {
    const s = window.sketch; const B = s.state; const IN = 25.4;
    const probe = () => { const c = B.cuts.tail; return [s.cutHalfWidth(c, 12 * IN) / IN, s.cutHalfWidth(c, 10 * IN) / IN, c.off / IN]; };
    const selEl = document.querySelector("select[data-wing]");
    B.wingRule = "narrow"; const narrow = probe(); B.wingRule = "natural"; const natural = probe(); B.wingRule = "narrow"; s.render(false);
    return { sel: selEl ? selEl.value : null, options: selEl ? [...selEl.options].map((o) => o.textContent) : [], ruled: (document.querySelector("#wingRow .ruled") || {}).textContent, note: (document.querySelector("#wingRow .flatnote") || {}).textContent,
      narrow, natural, rail10: s.railHalfWidth(10 * IN) / IN, wings: document.getElementById("topCap").textContent, sideSel: document.querySelectorAll("#wingRow select").length };
  });
  console.log("winged fish:", JSON.stringify(wing));
  if (wing.sel !== "narrow" || wing.sideSel !== 1) problems.push("the winged Fish should show the wing-rule selector in the sidebar, on Narrowest: " + JSON.stringify([wing.sel, wing.sideSel]));
  if (!/Wings\s*1\/4" wing at 11 1\/2"/.test(wing.ruled || "")) problems.push("the Wings row should name the wing: " + wing.ruled);
  if (!(Math.abs(wing.narrow[0] - wing.natural[0]) > 0.2)) problems.push("the wing rule makes no difference ahead of the wing");
  if (Math.abs(wing.narrow[1] - (wing.rail10 - wing.narrow[2])) > 0.02) problems.push("the narrowest rule should measure the concave's edge off the real rail behind the wing: " + wing.narrow[1] + " vs " + (wing.rail10 - wing.narrow[2]));
  if (!(wing.natural[1] > wing.narrow[1] + 0.1)) problems.push("the natural rule should sit outside the real rail behind the wing");
  if (!/wing/.test(wing.wings)) problems.push("the winged board's caption does not say so");
  await page.evaluate(() => { const s = window.sketch; s.state.station = 12 * 25.4; s.render(false); }); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "desktop-fishwing-selector.png") });
  await page.selectOption("select[data-wing]", "natural"); await page.waitForTimeout(120);
  const natState = await page.evaluate(() => ({ rule: window.sketch.state.wingRule, sel: document.querySelector("select[data-wing]").value, note: document.querySelector("#wingRow .flatnote").textContent }));
  if (natState.rule !== "natural" || natState.sel !== "natural" || !/before the wing/.test(natState.note)) problems.push("choosing Natural outline did not take: " + JSON.stringify(natState));
  await page.screenshot({ path: path.join(out, "desktop-fishwing-natural.png") });
  await page.selectOption("select[data-wing]", "narrow"); await page.click('#bar [data-b="shortboard"]'); await page.waitForTimeout(120);

  // drag the section line: the section caption must follow
  const before = await page.textContent("#secCap");
  const grab = await page.$("#grab");
  const gb = await grab.boundingBox();
  await page.mouse.move(gb.x + gb.width / 2, gb.y + gb.height / 2);
  await page.mouse.down();
  await page.mouse.move(gb.x + 150, gb.y + gb.height / 2, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(100);
  const after = await page.textContent("#secCap");
  console.log("section caption before/after drag:", before, "|", after);
  if (before === after) problems.push("dragging the section line did not move the section");

  // GUIDE: nineteen cards, one per name and one for the channels, each with its cartoon and its two sentences; the
  // five vees draw five different sections; the cuts on the board now are marked
  await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(200);
  const guide = await page.evaluate(() => {
    const cards = [...document.querySelectorAll("#guidePanel .card")];
    const byName = {}; for (const c of cards) byName[c.querySelector("h4 span").textContent] = c;
    const secPath = (n) => { const ps = byName[n].querySelectorAll("svg path.board"); return ps[ps.length - 1].getAttribute("d"); };
    const vees = ["Panel Vee", "Rolled Vee", "Spiral Vee", "Tri-Plane Hull Center", "Reverse Vee Nose"].map(secPath);
    const sentences = cards.map((c) => c.querySelector("p").textContent.split(/\.\s+/).length);
    return { n: cards.length, names: Object.keys(byName), on: cards.filter((c) => c.classList.contains("on")).map((c) => c.querySelector("h4 span").textContent),
      svgs: cards.filter((c) => c.querySelector("svg path.board")).length, hows: cards.filter((c) => /How to shape\S/.test((c.querySelector("p.how") || {}).textContent || "")).length, shaded: cards.filter((c) => c.querySelectorAll("svg .shade rect").length > 20).length,
      distinctVees: new Set(vees).size, sentences, heads: [...document.querySelectorAll("#guidePanel .datahead")].map((e) => e.textContent),
      panelScroll: document.getElementById("guidePanel").scrollHeight > document.getElementById("guidePanel").clientHeight, viewerHidden: getComputedStyle(document.getElementById("viewerPanel")).display === "none",
      cols: new Set([...document.querySelector("#guidePanel .cards").querySelectorAll(".card")].map((c) => Math.round(c.getBoundingClientRect().x))).size, cardW: cards[0].getBoundingClientRect().width };
  });
  console.log("guide:", JSON.stringify({ ...guide, names: guide.names.length }));
  if (guide.n !== 19 || guide.names.length !== 19) problems.push("GUIDE should have nineteen cards: " + guide.n);
  if (guide.svgs !== 19) problems.push("every card needs its cartoon: " + guide.svgs);
  if (guide.hows !== 19) problems.push("every card needs its How to shape line: " + guide.hows);
  if (guide.shaded !== 16) problems.push("sixteen cards (every cut but the three flats) should carry a shade: " + guide.shaded);
  if (guide.distinctVees !== 5) problems.push("the five vees should draw five different sections: " + guide.distinctVees);
  if (guide.on.join() !== "Flat Entry,Deep Single Concave,Flat Exit") problems.push("the Shortboard's own cuts should be marked: " + guide.on.join());
  if (guide.sentences.some((k) => k < 2 || k > 3)) problems.push("each card should carry one or two sentences per part: " + guide.sentences.join(","));
  if (guide.heads.length !== 4) problems.push("GUIDE should be headed Nose, Center, Tail, Channels: " + guide.heads.join(" | "));
  if (!guide.panelScroll || !guide.viewerHidden) problems.push("the GUIDE panel should scroll inside the folder with the viewer hidden");
  if (guide.cols !== 3) problems.push("a computer should show three cards across: " + guide.cols);
  await page.screenshot({ path: path.join(out, "desktop-guide.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 1380; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-guide-tail.png") });
  await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "desktop-guide-slate.png") });
  // the guide follows the board: the Fish's own cuts marked, the cartoons on the Fish's outline
  await page.click('#bar [data-b="fish"]'); await page.waitForTimeout(200);
  const fishGuide = await page.evaluate(() => ({ on: [...document.querySelectorAll("#guidePanel .card.on h4 span:first-child")].map((e) => e.textContent), note: document.querySelector("#guidePanel .guidenote").textContent }));
  if (fishGuide.on.join() !== "Flat Entry,Flat Center,Panel Vee" || !/your Fish/.test(fishGuide.note)) problems.push("GUIDE should follow the board: " + JSON.stringify(fishGuide));
  await page.click('#bar [data-b="shortboard"]'); await page.click('#bar [data-t="daylight"]'); await page.click('.tabs [data-page="viewer"]'); await page.waitForTimeout(100);

  // every theme draws without error
  for (const t of ["daylight", "chalk", "slate", "phosphor"]) { await page.click(`#bar [data-t="${t}"]`); await page.waitForTimeout(60); if (t !== "daylight") await page.screenshot({ path: path.join(out, `desktop-${t}.png`) }); }
  await page.click('#bar [data-t="daylight"]');
  // Metric, with six channels on
  await page.selectOption("select[data-count]", "6"); await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(80);
  const metricLbl = await page.evaluate(() => [...document.querySelectorAll("#sections [data-lbl]")].map((e) => e.textContent));
  console.log("metric labels:", metricLbl.join(" / "));
  if (!metricLbl.some((l) => / cm from the/.test(l))) problems.push("metric station labels do not read in cm");
  if (!metricLbl.some((l) => /Depth — \d+ mm/.test(l))) problems.push("metric depth does not read in whole mm");
  if (!metricLbl.some((l) => /Off Stringer — \d+ mm/.test(l))) problems.push("metric Off Stringer does not read in whole mm");
  if (!metricLbl.some((l) => /Stagger — \d+\.\d cm per channel · the outer pair starts \d+\.\d cm from the tail/.test(l))) problems.push("metric Stagger does not read as a dim in cm: " + metricLbl.filter((l) => /Stagger/.test(l)).join(" / "));
  await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  const data = await page.evaluate(() => ({ tables: document.querySelectorAll("#dataPanel table").length, rows: document.querySelectorAll("#dataPanel tbody tr").length, heads: [...document.querySelectorAll("#dataPanel th")].map((e) => e.textContent.trim()),
    line: document.querySelector("#dataPanel .datanotes p").textContent }));
  console.log("DATA (metric):", JSON.stringify(data));
  if (!/Foam off \d+\.\d\d L · \d+\.\d\d L now, \d+\.\d\d L before contours · the stringer finishes \d+ mm at the center, planed \d+ mm/.test(data.line)) problems.push("DATA's first line should carry the litres and the stringer in mm: " + data.line);
  if (data.tables !== 2) problems.push("DATA should have the depths table and the layout-marks table: " + data.tables);
  if (!data.heads.some((h) => /Wall 3/.test(h)) || !data.heads.some((h) => /Center edge/.test(h))) problems.push("the layout-marks table lacks its columns: " + data.heads.join(","));
  await page.screenshot({ path: path.join(out, "desktop-data-metric.png") });
  await page.click('.tabs [data-page="guide"]'); await page.waitForTimeout(150);
  const metricGuide = await page.evaluate(() => document.querySelectorAll("#guidePanel .card").length);
  if (metricGuide !== 19) problems.push("GUIDE in Metric lost cards: " + metricGuide);
  await page.click('#bar [data-u="imperial"]'); await page.click('.tabs [data-page="viewer"]');
  for (const b of ["fish", "midlength", "longboard"]) { await page.click(`#bar [data-b="${b}"]`); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${b}.png`) }); }
  // the sketch bar's phone frame on a computer must give the same phone stack
  await page.click('#bar [data-b="shortboard"]'); await page.click('#bar [data-f="1"]'); await page.waitForTimeout(150);
  const framed = await page.evaluate(() => ({ topbar: getComputedStyle(document.querySelector(".topbar")).display, w: document.getElementById("app").getBoundingClientRect().width,
    shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, sec: document.getElementById("sec").getBoundingClientRect().height }));
  console.log("phone frame on a computer:", JSON.stringify(framed));
  if (framed.topbar !== "flex" || framed.w !== 390 || framed.shown !== 1) problems.push("the phone frame does not give the phone stack");
  if (framed.sec < 90) problems.push("the framed section drawing is squashed: " + framed.sec);
  await page.screenshot({ path: path.join(out, "desktop-phone-frame.png") });
  await page.click('#bar [data-f="0"]');
  await page.close();

  // ---- an upright phone: 390 x 844 (iPhone 14), touch ----
  page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push("phone: " + e.message));
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const ph = await page.evaluate(() => {
    const main = document.querySelector(".main").getBoundingClientRect();
    const side = document.querySelector(".side").getBoundingClientRect();
    const bar = document.querySelector(".topbar").getBoundingClientRect();
    const shown = [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec);
    const secrow = getComputedStyle(document.getElementById("secrow")).display;
    const row = document.getElementById("secrow").getBoundingClientRect();
    const strip = document.querySelector(".strip").getBoundingClientRect();
    return { topbar: [bar.height, getComputedStyle(document.querySelector(".topbar")).display], main: [main.y, main.height], side: [side.y, side.height], shown, secrow, rowW: row.width, rowH: row.height, stripH: strip.height,
      tabs: document.querySelectorAll("#secrow .tab").length, ruler: document.querySelectorAll("#sec .ruler").length, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight };
  });
  console.log("phone", JSON.stringify(ph));
  if (ph.topbar[1] !== "flex" || ph.main[0] > ph.side[0]) problems.push("phone did not get the phone layout (width alone)");
  if (ph.shown.length !== 1) problems.push("phone should show one section's controls, shows " + ph.shown.join(","));
  if (ph.secrow === "none" || ph.tabs !== 3) problems.push("phone has no three-button switch");
  if (ph.rowH > 40 || ph.stripH > 40) problems.push("a switch or the tab strip wrapped onto two lines: " + JSON.stringify([ph.rowH, ph.stripH]));
  if (ph.ruler > 0) problems.push("the layout ruler should stay off a phone's section");
  if (ph.docScroll > ph.inner + 2) problems.push("the phone page scrolls as a whole (" + ph.docScroll + " > " + ph.inner + ")");
  const boxes = await page.evaluate(() => ({ top: document.getElementById("top").getBoundingClientRect().height, sec: document.getElementById("sec").getBoundingClientRect().height, bar: document.getElementById("bar").getBoundingClientRect().height }));
  console.log("phone boxes:", JSON.stringify(boxes));
  if (boxes.sec < 90) problems.push("the phone's section drawing is squashed: " + boxes.sec);
  if (boxes.bar > 60) problems.push("the sketch bar is too tall on a phone: " + boxes.bar);
  await page.screenshot({ path: path.join(out, "phone-daylight.png") });
  // TAIL shows the tail's cut and its channels block beneath
  await page.tap('#secrow [data-sec="tail"]'); await page.waitForTimeout(80);
  const shownTail = await page.evaluate(() => ({ shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec), block: !!document.querySelector('.sidesec[data-sec="tail"] [data-cut="channels"] select[data-count]') }));
  console.log("after tapping TAIL:", JSON.stringify(shownTail));
  if (shownTail.shown.join() !== "tail" || !shownTail.block) problems.push("TAIL on a phone should show the tail cut with its channels block");
  await page.selectOption("select[data-count]", "6"); await page.waitForTimeout(150);
  await page.evaluate(() => { const c = document.getElementById("controls"); const el = c.querySelector('[data-cut="channels"]'); c.scrollTop = el.offsetTop - 70; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "phone-tail-channels.png") });
  // a thumb tap on the board moves the section
  const b4 = await page.textContent("#secCap");
  const topBox = await (await page.$("#top")).boundingBox();
  await page.touchscreen.tap(topBox.x + topBox.width * 0.3, topBox.y + topBox.height / 2);
  await page.waitForTimeout(80);
  const aft = await page.textContent("#secCap");
  console.log("phone tap on the board:", b4, "|", aft);
  if (b4 === aft) problems.push("tapping the board on a phone did not move the section");
  // GUIDE on a phone: one card across, scrolling inside the pinned panel, the page itself still not scrolling
  await page.tap('.tabs [data-page="guide"]'); await page.waitForTimeout(250);
  const phGuide = await page.evaluate(() => { const p = document.getElementById("guidePanel"); const cards = [...document.querySelectorAll("#guidePanel .card")];
    return { n: cards.length, cols: new Set(cards.slice(0, 6).map((c) => Math.round(c.getBoundingClientRect().x))).size, scrolls: p.scrollHeight > p.clientHeight, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight, cardW: cards[0].getBoundingClientRect().width }; });
  console.log("phone guide:", JSON.stringify(phGuide));
  if (phGuide.n !== 19 || phGuide.cols !== 1 || !phGuide.scrolls) problems.push("GUIDE on a phone should be one card across, scrolling: " + JSON.stringify(phGuide));
  if (phGuide.docScroll > phGuide.inner + 2) problems.push("GUIDE makes the phone page scroll as a whole");
  await page.screenshot({ path: path.join(out, "phone-guide.png") });
  await page.evaluate(() => { document.getElementById("guidePanel").scrollTop = 2600; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "phone-guide-tail.png") });
  await page.tap('.tabs [data-page="viewer"]'); await page.click('#bar [data-b="fishwing"]'); await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(150);
  const phWing = await page.evaluate(() => ({ sel: document.querySelectorAll("#wingRow select").length, y: document.getElementById("wingRow").getBoundingClientRect().y }));
  if (phWing.sel !== 1) problems.push("the winged Fish on a phone should show the wing-rule selector");
  await page.evaluate(() => { const c = document.getElementById("controls"); const w = document.getElementById("wingRow"); c.scrollTop = w.getBoundingClientRect().top - c.getBoundingClientRect().top + c.scrollTop - 12; }); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(out, "phone-fishwing-slate.png") });
  await page.click('#bar [data-t="daylight"]'); await page.click('#bar [data-u="metric"]'); await page.click('#bar [data-b="longboard"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "phone-longboard-metric.png") });
  await page.click('#bar [data-b="shortboard"]'); await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-data.png") });
  await page.close();

  await browser.close();
  console.log("\nERRORS:", errors.length ? errors.join("\n") : "none");
  console.log("PROBLEMS:", problems.length ? problems.join("\n") : "none");
  process.exit(problems.length || errors.length ? 1 : 0);
})();

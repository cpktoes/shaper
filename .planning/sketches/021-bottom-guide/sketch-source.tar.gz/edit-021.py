"""Sketch 021 from 020's template: B fixed, no channels to start, Parallel run, the wing rule as a sidebar selector,
and a third tab, GUIDE. Exact-string edits; every old string must be found once."""
import re, sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: sys.exit(f"expected {count} of: {old[:90]!r}, found {n}")
    t = t.replace(old, new)

rep('<title>Sketch 020 — Bottom contours: channels and layout marks</title>', '<title>Sketch 021 — Bottom contours: the GUIDE tab, channels inside TAIL, the defaults</title>')
rep('''  <b>020 Bottom</b>
  <span class="grp"><span>Channels live</span>
    <button data-v="A" class="on">A: Own card</button>
    <button data-v="B">B: Inside Tail</button>
    <button data-v="C">C: A tail cut</button>
  </span>
  <span class="grp"><span>Board</span><span id="gBoard"></span></span>
  <span class="grp"><span>Off Rail from</span><button data-w="narrow" class="on">Narrowest outline</button><button data-w="natural">Natural outline</button></span>
''', '''  <b>021 Bottom</b>
  <span class="grp"><span>Board</span><span id="gBoard"></span></span>
''')
rep('aria-label="About this variant"', 'aria-label="About this sketch"')
rep('''<div style="padding-top:12px"><label class="check"><input type="checkbox" id="showRail" checked>Show the finished rail from RAILS</label></div>
''', '''<div style="padding-top:12px"><label class="check"><input type="checkbox" id="showRail" checked>Show the finished rail from RAILS</label></div>
        <div id="wingRow"></div>
''')
rep('''          <button class="tab" role="tab" data-page="data">Data</button>
''', '''          <button class="tab" role="tab" data-page="data">Data</button>
          <button class="tab" role="tab" data-page="guide">Guide</button>
''')
rep('''        <div class="inner text" id="dataPanel" style="display:none"></div>
''', '''        <div class="inner text" id="dataPanel" style="display:none"></div>
        <div class="inner text" id="guidePanel" style="display:none"></div>
''')
# ---- styles: the GUIDE's cards ----
rep('''/* drawing strokes — one ink, one dash per role''', '''/* GUIDE: one card per cut — its cartoon (drawn by the VIEWER's own code), its name, a sentence on what it is and one on what it does */
.guidenote { font-size: 12px; color: var(--muted); line-height: 1.5; }
.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(236px, 1fr)); gap: 10px; margin-bottom: 6px; }
.card { min-width: 0; border: 1px solid var(--faint); border-radius: 10px; padding: 10px 12px 12px; display: flex; flex-direction: column; gap: 6px; }
.card.on { border-color: var(--line); }
.card h4 { margin: 0; display: flex; justify-content: space-between; align-items: baseline; gap: 8px; font-size: 14px; font-weight: 700; color: var(--ink); }
.card h4 .now { flex: none; font-size: 9px; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; color: var(--accent-ink); }
.card svg { display: block; width: 100%; height: auto; overflow: visible; }
.card svg path, .card svg line { vector-effect: non-scaling-stroke; }
.card p { margin: 0; font-size: 13px; line-height: 1.45; color: var(--muted); }
.card p b { font-weight: 600; color: var(--ink); }

/* drawing strokes — one ink, one dash per role''')
rep('''#app.phone .footline { display: none; }
/* PHONE-END */''', '''#app.phone .footline { display: none; }
#app.phone .card { padding: 8px 10px 10px; }
/* PHONE-END */''')
# ---- the channels' defaults: none to start, Parallel, the width following the count ----
rep('''const makeChannels = (b, count) => ({ name: "Channels", kind: "channels", count, depth: i(1 / 4), width: i(count === 4 ? 2.5 : count === 8 ? 1.25 : 1.75), offS: 0, off: 0, start: b.fin + i(10), deep: b.fin, end: 0, smooth: 0, run: "rail", longer: "inner", stagger: i(2), trough: 0, vee: 0, pointed: false, spiral: false });
const RUNS = (b) => [["rail", "With the rail"], ["parallel", "Parallel to the stringer"], ["toe", b.toeDeg > 0 ? `Toe-in · ${b.toeDeg.toFixed(1)}° like the fins` : "Toe-in (no toe on this board)"]];''',
'''// Every board opens with no channels and a set runs Parallel to the stringer until the shaper says otherwise (the founder,
// 2026-11-07: "Channel Default = none", "Run default is parallel to stringer").
const channelWidth = (count) => i(count === 4 ? 2.5 : count === 8 ? 1.25 : 1.75);
const makeChannels = (b, count) => ({ name: "Channels", kind: "channels", count, depth: i(1 / 4), width: channelWidth(count), offS: 0, off: 0, start: b.fin + i(10), deep: b.fin, end: 0, smooth: 0, run: "parallel", longer: "inner", stagger: i(2), trough: 0, vee: 0, pointed: false, spiral: false });
const RUNS = (b) => [["parallel", "Parallel to the stringer"], ["rail", "With the rail"], ["toe", b.toeDeg > 0 ? `Toe-in · ${b.toeDeg.toFixed(1)}° like the fins` : "Toe-in (no toe on this board)"]];
// what Off Rail is measured from on a winged board — a selector, Narrowest outline by default (the founder, 2026-11-07)
const WING_RULES = [["narrow", "Narrowest outline"], ["natural", "Natural outline, before the wing"]];
const WING_NOTE = { narrow: "The real rail behind the wing, and that narrower line carried forward past it — so no cut ever crosses the rail.",
  natural: "The curve you drew before the wing. Behind the wing it sits outside the real rail, so a cut can run out through the step." };''')
rep('''const CHANNELS_DEF = { name: "Channels", kind: "channels" };
''', '')
rep('''const STARTS = { shortboard: ["Flat Entry", "Deep Single Concave", "Flat Exit", 6], fish: ["Flat Entry", "Flat Center", "Panel Vee", 4], fishwing: ["Flat Entry", "Flat Center", "Extending Single Concave", 4],
  midlength: ["Blended Nose Concave", "Shallow Single Concave", "Spiral Vee", 0], longboard: ["Teardrop Nose Concave", "Continuous Belly / Rolled Mid", "Rolled Vee", 0] };''',
'''const STARTS = { shortboard: ["Flat Entry", "Deep Single Concave", "Flat Exit", 0], fish: ["Flat Entry", "Flat Center", "Panel Vee", 0], fishwing: ["Flat Entry", "Flat Center", "Extending Single Concave", 0],
  midlength: ["Blended Nose Concave", "Shallow Single Concave", "Spiral Vee", 0], longboard: ["Teardrop Nose Concave", "Continuous Belly / Rolled Mid", "Rolled Vee", 0] };''')
rep('''  if (name === "Channels") { const ch = state.ch || makeChannels(b, 6); if (ch.count < 4) ch.count = 6; return ch; }
''', '')
rep('''const namesFor = (key) => key === "tail" && state.variant === "C" ? [...NAMES.tail, CHANNELS_DEF] : NAMES[key];''', '''const namesFor = (key) => NAMES[key];''')
rep('''let state = { board: "shortboard", variant: "A", theme:''', '''let state = { board: "shortboard", theme:''')
rep('''  if (state.variant === "C" && st[3] > 0) state.cuts.tail = state.ch;
''', '')
t2 = re.sub(r"// the variants differ only in where the channels live; flipping keeps the shaper's numbers\nfunction syncVariant\(\) \{.*?\n\}\nconst chOn = \(\) => state\.variant === \"C\" \? state\.cuts\.tail\.kind === \"channels\" : state\.ch\.count > 0;",
            "const chOn = () => state.ch.count > 0;", t, count=1, flags=re.S)
if t2 == t: sys.exit("syncVariant block not found")
t = t2
rep('''if (state.variant !== "C" && state.ch.count > 0) out.push(["channels", state.ch]);''', '''if (state.ch.count > 0) out.push(["channels", state.ch]);''')
# ---- the sidebar: three cards, the channels inside TAIL (B) ----
rep('''  const cards = state.variant === "A" ? ["nose", "center", "tail", "channels"] : ["nose", "center", "tail"];
  for (const key of cards) {
    const c = cutByKey(key);
    const title = key === "channels" ? (c.count >= 4 ? `${c.count} channels` : "None") : c.name;
    h += `<div class="sidesec${key === state.active ? " shown" : ""}" data-sec="${key}" data-cut="${key}"><div class="ruled"><span>${TITLE[key]}</span><span class="cutname">${svgEsc(title)}</span></div><div class="group">`;
    if (key === "channels") h += channelBlock("channels", true);
    else {
      h += `<div><div class="lbl">Cut</div>${sel(`data-sel="${key}"`, namesFor(key).map((n) => [n.name, n.name]), c.name)}</div>`;
      if (c.kind === "flat") h += `<div class="flatnote">Nothing is cut in this section.</div>`;
      if (c.kind === "channels") h += channelBlock(key, false);          // variant C: the tail's cut IS the channels
      else h += sliders(c, key, key);
      if (c.kind === "single" && key === "nose") h += `<label class="check"><input type="checkbox" data-pointed="${key}"${c.pointed ? " checked" : ""}>Closes to a point toward the center</label>`;
      if (key === "tail" && state.variant === "B") h += `<div data-cut="channels"><div class="subhead"><span>Channels</span><span class="cutname">${state.ch.count >= 4 ? `${state.ch.count}, cut after the ${svgEsc(c.name)}` : "None"}</span></div><div class="group">${channelBlock("tail", true)}</div></div>`;
    }
    h += `</div></div>`;
  }''',
'''  // B (the founder, 2026-11-07): three cards, and the channels live inside TAIL under the tail's own cut, cut after it
  const cards = ["nose", "center", "tail"];
  for (const key of cards) {
    const c = cutByKey(key);
    h += `<div class="sidesec${key === state.active ? " shown" : ""}" data-sec="${key}" data-cut="${key}"><div class="ruled"><span>${TITLE[key]}</span><span class="cutname">${svgEsc(c.name)}</span></div><div class="group">`;
    h += `<div><div class="lbl">Cut</div>${sel(`data-sel="${key}"`, namesFor(key).map((n) => [n.name, n.name]), c.name)}</div>`;
    if (c.kind === "flat") h += `<div class="flatnote">Nothing is cut in this section${key === "tail" && state.ch.count >= 4 ? " but the channels" : ""}.</div>`;
    h += sliders(c, key, key);
    if (c.kind === "single" && key === "nose") h += `<label class="check"><input type="checkbox" data-pointed="${key}"${c.pointed ? " checked" : ""}>Closes to a point toward the center</label>`;
    if (key === "tail") h += `<div data-cut="channels"><div class="subhead"><span>Channels</span><span class="cutname">${state.ch.count >= 4 ? `${state.ch.count}, cut after the ${svgEsc(c.name)}` : "None"}</span></div><div class="group">${channelBlock("tail", true)}</div></div>`;
    h += `</div></div>`;
  }''')
# ---- handlers ----
rep('''document.getElementById("sections").addEventListener("change", (e) => {''', '''document.getElementById("controls").addEventListener("change", (e) => {''')
rep('''  else if (el.matches("select[data-count]")) { const was = state.ch.count; state.ch.count = +el.value; state.active = el.dataset.sec; state.live = state.variant === "C" ? "tail" : "channels"; buildControls();
    if (was === 0 && state.ch.count > 0) state.station = state.ch.deep; render(false); }
  else if (el.matches("select[data-run]")) { state.ch.run = el.value; state.live = state.variant === "C" ? "tail" : "channels"; render(false); }
  else if (el.matches("select[data-longer]")) { state.ch.longer = el.value; state.active = el.dataset.sec; state.live = state.variant === "C" ? "tail" : "channels"; buildControls(); render(false); }''',
'''  else if (el.matches("select[data-count]")) { const was = state.ch.count; state.ch.count = +el.value;
    // a width still at one of the three starting widths follows the count (2 1/2" · 1 3/4" · 1 1/4"); a width the shaper set stays
    if ([4, 6, 8].some((n) => Math.abs(state.ch.width - channelWidth(n)) < 0.01)) state.ch.width = channelWidth(state.ch.count);
    state.active = el.dataset.sec; state.live = "channels"; buildControls();
    if (was === 0 && state.ch.count > 0) state.station = state.ch.deep; render(false); }
  else if (el.matches("select[data-run]")) { state.ch.run = el.value; state.live = "channels"; render(false); }
  else if (el.matches("select[data-longer]")) { state.ch.longer = el.value; state.active = el.dataset.sec; state.live = "channels"; buildControls(); render(false); }
  else if (el.matches("select[data-wing]")) { state.wingRule = el.value; render(true); }''')
rep('''  if (sec.dataset.sec !== state.active || ck !== state.live) { state.active = sec.dataset.sec; state.live = state.variant === "C" ? sec.dataset.sec : ck; syncControls(); render(false); } });''',
'''  if (sec.dataset.sec !== state.active || ck !== state.live) { state.active = sec.dataset.sec; state.live = ck; syncControls(); render(false); } });''')
rep('''  if (b.dataset.v) { state.variant = b.dataset.v; syncVariant(); applyChrome(); render(true); return; }
  else if (b.dataset.w) { state.wingRule = b.dataset.w; }
  else if (b.dataset.t) state.theme = b.dataset.t;''', '''  if (b.dataset.t) state.theme = b.dataset.t;''')
rep('''  document.querySelectorAll("#bar [data-v]").forEach((b) => b.classList.toggle("on", b.dataset.v === state.variant));
  document.querySelectorAll("#bar [data-w]").forEach((b) => b.classList.toggle("on", b.dataset.w === state.wingRule));
''', '')
t2 = re.sub(r'  document\.getElementById\("dataPanel"\)\.style\.display = state\.page === "data" \? "" : "none";\n  const notes = \{ A: .*?notes\[state\.variant\];',
  '''  document.getElementById("dataPanel").style.display = state.page === "data" ? "" : "none";
  document.getElementById("guidePanel").style.display = state.page === "guide" ? "" : "none";
  document.getElementById("note").innerHTML = "<b>021 — the founder's rulings of 2026-11-07 built in, and a GUIDE tab.</b> The channels live inside the TAIL card (B), every board opens with none, and a set runs Parallel to the stringer until you say otherwise. The wing rule is a selector in the sidebar, shown only on a winged board, Narrowest outline by default. GUIDE is the third tab: what each cut is and what it does, a sentence each, with every cut drawn on the board you have open — from above with its shade, and across at its deepest point.";''',
  t, count=1, flags=re.S)
if t2 == t: sys.exit("notes block not found")
t = t2
rep('''raf = requestAnimationFrame(() => { drawTop(); drawSec(); drawFoot(); if (state.page === "data") drawData(); });''',
    '''raf = requestAnimationFrame(() => { drawTop(); drawSec(); drawFoot(); if (state.page === "data") drawData(); if (state.page === "guide") drawGuide(); });''')
rep('''  document.getElementById("boardName").textContent = B.name;
}''', '''  document.getElementById("boardName").textContent = B.name;
  // the wing rule: one setting for the whole bottom, so it sits above the three sections, and only a winged board shows it
  const wr = document.getElementById("wingRow");
  if (B.wings && B.wings.length) { const w = B.wings[0];
    wr.innerHTML = `<div class="ruled"><span>Wings</span><span class="cutname">${mark(w.depth)} wing at ${dim(w.station)}</span></div><div class="group"><div><div class="lbl">Measure Off Rail from</div>${sel(`data-wing="1"`, WING_RULES, state.wingRule)}</div><div class="flatnote">${WING_NOTE[state.wingRule]}</div></div>`; }
  else wr.innerHTML = "";
}''')
rep('''window.sketch = { state, render, setBoard, foamOff, litresOff, deepestAt, applyChrome, channelEdges, channelMarks, channelFit, chStart, chFade, cutOff, cutHalfWidth, marksOf, syncVariant, buildControls, railHalfWidth: curveAt, refHalfWidth: refAt };''',
    '''window.sketch = { state, render, setBoard, foamOff, litresOff, deepestAt, applyChrome, channelEdges, channelMarks, channelFit, chStart, chFade, cutOff, cutHalfWidth, marksOf, cartoon, drawGuide, makeCut, makeChannels, buildControls, railHalfWidth: curveAt, refHalfWidth: refAt };''')
# ---- the GUIDE ----
rep('''/* ============ the sidebar's sections ============ */''', '''/* ============ GUIDE: what each cut is, and what it does ============ */
// The founder's ask (2026-11-07): "a third tab that is informational and teaches the user VERY briefly (like 1-2 sentences)
// and with a cartoon, what each contour type does, is, and looks like. With so many Vee options, I think we need a clear
// idea how they differ." One sentence on what it is and looks like, one on what it does — first drafts for his pen.
const GUIDE = {
  "Flat Entry": ["The planed bottom left alone from the nose back.", "Neutral and quick to plane; the work is left to the center."],
  "Rolled Belly Entry": ["The bottom rounds from the stringer to the rails under the nose, like a boat's hull.", "Softens the entry in chop and lets the board roll into a turn, at the cost of some speed."],
  "Teardrop Nose Concave": ["A single concave widest under the nose, closing to a point before the center.", "A noserider's lift: it holds air and water under the nose so it rides high with you standing on it."],
  "Blended Nose Concave": ["A shallow single under the nose that fades into the center without an edge.", "Lifts the entry of a longboard or mid-length without the teardrop's drag."],
  "Slight Single Concave Entry": ["The faintest single concave from the nose back, barely a gauge mark deep.", "Quickens the entry and leads the water into the center's concave."],
  "Reverse Vee Nose": ["A vee under the nose — the stringer low, both rails lifted — flattening out toward the center.", "Lets the nose knife through chop and roll into a turn instead of catching."],
  "Flat Center": ["Nothing cut between the wide point and the fins.", "Fast and predictable; the classic partner to a vee or a double in the tail."],
  "Deep Single Concave": ["One trough across the center, deepest at the stringer, running out flat at the rails.", "Lift and drive: it sends the water straight down the board. The modern shortboard standard."],
  "Shallow Single Concave": ["The same single at half the depth.", "Some of the lift with less of the drag, and friendlier in bumpy water."],
  "Early Double Concave": ["Two troughs either side of a flat at the stringer, starting ahead of the wide point.", "Splits the water early, loosens the board, and runs on into a tail double or vee."],
  "Continuous Belly / Rolled Mid": ["The bottom rounds from the stringer to the rails along the whole middle — a displacement hull.", "Glides through chop and rolls into turns, giving up speed and lift."],
  "Tri-Plane Hull Center": ["A flat panel down the stringer with a flat plane each side, angled up to the rails.", "Fast off the panel, with a vee's ease rail to rail."],
  "Flat Exit": ["Nothing cut from the fins back.", "The cleanest release; the fins do the turning."],
  "Double Concave Exit": ["Two troughs through the fins to the tail, a flat left at the stringer.", "Each fin sits in its own stream of water for drive, and the ridge at the stringer helps the board roll rail to rail."],
  "Panel Vee": ["Two flat planes meeting at the stringer and rising to the rails, from about the fins out the tail.", "The classic: lifted rails roll into a turn easily, trading away some speed."],
  "Spiral Vee": ["A double concave cut into a vee; the vee grows toward the tail as the double runs out, so the panels seem to twist.", "The double's drive through the fins with the vee's easy roll off the tail."],
  "Rolled Vee": ["A vee whose planes are rounded instead of flat, with no corner at the stringer.", "Softer than a panel vee: forgiving through a turn, a touch slower."],
  "Extending Single Concave": ["The center's single concave carried through the fins and out the tail.", "Drive and lift to the very end — fast, and stiffer rail to rail."],
  "Channels": ["Four, six or eight troughs through the fins, each a ramp into a vertical wall at the rail side, cut last.", "Every wall grips like a small fin: drive and hold at speed in clean, powerful waves."],
};
// One cut's cartoon: the open board from above with that cut alone — its shade and the pencil lines a shaper would rule —
// and the section across it where it is deepest, Height ×8, the planed bottom a dashed straightedge beneath. Drawn with
// the VIEWER's own maths and dashes so the guide teaches the drawing as well as the cut. Lines keep their width when the
// card scales (vector-effect in the stylesheet); the dashes are written for a 300-wide card.
function cartoon(c, key, id) {
  const W0 = 300, hTop = 76, gap = 6, hSec = 72, H = hTop + gap + hSec;
  const L = B.L, Wmax = B.widePointWidth / 2;
  const kt = Math.min(284 / L, (hTop - 10) / (2 * Wmax)), cy = hTop / 2;
  const X = (s) => W0 / 2 + (L / 2 - s) * kt, Y = (y) => cy + y * kt;
  const pts = B.outline; let d = "";
  for (let j = 0; j < pts.length; j++) d += (j ? "L" : "M") + X(pts[j][0]).toFixed(1) + " " + Y(pts[j][1]).toFixed(1);
  for (let j = pts.length - 1; j >= 0; j--) d += "L" + X(pts[j][0]).toFixed(1) + " " + Y(-pts[j][1]).toFixed(1);
  if (Math.abs(B.close - B.first) > 0.5) d += "L" + X(B.close).toFixed(1) + " " + Y(0).toFixed(1);
  d += "Z";
  const on = c.kind !== "flat" && c.depth > 0 && !(c.kind === "channels" && c.count < 4);
  const off = (s, y) => on ? cutOff(c, s, y, curveAt(s)) : 0;
  let out = `<path class="board" stroke-width="1" d="${d}"/>`;
  if (on) {
    out += `<defs><clipPath id="${id}"><path d="${d}"/></clipPath></defs><g clip-path="url(#${id})">`;
    const cols = 72, m = 18, step32 = IN / 32; let rects = "";
    for (let a = 0; a < cols; a++) { const s = (a + 0.5) / cols * L, W = curveAt(s), inner = innerAt(s); if (W <= 0.5) continue;
      const x0 = X(s + L / cols / 2), w = (X(s - L / cols / 2) - x0).toFixed(2);
      const ys = [], fs = []; for (let j = 0; j <= m; j++) { const y = inner + (W - inner) * j / m; ys.push(y); fs.push(off(s, y)); }
      let maxF = 0; for (const f of fs) maxF = Math.max(maxF, f);
      for (let lv = step32; lv <= maxF + 1e-9; lv += step32) { let j = 0; while (j <= m) { if (fs[j] >= lv) { let j2 = j; while (j2 + 1 <= m && fs[j2 + 1] >= lv) j2++;
        const ya = j > 0 ? (ys[j - 1] + ys[j]) / 2 : ys[0], yb = j2 < m ? (ys[j2] + ys[j2 + 1]) / 2 : ys[m]; const h = ((yb - ya) * kt).toFixed(2);
        rects += `<rect x="${x0.toFixed(2)}" y="${Y(ya).toFixed(2)}" width="${w}" height="${h}"/><rect x="${x0.toFixed(2)}" y="${Y(-yb).toFixed(2)}" width="${w}" height="${h}"/>`; j = j2 + 1; } else j++; } }
    }
    out += `<g class="shade" fill-opacity="0.05">${rects}</g>`;
    const line = (yAt, steps = 120) => { let d1 = "", d2 = "", onL = false;
      for (let a = 0; a <= steps; a++) { const s = c.end + (c.start - c.end) * a / steps; const y = yAt(s); const W = curveAt(s);
        if (fade(c, s) > 0.004 && y !== null && y > 0.5 && y < W + 0.5) { const cmd = onL ? "L" : "M"; d1 += `${cmd}${X(s).toFixed(1)} ${Y(y).toFixed(1)}`; d2 += `${cmd}${X(s).toFixed(1)} ${Y(-y).toFixed(1)}`; onL = true; } else onL = false; }
      return d1 + d2; };
    let dd = "";
    if (c.kind === "single" || c.kind === "double") { dd += line((s) => cutHalfWidth(c, s)); if (c.kind === "double") dd += line((s) => doubleMarks(c, cutHalfWidth(c, s)).a); }
    else if (c.kind === "channels") for (const { col } of channelMarks(c, c.deep)) dd += line((s) => { const mk = channelMarks(c, s).find((q) => q.col === col); return mk && mk.on ? mk.y : null; }, 100);
    else if (c.offS > 0) dd += line(() => c.offS, 60);
    if (dd) out += `<path class="pencil" stroke-width="1" d="${dd}"/>`;
    if (c.kind === "double") out += `<path class="deepline" stroke-width="1" stroke-dasharray="1 3" d="${line((s) => doubleMarks(c, cutHalfWidth(c, s)).t)}"/>`;
    out += `</g>`;
  }
  out += `<line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${X(L).toFixed(1)}" y1="${cy}" x2="${X(Math.max(0, B.close)).toFixed(1)}" y2="${cy}"/>`;
  // the section is taken where the cut is deepest (a flat one at the wide point), kept 3" inside either tip so the slab reads
  const s = on ? Math.max(3 * IN, Math.min(L - 3 * IN, c.deep)) : B.wide;
  out += `<line class="cutline" stroke-width="1" stroke-dasharray="7 2.5 1.5 2.5" x1="${X(s).toFixed(1)}" y1="${(Y(-curveAt(s)) - 5).toFixed(1)}" x2="${X(s).toFixed(1)}" y2="${(Y(curveAt(s)) + 5).toFixed(1)}"/>`;
  const Wo = curveAt(s), inner = innerAt(s), T = thickAt(s);
  const kx = 284 / (2 * Wmax), top0 = hTop + gap, y0 = top0 + hSec - 12, budget = 8;
  let deepest = 0; for (let j = 0; j <= 40; j++) deepest = Math.max(deepest, off(s, inner + (Wo - inner) * j / 40));
  const room = y0 - top0 - budget - 4; let ky = kx * 8; if (deepest > 0.3 && deepest * ky > room) ky = room / deepest;
  const slabTop = y0 - T * ky, broken = slabTop < top0 + budget, yTop = broken ? top0 + budget : slabTop;
  const xOf = (y) => W0 / 2 + y * kx, hOf = (y) => y0 - off(s, Math.abs(y)) * ky;
  const piece = (yA, yB) => { let p = `M${xOf(yA).toFixed(1)} ${yTop.toFixed(1)}L${xOf(yB).toFixed(1)} ${yTop.toFixed(1)}`; const n = 90; for (let j = 0; j <= n; j++) { const y = yB - (yB - yA) * j / n; p += `L${xOf(y).toFixed(1)} ${hOf(y).toFixed(1)}`; } return p + "Z"; };
  if (Wo > 0.5) {
    out += inner > 0.5 ? `<path class="board" stroke-width="1" d="${piece(inner, Wo)}"/><path class="board" stroke-width="1" d="${piece(-Wo, -inner)}"/>` : `<path class="board" stroke-width="1" d="${piece(-Wo, Wo)}"/>`;
    if (broken) { let z = `M${(xOf(-Wo) - 6).toFixed(1)} ${yTop.toFixed(1)}`; const segs = 24; for (let j = 1; j <= segs; j++) z += `L${(xOf(-Wo) - 6 + (2 * Wo * kx + 12) * j / segs).toFixed(1)} ${(yTop + (j % 2 ? -2 : 2)).toFixed(1)}`;
      out += `<path class="brk" d="${z}" style="stroke:var(--panel);stroke-width:5"/><path class="brk" stroke-width="1" d="${z}"/>`; }
    if (inner <= 0.5) out += `<line class="stringer" stroke-width="1" stroke-dasharray="12 3 3 3" x1="${W0 / 2}" y1="${(yTop + 2).toFixed(1)}" x2="${W0 / 2}" y2="${(hOf(0) - 1.5).toFixed(1)}"/>`;
  }
  out += `<line class="straight" stroke-width="1" stroke-dasharray="4 3" x1="${(xOf(-Wo) - 14).toFixed(1)}" y1="${y0}" x2="${(xOf(Wo) + 14).toFixed(1)}" y2="${y0}"/>`;
  return `<svg viewBox="0 0 ${W0} ${H}" aria-hidden="true">${out}</svg>`;
}
function drawGuide() {
  let n = 0;
  const card = (c, key, isOn) => `<div class="card${isOn ? " on" : ""}"><h4><span>${svgEsc(c.name)}</span>${isOn ? `<span class="now">On this board</span>` : ""}</h4>${cartoon(c, key, `g${n++}`)}<p><b>${svgEsc(GUIDE[c.name][0])}</b> ${svgEsc(GUIDE[c.name][1])}</p></div>`;
  let h = `<div class="guidenote">What each cut is, and what it does. Every cut is drawn on your ${svgEsc(B.name)} at its starting numbers — from above with its shade, and across where it is deepest, Height ×8 — the way VIEWER draws it.</div>`;
  for (const [key, title] of [["nose", "Nose"], ["center", "Center"], ["tail", "Tail"]]) {
    h += `<div class="datahead">${title}</div><div class="cards">`;
    for (const def of NAMES[key]) h += card(makeCut(key, def.name, B), key, state.cuts[key].name === def.name);
    h += `</div>`;
  }
  h += `<div class="datahead">Channels · cut last, inside TAIL</div><div class="cards">${card(makeChannels(B, 6), "channels", state.ch.count > 0)}</div>`;
  document.getElementById("guidePanel").innerHTML = h;
}

/* ============ the sidebar's sections ============ */''')
p.write_text(t)
print("ok", len(t))

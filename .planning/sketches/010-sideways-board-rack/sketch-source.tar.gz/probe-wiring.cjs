// Scratch only: after switching tabs a few times, one tap must act once (all three sketches).
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = []; page.on("pageerror", (e) => errors.push(String(e)));
  const base = "file:///Users/kontoes/Code/shaper/.planning/sketches/";
  // 011 C: two taps on ‹ move the middle board two places.
  await page.goto(base + "011-phone-rack-reorder/index.html"); await page.waitForTimeout(600);
  for (const v of ["b", "a", "c"]) { await page.evaluate((v) => { state.variant = v; renderAll(); }, v); await page.waitForTimeout(300); }
  await page.evaluate(() => rack.goTo(5, false)); await page.waitForTimeout(400);
  const before = await page.evaluate(() => rack.slotOf(rack.middle(), rack.order));
  await page.click('[data-move="-1"]'); await page.waitForTimeout(500); await page.click('[data-move="-1"]'); await page.waitForTimeout(600);
  console.log("011 C: slot", before, "->", await page.evaluate(() => rack.slotOf(rack.middle(), rack.order)));
  // 010: the ⋯ menu opens (and stays open) after switching tabs.
  await page.goto(base + "010-sideways-board-rack/index.html"); await page.waitForTimeout(600);
  for (const v of ["b", "today", "a"]) { await page.evaluate((v) => { state.variant = v; renderAll(); }, v); await page.waitForTimeout(300); }
  await page.evaluate(() => { const b = rack.list.findIndex((x) => x.name === "Egg"); rack.turned = b; rack.cursor = null; rack.kick(); }); await page.waitForTimeout(700);
  await page.click(".dcap .more"); await page.waitForTimeout(200);
  console.log("010 menu open:", await page.evaluate(() => !!document.querySelector(".dcap .menu.open")));
  await page.click('.dcap [data-move="-1"]'); await page.waitForTimeout(600);
  console.log("010 Move left once:", await page.evaluate(() => rack.order.map((b) => rack.list[b].name).slice(2, 6).join(" | ")));
  // 009: the ⋯ menu opens after switching tabs.
  await page.goto(base + "009-phone-swipe-rack/index.html"); await page.waitForTimeout(600);
  for (const v of ["a", "c", "b"]) { await page.evaluate((v) => { state.variant = v; renderAll(); }, v); await page.waitForTimeout(300); }
  await page.evaluate(() => rack.goTo(2, false)); await page.waitForTimeout(700);
  await page.click("#cap .more"); await page.waitForTimeout(200);
  console.log("009 menu open:", await page.evaluate(() => !!document.querySelector("#cap .menu.open")));
  console.log("errors", JSON.stringify(errors));
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

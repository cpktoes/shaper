/* ---------------- the rack: one or more rows, one turned board, boards you can move ---------------- */
let rack = null, rackOrder = null;
class Rack {
  constructor(host, list, opts) {
    this.host = host; this.list = list; this.o = opts; this.n = list.length;
    this.CW = opts.CW; this.P = 48; this.labelsW = 26; this.top = 10;
    this.floorPad = opts.look === "shop" ? 16 : 12; this.bandH = 96; this.gap = 14;
    const tallest = Math.max(...list.map((b) => b.lengthMm), 84 * 25.4);
    // One scale for every board in every row, so lengths and rockers compare across the whole quiver.
    const fit = (boardsH) => {
      const s = boardsH / tallest;
      const maxOut = Math.max(...list.map((b) => 2 * Math.max(...b.half) * s));
      const reserve = Math.max(0, maxOut + 18 - this.P);
      return { boardsH, s, reserve, cap: Math.max(1, Math.floor((this.CW - this.labelsW - reserve) / this.P)) };
    };
    let L = fit(380); if (L.cap < this.n) L = fit(290);
    Object.assign(this, L);
    this.preps = list.map((b) => prep(b, this.s));
    this.nRows = Math.ceil(this.n / this.cap); this.per = Math.ceil(this.n / this.nRows);
    this.floorY = this.top + this.boardsH; this.H = this.floorY + this.floorPad;
    this.rowPitch = this.H + this.bandH + this.gap; this.totalH = this.nRows * this.rowPitch - this.gap;
    // The unsaved board has no stored place yet, so it stays first and nothing goes in front of it.
    this.pinned = list[0] && list[0].inProgress ? 1 : 0;
    this.order = opts.order && opts.order.length === this.n ? opts.order.slice() : list.map((_, i) => i);
    this.view = this.order;
    this.f = list.map(() => 0); this.tgt = list.map(() => 0); this.lastV = list.map(() => -1); this.lastLift = list.map(() => -1); this.lastHeld = list.map(() => false);
    this.turned = this.order[0]; this.f[this.turned] = 1;
    this.px = []; this.py = []; this.lastPx = []; this.lastPy = [];
    this.cursor = null; this.lastMove = 0; this.drag = null; this.pending = null; this.raf = 0; this.lastT = 0;
    this.build();
  }
  get dur() { return state.speed === "slow" ? 2600 : 520; }
  get tau() { return state.speed === "slow" ? 420 : 70; }
  get tauPos() { return state.speed === "slow" ? 700 : 110; }
  vis(f) { return this.o.mode === "under" ? ease(f) : f; }
  slotPos(k) { const r = Math.floor(k / this.per), c = k % this.per; return { r, x: this.labelsW + this.reserve / 2 + c * this.P + this.P / 2, y: r * this.rowPitch }; }
  slotOf(b, order = this.view) { return order.indexOf(b); }
  rowCount(r) { return Math.min(this.per, this.n - r * this.per); }
  slotAt(r, u, minSlot = 0) { const c = clamp(Math.round((u - this.labelsW - this.reserve / 2 - this.P / 2) / this.P), 0, this.rowCount(r) - 1); return Math.max(minSlot, r * this.per + c); }
  local(e) { const rc = this.svg.getBoundingClientRect(); return { u: (e.clientX - rc.left) / appScale, y: (e.clientY - rc.top) / appScale }; }
  build() {
    const { CW } = this, look = this.o.look, shop = SHOP[state.theme];
    let back = "", front = "";
    for (let r = 0; r < this.nRows; r++) {
      const oy = r * this.rowPitch;
      if (look === "drawing") {
        if (state.lines === "on") for (const mk of this.heightMarks()) back += `<line x1="${this.labelsW - 2}" x2="${CW}" y1="${oy + mk.y}" y2="${oy + mk.y}" stroke="var(--color-border)" stroke-dasharray="5 4"/><text class="rlabel" x="0" y="${oy + mk.y + 3.5}">${mk.label}</text>`;
        back += `<line x1="0" x2="${CW}" y1="${oy + this.floorY + 0.5}" y2="${oy + this.floorY + 0.5}" stroke="var(--color-line)"/>`;
      } else {
        back += `<rect x="0" y="${oy}" width="${CW}" height="${this.H}" rx="6" fill="${shop.wall}"/>`;
        back += `<rect x="0" y="${oy + this.floorY - this.boardsH * 0.5 - 3}" width="${CW}" height="6" fill="${shop.bar}" opacity=".8"/>`;
        front += `<rect x="0" y="${oy + this.floorY - 4}" width="${CW}" height="${this.floorPad + 4}" rx="3" fill="url(#rail)"/>`;
      }
    }
    let bds = "";
    this.list.forEach((b, i) => {
      const fill = look === "shop" ? "url(#foam)" : "var(--color-board)";
      const stroke = look === "shop" ? shop.stroke : "var(--color-text)";
      const strCol = look === "shop" ? shop.stringer : "var(--color-line)";
      const dash = look === "shop" ? "" : `stroke-dasharray="16 4 4 4"`;
      const shadow = look === "shop" ? `<ellipse class="shadow" cx="0" cy="${this.floorY - 1}" rx="${(this.preps[i].sideW / 2 + 6).toFixed(1)}" ry="3.2" fill="${shop.shadow}" opacity=".7"/>` : "";
      bds += `<g class="bd" data-b="${i}">${shadow}<g class="lift"><path class="body" fill="${fill}" stroke="${stroke}" stroke-width="${look === "shop" ? 0.8 : 1.15}" stroke-linejoin="round"/><path class="str" fill="none" stroke="${strCol}" stroke-width="${look === "shop" ? 1 : 0.8}" ${dash}/></g><text class="spine"></text></g>`;
    });
    const defs = `<defs><linearGradient id="foam" x1="0" x2="1"><stop offset="0" stop-color="${shop.foamEdge}"/><stop offset=".22" stop-color="${shop.foamShade}"/><stop offset=".5" stop-color="${shop.foam}"/><stop offset=".78" stop-color="${shop.foamShade}"/><stop offset="1" stop-color="${shop.foamEdge}"/></linearGradient><linearGradient id="rail" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${shop.railTop}"/><stop offset=".35" stop-color="${shop.rail}"/><stop offset="1" stop-color="${shop.railLow}"/></linearGradient><filter id="liftfx" x="-60%" y="-10%" width="220%" height="130%"><feDropShadow dx="0" dy="10" stdDeviation="8" flood-color="${shop.shadow}"/></filter></defs>`;
    const tick = `<path class="droptick" d="M-14 0H14" stroke="var(--color-accent-ink)" stroke-width="3" stroke-linecap="round" opacity="0"/>`;
    this.host.innerHTML = `<div class="rack"><svg width="${CW}" height="${this.totalH}" viewBox="0 0 ${CW} ${this.totalH}" tabindex="0" aria-label="Board rack. Point at a board to turn it, click to open it, drag it to move it. Arrow keys move along; Alt and an arrow moves the turned board.">${defs}${back}<g class="boards">${bds}</g>${front}<g class="over">${tick}</g></svg><div class="dcap hide"></div></div>`;
    this.svg = this.host.querySelector("svg");
    this.layer = this.svg.querySelector("g.boards"); this.over = this.svg.querySelector("g.over"); this.tick = this.svg.querySelector(".droptick");
    this.cap = this.host.querySelector(".dcap"); this.capFor = -1;
    this.groups = [];
    this.svg.querySelectorAll("g.bd").forEach((g) => { const b = +g.dataset.b; g._body = g.querySelector(".body"); g._str = g.querySelector(".str"); g._lift = g.querySelector(".lift"); g._spine = g.querySelector(".spine"); this.groups[b] = g; });
    this.list.forEach((_, b) => { this.fillSpine(b); const p = this.slotPos(this.slotOf(b)); this.px[b] = p.x; this.py[b] = p.y; });
    this.wire();
    this.update(performance.now(), true);
  }
  heightMarks() {
    const out = [], maxMm = this.boardsH / this.s;
    if (state.units === "metric") { for (let cm = 150; cm * 10 <= maxMm + 1; cm += 50) out.push({ y: this.floorY - cm * 10 * this.s, label: cm + "" }); }
    else { for (let ft = 4; ft * 304.8 <= maxMm + 1; ft++) out.push({ y: this.floorY - ft * 304.8 * this.s, label: ft + "′" }); }
    return out;
  }
  fillSpine(b) {
    const t = this.groups[b]._spine, bd = this.list[b];
    t.innerHTML = `<tspan class="nm">${esc(bd.name)}</tspan><tspan class="dm" dx="7">${esc(lineOf(bd))}</tspan>`;
    t.style.fontSize = "12px";
    const room = this.boardsH - 4;
    try { const len = t.getComputedTextLength(); if (len > room) t.style.fontSize = (12 * room / len).toFixed(2) + "px"; } catch (e) {}
  }
  boardAt(u, y) {
    const r = Math.floor(y / this.rowPitch), yl = y - r * this.rowPitch;
    if (r < 0 || r >= this.nRows || yl < 0 || yl > this.H) return -1;
    let best = -1, bd = 1e9;
    for (let b = 0; b < this.n; b++) {
      if (Math.floor(this.slotOf(b) / this.per) !== r) continue;
      const d = Math.abs(u - this.px[b]), reach = Math.max(this.P / 2 - 2, halfExtent(this.preps[b], this.vis(this.f[b]) * Math.PI / 2) + 4);
      if (d <= reach && d < bd) { bd = d; best = b; }
    }
    return best;
  }
  wire() {
    const svg = this.svg;
    svg.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const { u, y } = this.local(e), b = this.boardAt(u, y);
      if (b < 0) return;
      this.pending = { b, u0: u, y0: y };
      try { svg.setPointerCapture(e.pointerId); } catch (err) {}
    });
    svg.addEventListener("pointermove", (e) => {
      const { u, y } = this.local(e);
      if (this.pending && !this.drag && !this.pending.blocked && Math.hypot(u - this.pending.u0, y - this.pending.y0) > 6) {
        const b = this.pending.b;
        if (this.slotOf(b, this.order) < this.pinned) this.pending.blocked = true;
        else { this.drag = { b, offU: this.pending.u0 - this.px[b], offY: this.pending.y0 - this.py[b], u, y, slot: this.slotOf(b, this.order) }; svg.classList.add("dragging"); this.over.insertBefore(this.groups[b], this.tick); this.cursor = null; }
      }
      if (this.drag) {
        const r = clamp(Math.floor((y - this.drag.offY + this.H / 2) / this.rowPitch), 0, this.nRows - 1);
        Object.assign(this.drag, { u, y, slot: this.slotAt(r, u, this.pinned) });
        this.kick(); return;
      }
      const r = Math.floor(y / this.rowPitch), yl = y - r * this.rowPitch;
      if (r >= 0 && r < this.nRows && yl >= 0 && yl <= this.H) { this.cursor = { r, u }; this.lastMove = performance.now(); } else this.cursor = null;
      this.kick();
    });
    const end = (cancel) => {
      if (this.drag) this.drop(cancel);
      else if (this.pending && !cancel) {
        if (this.pending.blocked) toast("The unsaved board stays first until it's saved");
        else openBoard(this.list[this.pending.b]);
      }
      this.pending = null;
    };
    svg.addEventListener("pointerup", () => end(false));
    svg.addEventListener("pointercancel", () => end(true));
    svg.addEventListener("pointerleave", () => { if (!this.drag) { this.cursor = null; this.kick(); } });
    svg.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        const d = e.key === "ArrowRight" ? 1 : -1;
        if (e.altKey) { if (!this.move(this.turned, d)) toast("It can't go that way"); }
        else { this.cursor = null; this.turned = this.order[clamp(this.slotOf(this.turned, this.order) + d, 0, this.n - 1)]; this.kick(); }
        e.preventDefault();
      }
      if (e.key === "Enter") openBoard(this.list[this.turned]);
    });
  }
  drop(cancel) {
    const { b, slot } = this.drag, from = this.slotOf(b, this.order);
    if (!cancel && slot !== from) {
      this.order = this.order.filter((x) => x !== b); this.order.splice(slot, 0, b);
      rackOrder = this.order.slice();
      toast(`Moved ${this.list[b].name}. The rack keeps your order.`);
    }
    this.drag = null; this.view = this.order; this.svg.classList.remove("dragging");
    this.layer.appendChild(this.groups[b]);
    this.turned = b; this.lastMove = 0;
    this.kick();
  }
  move(b, d) {
    const k = this.slotOf(b, this.order), nk = clamp(k + d, this.pinned, this.n - 1);
    if (k < this.pinned || nk === k) return false;
    this.order.splice(k, 1); this.order.splice(nk, 0, b); this.view = this.order; rackOrder = this.order.slice();
    this.turned = b; this.cursor = null; this.kick();
    return true;
  }
  kick() { if (!this.raf) this.raf = requestAnimationFrame((t) => { this.raf = 0; this.update(t); }); }
  update(now, force) {
    const dt = this.lastT ? clamp(now - this.lastT, 0, 64) : 16; this.lastT = now;
    const mode = this.o.mode, n = this.n, P = this.P, drag = this.drag;
    const resting = !this.cursor || now - this.lastMove > 180;
    // While a board is held, everything else is laid out as if it were already in its new place.
    if (drag) { const o = this.order.filter((x) => x !== drag.b); o.splice(drag.slot, 0, drag.b); this.view = o; } else this.view = this.order;
    if (!drag && this.cursor) {
      const { r, u } = this.cursor;
      if (mode === "under") {
        const t = this.turned, inRow = Math.floor(this.slotOf(t) / this.per) === r;
        const half = inRow ? halfExtent(this.preps[t], this.vis(this.f[t]) * Math.PI / 2) + 6 : 0;
        if (!(inRow && Math.abs(u - this.px[t]) <= Math.max(half, P / 2))) this.turned = this.view[this.slotAt(r, u)];
      } else this.turned = this.view[this.slotAt(r, u)];
    }
    let busy = false;
    for (let b = 0; b < n; b++) {
      let tgt;
      if (drag) tgt = 0;
      else if (mode === "follow" && this.cursor && !resting) { const k = this.slotOf(b), p = this.slotPos(k); tgt = p.r === this.cursor.r ? smooth(clamp(1 - Math.abs(this.cursor.u - p.x) / P, 0, 1)) : 0; }
      else tgt = b === this.turned ? 1 : 0;
      this.tgt[b] = tgt;
      const f = this.f[b];
      if (f !== tgt) {
        if (mode === "follow") { const k = 1 - Math.exp(-dt / (resting ? this.dur / 3.2 : this.tau)); this.f[b] = Math.abs(tgt - f) < 0.002 ? tgt : f + (tgt - f) * k; }
        else this.f[b] = tgt > f ? Math.min(tgt, f + dt / this.dur) : Math.max(tgt, f - dt / (this.dur * 0.6));
        busy = true;
      }
    }
    // Where every board belongs: its slot, plus (Drawing look) the room the rack makes around a turning board.
    const tx = [], ty = [];
    for (let r = 0; r < this.nRows; r++) {
      const ks = []; for (let c = 0; c < this.rowCount(r); c++) ks.push(r * this.per + c);
      const ext = ks.map((k) => { const b = this.view[k]; return this.o.look === "drawing" && b !== drag?.b ? Math.max(0, this.preps[b].outW + 18 - P) * this.vis(this.f[b]) : 0; });
      const total = ext.reduce((a, v) => a + v, 0);
      let before = 0;
      ks.forEach((k, j) => { const b = this.view[k], p = this.slotPos(k); tx[b] = p.x + before / 2 - (total - before - ext[j]) / 2; ty[b] = p.y; before += ext[j]; });
    }
    const kp = 1 - Math.exp(-dt / this.tauPos);
    for (let b = 0; b < n; b++) {
      if (drag && b === drag.b) { this.px[b] = drag.u - drag.offU; this.py[b] = drag.y - drag.offY; continue; }
      const dx = tx[b] - this.px[b], dy = ty[b] - this.py[b];
      if (force) { this.px[b] = tx[b]; this.py[b] = ty[b]; }
      else if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05) { this.px[b] += dx * kp; this.py[b] += dy * kp; busy = true; }
      else { this.px[b] = tx[b]; this.py[b] = ty[b]; }
    }
    for (let b = 0; b < n; b++) {
      const g = this.groups[b], held = !!(drag && drag.b === b);
      if (force || this.px[b] !== this.lastPx[b] || this.py[b] !== this.lastPy[b]) { g.setAttribute("transform", `translate(${this.px[b].toFixed(2)} ${this.py[b].toFixed(2)})`); this.lastPx[b] = this.px[b]; this.lastPy[b] = this.py[b]; }
      const v = this.vis(this.f[b]);
      if (force || Math.abs(v - this.lastV[b]) >= 0.0005) {
        this.lastV[b] = v;
        const Pp = this.preps[b], theta = v * Math.PI / 2;
        g._body.setAttribute("d", boardPath(Pp, theta, 0, this.floorY));
        g._str.setAttribute("d", stringerPath(Pp, theta, 0, this.floorY));
        g._str.setAttribute("opacity", (Math.sin(theta) * 0.85).toFixed(3));
        const sx = -halfExtent(Pp, theta) - 4;
        if (state.spine === "up") g._spine.setAttribute("transform", `translate(${sx.toFixed(2)} ${this.floorY - 3}) rotate(-90)`);
        else g._spine.setAttribute("transform", `translate(${(sx - 9.5).toFixed(2)} ${this.top + 2}) rotate(90)`);
        g._spine.setAttribute("opacity", (1 - v).toFixed(3));
      }
      const lift = Math.max(v, held ? 1 : 0);
      if (force || lift !== this.lastLift[b] || held !== this.lastHeld[b]) {
        this.lastLift[b] = lift; this.lastHeld[b] = held;
        if (this.o.look === "shop") {
          g._lift.setAttribute("transform", `translate(0 ${this.floorY - 10 * lift}) scale(${1 + 0.1 * lift}) translate(0 ${-this.floorY})`);
          if (lift > 0.02) g._lift.setAttribute("filter", "url(#liftfx)"); else g._lift.removeAttribute("filter");
          if (!held && v > 0.5 && this.layer.lastElementChild !== g) this.layer.appendChild(g);
        } else {
          g._lift.setAttribute("transform", held ? "translate(0 -12)" : "");
          g._body.setAttribute("stroke", held ? "var(--color-accent-ink)" : "var(--color-text)");
          g._body.setAttribute("stroke-width", held ? "1.8" : "1.15");
        }
      }
    }
    // The gap a held board will drop into.
    if (drag) { const p = this.slotPos(drag.slot); this.tick.setAttribute("transform", `translate(${p.x} ${p.y + this.floorY + 7})`); this.tick.setAttribute("opacity", "1"); }
    else this.tick.setAttribute("opacity", "0");
    // The caption sits under the board that is turned (or turning most), in its row's band.
    let show = this.turned;
    if (mode === "follow" && this.cursor && !resting && !drag) { let m = -1; for (let b = 0; b < n; b++) if (this.tgt[b] > m) { m = this.tgt[b]; show = b; } }
    if (drag) this.cap.classList.add("hide");
    else {
      if (this.capFor !== show) { this.capFor = show; this.cap.innerHTML = captionHtml(this.list[show], show); }
      this.cap.classList.remove("hide");
      const p = this.slotPos(this.slotOf(show));
      this.cap.style.left = clamp(this.px[show] - 135, 0, this.CW - 270).toFixed(1) + "px";
      this.cap.style.top = (p.y + this.H + 10) + "px";
    }
    if (busy || drag || (this.cursor && now - this.lastMove < 400)) this.kick();
    else this.lastT = 0;
    if (this.o.onFrame) this.o.onFrame();
  }
}


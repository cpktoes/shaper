// Scratch only: drives sketch 010 in headless Chromium — hover, sweep, drag a board — and takes pictures.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const OUT = __dirname + "/shots/";
const URL = "file:///Users/kontoes/Code/shaper/.planning/sketches/010-sideways-board-rack/index.html";
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  await page.goto(URL);
  await page.waitForTimeout(800);
  const set = async (k, v) => { await page.evaluate(([k, v]) => { state[k] = v; renderAll(); }, [k, v]); await page.waitForTimeout(500); };
  const boardX = async (name) => page.evaluate((name) => { const b = rack.list.findIndex((x) => x.name === name); const rc = rack.svg.getBoundingClientRect(); return { x: rc.left + rack.px[b] * appScale, y: rc.top + (rack.py[b] + rack.floorY - 120) * appScale, b }; }, name);
  const info = async () => page.evaluate(() => ({ turned: rack.list[rack.turned].name, order: rack.order.map((b) => rack.list[b].name).join(" | "), f: rack.f.map((v) => +v.toFixed(2)).join(","), cap: document.querySelector(".dcap .name")?.textContent, bar: document.querySelector("#sketch-bar .meas")?.innerText, rows: rack.nRows, per: rack.per, boardsH: rack.boardsH, sPerIn: +(rack.s * 25.4).toFixed(2) }));

  await page.screenshot({ path: OUT + "a-rest.png" });
  console.log("rest", JSON.stringify(await info()));
  // Sweep the cursor slowly from the Groveler to the Log and stop half-way between two boards.
  const g = await boardX("Groveler"), l = await boardX("Log");
  await page.mouse.move(g.x, g.y);
  await page.mouse.move((g.x + l.x) / 2, g.y, { steps: 8 });
  await page.waitForTimeout(60);
  await page.screenshot({ path: OUT + "a-sweep-between.png" });
  console.log("between", JSON.stringify(await info()));
  await page.waitForTimeout(900);
  await page.screenshot({ path: OUT + "a-settled.png" });
  console.log("settled", JSON.stringify(await info()));
  // Drag the Log to the second place.
  const log = await boardX("Log"), dd = await boardX("Daily Driver");
  await page.mouse.move(log.x, log.y); await page.mouse.down();
  await page.mouse.move(log.x - 40, log.y - 10, { steps: 5 });
  await page.mouse.move(dd.x + 6, log.y - 10, { steps: 12 });
  await page.waitForTimeout(350);
  await page.screenshot({ path: OUT + "a-drag.png" });
  console.log("dragging", JSON.stringify(await page.evaluate(() => ({ slot: rack.drag && rack.drag.slot, view: rack.view.map((b) => rack.list[b].name).slice(0, 5).join(" | ") }))));
  await page.mouse.up();
  await page.waitForTimeout(900);
  await page.screenshot({ path: OUT + "a-dropped.png" });
  console.log("dropped", JSON.stringify(await info()));
  // A click without a drag opens the board.
  const egg = await boardX("Egg");
  await page.mouse.click(egg.x, egg.y);
  await page.waitForTimeout(150);
  console.log("toast", await page.evaluate(() => document.getElementById("toast").textContent));
  // Try to drag the unsaved board: it must stay first.
  const un = await boardX("Untitled Board");
  await page.mouse.move(un.x, un.y); await page.mouse.down(); await page.mouse.move(un.x + 200, un.y, { steps: 10 }); await page.mouse.up();
  await page.waitForTimeout(200);
  console.log("unsaved", await page.evaluate(() => document.getElementById("toast").textContent), JSON.stringify((await info()).order.split(" | ")[0]));
  // Move left from the ⋯ menu.
  await page.evaluate(() => rack.move(rack.list.findIndex((x) => x.name === "Egg"), -1));
  await page.waitForTimeout(600);
  console.log("menu-move", (await info()).order);

  // B: shop rack, mid-sweep and mid-drag.
  await set("variant", "b");
  await page.screenshot({ path: OUT + "b-rest.png" });
  const n1 = await boardX("Noserider");
  await page.mouse.move(n1.x - 60, n1.y); await page.mouse.move(n1.x, n1.y, { steps: 6 });
  await page.waitForTimeout(900);
  await page.screenshot({ path: OUT + "b-turned.png" });
  console.log("b", JSON.stringify(await info()));
  const sf = await boardX("Single Fin Mid");
  await page.mouse.move(sf.x, sf.y); await page.mouse.down(); await page.mouse.move(sf.x - 150, sf.y - 10, { steps: 12 });
  await page.waitForTimeout(350);
  await page.screenshot({ path: OUT + "b-drag.png" });
  await page.mouse.up(); await page.waitForTimeout(800);

  // 30 boards: two rows, then drag one from the second row into the first.
  await set("variant", "a"); await set("count", 30);
  await page.mouse.move(5, 5);
  await page.screenshot({ path: OUT + "a-30.png", fullPage: false });
  console.log("thirty", JSON.stringify(await info()));
  const jake = await boardX("Jake's Daily"), keel = await boardX("Keel Twin");
  await page.mouse.move(jake.x, jake.y); await page.mouse.down(); await page.mouse.move(keel.x, keel.y, { steps: 16 });
  await page.waitForTimeout(400);
  await page.screenshot({ path: OUT + "a-30-drag.png" });
  await page.mouse.up(); await page.waitForTimeout(900);
  console.log("thirty-drop", (await info()).order.split(" | ").slice(0, 5).join(" | "));
  // Today, for the yardstick.
  await set("count", 15); await set("variant", "today");
  console.log("today", JSON.stringify(await page.evaluate(() => document.querySelector("#sketch-bar .meas")?.innerText)));
  await page.screenshot({ path: OUT + "today.png" });
  // The calmer turn: only the board the cursor is on.
  await set("variant", "a"); await set("turn", "under");
  const st = await boardX("Step-Up");
  await page.mouse.move(st.x - 80, st.y); await page.mouse.move(st.x, st.y, { steps: 6 }); await page.waitForTimeout(800);
  console.log("under", JSON.stringify(await info()));
  await page.screenshot({ path: OUT + "a-under.png" });
  // Light theme.
  await set("turn", "follow"); await set("theme", "daylight");
  await page.mouse.move(5, 5); await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + "a-daylight.png" });
  await set("variant", "b"); await page.screenshot({ path: OUT + "b-daylight.png" });
  console.log("errors", JSON.stringify(errors));
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });

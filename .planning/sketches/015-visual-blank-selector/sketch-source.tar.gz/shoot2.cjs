const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const file = "file://" + process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch();
  const cases = [
    ["b-onescale-ghost", { variant: "b", device: "computer", scale: "one", ghost: true, board: "midlength" }],
    ["b-untitled-closed", { variant: "b", device: "computer", board: "default", ui: { a: { tab: "viewer" }, b: { tab: "viewer", open: false }, c: { tab: "viewer" } } }],
    ["a-upright-computer", { variant: "a", device: "computer", drawn: "upright" }],
    ["c-phone-flat", { variant: "c", device: "phone", drawn: "flat" }],
  ];
  for (const [name, st] of cases) {
    const page = await browser.newPage({ viewport: { width: 1440, height: 980 } });
    const errs = []; page.on("pageerror", (e) => errs.push(e.message));
    await page.goto(file);
    await page.evaluate((st) => localStorage.setItem("sketch015-r2", JSON.stringify({ theme: "slate", ...st })), st);
    await page.reload(); await page.waitForTimeout(300);
    if (name.startsWith("c-")) await page.evaluate(() => { const sb = document.querySelector(".sidebar"); const sect = [...sb.querySelectorAll(".sect")].find((e) => e.textContent.trim() === "Blank"); sb.scrollTop = sect.offsetTop - sb.offsetTop - 6; });
    await (await page.$(".device")).screenshot({ path: `${out}/${name}.png` });
    console.log(name, errs.length ? errs : "ok");
    await page.close();
  }
  await browser.close();
})();

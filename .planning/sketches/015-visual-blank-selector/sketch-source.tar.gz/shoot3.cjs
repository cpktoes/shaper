// Scratch only: the sketch as a real phone shows it, upright and sideways.
const { chromium, devices } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const file = "file://" + process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch();
  for (const [name, vp] of [["realphone-upright", { width: 390, height: 664 }], ["realphone-sideways", { width: 844, height: 340 }]]) {
    const ctx = await browser.newContext({ viewport: vp, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    const page = await ctx.newPage();
    const errs = []; page.on("pageerror", (e) => errs.push(e.message));
    await page.goto(file);
    await page.evaluate(() => localStorage.setItem("sketch015-r2", JSON.stringify({ theme: "slate", variant: "b" })));
    await page.reload(); await page.waitForTimeout(300);
    await page.screenshot({ path: `${out}/${name}.png` });
    const info = await page.evaluate(() => ({ dev: document.querySelector(".device").className, h: document.querySelector(".device").offsetHeight, scrollW: document.documentElement.scrollWidth, chrome: document.getElementById("chrome").offsetHeight }));
    // pick from the popup, then open Options
    await page.locator(".dialog .card").nth(4).tap(); await page.waitForTimeout(100);
    const afterPick = await page.evaluate(() => [state.ui.b.open, state.ui.b.picked]);
    await page.tap("#bar-btn"); await page.waitForTimeout(100);
    await page.screenshot({ path: `${out}/${name}-options.png` });
    console.log(name, info, afterPick, errs.length ? errs : "ok");
    await ctx.close();
  }
  await browser.close();
})();

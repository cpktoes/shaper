const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const file = "file://" + process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch();
  for (const [name, vp, mobile, scheme] of [["pub-phone-light", { width: 390, height: 664 }, true, "light"], ["pub-computer-dark", { width: 1440, height: 900 }, false, "dark"]]) {
    const ctx = await browser.newContext({ viewport: vp, isMobile: mobile, hasTouch: mobile, colorScheme: scheme });
    const page = await ctx.newPage(); const errs = []; page.on("pageerror", (e) => errs.push(e.message));
    await page.goto(file); await page.waitForTimeout(400);
    await page.screenshot({ path: `${out}/${name}.png` });
    console.log(name, errs.length ? errs : "ok", await page.evaluate(() => [state.theme, getComputedStyle(document.body).backgroundColor, document.documentElement.scrollWidth]));
    await ctx.close();
  }
  await browser.close();
})();

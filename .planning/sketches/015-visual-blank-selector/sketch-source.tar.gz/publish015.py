# Scratch only: turns sketch 015's page into the published copy (a page body for the artifact viewer). Recipe: sketch 011's publish011.py.
import re, sys
src = open(sys.argv[1]).read()
s = src
head_end = s.index("<style>")
title = "<title>Visual Blank Selector</title>\n"
fonts = '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">\n'
s = title + fonts + s[head_end:]
s = s.replace("</head>\n<body>\n", "").replace("</body>\n</html>\n", "")
assert "<head>" not in s and "<body>" not in s and "<html" not in s and "theme-link" not in s, "skeleton tags left"
slate = {"--color-bg": "#12141a", "--color-surface": "#12141a", "--color-canvas": "#1a1d25", "--color-well": "#1b1f26", "--color-border": "#333842", "--color-line": "#6a707c", "--color-text": "#f2f4f7", "--color-text-muted": "#a1a8b4", "--color-primary": "#18526d", "--color-on-primary": "#f2f4f7", "--color-accent-ink": "#3490bc", "--color-board": "#1a2732", "--color-warning-ink": "#ff9670", "--color-page": "#0b0c10", "--shadow-lg": "0 10px 24px rgba(0,0,0,0.45)"}
day = {"--color-bg": "#ffffff", "--color-surface": "#ffffff", "--color-canvas": "#dfdcd3", "--color-well": "#efece5", "--color-border": "#c9c2ad", "--color-line": "#897c58", "--color-text": "#1f2a3b", "--color-text-muted": "#566171", "--color-primary": "#8ec1b8", "--color-on-primary": "#1f2a3b", "--color-accent-ink": "#48605c", "--color-board": "#d9f2ed", "--color-warning-ink": "#ac3811", "--color-page": "#c9c5ba", "--shadow-lg": "0 10px 24px rgba(0,0,0,0.18)"}
decl = lambda d: " ".join(f"{k}: {v};" for k, v in d.items())
tokens = f"""  /* The app's own palettes: Daylight when the phone is light, Slate when it's dark. */
  :root {{ {decl(day)} --font-sans: "Inter", Roboto, system-ui, sans-serif; --tracking-architectural: 0.15em; }}
  @media (prefers-color-scheme: dark) {{ :root:not([data-theme="light"]) {{ {decl(slate)} color-scheme: dark; }} }}
  :root[data-theme="dark"] {{ {decl(slate)} color-scheme: dark; }}
"""
s = s.replace("<style>\n", "<style>\n" + tokens, 1)
old = "#chrome { position: sticky; top: 0;"
assert old in s
s = s.replace(old, "#chrome { position: sticky; top: env(safe-area-inset-top, 0px);", 1)
old = "#sketch-tools { position: fixed; bottom: 12px;"
assert old in s
s = s.replace(old, "#sketch-tools { position: fixed; bottom: calc(12px + env(safe-area-inset-bottom, 0px));", 1)
# Theme: follow the phone by default; Slate and Daylight stay in the switches.
old = 'variant: "b", device: "computer", drawn: "flat", board: "fish", units: "imperial", theme: "slate",'
assert old in s
s = s.replace(old, 'variant: "b", device: "computer", drawn: "flat", board: "fish", units: "imperial", theme: "auto",', 1)
old = "const DATA = "
s = s.replace(old, "window.__publish = true;\nconst DATA = ", 1)
s = s.replace('localStorage.getItem("sketch015-r2")', 'localStorage.getItem("visual-blank-selector-r2")').replace('localStorage.setItem("sketch015-r2"', 'localStorage.setItem("visual-blank-selector-r2"')
assert 'sketch015-r2"' not in s
open(sys.argv[2], "w").write(s)
# A local preview wraps it the way the viewer does.
open(sys.argv[3], "w").write('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><style>:root{color-scheme:light;padding-block:env(safe-area-inset-top,0) env(safe-area-inset-bottom,0)}body{margin:0;font:14px system-ui;background:#fafaf8}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' + s + "</body></html>")
print(len(s), "bytes; title:", re.search(r"<title>(.*?)</title>", s).group(1))

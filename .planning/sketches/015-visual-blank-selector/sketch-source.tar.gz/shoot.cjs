// Scratch only: pictures of sketch 015 via headless Chromium from the repo's own Playwright.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const file = "file://" + process.argv[2];
const out = process.argv[3];
const only = process.argv[4] || "";
(async () => {
  const browser = await chromium.launch();
  const shots = [
    ["b-computer-closed", { variant: "b", device: "computer" }, null],
    ["b-computer-open", { variant: "b", device: "computer" }, async (p) => { await p.click('.blankbtn'); }],
    ["a-computer-tab", { variant: "a", device: "computer" }, async (p) => { await p.click('.tab[data-tab="blanks"]'); }],
    ["c-computer", { variant: "c", device: "computer" }, async (p) => { await p.click('[data-act="cchange"]'); }],
    ["b-phone-open", { variant: "b", device: "phone" }, async (p) => { await p.click('.blankbtn'); }],
    ["b-phone-open-flat", { variant: "b", device: "phone", drawn: "flat" }, async (p) => { await p.click('.blankbtn'); }],
    ["a-phone-tab", { variant: "a", device: "phone" }, async (p) => { await p.click('.tab[data-tab="blanks"]'); }],
    ["c-phone", { variant: "c", device: "phone" }, async (p) => { await p.click('[data-act="cchange"]'); await p.evaluate(() => { const s = document.querySelector(".sidebar"); s.scrollTop = 300; }); }],
    ["b-side-open", { variant: "b", device: "side" }, async (p) => { await p.click('.blankbtn'); }],
    ["a-side-tab", { variant: "a", device: "side" }, async (p) => { await p.click('.tab[data-tab="blanks"]'); }],
    ["all-phone", { variant: "all", device: "phone" }, null],
  ].filter((s) => !only || s[0].includes(only));
  for (const [name, st, act] of shots) {
    for (const theme of ["slate"]) {
      const page = await browser.newPage({ viewport: { width: 1440, height: 980 } });
      const errs = [];
      page.on("pageerror", (e) => errs.push(e.message));
      page.on("console", (m) => { if (m.type() === "error") errs.push(m.text()); });
      await page.goto(file);
      await page.evaluate(([st, theme]) => { localStorage.setItem("sketch015", JSON.stringify({ ui: { a: { tab: "viewer" }, b: { tab: "viewer", open: false }, c: { tab: "viewer", listOpen: false } }, ...st, theme })); }, [st, theme]);
      await page.reload();
      await page.waitForTimeout(300);
      if (act) await act(page);
      await page.waitForTimeout(250);
      const dev = await page.$(".compare") || await page.$(".device");
      await (dev).screenshot({ path: `${out}/${name}-${theme}.png` });
      console.log(name, theme, errs.length ? "ERRORS " + errs.join(" | ") : "ok");
      await page.close();
    }
  }
  await browser.close();
})();

// Scratch only: drives sketch 015's controls and checks each one does what it says.
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const file = "file://" + process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 980 } });
  const errs = []; page.on("pageerror", (e) => errs.push(e.message));
  await page.goto(file);
  await page.evaluate(() => localStorage.setItem("sketch015-r2", JSON.stringify({ variant: "b", device: "computer", theme: "daylight", ui: { a: { tab: "viewer" }, b: { tab: "viewer", open: false }, c: { tab: "viewer", listOpen: false } } })));
  await page.reload(); await page.waitForTimeout(200);
  const st = () => page.evaluate(() => ({ open: state.ui.b.open, picked: state.ui.b.picked, stars: state.stars.length, cards: document.querySelectorAll(".dialog .card").length, count: document.querySelector("[data-count]")?.textContent }));
  await page.click(".blankbtn"); console.log("opened", await st());
  await page.click('.dialog .card[data-id="Arctic Foam|6\'0\\" SB"] .star').catch(async () => { console.log("star-by-id failed; first unstarred"); });
  console.log("after star", await st());
  // one tap on a star must change the count by exactly one (the 011 double-fire bug)
  const s0 = (await st()).stars; await page.locator(".dialog .card .star:not(.on)").first().click(); console.log("star once:", s0, "->", (await st()).stars);
  // maker chip
  await page.click('.chip[data-m="US Blanks"]'); console.log("hide US Blanks", await st());
  await page.click('.chip[data-m="US Blanks"]');
  // search
  await page.fill('.dialog [data-act="q"]', "marko"); await page.waitForTimeout(100); console.log("search marko", await st(), await page.evaluate(() => document.activeElement.dataset.act));
  await page.fill('.dialog [data-act="q"]', "");
  // length range
  await page.click('[data-act="fopen"][data-k="len"]');
  await page.evaluate(() => { const r = document.querySelector('.drawer input[data-i="1"]'); r.value = String(7 * 12 * 25.4); r.dispatchEvent(new Event("input", { bubbles: true })); r.dispatchEvent(new Event("change", { bubbles: true })); });
  await page.waitForTimeout(100); console.log("length to 7'", await st(), await page.textContent('[data-act="fopen"][data-k="len"]'));
  await page.screenshot({ path: `${out}/b-drawer-daylight.png`, clip: { x: 0, y: 90, width: 1440, height: 890 } });
  await page.click('[data-act="rngreset"]').catch(() => {});
  // scroll to the won't fit group
  await page.evaluate(() => { const g = [...document.querySelectorAll(".dialog .grp-label")].find((e) => /Won/.test(e.textContent)); g.scrollIntoView(); });
  await page.waitForTimeout(150);
  await (await page.$(".device")).screenshot({ path: `${out}/b-wontfit-daylight.png` });
  // pick a card: the popup closes and the blank loads
  await page.locator(".dialog .card").nth(5).click(); console.log("picked", await st());
  // A: browse switches tab, pick returns to viewer
  await page.click('[data-set="variant"][data-val="a"]'); console.log("A tab", await page.evaluate(() => state.ui.a.tab));
  await page.locator(".panel .card").nth(2).click(); console.log("A after pick", await page.evaluate(() => [state.ui.a.tab, state.ui.a.picked]));
  // C
  await page.click('[data-set="variant"][data-val="c"]'); await page.locator(".brow").nth(4).click(); console.log("C after pick", await page.evaluate(() => [state.ui.c.picked, !!state.ui.c.listOpen]));
  // all three
  await page.click('[data-set="variant"][data-val="all"]'); await page.waitForTimeout(150);
  await page.screenshot({ path: `${out}/all-computer-daylight.png` });
  await page.click('[data-set="device"][data-val="phone"]'); await page.waitForTimeout(150);
  await page.screenshot({ path: `${out}/all-phone-daylight.png` });
  console.log("errors:", errs.length ? errs : "none");
  await browser.close();
})();

/* Scratch only (sketch 015): runs the app's own blank maths over the whole catalogue and writes every
   pickable blank — its printed dims, its card lines in both systems, its fit verdict for the default
   board, and its curves (levelled bottom, deck, half-width) — as JSON for the sketch to draw. Never committed. */
import { writeFileSync } from "node:fs";
import { isPickable } from "@/lib/blanks/catalog";
import { readSeedCatalog } from "@/lib/blanks/seed-files";
import { KNOWN_BLANK_VENDORS } from "@/lib/blanks/vendors";
import { DEFAULT_BLANK_CUT } from "@/lib/geometry/blank";
import { floorCheck, listBlanks, prepareBlank, type BoardFitContext } from "@/lib/geometry/blank-fit";
import { blankRowMeta, blankRowVolume, formatShortfall } from "@/lib/geometry/blank-reasons";
import { DEFAULT_BOARD_SPEC } from "@/lib/geometry/board";
import { DEFAULT_FIT_DEFAULTS } from "@/lib/fit-defaults-preference";
import { buildOutline, sampleOutline } from "@/lib/geometry/outline";
import { silhouette } from "@/lib/geometry/screen-tiles";
import { formatDim, formatLength, formatMark } from "@/lib/geometry/measure-display";
import { mm, type Mm } from "@/lib/geometry/units";

const out = process.argv[2];
const catalogue = readSeedCatalog();
const counts: Record<string, { all: number; pickable: number }> = {};
for (const r of catalogue) {
  counts[r.vendor] ??= { all: 0, pickable: 0 };
  counts[r.vendor].all++;
  if (isPickable(r)) counts[r.vendor].pickable++;
}
const prepared = catalogue.filter(isPickable).map(prepareBlank);


import { BOARD_PRESETS } from "@/lib/geometry/presets";
const BOARDS = [
  { id: "default", name: "Untitled (a new board)", outline: DEFAULT_BOARD_SPEC.outline, foil: DEFAULT_BOARD_SPEC.foil, pick: null as null | { vendor: string; name: string } },
  ...BOARD_PRESETS.map((p) => ({ id: p.id, name: p.name, outline: p.outline, foil: { ...DEFAULT_BOARD_SPEC.foil, ...p.foil }, pick: p.blank ? { vendor: p.blank.vendor, name: p.blank.name } : null })),
];
const { extraLength, planerMaxDepth, widthMargin } = DEFAULT_FIT_DEFAULTS;
const r1 = (n: number) => Math.round(n * 10) / 10;
const boards = BOARDS.map((bd) => {
  const geometry = buildOutline(bd.outline);
  const ctx: BoardFitContext = {
    board: {
      length: bd.outline.length, centerThickness: bd.foil.center, noseTip: bd.foil.noseTip, tailTip: bd.foil.tailTip,
      nose12Offset: mm(0), tail12Offset: mm(0), deckSkin: DEFAULT_BLANK_CUT.deckSkin, tipStyle: DEFAULT_BLANK_CUT.tipStyle,
      fineTuneSurface: DEFAULT_BLANK_CUT.fineTuneSurface,
    },
    halfWidthAt: (s: Mm) => sampleOutline(geometry, s),
    widePointStation: geometry.widePointStation,
  };
  const list = listBlanks(prepared, ctx, { extraLength, planerMaxDepth, widthMargin });
  const info = { length: bd.outline.length, widePointStation: geometry.widePointStation, centerThickness: bd.foil.center };
  const verdicts: Record<string, [string, number, string | null, string | null]> = {};
  for (const v of list.fits) verdicts[`${v.prepared.record.vendor}|${v.prepared.record.name}`] = ["f", r1(v.placement), null, null];
  for (const v of list.wontFit) verdicts[`${v.prepared.record.vendor}|${v.prepared.record.name}`] = ["w", r1(v.placement), formatShortfall(v.worst, info, "imperial"), formatShortfall(v.worst, info, "metric")];
  // The pasted spec: only the length floor hides a blank; one too thin at the centre is listed greyed, with why.
  for (const pb of prepared) {
    const id = `${pb.record.vendor}|${pb.record.name}`;
    if (verdicts[id]) continue;
    const floor = floorCheck(pb, { length: bd.outline.length, centerThickness: bd.foil.center, deckSkin: DEFAULT_BLANK_CUT.deckSkin }, { extraLength, planerMaxDepth, widthMargin });
    if (floor.lengthShortBy !== null) continue;
    const need = mm(bd.foil.center + DEFAULT_BLANK_CUT.deckSkin + planerMaxDepth);
    const say = (sys: "imperial" | "metric") => `Too thin at the center — ${formatMark(pb.centerThicknessMm, sys)}, and this board needs ${formatMark(need, sys)} there (its ${formatMark(bd.foil.center, sys)} center, a ${formatMark(DEFAULT_BLANK_CUT.deckSkin, sys)} deck skin and a ${formatMark(planerMaxDepth, sys)} bottom pass)`;
    verdicts[id] = ["t", 0, say("imperial"), say("metric")];
  }
  const maxHalf = Math.max(...silhouette(geometry).map((p) => Math.abs(p.w)));
  return {
    id: bd.id, name: bd.name, pick: bd.pick ? `${bd.pick.vendor}|${bd.pick.name}` : null,
    lengthMm: bd.outline.length, centerMm: bd.foil.center,
    lineI: `${formatLength(bd.outline.length, "imperial")} × ${formatDim(mm(maxHalf * 2), "imperial")} × ${formatMark(bd.foil.center, "imperial")}`,
    lineM: `${formatLength(bd.outline.length, "metric")} × ${formatDim(mm(maxHalf * 2), "metric")} × ${formatMark(bd.foil.center, "metric")}`,
    silhouette: silhouette(geometry).map(({ station, w }) => [r1(station), r1(w)]),
    counts: { fits: list.fits.length, wontFit: list.wontFit.length },
    verdicts,
  };
});

const N = 72;
const tipFr: number[] = [];
for (let k = 1; k < 12; k++) tipFr.push((1 / N) * (k / 12) ** 2);
const fr = [...new Set([...Array.from({ length: N + 1 }, (_, i) => i / N), ...tipFr, ...tipFr.map((f) => 1 - f)])].sort((a, b) => a - b);
const q = (n: number) => Math.round(n * 2); // half-millimetres as integers

const blanks = prepared.map((p) => {
  const r = p.record;
  const L = r.lengthMm;
  const xs = fr.map((f) => f * L);
  const st = (label: string) => r.stations.find((s) => s.label === label) ?? null;
  const c = st("C");
  const maxW = Math.max(...r.stations.map((s) => s.widthMm ?? 0));
  const fmt = (v: number | null, kind: "dim" | "mark", sys: "imperial" | "metric") => v == null ? null : kind === "dim" ? formatDim(mm(v), sys) : formatMark(mm(v), sys);
  const table = ["N0", "N12", "C", "T12", "T0"].map((l) => {
    const s = st(l);
    return s ? { l, wI: fmt(s.widthMm, "dim", "imperial"), wM: fmt(s.widthMm, "dim", "metric"), tI: fmt(s.thicknessMm, "mark", "imperial"), tM: fmt(s.thicknessMm, "mark", "metric"), rI: fmt(s.rockerMm, "mark", "imperial"), rM: fmt(s.rockerMm, "mark", "metric") } : { l };
  });
  const noseR = p.rocker.sample(mm(L)), tailR = p.rocker.sample(mm(0));
  const cw = c?.widthMm ?? null;
  return {
    id: `${r.vendor}|${r.name}`, vendor: r.vendor, name: r.name, lengthMm: r1(L), volume: r.volumeLitres,
    lenI: formatLength(L, "imperial"), lenM: formatLength(L, "metric"),
    widthI: formatDim(mm(maxW), "imperial"), widthM: formatDim(mm(maxW), "metric"),
    centerI: c?.thicknessMm != null ? formatMark(c.thicknessMm, "imperial") : null,
    centerM: c?.thicknessMm != null ? formatMark(c.thicknessMm, "metric") : null,
    noseRI: formatMark(mm(noseR), "imperial"), noseRM: formatMark(mm(noseR), "metric"),
    tailRI: formatMark(mm(tailR), "imperial"), tailRM: formatMark(mm(tailR), "metric"),
    noseRmm: r1(noseR), tailRmm: r1(tailR), centerMm: c?.thicknessMm ?? null,
    cWidthI: cw != null ? formatDim(mm(cw), "imperial") : null, cWidthM: cw != null ? formatDim(mm(cw), "metric") : null,
    metaI: blankRowMeta(r, "imperial"), metaM: blankRowMeta(r, "metric"), vol: blankRowVolume(r),
    table,
    b: xs.map((x) => q(p.rocker.sample(mm(x)))),
    t: xs.map((x) => q(p.thickness.sample(mm(x)))),
    h: xs.map((x) => q(Math.max(0, p.width.sample(mm(x)) / 2))),
    printed: r.stations.filter((s) => s.widthMm != null).map((s) => [r1(s.fromTailMm), q(s.widthMm! / 2)]),
  };
});

writeFileSync(out, JSON.stringify({ makers: KNOWN_BLANK_VENDORS, counts, fr: fr.map((f) => Math.round(f * 1e6) / 1e6), boards, blanks }));
console.log("blanks", blanks.length, boards.map((b) => [b.id, b.counts, b.pick, b.lineI, Object.values(b.verdicts).filter((v) => v[0] === "t").length, Object.keys(b.verdicts).length]));

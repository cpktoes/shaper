// Scratch only: writes sketch 015's self-contained page from template.html + blanks.json.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
const here = new URL(".", import.meta.url);
const data = readFileSync(new URL("./blanks.json", here), "utf8");
const html = readFileSync(new URL("./template.html", here), "utf8").replace("/*__DATA__*/", () => data);
const dir = process.argv[2];
mkdirSync(dir, { recursive: true });
writeFileSync(`${dir}/index.html`, html);
console.log("wrote", `${dir}/index.html`, html.length, "bytes");

/* Sketch 019's real board figures, read from the app's own maths. Never hand-type a board number. */
import { writeFileSync } from "node:fs";
import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/__fixtures__/phase16-boards";
import { designCrossSectionInput, designSideProfile, deriveEffectiveRails, summarizeDesign, deriveEffectiveFins, LIVE_DESIGN_RULES } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/design";
import { buildOutline, foamHalfWidth, sampleOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/outline";
import { boardSections } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/volume";
import { sampledFinishedRail } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/finished-rail";
import { computeFinPlacement, importedFinTailFromOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/presets";
import { mm } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/units";

const STATIONS = 241;      // the long table: width, thickness, every 1/240 of the board
const SECTIONS = 49;       // real cross-sections down the board
// across the half-section, as a share of the half-width: closer together at the rail where it turns
const U = [0, .2, .4, .55, .68, .78, .85, .9, .93, .955, .975, .988, .996, 1];
const r1 = (v: number) => Math.round(v * 10) / 10;

function at(run: [number, number][], x: number): number {
  // run is ordered by x, either way round
  for (let i = 0; i < run.length - 1; i++) {
    const [x0, y0] = run[i], [x1, y1] = run[i + 1];
    if ((x >= x0 && x <= x1) || (x >= x1 && x <= x0)) {
      const t = x1 === x0 ? 0 : (x - x0) / (x1 - x0);
      return y0 + (y1 - y0) * t;
    }
  }
  return run[run.length - 1][1];
}

const all = phase16Boards();
const out: unknown[] = [];
for (const preset of BOARD_PRESETS) {
  const hard = preset.rails.tailHardEdge ? "hard" : "soft";
  const board = all.find((b) => b.label === `${preset.id}|asis|${hard}`)!;
  const fields = board.fields;
  const g = buildOutline(fields.outline);
  const profile = designSideProfile(fields, LIVE_DESIGN_RULES);
  const rails = deriveEffectiveRails(fields.rails, profile.effectiveFoil, fields.railsImportFoilThickness);
  const input = designCrossSectionInput(g, profile, rails, fields.outline.length);
  const L = fields.outline.length as number;
  const litres = summarizeDesign(fields).volumeLitres as number;

  const curve: number[] = [], foam: number[] = [], thick: number[] = [];
  for (let i = 0; i < STATIONS; i++) {
    const s = mm((i / (STATIONS - 1)) * L);
    curve.push(r1(sampleOutline(g, s)));
    foam.push(r1(foamHalfWidth(g, s)));
    thick.push(r1(profile.thicknessAt(s)));
  }

  const stations = Array.from({ length: SECTIONS }, (_, i) => mm((i / (SECTIONS - 1)) * L));
  const secs = boardSections(input, stations);
  const sections = secs.map((sec) => {
    const s = sec.station as number;
    const W = sec.halfWidth as number;
    const inner = Math.max(0, (sampleOutline(g, sec.station) as number) - W);
    if (!sec.result || W <= 0) return { s: r1(s), W: 0, T: r1(sec.thickness), inner: r1(inner), lo: U.map(() => 0), hi: U.map(() => 0) };
    const half = sec.blended ?? sampledFinishedRail(sec.result, sec.domed, W);
    let apex = 0;
    for (let i = 1; i < half.length; i++) if (half[i][0] > half[apex][0]) apex = i;
    const deck = half.slice(0, apex + 1) as [number, number][];
    const bottom = half.slice(apex) as [number, number][];
    return {
      s: r1(s), W: r1(W), T: r1(sec.thickness), inner: r1(inner),
      hi: U.map((u) => r1(at(deck, u * W))),
      lo: U.map((u) => r1(at(bottom, u * W))),
    };
  });

  const fins = computeFinPlacement(
    deriveEffectiveFins(fields.fins, fields.finsImportTemplate, fields.outline, g),
    fields.finsImportTemplate ? importedFinTailFromOutline(g) : null,
  );
  const r = fins.resolved as unknown as Record<string, number>;
  out.push({
    id: preset.id, name: preset.name, L: r1(L), litres,
    wide: r1(g.widePointStation), widePointWidth: r1(fields.outline.widePointWidth as number),
    fin: r1(Math.max(...(fins.marks.some((m) => m.role === "front") ? fins.marks.filter((m) => m.role === "front") : fins.marks).map((m) => m.offTail as number))), finWord: fins.marks.some((m) => m.role === "front") ? "Front fins" : "Fin",
    finSetup: fields.fins.finSetup, tail: fields.outline.tail.kind,
    close: r1(g.centreCloseStation), block: r1(g.points[0].halfWidth), first: r1(g.points[0].station),
    outline: g.points.map((p) => [r1(p.station), r1(p.halfWidth)]),
    curve, foam, thick, sections,
  });
  console.log(preset.name, "L", (L / 25.4).toFixed(2), "litres", litres.toFixed(2), "wide from tail", ((g.widePointStation as number) / 25.4).toFixed(2),
    "tail", fields.outline.tail.kind, "close", ((g.centreCloseStation as number) / 25.4).toFixed(2), "first", ((g.points[0].station as number) / 25.4).toFixed(2),
    fields.fins.finSetup, "center T", ((profile.thicknessAt(mm(L / 2)) as number) / 25.4).toFixed(3));
}
writeFileSync("/private/tmp/claude-501/-Users-kontoes-Code-shaper--claude-worktrees-unruffled-jackson-c76275/7b5389e2-7382-49ed-ba5a-3a8051c827d3/scratchpad/019/boards.json", JSON.stringify({ U, boards: out }));

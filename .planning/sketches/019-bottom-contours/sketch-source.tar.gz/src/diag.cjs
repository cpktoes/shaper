const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  await page.goto("file://" + process.argv[2]);
  await page.waitForFunction(() => window.sketch);
  const r = await page.evaluate(() => {
    const q = (s) => { const e = document.querySelector(s); const b = e.getBoundingClientRect(); const cs = getComputedStyle(e); return { y: Math.round(b.y), h: Math.round(b.height), w: Math.round(b.width), d: cs.display, of: cs.overflow }; };
    return { app: document.getElementById("app").className, inner: window.innerWidth + "x" + window.innerHeight, shell: q(".shell"), main: q(".main"), folder: q(".folder"), innerCard: q("#viewerPanel"), secrow: q("#secrow"), tail: q('#secrow [data-sec="tail"]'), views: q(".views"), top: q("#top"), sec: q("#sec"), foot: q("#foot"), side: q(".side"), controls: q("#controls") };
  });
  console.log(JSON.stringify(r, null, 1));
  await browser.close();
})();

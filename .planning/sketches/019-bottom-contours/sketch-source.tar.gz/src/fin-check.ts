import { phase16Boards } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/__fixtures__/phase16-boards";
import { deriveEffectiveFins } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/design";
import { buildOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/outline";
import { computeFinPlacement, importedFinTailFromOutline } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/fins";
import { BOARD_PRESETS } from "/Users/kontoes/Code/shaper/.claude/worktrees/unruffled-jackson-c76275/lib/geometry/presets";
const all = phase16Boards();
for (const preset of BOARD_PRESETS) {
  const b = all.find((x) => x.label.startsWith(preset.id + "|asis"))!;
  const f = b.fields; const g = buildOutline(f.outline);
  const res = computeFinPlacement(deriveEffectiveFins(f.fins, f.finsImportTemplate, f.outline, g), f.finsImportTemplate ? importedFinTailFromOutline(g) : null);
  console.log(preset.id, f.fins.finSetup, JSON.stringify(res.marks.map((m: any) => ({ role: m.role, off: +(m.offTail/25.4).toFixed(2), x: m.offCenter !== undefined ? +(m.offCenter/25.4).toFixed(2) : undefined }))));
  console.log(Object.fromEntries(Object.entries(res.resolved).filter(([k,v]) => /OffTail/.test(k)).map(([k,v]) => [k, +((v as number)/25.4).toFixed(2)])));
}

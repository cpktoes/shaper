// extra pictures: the phone at ×1 with the Longboard's belly, and the Shortboard's tail section on the phone
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  await page.goto("file://" + process.argv[2]);
  await page.waitForFunction(() => window.sketch);
  await page.click('#bar [data-b="longboard"]'); await page.waitForTimeout(100);
  await page.click('#exag [data-e="1"]'); await page.waitForTimeout(100);
  await page.screenshot({ path: path.join(process.argv[3], "phone-longboard-x1.png") });
  await page.click('#bar [data-b="shortboard"]'); await page.click('#exag [data-e="4"]'); await page.waitForTimeout(100);
  await page.evaluate(() => { window.sketch.state.station = 10.88 * 25.4; window.sketch.state.active = "tail"; window.sketch.render(true); });
  await page.waitForTimeout(150);
  await page.screenshot({ path: path.join(process.argv[3], "phone-shortboard-tail.png") });
  await browser.close();
})();

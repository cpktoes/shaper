// Headless checks of sketch 019 at a computer's width and an upright phone's, with pictures.
// Run: node test.cjs <path-to-index.html> <out-dir>
const { chromium } = require("/Users/kontoes/Code/shaper/node_modules/playwright");
const path = require("node:path");
const fs = require("node:fs");

const file = process.argv[2];
const out = process.argv[3];
fs.mkdirSync(out, { recursive: true });
const url = "file://" + path.resolve(file);

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  const errors = [];

  // ---- a computer: 1280 x 800 ----
  let page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("pageerror", (e) => errors.push("desktop: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("desktop console: " + m.text()); });
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const desk = await page.evaluate(() => {
    const app = document.getElementById("app");
    const side = document.querySelector(".side").getBoundingClientRect();
    const main = document.querySelector(".main").getBoundingClientRect();
    const top = document.getElementById("top").getBoundingClientRect();
    const sec = document.getElementById("sec").getBoundingClientRect();
    return { phone: app.classList.contains("phone"), side: [side.x, side.width, side.height], main: [main.x, main.width, main.height], top: [top.width, top.height], sec: [sec.width, sec.height],
      rects: document.querySelectorAll("#top .shade rect").length, foot: document.getElementById("foot").innerText, sections: document.querySelectorAll(".sidesec").length,
      shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, litresOff: window.sketch.litresOff() };
  });
  console.log("desktop", JSON.stringify(desk));
  if (desk.phone) problems.push("desktop got the phone layout");
  if (desk.side[1] !== 340) problems.push("sidebar is not 340 wide: " + desk.side[1]);
  if (desk.shown !== 3) problems.push("a computer should show all three sections, shows " + desk.shown);
  if (desk.rects < 100) problems.push("no shade drawn");
  await page.screenshot({ path: path.join(out, "desktop-A-daylight.png") });

  // the planning memory's rough figure: a 3/16" single 2" off the rail takes about 0.55 L off the Shortboard
  const check = await page.evaluate(() => {
    const s = window.sketch; const B = s.state;
    const c = B.cuts.center; const IN = 25.4;
    B.cuts.nose = { ...B.cuts.nose, kind: "flat", depth: 0 }; B.cuts.tail = { ...B.cuts.tail, kind: "flat", depth: 0 };
    Object.assign(c, { kind: "single", off: 2 * IN, start: 74 * IN - 16 * IN, deep: (36 + 10.88) / 2 * IN, end: 6 * IN, depth: 3 / 16 * IN, smooth: 50, pointed: false, spiral: false });
    const a = s.litresOff(); c.smooth = 0; const b = s.litresOff(); c.smooth = 100; const d = s.litresOff();
    return { at50: a, at0: b, at100: d };
  });
  console.log("3/16 single, 2 off rail, 16 off the nose to 6 off the tail:", JSON.stringify(check));
  if (!(check.at50 > 0.4 && check.at50 < 0.7)) problems.push("litres off the test single is off: " + check.at50);

  // drag the section line: the section caption must follow
  await page.evaluate(() => { window.sketch.setBoard("shortboard"); window.sketch.render(true); });
  await page.waitForTimeout(100);
  const before = await page.textContent("#secCap");
  const grab = await page.$("#grab");
  const gb = await grab.boundingBox();
  await page.mouse.move(gb.x + gb.width / 2, gb.y + gb.height / 2);
  await page.mouse.down();
  await page.mouse.move(gb.x + 150, gb.y + gb.height / 2, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(100);
  const after = await page.textContent("#secCap");
  console.log("section caption before/after drag:", before, "|", after);
  if (before === after) problems.push("dragging the section line did not move the section");

  // every variant, theme and units pair draws without error; DATA renders rows
  for (const v of ["A", "B", "C"]) for (const t of ["daylight", "chalk", "slate", "phosphor"]) {
    await page.click(`#bar [data-v="${v}"]`); await page.click(`#bar [data-t="${t}"]`); await page.waitForTimeout(60);
    if (v === "A" || t === "slate") await page.screenshot({ path: path.join(out, `desktop-${v}-${t}.png`) });
  }
  await page.click('#bar [data-u="metric"]'); await page.waitForTimeout(80);
  const metricFoot = await page.textContent("#foot");
  const metricLbl = await page.evaluate(() => [...document.querySelectorAll("#sections [data-lbl]")].map((e) => e.textContent));
  console.log("metric foot:", metricFoot.replace(/\n/g, " | "));
  console.log("metric labels:", metricLbl.join(" / "));
  if (!/mm/.test(metricFoot)) problems.push("metric foot shows no millimetres");
  if (!metricLbl.some((l) => / cm from the/.test(l))) problems.push("metric station labels do not read in cm");
  if (!metricLbl.some((l) => /Depth — \d+ mm/.test(l))) problems.push("metric depth does not read in whole mm");
  await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  const rows = await page.evaluate(() => document.querySelectorAll("#dataPanel tbody tr").length);
  console.log("DATA rows (metric):", rows);
  if (rows < 10) problems.push("DATA has too few rows: " + rows);
  await page.screenshot({ path: path.join(out, "desktop-data-metric.png") });
  await page.click('#bar [data-u="imperial"]'); await page.click('#bar [data-t="daylight"]'); await page.click('#bar [data-v="A"]');
  await page.click('.tabs [data-page="viewer"]');
  for (const b of ["fish", "midlength", "longboard"]) { await page.click(`#bar [data-b="${b}"]`); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, `desktop-${b}.png`) }); }
  // the sketch bar's phone frame on a computer must give the same phone stack
  await page.click('#bar [data-b="shortboard"]'); await page.click('#bar [data-f="1"]'); await page.waitForTimeout(150);
  const framed = await page.evaluate(() => ({ topbar: getComputedStyle(document.querySelector(".topbar")).display, w: document.getElementById("app").getBoundingClientRect().width,
    shown: [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").length, sec: document.getElementById("sec").getBoundingClientRect().height }));
  console.log("phone frame on a computer:", JSON.stringify(framed));
  if (framed.topbar !== "flex" || framed.w !== 390 || framed.shown !== 1) problems.push("the phone frame does not give the phone stack");
  if (framed.sec < 90) problems.push("the framed section drawing is squashed: " + framed.sec);
  await page.screenshot({ path: path.join(out, "desktop-phone-frame.png") });
  await page.click('#bar [data-f="0"]');
  await page.close();

  // ---- an upright phone: 390 x 844 (iPhone 14), touch ----
  page = await browser.newPage({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  page.on("pageerror", (e) => errors.push("phone: " + e.message));
  await page.goto(url);
  await page.waitForFunction(() => window.sketch && document.querySelectorAll("#top path.board").length > 0);
  const ph = await page.evaluate(() => {
    const app = document.getElementById("app");
    const main = document.querySelector(".main").getBoundingClientRect();
    const side = document.querySelector(".side").getBoundingClientRect();
    const bar = document.querySelector(".topbar").getBoundingClientRect();
    const shown = [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec);
    const secrow = getComputedStyle(document.getElementById("secrow")).display;
    const scroll = document.getElementById("controls");
    return { phone: app.classList.contains("phone"), topbar: [bar.height, getComputedStyle(document.querySelector(".topbar")).display], main: [main.y, main.height], side: [side.y, side.height], shown, secrow,
      scrollable: scroll.scrollHeight > scroll.clientHeight, docScroll: document.documentElement.scrollHeight, inner: window.innerHeight };
  });
  console.log("phone", JSON.stringify(ph));
  if (ph.topbar[1] !== "flex" || ph.main[0] > ph.side[0]) problems.push("phone did not get the phone layout (width alone)");
  if (ph.shown.length !== 1) problems.push("phone should show one section's controls, shows " + ph.shown.join(","));
  if (ph.secrow === "none") problems.push("phone has no NOSE/CENTER/TAIL switch");
  if (ph.docScroll > ph.inner + 2) problems.push("the phone page scrolls as a whole (" + ph.docScroll + " > " + ph.inner + ")");
  const boxes = await page.evaluate(() => ({ top: document.getElementById("top").getBoundingClientRect().height, sec: document.getElementById("sec").getBoundingClientRect().height, bar: document.getElementById("bar").getBoundingClientRect().height,
    main: document.querySelector(".main").getBoundingClientRect().height, controls: document.getElementById("controls").getBoundingClientRect().height }));
  console.log("phone boxes:", JSON.stringify(boxes));
  if (boxes.sec < 90) problems.push("the phone's section drawing is squashed: " + boxes.sec);
  if (boxes.bar > 60) problems.push("the sketch bar is too tall on a phone: " + boxes.bar);
  await page.screenshot({ path: path.join(out, "phone-A-daylight.png") });
  await page.click('#bar [data-b="fish"]'); await page.waitForTimeout(120); await page.screenshot({ path: path.join(out, "phone-fish.png") }); await page.click('#bar [data-b="shortboard"]'); await page.waitForTimeout(120);
  // the switch changes which section's controls show
  await page.tap('#secrow [data-sec="tail"]'); await page.waitForTimeout(80);
  const shownTail = await page.evaluate(() => [...document.querySelectorAll(".sidesec")].filter((e) => getComputedStyle(e).display !== "none").map((e) => e.dataset.sec));
  console.log("after tapping TAIL:", shownTail);
  if (shownTail.join() !== "tail") problems.push("TAIL switch did not show the tail's controls");
  // a thumb drag on the board moves the section
  const b4 = await page.textContent("#secCap");
  const topBox = await (await page.$("#top")).boundingBox();
  await page.touchscreen.tap(topBox.x + topBox.width * 0.3, topBox.y + topBox.height / 2);
  await page.waitForTimeout(80);
  const aft = await page.textContent("#secCap");
  console.log("phone tap on the board:", b4, "|", aft);
  if (b4 === aft) problems.push("tapping the board on a phone did not move the section");
  await page.click('#bar [data-t="slate"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-A-slate.png") });
  await page.click('#bar [data-v="B"]'); await page.click('#bar [data-t="phosphor"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-B-phosphor.png") });
  await page.click('#bar [data-u="metric"]'); await page.click('#bar [data-b="longboard"]'); await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(out, "phone-longboard-metric.png") });
  await page.click('.tabs [data-page="data"]'); await page.waitForTimeout(80);
  await page.screenshot({ path: path.join(out, "phone-data.png") });
  await page.close();

  await browser.close();
  console.log("\nERRORS:", errors.length ? errors.join("\n") : "none");
  console.log("PROBLEMS:", problems.length ? problems.join("\n") : "none");
  process.exit(problems.length || errors.length ? 1 : 0);
})();
